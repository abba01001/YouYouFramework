using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JsonDisplay : MonoBehaviour
{

    [HideInInspector]
    public string jsonString = "{\"name\": \"example\", \"value\": 123}"; // 示例JSON字符串

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            var dataService = MainContainer.Container.Resolve<IDataService>();
            dataService.SaveData(true, true);
            var storageService = MainContainer.Container.Resolve<IStorageService>();
            jsonString = storageService.Load<string>("GameData", "");
        }
    }
}
