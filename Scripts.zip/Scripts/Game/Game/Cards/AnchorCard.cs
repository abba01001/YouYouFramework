using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using SoliUtils;

public class AnchorCard : BaseCard
{
    public GameObject ProcessObj;
    public SpriteRenderer ProcessSprite;
    public TMPro.TMP_Text ProcessText;

    public override bool IsFaceUp
    {
        get => _isFaceUp;
        set
        {
            // if (_isFaceUp == value) return;
            _isFaceUp = value;
            cardObj.transform.localScale = value ? Vector3.one : faceDownVec;
            cardObj.transform.localScale *= Constants.CardSizeScale;
            ProcessObj.SetActive(value);
        }
    }

    public void SetProcess(int num1, int num2)
    {
        // ProcessSprite.size = new Vector2(96 * (num1 / (float)num2), 12);
        if(num2 == 0)
        {
            ProcessSprite.size = new Vector2(0, 10);
            ProcessText.text = $"{num1}/{num2}";
            return;
        }
        float target = 86 * (num1 / (float)num2);
        DOTween.To(() => ProcessSprite.size.x,
            x => ProcessSprite.size = new Vector2(x, 10),
            target, 0.5f);
        ProcessText.text = $"{num1}/{num2}";
    }

    internal float DoTriggerAnchor(Vector3 formPos, bool lastOne = false)
    {
        IEnumerator PlayAnim(Vector3 formPos)
        {
            // SetSortingOrder(FxSortOrder + 1);
            GameObject anchorPrefab = null;
            GameObject stonePrefab = null;
            _ = GlobalRes.DynamicLoadPrefab(Constants.anchorPrefabStr, (obj) =>
            {
                anchorPrefab = obj;
                anchorPrefab.transform.position = formPos;
            });
            _ = GlobalRes.DynamicLoadPrefab(Constants.stoneBrokenStr, (obj) =>
            {
                stonePrefab = obj;
                stonePrefab.transform.position = transform.position;
            });
            while (anchorPrefab == null || stonePrefab == null)
            {
                yield return null;
            }

            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            Vector3 selfPos = transform.position;
            anchorPrefab.transform.position = formPos;
            anchorPrefab.transform.localScale = Vector3.one * 0.5f;
            stonePrefab.transform.position = selfPos;
            stonePrefab.gameObject.SetActive(false);
            seq.Append(anchorPrefab.transform.DOScale(Vector3.one * 0.9f, 0.1f));
            seq.Append(anchorPrefab.transform.DOScale(Vector3.one * 0.7f, 0.1f));
            // seq.AppendInterval(0.5f);
            seq.AppendCallback(() => SoundPlayer.Instance.PlayKey());

            Vector3 endPos = selfPos + new Vector3(210, 0, 0);
            // Vector3 controlPos = formPos + new Vector3(100, endPos.y > formPos.y ? 100 : -100, 0);
            // Vector3[] pathPosArray = BezierUtils.GetBeizerList(formPos, controlPos, endPos, 10);
            // seq.Append(anchorPrefab.transform.DOPath(pathPosArray, 0.25f, PathType.CatmullRom, gizmoColor: Color.red));
            seq.Append(anchorPrefab.transform.DOMove(endPos, 0.25f));
            seq.Join(anchorPrefab.transform.DOScale(Vector3.one, 0.25f));

            seq.AppendCallback(() =>
            {
                if (lastOne)
                {
                    ImageAlpha = 0;
                }
                stonePrefab.gameObject.SetActive(true);
                anchorPrefab.GetComponent<Animator>().Play("tieqiao_dh_02");
                SoundPlayer.Instance.PlayAnchor();
            });
            // seq.AppendInterval(1f);
            // seq.Append(DoAlphaAnim(0, 0.5f/5));
            if (lastOne)
            {
                seq.Append(DoAlphaAnim(0, 0.5f / 5));
            }
            seq.AppendCallback(() =>
            {
                if (lastOne)
                {
                    ImageAlpha = 1;
                }
                Destroy(stonePrefab.gameObject, 1f);
                Destroy(anchorPrefab.gameObject, 1f);
                // GlobalRes.Release<GameObject>(Constants.anchorPrefabStr);
                // GlobalRes.Release<GameObject>(Constants.stoneBrokenStr);
                if (lastOne)
                {
                    gameObject.SetActive(false);
                }
            });
        }
        StartCoroutine(PlayAnim(formPos));
        return 1f; //seq.Duration();
    }

}
