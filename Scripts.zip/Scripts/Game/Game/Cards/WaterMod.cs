using UnityEngine;

public class WaterMod : BaseMod
{
    private void OnEnable() 
    {
        gameObject.transform.localScale = Vector3.one;
        gameObject.transform.localEulerAngles = Vector3.zero;
        gameObject.transform.localPosition = new Vector3(0, 0, -0.1f);
    }
}
