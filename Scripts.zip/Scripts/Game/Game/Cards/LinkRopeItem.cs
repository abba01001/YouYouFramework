using DG.Tweening;
using UnityEngine;
using SoliUtils;
public class LinkRopeItem : MonoBehaviour
{
    private Transform pointA;
    private Transform pointB;
    private Vector3 controlPoint;
    public Texture ropeTexture;
    public SpriteRenderer End1;
    public SpriteRenderer End2;
    private LineRenderer lineRenderer;
    private Vector3 endPos1 = new Vector3(999,999,999);
    private Vector3 endPos2 = new Vector3(999,999,999);
    private bool lastStateIsRed = true;

    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.positionCount = 10;
        lineRenderer.useWorldSpace = true;
        lineRenderer.startWidth = 11;
        lineRenderer.endWidth = 11;
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer.material.mainTexture = ropeTexture;
        lineRenderer.textureMode = LineTextureMode.RepeatPerSegment;
    }

    public void ConnectEnds(Transform obj1, Transform obj2)
    {
        pointA = obj1;
        pointB = obj2;
        var pos1 = End1.transform.position;
        pos1.z = obj1.position.z - 0.9f;
        End1.transform.position = pos1;
        var pos2 = End2.transform.position;
        pos2.z = obj2.position.z - 0.9f;
        End2.transform.position = pos2;
        // Update();
        endPos1 = pos1;
        endPos2 = pos2;
        End1.DOFade(0, 0f).OnComplete(()=>{End1.DOFade(1, 0.5f);});
        End2.DOFade(0, 0f).OnComplete(()=>{End2.DOFade(1, 0.5f);});
    }

    public void ChangeEndState(GameObject obj, bool green)
    {
        SpriteRenderer sprite = null;
        if (obj == pointA.transform.parent.parent.gameObject)
        {
            sprite = End1;
        }
        else if (obj == pointB.transform.parent.parent.gameObject)
        {
            sprite = End2;
        }

        if (sprite != null)
        {
            string spriteTex = green ? "Assets/Res/Cards/Textures/sz_2.png" : "Assets/Res/Cards/Textures/sz_1.png";
            _ = SpriteUtils.GetSpriteAsyncByPath(spriteTex, (temp) =>
            {
                sprite.sprite = temp;
            });
            if (green && lastStateIsRed) SoundPlayer.Instance.PlayMainSound("LinkRope_RedtoGreen");
            lastStateIsRed = !green;
        }
    }

    void Update()
    {
        if(Vector3.Distance(End1.transform.position, endPos1) > 5 || Vector3.Distance(End2.transform.position, endPos2) > 5)
        {
            AdjustControlPoint();
            DrawBezierCurve();
            endPos1 = End1.transform.position;
            endPos2 = End2.transform.position;
        }
        MovingEnds();
    }

    void MovingEnds()
    {
        End1.transform.position = pointA.position - new Vector3(0, 0, 0.9f);
        End2.transform.position = pointB.position - new Vector3(0, 0, 0.9f);
    }


    void DrawBezierCurve()
    {
        float distance = Vector3.Distance(End1.transform.position + new Vector3(0, 0, 0.4f), End2.transform.position + new Vector3(0, 0, 0.4f));
        int segments = (int)distance / 16;
        lineRenderer.positionCount = segments + 1;
        for (int i = 0; i <= segments; i++)
        {
            float t = i / (float)segments;
            Vector3 position = CalculateQuadraticBezierPoint(t, End1.transform.position + new Vector3(0, 0, 0.4f), controlPoint, End2.transform.position + new Vector3(0, 0, 0.4f));
            lineRenderer.SetPosition(i, position);
        }
    }

    void AdjustControlPoint()
    {
        Vector3 middlePoint = (End1.transform.position + End2.transform.position) / 2;
        float distance = Vector3.Distance(End1.transform.position, End2.transform.position);
        if (distance < 200)
            controlPoint = middlePoint + Vector3.down * distance / 4;
        else
            controlPoint = middlePoint + Vector3.down * distance / 11;
    }

    Vector3 CalculateQuadraticBezierPoint(float t, Vector3 p0, Vector3 p1, Vector3 p2)
    {
        float u = 1 - t;
        float tt = t * t;
        float uu = u * u;

        Vector3 p = uu * p0; // (1-t)^2 * P0
        p += 2 * u * t * p1; // 2(1-t)t * P1
        p += tt * p2; // t^2 * P2

        return p;
    }
}
