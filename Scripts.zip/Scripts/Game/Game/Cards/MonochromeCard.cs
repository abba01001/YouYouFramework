using DG.Tweening;
using UnityEngine;
using SoliUtils;

namespace Game.Cards
{
    public class MonochromeCard : BaseCard
    {

        public override void PlayDisappearEf()
        {
            CardData cardData = BattleDataMgr.Instance.GetLastHandCard();
            string assetPath = "";
            if (cardData != null)
            {
                if (cardData.CardType == CardType.Value)
                {
                    int cardType = cardData.Value / Constants.ValueCardCount13; //0梅花♣  1爱心❤  2黑桃♠  3方块♦
                    assetPath = $"Assets/Res/Prefabs/FX/tx_MonochromeCard_0{cardType + 1}.prefab";
                }
                else if (cardData.CardType == CardType.Gold)
                {
                    assetPath = $"Assets/Res/Prefabs/FX/tx_MonochromeCard_0{cardData.cm.suit + 1}.prefab";
                }
                else if (cardData.CardType == CardType.Monochrome)
                {
                    assetPath = cardData.cm.suit == 1 ? $"Assets/Res/Prefabs/FX/tx_MonochromeCard_02.prefab" : $"Assets/Res/Prefabs/FX/tx_MonochromeCard_01.prefab";
                }
                else if (cardData.CardType == CardType.Joker)
                {
                    assetPath = $"Assets/Res/Prefabs/FX/tx_MonochromeCard_05.prefab";
                }

                if (assetPath != "")
                {
                    GlobalRes.DynamicLoadPrefab(assetPath, (obj) =>
                    {
                        var scene = Camera.main.transform.parent;
                        obj.transform.SetParent(scene);
                        obj.transform.position = gameObject.transform.position;
                        obj.SetActive(true);
                    }, true, 3f);
                }
            }
        }

        public override float FlopCard(bool faceup = true)
        {
            SetMonochrome();
            return base.FlopCard(faceup);
        }

        public override void SetData(CardData cardData, int cardBackId, int betValue)
        {
            base.SetData(cardData, cardBackId);
            SetMonochrome();
        }

        public void SetMonochrome()
        {
            if (CardData.cm.random || CardData.cm.suit == -1)
            {
                var rendererTemp = cardObj.GetComponent<SpriteRenderer>();
                // MaterialPropertyBlock blockTemp = new MaterialPropertyBlock();
                // rendererTemp.GetPropertyBlock(blockTemp);
                // blockTemp.SetTexture("_SpecTex", GlobalRes.Load<Texture2D>($"Assets/Res/Cards/Textures/moch0.png"));
                // rendererTemp.SetPropertyBlock(blockTemp);
                _ = SpriteUtils.GetTextureAsyncByPath($"Assets/Res/Cards/Textures/moch0.png", (temp) =>
                {
                    var matTemp = new Material(rendererTemp.material);
                    matTemp.SetTexture("_SpecTex", temp);
                    rendererTemp.material = matTemp;
                });
                return;
            }
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            // MaterialPropertyBlock block = new MaterialPropertyBlock();
            // renderer.GetPropertyBlock(block);
            // block.SetTexture("_SpecTex", GlobalRes.Load<Texture2D>($"Assets/Res/Cards/Textures/moch{(CardData.cm.suit==0||CardData.cm.suit==2 ? 2 : 1)}.png"));
            // renderer.SetPropertyBlock(block);
            _ = SpriteUtils.GetTextureAsyncByPath($"Assets/Res/Cards/Textures/moch{(CardData.cm.suit == 0 || CardData.cm.suit == 2 ? 2 : 1)}.png", (temp) =>
            {
                var mat = new Material(renderer.material);
                mat.SetTexture("_SpecTex", temp);
                renderer.material = mat;
            });
        }

    }
}
