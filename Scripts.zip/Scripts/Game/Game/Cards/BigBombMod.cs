using DG.Tweening;
using TMPro;
using UnityEngine;
using SoliUtils;

public class BigBombMod : BaseMod
{
    public TextMeshPro TimerText;
    public GameObject glowObj;
    public GameObject fireObj;

    private int _timer;
    public int Timer
    {
        set
        {
            _timer = value;
            DoFlipAnim();
        }
        get
        {
            return _timer;
        }
    }

    private void DoFlipAnim()
    {
        TimerText.GetComponent<Animator>().SetTrigger("change");
        Sequence seq = DOTween.Sequence();
        SoundPlayer.Instance.PlayMainSound("bomb_text_dh");
        seq.AppendInterval(0.4f);
        seq.AppendCallback(() =>
        {
            TimerText.text = _timer.ToString();
        });
        seq.SetTarget(transform);
    }

    public override void PlayDisappearEf()
    {
        GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_BigBombMod_01.prefab", (obj) =>
        {
            var scene = Camera.main.transform.parent;
            obj.transform.SetParent(scene);
            obj.transform.position = gameObject.transform.position;
            obj.SetActive(true);
        },true,3f);
    }
    
    private void OnEnable()
    {
        gameObject.transform.localScale = Vector3.one;
        gameObject.transform.localEulerAngles = Vector3.zero;
        gameObject.transform.localPosition = Vector3.one;
        TimerText.gameObject.SetActive(false);
        glowObj.gameObject.SetActive(false);
        fireObj.gameObject.SetActive(false);
    }

    public override void Active(bool act = true)
    {
        if (act)
        {
            
            TimerText.gameObject.SetActive(true);
            glowObj.gameObject.SetActive(true);
            fireObj.gameObject.SetActive(true);
            SetAlpha(255);
        }
        else
        {
            TimerText.gameObject.SetActive(false);
            glowObj.gameObject.SetActive(false);
            fireObj.gameObject.SetActive(false);
            SetAlpha(0);
        }
    }

    public override void SetAlpha(int alpha)
    {
        base.SetAlpha(alpha);
        TimerText.alpha = alpha / 255f;
    }
}
