using UnityEngine;
using SoliUtils;
using Cysharp.Threading.Tasks;

public class TwoValueCard : BaseCard
{

    public override bool IsFaceUp
    {
        get => _isFaceUp;
        set
        {
            // if (_isFaceUp == value) return;
            _isFaceUp = value;
            cardObj.transform.localScale = value ? Vector3.one : faceDownVec;
            cardObj.transform.localScale *= Constants.CardSizeScale * Constants.TwoValueCardSizeScale;
        }
    }

    public override void SetData(CardData cardData, int cardBackId, int betValue)
    {
        base.SetData(cardData, cardBackId, betValue);
        SetValue();
    }

    public async void SetValue()
    {
        var value1 = CardData.Value;
        var value2 = CardData.Value2;

        if (GameCommon.IsEditorMode)
        {
            if (value1 == -1)
            {
                var rendererTemp = cardObj.GetComponent<SpriteRenderer>();
                // MaterialPropertyBlock blockTemp = new MaterialPropertyBlock();
                // rendererTemp.GetPropertyBlock(blockTemp);
                // blockTemp.SetTexture("_FirstValueTex", new Texture2D(0, 0));
                // blockTemp.SetTexture("_FirstSuitTex", new Texture2D(0, 0));
                // rendererTemp.SetPropertyBlock(blockTemp);
                var mat = new Material(rendererTemp.material);
                mat.SetTexture("_FirstValueTex", new Texture2D(0, 0));
                mat.SetTexture("_FirstSuitTex", new Texture2D(0, 0));
                rendererTemp.material = mat;
            }

            if (value2 == -1)
            {
                var rendererTemp = cardObj.GetComponent<SpriteRenderer>();
                // MaterialPropertyBlock blockTemp = new MaterialPropertyBlock();
                // rendererTemp.GetPropertyBlock(blockTemp);
                // blockTemp.SetTexture("_SecondValueTex", new Texture2D(0, 0));
                // blockTemp.SetTexture("_SecondSuitTex", new Texture2D(0, 0));
                // rendererTemp.SetPropertyBlock(blockTemp);
                var mat = new Material(rendererTemp.material);
                mat.SetTexture("_SecondValueTex", new Texture2D(0, 0));
                mat.SetTexture("_SecondSuitTex", new Texture2D(0, 0));
                rendererTemp.material = mat;
            }
        }

        if (value1 == -1 || value2 == -1)
        {
            return;
        }

        var renderer = cardObj.GetComponent<SpriteRenderer>();

        Texture2D valueTex1 = null;
        Texture2D flowerTex1 = null;
        Texture2D valueTex2 = null;
        Texture2D flowerTex2 = null;

        var typeIndex1 = value1 / Constants.ValueCardCount13;
        var valueIndex1 = value1 % Constants.ValueCardCount13;
        var color1 = (typeIndex1 == 1 || typeIndex1 == 3) ? "red" : "black";

        var typeIndex2 = value2 / Constants.ValueCardCount13;
        var valueIndex2 = value2 % Constants.ValueCardCount13;
        var color2 = (typeIndex2 == 1 || typeIndex2 == 3) ? "red" : "black";

        _ = SpriteUtils.GetTextureAsyncByPath($"Assets/Res/Cards/Textures/duodian_{color1}_{valueIndex1 + 1}.png", (temp) =>
        {
            valueTex1 = temp;
        });
        _ = SpriteUtils.GetTextureAsyncByPath(Constants.FlowerRes2Map[typeIndex1], (temp) =>
        {
            flowerTex1 = temp;
        });
        _ = SpriteUtils.GetTextureAsyncByPath($"Assets/Res/Cards/Textures/duodian_{color2}_{valueIndex2 + 1}.png", (temp) =>
        {
            valueTex2 = temp;
        });
        _ = SpriteUtils.GetTextureAsyncByPath(Constants.FlowerRes2Map[typeIndex2], (temp) =>
        {
            flowerTex2 = temp;
        });


        while (valueTex1 == null || flowerTex1 == null || valueTex2 == null || flowerTex2 == null)
        {
            await UniTask.Yield();
        }

        var new_mat = new Material(renderer.material);
        new_mat.SetTexture("_FirstValueTex", valueTex1);
        new_mat.SetTexture("_FirstSuitTex", flowerTex1);
        new_mat.SetTexture("_SecondValueTex", valueTex2);
        new_mat.SetTexture("_SecondSuitTex", flowerTex2);
        renderer.material = new_mat;



        // renderer.SetPropertyBlock(block);
        //renderer.material = new_mat;
    }

    // public override void SetFront(int bet=1)
    // {
    //     if (Constants.CardFrontRes.TryGetValue(bet, out var file))
    //     {
    //         MaterialPropertyBlock block = new MaterialPropertyBlock();
    //         var renderer = cardObj.GetComponent<SpriteRenderer>();
    //         renderer.GetPropertyBlock(block);
    //         var res = GlobalRes.Load<Texture2D>(file);
    //         block.SetTexture("_MainTex", res);
    //         renderer.SetPropertyBlock(block);
    //     }
    // }
}