using DG.Tweening;
using UnityEngine;
using SoliUtils;

namespace Game.Cards
{
    public class ClothMod : BaseMod
    {
        public Animator Anim;
        private void OnEnable() 
        {
            gameObject.transform.localScale = Vector3.one;
            gameObject.transform.localEulerAngles = Vector3.zero;
            gameObject.transform.localPosition = new Vector3(0, 0, -0.1f);
        }

        public override void PlayDisappearEf()
        {
            GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_ClothMod_01.prefab", (obj) =>
            {
                var scene = Camera.main.transform.parent;
                obj.transform.SetParent(scene);
                obj.transform.position = gameObject.transform.position;
                obj.SetActive(true);
            },true,3f);
        }
        
        public void SetState(bool isOpen)
        {
            Anim.enabled = true;
            if(isOpen)
            {
                Anim.SetTrigger("OpenCloth");
                SoundPlayer.Instance.PlayMainSound("blind_ClothOpen");
            }
            else
            {
                var state = Anim.GetCurrentAnimatorStateInfo(0);
                if (!state.IsName("ani_ClothMod_Close"))
                {
                    SoundPlayer.Instance.PlayMainSound("blind_ClothClose");
                    Anim.SetTrigger("CloseCloth");
                }
            }
        }
    }
}