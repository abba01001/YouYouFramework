using UnityEngine;

namespace Game.Cards
{
    public class GreenLeafMod : BaseMod
    {
        public GameObject Bird;

        private void OnEnable() 
        {
            gameObject.transform.localScale = Vector3.one;
            gameObject.transform.localEulerAngles = Vector3.zero;
            gameObject.transform.localPosition = new Vector3(0, 0, -0.1f);
            Bird.SetActive(false);
        }
        
        public void SetBirdActive(bool active)
        {
            Bird.SetActive(active);
        }
    }
}