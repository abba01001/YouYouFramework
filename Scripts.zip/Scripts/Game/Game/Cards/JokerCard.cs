using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using SoliUtils;

public class JokerCard : BaseCard
{
    private GameObject liuGuangEf = null;
    public override void PlayDisappearEf()
    {
        GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_Joker_01.prefab", (obj) =>
        {
            var scene = Camera.main.transform.parent;
            obj.transform.SetParent(scene);
            obj.transform.position = gameObject.transform.position;
            obj.SetActive(true);
        },true,3f);
        if (liuGuangEf != null)
        {
            Destroy(liuGuangEf);
            liuGuangEf = null;
        }
    }
    
    public override void OnDisable()
    {
        if (liuGuangEf != null)
        {
            Destroy(liuGuangEf);
            liuGuangEf = null;
        }
    }

    public override void PlayShowEf()
    {
        if (liuGuangEf == null)
        {
            GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_JokerCard_UI_liuguang_01.prefab", (obj) =>
            {
                var scene = Camera.main.transform.parent;
                obj.transform.SetParent(transform.Find("card"));
                obj.transform.localPosition = Vector3.zero;
                obj.transform.localScale = Vector3.one;
                obj.transform.localRotation = Quaternion.identity;//Quaternion.Euler(new Vector3(0,0,CardData.cm.angle));
                obj.SetActive(true);
                liuGuangEf = obj;
            });
        }
        else
        {
            liuGuangEf.SetActive(true);
        }
    }

    public float DoJokerToHandCards(Vector3 formPos, Vector3 toPos)
    {
        float t1 = 0.35f;
        float t2 = 0.15f;
        float t3 = 1.0f;
        float t4 = 0.8f;
        SetSortingOrder(FxSortOrder);
        SetSortingLayer("UI");
        _ = GlobalRes.DynamicLoadPrefab(Constants.buyJokerCardFxStr1, (showFx1) =>
        {
            showFx1.transform.SetParent(transform);
            showFx1.transform.localPosition = Vector3.zero;
        }, true, t1 + t2 + t3);
        _ = GlobalRes.DynamicLoadPrefab(Constants.buyJokerCardFxStr2, (showFx2) =>
        {
            showFx2.transform.SetParent(transform);
            showFx2.transform.localPosition = Vector3.zero;
        }, true, t1 + t2 + t3);
        // GameObject showFx1 = Instantiate(GlobalRes.Load<GameObject>(Constants.buyJokerCardFxStr1));
        // GameObject showFx2 = Instantiate(GlobalRes.Load<GameObject>(Constants.buyJokerCardFxStr2));
        // showFx1.transform.SetParent(transform);
        // showFx2.transform.SetParent(transform);
        formPos += new Vector3(0,220,0);
        formPos.z = toPos.z;
        transform.position = formPos;
        formPos = formPos + new Vector3(0, 150, 0);
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        seq.Append(transform.DOMoveY(formPos.y, t1).SetEase(Ease.OutQuad));
        seq.Join(transform.DOScale(1.1f, t1).SetEase(Ease.OutQuad));
        seq.AppendInterval(t2);
        seq.Append(cardObj.transform.DOLocalRotate(new Vector3(0, 0, 360), t3, RotateMode.FastBeyond360).SetEase(Ease.OutSine));

        Vector3 controlPos = formPos + new Vector3(-300, 350);
        Vector3[] pathPosArray = BezierUtils.GetBeizerList(formPos, controlPos, toPos, 10);
        seq.Join(transform.DOPath(pathPosArray, t3, PathType.CatmullRom, gizmoColor: Color.red).SetEase(Ease.InOutQuad));

        // seq.Join(transform.DOMove(toPos, t3).SetEase(Ease.InOutQuad));
        seq.Join(transform.DOScale(1.0f, t3).SetEase(Ease.OutSine));
        seq.AppendCallback(() =>
        {
            SetSortingOrder(DefaultSortOrder);
            transform.position = toPos;
            // Destroy(showFx1);
            // GlobalRes.Release<GameObject>(Constants.buyJokerCardFxStr1);
        });
        seq.AppendInterval(t4);
        seq.OnComplete(() =>
        {
            // Destroy(showFx2);
            // GlobalRes.Release<GameObject>(Constants.buyJokerCardFxStr2);
            SetSortingLayer("Default");
        });

        return t1 + t2 + t3;
    }

    public float UndoJokerToHandCards(Vector3 formPos, Vector3 toPos)
    {
        float t3 = 1.0f;
        SetSortingOrder(FxSortOrder);

        formPos.z = toPos.z;
        transform.position = formPos;
        formPos = formPos + new Vector3(0, 150, 0);
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        seq.Append(cardObj.transform.DOLocalRotate(new Vector3(0, 0, 360), t3, RotateMode.FastBeyond360).SetEase(Ease.OutSine));

        Vector3 controlPos = formPos + new Vector3(0, 350);
        Vector3[] pathPosArray = BezierUtils.GetBeizerList(formPos, controlPos, toPos, 10);
        seq.Join(transform.DOPath(pathPosArray, t3, PathType.CatmullRom, gizmoColor: Color.red).SetEase(Ease.InOutQuad));
        seq.JoinCallback(() => { DoAlphaAnim(0, t3, Ease.InCirc); });
        seq.Join(transform.DOScale(1.0f, t3).SetEase(Ease.OutSine));
        seq.AppendCallback(() =>
        {
            SetSortingOrder(DefaultSortOrder);
            transform.position = toPos;
        });
        seq.OnComplete(() =>
        {
            gameObject.SetActive(false);
        });

        return t3;
    }

    public override void SetBack(int cardBackId, int betValue)
    {

    }

    internal float DoPowerItemEnter(Vector3 startPos, float offsetTime)
    {
        transform.DOKill(true);
        cardObj.gameObject.SetActive(false);
        SetVisible(false);
        SetSortingOrder(FxSortOrder);
        transform.position = startPos;
        CardAngle = 0;
        DoAlphaAnim(0, 0);
        Vector3 endPos = new Vector3(CardData.cm.x, CardData.cm.y, CardData.cm.depth);
        // Debug.LogError($"======= startPos : {startPos.x} {startPos.y}");
        // Debug.LogError($"======= endPos : {endPos.x} {endPos.y}");
        Vector3 controlPos = (startPos + endPos) / 2 + new Vector3(0, 600);
        Vector3[] pathPos = BezierUtils.GetBeizerList(startPos, controlPos, endPos, 10);
        Sequence seq1 = DOTween.Sequence();
        seq1.AppendInterval(offsetTime);
        seq1.AppendCallback(() =>
        {
            cardObj.gameObject.SetActive(true);
            DoAlphaAnim(1, 0.35f);
            PlayAnimation("PowerItemMoveA", () =>
            {
                PlayAnimation("PowerItemMoveB");
                Sequence seq = DOTween.Sequence();
                seq.Append(transform.DOPath(pathPos, 1.1f));
                seq.InsertCallback(0.6f, () =>
                {
                    SetSortingOrder(DefaultSortOrder);
                    CardAngle = CardData.cm.angle;
                });
            });
        });
        seq1.AppendInterval(0.83f);
        seq1.AppendCallback(() =>
        {
            _ = GlobalRes.DynamicLoadPrefab(Constants.powerItemShowFxStr, (showFx) =>
            {
                showFx.transform.position = startPos;
                // GlobalRes.Release<GameObject>(Constants.powerItemShowFxStr, 2);
            }, true, 2f);
        });
        return 1.64f + 1.25f + offsetTime;
    }
}
