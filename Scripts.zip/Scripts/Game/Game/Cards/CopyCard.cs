using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using QFramework;
using SoliUtils;

public class CopyCard : BaseCard
{
    public override void SetData(CardData cardData, int cardBackId, int betValue)
    {
        base.SetData(cardData, cardBackId);
        _ = SpriteUtils.GetTextureAsyncByPath(Constants.CardBackTex_Normal, (res) =>
        {
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            var mat = new Material(renderer.material);
            mat.SetTexture("_MainTex", res);
            renderer.material = mat;
        });
    }

}
