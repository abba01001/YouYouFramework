using System.Collections;
using System.Collections.Generic;
using SoliUtils;
using UnityEngine;

public class TaskMod : BaseMod
{
    [SerializeField] public SpriteRenderer Icon;

    private void ShowRookieTaskIcon(int level)
    {
        string[] names = { "xsgk_4", "xsgk_6", "xsgk_5" };
        string key = Constants.AtlasNamePath.ViewRookieAtlas;
        int targetWidth = 80;
        int targetHeight = 80;
        _ = Icon.SetSpriteByAtlas(key, names[level - 1], true, () =>
        {
            float originalWidth = Icon.sprite.textureRect.size.x;
            float originalHeight = Icon.sprite.textureRect.size.y;
            float scaleX = targetWidth / originalWidth;
            float scaleY = targetHeight / originalHeight;
            float scaleFactor = Mathf.Min(scaleX, scaleY) * 100;
            Icon.transform.localScale = new Vector3(scaleFactor, scaleFactor, 1f);
        });
    }

    public void ReFreshTaskIcon()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var rookieStatus = dataService.GetRookieStatus();
        if (rookieStatus < 3)
        {
            ShowRookieTaskIcon(rookieStatus + 1);
        }
    }
}
