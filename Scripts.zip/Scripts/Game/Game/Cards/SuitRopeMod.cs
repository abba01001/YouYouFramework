using System;
using System.Collections.Generic;
using System.Diagnostics;
using UniRx;
using UnityEngine;
using SoliUtils;

namespace Game.Cards
{
    public class SuitRopeMod : BaseMod
    {
        [SerializeField] public GameObject Rope1;
        [SerializeField] public GameObject Rope2;
        [SerializeField] public GameObject[] Flowers;

        private Dictionary<int, int> _initSuitList = new Dictionary<int, int>();
        private Dictionary<int, bool> _suitStateList = new Dictionary<int, bool>();

        private void OnEnable()
        {
            gameObject.transform.localScale = Vector3.one;
            gameObject.transform.localEulerAngles = Vector3.zero;
            gameObject.transform.localPosition = new Vector3(0, 0, -0.1f);
        }

        public void InitSuit(List<int> suits)
        {
            _initSuitList.Clear();
            _suitStateList.Clear();
            for (int i = 0; i < suits.Count; i++)
            {
                _initSuitList.Add(i, suits[i]);
                _suitStateList.Add(i, false);
            }
            Rope1.SetActive(_initSuitList.Count > 0);
            Rope2.SetActive(_initSuitList.Count > 2);

            for (int i = 0; i < 4; i++)
            {
                int idx = i;
                if (_initSuitList.ContainsKey(idx))
                {
                    Flowers[idx].SetActive(true);
                    _ = SpriteUtils.GetSpriteAsyncByPath($"Assets/Res/Cards/Textures/qizi_suit_{_initSuitList[idx]}.png", (res) =>
                    {
                        var renderer = Flowers[idx].GetComponent<SpriteRenderer>();
                        renderer.sprite = res;
                    });
                }
                else
                {
                    Flowers[idx].SetActive(false);
                }
            }
        }

        public void ResetSuits(Dictionary<int, bool> ropeStates)
        {
            for (int i = 0; i < 4; i++)
            {
                int idx = i;
                if (_initSuitList.ContainsKey(idx) && !ropeStates[idx])
                {
                    Flowers[idx].SetActive(true);
                    _ = SpriteUtils.GetSpriteAsyncByPath($"Assets/Res/Cards/Textures/qizi_suit_{_initSuitList[idx]}.png", (res) =>
                    {
                        var renderer = Flowers[idx].GetComponent<SpriteRenderer>();
                        renderer.sprite = res;
                    });
                }
                else
                {
                    Flowers[idx].SetActive(false);
                }
            }
            Rope1.SetActive(_initSuitList.Count > 0 && (!ropeStates[0] || (ropeStates.ContainsKey(1) ? !ropeStates[1] : false)));
            Rope2.SetActive(_initSuitList.Count > 2 && (!ropeStates[2] || (ropeStates.ContainsKey(3) ? !ropeStates[3] : false)));
        }

        public void CheckRopeState()
        {
            if (_initSuitList.Count == 0)
            {
                HideRope();
            }
        }

        /// <summary>
        /// 刷新花色显示
        /// </summary>
        private void RefreshSuits()
        {
            // Rope1.SetActive(_suitList.Contains(_initSuitList[0]) && (_initSuitList.Count > 1 ? _suitList.Contains(_initSuitList[1]) : true));
            // Rope2.SetActive(_suitList.Contains(_initSuitList[2]) && (_initSuitList.Count > 3 ? _suitList.Contains(_initSuitList[3]) : true));
            // for(int i=3; i>=0; i--)
            // {

            // }

            // for (int i = 0; i < 4; i++)
            // {
            //     int idx = i;
            //     int suitIdx = _initSuitList.IndexOf()
            //     Flowers[idx].SetActive(i < _suitList.Count);
            //     if (idx < _suitList.Count)
            //     {
            //         _ = SpriteUtils.GetSpriteAsyncByPath($"Assets/Res/Cards/Textures/qizi_suit_{_suitList[idx]}.png", (res) =>
            //         {
            //             var renderer = Flowers[idx].GetComponent<SpriteRenderer>();
            //             renderer.sprite = res;
            //             // var mat = new Material(renderer.material);
            //             // mat.SetTexture("_MainTex", res);
            //             // renderer.material = mat;
            //         });
            //     }
            // }
        }

        /// <summary>
        /// 说明花色被消除完毕，直接把整个GameObject隐藏
        /// </summary>
        public void HideRope()
        {
            Observable.Timer(TimeSpan.FromSeconds(2f)).Subscribe(_ =>
            {
                GameObjManager.Instance.PushGameObject(gameObject);
            });
        }

        public void PlaySuitEff(int idx)
        {
            Flowers[idx].SetActive(false);
            if (idx == 0 || idx == 1)
            {
                if (!Flowers[0].activeSelf && !Flowers[1].activeSelf)
                {
                    Rope1.SetActive(false);
                    _ = GlobalRes.DynamicLoadPrefab(Constants.suitropeRope1, (obj) =>
                    {
                        obj.SetActive(true);
                        obj.transform.SetParent(Rope1.transform.parent);
                        obj.transform.position = Rope1.transform.position;
                        _ = Observable.Timer(TimeSpan.FromSeconds(2)).Subscribe(_ =>
                        {
                            Destroy(obj);
                        }).AddTo(Rope1);
                    });
                }
            }
            else
            {
                if (!Flowers[2].activeSelf && !Flowers[3].activeSelf)
                {
                    Rope2.SetActive(false);
                    _ = GlobalRes.DynamicLoadPrefab(Constants.suitropeRope2, (obj) =>
                    {
                        obj.SetActive(true);
                        obj.transform.SetParent(Rope2.transform.parent);
                        obj.transform.position = Rope2.transform.position;
                        _ = Observable.Timer(TimeSpan.FromSeconds(2)).Subscribe(_ =>
                        {
                            Destroy(obj);
                        }).AddTo(Rope2);
                    });
                }
            }

            int suit = _initSuitList[idx];
            string[] strMap = new string[] { Constants.suitropeSuit0, Constants.suitropeSuit1, Constants.suitropeSuit2, Constants.suitropeSuit3 };
            _ = GlobalRes.DynamicLoadPrefab(strMap[suit], (obj) =>
                {
                    obj.SetActive(true);
                    obj.transform.position = Flowers[idx].transform.position;
                    obj.transform.SetParent(Flowers[idx].transform.parent);
                    _ = Observable.Timer(TimeSpan.FromSeconds(2)).Subscribe(_ =>
                    {
                        Destroy(obj);
                    }).AddTo(transform);
                });

            _ = GlobalRes.DynamicLoadPrefab(Constants.suitropeBao, (obj) =>
                {
                    obj.SetActive(true);
                    obj.transform.position = Flowers[idx].transform.position;
                    obj.transform.SetParent(Flowers[idx].transform.parent);
                    _ = Observable.Timer(TimeSpan.FromSeconds(2)).Subscribe(_ =>
                    {
                        Destroy(obj);
                    }).AddTo(transform);
                });
            SoundPlayer.Instance.PlayMainSound("rope_suit");
        }
    }
}