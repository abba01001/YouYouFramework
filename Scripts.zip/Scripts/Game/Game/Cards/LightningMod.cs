using System;
using DG.Tweening;
using Doozy.Engine.UI;
using TMPro;
using UniRx;
using UnityEngine;
using SoliUtils;

namespace Game.Cards
{
    public class LightningMod : BaseMod
    {
        private int lastTimer = 1;
        [SerializeField] private TextMeshPro TimerText;
        [SerializeField] private GameObject Cloud;
        [SerializeField] private GameObject TimerAnim;
        private void OnEnable()
        {
            gameObject.transform.localScale = Vector3.one;
            gameObject.transform.localEulerAngles = Vector3.zero;
            gameObject.transform.localPosition = new Vector3(0, 0, -0.1f);
            TimerText.gameObject.SetActive(false);
            Cloud.SetActive(false);
        }

        public override void PlayDisappearEf()
        {
            GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_LightningMod_01.prefab", (obj) =>
            {
                var scene = Camera.main.transform.parent;
                obj.transform.SetParent(scene);
                obj.transform.position = gameObject.transform.position;
                obj.SetActive(true);
            },true,3f);
        }

        public override void Active(bool act = true)
        {
            if (act)
            {
                TimerText.gameObject.SetActive(true);
                Cloud.SetActive(true);
                SetAlpha(255);
            }
            else
            {
                TimerText.gameObject.SetActive(false);
                Cloud.SetActive(false);
                SetAlpha(0);
            }
        }

        public void SetTimer(int timer)
        {
            TimerText.text = timer.ToString();
            TimerAnim.gameObject.SetActive(false);
            Observable.NextFrame().Subscribe(_ =>
            {
                TimerAnim.gameObject.SetActive(true);
            });
            if (lastTimer != timer)
            {
                SoundPlayer.Instance.PlayMainSound("Lightning_countdown");
            }
            lastTimer = timer;
        }
    }
}