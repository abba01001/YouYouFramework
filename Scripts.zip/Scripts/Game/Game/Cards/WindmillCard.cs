using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using SoliUtils;

public class WindmillCard : BaseCard
{
    internal float DoTriggerFlyAnim()
    {
        float time1 = 1f;
        float time2 = 0.2f;
        float time3 = 1.5f;
        IEnumerator PlayAnim()
        {
            SetSortingOrder(FxSortOrder);
            GameObject baoFx = null; //Instantiate(GlobalRes.Load<GameObject>(Constants.baoFx2Str));
            _ = GlobalRes.DynamicLoadPrefab(Constants.windmiallFx, (obj) =>
            {
                baoFx = obj;
                baoFx.transform.SetParent(transform);
                baoFx.transform.localPosition = new Vector3(100, 0, 0);
                baoFx.gameObject.SetActive(false);
            });
            while (baoFx == null)
            {
                yield return null;
            }
            cardObj.transform.localRotation = Quaternion.identity;
            SoundPlayer.Instance.PlayMainSound("WindmillCard_tuowei_lz_01");
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            seq.AppendCallback(() =>
                {
                    baoFx.gameObject.SetActive(true);
                });
            seq.Join(transform.DOScale(Vector3.one * 2f, time1).SetEase(Ease.Linear));
            seq.Join(transform.DOMove(new Vector3(0, 0, Depth), time1).SetEase(Ease.Linear));
            // seq.Join(cardObj.transform.DORotate(Vector3.zero, time1).SetEase(Ease.Linear));
            seq.Join(transform.DORotate(new Vector3(0, 360 * 2, 0), time1, RotateMode.FastBeyond360).SetEase(Ease.Linear));
            seq.AppendInterval(time2);
            seq.Join(transform.DORotate(new Vector3(0, 360 * 5, 0), time3, RotateMode.FastBeyond360).SetEase(Ease.Linear));
            seq.Join(transform.DOMoveX(1200, time3).SetEase(Ease.Linear));
            seq.Append(transform.DOScale(Vector3.one, 0.1f));
            seq.AppendInterval(3f);
            seq.OnComplete(() =>
            {
                if (baoFx != null)
                {
                    GameObject.Destroy(baoFx);
                    baoFx = null;
                }
                SetSortingOrder(DefaultSortOrder);
            });
            seq.OnKill(() =>
            {
                if (baoFx != null)
                {
                    GameObject.Destroy(baoFx);
                    baoFx = null;
                }
                SetSortingOrder(DefaultSortOrder);
            });
        }
        StartCoroutine(PlayAnim());

        return time1 + time2 + time3;
    }

    public float UndoAnim(Vector3 pos)
    {
        SetSortingOrder(FxSortOrder);
        gameObject.SetActive(true);
        float duration = 1f;
        transform.DOMove(pos, duration).SetEase(Ease.Linear).OnComplete(()=>{
            SetSortingOrder(DefaultSortOrder);
        });
        return duration;
    }

    public override void SetBack(int cardBackId, int betValue)
    {
    }

}
