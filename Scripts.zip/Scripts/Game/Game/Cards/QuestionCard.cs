using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using SoliUtils;
using UnityEngine;

public class QuestionCard : BaseCard
{
    internal float DoTriggerQuestionCard(bool undo = false)
    {
        if (undo)
        {
            var pos = new Vector3(CardData.cm.x, CardData.cm.y, CardData.cm.depth);
            CardAngle = CardData.cm.angle;
            var scale = Constants.CardSizeScale;
            transform.localScale = Vector3.one;
            cardObj.transform.localScale = scale;
            transform.position = pos;
            gameObject.SetActive(true);
            DoAlphaAnim(1, 0.2f, Ease.Linear);
            return 0.1f;
        }

        SoundPlayer.Instance.PlayMainSound("QuestionCard_show");
        PlayAnimation("ani_QuestionCard_01", () =>
        {
            gameObject.SetActive(false);
            CardAngle = CardData.cm.angle;
            var scale = Constants.CardSizeScale;
            transform.localScale = Vector3.one;
            cardObj.transform.localScale = scale;
        });

        _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_QuestionCard_01.prefab", (obj) =>
            {
                var scene = Camera.main.transform.parent;
                obj.transform.SetParent(scene);
                obj.transform.position = gameObject.transform.position;
                obj.SetActive(true);
            }, true, 3f);

        return 105 / 60f;
    }
}
