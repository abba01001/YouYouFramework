using System;
using System.Collections;
using DG.Tweening;
using UnityEngine;
using SoliUtils;
using UniRx;

public class LockCard : BaseCard
{
    private GameObject lockAnim = null;
    private IDisposable subscription;
    internal void DoOpenLockCard()
    {
        SoundPlayer.Instance.PlayLock();
        IEnumerator PlayAnim()
        {
            GameObject openLockFx = null;//Instantiate(GlobalRes.Load<GameObject>(Constants.OpenLockFx));
            GlobalRes.DynamicLoadPrefab(Constants.OpenLockFx, (obj) =>
            {
                openLockFx = obj;
                openLockFx.gameObject.SetActive(false);
            });
            while (openLockFx == null)
            {
                yield return null;
            }
            
            float time = 0.2f;
            Vector3 selfPos = transform.position;
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            seq.Append(transform.DOScale(Vector3.one * 1.2f, time).SetEase(Ease.OutQuart));
            seq.AppendCallback(() =>
            {
                DestroyLockAnim();
                openLockFx.gameObject.SetActive(true);
                openLockFx.transform.position = selfPos;
            });
            seq.Append(transform.DOScale(Vector3.one * 0.5f, time));
            seq.Join(DoAlphaAnim(0, time));
            seq.AppendInterval(0.4f);
            seq.OnComplete(() =>
            {
                gameObject.SetActive(false);
                Destroy(openLockFx.gameObject);
                // GlobalRes.Release<GameObject>(Constants.OpenLockFx);
            });
        }
        StopCoroutine(PlayAnim());
        StartCoroutine(PlayAnim());
    }
    
    public override void OnDisable()
    {
        DestroyLockAnim();
    }
    
    public void DestroyLockAnim()
    {
        if (lockAnim != null)
        {
            Destroy(lockAnim);
            subscription?.Dispose();
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            renderer.material.SetTextureOffset("_SpecTex",new Vector2(0, 0));
            lockAnim = null;
        }
    }
    
    public void PlayLockAnim()
    {
        if (!gameObject.activeSelf) return;
        if(!CardData.IsFaceup) return;
        if (lockAnim == null)
        {
            _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/LockCard_dh.prefab", (obj) =>
            {
                var renderer = cardObj.GetComponent<SpriteRenderer>();
                renderer.material.SetTextureOffset("_SpecTex",new Vector2(-1, -1));
                
                obj.transform.SetParent(cardObj.transform);
                obj.transform.localScale = Vector3.one;
                obj.transform.localPosition = Vector3.zero;
                obj.transform.localRotation = Quaternion.identity;
                obj.SetActive(true);
                lockAnim = obj;

                SoundPlayer.Instance.PlayMainSound("ani_card_lock");
                subscription = Observable.Interval(TimeSpan.FromSeconds(6f))
                    .Subscribe(_ =>  SoundPlayer.Instance.PlayMainSound("ani_card_lock"));
            });
        }
    }
    
}
