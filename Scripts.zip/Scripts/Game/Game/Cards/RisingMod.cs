using UnityEngine;

public class RisingMod : BaseMod
{
    public Animator animator;

    private void OnEnable() 
    {
        gameObject.transform.localScale = Vector3.one;
        gameObject.transform.localEulerAngles = Vector3.zero;
        gameObject.transform.localPosition = new Vector3(0, 0, -0.1f);
        SetAlpha(0);
    }

    public void ShowEff()
    {
        SetAlpha(255);
        // animator.Play("arrow_01");
    }
    
    // public override void SetAlpha(int alpha)
    // {
    //     foreach(var mat in GetComponentsInChildren<MeshRenderer>())
    //     {
    //         MaterialPropertyBlock block = new MaterialPropertyBlock();
    //         mat.GetPropertyBlock(block);
	   //      block.SetColor("_BlendColor", new Color32(255, 255, 255, (byte)alpha));
    //         mat.SetPropertyBlock(block);
    //     }
    // }

}
