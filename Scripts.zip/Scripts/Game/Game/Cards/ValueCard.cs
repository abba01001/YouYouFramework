using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using Game.Cards;
using UniRx;
using UnityEngine;
using SoliUtils;

public class ValueCard : BaseCard
{
    public Sprite DefaultFront;
    public Sprite DefaultBack;

    private Texture2D lastValueTexture2D;

    public override void Reset()
    {
        base.Reset();

        var renderer = cardObj.GetComponent<SpriteRenderer>();
        MaterialPropertyBlock block = new MaterialPropertyBlock();
        renderer.GetPropertyBlock(block);
        block.SetTexture("_MainTex", DefaultFront.texture);
        block.SetTexture("_BackTex", DefaultBack.texture);
        renderer.SetPropertyBlock(block);
    }

    public override void SetData(CardData cardData, int cardBackId, int betValue)
    {
        base.SetData(cardData, cardBackId, betValue);
        SetValue();
    }


    internal void DoBombAddCard(Vector3 bombPos, Vector3 toPos)
    {
        float time = 0.9f;
        SetSortingOrder(FxSortOrder);
        Sequence seq = DOTween.Sequence();
        _ = seq.SetId(transform);
        bombPos.z = toPos.z;
        SetVisible(true);
        transform.position = bombPos;
        transform.localScale = Vector3.one * 0.7f;
        bool isLeftHalf = toPos.x <= 0;
        _ = seq.Append(transform.DOMoveX(toPos.x, time));
        _ = seq.Join(transform.DOScale(Vector3.one, time / 5));
        _ = seq.Join(transform.DOBlendableRotateBy(new Vector3(0, 0, isLeftHalf ? -360 : 360), time, RotateMode.FastBeyond360));
        _ = seq.Insert(0, transform.DOMoveY(toPos.y + 200, time / 2).SetEase(Ease.OutCubic));
        _ = seq.Insert(time / 2, transform.DOMoveY(toPos.y, time / 2).SetEase(Ease.InQuad));
        seq.onComplete += () =>
        {
            SetSortingOrder(DefaultSortOrder);
        };
    }

    public async void SetValue()
    {
        var renderer = cardObj.GetComponent<SpriteRenderer>();
        var defaultFontBg = Constants.CardFrontTex_Normal;
        var defaultBackBg = Constants.CardBackTex_Normal;

        var value = CardData.Value;
        if (value == -1)
        {
            var frontBg = defaultFontBg;
            if (!string.IsNullOrEmpty(frontBgTexture))
                frontBg = frontBgTexture;
            _ = SpriteUtils.GetSpriteAsyncByPath(frontBg, (temp) =>
            {
                renderer.sprite = temp;
            });

            if (!string.IsNullOrEmpty(backBgTexture))
            {
                _ = SpriteUtils.GetTextureAsyncByPath(backBgTexture, (temp) =>
                {
                    MaterialPropertyBlock block = new MaterialPropertyBlock();
                    renderer.GetPropertyBlock(block);
                    block.SetTexture("_BackTex", temp);
                    renderer.SetPropertyBlock(block);
                });
            }

            var matTemp = new Material(renderer.material);
            matTemp.SetTexture("_FlowerTex", new Texture2D(0, 0));
            matTemp.SetTexture("_ValueTex", new Texture2D(0, 0));
            matTemp.SetInt("_ToggleTempValue", 0);
            renderer.material = matTemp;

            if (!GameCommon.IsEditorMode)
            {
                return;
            }
        }

        var typeIndex = value / Constants.ValueCardCount13;
        var valueIndex = value % Constants.ValueCardCount13;
        var color = (typeIndex == 1 || typeIndex == 3) ? "red" : "black";

        Sprite frontBgSprite = null;
        Texture2D backBgTexture2D = null;
        Texture2D flowerTexture2D = null;
        Texture2D valueTexture2D = null;
        if (!string.IsNullOrEmpty(frontBgTexture))
        {
            _ = SpriteUtils.GetSpriteAsyncByPath(frontBgTexture, (temp) =>
            {
                frontBgSprite = temp;
            });
        }
        else
        {
            _ = SpriteUtils.GetSpriteAsyncByPath(defaultFontBg, (temp) =>
            {
                frontBgSprite = temp;
            });
        }


        if (!string.IsNullOrEmpty(backBgTexture))
        {
            _ = SpriteUtils.GetTextureAsyncByPath(backBgTexture, (temp) =>
            {
                backBgTexture2D = temp;
            });
        }
        else
        {
            _ = SpriteUtils.GetTextureAsyncByPath(defaultBackBg, (temp) =>
            {
                backBgTexture2D = temp;
            });
        }

        _ = SpriteUtils.GetTextureAsyncByPath(Constants.FlowerResMap[typeIndex], (temp) =>
        {
            flowerTexture2D = temp;
        });

        _ = SpriteUtils.GetTextureAsyncByPath($"Assets/Res/Cards/Textures/{color}_{valueIndex + 1}.png", (temp) =>
        {
            valueTexture2D = temp;
            lastValueTexture2D = temp;
        });

        while (flowerTexture2D == null || valueTexture2D == null || frontBgSprite == null || backBgTexture2D == null)
        {
            await UniTask.Yield();
        }

        MaterialPropertyBlock block = new MaterialPropertyBlock();
        renderer.GetPropertyBlock(block);
        renderer.sprite = frontBgSprite;
        block.SetTexture("_MainTex", frontBgSprite.texture);
        block.SetTexture("_FlowerTex", flowerTexture2D);
        block.SetTexture("_ValueTex", valueTexture2D);
        block.SetTexture("_BackTex", backBgTexture2D);
        // block.SetTexture("_ValueTempTex", valueTexture2D);
        // block.SetInt("_ToggleTempValue", 0);
        renderer.SetPropertyBlock(block);

        renderer.material.SetTextureScale("_MainTex", new Vector2(1, 1));
        if (frontBgHide)
            renderer.material.SetTextureScale("_MainTex", new Vector2(0, 0)); // 正面背景图不显示

    }

    public void ShowRisingEff(Action cb = null, bool undo = false)
    {
        var risingMod = cardObj.GetComponentInChildren<RisingMod>();
        if (risingMod != null)
        {
            risingMod.ShowEff();
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            //SoundPlayer.Instance.PlayUpdownChange();


            renderer.material.SetInt("_ToggleTempValue", 1);
            var oldValueTex = renderer.material.GetTexture("_ValueTex") as Texture2D;
            renderer.material.SetTexture("_ValueTempTex", lastValueTexture2D);
            if (!undo)
            {
                renderer.material.DOOffset(new Vector2(0, 0f), "_ValueTempTex", 0f);
                renderer.material.DOOffset(new Vector2(0, 1f), "_ValueTex", 0f);
            }
            else
            {
                renderer.material.DOOffset(new Vector2(0, 0f), "_ValueTempTex", 0f);
                renderer.material.DOOffset(new Vector2(0, -1f), "_ValueTex", 0f);
            }
            cb?.Invoke();
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            if (!undo)
            {
                seq.Join(renderer.material.DOOffset(new Vector2(0, -1f), "_ValueTempTex", 0.2f));
                seq.Join(renderer.material.DOOffset(new Vector2(0, 0f), "_ValueTex", 0.2f));
            }
            else
            {
                seq.Join(renderer.material.DOOffset(new Vector2(0, 1f), "_ValueTempTex", 0.2f));
                seq.Join(renderer.material.DOOffset(new Vector2(0, 0f), "_ValueTex", 0.2f));
            }
            seq.OnComplete(() =>
            {
                renderer.material.SetInt("_ToggleTempValue", 0);
            });
        }
        else
        {
            cb?.Invoke();
        }
    }

    public void ShowLoweringEff(Action cb = null, bool undo = false)
    {
        var loweringMod = cardObj.GetComponentInChildren<LoweringMod>();
        if (loweringMod != null)
        {
            loweringMod.ShowEff();
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            //SoundPlayer.Instance.PlayUpdownChange();

            renderer.material.SetInt("_ToggleTempValue", 1);
            var oldValueTex = renderer.material.GetTexture("_ValueTex") as Texture2D;
            renderer.material.SetTexture("_ValueTempTex", lastValueTexture2D);
            if (!undo)
            {
                renderer.material.DOOffset(new Vector2(0, 0f), "_ValueTempTex", 0f);
                renderer.material.DOOffset(new Vector2(0, -1f), "_ValueTex", 0f);
            }
            else
            {
                renderer.material.DOOffset(new Vector2(0, 0f), "_ValueTempTex", 0f);
                renderer.material.DOOffset(new Vector2(0, 1f), "_ValueTex", 0f);
            }
            cb?.Invoke();
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            if (!undo)
            {
                seq.Join(renderer.material.DOOffset(new Vector2(0, 1f), "_ValueTempTex", 0.2f));
                seq.Join(renderer.material.DOOffset(new Vector2(0, 0f), "_ValueTex", 0.2f));
            }
            else
            {
                seq.Join(renderer.material.DOOffset(new Vector2(0, -1f), "_ValueTempTex", 0.2f));
                seq.Join(renderer.material.DOOffset(new Vector2(0, 0f), "_ValueTex", 0.2f));
            }
            seq.OnComplete(() =>
            {
                renderer.material.SetInt("_ToggleTempValue", 0);
            });
        }
        else
        {
            cb?.Invoke();
        }
    }

    public void SetRopeSuits(CardData cd)
    {
        var ropeMod = cardObj.GetComponentInChildren<SuitRopeMod>();
        for (int i = 0; i < cd.SuitRopeStates.Count; i++)
        {
            if (cd.SuitRopeStates[i] && ropeMod.Flowers[i].activeSelf)
            {
                ropeMod.PlaySuitEff(i);
            }
        }
    }

    public void SetRopeSuits(List<int> list, bool resetValue = false)
    {
        var ropeMod = cardObj.GetComponentInChildren<SuitRopeMod>();
        if (resetValue && ropeMod == null)
            ResetModifier();
        if (ropeMod != null)
        {
            ropeMod.InitSuit(list);
        }
    }

    public void SetClothOpen(bool isOpen, bool refreshValue = false)
    {
        if (refreshValue)
            SetValue();
        cardObj.GetComponentInChildren<ClothMod>()?.SetState(isOpen);
    }

    public void SetMagicClothOpen(bool isOpen, bool refreshValue = false)
    {
        // if (refreshValue)
        SetValue();
        cardObj.GetComponentInChildren<MagicClothMod>()?.SetState(isOpen);
    }

    public void SetGreenLeafBird(bool birdActive)
    {
        // cardObj.GetComponentInChildren<GreenLeafMod>().SetBirdActive(birdActive);
    }

    public void SetLightningTimer(int timer, int resetValue = -1)
    {
        if (resetValue == CardData.Value)
            SetValue();
        gameObject.GetComponentInChildren<LightningMod>()?.SetTimer(timer);
    }

    // public override void SetFront(int bet=1)
    // {
    //     if (Constants.CardFrontRes.TryGetValue(bet, out var file))
    //     {
    //         MaterialPropertyBlock block = new MaterialPropertyBlock();
    //         var renderer = cardObj.GetComponent<SpriteRenderer>();
    //         renderer.GetPropertyBlock(block);
    //         var res = Resources.Load<Texture2D>(file);
    //         block.SetTexture("_MainTex", res);
    //         renderer.SetPropertyBlock(block);
    //     }
    // }


    public async void BreakIce()
    {
        var iceMod = cardObj.GetComponentInChildren<IceMod>();
        if (iceMod != null)
        {
            iceMod.SetAlpha(0);
            SoundPlayer.Instance.PlayIceBreak();
            GameObject breakPrefab = null; //Instantiate(GlobalRes.Load<GameObject>(Constants.iceBreakStr));
            GameObject breakFx = null; //Instantiate(GlobalRes.Load<GameObject>(Constants.iceBreakFxStr));

            _ = GlobalRes.DynamicLoadPrefab(Constants.iceBreakStr, (obj) => { breakPrefab = obj; });
            _ = GlobalRes.DynamicLoadPrefab(Constants.iceBreakFxStr, (obj) => { breakFx = obj; });
            while (breakPrefab == null || breakFx == null)
            {
                await UniTask.Yield();
            }

            breakPrefab.transform.position = transform.position;
            breakFx.transform.position = transform.position;
            Destroy(breakPrefab, 2);
            Destroy(breakFx, 2);
            // GlobalRes.Release<GameObject>(Constants.iceBreakStr, 2);
            // GlobalRes.Release<GameObject>(Constants.iceBreakFxStr, 2);
        }
    }

    public void UndoBreakIce()
    {
        var iceMod = cardObj.GetComponentInChildren<IceMod>();
        if (iceMod != null)
        {
            iceMod.Active();
        }
    }

    public void RefreshSuitRope(Dictionary<int, int> ropeSuits, Dictionary<int, bool> ropeStates)
    {
        var risingMod = cardObj.GetComponentInChildren<SuitRopeMod>();
        if (risingMod != null)
        {
            risingMod.ResetSuits(ropeStates);
        }
    }




}
