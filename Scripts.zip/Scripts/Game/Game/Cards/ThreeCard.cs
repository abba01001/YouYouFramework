using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using SoliUtils;

public class ThreeCard : BaseCard
{
    public override void SetData(CardData cardData, int cardBackId, int betValue)
    {
        base.SetData(cardData, cardBackId);
        SetNumber();
    }

    public void SetNumber()
    {
        var rendererTemp = cardObj.GetComponent<SpriteRenderer>();
        var number = Math.Max(CardData.Value, 1);
        number = Math.Min(number, 5);
        _ = SpriteUtils.GetSpriteAsyncByPath($"Assets/Res/Cards/Textures/more_{number}.png", (temp) =>
        {
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            renderer.sprite = temp;
            // var matTemp = new Material(rendererTemp.material);
            // matTemp.SetTexture("_MainTex", temp);
            // rendererTemp.material = matTemp;
        });

    }

    //丰收牌触发动画
    internal float DoTriggerThreeCard(bool undo = false)
    {
        if (undo)
        {
            var pos = new Vector3(CardData.cm.x, CardData.cm.y, CardData.cm.depth);
            CardAngle = CardData.cm.angle;
            var scale = Constants.CardSizeScale;
            transform.localScale = Vector3.one;
            cardObj.transform.localScale = scale;
            transform.position = pos;
            gameObject.SetActive(true);
            DoAlphaAnim(1, 0.2f, Ease.Linear);
            return 0.1f;
        }
        IEnumerator PlayAnim()
        {
            SoundPlayer.Instance.PlayThreeOut();
            GameObject baoFx = null;//Instantiate(GlobalRes.Load<GameObject>(Constants.baoFx3Str));
            _ = GlobalRes.DynamicLoadPrefab(Constants.baoFx3Str, (obj) => { baoFx = obj; });
            while (baoFx == null)
            {
                yield return null;
            }

            float time = 0.2f;
            SetSortingOrder(FxSortOrder + 1);
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            baoFx.transform.position = transform.position;
            baoFx.gameObject.SetActive(false);
            seq.Append(transform.DOScale(Vector3.one * 1.3f, time).SetEase(Ease.OutCubic));
            seq.AppendInterval(0.1f);
            //seq.Append(transform.DOScale(Vector3.one * 0.6f, time).SetEase(Ease.InSine));
            seq.AppendCallback(() =>
            {
                baoFx.gameObject.SetActive(true);
                gameObject.SetActive(false);
            });
            seq.Join(DoAlphaAnim(0, time, Ease.Linear));
            seq.OnComplete(() =>
            {
                SetSortingOrder(DefaultSortOrder);
                GameObject.Destroy(baoFx, 1f);
                // GlobalRes.Release<GameObject>(Constants.baoFx3Str);
            });
        }
        StopCoroutine(PlayAnim());
        StartCoroutine(PlayAnim());
        return 0.5f; //seq.Duration();
    }

    public override void SetBack(int cardBackId, int betValue)
    {

    }


}
