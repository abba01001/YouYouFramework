using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using TMPro;
using UniRx;
using UnityEngine;
using SoliUtils;

public class BombMod : BaseMod
{
    public TextMeshPro TimerText;
    public GameObject fireObj;
    public GameObject countAnimObj;
    public GameObject[] paoes;
    public GameObject[] paoFxes;
    public GameObject bombEff1;
    public GameObject bombEff2;
    public GameObject boxes;

    public Transform[] poses;


    private int _timer;
    public int Timer
    {
        set
        {
            if (_timer > value)
                _ = DOTween.Restart(countAnimObj);
            _timer = value;
            TimerText.text = _timer.ToString();
            if(_timer > 0)
            {
                Reset();
            }
        }
        get
        {
            return _timer;
        }
    }

    private void OnEnable()
    {
        gameObject.transform.localScale = Vector3.one;
        gameObject.transform.localEulerAngles = Vector3.zero;
        gameObject.transform.localPosition = Vector3.one;
        TimerText.gameObject.SetActive(false);
        fireObj.gameObject.SetActive(false);
        bombEff1.gameObject.SetActive(false);
        bombEff2.gameObject.SetActive(false);
    }

    public override void Active(bool act = true)
    {
        if (act)
        {
            TimerText.gameObject.SetActive(true);
            fireObj.gameObject.SetActive(true);
            SetAlpha(255);
        }
        else
        {
            TimerText.gameObject.SetActive(false);
            fireObj.gameObject.SetActive(false);
            SetAlpha(0);
        }
    }

    public override void SetAlpha(int alpha)
    {
        base.SetAlpha(alpha);
        TimerText.alpha = alpha / 255f;
    }

    Vector3[] CreateComplexPath(Vector3 startPoint, Vector3 endPoint, float initialAngle, float initialDistance, float radius, int segments)
    {
        Vector3[] path = new Vector3[segments + 4];

        // 起始点
        path[0] = startPoint;

        // 初始飞行路径点
        float distance = initialDistance;
        float newX = startPoint.x + distance * Mathf.Cos(initialAngle);
        float newY = startPoint.y + distance * Mathf.Sin(initialAngle);
        Vector3 initialPoint = new Vector3(newX, newY, 0);
        path[1] = initialPoint;

        // 创建小圈路径
        for (int i = 0; i < segments; i++)
        {
            float angle = (i / (float)segments) * Mathf.PI * 2;
            float factor = Mathf.Sin(angle * 0.5f); // 控制小圈的不规则形状

            // 计算小圈的偏移量，注意只在X和Y平面上移动
            Vector3 offsetVector = new Vector3(
                Mathf.Cos(angle) * radius * factor,
                Mathf.Sin(angle) * radius * factor,
                0);

            path[i + 2] = initialPoint + offsetVector;
        }

        // 目标点
        path[segments + 2] = initialPoint;
        path[segments + 3] = endPoint;

        return path;
    }

    public override void PlayDisappearEf()
    {
        if(!transform.gameObject.activeInHierarchy) return;
        GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/bao_tx_FireCrackerMod_01.prefab", (obj) =>
        {
            var scene = Camera.main.transform.parent;
            obj.transform.SetParent(scene);
            obj.transform.position = gameObject.transform.position;
            obj.SetActive(true);
        },true,3f);
        GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/bao_tx_FireCrackerMod_03.prefab", (obj) =>
        {
            var scene = Camera.main.transform.parent;
            obj.transform.SetParent(scene);
            obj.transform.position = gameObject.transform.position;
            obj.SetActive(true);
        },true,3f);
    }
    
    public async void FlyFire(Vector3[] _poses, float duration)
    {
        void PlayAnim(Vector3 pos)
        {
            GameObject bombFx = null; //Instantiate(GlobalRes.Load<GameObject>(Constants.bombFxStr));
            _ = GlobalRes.DynamicLoadPrefab(Constants.fireFxStr, (obj) =>
            {
                bombFx = obj;
            
                bombFx.SetActive(true);
                var scene = Camera.main.transform.parent;
                bombFx.transform.SetParent(scene);
                bombFx.transform.position = pos;
                _ = Observable.Timer(TimeSpan.FromSeconds(2)).Subscribe(_ =>
                {
                    Destroy(bombFx);
                }).AddTo(scene);
                SoundPlayer.Instance.PlayBomb();
            });
        }

        for (int i = 0; i < _poses.Length; i++)
        {
            int idx = i;
            Vector3 fromPos = paoes[idx].transform.position;
            Vector3 endPos = _poses[idx];

            List<Vector3> pathes = new List<Vector3>();

            // int[] ang = { 30, 0, -3 };
            // float angleInRadians = (ang[idx] + 90) * Mathf.Deg2Rad;
            // float distance = 200;
            // float newX = fromPos.x + distance * Mathf.Cos(angleInRadians);
            // float newY = fromPos.y + distance * Mathf.Sin(angleInRadians);
            // Vector3 firstPos = new Vector3(newX, newY, -100);
            // Vector3 controlPos = (firstPos - fromPos) / 2;
            // Vector3[] pathPosArray = BezierUtils.GetBeizerList(fromPos, controlPos, firstPos, 100);
            // pathes.AddRange(pathPosArray);
            // pathes.Add(firstPos);
            // Vector3 controlPos = (endPos - fromPos) / 2;
            // controlPos.y = fromPos.y+200;
            // Vector3[] pathPosArray = BezierUtils.GetBeizerList(fromPos, controlPos, endPos, 100);
            // pathes.AddRange(pathPosArray);
            _ = paoes[idx].transform.DOScale(2f, duration / 3 * 2).OnComplete(() =>
            {
                _ = paoes[idx].transform.DOScale(1.5f, duration / 3 * 1);
            });


            // 起始点
            Vector3 startPoint = fromPos;
            // 目标点
            Vector3 endPoint = endPos;
            float loopRadius = UnityEngine.Random.Range(80, 250); // 小圈的半径
            float loopOffset = UnityEngine.Random.Range(80, 250); // 小圈的偏移
            int loopSegments = 150; // 小圈的细分段数
            float initdis = UnityEngine.Random.Range(50, 300); // 初始飞行距离
            int[] ang = { 30, 0, -3 };
            float angleInRadians = (ang[idx] + 90) * Mathf.Deg2Rad;

            // 计算中间点来形成小圈
            Vector3[] path = CreateComplexPath(startPoint, endPoint, angleInRadians, initdis, loopRadius, loopSegments);

            // 使用 DOPath 方法沿路径移动对象
            // paoes[idx].transform.DOPath(path, duration, PathType.CatmullRom)
            //          .SetOptions(false) // 保持对象朝向路径方向
            //          .SetLookAt(0.01f); // 设置朝向的灵敏度，可以根据需要调整


            paoes[idx].transform.DOPath(path, duration, PathType.CatmullRom, PathMode.TopDown2D)
                // .SetOptions(false) // 保持对象朝向路径方向
                // .SetLookAt(0.01f) // 设置朝向的灵敏度，可以根据需要调整
                .OnWaypointChange(p =>
                {
                    if (p > 0 && p + 1 < path.Length)
                    {
                        Vector3 direction = path[p + 1] - path[p];
                        float angle = (Mathf.Atan2(direction.y, direction.x) - 90) * Mathf.Rad2Deg;
                        paoes[idx].transform.DORotateQuaternion(Quaternion.Euler(0, 0, angle), 0.2f);
                    }
                }).SetEase(Ease.InCubic).OnComplete(() =>
                {
                    paoes[idx].gameObject.SetActive(false);
                    PlayAnim(endPos);
                });
            paoFxes[idx].SetActive(true);
        }
        SoundPlayer.Instance.PlayMainSound("tuowei_tx_FireCrackerMod");

        _ = Observable.Timer(TimeSpan.FromSeconds(0.5f)).Subscribe(_ =>
        {
            boxes.gameObject.SetActive(true);
            bombEff1.gameObject.SetActive(false);
            for (int i = _poses.Length; i < 3; i++)
            {
                paoes[i].SetActive(false);
            }
        }).AddTo(this);
    }

    public void Reset()
    {
        for (int i = 0; i < 3; i++)
        {
            _ = paoes[i].transform.DOKill();
            paoes[i].transform.localPosition = poses[i].localPosition;
            paoes[i].transform.localRotation = poses[i].localRotation;
            paoes[i].SetActive(true);
            paoFxes[i].SetActive(false);
        }
        boxes.gameObject.SetActive(true);
        bombEff1.gameObject.SetActive(false);
    }
}
