using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using SoliUtils;
using Cysharp.Threading.Tasks;
using UniRx;

public class RudderCard : BaseCard
{
    private GameObject frontItem;
    public override void SetData(CardData cardData, int cardBackId, int betValue)
    {
        base.SetData(cardData, cardBackId);
        SetFront();
    }

    public override bool IsFaceUp
    {
        get => _isFaceUp;
        set
        {
            // if (_isFaceUp == value) return;
            _isFaceUp = value;
            cardObj.transform.localScale = value ? Vector3.one : faceDownVec;
            cardObj.transform.localScale *= Constants.CardSizeScale;
            frontItem?.SetActive(_isFaceUp);
            if (frontItem != null)
            {
                if (_isFaceUp)
                {
                    var ani = frontItem.GetComponent<Animator>();
                    ani.enabled = true;
                    ani.Play($"ani_RudderCard_0{(CardData.cm.suit == 0 || CardData.cm.suit == 2 ? 1 : 2)}");
                }
                else
                {

                }
            }
        }
    }

    public override float DoTurnCard(Vector3 toPos, bool toFaceUp, float halfTime = 0.175f)
    {
        if (!toFaceUp)
        {
            if (frontItem != null)
            {
                GameObject.Destroy(frontItem);
                frontItem = null;
            }
        }
        else
        {
            SetFront();
        }
        return base.DoTurnCard(toPos, toFaceUp, halfTime);
    }

    public void SetFront()
    {
        // if (CardData.cm.random || CardData.cm.suit == -1)
        // {
        //     return;
        // }

        var renderer = cardObj.GetComponent<SpriteRenderer>();

        string res = "Assets/Res/Cards/Textures/RudderCard_r.png";
        if (CardData.cm.suit == 0 || CardData.cm.suit == 2)
            res = "Assets/Res/Cards/Textures/RudderCard_b.png";
        _ = SpriteUtils.GetSpriteAsyncByPath(res, (temp) =>
            {
                renderer.sprite = temp;
            });


        if (frontItem != null)
        {
            GameObject.Destroy(frontItem);
            frontItem = null;
        }

        _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/RudderCard_dh.prefab", (obj) =>
            {
                frontItem = obj;
                frontItem.transform.SetParent(cardObj.transform);
                frontItem.gameObject.SetActive(_isFaceUp);
                frontItem.transform.localPosition = Vector3.zero;
                frontItem.transform.localRotation = Quaternion.identity;
                frontItem.transform.localScale = Vector3.one;
                var ani = frontItem.GetComponent<Animator>();
                ani.enabled = true;
                ani.Play($"ani_RudderCard_0{(CardData.cm.suit == 0 || CardData.cm.suit == 2 ? 1 : 2)}");
            });
    }

    internal float DoTriggerRudderCard()
    {
        if (frontItem == null)
            return 0f;
        SetSortingOrder(FxSortOrder + 1);
        
        var duration = 245 / 60f - 0.5f;

        var mid = frontItem.transform.Find("card_mid");
        mid.DOMove(Vector3.zero, 0.5f).OnComplete(() =>
        {
        });
        var ani = frontItem.GetComponent<Animator>();
        ani.enabled = true;
        ani.Play($"ani_RudderCard_03");

        DoAlphaAnim(0, 0.5f);

        Observable.Timer(TimeSpan.FromSeconds(duration * 0.8f)).Subscribe(_ =>
        {
            mid.DOMove(Vector3.zero + Vector3.down * 800, 0.5f).SetEase(Ease.InSine);
        }).AddTo(this);

        GameObject fx = null;
        Observable.Timer(TimeSpan.FromSeconds(11/12f)).Subscribe(_ =>
        {
            GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_RudderCard_01.prefab", (obj) =>
                {
                    fx = obj;
                    obj.gameObject.SetActive(true);
                    obj.transform.localPosition = Vector3.zero;
                    obj.transform.localRotation = Quaternion.identity;
                    obj.transform.localScale = Vector3.one;
                });
        }).AddTo(this);


        Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_ =>
        {
            GameObject.Destroy(frontItem);
            frontItem = null;
            if (fx != null)
                GameObject.Destroy(fx);
            SetSortingOrder(DefaultSortOrder);
            gameObject.SetActive(false);
        }).AddTo(this);

        return duration; //seq.Duration();
    }


}
