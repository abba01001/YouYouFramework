using UnityEngine;

public partial class BaseMod : MonoBehaviour
{
    public virtual void SetAlpha(int alpha)
    {
        foreach (var renderer in GetComponentsInChildren<Renderer>())
        {
            // MaterialPropertyBlock block = new MaterialPropertyBlock();
            // renderer.GetPropertyBlock(block);
            // block.SetColor("_BlendColor", new Color32(255, 255, 255, (byte)alpha));
            // renderer.SetPropertyBlock(block);
            var mat = new Material(renderer.material);
            mat.SetColor("_BlendColor", new Color32(255, 255, 255, (byte)alpha));
            renderer.material = mat;
        }
    }

    public virtual void Active(bool act = true)
    {
        if (act)
            SetAlpha(255);
        else
            SetAlpha(0);
    }

    public virtual void PlayDisappearEf()
    {
        
    }
}