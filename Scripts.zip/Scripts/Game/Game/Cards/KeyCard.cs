using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using SoliUtils;
using UniRx;

public class KeyCard : BaseCard
{
    private GameObject keyAnim = null;
    private IDisposable subscription;
    //钥匙牌触发动画
    internal float DoTriggerKeyCard(List<BaseCard> lockCardList)
    {
        SoundPlayer.Instance.PlayUtilShow();
        IEnumerator PlayAnim()
        {
            SetSortingOrder(FxSortOrder);
            GameObject showFx = null; //Instantiate(GlobalRes.Load<GameObject>(Constants.showFxStr));
            List<GameObject> keyPrefabList = new List<GameObject>(lockCardList.Count);
            _ = GlobalRes.DynamicLoadPrefab(Constants.showFxStr, (obj) =>
            {
                showFx = obj;
                showFx.gameObject.SetActive(false);
            });
            lockCardList.ForEach(x =>
            {
                _ = GlobalRes.DynamicLoadPrefab(Constants.keyPrefabStr, (obj) =>
                {
                    obj.gameObject.SetActive(false);
                    keyPrefabList.Add(obj);
                });
                x.SetSortingOrder(FxSortOrder);
            });
            while (keyPrefabList.Count != lockCardList.Count || showFx == null)
            {
                yield return null;
            }
            
            float time = 0.2f;
            Vector3 selfPos = transform.position;
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            seq.Append(transform.DOScale(Vector3.one * 1.2f, time).SetEase(Ease.OutQuart));
            seq.AppendCallback(() =>
            {
                DestroyKeyAnim();
                showFx.gameObject.SetActive(true);
                showFx.transform.position = selfPos;
                keyPrefabList.ForEach(x =>
                {
                    x.transform.gameObject.SetActive(true);
                    x.transform.position = selfPos;
                    x.transform.localScale = Vector3.one * 1.2f;
                });
            });
            seq.AppendInterval(0.01f);
            keyPrefabList.ForEach(x => seq.Join(x.transform.DOPunchScale(Vector3.one * 0.3f, time, elasticity: 0)));
            seq.Join(transform.DOScale(Vector3.one * 0.5f, time));
            seq.Join(DoAlphaAnim(0, time));
            seq.AppendInterval(time);
            seq.AppendInterval(0.01f);
            seq.AppendCallback(() => { SoundPlayer.Instance.PlayKey(); });
            for (int i = 0; i < keyPrefabList.Count; i++)
            {
                seq.Join(keyPrefabList[i].transform.DOMove(lockCardList[i].transform.position, 0.4f)
                    .SetEase(Ease.OutQuad));
                seq.Join(keyPrefabList[i].transform.DORotate(new Vector3(0, 0, 360), 0.4f, RotateMode.FastBeyond360)
                    .SetEase(Ease.OutQuad));
            }

            seq.AppendInterval(0.01f);
            keyPrefabList.ForEach(x => seq.Join(x.GetComponent<SpriteRenderer>().DOFade(0, time)));
            lockCardList.ForEach(toCard => seq.InsertCallback(1f, () => ((LockCard) toCard).DoOpenLockCard()));
            seq.OnComplete(() =>
            {
                SetSortingOrder(DefaultSortOrder);
                Destroy(showFx.gameObject);
                // GlobalRes.Release<GameObject>(Constants.showFxStr);
                keyPrefabList.ForEach(x => Destroy(x.gameObject));
                // GlobalRes.Release<GameObject>(Constants.keyPrefabStr);
                gameObject.SetActive(false);
            });
        }
        StopCoroutine(PlayAnim());
        StartCoroutine(PlayAnim());
        return 1.21f; //seq.Duration();
    }

    public override void OnDisable()
    {
        DestroyKeyAnim();
    }

    public void DestroyKeyAnim()
    {
        if (keyAnim != null)
        {
            Destroy(keyAnim);
            subscription?.Dispose();
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            renderer.material.SetTextureOffset("_SpecTex",new Vector2(0, 0));
            keyAnim = null;
        }
    }
    
    public void PlayShowKeyAnim()
    {
        if (!gameObject.activeSelf) return;
        if(!CardData.IsFaceup) return;
        if (keyAnim == null)
        {
            _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/KeyCard_dh.prefab", (obj) =>
            {
                var renderer = cardObj.GetComponent<SpriteRenderer>();
                renderer.material.SetTextureOffset("_SpecTex",new Vector2(-1, -1));
                
                obj.transform.SetParent(cardObj.transform);
                obj.transform.localScale = Vector3.one;
                obj.transform.localPosition = Vector3.zero;
                obj.transform.localRotation = Quaternion.identity;
                obj.SetActive(true);
                keyAnim = obj;
                
                SoundPlayer.Instance.PlayMainSound("ani_card_key");
                subscription = Observable.Interval(TimeSpan.FromSeconds(6f))
                    .Subscribe(_ =>  SoundPlayer.Instance.PlayMainSound("ani_card_key"));
            });
        }
    }
}