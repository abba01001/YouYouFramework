using QFramework;
using UnityEngine;
using SoliUtils;

public class LockItemHead : MonoBehaviour
{
    void OnMouseDown()
    {
        if (GameCommon.IsEditorMode)
        {
            transform.SendMessageUpwards("OnEditorMouseDownEvent");
        }
    }
}

public class LockValueItem : MonoBehaviour
{
    public BlockModel data;
}

public partial class LockItem : MonoBehaviour
{
    public GameObject rect;
    public GameObject item;
    public void Show(LockModel data)
    {
        transform.Find("top").gameObject.AddComponent<LockItemHead>();
        if (data == null)
            return;
        transform.position = new Vector3(data.x, data.y, transform.position.z);

        if (data.blocks != null)
        {
            foreach (var block in data.blocks)
            {
                var newItem = Instantiate(item, transform);
                if (block.random)
                {
                    newItem.GetComponentsInChildren<SpriteRenderer>()[1].sprite = null;
                }
                else if (block.type.Equals("value"))
                {
                    SpriteUtils.GetSpriteAsyncByPath($"Assets/Res/Cards/Textures/duodian_black_{block.value}.png", (temp) =>
                    {
                        newItem.GetComponentsInChildren<SpriteRenderer>()[1].sprite = temp;
                    });
                }
                else if (block.type.Equals("suit"))
                {
                    newItem.GetComponentsInChildren<SpriteRenderer>()[1].sprite =
                        GlobalRes.Load<Sprite>(Constants.FlowerRes2Map[block.value]);
                }
                else if (block.type.Equals("color"))
                {
                    var img = block.value == 0 ? "yanse_hei" : "yanse_hong";
                    newItem.GetComponentsInChildren<SpriteRenderer>()[1].sprite =
                        GlobalRes.Load<Sprite>($"Assets/Res/Cards/Textures/{img}.png");
                }
                var lvi = newItem.AddComponent<LockValueItem>();
                lvi.data = block;
            }
        }
        item.SetActive(false);
        var delta = GetComponent<RectTransform>().sizeDelta;
        if(data.blocks != null && data.blocks.Length > 0)
            delta.y = 75 * data.blocks.Length;
        GetComponent<RectTransform>().sizeDelta = delta;
    }

    public void ReViewItem(LockModel data)
    {
        var items = GetComponentsInChildren<LockValueItem>();
        foreach (var item in items)
        {
            Destroy(item.gameObject);
        }
        if (data.blocks != null)
        {
            foreach (var block in data.blocks)
            {
                var newItem = Instantiate(item, transform);
                newItem.SetActive(true);
                if (block.random)
                {
                    newItem.GetComponentsInChildren<SpriteRenderer>()[1].sprite = null;
                }
                else if (block.type.Equals("value"))
                {
                    SpriteUtils.GetSpriteAsyncByPath($"Assets/Res/Cards/Textures/duodian_black_{block.value}.png", (temp) =>
                    {
                        newItem.GetComponentsInChildren<SpriteRenderer>()[1].sprite = temp;
                    });
                }
                else if (block.type.Equals("suit"))
                {
                    newItem.GetComponentsInChildren<SpriteRenderer>()[1].sprite =
                        GlobalRes.Load<Sprite>(Constants.FlowerRes2Map[block.value]);
                }
                else if (block.type.Equals("color"))
                {
                    var img = block.value == 0 ? "yanse_hei" : "yanse_hong";
                    newItem.GetComponentsInChildren<SpriteRenderer>()[1].sprite =
                        GlobalRes.Load<Sprite>($"Assets/Res/Cards/Textures/{img}.png");
                }
                var lvi = newItem.AddComponent<LockValueItem>();
                lvi.data = block;
            }
            var delta = GetComponent<RectTransform>().sizeDelta;
            delta.y = 75 * data.blocks.Length;
            GetComponent<RectTransform>().sizeDelta = delta;
        }
    }


    // private Vector2 mouseStart;
    // private bool mouseDown;
    // private void Update() 
    // {
    //     if (Input.GetMouseButtonDown(0))
    //     {
    //         mouseStart = Input.mousePosition;
    //         mouseDown = true;
    //     }
    //     if (Input.GetMouseButtonUp(0))
    //         mouseDown = false;


    //     if (mouseDown)
    //     {
    //         var touch = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
    //         Vector3 screenPos = Camera.main.WorldToScreenPoint(transform.position); 
    //         if(Vector2.Distance(touch, screenPos) < 50)
    //         {
    //             var move = touch - mouseStart;
    //             var pos = transform.localPosition;
    //             pos.x += move.x;
    //             pos.y += move.y;
    //             transform.localPosition = pos;
    //             mouseStart = touch;
    //         }
    //         else
    //         {


    //         }
    //     }
    // }
}