using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using SoliUtils;

public class ZapCard : BaseCard
{
    internal float DoTriggerZapCard()
    {
        SoundPlayer.Instance.PlayUtilShow();
        IEnumerator PlayAnim()
        {
            float time = 0.2f;
            GameObject showFx = null;
            GameObject zapPrefab = null;
            GlobalRes.DynamicLoadPrefab(Constants.showFxStr, (obj) =>
            {
                showFx = obj;
                showFx.transform.position = transform.position;
            });
            GlobalRes.DynamicLoadPrefab(Constants.zapPrefabStr, (obj) =>
            {
                zapPrefab = obj;
                zapPrefab.transform.localScale = Vector3.one * 1.2f;
                zapPrefab.transform.position = transform.position;
                zapPrefab.transform.DOPunchScale(Vector3.one * 0.3f, time, elasticity:0);
            });
            while (showFx == null || zapPrefab == null)
            {
                yield return null;
            }
            
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            seq.Append(transform.DOScale(Vector3.one * 1.2f, time).SetEase(Ease.OutQuart));
            seq.AppendInterval(time);
            seq.Append(transform.DOScale(Vector3.one * 0.5f, time));
            seq.Join(DoAlphaAnim(0, time));
            seq.OnComplete(() =>
            {
                gameObject.SetActive(false);
                Destroy(showFx.gameObject);
                Destroy(zapPrefab.gameObject);
                // GlobalRes.Release<GameObject>(Constants.showFxStr);
                // GlobalRes.Release<GameObject>(Constants.zapPrefabStr);
            });
        }
        
        StopCoroutine(PlayAnim());
        StartCoroutine(PlayAnim());
        return 0.6f; //seq.Duration();
    }
}
