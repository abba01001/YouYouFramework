using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoliUtils;

public class GoldCard : BaseCard
{
    [SerializeField] private GameObject goldFxObj;

    // private bool forceHideEff = false;

    public override float FlopCard(bool faceup = true)
    {
        SetGold();
        return base.FlopCard(faceup);
    }

    public void ShowEff(bool vis)
    {
        // if (goldFxObj != null)
        //     goldFxObj.SetActive(_isFaceUp && vis);
    }

    public override void SetData(CardData cardData, int cardBackId, int betValue)
    {
        base.SetData(cardData, cardBackId);
        SetGold();
    }
    
    public void SetGold()
    {
        if(CardData.cm.random || CardData.cm.suit == -1)
        {
            var rendererTemp = cardObj.GetComponent<SpriteRenderer>();
            // MaterialPropertyBlock blockTemp = new MaterialPropertyBlock();
            // rendererTemp.GetPropertyBlock(blockTemp);
            // blockTemp.SetTexture("_SpecTex", GlobalRes.Load<Texture2D>($"Assets/Res/Cards/Textures/gold0.png"));
            // rendererTemp.SetPropertyBlock(blockTemp);
            _ = SpriteUtils.GetTextureAsyncByPath($"Assets/Res/Cards/Textures/gold0.png", (temp) =>
            {
                var matTemp = new Material(rendererTemp.material);
                matTemp.SetTexture("_SpecTex", temp);
                rendererTemp.material = matTemp;
            });
            return;
        }
        var renderer = cardObj.GetComponent<SpriteRenderer>();
        // MaterialPropertyBlock block = new MaterialPropertyBlock();
        // renderer.GetPropertyBlock(block);
        // block.SetTexture("_SpecTex", GlobalRes.Load<Texture2D>($"Assets/Res/Cards/Textures/gold{CardModel.suit+1}.png"));
        // renderer.SetPropertyBlock(block);
        _ = SpriteUtils.GetTextureAsyncByPath($"Assets/Res/Cards/Textures/gold{CardData.cm.suit + 1}.png", (temp) =>
        {
            var mat = new Material(renderer.material);
            mat.SetTexture("_SpecTex", temp);
            renderer.material = mat;
        });
    }


    public override float DoTurnCard(Vector3 toPos, bool toFaceUp, float halfTime = 0.175f)
    {
        // if (goldFxObj != null)
        // {
        //     if(forceHideEff)
        //         goldFxObj.SetActive(false);
        //     else
        //         goldFxObj.SetActive(toFaceUp);
        // }
        // forceHideEff = false;
        return base.DoTurnCard(toPos, toFaceUp, halfTime);
    }

    public override float MoveToOpenCardFromHandCards(Vector3Int pos)
    {
        // forceHideEff = true;
        return base.MoveToOpenCardFromHandCards(pos);
    }
}
