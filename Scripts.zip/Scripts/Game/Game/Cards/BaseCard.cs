using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UniRx;
using Doozy.Engine.UI;
using Game.Cards;
using QFramework;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.U2D;
using SoliUtils;
using Random = UnityEngine.Random;
using UnityEngine.EventSystems;
using System.Linq;

public partial class CardObjMono : MonoBehaviour
{
    bool IsPointerOverUIElement()
    {
        PointerEventData eventDataCurrentPosition = new PointerEventData(EventSystem.current);
        eventDataCurrentPosition.position = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        List<RaycastResult> results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(eventDataCurrentPosition, results);
        return results.Count > 1;//忽略game view
    }

    public Action ClickEvent;


    void OnMouseDown()
    {
        if (GameCommon.IsEditorMode)
        {
            transform.SendMessageUpwards("OnEditorMouseDownEvent");
        }
        else
        {
            if (!IsPointerOverUIElement())
            {
                if (!UIPopup.AnyPopupVisible && GameController.Instance.IsPlaying)
                    ClickEvent?.Invoke();
                // transform.SendMessageUpwards("OnMouseDownEvent");
            }
        }
    }
}

public partial class BaseCard : MonoBehaviour
{
    [SerializeField] protected GameObject cardObj;

    public const int DefaultSortOrder = 0;
    public const int FxSortOrder = 31;
    public Animator selfAnimator;
    public bool frontBgHide;
    public string frontBgTexture;
    public string backBgTexture;
    public SpriteAtlas cardAtlas;
    public Dictionary<GameObjType, BaseMod> recordMod = new Dictionary<GameObjType, BaseMod>();
    private GameObject greenLeafObj;
    private IDisposable animationCb;
    [HideInInspector] public int CardId;
    public CardData CardData { get; set; }

    public static readonly Vector3 faceDownVec = new Vector3(-1, 1, 1);


    public bool _isFaceUp = true;

    public virtual bool IsFaceUp
    {
        get => _isFaceUp;
        set
        {
            // if (_isFaceUp == value) return;
            _isFaceUp = value;
            cardObj.transform.localScale = value ? Vector3.one : faceDownVec;
            cardObj.transform.localScale *= Constants.CardSizeScale;
        }
    }

    public int CardAngle
    {
        get
        {
            return (int)Mathf.Round(cardObj.transform.localEulerAngles.z);
        }
        set
        {
            // var angles = cardObj.transform.localEulerAngles;
            // angles.z = value;
            // cardObj.transform.localEulerAngles = angles;
            cardObj.transform.localEulerAngles = new Vector3(0, 0, value);
        }
    }

    private int? _depth = null;

    public int Depth
    {
        get
        {
            if (!_depth.HasValue)
                Depth = CardData.cm.depth;
            return _depth.Value;
        }
        set
        {
            if (_depth == value) return;
            _depth = value;
            CardData.cm.depth = value;
            Vector3 pos = transform.position;
            pos.z = _depth.Value;
            transform.position = pos;
        }
    }

    public virtual void Awake()
    {
        var com = cardObj.AddComponent<CardObjMono>();
        com.ClickEvent = OnMouseDownEvent;
        selfAnimator = GetComponent<Animator>();
        selfAnimator.enabled = false;
        // cardAtlas = GlobalRes.Load<SpriteAtlas>("Assets/Res/Textures/cards.spriteatlas");
    }

    public void SetPosition(int x, int y, int depth, int angle, bool faceup)
    {
        transform.position = new Vector3(x, y, depth);
        Depth = depth;
        IsFaceUp = faceup;
        CardAngle = angle;
    }

    public virtual void Reset()
    {
        SetSortingOrder(DefaultSortOrder);
        SetVisible(true);
        RemoveAllModifier();

        var scale = Constants.CardSizeScale;
        if (this is TwoValueCard)
            scale *= Constants.TwoValueCardSizeScale;
        cardObj.transform.localScale = scale;
        transform.DOScale(Vector3.one, 0);
        ImageAlpha = 1;
        frontBgTexture = null;
        backBgTexture = null;
        frontBgHide = false;
        var cardMat = cardObj.GetComponent<SpriteRenderer>().material;
        cardMat.SetVector("_ShadowVector", new Vector4(0.9f, 0.9f, 0f, 0f));
        cardMat.SetFloat("_GrayScaleAmount", 0);
        // cardMat.SetFloat("_Alpha", 1);
    }

    public virtual void SetData(CardData cardData, int cardBackId, int betValue = 1)
    {
        CardData = cardData;
        SetPosition(CardData.cm.x, CardData.cm.y, CardData.cm.depth, CardData.cm.angle, CardData.cm.faceUp);
        if (CardData.CardType == CardType.Value && CardData.cm.modifiers != null && CardData.cm.modifiers.Length > 0)
        {
            CreateModifier(CardData.cm.modifiers);
        }
    }

    public void CreateModifier(ModifierModel[] modifiers)
    {
        var mods = transform.GetComponentsInChildren<BaseMod>(true).ToList();
        foreach (var item in mods)
        {
            GameObject.DestroyImmediate(item.gameObject);
        }
        foreach (var mod in modifiers)
        {
            GameObject modObj = null;
            if (mod.modType == ModifierType.Bomb)
            {
                modObj = gameObject.GetComponentInChildren<BombMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.BombMod);
                modObj.GetComponent<BombMod>().Timer = CardData.BombTimer;
            }
            else if (mod.modType == ModifierType.BigBomb)
            {
                modObj = gameObject.GetComponentInChildren<BigBombMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.BigBombMod);
                modObj.GetComponent<BigBombMod>().Timer = CardData.BigBombTimer;
                frontBgTexture = Constants.CardFrontTex_BigBomb;
                backBgTexture = Constants.CardBackTex_BigBomb;
            }
            else if (mod.modType == ModifierType.Rising)
            {
                modObj = gameObject.GetComponentInChildren<RisingMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.RisingMod);
            }
            else if (mod.modType == ModifierType.Lowering)
            {
                modObj = gameObject.GetComponentInChildren<LoweringMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.LoweringMod);
            }
            else if (mod.modType == ModifierType.Water)
            {
                modObj = gameObject.GetComponentInChildren<WaterMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.WaterMod);
            }
            else if (mod.modType == ModifierType.Ice)
            {
                modObj = gameObject.GetComponentInChildren<IceMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.IceMod);
            }
            else if (mod.modType == ModifierType.Lightning && CardData.HasLightning())
            {
                modObj = gameObject.GetComponentInChildren<LightningMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.LightningMod);
                modObj.GetComponent<LightningMod>().SetTimer(CardData.LightningTimer);
                frontBgTexture = Constants.CardFrontTex_Lighting;
                backBgTexture = Constants.CardBackTex_Lighting;
            }
            else if (mod.modType == ModifierType.GreenLeaf)
            {
                modObj = gameObject.GetComponentInChildren<GreenLeafMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.GreenLeafMod);
                frontBgTexture = Constants.CardFrontTex_GreenLeaf;
                backBgTexture = Constants.CardBackTex_GreenLeaf;
            }
            else if (mod.modType == ModifierType.Cloth)
            {
                modObj = gameObject.GetComponentInChildren<ClothMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.ClothMod);
                modObj.GetComponent<ClothMod>().SetState(CardData.IsClothOpen());
            }
            else if (mod.modType == ModifierType.MagicCloth)
            {
                modObj = gameObject.GetComponentInChildren<MagicClothMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.MagicClothMod);
                modObj.GetComponent<MagicClothMod>().SetState(CardData.IsClothOpen());
            }
            else if (mod.modType == ModifierType.SuitRope)
            {
                modObj = gameObject.GetComponentInChildren<SuitRopeMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.SuitRopeMod);
                modObj.GetComponent<SuitRopeMod>().InitSuit(CardData.GetSuitRopeSuits());
            }
            else if (mod.modType == ModifierType.Coin)
            {
                modObj = GameObjManager.Instance.PopGameObject(GameObjType.CoinMod);
            }
            else if (mod.modType == ModifierType.Lizard)
            {
                modObj = gameObject.GetComponentInChildren<LizardMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.LizardMod);
            }
            else if (mod.modType == ModifierType.Task)
            {
                modObj = gameObject.GetComponentInChildren<TaskMod>(true)?.gameObject;
                if (modObj == null)
                    modObj = GameObjManager.Instance.PopGameObject(GameObjType.TaskMod);
            }

            if (modObj != null)
            {
                modObj.transform.SetParent(cardObj.transform);
                modObj.transform.localPosition = Vector3.zero;
                modObj.transform.localScale = Vector3.one;
                modObj.transform.localRotation = Quaternion.identity;
                modObj.SetActive(false);
            }
        }
    }

    public void ShowModifier(bool show)
    {
        var mods = transform.GetComponentsInChildren<BaseMod>(true);
        foreach (var mod in mods)
        {
            if (show)
            {
                switch (mod)
                {
                    case BombMod bombMod:
                        if (CardData.HasBomb())
                        {
                            mod.gameObject.SetActive(true);
                            bombMod.Timer = CardData.BombTimer;
                            mod.Active(true);
                        }
                        break;

                    case BigBombMod bigBombMod:
                        if (CardData.HasBigBomb())
                        {
                            mod.gameObject.SetActive(true);
                            bigBombMod.Timer = CardData.BigBombTimer;
                            if (CardData.BigBombTimer <= 3)
                                TypeEventSystem.Send<BigBombEvent>(new BigBombEvent(true));
                            mod.Active(true);
                        }
                        break;

                    case RisingMod risingMod:
                        mod.gameObject.SetActive(true);
                        mod.Active(true);
                        break;

                    case LoweringMod loweringMod:
                        mod.gameObject.SetActive(true);
                        mod.Active(true);
                        break;

                    case WaterMod waterMod:
                        if (CardData.HasWater())
                        {
                            mod.gameObject.SetActive(true);
                            mod.Active(true);
                        }
                        break;

                    case IceMod iceMod:
                        if (CardData.HasIce())
                        {
                            mod.gameObject.SetActive(true);
                            mod.Active(true);
                        }
                        break;

                    case LightningMod lightningMod:
                        if (CardData.HasLightning())
                        {
                            mod.gameObject.SetActive(true);
                            lightningMod.SetTimer(CardData.LightningTimer);
                            mod.Active(true);
                        }
                        break;

                    case GreenLeafMod greenLeafMod:
                        if (CardData.HasGreenLeaf())
                        {
                            mod.gameObject.SetActive(true);
                            mod.Active(true);
                        }
                        break;

                    case ClothMod clothMod:
                        if (CardData.HasCloth())
                        {
                            mod.gameObject.SetActive(true);
                            clothMod.SetState(CardData.IsClothOpen());
                            mod.Active(true);
                        }
                        break;

                    case MagicClothMod magicClothMod:
                        if (CardData.HasMagicCloth())
                        {
                            mod.gameObject.SetActive(true);
                            magicClothMod.SetState(CardData.IsClothOpen());
                            mod.Active(true);
                        }
                        break;

                    case SuitRopeMod suitRopeMod:
                        if (CardData.HasSuitRope())
                        {
                            mod.gameObject.SetActive(true);
                            suitRopeMod.ResetSuits(CardData.SuitRopeStates);
                            mod.Active(true);
                        }
                        break;

                    case LizardMod lizardMod:
                        if (CardData.HasLizard())
                        {
                            mod.gameObject.SetActive(true);
                            mod.Active(true);
                        }
                        break;

                    case TaskMod taskMod:
                        if (CardData.HasTask())
                        {
                            mod.gameObject.SetActive(true);
                            mod.Active(true);
                            taskMod.ReFreshTaskIcon();
                        }
                        break;
                }
            }
            else
            {
                if (CardData.IsFaceup)
                {
                    mod.PlayDisappearEf();
                }
                mod.gameObject.SetActive(false);
            }
        }
    }

    public void ResetModifier()
    {
        if (CardData.CardType == CardType.Value && CardData.cm.modifiers != null && CardData.cm.modifiers.Length > 0)
        {
            ShowModifier(true);
        }
    }

    protected void PlayAnimation(string animName, Action endCall = null, int layer = 0)
    {
        selfAnimator.enabled = true;
        selfAnimator.Play(animName, layer, 0);
        UniRx.Observable.NextFrame().Subscribe(_ =>
        {
            animationCb = Observable.Timer(TimeSpan.FromSeconds(selfAnimator.GetCurrentAnimatorStateInfo(0).length)).Subscribe(
                _ =>
                {
                    selfAnimator.enabled = false;
                    endCall?.Invoke();
                });
        });
    }

    private void StopAnimation()
    {
        selfAnimator.enabled = false;
        animationCb?.Dispose();
    }


    //购买手牌动画
    internal void DoBuyHandCardsAnim(Vector3Int formPos, Vector3Int toPos, float delay, bool playEffect)
    {
        float time = 0.5f;
        transform.position = formPos;
        Depth = toPos.z;
        //CardAngle = -60;

        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);

        cardObj.transform.localPosition = new Vector3(0, -15, 0);
        cardObj.transform.localScale = Vector3.zero;
        //seq.InsertCallback(delay + 0f / 60, () => {cardObj.transform.localScale = new Vector3(-0.8f,0.8f,0); });
        //seq.Insert(delay+0f / 60, cardObj.transform.DOScale(new Vector3(-0.9f, 0.7f, 0), 12f / 60));
        seq.Insert(delay + 0f / 60, cardObj.transform.DOLocalMoveY(-23, 12f / 60));
        seq.Insert(delay + 0f / 60, transform.DOMoveX(toPos.x, time));


        seq.Insert(delay + 12f / 60, cardObj.transform.DOScale(new Vector3(-0.85f, 0.95f, 0), 16f / 60));
        seq.Insert(delay + 12f / 60, cardObj.transform.DOLocalMoveY(100, 16f / 60));
        seq.Insert(delay + 12f / 60, cardObj.transform.DORotate(new Vector3(0, 0f, -7f), 10f / 60));

        seq.Insert(delay + 22f / 60, cardObj.transform.DORotate(new Vector3(0, 0f, 7f), 9f / 60));
        seq.Insert(delay + 28f / 60, cardObj.transform.DOScale(new Vector3(-1f, 1f, 0), 12f / 60));
        seq.Insert(delay + 28f / 60, cardObj.transform.DOLocalMoveY(0, 12f / 60));

        seq.Insert(delay + 31f / 60, cardObj.transform.DORotate(new Vector3(0, 0f, 0f), 9f / 60));

        seq.Insert(delay + 40f / 60, cardObj.transform.DOScale(new Vector3(-1.05f, 0.95f, 0), 4f / 60));
        seq.Insert(delay + 40f / 60, cardObj.transform.DOLocalMoveY(-3, 4f / 60));


        seq.Insert(delay + 44f / 60, cardObj.transform.DOScale(new Vector3(-1f, 1f, 0), 6f / 60));
        seq.Insert(delay + 44f / 60, cardObj.transform.DOLocalMoveY(0, 6f / 60));

        if (playEffect)
        {
            GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_+5_01.prefab", (obj) =>
            {
                var scene = Camera.main.transform.parent;
                obj.transform.SetParent(scene);
                obj.transform.position = gameObject.transform.position;
                obj.SetActive(true);
            }, true, 3f);
        }

        // seq.AppendInterval(delay);
        // seq.Append(transform.DOMoveX(toPos.x, time));
        // seq.Join(transform.DOMoveY(toPos.y, time).SetEase(Ease.OutQuad));
        // seq.Join(cardObj.transform.DORotate(Vector3.zero, time).SetEase(Ease.OutQuart));
    }

    //手牌初始化动画
    internal void DoHandCardsInitAnim(Vector3Int formPos, Vector3Int toPos, float delay)
    {
        float time = 0.5f;
        transform.position = formPos;
        Depth = toPos.z;
        CardAngle = -60;
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        seq.AppendInterval(delay);
        seq.Append(transform.DOMoveX(toPos.x, time));
        seq.Join(transform.DOMoveY(toPos.y, time).SetEase(Ease.OutQuad));
        seq.Join(cardObj.transform.DORotate(Vector3.zero, time).SetEase(Ease.OutQuart));
    }

    internal float DoFinishRecycleCard(float delay, int idx, int totalIntegral, TweenCallback onComplete)
    {
        float time = 0.3f;
        Sequence seq = DOTween.Sequence();

        seq.SetId(transform);
        seq.AppendInterval(delay);
        seq.AppendCallback(() =>
        {
            SoundPlayer.Instance.PlayNoteRemain(idx + 1);
            // TypeEventSystem.Send<FlyStarTuoWeiFx>(new FlyStarTuoWeiFx(totalIntegral,formPos,toPos,false));
        });
        seq.Append(transform.DOBlendableLocalMoveBy(new Vector3(0, 150, 0), time).SetEase(Ease.OutSine));
        seq.Join(DoAlphaAnim(0, time, Ease.InQuint));
        seq.onComplete += onComplete;
        return seq.Duration();
    }

    public Tween DoAlphaAnim(float alpha = 0f, float duration = 0.8f, Ease ease = Ease.InQuart)
    {
        var baseMod = cardObj.GetComponentInChildren<BaseMod>(true);
        if (duration == 0)
        {
            if (baseMod != null)
            {
                foreach (var _mat in baseMod.GetComponentsInChildren<SpriteRenderer>(true))
                {
                    var _color = _mat.color;
                    _color.a = alpha * 255;
                    _mat.color = _color;
                }
            }
            var mat = cardObj.GetComponent<SpriteRenderer>().material;
            mat.DOFloat(alpha, "_Alpha", 0);
        }
        else
        {
            if (baseMod != null)
            {
                foreach (var mat in baseMod.GetComponentsInChildren<SpriteRenderer>(true))
                    mat.DOColor(Color.clear, alpha * 255);
            }
            return cardObj.GetComponent<SpriteRenderer>().material.DOFloat(alpha, "_Alpha", duration).SetEase(ease);
        }
        return null;
    }

    public void SetVisible(bool vis)
    {
        var baseMod = cardObj.GetComponentInChildren<BaseMod>(true);
        baseMod?.SetAlpha(vis ? 255 : 0);
        cardObj.GetComponent<SpriteRenderer>().material.DOFloat(vis ? 1 : 0, "_Alpha", 0);
    }

    public void ResetVisible()
    {
        cardObj.GetComponent<SpriteRenderer>().material.DOFloat(1, "_Alpha", 0);
    }

    protected float ImageAlpha
    {
        set
        {
            MaterialPropertyBlock block = new MaterialPropertyBlock();
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            renderer.GetPropertyBlock(block);
            block.SetFloat("_SpecAlpha", value);
            renderer.SetPropertyBlock(block);
        }
        get
        {
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            return renderer.material.GetFloat("_SpecAlpha");
        }
    }

    void OnMouseDownEvent()
    {
        // Debug.Log($"=========== >>> OnMouseDownEvent >>> CardValue:{CardModel.value} || CardId:{CardId}");
        TouchCardEvent t = GameObjManager.Instance.PopClass<TouchCardEvent>(true);
        t.Init(CardId);
        TypeEventSystem.Send<TouchCardEvent>(t);
    }

    public void DoErrorCardAnim()
    {
        if (selfAnimator.enabled) return;
        var seq = DOTween.Sequence();
        seq.SetId(transform);
        seq.Append(cardObj.transform.DOBlendableLocalRotateBy(new Vector3(0, 0, 20), 0.05f));
        seq.Append(cardObj.transform.DOBlendableLocalRotateBy(new Vector3(0, 0, -40), 0.05f));
        seq.Append(cardObj.transform.DOBlendableLocalRotateBy(new Vector3(0, 0, 30), 0.05f));
        seq.Append(cardObj.transform.DOBlendableLocalRotateBy(new Vector3(0, 0, -20), 0.05f));
        seq.Append(cardObj.transform.DOBlendableLocalRotateBy(new Vector3(0, 0, 10), 0.05f));

        // PlayAnimation("shake", 0, () =>
        // {
        //     Vector3 toEulerAngle = new Vector3(0, 0, CardData.cm.angle);
        //     cardObj.transform.DOLocalRotate(toEulerAngle, 0.1f).SetEase(Ease.OutSine);
        //     var scale = Constants.CardSizeScale;
        //     if (this is TwoValueCard)
        //         scale *= Constants.TwoValueCardSizeScale;
        //     cardObj.transform.DOScale(scale, 0.1f).SetEase(Ease.OutSine);
        // });
        seq.AppendCallback(() => SoundPlayer.Instance.PlayInvalidMove());
    }

    public void DoHandCardPosMove(Vector3Int newPos)
    {
        Depth = newPos.z;
        transform.DOMove(newPos, 0.3f);
    }

    // public virtual float MoveToOpenCardFromHandCards(Vector3Int pos)
    // {
    //     SoundPlayer.Instance.PlayNormalFlip(); //added
    //     DOTween.Kill(transform, true);
    //     SetSortingOrder(FxSortOrder);
    //     Depth = pos.z;


    // }

    public virtual float MoveToOpenCardFromHandCards(Vector3Int pos)
    {
        SetSortingOrder(FxSortOrder);
        Depth = pos.z;
        return DoTurnCard(pos, true, 0.25f * GameCommon.CardAnimScale);
    }

    public float UndoOpenCardFromHandCards(Vector3Int pos)
    {
        SetSortingOrder(FxSortOrder);
        Depth = pos.z;
        return DoTurnCard(pos, false);
    }

    //游戏开始降落卡牌动画
    public float DoGameStartFallAnim(float delay, float singleTime, float moveTime, int fallIndex)
    {
        IsFaceUp = false;
        bool isLeftHalf = CardData.cm.x <= 0;
        Vector3 formPos = new Vector3(0, 700, CardData.cm.depth);
        Vector3 toPos = new Vector3(CardData.cm.x, CardData.cm.y, CardData.cm.depth);
        float diffAngle = Vector3.Angle(formPos - toPos, formPos);
        Vector3 formEulerAngle = new Vector3(isLeftHalf ? 60 : -60, 60,
            (isLeftHalf ? -1 : 1) * (diffAngle + 30 + CardData.cm.angle));
        Vector3 toEulerAngle = new Vector3(0, 0, CardData.cm.angle);
        transform.position = formPos;
        cardObj.transform.localEulerAngles = formEulerAngle;

        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        float startTime = delay + fallIndex * singleTime;
        //seq.Insert(startTime, transform.DOMoveX(toPos.x, 0.8f).SetEase(Ease.OutQuart));
        //seq.Insert(startTime, transform.DOMoveY(toPos.y, 0.8f).SetEase(Ease.OutQuart));
        seq.Insert(startTime, transform.DOMove(toPos, moveTime).SetEase(Ease.OutQuint));
        seq.Insert(startTime, cardObj.transform.DOLocalRotate(toEulerAngle, moveTime / 3 * 2).SetEase(Ease.OutSine));
        seq.Insert(startTime,
            cardObj.GetComponent<SpriteRenderer>().material
                .DOVector(new Vector4(0.9f, 0.9f, 0.05f, 0.1f), "_ShadowVector", 0));
        seq.Insert(startTime + moveTime / 3,
            cardObj.GetComponent<SpriteRenderer>().material.DOVector(new Vector4(0.9f, 0.9f, 0f, 0f), "_ShadowVector",
                moveTime / 3 * (4 / 5f)));

        return seq.Duration();
    }


    //翻转卡牌动画
    public virtual float DoTurnCard(Vector3 toPos, bool toFaceUp, float halfTime = 0.175f)
    {
        SoundPlayer.Instance.PlayNormalFlip(); //added
        if (BattleDataMgr.Instance.IsHandCard(CardData.id))
        {
            PlayAnimation(toFaceUp ? "flip" : "flipback", () =>
            {
                cardObj.transform.localPosition = Vector3.zero;
                Vector3 toEulerAngle = new Vector3(0, 0, CardData.cm.angle);
                cardObj.transform.DOLocalRotate(toEulerAngle, 0.2f).SetEase(Ease.OutSine);
                IsFaceUp = toFaceUp;
            });
        }
        DOTween.Kill(transform, true);
        bool isOpenCard = false;
        // if (toFaceUp == false) IsFaceUp = false;

        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        Vector3 position = transform.position;
        toPos.z = Depth;
        position.z = Depth;
        Vector3 halfPos = (toPos - position) / 2 + position + new Vector3(0, 10, 0);
        Vector3 halfScale = new Vector3(0, 1.1f, 1);
        Vector3 halfBlendableAngle = new Vector3(0, 30, -30);
        if (CardData.CardType == CardType.TwoValue)
            halfScale *= Constants.TwoValueCardSizeScale;
        seq.Append(cardObj.transform.DOScale(halfScale * Constants.CardSizeScale, halfTime));
        seq.Join(transform.DOMove(halfPos, halfTime));
        if (isOpenCard)
            seq.Join(cardObj.transform.DOBlendableLocalRotateBy(halfBlendableAngle, halfTime));

        Vector3 scale = (toFaceUp ? Vector3.one : faceDownVec) * Constants.CardSizeScale;
        if (CardData.CardType == CardType.TwoValue)
            scale *= Constants.TwoValueCardSizeScale;
        seq.Append(cardObj.transform.DOScale(scale, halfTime));
        seq.Join(transform.DOMove(toPos, 1 / 3f));
        if (isOpenCard)
            seq.Join(cardObj.transform.DORotate(new Vector3(0, 0, CardData.cm.angle), halfTime));
        //seq.Join(transform.DOBlendableLocalRotateBy(-halfBlendableAngle, halfTime));

        seq.Insert(0,
            cardObj.GetComponent<SpriteRenderer>().material
                .DOVector(new Vector4(0.9f, 0.9f, 0.05f, 0), "_ShadowVector", 0));
        seq.Insert(halfTime / 2,
            cardObj.GetComponent<SpriteRenderer>().material.DOVector(new Vector4(0.9f, 0.9f, 0f, 0f), "_ShadowVector",
                halfTime / 2 * (4 / 5f)));

        seq.OnComplete(() =>
        {
            SetSortingOrder(DefaultSortOrder);
            TypeEventSystem.Send<DoTurnCardEvent>();
            if (toFaceUp == true) IsFaceUp = true;
            ShowModifier(toFaceUp);
        });
        return seq.Duration();
    }

    public void SetSortingOrder(int newSortingOrder)
    {
        // cardRender.sortingOrder = newSortingOrder;
        GetComponent<SortingGroup>().sortingOrder = newSortingOrder;
    }
    
    public void SetSortingLayer(string layerName)
    {
        // cardRender.sortingOrder = newSortingOrder;
        GetComponent<SortingGroup>().sortingLayerName = layerName;
    }

    public virtual void SetFront(int bet = 1)
    {
    }

    public virtual void SetBack(int cardBackId, int betValue)
    {

    }

    //连胜卡背
    public void SetStreakBack()
    {
        _ = SpriteUtils.GetTextureAsyncByPath(Constants.CardBackTex_Win, (texture2D) =>
        {
            MaterialPropertyBlock block = new MaterialPropertyBlock();
            var renderer = cardObj.GetComponent<SpriteRenderer>();
            renderer.GetPropertyBlock(block);
            block.SetTexture("_BackTex", texture2D);
            renderer.SetPropertyBlock(block);
        });
    }

    void SetCanTouch(bool canTouch)
    {
        cardObj.GetComponent<Collider2D>().enabled = canTouch;
    }

    public CardType GetCardType()
    {
        return CardData.CardType;
    }

    //回退抽卡堆操作
    public float UndoOpenCardFromDesktop()
    {
        var time = 0.7f;
        var pos = new Vector3(CardData.cm.x, CardData.cm.y, CardData.cm.depth);
        CardAngle = CardData.cm.angle;
        var scale = Constants.CardSizeScale;
        if (this is TwoValueCard)
            scale *= Constants.TwoValueCardSizeScale;
        cardObj.transform.localScale = scale;
        transform.DOMove(pos, time).SetEase(Ease.OutCubic);
        return time;
    }

    public virtual float FlopCard(bool faceup = true)
    {
        return DoFaceUpAnim(faceup);
    }

    public virtual float DoFaceUpAnim(bool toFaceUp, float time = 0.25f)
    {
        if (IsFaceUp == toFaceUp) return 0;
        _isFaceUp = toFaceUp;
        DoAlphaAnim(1, 0);
        DOTween.Kill(transform, true);

        float halfTime = time / 2;
        DoTurnCard(transform.position, toFaceUp, halfTime);
        //PlayShowEf();
        return time;
    }


    public virtual void PlayDisappearEf()
    {

    }

    public virtual void PlayShowEf()
    {

    }

    public void PlayDisappearSound()
    {
        string assetPath = "";
        if (CardData.HasBomb())
        {
            var bombMod = cardObj.GetComponentInChildren<BombMod>(false);
            if (bombMod != null)
            {
                assetPath = "Bomb_Remove";
            }
        }
        else if (CardData.CardType == CardType.Monochrome)
        {
            assetPath = "MonoChrome_Remove";
        }
        else if (CardData.HasBigBomb())
        {
            assetPath = "NewBomb_Remove";
        }
        else if (CardData.HasLightning())
        {
            assetPath = "Lightning_Remove";
        }
        else if (CardData.CardType == CardType.Joker)
        {
            assetPath = "Wild_Remove";
        }
        else if (CardData.HasCloth())
        {
            assetPath = "Cloth_Remove";
        }

        if (assetPath != "")
        {
            SoundPlayer.Instance.PlayMainSound(assetPath);
        }
    }

    public void PlayDisappearGreanLeafEf()
    {
        GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_GreenLeafMod_01.prefab", (obj) =>
        {
            var scene = Camera.main.transform.parent;
            obj.transform.SetParent(scene);
            obj.transform.position = gameObject.transform.position;
            obj.SetActive(true);
        }, true, 3f);
    }

    private void ResetOrignPos()
    {
        if (selfAnimator.enabled)
        {
            StopAnimation();
            Vector3 toEulerAngle = new Vector3(0, 0, CardData.cm.angle);
            cardObj.transform.DOLocalRotate(toEulerAngle, 0f).SetEase(Ease.OutSine);
            var scale = Constants.CardSizeScale;
            if (this is TwoValueCard)
                scale *= Constants.TwoValueCardSizeScale;
            cardObj.transform.localPosition = Vector3.zero;
            cardObj.transform.DOScale(scale, 0f).SetEase(Ease.OutSine);
        }
    }

    //消除桌牌动画（桌牌下落到手牌位置）
    public virtual float MoveToOpenCardFromDesktop(Vector3 pos)
    {
        ResetOrignPos();
        cardObj.transform.DOKill(true);
        SetCanTouch(false);
        Vector3 position = transform.position;
        position.z = pos.z;
        transform.position = position;
        Vector3 diffPos = pos - position;
        float time = Mathf.Clamp(diffPos.magnitude / 380f, 0.4f, 0.8f * GameCommon.CardDropScale);

        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        cardObj.transform.localRotation = Quaternion.identity;
        cardObj.transform.DOScale(Constants.CardSizeScale, time);

        //横向移动
        seq.Append(transform.DOMoveX(pos.x, time).SetEase(Ease.OutSine));

        //竖向移动
        seq.Insert(0f, transform.DOMoveY(position.y + 200, time / 5 * 2));
        seq.Insert(time / 5 * 2, transform.DOMoveY(pos.y, time / 5 * 3).SetEase(Ease.InQuad));

        //空中缩放动画
        seq.Insert(0f, transform.DOScale(Vector3.one * 1.4f, time / 3f * 2));
        seq.Insert(time / 3f * 2, transform.DOScale(Vector3.one, time / 3f));

        //翻转动画
        //seq.Insert(0f, cardObj.transform.DOLocalRotate(new Vector3(0, 0, diffPos.x > 0 ? -330 : 330), time / 4 * 3, RotateMode.FastBeyond360).SetEase(Ease.OutQuad));
        //seq.Insert(time / 4 * 3, cardObj.transform.DOLocalRotate(Vector3.zero, time / 4));
        seq.Insert(0f,
            cardObj.transform
                .DOLocalRotate(new Vector3(0, 0, diffPos.x > 0 ? -360 : 360), time, RotateMode.FastBeyond360)
                .SetEase(Ease.OutQuad));
        seq.Insert(0f,
            cardObj.GetComponent<SpriteRenderer>().material
                .DOVector(new Vector4(0.9f, 0.9f, 0.05f, 0.1f), "_ShadowVector", 0));
        seq.Insert(0f,
            cardObj.GetComponent<SpriteRenderer>().material
                .DOVector(new Vector4(0.9f, 0.9f, 0f, 0f), "_ShadowVector", time));
        seq.onComplete += () =>
        {
            SetCanTouch(true);
            transform.position = pos;
            cardObj.transform.localRotation = Quaternion.identity;
        };

        //return time;
        return seq.Duration();
    }

    //通过拉绳 消除桌牌动画（桌牌下落到手牌位置）
    public virtual float MoveToOpenCardByLinkRope(Vector3 pos)
    {
        ResetOrignPos();
        cardObj.transform.DOKill(true);
        SetCanTouch(false);
        Vector3 position = transform.position;
        position.z = pos.z;
        transform.position = position;
        Vector3 diffPos = pos - position;
        float time = Mathf.Clamp(diffPos.magnitude / 380f, 0.4f, 0.8f * GameCommon.CardDropScale);

        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        cardObj.transform.localRotation = Quaternion.identity;
        cardObj.transform.DOScale(Constants.CardSizeScale, time);

        float delay = 0.5f;
        seq.AppendInterval(delay); //等待前面一张牌落地

        //横向移动
        seq.Append(transform.DOMoveX(pos.x, time).SetEase(Ease.OutSine));

        //竖向移动
        seq.Insert(delay + 0f, transform.DOMoveY(position.y + 200, time / 5 * 2));
        seq.Insert(delay + time / 5 * 2, transform.DOMoveY(pos.y, time / 5 * 3).SetEase(Ease.InQuad));

        //空中缩放动画
        seq.Insert(delay + 0f, transform.DOScale(Vector3.one * 1.2f, time / 2));
        seq.Insert(delay + time / 2, transform.DOScale(Vector3.one, time / 2));

        //翻转动画
        //seq.Insert(0f, cardObj.transform.DOLocalRotate(new Vector3(0, 0, diffPos.x > 0 ? -330 : 330), time / 4 * 3, RotateMode.FastBeyond360).SetEase(Ease.OutQuad));
        //seq.Insert(time / 4 * 3, cardObj.transform.DOLocalRotate(Vector3.zero, time / 4));
        seq.Insert(delay + 0f,
            cardObj.transform
                .DOLocalRotate(new Vector3(0, 0, diffPos.x > 0 ? -360 : 360), time, RotateMode.FastBeyond360)
                .SetEase(Ease.OutQuad));
        seq.Insert(delay + 0f,
            cardObj.GetComponent<SpriteRenderer>().material
                .DOVector(new Vector4(0.9f, 0.9f, 0.05f, 0.1f), "_ShadowVector", 0));
        seq.Insert(delay + 0f,
            cardObj.GetComponent<SpriteRenderer>().material
                .DOVector(new Vector4(0.9f, 0.9f, 0f, 0f), "_ShadowVector", time));
        seq.onComplete += () =>
        {
            SetCanTouch(true);
            transform.position = pos;
            cardObj.transform.localRotation = Quaternion.identity;
        };

        //return time;
        return seq.Duration();
    }

    public void DoMissAnim()
    {
        if (selfAnimator.enabled) return;
        PlayAnimation("shake", () =>
        {
            Vector3 toEulerAngle = new Vector3(0, 0, CardData.cm.angle);
            cardObj.transform.DOLocalRotate(toEulerAngle, 0.1f).SetEase(Ease.OutSine);
            var scale = Constants.CardSizeScale;
            if (this is TwoValueCard)
                scale *= Constants.TwoValueCardSizeScale;
            cardObj.transform.DOScale(scale, 0.1f).SetEase(Ease.OutSine);
        });
        SoundPlayer.Instance.PlayMainSound("ani_shake_01");
        // SoundPlayer.Instance.PlayGuide();
    }

    public void DoScaleAnim()
    {
        Sequence scaleSeq = DOTween.Sequence();
        scaleSeq.SetId(transform);
        scaleSeq.Insert(0f, transform.DOScaleX(1.2f, 0.1f));
        scaleSeq.Insert(0f, transform.DOScaleY(1.2f, 0.1f));
        scaleSeq.Insert(0.1f, transform.DOScaleX(0.9f, 0.1f));
        scaleSeq.Insert(0.1f, transform.DOScaleY(0.9f, 0.1f));
        scaleSeq.Insert(0.2f, transform.DOScaleX(1.15f, 0.1f));
        scaleSeq.Insert(0.2f, transform.DOScaleY(1.15f, 0.1f));
        scaleSeq.Insert(0.3f, transform.DOScaleX(0.95f, 0.1f));
        scaleSeq.Insert(0.3f, transform.DOScaleY(0.95f, 0.1f));
        scaleSeq.Insert(0.4f, transform.DOScaleX(1.1f, 0.1f));
        scaleSeq.Insert(0.4f, transform.DOScaleY(1.1f, 0.1f));
        scaleSeq.Insert(0.5f, transform.DOScaleX(1f, 0.1f));
        scaleSeq.Insert(0.5f, transform.DOScaleY(1f, 0.1f));
        SoundPlayer.Instance.PlayGuide();
    }

    public virtual void OnDisable()
    {
        DestroyGreanLeafEf();
    }

    public void DestroyGreanLeafEf()
    {
        if (greenLeafObj != null)
        {
            Destroy(greenLeafObj);
            greenLeafObj = null;
        }
    }

    public void PlayGreanLeafEf(int type)
    {
        if (type == 1)//瓢虫起飞的那张牌
        {
            GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_yezi_GreenLeafMod_02.prefab", (obj) =>
            {
                var scene = Camera.main.transform.parent;
                obj.transform.SetParent(scene);
                obj.transform.position = gameObject.transform.position;
                obj.SetActive(true);
            }, true, 3f);
            if (greenLeafObj != null)
            {
                Destroy(greenLeafObj);
                greenLeafObj = null;
            }
        }
        else//瓢虫停在的那张牌
        {
            if (greenLeafObj != null)
            {
                greenLeafObj.SetActive(true);
            }
            else
            {
                GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_yezi_GreenLeafMod_01.prefab", (obj) =>
                {
                    var scene = Camera.main.transform.parent;
                    obj.transform.SetParent(scene);
                    obj.transform.position = gameObject.transform.position;
                    obj.SetActive(true);
                    greenLeafObj = obj;
                });
            }
            GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_yezi_GreenLeafMod_02.prefab", (obj) =>
            {
                var scene = Camera.main.transform.parent;
                obj.transform.SetParent(scene);
                obj.transform.position = gameObject.transform.position;
                obj.SetActive(true);
            }, true, 3f);
        }

    }

    //被炸动画
    public float DoBeBoomAnim(Vector3 boomCenter)
    {
        // SetCardPosType(CardPosType.None);
        float closeTime = 0.5f;
        float flyAwayTime = 1f;
        SetSortingOrder(FxSortOrder);
        Vector3 tempPos = cardObj.transform.localEulerAngles;
        Vector3 diffDir = (transform.position - boomCenter).normalized;
        if (diffDir.magnitude < 0.1f) diffDir = Vector3.up;
        Vector3 randomSpeed = new Vector3(Random.Range(500, 1000), (diffDir.y > 0 ? 1 : -1) * Random.Range(1000, 1500),
            (diffDir.x > 0 ? 1 : -1) * Random.Range(500, 1000));
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        seq.Append(transform.DOMove(boomCenter + diffDir * 50, closeTime).SetEase(Ease.InQuart));
        seq.Append(transform.DOBlendableMoveBy(diffDir * 1200, flyAwayTime));
        seq.Join(
            DOTween.To(
                () => tempPos,
                (eulerAngle) =>
                {
                    tempPos = eulerAngle;
                    cardObj.transform.localEulerAngles = eulerAngle;
                },
                randomSpeed,
                flyAwayTime
            )
        );
        seq.OnComplete(() =>
        {
            SetSortingOrder(DefaultSortOrder);
            ShowModifier(false);
            gameObject.SetActive(false);
        });
        return seq.Duration();
    }

    public float DoFlyOutByWindmill(float delay)
    {
        SetSortingOrder(FxSortOrder);
        float time = 1.5f;
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        seq.AppendInterval(delay);
        seq.AppendCallback(() =>
        {
            transform.DORotate(new Vector3(0, 360 * 4, 0), time, RotateMode.FastBeyond360).SetEase(Ease.Linear);
            transform.DOMoveX(transform.position.x + 3000, time).SetEase(Ease.Linear).OnComplete(() =>
            {
                SetSortingOrder(DefaultSortOrder);
            });
        });
        return time;
    }

    public float UndoFlyOutByWindmill()
    {
        SetSortingOrder(FxSortOrder);
        gameObject.SetActive(true);
        float time = 1.5f;
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        seq.AppendCallback(() =>
        {
            transform.DORotate(new Vector3(0, 360 * 4, 0), time, RotateMode.FastBeyond360).SetEase(Ease.Linear);
            transform.DOMove(new Vector3(CardData.cm.x, CardData.cm.y, CardData.cm.depth), time).SetEase(Ease.Linear).OnComplete(() =>
            {
                SetSortingOrder(DefaultSortOrder);
            });
        });
        return time;
    }

    public float UndoCollectedCard()
    {
        gameObject.SetActive(true);
        transform.DOScale(Vector3.one, 0.2f);
        DoAlphaAnim(1, 0.2f, Ease.Linear);
        return 0.1f;
    }

    public float UndoBlowAwayCard()
    {
        gameObject.SetActive(true);
        var pos = new Vector3(CardData.cm.x, CardData.cm.y, CardData.cm.depth);
        CardAngle = CardData.cm.angle;
        var scale = Constants.CardSizeScale;
        if (this is TwoValueCard)
            scale *= Constants.TwoValueCardSizeScale;
        cardObj.transform.localScale = scale;
        transform.localScale = Vector3.one;
        transform.position = pos;
        DoAlphaAnim(1, 0.2f, Ease.Linear);
        ShowModifier(true);
        if (this is RudderCard)
            (this as RudderCard)?.SetFront();
        return 0.1f;
    }

    public float UndoKeyLockCard()
    {
        gameObject.SetActive(true);
        var pos = new Vector3(CardData.cm.x, CardData.cm.y, CardData.cm.depth);
        CardAngle = CardData.cm.angle;
        var scale = Constants.CardSizeScale;
        cardObj.transform.localScale = scale;
        transform.localScale = Vector3.one;
        transform.position = pos;
        DoAlphaAnim(1, 0.2f, Ease.Linear);
        return 0.1f;
    }

    public float UndoBombCards(Vector3 bombPos)
    {
        float duration = 0.5f;
        DoAlphaAnim(0, duration, Ease.Linear);
        transform.DOMove(bombPos, duration).OnComplete(() =>
        {
            transform.gameObject.SetActive(false);
        });
        return 0.1f;
    }

    public float DoBeTargetMoveToPair(Vector3 pairCard)
    {
        return 0;
    }

    public float DoBeMonkeyBananaAnim(Vector3 targetCard, Vector3 pairCard)
    {
        float flyAwayTime = 1f;
        Vector3 diffDir;
        Vector3 tempPos = cardObj.transform.localEulerAngles;
        Sequence seq = DOTween.Sequence();
        bool isCenterCard = (targetCard == transform.position);
        if (!isCenterCard)
        {
            if (targetCard.x > pairCard.x)
            {
                diffDir = (Vector3.up + Vector3.left);
            }
            else
            {
                diffDir = (Vector3.up + Vector3.right);
            }
        }
        else
        {
            if (targetCard.x > pairCard.x)
            {
                diffDir = (Vector3.up + Vector3.right);
            }
            else
            {
                diffDir = (Vector3.up + Vector3.left);
            }
        }


        Vector3 randomSpeed = new Vector3(Random.Range(500, 1000), (diffDir.y > 0 ? 1 : -1) * Random.Range(1000, 1500),
            (diffDir.x > 0 ? 1 : -1) * Random.Range(500, 1000));
        seq.SetId(transform);
        seq.Append(transform.DOBlendableMoveBy(diffDir * 1200, flyAwayTime));
        seq.Join(
            DOTween.To(
                () => tempPos,
                (eulerAngle) =>
                {
                    tempPos = eulerAngle;
                    cardObj.transform.localEulerAngles = eulerAngle;
                },
                randomSpeed,
                flyAwayTime
            )
        );
        seq.OnComplete(() =>
        {
            ShowModifier(false);
            gameObject.SetActive(false);
        });
        return seq.Duration();
    }

    internal float DoBeZapped()
    {
        IEnumerator PlayAnim()
        {
            GameObject showFx = null; //Instantiate(GlobalRes.Load<GameObject>(Constants.baoFx1Str));
            _ = GlobalRes.DynamicLoadPrefab(Constants.baoFx1Str, (obj) => { showFx = obj; });
            while (showFx == null)
            {
                yield return null;
            }
            SoundPlayer.Instance.PlayZap();

            float time = 0.8f;
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            SetSortingOrder(FxSortOrder);
            showFx.transform.position = transform.position;

            var position = transform.position;

            seq.Insert(0f, transform.DOMoveY(position.y + 200, time / 5 * 2));
            seq.Insert(time / 5 * 2, transform.DOMoveY(-700, time / 5 * 3).SetEase(Ease.InQuad));

            // seq.Insert(0f, transform.DOScale(Vector3.one * 1.2f, time / 2));
            // seq.Insert(time / 2, transform.DOScale(Vector3.one, time / 2));

            seq.Insert(0f,
                cardObj.transform.DOLocalRotate(new Vector3(0, 0, 360), time, RotateMode.FastBeyond360)
                    .SetEase(Ease.OutQuad));
            seq.Insert(0f,
                cardObj.GetComponent<SpriteRenderer>().material
                    .DOVector(new Vector4(0.9f, 0.9f, 0.1f, 0.1f), "_ShadowVector", time / 2));
            seq.Insert(time / 2,
                cardObj.GetComponent<SpriteRenderer>().material
                    .DOVector(new Vector4(0.9f, 0.9f, 0f, 0f), "_ShadowVector", time / 2));

            seq.OnComplete(() =>
            {
                SetSortingOrder(DefaultSortOrder);
                Destroy(showFx);
                ShowModifier(false);
                gameObject.SetActive(false);
                // GlobalRes.Release<GameObject>(Constants.baoFx1Str);
            });
        }

        StopCoroutine(PlayAnim());
        StartCoroutine(PlayAnim());

        return 1.6f; //seq.Duration();
    }


    //丰收牌加牌动画
    internal Sequence DoThreeAnim(Vector3 threeCardPos, float delay, Vector3 formPos, Vector3Int toPos)
    {
        transform.DOKill();
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        GameObject fxGo = null;
        formPos.z = toPos.z;
        bool isLeft = formPos.x < toPos.x;
        // SetSortingOrder(FxSortOrder);
        transform.position = threeCardPos;
        seq.AppendInterval(delay);
        seq.AppendCallback(() =>
        {
            SetVisible(true);
            _ = GlobalRes.DynamicLoadPrefab(Constants.threeFxPrefabStr, (obj) =>
            {
                fxGo = obj;
                fxGo.transform.position = formPos;
            });
        });
        SoundPlayer.Instance.PlayThreeIn();
        Vector3 controlPos = formPos + new Vector3(toPos.x - 600, (formPos.y - toPos.y) / 2);
        Vector3[] pathPosArray = BezierUtils.GetBeizerList(formPos, controlPos, toPos, 20);

        seq.Join(transform.DOPath(pathPosArray, 0.8f, PathType.CatmullRom, gizmoColor: Color.red).SetEase(Ease.InOutSine));
        seq.Join(cardObj.transform.DORotate(new Vector3(0, 0, isLeft ? -360 : 360), 0.8f, RotateMode.FastBeyond360)
            .SetEase(Ease.InOutSine));

        Observable.Timer(TimeSpan.FromSeconds(3f)).Subscribe(_ =>
        {
            Destroy(fxGo);
            // GlobalRes.Release<GameObject>(Constants.threeFxPrefabStr);
        });

        return seq;
    }


    //Combo获得的卡牌动画
    internal float DoComboAddCardAnim(Vector3 formPos, Vector3Int toPos, float timeDelay, float flyDelay)
    {
        transform.DOKill(true);
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        formPos.z = toPos.z;
        var newToPos = toPos + new Vector3(0, 300, 0);
        Vector3 diffPos = newToPos - formPos;
        SetCanTouch(false);
        // SetSortingOrder(FxSortOrder);
        transform.position = formPos;
        cardObj.transform.DORotate(new Vector3(0, 0, -20), 0, RotateMode.FastBeyond360);
        transform.localScale = new Vector3(0.4f, 0.4f, 1);
        var moveTime = 1f;
        var moveTime2 = 0.5f;
        var delay = timeDelay + flyDelay;
        delay = Math.Max(delay, 0.1f);
        seq.AppendInterval(delay);
        seq.AppendCallback(() =>
        {
            SetVisible(true);
            cardObj.transform.DORotate(new Vector3(0, 0, 720), moveTime, RotateMode.FastBeyond360).SetEase(Ease.InOutQuad);
            Vector3 controlPos = newToPos + new Vector3(800, -300);
            Vector3[] pathPosArray = BezierUtils.GetBeizerList(formPos, controlPos, newToPos, 20);
            transform.DOPath(pathPosArray, moveTime, PathType.CatmullRom, gizmoColor: Color.red).SetEase(Ease.InOutQuad);
            transform.DOScale(Vector3.one * 1.2f, moveTime).SetEase(Ease.OutBack);
            cardObj.GetComponent<SpriteRenderer>().material.DOVector(new Vector4(0.9f, 0.9f, 0.1f, 0.1f), "_ShadowVector", moveTime / 2);
            cardObj.GetComponent<SpriteRenderer>().material.DOVector(new Vector4(0.9f, 0.9f, 0f, 0f), "_ShadowVector", moveTime / 2);
            SoundPlayer.Instance.PlayComboFlycard();
        });
        seq.AppendInterval(moveTime);
        seq.AppendCallback(() =>
        {
            transform.DOMove(toPos, moveTime2).SetEase(Ease.OutQuart);
            transform.DOScale(Vector3.one, moveTime2).SetEase(Ease.OutQuart);
        });

        // seq.InsertCallback(timeDelay + flyDelay + 0.8f, () => SetSortingOrder(DefaultSortOrder));
        seq.OnComplete(() =>
        {
            transform.localScale = Vector3.one;
            cardObj.transform.localRotation = Quaternion.identity;
            SetCanTouch(true);
        });
        var duration = seq.Duration();
        seq.Play();
        return duration;
    }

    //兔子连胜加牌动画
    internal float DoRabitAddHandCard()
    {
        transform.DOKill();
        GameUtils.LogError("11111111111111111");

        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);

        return seq.Duration();
    }

    //局前道具加牌动画
    internal float DoItemAddHandCard(Vector3 formPos, Vector3Int toPos)
    {
        transform.DOKill();
        transform.gameObject.SetActive(true);
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        formPos.z = toPos.z;
        bool isLeft = formPos.x < toPos.x;
        // SetSortingOrder(FxSortOrder);
        transform.position = formPos;
        seq.AppendCallback(() =>
        {
            SetVisible(true);
        });
        Vector3 controlPos = formPos + new Vector3(toPos.x - 600, (formPos.y - toPos.y) / 2);
        Vector3[] pathPosArray = BezierUtils.GetBeizerList(formPos, controlPos, toPos, 20);

        seq.Join(transform.DOPath(pathPosArray, 0.8f, PathType.CatmullRom, gizmoColor: Color.red).SetEase(Ease.InOutSine));
        seq.Join(cardObj.transform.DORotate(new Vector3(0, 0, isLeft ? -360 : 360), 0.8f, RotateMode.FastBeyond360)
            .SetEase(Ease.InOutSine));
        seq.OnComplete(() =>
        {
            // Destroy(fxGo);
            // GlobalRes.Release<GameObject>(Constants.threeFxPrefabStr);
            // SetSortingOrder(DefaultSortOrder);
        });


        return seq.Duration();
    }

    public void MoveInHandCards(Vector3Int toPos, float time)
    {
        if (!transform.gameObject.activeSelf)
            return;
        transform.DOLocalMove(toPos, time);
    }


    public void RemoveAllModifier()
    {
        var bombMod = cardObj.GetComponentInChildren<BombMod>(true);
        if (bombMod != null)
        {
            GameObjManager.Instance.PushGameObject(bombMod.gameObject);
        }

        var bigBombMod = cardObj.GetComponentInChildren<BigBombMod>(true);
        if (bigBombMod != null)
        {
            GameObjManager.Instance.PushGameObject(bigBombMod.gameObject);
        }

        var risingMod = cardObj.GetComponentInChildren<RisingMod>(true);
        if (risingMod != null)
        {
            GameObjManager.Instance.PushGameObject(risingMod.gameObject);
        }

        var loweringMod = cardObj.GetComponentInChildren<LoweringMod>(true);
        if (loweringMod != null)
        {
            GameObjManager.Instance.PushGameObject(loweringMod.gameObject);
        }

        var waterMod = cardObj.GetComponentInChildren<WaterMod>(true);
        if (waterMod != null)
        {
            GameObjManager.Instance.PushGameObject(waterMod.gameObject);
        }

        var iceMod = cardObj.GetComponentInChildren<IceMod>(true);
        if (iceMod != null)
        {
            GameObjManager.Instance.PushGameObject(iceMod.gameObject);
        }

        var lightningMod = gameObject.GetComponentInChildren<LightningMod>(true);
        if (lightningMod != null)
        {
            GameObjManager.Instance.PushGameObject(lightningMod.gameObject);
        }

        var greenLeafMod = cardObj.GetComponentInChildren<GreenLeafMod>(true);
        if (greenLeafMod != null)
        {
            GameObjManager.Instance.PushGameObject(greenLeafMod.gameObject);
        }

        var clothMod = cardObj.GetComponentInChildren<ClothMod>(true);
        if (clothMod != null)
        {
            GameObjManager.Instance.PushGameObject(clothMod.gameObject);
        }

        var magicClothMod = cardObj.GetComponentInChildren<MagicClothMod>(true);
        if (magicClothMod != null)
        {
            GameObjManager.Instance.PushGameObject(magicClothMod.gameObject);
        }

        var ropeMod = cardObj.GetComponentInChildren<SuitRopeMod>(true);
        if (ropeMod != null)
        {
            GameObjManager.Instance.PushGameObject(ropeMod.gameObject);
        }

        var coinMod = cardObj.GetComponentInChildren<CoinMod>(true);
        if (coinMod != null)
        {
            GameObjManager.Instance.PushGameObject(coinMod.gameObject);
        }

        var lizardMod = cardObj.GetComponentInChildren<LizardMod>(true);
        if (lizardMod != null)
        {
            GameObjManager.Instance.PushGameObject(lizardMod.gameObject);
        }
    }

    public void UpdateBomb(int timer)
    {
        var bombMod = cardObj.GetComponentInChildren<BombMod>(true);
        if (bombMod != null)
        {
            bombMod.Timer = timer;
            SoundPlayer.Instance.PlayMainSound("ani_countchange");
        }
    }

    public void UpdateBigBomb(int timer)
    {
        var bigBombMod = cardObj.GetComponentInChildren<BigBombMod>(true);
        if (bigBombMod != null)
        {
            bigBombMod.Timer = timer;
        }
    }

    //大爆炸触发动画
    internal float DoTriggerBigBombCard()
    {
        SetSortingOrder(FxSortOrder);

        IEnumerator PlayAnim()
        {
            GameObject bombFx = null; //Instantiate(GlobalRes.Load<GameObject>(Constants.bombFxStr));
            _ = GlobalRes.DynamicLoadPrefab(Constants.bombFxStr, (obj) => { bombFx = obj; });
            while (bombFx == null)
            {
                yield return null;
            }
            SoundPlayer.Instance.PlayMainSound("zhadan_bao_tx_01");
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            bombFx.SetActive(false);
            bombFx.transform.position = transform.position;
            seq.Append(transform.DOScale(Vector3.one * 1.2f, 0.2f).SetEase(Ease.OutQuart));
            //seq.Append(transform.DOScale(Vector3.one * 0.5f, time));
            seq.Append(DoAlphaAnim(0, 0.5f));
            seq.InsertCallback(0.5f, () =>
            {
                SetSortingOrder(DefaultSortOrder);
                //SoundPlayer.Instance.PlayBomb();
                bombFx.gameObject.SetActive(true);
                Destroy(bombFx, 2);
                // GlobalRes.Release<GameObject>(Constants.bombFxStr, 2);
            });
            seq.OnComplete(() =>
            {
                ShowModifier(false);
                gameObject.SetActive(false);
            });
        }

        StopCoroutine(PlayAnim());
        StartCoroutine(PlayAnim());
        return 2.7f; //seq.Duration();
    }

    //定时炸弹爆炸触发动画
    internal void DoTriggerBombCard(Vector3[] poses, float duration)
    {
        SetSortingOrder(FxSortOrder);
        // SoundPlayer.Instance.ReleaseViceSound("fx_huoguang");
        // var bombMod = transform.GetComponentInChildren<BombMod>(true);
        var bombMod = (BombMod)transform.GetComponentInChildren(typeof(BombMod), true);
        bombMod.FlyFire(poses, duration);
        Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_ =>
        {
            SetSortingOrder(DefaultSortOrder);
            ShowModifier(false);
        }).AddTo(this);
    }


    internal void DoShowBombCardAnim()
    {
        PlayAnimation("ani_FireCracker_01", () =>
        {
            Vector3 pos = Vector3.zero;
            var scale = Constants.CardSizeScale;
            Vector3 toEulerAngle = new Vector3(0, 0, CardData.cm.angle);

            cardObj.transform.localPosition = pos;
            cardObj.transform.localScale = scale;
            cardObj.transform.DOLocalRotate(toEulerAngle, 0f).SetEase(Ease.OutSine);
        });
        //"ani_FireCracker_01"
    }

    //连胜获得的卡牌 动画 
    public void DoWinStreakToHandCardsAnim(Vector3 pos)
    {
        SoundPlayer.Instance.PlayWinStreakFlyCard();
        cardObj.transform.DOKill(true);
        SetCanTouch(false);
        Vector3 position = transform.position;
        position.z = pos.z;
        transform.position = position;
        Vector3 diffPos = pos - position;
        float time = Mathf.Clamp(diffPos.magnitude / 380f, 0.4f, 0.8f);
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        cardObj.transform.localRotation = Quaternion.identity;

        //横向移动
        seq.Append(transform.DOMoveX(pos.x, time).SetEase(Ease.OutSine));

        //竖向移动
        seq.Insert(0f, transform.DOMoveY(position.y + 200, time / 5 * 2));
        seq.Insert(time / 5 * 2, transform.DOMoveY(pos.y, time / 5 * 3).SetEase(Ease.InQuad));

        //空中缩放动画
        seq.Insert(0f, transform.DOScale(Vector3.one * 1.2f, time / 2));
        seq.Insert(time / 2, transform.DOScale(Vector3.one, time / 2));

        //翻转动画
        //seq.Insert(0f, cardObj.transform.DOLocalRotate(new Vector3(0, 0, diffPos.x > 0 ? -330 : 330), time / 4 * 3, RotateMode.FastBeyond360).SetEase(Ease.OutQuad));
        //seq.Insert(time / 4 * 3, cardObj.transform.DOLocalRotate(Vector3.zero, time / 4));
        seq.Insert(0f,
            cardObj.transform
                .DOLocalRotate(new Vector3(0, 0, diffPos.x > 0 ? -360 : 360), time, RotateMode.FastBeyond360)
                .SetEase(Ease.OutQuad));
        seq.Insert(0f,
            cardObj.GetComponent<SpriteRenderer>().material
                .DOVector(new Vector4(0.9f, 0.9f, 0.05f, 0.1f), "_ShadowVector", 0));
        seq.Insert(0f,
            cardObj.GetComponent<SpriteRenderer>().material
                .DOVector(new Vector4(0.9f, 0.9f, 0f, 0f), "_ShadowVector", time));
        seq.onComplete += () =>
        {
            SetCanTouch(true);
            transform.position = pos;
            cardObj.transform.localRotation = Quaternion.identity;
        };
    }

    internal float DoItemEliminate(float delayTime, bool remove = true)
    {
        IEnumerator PlayAnim(float delayTime)
        {
            // SetSortingOrder(FxSortOrder);
            GameObject cardChipFx = null; //Instantiate(GlobalRes.Load<GameObject>(Constants.cardChipFxStr));
            _ = GlobalRes.DynamicLoadPrefab(Constants.cardChipFxStr, (obj) =>
            {
                cardChipFx = obj;
                cardChipFx.SetActive(false);
                Vector3 position = transform.position;
                cardChipFx.transform.position = position;
            });
            while (cardChipFx == null)
            {
                yield return null;
            }

            if (!remove)
            {
                cardChipFx.SetActive(true);
                Transform card1 = cardChipFx.transform.Find("chip_01/ValueCard_chip_01/card");
                Transform card2 = cardChipFx.transform.Find("chip_02/ValueCard_chip_02/card");
                card1.gameObject.SetActive(false);
                card2.gameObject.SetActive(false);
            }
            else
            {
                Sequence seq = DOTween.Sequence();
                seq.SetId(transform);
                seq.AppendInterval(delayTime - 0.3f);
                seq.Append(cardObj.transform.DORotate(new Vector3(0, 0, 0), 0.1f).SetEase(Ease.OutQuad));
                seq.Join(transform.DOScale(Vector3.one * 1.5f, 0.1f).SetEase(Ease.OutQuad));
                seq.AppendInterval(0.3f);
                var cardRender = cardObj.GetComponent<SpriteRenderer>();
                seq.AppendCallback(() =>
                {
                    SoundPlayer.Instance.PlayZap();
                    SetVisible(false);
                    cardChipFx.SetActive(true);

                    if (CardData.CardType == CardType.Value)
                    {
                        int typeIndex = CardData.Value / Constants.ValueCardCount13;
                        int valueIndex = CardData.Value % Constants.ValueCardCount13;
                        string color = (typeIndex == 1 || typeIndex == 3) ? "red" : "black";
                        Texture2D flowerTex = GlobalRes.Load<Texture2D>(Constants.FlowerResMap[typeIndex]);
                        Texture2D valueTex =
                            GlobalRes.Load<Texture2D>($"Assets/Res/Cards/Textures/{color}_{valueIndex + 1}.png");
                        Transform card1 = cardChipFx.transform.Find("chip_01/ValueCard_chip_01/card");
                        Transform card2 = cardChipFx.transform.Find("chip_02/ValueCard_chip_02/card");
                        card1.gameObject.SetActive(true);
                        card2.gameObject.SetActive(true);

                        MaterialPropertyBlock block1 = new MaterialPropertyBlock();
                        var renderer1 = card1.GetComponent<SpriteRenderer>();
                        renderer1.GetPropertyBlock(block1);
                        block1.SetTexture("_FlowerTex", flowerTex);
                        block1.SetTexture("_ValueTex", valueTex);
                        renderer1.SetPropertyBlock(block1);

                        MaterialPropertyBlock block2 = new MaterialPropertyBlock();
                        var renderer2 = card2.GetComponent<SpriteRenderer>();
                        renderer2.GetPropertyBlock(block2);
                        block2.SetTexture("_FlowerTex", flowerTex);
                        block2.SetTexture("_ValueTex", valueTex);
                        renderer2.SetPropertyBlock(block2);
                    }
                });
                //seq.Insert(delayTime, transform.DOMoveY(position.y + 200, time / 5 * 2));
                //seq.Insert(delayTime + time / 5 * 2, transform.DOMoveY(-700, time / 5 * 3).SetEase(Ease.InQuad));
                //seq.Insert(delayTime, cardObj.transform.DOLocalRotate(new Vector3(0, 0, 360), time, RotateMode.FastBeyond360).SetEase(Ease.OutQuad));
                //seq.Insert(delayTime, cardRender.material.DOVector(new Vector4(0.9f, 0.9f, 0.1f, 0.1f), "_ShadowVector", time / 2));
                //seq.Insert(delayTime + time / 2, cardRender.material.DOVector(new Vector4(0.9f, 0.9f, 0f, 0f), "_ShadowVector", time / 2));
                seq.AppendInterval(0.5f);
                seq.OnComplete(() =>
                {
                    SetVisible(true);
                    Destroy(cardChipFx);
                    // GlobalRes.Release<GameObject>(Constants.cardChipFxStr);
                    ShowModifier(false);
                    gameObject.SetActive(false);
                });
            }

        }

        // StopCoroutine(PlayAnim(delayTime));
        StartCoroutine(PlayAnim(delayTime));

        return delayTime; //seq.Duration();
    }

    public void ShowLockStatue(bool islock)
    {
        cardObj.GetComponent<SpriteRenderer>().material.DOFloat(islock ? 1 : 0, "_GrayScaleAmount", 0.2f);
    }

    internal float DoIceMove(BaseCard iceCard, Action onIceBreak)
    {
        SetSortingOrder(FxSortOrder);
        Sequence seq = DOTween.Sequence();
        SetVisible(true);

        Vector3 selfPos = transform.position;
        Vector3 iceCardPos = iceCard.transform.position;
        Vector3 startPos = selfPos + new Vector3(0, 50);
        bool isLeft = selfPos.x > iceCardPos.x;
        Vector3 controlPos = selfPos + new Vector3(300 * (isLeft ? 1 : -1), 150);
        controlPos.z = selfPos.z;
        iceCardPos.z = selfPos.z;
        Vector3[] pathPosArray = BezierUtils.GetBeizerList(startPos, controlPos, iceCardPos, 10);
        seq.AppendCallback(() => SoundPlayer.Instance.PlayIceBounce());
        seq.Append(transform.DOMove(startPos + new Vector3(0, 20), 0.6f).SetEase(Ease.OutSine));
        seq.Join(transform.DOPunchScale(Vector3.one * 0.1f, 0.45f, 0, 0));
        seq.AppendCallback(() => { SoundPlayer.Instance.PlayIceFly(); });
        seq.Append(transform.DOMove(startPos, 0.3f).SetEase(Ease.OutBack).SetEase(Ease.InCubic));
        seq.Join(cardObj.transform.DORotate(isLeft ? new Vector3(-25, 20, 0) : new Vector3(25, 12, 0), 0.3f));
        seq.AppendCallback(() =>
            cardObj.transform.localEulerAngles = isLeft ? new Vector3(-45, 40, 0) : new Vector3(45, 25, 0));
        seq.Append(
            transform.DOPath(pathPosArray, 0.4f, PathType.CatmullRom, gizmoColor: Color.red).SetEase(Ease.InQuad));
        seq.Join(cardObj.transform.DOBlendableLocalRotateBy(new Vector3(0, 0, isLeft ? 360 : -360), 0.35f,
            RotateMode.FastBeyond360));
        seq.AppendCallback(() =>
        {
            (iceCard as ValueCard)?.BreakIce();
            onIceBreak?.Invoke();
        });
        seq.Append(transform.DOBlendableMoveBy((pathPosArray[9] - pathPosArray[8]).normalized * 1500, 0.7f));
        seq.OnComplete(() =>
        {
            SetSortingOrder(DefaultSortOrder);
            transform.rotation = Quaternion.identity;
            gameObject.SetActive(false);
        });
        return seq.Duration();
    }

    internal float UndoIceMove(int depth)
    {
        cardObj.transform.rotation = Quaternion.identity;
        transform.rotation = Quaternion.identity;
        gameObject.SetActive(true);
        float duration = 1f;
        var pos = GameObjTransInfo.OpenCardPos;
        pos.z = depth;
        transform.DOMove(pos, duration).SetEase(Ease.Linear).OnComplete(() =>
        {
            SetSortingOrder(DefaultSortOrder);
        });
        return duration;
    }


    public float DoLightningHitCardEffect(bool fallback)
    {
        float duration = 0.1f;
        if (fallback)
        {
            gameObject.SetActive(true);
            // transform.localPosition -= new Vector3(0, 50, 0);
        }
        else
        {
            _ = GlobalRes.DynamicLoadPrefab(Constants.lightningFx02, (obj) =>
            {
                _ = Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe(_ =>
                {
                    gameObject.SetActive(false);
                }).AddTo(obj);
                obj.SetActive(true);
                SoundPlayer.Instance.PlayMainSound("LightningMod_fx_01");
                SoundPlayer.Instance.PlayMainSound("LightningMod_fx_02");
                var scene = Camera.main.transform.parent;
                obj.transform.SetParent(scene);
                obj.transform.position = gameObject.transform.position;
                _ = Observable.Timer(TimeSpan.FromSeconds(2)).Subscribe(_ =>
                {
                    Destroy(obj);
                }).AddTo(scene);
            });
            duration = 1;
        }
        return duration;
    }

    internal float DoQuestionNewCard()
    {
        CardAngle = CardData.cm.angle;
        PlayAnimation("ani_QuestionCard_02", () =>
        {
            CardAngle = CardData.cm.angle;
        });

        _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_QuestionCard_02.prefab", (obj) =>
            {
                var scene = Camera.main.transform.parent;
                obj.transform.SetParent(scene);
                obj.transform.position = gameObject.transform.position;
                obj.SetActive(true);
            }, true, 3f);

        return 18 / 60f;
    }

    public float UndoQuestionCard()
    {
        float duration = 0.5f;
        var scale = Constants.CardSizeScale;
        if (this is TwoValueCard)
            scale *= Constants.TwoValueCardSizeScale;
        cardObj.transform.localScale = scale;
        transform.DOScale(Vector3.one, 0);
        transform.gameObject.SetActive(true);
        DoAlphaAnim(0, 0);
        DoAlphaAnim(1, duration, Ease.Linear).OnComplete(() =>
        {
        });
        return 0.1f;
    }

    public float UndoQuestionNewCard()
    {
        float duration = 0.5f;
        var scale = Constants.CardSizeScale;
        if (this is TwoValueCard)
            scale *= Constants.TwoValueCardSizeScale;
        cardObj.transform.localScale = scale;
        transform.DOScale(Vector3.one, 0);
        DoAlphaAnim(0, duration, Ease.Linear).OnComplete(() =>
        {
            transform.gameObject.SetActive(false);
        });
        return 0.1f;
    }

    //被船舵动画
    public float DoBeRudderAnim()
    {
        float closeTime = 0.5f;
        float flyAwayTime = 1f;
        SetSortingOrder(FxSortOrder);
        Vector3 tempPos = cardObj.transform.localEulerAngles;
        Vector3 diffDir = (transform.position - Vector3.zero).normalized;
        if (diffDir.magnitude < 0.1f) diffDir = Vector3.up;
        Vector3 randomSpeed = new Vector3(Random.Range(500, 1000), (diffDir.y > 0 ? 1 : -1) * Random.Range(1000, 1500),
            (diffDir.x > 0 ? 1 : -1) * Random.Range(500, 1000));
        Sequence seq = DOTween.Sequence();
        seq.SetId(transform);
        // seq.Append(transform.DOMove(Vector3.zero + diffDir * 50, closeTime).SetEase(Ease.InQuart));
        seq.Append(transform.DOBlendableMoveBy(diffDir * 1200, flyAwayTime));
        seq.Join(
            DOTween.To(
                () => tempPos,
                (eulerAngle) =>
                {
                    tempPos = eulerAngle;
                    cardObj.transform.localEulerAngles = eulerAngle;
                },
                randomSpeed,
                flyAwayTime
            )
        );
        seq.OnComplete(() =>
        {
            SetSortingOrder(DefaultSortOrder);
            ShowModifier(false);
            gameObject.SetActive(false);
        });

        var duration = seq.Duration();

        PlayAnimation("ani_RudderCard_04");

        return duration;
    }
}