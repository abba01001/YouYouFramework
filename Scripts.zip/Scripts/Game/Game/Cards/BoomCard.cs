using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using SoliUtils;

public class BoomCard : BaseCard
{

    //炸弹牌牌触发动画
    internal float DoTriggerBoomCard()
    {
        SoundPlayer.Instance.PlayBoom();
        IEnumerator PlayAnim()
        {
            GameObject baoFx = null; //Instantiate(GlobalRes.Load<GameObject>(Constants.baoFx2Str));
            GameObject showFx = null;//Instantiate(GlobalRes.Load<GameObject>(Constants.showFxStr));
            GameObject boomPrefab = null;//Instantiate(GlobalRes.Load<GameObject>(Constants.boomPrefabStr));
            GameObject boomGatherFx = null;//Instantiate(GlobalRes.Load<GameObject>(Constants.boomGatherFxStr));

            GlobalRes.DynamicLoadPrefab(Constants.baoFx2Str, (obj) => { baoFx = obj;baoFx.gameObject.SetActive(false); });
            GlobalRes.DynamicLoadPrefab(Constants.showFxStr, (obj) => { showFx = obj;showFx.gameObject.SetActive(false); });
            GlobalRes.DynamicLoadPrefab(Constants.boomPrefabStr, (obj) => { boomPrefab = obj; boomPrefab.gameObject.SetActive(false);});
            GlobalRes.DynamicLoadPrefab(Constants.boomGatherFxStr, (obj) => { boomGatherFx = obj; boomGatherFx.gameObject.SetActive(false);});
            while (baoFx == null || showFx == null || boomPrefab == null || boomGatherFx == null)
            {
                yield return null;
            }
            
            float time = 0.2f;
            Vector3 selfPos = transform.position;
            Sequence seq = DOTween.Sequence();
            seq.SetId(transform);
            boomGatherFx.transform.position = selfPos;
            seq.Append(transform.DOScale(Vector3.one * 1.2f, time).SetEase(Ease.OutQuart));
            seq.AppendCallback(() =>
            {
                showFx.gameObject.SetActive(true);
                boomPrefab.gameObject.SetActive(true);
                showFx.transform.position = selfPos;
                boomPrefab.transform.position = selfPos;
                boomPrefab.transform.localScale = Vector3.one * 1.2f;
            });
            seq.Append(boomPrefab.transform.DOPunchScale(Vector3.one * 0.3f, time, elasticity: 0));
            seq.Join(transform.DOScale(Vector3.one * 0.5f, time));
            seq.Join(DoAlphaAnim(0, time));
            seq.AppendInterval(time);
            seq.AppendCallback(() => boomGatherFx.gameObject.SetActive(true));
            seq.Append(boomPrefab.transform.DOBlendableScaleBy(Vector3.one * 0.5f, 0.3f));
            seq.OnComplete(() =>
            {
                baoFx.gameObject.SetActive(true);
                baoFx.transform.position = selfPos;
                gameObject.SetActive(false);
                Destroy(baoFx.gameObject, 1.5f);
                Destroy(showFx.gameObject);
                Destroy(boomPrefab.gameObject);
                Destroy(boomGatherFx.gameObject);
                // GlobalRes.Release<GameObject>(Constants.baoFx2Str, 1.5f);
                // GlobalRes.Release<GameObject>(Constants.showFxStr);
                // GlobalRes.Release<GameObject>(Constants.boomPrefabStr);
                // GlobalRes.Release<GameObject>(Constants.boomGatherFxStr);
            });
        }
        StopCoroutine(PlayAnim());
        StartCoroutine(PlayAnim());
        return 1.1f; //seq.Duration();
    }

    internal float DoPowerItemEnter(Vector3 startPos, float offsetTime)
    {
        SetVisible(false);
        SetSortingOrder(FxSortOrder);
        transform.position = startPos;
        CardAngle = 0;
        Vector3 endPos = new Vector3(CardData.cm.x, CardData.cm.y, CardData.cm.depth);
        Vector3 controlPos = (startPos + endPos) / 2 + new Vector3(0, 600);
        Vector3[] pathPos = BezierUtils.GetBeizerList(startPos, controlPos, endPos, 10);
        Sequence seq1 = DOTween.Sequence();
        seq1.AppendInterval(offsetTime);
        seq1.AppendCallback(() =>
        {
            DoAlphaAnim(1, 0.35f);
            PlayAnimation("PowerItemMoveA", () =>
            {
                PlayAnimation("PowerItemMoveB");
                Sequence seq = DOTween.Sequence();
                seq.Append(transform.DOPath(pathPos, 1.1f));
                seq.InsertCallback(0.6f, () =>
                {
                    SetSortingOrder(DefaultSortOrder);
                    CardAngle = CardData.cm.angle;
                });
            });
        });
        seq1.AppendInterval(0.83f);
        seq1.AppendCallback(() =>
        {
            _ = GlobalRes.DynamicLoadPrefab(Constants.powerItemShowFxStr, (showFx) =>
            {
                showFx.transform.position = startPos;
                // GlobalRes.Release<GameObject>(Constants.powerItemShowFxStr, 2);
            },true,2f);
        });
        return 1.64f + 1.25f + offsetTime;
    }
}
