using System;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
[ExecuteInEditMode]
public class ChainLightning : MonoBehaviour
{
    [Header("线条的细节程度")]
    public float detail = 1f; // 线条的细节程度
    [Header("线条的位移量")]
    public float displacement = 15f; // 线条的位移量
    [Header("线条频率")]
    public float frequency = 0.1f; // 闪电效果的刷新频率（秒）
    public Vector3 EndPosition = Vector3.one * 9999f; // 结束位置
    public Vector3 StartPosition = Vector3.one * 9999f; // 开始位置
    public float yOffset = 0f;
    
    private float timer = 0f;
    
    private LineRenderer _lineRenderer;
    private List<Vector3> _linePosList;

    private static readonly Vector3 InvalidPosition = Vector3.one * 9999f;

    private void Awake()
    {
        _lineRenderer = GetComponent<LineRenderer>();
        _linePosList = new List<Vector3>();
    }

    public void SetData(Vector3 startPos, Vector3 endPos, Action cb)
    {
        StartPosition = startPos;
        EndPosition = endPos;
        cb?.Invoke();
    }

    private void Update()
    {
        if (Time.timeScale != 0)
        {
            timer += Time.deltaTime;
            if (timer >= frequency)
            {
                timer = 0f;
                UpdateLightning();
            }
        }
    }

    private void UpdateLightning()
    {
        if (Time.timeScale != 0)
        {
            _linePosList.Clear();

            Vector3 startPos = StartPosition != InvalidPosition ? StartPosition + Vector3.up * yOffset : Vector3.zero;
            Vector3 endPos = EndPosition != InvalidPosition ? EndPosition + Vector3.up * yOffset : Vector3.zero;

            CollectLinePos(startPos, endPos, displacement);
            _linePosList.Add(endPos);

            _lineRenderer.positionCount = _linePosList.Count;
            for (int i = 0; i < _linePosList.Count; i++)
            {
                _lineRenderer.SetPosition(i, _linePosList[i]);
            }
        }
    }

    private void CollectLinePos(Vector3 startPos, Vector3 destPos, float displace)
    {
        if (displace < detail)
        {
            _linePosList.Add(startPos);
        }
        else
        {
            Vector3 midPos = Vector3.Lerp(startPos, destPos, 0.5f);
            midPos.x += (UnityEngine.Random.value - 0.5f) * displace;
            midPos.y += (UnityEngine.Random.value - 0.5f) * displace;
            midPos.z += (UnityEngine.Random.value - 0.5f) * displace;

            CollectLinePos(startPos, midPos, displace / 2f);
            CollectLinePos(midPos, destPos, displace / 2f);
        }
    }
}
