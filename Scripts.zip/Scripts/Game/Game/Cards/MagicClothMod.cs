using DG.Tweening;
using UnityEngine;
using SoliUtils;

namespace Game.Cards
{
    public class MagicClothMod : BaseMod
    {
        private Animator anim;
        private void OnEnable()
        {
            gameObject.transform.localScale = Vector3.one;
            gameObject.transform.localEulerAngles = Vector3.zero;
            gameObject.transform.localPosition = new Vector3(0, 0, -0.1f);
            anim = GetComponent<Animator>();
        }

        public void SetState(bool isOpen)
        {
            anim.gameObject.SetActive(true);
            if (isOpen)
            {
                anim.SetTrigger("OpenMagicCloth");
                SoundPlayer.Instance.PlayMainSound("ani_ClothOpen");
            }
            else
            {
                var state = anim.GetCurrentAnimatorStateInfo(0);
                if (!state.IsName("CloseMagicCloth"))
                {
                    anim.SetTrigger("CloseMagicCloth");
                    SoundPlayer.Instance.PlayMainSound("ani_ClothClose");
                }
            }
        }
    }
}