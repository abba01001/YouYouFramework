using System;
using System.Collections.Generic;
using Doozy.Engine.Extensions;
using SoliUtils;

public class IBattleOperation
{
    public int cardId;
    public int Round;
    public long time;
    public List<int> deskCards = new List<int>();
    public Dictionary<int, CardData> allCardData = new Dictionary<int, CardData>();
    private Queue<IRenderCommand> renderQueue;
    public Queue<IRenderCommand> RenderQueue
    {
        get => renderQueue;
        set
        {
            renderQueue = new Queue<IRenderCommand>(value);
        }
    }
    public IBattleOperation()
    {
        time = TimeUtils.UtcNow();
    }

    public int handCardNumber = 0; //操作前手牌数量
    public void SetHandCardNumber(int number)
    {
        handCardNumber = number;
    }

    public int openCardNumber = 0; //操作后明牌数量
    public void SetOpenCardNumber(int number)
    {
        openCardNumber = number;
    }
    public int comboStepIdx; //操作前步骤
    public List<bool> comboColorList; //操作前的combo
}

public class SystemStartOpt : IBattleOperation
{

}

public class SystemOverOpt : IBattleOperation
{

}

public class SystemEmptyOpt : IBattleOperation
{

}

public class UndoOpt : IBattleOperation
{

}
public class BuyJokerOpt : IBattleOperation
{
    public BuyJokerOpt(int round, int cardId, Dictionary<int, CardData> cards, List<int> deskCards)
    {
        this.cardId = cardId;
        Round = round;
        foreach (var pair in cards)
        {
            allCardData.TryAdd(pair.Key, pair.Value.Copy());
        }
        this.deskCards = new List<int>(deskCards);
    }
}
public class BuyCardOpt : IBattleOperation
{

}

public class CollectCardOpt : IBattleOperation
{
    public CollectCardOpt(int _cardId) => cardId = _cardId;
}

public class ClickDeskCardOpt : IBattleOperation
{
    public List<CardData> cardList = new List<CardData>();
    public ClickDeskCardOpt(int round, int cardId, Dictionary<int, CardData> cards, List<int> deskCards)
    {
        this.cardId = cardId;
        Round = round;
        foreach (var pair in cards)
        {
            allCardData.TryAdd(pair.Key, pair.Value.Copy());
        }
        this.deskCards = new List<int>(deskCards);
    }
    public void AddCard(CardData card)
    {
        cardList.Add(card.Copy());
    }
}

public class FlopHandCardOpt : IBattleOperation
{
    public List<int> cardList = new List<int>();
    public FlopHandCardOpt(int round, int cardId, Dictionary<int, CardData> cards, List<int> deskCards)
    {
        this.cardId = cardId;
        Round = round;
        foreach (var pair in cards)
        {
            allCardData.TryAdd(pair.Key, pair.Value.Copy());
        }
        this.deskCards = new List<int>(deskCards);
    }
    public void AddCard(int cardId)
    {
        cardList.Add(cardId);
    }
    public void AddCards(List<int> cardIds)
    {
        cardList.AddRange(cardIds);
    }
}

public class ClickBoomCardOpt : IBattleOperation
{
    public CardData card;

    public ClickBoomCardOpt(CardData a)
    {
        card = a;
    }
}

public class ClickWindmillCardOpt : IBattleOperation
{
    public CardData windmillCard;
    public List<CardData> windmillFlyCards;

    public ClickWindmillCardOpt(CardData windmill, List<CardData> windmillFly)
    {
        windmillCard = windmill;
        windmillFlyCards = windmillFly;
    }
}

public class ClickZapCardOpt : IBattleOperation
{
    public CardData card;

    public ClickZapCardOpt(CardData a)
    {
        card = a;
    }
}

public class ClickKeyCardOpt : IBattleOperation
{
    public CardData card;

    public ClickKeyCardOpt(CardData a)
    {
        card = a;
    }
}

public class ClickThreeCardOpt : IBattleOperation
{
    public CardData card;

    public ClickThreeCardOpt(CardData a)
    {
        card = a;
    }
}
public class ClickCopyCardOpt : IBattleOperation
{
    public CardData card;

    public ClickCopyCardOpt(CardData a)
    {
        card = a;
    }
}

public class ClickMonkeyBananaCardOpt : IBattleOperation
{
    public CardData clickCard;
    public CardData pairCard;

    public ClickMonkeyBananaCardOpt(CardData click, CardData pair)
    {
        clickCard = click;
        pairCard = pair;
    }
}


public class BreakIceOpt : IBattleOperation
{
    public CardData openCard;
    public CardData deskCard;

    public BreakIceOpt(CardData a, CardData b)
    {
        openCard = a;
        deskCard = b;
    }
}