﻿using System.Collections;
using UnityEngine;

public class GameObjectData
{
    public Transform viewTransform;
    public GameObject gameObject;
    public Transform transform;
    public Transform parent;
    public int siblingIndex;
    public Vector3 viewLocalPosition;
    public Vector3 position;
    public RectTransform rectTransform;
    public Vector3 localPosition;
    public Vector2 anchoredPosition;
    public int sortingOrder;

    public void InitViewObj(Transform viewTransform,GameObject gameObject)
    {
        this.viewTransform = viewTransform;
        this.gameObject = gameObject;
        transform = gameObject.transform;
        viewLocalPosition = GetViewLocalPosition();
        parent = transform.parent;
        siblingIndex = transform.GetSiblingIndex();
        position = transform.position;
        localPosition = transform.localPosition;
        rectTransform = gameObject.GetComponent<RectTransform>();
        anchoredPosition = rectTransform.anchoredPosition;
    }

    private Vector3 GetViewLocalPosition()
    {
        Vector3 localPosition = transform.localPosition;
        Transform parentTf = transform.parent;
        while (parentTf != viewTransform)
        {
            localPosition += parentTf.localPosition;
            parentTf = parentTf.parent;
        }
        return localPosition;
    }

    public void Reset()
    {
        transform.SetParent(parent);
        transform.SetSiblingIndex(siblingIndex);
        transform.localPosition = localPosition;
    }
    
}