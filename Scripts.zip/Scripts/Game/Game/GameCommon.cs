using DG.Tweening;
using System;
using System.Diagnostics;

public static class GameCommon
{
    public static bool IsAiMode = false;
    public static bool IsEditorMode = false;
    public static bool IsRandomMode = false;
    public static bool IsOffMode = false;
    public static bool IsGmMode = false;
    public static float CoverCardMultiple = 0.5f;
    public static float CardAnimScale = 0.5f;
    public static float CardDropScale = 0.9f;
    public static Action HideRookieTipItem;
    public static bool HasCheckUser = false;
    public static bool HasServerTime = false;
    public static bool IsOldUser = false;
    public static bool IsRemoteUser = false;
    public static bool IsRemoteData = false;
    public static bool IsShieldPurchase = false;
    public static bool IsShowCarding = false;
    public static bool IsShowingStartGamePopup = false;
    public static bool IsAddingCollect = false;
    public static bool IsPlayingCollectFraming = false;
    public static bool IsPlayingCollectAnim = false;
    public static bool IsShowSpeialCardTiping = false;
    public static bool IsRequestingEmail = false;
    public static bool IsRequestingRank = false;
    public static bool IsShowHeartBeat = false;
    public static bool GMAddCollectResource = false;
    public static bool IsExitGame = false;
    public static bool IsPlayedGame { get; private set; }
    public static bool? LastGameIsWin { get; private set; }
    public static bool IsEnterGame = false;
    public static bool IsDataUpload = true;
    public static int VisiblePopupCount = 0;

    public static int BeforeEndActivityTime = 180;
    static GameCommon()
    {
        IsPlayedGame = false;
        LastGameIsWin = null;
#if UNITY_EDITOR
        IsShieldPurchase = false;
#else
    IsShieldPurchase = true;
#endif
    }

    public static void SetGameFinish(bool isWin, int duration)
    {
        IsPlayedGame = true;
        LastGameIsWin = isWin;
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        if (isWin)
            dataService.FailSameLevelTimes = 0;
        else
        {
            if (duration >= 90)
                dataService.FailSameLevelTimes++;

            //前三个宝箱白给    
            if(dataService.MergeLevelBoxIndex < 3 )
            {
                dataService.AddMergeLevelBox();
            }
        }
    }

    // 设置Dotween动画速度
    public static void SetTweenSpeed(float speed = 1)
    {
        DOTween.timeScale = speed;
    }
}