using System;
using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;

public class CameraMono : MonoBehaviour
{
    // Start is called before the first frame update
    
    private void Awake()
    {
    }

    void Start()
    {
        //var orthoCam = GetComponent<Camera>();
        //var fov = 2f * Mathf.Rad2Deg * Mathf.Atan2(orthoCam.orthographicSize,orthoCam.transform.position.z);
        //var projmtx = Matrix4x4.Perspective(fov, -orthoCam.aspect, orthoCam.nearClipPlane, orthoCam.farClipPlane);
        //var proj = GL.GetGPUProjectionMatrix(projmtx,false);
        //Shader.SetGlobalMatrix("_PerspCamProj", proj);
        
        //float CXSize = orthoCam.orthographicSize * 2 * ((float) Screen.width / (float) Screen.height)/2 + orthoCam.transform.position.x;
        //float CYSize = orthoCam.orthographicSize * 2 / Mathf.Cos ( 0 * Mathf.Deg2Rad ) / 2 + orthoCam.transform.position.y;

        // var str = "caiweiyuan";
        // var key = "g7uHygaenuWhnAKRXHzsrZX3T2D8pOQT";
        // var str1 = DESEncrypt.Encrypt(str, key);
        // Debug.Log(str1);
        // var str2 = DESEncrypt.Decrypt(str1, key);
        // Debug.Log(str2);
        
        
        // (new AIController()).Run();

        // Application.targetFrameRate = 60;
        // var f = 0.6f;
        // var width = 750;
        // var height = 1624;
        // Screen.SetResolution((int)(width * f), (int)(height * f), true);
        // LevelUtils.CreateLevelData(10);

        // Debug.Log("Test=================================1");
        //  Debug.Log(CXSize);
        //   Debug.Log(CYSize);
        //   AIController.Run();
        // long a = 0;
        // for (int i = 0; i < 52; i++)
        // {
        //     int b = i;
        //     Debug.Log(BitUtils.IsFlag(a, b));
        // }
        // Debug.Log("Test=================================2");
        // for (int i = 0; i < 52; i++)
        // {
        //     int b = i;
        //     a = BitUtils.Flag(a, b);
        //     Debug.Log(BitUtils.IsFlag(a, b));
        // }
        // Debug.Log("Test=================================2");

        // int[] nums = new[] {0, 3};
        // var dic = GetPath.GetPathResult(nums);
        // foreach (var v in dic[1])
        // {
        //     Debug.Log($"===== --------");
        //     foreach (var z in v)
        //     {
        //         Debug.Log($"===== {z}");
        //     }
        // }
        //
        // var dic2 = PathAlgorithm.FindLink(nums);
        //
        // List<int> aaa = new List<int>{0,1,2,3,0};
        //
        // aaa.Remove(0);
        // int a = 0;
        // a++;
    }

    // Update is called once per frame
    void Update()
    {
        // var cardBounds1 = card1.GetComponent<BoxCollider2D>().bounds;
        // var cardBounds2 = card2.GetComponent<BoxCollider2D>().bounds;
        // Debug.Log(cardBounds1.Intersects(cardBounds2));
        
        // card1.transform.Rotate(new Vector3(0, 2, 0));
    }
}
