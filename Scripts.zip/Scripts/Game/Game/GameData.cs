﻿using QFramework;
using System.Collections.Generic;
using Activities;
using UnityEngine;
using SoliUtils;

public class GameData
{
    private readonly IConfigService configService;
    private readonly IDataService dataService;
    public readonly int Level;
    public readonly List<int> itemList;

    public int BattleIntegral;
    public int AddBuildCoin;
    public int ComsumeCoin;
    public int BuyCardNum { get; set; }
    public int BuyJokerNum { get; set; }
    public int BuyUndoNum { get; private set; }
    public int UseUndoCount { get; private set; }
    public int UseJokerCount { get; private set; }
    public int UseBuyCardCount { get; private set; }
    public int UseFreeJokerCount { get; private set; }

    public int StarRewardNum { get; private set; }
    public int ComboNum { get; private set; }
    public int LeftCardCoin { get; private set; }
    public long EnterCoin;
    public int ComboJokerRewardNum { get; set; }

    //
    public int RemainStepNum { get; set; }
    public int RemainDeskCardNum { get; set; }
    public int RemainHandCardNum { get; set; }
    public int RemainCoin { get; set; }


    private readonly Dictionary<PropChangeWay, int> coinDic;

    public GameData(IConfigService _configService, IDataService _dataService, int _level, List<int> _item)
    {
        Level = _level;
        configService = _configService;
        dataService = _dataService;
        itemList = _item;
        coinDic = new Dictionary<PropChangeWay, int>();

        BuyCardNum = 0;
        BuyJokerNum = 0;
        BuyUndoNum = 0;
        UseUndoCount = 0;
        UseJokerCount = 0;
        UseBuyCardCount = 0;
        UseFreeJokerCount = 0;
        StarRewardNum = 0;
        BattleIntegral = 0;
        AddBuildCoin = 0;
        ComsumeCoin = 0;
        ComboNum = 0;
        LeftCardCoin = 0;
    }

    public void AddRewardCoin(PropChangeWay changeWay, int coin, params object[] param)
    {
        int oldNum = GetCoin();
        if (coinDic.ContainsKey(changeWay))
            coinDic[changeWay] += coin;
        else
            coinDic.Add(changeWay, coin);

        GameRewardChangeEvent t = GameObjManager.Instance.PopClass<GameRewardChangeEvent>(true);
        t.Init((int)PropEnum.Coin, oldNum, oldNum + coin, changeWay, param);
        TypeEventSystem.Send<GameRewardChangeEvent>(t);
    }

    public void ReduceRewardCoin(PropChangeWay changeWay, int coin, params object[] param)
    {
        int oldNum = GetCoin();
        if (!coinDic.ContainsKey(changeWay) || coinDic[changeWay] < coin)
        {
            Debug.LogError("削减奖励值出现意外");
            return;
        }
        coinDic[changeWay] -= coin;

        GameRewardChangeEvent t = GameObjManager.Instance.PopClass<GameRewardChangeEvent>(true);
        t.Init((int)PropEnum.Coin, oldNum, oldNum - coin, changeWay, param);
        TypeEventSystem.Send<GameRewardChangeEvent>(t);
    }

    public void AddRewardStar(int starNum)
    {
        ComboNum++;
        int oldNum = StarRewardNum;
        StarRewardNum += starNum;
        GameRewardChangeEvent t = GameObjManager.Instance.PopClass<GameRewardChangeEvent>(true);
        t.Init((int)PropEnum.StageStar, oldNum, StarRewardNum, PropChangeWay.ComboStep, null);
        TypeEventSystem.Send<GameRewardChangeEvent>(t);
    }

    public void ReduceRewardStar(int starNum)
    {
        ComboNum--;
        int oldNum = StarRewardNum;
        StarRewardNum -= starNum;
        GameRewardChangeEvent t = GameObjManager.Instance.PopClass<GameRewardChangeEvent>(true);
        t.Init((int)PropEnum.StageStar, oldNum, StarRewardNum, PropChangeWay.ComboStep, null);
        TypeEventSystem.Send<GameRewardChangeEvent>(t);
    }

    public int GetCoin(params PropChangeWay[] changeWayArray)
    {
        int result = 0;
        if (changeWayArray == null || changeWayArray.Length == 0)
        {
            foreach (var item in coinDic)
                result += item.Value;
        }
        else
        {
            foreach (var item in changeWayArray)
                result += coinDic.ContainsKey(item) ? coinDic[item] : 0;
        }

        return result;
    }

    //剩余手牌金币
    public int GetLeftCardCoin()
    {
        int max = int.Parse(configService.ValueConfig["remainStartLimit"]);
        if (LeftCardCoin > max)
        {
            LeftCardCoin = max;
        }
        return LeftCardCoin;
    }

    public int GetLeftCardIntegral(BattleResultEvent e)
    {
        int addCardIntegral = 0;
        if (e.cards.Count != 0)
        {
            Dictionary<int, int> integralCardRule = configService.GetIntegralCardRule;
            integralCardRule.TryGetValue(e.cards.Count, out addCardIntegral);
        }
        return addCardIntegral;
    }

    public int GetGuaranteeCoin()
    {
        return int.Parse(configService.ValueConfig["MinGold"]);
    }
    
    //处理结算的资源
    public void HandleResultProp(BattleResultEvent e)
    {
        if(dataService.IsRookieStatus())
            return;
        HandleLeftCardCoin(e);
        
        int getBuildCoin = CaculateAddBuildCoin();
        int rewardCoin = GetCoin() + GetLeftCardCoin() + GetGuaranteeCoin();

        dataService.AddCoin(rewardCoin, PropChangeWay.WinGame, Vector3.zero, false);
        dataService.PiggyData.AddPiggyCoin(rewardCoin, true);
        foreach (var pair in GetResultReward())
        {
            if (pair.Key != (int)PropEnum.BuildCoin)
            {
                dataService.AddProp(pair.Key, pair.Value, PropChangeWay.WinGame);
                dataService.AddFlyAnimProp(pair.Key, pair.Value);
            }
        }

        dataService.AddFlyAnimProp((int)PropEnum.BuildCoin, getBuildCoin);
        dataService.AddFlyAnimProp((int)PropEnum.Coin, rewardCoin);
        dataService.AddFlyAnimProp((int)PropEnum.PiggyCoin, rewardCoin);
        ActivityManager.Instance.EnergyActivity.HandleResultEnergy();
        dataService.AddMergeLevelBox();
    }

    //剩余手牌金币
    public void HandleLeftCardCoin(BattleResultEvent e)
    {
        for (int i = 0; i < e.cards.Count; i++)
        {
            int index = i;
            var card = e.cards[index];
            var configService = MainContainer.Container.Resolve<IConfigService>();
            int rewardNum = configService.GetRemainReward(Level, index + 1) * dataService.NowBet;
            int multiple = card.GetCardType() == CardType.Value ? 1 : 2;
            LeftCardCoin += rewardNum * multiple;
        }
    }

    public bool BuyCard()
    {
        if (!dataService.UseProp((int)PropEnum.FreeBuyCard, PropChangeWay.BuyHandCard))
        {
            if (dataService.ConsumeCoin(GetNowBuyCardCost(), PropChangeWay.BuyHandCard))
            {
                BuyCardNum++;
            }
            else
            {
                ActivityManager.Instance.CheckPushGift(Constants.ProductId.BankruptcyPack_1, GiftType.BrokenGift);
                return false;
            }
        }
        UseBuyCardCount++;
        return true;
    }

    public void ExitBuyCard()
    {
        if (dataService.GetPropNum((int) PropEnum.FreeBuyCard) == 0)
        {
            if (dataService.ConsumeCoin(GetNowBuyCardCost(), PropChangeWay.BuyHandCard))
            {
                BuyCardNum++;
                dataService.AddProp((int)PropEnum.FreeBuyCard,1,PropChangeWay.BuyHandCard);
                TypeEventSystem.Send<BuyPlus5Event>();
                RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
                t.Init(this);
                TypeEventSystem.Send<RefreshGameViewEvent>(t);
            }
            else
            {
                ActivityManager.Instance.CheckPushGift(Constants.ProductId.BankruptcyPack_1, GiftType.BrokenGift);
            }
        }
    }
    
    public void UsePlus5Card()
    {
        dataService.UseProp((int) PropEnum.FreeBuyCard, PropChangeWay.BuyHandCard);
        UseBuyCardCount++;
        
        BattleCenter.Instance.OnBuyCardsEvent(UseBuyCardCount);
        RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
        t.Init(this);
        TypeEventSystem.Send<RefreshGameViewEvent>(t);
    }

    public bool BuyJoker()
    {
        if (!dataService.UseProp((int)PropEnum.FreeJoker, PropChangeWay.BuyJokerCard))
        {
            if (dataService.ConsumeCoin(GetNowBuyJokerCost(), PropChangeWay.BuyJokerCard))
            {
                BuyJokerNum++;
            }
            else
            {
                // BoxBuilder.ShowCoinAdPop();
                //BoxBuilder.ShowShopPop();
                ActivityManager.Instance.CheckPushGift(Constants.ProductId.BankruptcyPack_2, GiftType.BrokenGift);

                // if (!GameUtils.TryShowTriggerGift(false, false))
                //     BoxBuilder.ShowShopPop();
                return false;
            }
        }
        else
        {
            UseFreeJokerCount++;
        }

        UseJokerCount++;
        return true;
    }

    public void UndoBuyJoker()
    {
        if (UseJokerCount > UseFreeJokerCount)
        {
            dataService.AddCoin(GetNowBuyJokerCost(), PropChangeWay.BuyJokerCard);
            if (BuyJokerNum > 0)
                BuyJokerNum--;
        }
        else if (UseFreeJokerCount > 0)
        {
            dataService.AddProp((int)PropEnum.FreeJoker, 1, PropChangeWay.UndoFreeJokerCard);
            UseFreeJokerCount--;
        }
        if (UseJokerCount > 0)
            UseJokerCount--;
    }

    public bool BuyUndo()
    {
        if (!dataService.UseProp((int)PropEnum.FreeUndo, PropChangeWay.BuyUndo))
        {
            if (dataService.ConsumeCoin(GetNowUndoCost(), PropChangeWay.BuyUndo))
            {
                BuyUndoNum++;
            }
            else
            {
                // BoxBuilder.ShowCoinAdPop();
                //BoxBuilder.ShowShopPop();
                ActivityManager.Instance.CheckPushGift(Constants.ProductId.BankruptcyPack_3, GiftType.BrokenGift);

                // if (!GameUtils.TryShowTriggerGift(false, false))
                //     BoxBuilder.ShowShopPop();
                return false;
            }
        }

        UseUndoCount++;
        return true;
    }

    public int GetNowBuyCardCost()
    {
        if (!GameCommon.IsAiMode && dataService.GetPropNum((int)PropEnum.FreeBuyCard) > 0) return 0;
        return configService.GetBuyCardCost(Level, BuyCardNum + 1) * dataService.NowBet;
    }

    public int GetNowBuyJokerCost()
    {
        if (!GameCommon.IsAiMode && dataService.GetPropNum((int)PropEnum.FreeJoker) > 0) return 0;
        return configService.GetBuyJokerCost(Level, BuyJokerNum + 1) * dataService.NowBet;
    }

    public int GetNowUndoCost()
    {
        if (!GameCommon.IsAiMode && dataService.GetPropNum((int)PropEnum.FreeUndo) > 0) return 0;
        return configService.GetUndoCost(Level, BuyUndoNum + 1) * dataService.NowBet;
    }

    public bool CanBuyCard()
    {
        return dataService.Coin >= GetNowBuyCardCost();
    }

    public bool CanUndo()
    {
        return dataService.Coin >= GetNowUndoCost();
    }

    public bool CanJoker()
    {
        return dataService.Coin >= GetNowBuyJokerCost();
    }

    //计算剩余手牌积分
    public void HandleCardIntegral(BattleResultEvent e)
    {

    }

    public void AddSmallCombo(int comboNum)
    {

    }

    public void SubSmallCombo(int comboNum)
    {

    }

    public void AddBigCombo(int comboStep)
    {

    }

    public void SubBigCombo(int comboStep)
    {

    }

    public int CaculateAddBuildCoin(bool isWin = true)
    {
        configService.GetBuildCoinRate().TryGetValue(dataService.NowBet, out float xishu);
        configService.GetResultReward(Level).TryGetValue((int)PropEnum.BuildCoin, out int count);
        AddBuildCoin = Mathf.RoundToInt(xishu * count);
        return AddBuildCoin;
    }

    public Dictionary<int, int> GetResultReward()
    {
        return configService.GetResultReward(Level);
    }

}