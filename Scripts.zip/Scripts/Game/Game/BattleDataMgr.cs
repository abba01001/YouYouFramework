using System;
using System.Collections.Generic;
using System.Linq;
using OBBUtils;
using QFramework;
using UniRx;
using SoliUtils;
using Vector2 = UnityEngine.Vector2;
using Vector3 = UnityEngine.Vector3;
using Debug = UnityEngine.Debug;
using Mathf = UnityEngine.Mathf;
using Activities;

public class BattleConfig
{
    public int levelId;
    public LevelModel levelModel;
    public int minGuar = 999;
    public int maxGuar = 999;
    public int cardBackId = 1;
    public int betValue = 1;
    public int deskCardAmend = 0;
    public int handCardAmend = 0;
    public List<int> itemList;
    public float cardWidth = Constants.CardSize.x * Constants.CardSizeScale.x;
    public float cardHeight = Constants.CardSize.y * Constants.CardSizeScale.y;
    public bool isGuarantee = false;
    public int[] comboSteps;
    public int comboLimitHandleNum = 0;
    public float[] comboLimitRate;
    public bool random = false; //纯随机
    public bool paid = false; //是否进入付费控制
    public Tuple<float, float> manyHandLinkRate;
    public List<CardType> winStreakCards;

}


public class BattleDataMgr : ISingleton
{
    private IDataService dataService
    {
        get => MainContainer.Container.Resolve<IDataService>();
    }
    private IConfigService configService
    {
        get => MainContainer.Container.Resolve<IConfigService>();
    }
    private IController Controller;
    private int CardAutoId;
    private bool isMovingScene = false;

    public Dictionary<int, CardData> AllCardsDic = new Dictionary<int, CardData>();//全部牌
    private List<int> DeskCards = new List<int>(); //桌面牌
    private List<int> HandCards = new List<int>(); //手牌堆
    private List<int> OpenCards = new List<int>(); //明牌堆
    private List<int> DiscCards = new List<int>(); //弃牌堆
    private List<int> HandRmCards = new List<int>(); //被吞的手牌（ps闪电）

    class CardNode
    {
        public int id;
        public List<CardNode> childNodes;
        public List<CardNode> parentNodes;

        public CardNode()
        {
            id = -1;
            childNodes = new List<CardNode>();
            parentNodes = new List<CardNode>();
        }
    }
    private Dictionary<int, CardNode> DeskCardsHash = new Dictionary<int, CardNode>(); //桌面牌

    private int Round = 0;

    private Queue<IRenderCommand> renderQueue = new Queue<IRenderCommand>();
    public Stack<IBattleOperation> OperatStack = new Stack<IBattleOperation>();

    private List<CardData> bananaCards = new List<CardData>();
    private List<CardData> monkeyCards = new List<CardData>();
    private List<int> lizardCards = new List<int>();

    private CardData CurHandCard
    {
        get
        {
            if (OpenCards.Count == 0)
                return null;
            return AllCardsDic[OpenCards[OpenCards.Count - 1]];
        }
    }

    private CardData lastCard;

    public bool IsFinish
    {
        get
        {
            return DeskCards.Count == 0 || happendBigBomb;
        }
    }

    public bool HappendBigBomb
    {
        get
        {
            return happendBigBomb;
        }
    }

    private BattleConfig battleConfig;
    private int handCardWasted = 0;
    private int guarNum = 0; //保底废牌数
    private bool triggerComboLimit = false; //是否触发combo限制规则
    private bool aborted = false;
    private bool happendBigBomb = false;

    private long faceupValueCardBit; //标记明面上的数值牌
    private int noHandCardTime = 0; //手牌堆为空次数
    private bool isMissComboFlag = false;
    private int[] initComboSteps;//本次游戏combo组
    private int comboStepIdx;//当前combo组
    private List<bool> comboColorList = new List<bool>();//本轮combo组
    private List<bool> optComboColorList = new List<bool>(); //本次操作的combo数
    private List<List<int>> comboAddCards = new List<List<int>>();//combo加牌记录
    public int ComboCount;//连续消牌计数

    public int movingSceneZ = 100;
    public int movingSceneBeginX = -500;
    public int movingSceneValidX = 460;
    public int SpecailHandCardNumber = 0; //特殊牌影响手牌数量
    public int SpecailDeskCardNumber = 0; //特殊牌影响桌面牌数量

    private int taskTotalNumber = 0; //任务牌总数量
    private int taskLeftNumber = 0; //任务牌剩余数量

    private List<int> handcardValues = new List<int>();

    private BattleDataMgr()
    {
    }

    public void Clean()
    {
        happendBigBomb = false;
        aborted = false;
        DeskCards.Clear();
        DeskCardsHash.Clear();
        HandCards.Clear();
        OpenCards.Clear();
        DiscCards.Clear();
        bananaCards.Clear();
        monkeyCards.Clear();
        AllCardsDic.Clear();
        faceupValueCardBit = 0;
        noHandCardTime = 0;
        handCardWasted = 0;
        lastCard = null;
        SpecailHandCardNumber = 0;
        SpecailDeskCardNumber = 0;
        Round = 0;
        handcardValues.Clear();
        comboAddCards.Clear();
        comboColorList.Clear();
        optComboColorList.Clear();
        comboStepIdx = 0;
        taskTotalNumber = 0;
        taskTotalNumber = 0;
        TypeEventSystem.Send<BigBombEvent>(new BigBombEvent(false));
    }

    public static BattleDataMgr Instance
    {
        get { return SingletonProperty<BattleDataMgr>.Instance; }
    }

    public void OnSingletonInit()
    {
    }

    public void LoadGame(BattleConfig battleCnf)
    {
        Controller = GameCommon.IsAiMode ? AIController.Instance : GameController.Instance;
        GameCommon.IsShowCarding = true;
        OperatStack.Clear();

        battleConfig = battleCnf;
        guarNum = GameUtils.RandomRange(battleConfig.minGuar, battleConfig.maxGuar + 1);


        //是否符合combo次数控牌规则
        int[] comboSteps = battleConfig.comboSteps;
        int comboLimitHandleNum = battleConfig.comboLimitHandleNum;
        int allComboCardNum = 0;
        for (int i = 0; i < comboLimitHandleNum; i++)
        {
            allComboCardNum += comboSteps[i % comboSteps.Length];
        }
        triggerComboLimit = allComboCardNum >= comboLimitHandleNum;
        initComboSteps = comboSteps;

        InitCards();

        // foreach (var item in DeskCardsHash)
        // {
        //     string str = "";
        //     foreach (var node in item.Value.childNodes)
        //     {
        //         str += $"{node.id},";
        //     }
        //     Debug.LogError($"{item.Key} => {str}");
        // }

        var tempDeskCards = new List<CardData>();
        var tempHandCards = new List<CardData>();
        foreach (var pair in AllCardsDic)
        {
            if (DeskCards.Contains(pair.Key))
                tempDeskCards.Add(pair.Value);
            if (HandCards.Contains(pair.Key))
                tempHandCards.Add(pair.Value);
        }
        InitBattleCommand t = new InitBattleCommand();
        t.Init(tempDeskCards, tempHandCards, isMovingScene);
        renderQueue.Enqueue(t);
        FlopAllTopCard();
        // CheckGreenLeaf();
        CheckActivity(ActivityType.limitPk);
        CheckSpecialCardTip();
        FlopHandCard();
        CheckItem(battleConfig.itemList); //检查开局道具
        CheckActivity(ActivityType.rabbitGift);
        // CheckWinStreakCards(battleCnf.winStreakCards);
        CheckWinStreakCards(battleCnf.winStreakCards);

        CheckGreenLeaf();
        CheckAutoUseFuncCard();
        FlopAllTopCard();

        var opt = new SystemStartOpt();
        RecordOperation(opt);

        TypeEventSystem.Send<ComboChangeEvent>(new ComboChangeEvent(0, 0, initComboSteps.Length > 0 ? initComboSteps[0] : 0, new List<bool>()));
    }

    private CardData CreateNewCardData(CardModel cm, bool createObb, bool render = true)
    {
        CardData card;
        if (createObb)
        {
            var width = battleConfig.cardWidth;
            var height = battleConfig.cardHeight;
            if (cm.cardType == CardType.TwoValue)
            {
                width *= Constants.TwoValueCardSizeScale.x;
                height *= Constants.TwoValueCardSizeScale.y;
            }
            OBB obb = CardData.CreateObb(cm, width, height);
            card = new CardData(cm.id, cm, obb);
        }
        else
            card = new CardData(cm.id, cm);
        AllCardsDic.Add(cm.id, card);
        if (render)
        {
            NewCreateCardCommand t = GameObjManager.Instance.PopClass<NewCreateCardCommand>(true);
            t.Init(card.id, card, battleConfig.cardBackId, battleConfig.betValue);
            renderQueue.Enqueue(t);
        }
        return card;
    }

    private void InitCards()
    {
        LevelModel levelModel = battleConfig.levelModel;
        isMovingScene = levelModel.settings.moving_scene;
        //生成桌面牌
        var maxX = int.MinValue;
        var minX = int.MaxValue;
        AllCardsDic.Clear();
        if (isMovingScene)
        {
            foreach (CardModel cm in levelModel.cards)
            {
                minX = Mathf.Min(minX, cm.x);
            }
            movingSceneBeginX = minX;
            // var offset = minX - movingSceneBeginX;
            // foreach (CardModel cm in levelModel.cards)
            // {
            //     cm.x -= offset;
            // }
        }

        CardAutoId = int.MinValue;
        Array.Sort(levelModel.cards, (a, b) => a.depth.CompareTo(b.depth));
        foreach (CardModel cm in levelModel.cards)
        {
            CardData card = CreateNewCardData(cm, true, false);
            DeskCardsAdd(card.id);
            if (card.id > CardAutoId)
                CardAutoId = card.id;
            if (isMovingScene && cm.x >= movingSceneValidX)
            {
                card.IsLocked = true;
                maxX = Mathf.Max(maxX, cm.x);
            }
        }

        //生成手牌
        int handCardNum = levelModel.settings.cards_in_stack.Length;
        for (int i = 0; i < handCardNum; i++)
        {
            var value = levelModel.settings.cards_in_stack[i];
            var cm = new CardModel(++CardAutoId, CardType.Value, value == -1, value, false);
            HandCardsAdd(CreateNewCardData(cm, false).id);
        }

        //为已经翻开的随机桌面牌定值
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (!card.IsLocked && (card.cm.faceUp || CheckTopCard(card)) && card.cm.random)
            {
                switch (card.CardType)
                {
                    case CardType.Value:
                        int value = GenDeskCardValue(cardId);
                        card.cm.SetValue(value);
                        card.Value = value;
                        break;
                    case CardType.Gold:
                        card.cm.suit = GameUtils.RandomRange(0, 4);
                        break;
                    case CardType.Monochrome:
                        card.cm.suit = GameUtils.RandomRange(0, 2);
                        break;
                    case CardType.TwoValue:
                        int value1 = GenDeskCardValue(cardId);
                        card.cm.SetValue(value1);
                        card.Value = value1;
                        int value2 = GenDeskCardValue(cardId);
                        card.cm.SetValue2(value2);
                        card.Value2 = value2;
                        break;
                    case CardType.Rudder:
                        card.cm.suit = GameUtils.RandomRange(0, 2);
                        break;
                }
                card.cm.random = false;
            }
            NewCreateCardCommand t = GameObjManager.Instance.PopClass<NewCreateCardCommand>(true);
            t.Init(card.id, card, battleConfig.cardBackId, battleConfig.betValue);
            renderQueue.Enqueue(t);
        }


        if (isMovingScene)
        {
            var startPos = new Vector3(movingSceneBeginX, 0, movingSceneZ);
            var endPos = new Vector3(maxX, 0, movingSceneZ);
            renderQueue.Enqueue(new AddMoveSceneCammand(startPos, endPos));
        }

        if (levelModel.locks != null && levelModel.locks.Length > 0)
        {
            for (int i = 0; i < levelModel.locks.Length; i++)
            {
                renderQueue.Enqueue(new AddLockItemCammand(levelModel.locks[i]));
            }
        }

        //初始化石头牌
        InitDeskAnchorCards();



    }

    private void InitDeskAnchorCards()
    {
        var waterNumber = 0;
        var anchorCards = new List<CardData>();
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (card.CardType == CardType.Anchor)
                anchorCards.Add(card);
            if (card.HasWater())
                waterNumber++;
            if (card.HasTask())
            {
                taskTotalNumber++;
                taskLeftNumber++;
            }
        }
        var anchorNumber = anchorCards.Count();

        if (anchorNumber == 0)
            return;

        List<int> parts = new List<int>();
        int baseValue = waterNumber / anchorNumber;
        int remainder = waterNumber % anchorNumber;
        for (int i = 0; i < anchorNumber; i++)
        {
            parts.Add(baseValue);
        }
        for (int i = 0; i < remainder; i++)
        {
            parts[i]++;
        }
        for (int i = 0; i < anchorNumber; i++)
        {
            anchorCards[i].SetWaterTotal(parts[i]);
        }
        RefreshAnchorCardCommand cmd = GameObjManager.Instance.PopClass<RefreshAnchorCardCommand>(true);
        cmd.Init(anchorCards, false, false);
        renderQueue.Enqueue(cmd);
    }


    void InsertGraphNode(CardNode new_node)
    {
        DeskCardsHash.Add(new_node.id, new_node);
        var ids = DeskCardsHash.Keys.ToList();
        foreach (var id in ids)
        {
            BuildGraph(DeskCardsHash[id], new_node, false);
        }
    }

    void RemoveGraphNode(int cardId)
    {
        var rem_node = DeskCardsHash[cardId];
        var ids = DeskCardsHash.Keys.ToList();
        foreach (var id in ids)
        {
            if (id != cardId)
            {
                if (DeskCardsHash[id].childNodes.Contains(rem_node))
                    DeskCardsHash[id].childNodes.Remove(rem_node);
                if (DeskCardsHash[id].parentNodes.Contains(rem_node))
                    DeskCardsHash[id].parentNodes.Remove(rem_node);
            }
        }
        DeskCardsHash.Remove(cardId);
    }

    void BuildGraph(CardNode root_node, CardNode new_node, bool isChild)
    {
        if (root_node.id == new_node.id)
            return;

        CardData rootCard = AllCardsDic[root_node.id];
        CardData newCard = AllCardsDic[new_node.id];

        if (!isChild && OBBCollision.GetCollision(rootCard.obb, newCard.obb))
        {
            if (newCard.cm.depth < rootCard.cm.depth)
            {
                if (!new_node.childNodes.Contains(root_node))
                    new_node.childNodes.Add(root_node);
                if (!root_node.parentNodes.Contains(new_node))
                    root_node.parentNodes.Add(new_node);
            }
            else if (newCard.cm.depth > rootCard.cm.depth)
            {
                if (!root_node.childNodes.Contains(new_node))
                    root_node.childNodes.Add(new_node);
                if (!new_node.parentNodes.Contains(root_node))
                    new_node.parentNodes.Add(root_node);
            }
            else
            {
                Debug.LogError($"出现层级一样且碰撞的牌 {root_node.id} {new_node.id}");
            }
        }

        // for (int i = 0; i < root_node.childNodes.Count; i++)
        // {
        //     CardNode child_node = root_node.childNodes[i];
        //     CardData childCard = AllCardsDic[child_node.id];
        //     if (new_node.id != child_node.id && OBBCollision.GetCollision(newCard.obb, childCard.obb))
        //     {
        //         if (newCard.cm.depth < childCard.cm.depth)
        //         {
        //             if (!new_node.childNodes.Contains(child_node))
        //                 new_node.childNodes.Add(child_node);
        //             if (!child_node.parentNodes.Contains(new_node))
        //                 child_node.parentNodes.Add(new_node);
        //         }
        //         else if (newCard.cm.depth > childCard.cm.depth)
        //         {
        //             if (!child_node.childNodes.Contains(new_node))
        //                 child_node.childNodes.Add(new_node);
        //             if (!new_node.parentNodes.Contains(child_node))
        //                 new_node.parentNodes.Add(child_node);
        //         }
        //         else
        //         {
        //             Debug.LogError($"出现层级一样且碰撞的牌 {new_node.id} {child_node.id}");
        //         }
        //         BuildGraph(child_node, new_node, true);
        //     }
        // }
    }

    private void DeskCardsAdd(int cardId)
    {
        if (DeskCardsHash.ContainsKey(cardId))
        {
            // Debug.LogError("=== 同一张牌添加了两次！！！！");
            return;
        }
        DeskCards.Add(cardId);
        CardData card = AllCardsDic[cardId];

        if (card.CardType == CardType.Value && card.Value > -1 && card.IsFaceup)
            BitUtils.Flag(ref faceupValueCardBit, card.Value);

        if (card.CardType == CardType.Monkey)
            monkeyCards.Add(card);
        else if (card.CardType == CardType.Banana)
            bananaCards.Add(card);

        InsertGraphNode(new CardNode() { id = cardId });
    }

    private void DeskCardsRemove(int cardId, bool combo = true)
    {
        if (DeskCardsHash.ContainsKey(cardId))
        {
            DeskCards.Remove(cardId);
            var carddata = AllCardsDic[cardId];
            var cardType = carddata.CardType;
            if (cardType == CardType.Value)
                BitUtils.UnFlag(ref faceupValueCardBit, carddata.Value);

            if (combo)
            {
                if (cardType == CardType.Joker)
                    AddCombo(carddata, true);
                else if (cardType == CardType.Value ||
                         cardType == CardType.Gold ||
                         cardType == CardType.TwoValue ||
                         cardType == CardType.Monochrome)
                    AddCombo(carddata);
            }

            RemoveGraphNode(cardId);
        }
    }

    private void HandCardsAdd(int cardId)
    {
        HandCards.Add(cardId);
    }

    private void HandCardsInsert(int idx, int cardId)
    {
        if (idx >= HandCards.Count)
            HandCards.Add(cardId);
        else
            HandCards.Insert(idx, cardId);
    }

    private void HandCardsRemove(int cardId)
    {
        HandCards.Remove(cardId);
        ReprotNoHandCard();
        CardData card = AllCardsDic[cardId];
        if (card.CardType == CardType.Value && card.Value > -1)
            BitUtils.Flag(ref faceupValueCardBit, card.Value);
        if (CurHandCard != null)
        {
            if (CurHandCard.CardType == CardType.Value && CurHandCard.Value > -1)
                BitUtils.UnFlag(ref faceupValueCardBit, CurHandCard.Value);
        }
    }

    private void OpenCardsAdd(int cardId)
    {
        OpenCards.Add(cardId);
        ReprotNoHandCard();
    }


    public bool CheckBingo(CardData deskCard, CardData handCard)
    {
        if (deskCard == null || handCard == null)
            return false;
        if (deskCard.CardType == CardType.Value)
        {
            if (deskCard.HasCloth() && !deskCard.IsClothOpen())
                return false;
            if (deskCard.HasMagicCloth() && !deskCard.IsClothOpen())
                return false;
            if (deskCard.HasSuitRope())
                return false;
            if (deskCard.HasLinkRope() && !deskCard.CanRemoveLinkRope())
                return false;
            if (deskCard.HasBird())
                return false;

            switch (handCard.CardType)
            {
                case CardType.Joker:
                    return true;
                case CardType.Value:
                    var val = Math.Abs(deskCard.Value - handCard.Value) % Constants.ValueCardCount13;
                    return val == 1 || val == Constants.ValueCardCount13 - 1;
                case CardType.TwoValue:
                    var val1 = Math.Abs(deskCard.Value - handCard.Value) % Constants.ValueCardCount13;
                    var val2 = Math.Abs(deskCard.Value - handCard.Value2) % Constants.ValueCardCount13;
                    return (val1 == 1 || val1 == Constants.ValueCardCount13 - 1) || (val2 == 1 || val2 == Constants.ValueCardCount13 - 1);
                case CardType.Gold:
                    return deskCard.Value / Constants.ValueCardCount13 == handCard.cm.suit;
                case CardType.Monochrome:
                    var _suit = deskCard.Value / Constants.ValueCardCount13;
                    if (handCard.cm.suit == 0)
                    {
                        return _suit == 0 || _suit == 2;
                    }
                    else if (handCard.cm.suit == 1)
                    {
                        return _suit == 1 || _suit == 3;
                    }
                    return false;
            }

        }
        else if (deskCard.CardType == CardType.TwoValue)
        {
            switch (handCard.CardType)
            {
                case CardType.Joker:
                    return true;
                case CardType.Value:
                    var val1 = Math.Abs(deskCard.Value - handCard.Value) % Constants.ValueCardCount13;
                    var val2 = Math.Abs(deskCard.Value2 - handCard.Value) % Constants.ValueCardCount13;
                    return (val1 == 1 || val1 == Constants.ValueCardCount13 - 1) || (val2 == 1 || val2 == Constants.ValueCardCount13 - 1);
                case CardType.TwoValue:
                    var val11 = Math.Abs(deskCard.Value - handCard.Value) % Constants.ValueCardCount13;
                    var val12 = Math.Abs(deskCard.Value - handCard.Value2) % Constants.ValueCardCount13;
                    var val21 = Math.Abs(deskCard.Value2 - handCard.Value) % Constants.ValueCardCount13;
                    var val22 = Math.Abs(deskCard.Value2 - handCard.Value2) % Constants.ValueCardCount13;
                    return (val11 == 1 || val11 == Constants.ValueCardCount13 - 1) ||
                        (val12 == 1 || val12 == Constants.ValueCardCount13 - 1) ||
                        (val21 == 1 || val21 == Constants.ValueCardCount13 - 1) ||
                        (val22 == 1 || val22 == Constants.ValueCardCount13 - 1);
                case CardType.Gold:
                    return deskCard.Value / Constants.ValueCardCount13 == handCard.cm.suit ||
                        deskCard.Value2 / Constants.ValueCardCount13 == handCard.cm.suit;
                case CardType.Monochrome:
                    var _suit1 = deskCard.Value / Constants.ValueCardCount13;
                    var _suit2 = deskCard.Value2 / Constants.ValueCardCount13;
                    if (handCard.cm.suit == 0)
                    {
                        return _suit1 == 0 || _suit1 == 2 || _suit2 == 0 || _suit2 == 2;
                    }
                    else if (handCard.cm.suit == 1)
                    {
                        return _suit1 == 1 || _suit1 == 3 || _suit2 == 1 || _suit2 == 3;
                    }
                    return false;
            }
        }
        else if (deskCard.CardType == CardType.Gold)
        {
            switch (handCard.CardType)
            {
                case CardType.Joker:
                    return true;
                case CardType.Value:
                    return handCard.Value / Constants.ValueCardCount13 == deskCard.cm.suit;
                case CardType.TwoValue:
                    return handCard.Value / Constants.ValueCardCount13 == deskCard.cm.suit ||
                     handCard.Value2 / Constants.ValueCardCount13 == deskCard.cm.suit;
                case CardType.Gold:
                    return deskCard.cm.suit == handCard.cm.suit;
                case CardType.Monochrome:
                    if (handCard.cm.suit == 0)
                    {
                        return deskCard.cm.suit == 0 || deskCard.cm.suit == 2;
                    }
                    else if (handCard.cm.suit == 1)
                    {
                        return deskCard.cm.suit == 1 || deskCard.cm.suit == 3;
                    }
                    return false;
            }

        }
        else if (deskCard.CardType == CardType.Monochrome)
        {
            switch (handCard.CardType)
            {
                case CardType.Joker:
                    return true;
                case CardType.Value:
                    var _suit = handCard.Value / Constants.ValueCardCount13;
                    if (deskCard.cm.suit == 0)
                    {
                        return _suit == 0 || _suit == 2;
                    }
                    else if (deskCard.cm.suit == 1)
                    {
                        return _suit == 1 || _suit == 3;
                    }
                    return false;

                case CardType.TwoValue:
                    var _suit1 = handCard.Value / Constants.ValueCardCount13;
                    var _suit2 = handCard.Value2 / Constants.ValueCardCount13;
                    if (deskCard.cm.suit == 0)
                    {
                        return _suit1 == 0 || _suit1 == 2 || _suit2 == 0 || _suit2 == 2;
                    }
                    else if (deskCard.cm.suit == 1)
                    {
                        return _suit1 == 1 || _suit1 == 3 || _suit2 == 1 || _suit2 == 3;
                    }
                    return false;

                case CardType.Gold:
                    if (deskCard.cm.suit == 0)
                    {
                        return handCard.cm.suit == 0 || handCard.cm.suit == 2;
                    }
                    else if (deskCard.cm.suit == 1)
                    {
                        return handCard.cm.suit == 1 || handCard.cm.suit == 3;
                    }
                    return false;

                case CardType.Monochrome:
                    return deskCard.cm.suit == handCard.cm.suit;
            }
        }

        return false;
    }

    public void TouchCard(int cardId)
    {
        CardData card = AllCardsDic[cardId];
        if (DeskCardsHash.ContainsKey(cardId))
        {
            if (!card.IsLocked)
                TouchDeskCard(card);
        }
        else if (HandCards.Count > 0 && HandCards[0] == cardId)
        {
            TouchHandCard();
        }
        else
        {
            Debug.LogError($"=== TouchCard {cardId}");
        }
        // else if (DeskCards.Contains(cardId) && !card.IsLocked)
        // {
        //     TouchDeskCard(card);
        // }
        // else if (CurHandCard != null && CurHandCard.id == cardId)
        // {
        //     CurHandCard.cm.PrintInfo();
        // }
    }

    public bool IsTopHandCard(int cardId)
    {
        return HandCards.Count > 0 && HandCards[0] == cardId;
    }

    public bool CheckWin()
    {
        return !happendBigBomb && DeskCards.Count == 0 && !aborted;
    }

    public int GetDeskCardsNum()
    {
        return DeskCards.Count;
    }

    public int GetHandCardsNum()
    {
        return HandCards.Count;
    }

    private void RecordOperation(IBattleOperation opt)
    {
        opt.comboStepIdx = comboStepIdx;
        opt.comboColorList = new List<bool>(comboColorList);

        if (ComboCount == 0)
        {
            comboColorList.Clear();
            optComboColorList.Clear();
        }
        SendComboEvent(false);
        optComboColorList.Clear();

        opt.RenderQueue = renderQueue;
        renderQueue.Clear();
        OperatStack.Push(opt);
        TypeEventSystem.Send<OperatCommandEvent>(new OperatCommandEvent(opt));
        TypeEventSystem.Send<UpdateUndoBtnState>();
    }

    private void UndoOperation(IBattleOperation lastOpt)
    {
        SendComboEvent(true, lastOpt);
        var opt = new UndoOpt();
        opt.RenderQueue = renderQueue;
        renderQueue.Clear();
        TypeEventSystem.Send<OperatCommandEvent>(new OperatCommandEvent(opt));
    }

    private void SendComboEvent(bool undo, IBattleOperation lastOpt = null)
    {
        if (initComboSteps.Length == 0)
            return;
        int stepIdx = comboStepIdx;
        if (undo)
        {
            var lastStepIdx = comboStepIdx;
            var lastColorList = new List<bool>(comboColorList);
            if (OperatStack.Count > 0)
            {
                comboStepIdx = lastOpt.comboStepIdx;
                comboColorList = lastOpt.comboColorList;
            }
            optComboColorList.Clear();

            for (int i = lastStepIdx; i > comboStepIdx; i--)
            {
                UndoComboCards();
            }

            List<bool> colors = new List<bool>();
            colors.AddRange(comboColorList);
            var comboLimit = initComboSteps[initComboSteps.Length - 1];
            if (comboStepIdx < initComboSteps.Length)
            {
                comboLimit = initComboSteps[comboStepIdx];
            }

            renderQueue.Enqueue(new ComboViewCommand(comboStepIdx, colors.Count, comboLimit, colors));
            // TypeEventSystem.Send<ComboChangeEvent>(new ComboChangeEvent(comboStepIdx, colors.Count, comboLimit, colors));

            var undoComboNumer = 0;
            if (lastStepIdx > comboStepIdx)
            {
                var _comboLimit = initComboSteps[initComboSteps.Length - 1];
                if (comboStepIdx < initComboSteps.Length)
                {
                    _comboLimit = initComboSteps[comboStepIdx];
                }
                bool sameColor = true;
                // foreach (var c in comboColorList)
                // {
                //     if (c != comboColorList[0])
                //     {
                //         sameColor = false;
                //         break;
                //     }
                // }
                sameColor = false; //屏蔽同色combo
                ActivityManager.Instance.SubCombo(comboLimit, sameColor);
                Controller.BattleCtrl.gameData.SubBigCombo(comboStepIdx + 1);

                undoComboNumer = _comboLimit - comboColorList.Count;
                undoComboNumer += lastColorList.Count;
                for (int i = lastStepIdx - 1; i > comboStepIdx; i--)
                {
                    _comboLimit = initComboSteps[initComboSteps.Length - 1];
                    if (i < initComboSteps.Length)
                    {
                        _comboLimit = initComboSteps[i];
                    }
                    undoComboNumer += _comboLimit;
                }
            }
            else
            {
                undoComboNumer = lastColorList.Count - comboColorList.Count;
            }

            for (int i = 0; i < undoComboNumer; i++)
            {
                int level = Controller.BattleCtrl.gameData.Level;
                int comboRewardNum = configService.GetComboReward(level, ComboCount) * dataService.NowBet;
                dataService.ConsumeCoin(comboRewardNum, PropChangeWay.Combo);
                if (ComboCount > 0)
                {
                    Controller.BattleCtrl.gameData.SubSmallCombo(ComboCount);
                    ComboCount--;
                }

            }
        }
        else
        {
            int comboCount = comboColorList.Count + optComboColorList.Count;
            if (comboCount > 0)
            {
                while (comboCount > 0)
                {
                    List<bool> colors = new List<bool>();
                    colors.AddRange(comboColorList);
                    var comboLimit = initComboSteps[initComboSteps.Length - 1];
                    if (stepIdx < initComboSteps.Length)
                    {
                        comboLimit = initComboSteps[stepIdx];
                    }

                    if (comboCount >= comboLimit)
                    {
                        for (int i = colors.Count; i < comboLimit; i++)
                        {
                            colors.Add(optComboColorList[0]);
                            optComboColorList.RemoveAt(0);
                        }
                        bool sameColor = true;
                        // foreach (var c in colors)
                        // {
                        //     if (c != colors[0])
                        //     {
                        //         sameColor = false;
                        //         break;
                        //     }
                        // }
                        sameColor = false; //屏蔽同色combo

                        ActivityManager.Instance.AddCombo(comboLimit, sameColor);
                        Controller.BattleCtrl.gameData.AddBigCombo(stepIdx + 1);

                        renderQueue.Enqueue(new ComboViewCommand(stepIdx, comboLimit, comboLimit, colors));
                        // TypeEventSystem.Send<ComboChangeEvent>(new ComboChangeEvent(stepIdx, comboLimit, comboLimit, colors));
                        stepIdx++;
                        comboCount -= comboLimit;
                        comboColorList.Clear();

                        comboLimit = initComboSteps[initComboSteps.Length - 1];
                        if (stepIdx < initComboSteps.Length)
                        {
                            comboLimit = initComboSteps[stepIdx];
                        }
                        renderQueue.Enqueue(new ComboViewCommand(stepIdx, 0, comboLimit, new List<bool>()));
                        // TypeEventSystem.Send<ComboChangeEvent>(new ComboChangeEvent(stepIdx, 0, comboLimit, new List<bool>()));
                    }
                    else
                    {
                        for (int i = colors.Count; i < comboCount; i++)
                        {
                            colors.Add(optComboColorList[0]);
                            comboColorList.Add(optComboColorList[0]);
                            optComboColorList.RemoveAt(0);
                        }
                        renderQueue.Enqueue(new ComboViewCommand(stepIdx, comboCount, comboLimit, colors));
                        // TypeEventSystem.Send<ComboChangeEvent>(new ComboChangeEvent(stepIdx, comboCount, comboLimit, colors));
                        break;
                    }
                }
            }
            else
            {
                var comboLimit = initComboSteps[initComboSteps.Length - 1];
                if (comboStepIdx < initComboSteps.Length)
                {
                    comboLimit = initComboSteps[comboStepIdx];
                }
                renderQueue.Enqueue(new ComboViewCommand(stepIdx, 0, comboLimit, new List<bool>()));
            }
            comboStepIdx = stepIdx;
        }
    }

    private void TouchDeskCard(CardData targetCard)
    {
        targetCard.cm.PrintInfo();
        targetCard.PrintInfo();

        var topCards = new List<int>();
        var rlCards = new List<int>();
        foreach (var cardId in DeskCards)
        {
            if (AllCardsDic.ContainsKey(cardId) && targetCard.id != cardId)
            {
                var card = AllCardsDic[cardId];
                if (card.IsFaceup)
                {
                    if (CheckTopCard(card))
                        topCards.Add(cardId);
                    if (card.HasRising() || card.HasLowering())
                        rlCards.Add(cardId);
                }
            }
        }

        IBattleOperation opt = null;
        if (CheckTopCard(targetCard))
        {
            switch (targetCard.CardType)
            {
                case CardType.Joker:
                    // opt = new CollectCardOpt(targetCard.id);
                    opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                    opt.SetHandCardNumber(HandCards.Count);
                    CollectJokerCard(targetCard);
                    break;

                case CardType.Value:
                    if (CheckBingo(targetCard, CurHandCard))
                    {
                        opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                        opt.SetHandCardNumber(HandCards.Count);
                        var _opt = opt as ClickDeskCardOpt;
                        if (targetCard.HasIce())
                        {
                            _opt.AddCard(CurHandCard);
                            targetCard.BreakIce();
                            AddCombo(targetCard);
                            renderQueue.Enqueue(new BreakIceByHandCardCommand(targetCard));
                            OpenCardsRemove();
                        }
                        else
                        {
                            CollectValueCard(targetCard);
                        }
                    }
                    else
                    {
                        TypeEventSystem.Send<RenderCommandEvent>(
                            new RenderCommandEvent(new ShakeCardCommand(targetCard)));
                    }
                    break;

                case CardType.TwoValue:
                    if (CheckBingo(targetCard, CurHandCard))
                    {
                        opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                        opt.SetHandCardNumber(HandCards.Count);
                        // opt = new CollectCardOpt(targetCard.id);
                        CollectTwovalueCard(targetCard);
                    }
                    else
                    {
                        TypeEventSystem.Send<RenderCommandEvent>(
                            new RenderCommandEvent(new ShakeCardCommand(targetCard)));
                    }
                    break;

                case CardType.Gold:
                    if (CheckBingo(targetCard, CurHandCard))
                    {
                        opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                        opt.SetHandCardNumber(HandCards.Count);
                        // opt = new CollectCardOpt(targetCard.id);
                        CollectGoldCard(targetCard);
                    }
                    else
                    {
                        TypeEventSystem.Send<RenderCommandEvent>(
                            new RenderCommandEvent(new ShakeCardCommand(targetCard)));
                    }
                    break;

                case CardType.Monochrome:
                    if (CheckBingo(targetCard, CurHandCard))
                    {
                        opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                        opt.SetHandCardNumber(HandCards.Count);
                        // opt = new CollectCardOpt(targetCard.id);
                        CollectMonochromeCard(targetCard);
                    }
                    else
                    {
                        TypeEventSystem.Send<RenderCommandEvent>(
                            new RenderCommandEvent(new ShakeCardCommand(targetCard)));
                    }
                    break;

                case CardType.Boom:
                    opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                    opt.SetHandCardNumber(HandCards.Count);
                    if (CollectBoomCard(targetCard))
                    {
                    }
                    break;

                case CardType.Windmill:
                    CollectWindmillCard(targetCard, out List<CardData> flyCards);
                    opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                    opt.SetHandCardNumber(HandCards.Count);
                    break;

                case CardType.Zap:
                    opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                    opt.SetHandCardNumber(HandCards.Count);
                    if (CollectZapCard(targetCard))
                    {
                    }
                    break;

                case CardType.Key:
                    opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                    opt.SetHandCardNumber(HandCards.Count);
                    var lockCard = CollectKeyCard(targetCard);
                    if (lockCard != null)
                    {
                        var _opt = opt as ClickDeskCardOpt;
                        _opt.AddCard(lockCard);
                    }
                    else
                    {
                        opt = null;
                    }
                    break;

                case CardType.Three:
                    opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                    opt.SetHandCardNumber(HandCards.Count);
                    CollectThreeCard(targetCard);
                    break;

                case CardType.Copy:
                    if (CurHandCard.CardType == CardType.Value)
                    {
                        opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                        opt.SetHandCardNumber(HandCards.Count);
                        // opt = new ClickCopyCardOpt(targetCard);
                        CollectCopyCard(targetCard);
                    }
                    else
                    {
                        TypeEventSystem.Send<RenderCommandEvent>(new RenderCommandEvent(new ShakeCardCommand(targetCard)));
                    }
                    break;

                case CardType.Monkey:
                    if (CollectMonkeyCard(targetCard, out CardData matchCard1))
                    {
                        opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                        opt.SetHandCardNumber(HandCards.Count);
                        // opt = new ClickMonkeyBananaCardOpt(targetCard, matchCard1);
                    }
                    else
                    {
                        TypeEventSystem.Send<RenderCommandEvent>(
                            new RenderCommandEvent(new ShakeCardCommand(targetCard)));
                    }
                    break;

                case CardType.Banana:
                    if (CollectBananaCard(targetCard, out CardData matchCard2))
                    {
                        opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                        opt.SetHandCardNumber(HandCards.Count);
                        //opt = new ClickMonkeyBananaCardOpt(targetCard, matchCard2);
                    }
                    else
                    {
                        TypeEventSystem.Send<RenderCommandEvent>(
                            new RenderCommandEvent(new ShakeCardCommand(targetCard)));
                    }
                    break;

                case CardType.Rudder:
                    opt = new ClickDeskCardOpt(++Round, targetCard.id, AllCardsDic, DeskCards);
                    opt.SetHandCardNumber(HandCards.Count);
                    if (CollectRudderCard(targetCard))
                    {
                    }
                    break;
            }
        }

        var lizardRemoveCards = new List<int>();
        while (lizardCards.Count > 0)
        {
            var _lizardRemoveCards = new List<int>();
            List<int> tempCards = new List<int>();
            foreach (var cardId in DeskCards)
            {
                if (AllCardsDic.ContainsKey(cardId))
                {
                    var card = AllCardsDic[cardId];
                    if (targetCard.id != cardId && CanBeBlowAway(card) && !card.HasLinkRope())
                    {
                        if (card.IsFaceup && CheckTopCard(card))
                        {
                            tempCards.Add(cardId);
                        }
                    }
                }
            }
            GameUtils.Shuffle(tempCards);
            for (int i = 0; i < lizardCards.Count; i++)
            {
                if (i < tempCards.Count)
                {
                    _lizardRemoveCards.Add(tempCards[i]);
                }
            }
            foreach (var cardId in _lizardRemoveCards)
            {
                DeskCardsRemove(cardId);
                DiscCards.Add(cardId);
            }
            renderQueue.Enqueue(new LizardCardCommand(lizardCards, _lizardRemoveCards));
            lizardRemoveCards.AddRange(_lizardRemoveCards);
            lizardCards.Clear();
            foreach (var cardId in _lizardRemoveCards)
            {
                var card = AllCardsDic[cardId];
                if (card.HasLizard())
                {
                    lizardCards.Add(card.id);
                }
            }
        }

        var roundAddCards = new List<int>();
        foreach (var cardId in DeskCards)
        {
            if (AllCardsDic.ContainsKey(cardId) && targetCard.id != cardId && !lizardRemoveCards.Contains(cardId))
            {
                var card = AllCardsDic[cardId];
                if (card.IsFaceup)
                {
                    if (rlCards.Contains(cardId))
                    {
                        roundAddCards.Add(cardId);
                    }
                    else if (topCards.Contains(cardId))
                    {
                        roundAddCards.Add(cardId);
                    }
                }
            }
        }

        CheckAutoUseFuncCard();

        if (opt != null)
        {
            opt.SetOpenCardNumber(OpenCards.Count);
            if (OpenCards.Count == 0 && HandCards.Count > 0)
                FlopHandCard();
            AddRound(roundAddCards);
            RecordOperation(opt);
        }

        CheckPlayCardLoopSound();
        if (CheckWin())
        {
            renderQueue.Enqueue(new ShowResultCommand(true));
            var sysOpt = new SystemOverOpt { RenderQueue = renderQueue };
            renderQueue.Clear();
            TypeEventSystem.Send<OperatCommandEvent>(new OperatCommandEvent(sysOpt));
        }
    }

    private int? OpenCardsRemove()
    {
        if (OpenCards.Count == 0) return null;
        var cardId = OpenCards[OpenCards.Count - 1];
        OpenCards.Remove(cardId);
        DiscCards.Add(cardId);
        return cardId;
    }

    private void CollectTwovalueCard(CardData targetCard)
    {
        handCardWasted = 0;
        DeskCardsRemove(targetCard.id);
        OpenCardsAdd(targetCard.id);
        CollectDeskCardCommand t = GameObjManager.Instance.PopClass<CollectDeskCardCommand>(true);
        t.Init(targetCard);
        renderQueue.Enqueue(t);

        CheckSuitRope(targetCard, targetCard);
    }

    private void CollectValueCard(CardData targetCard)
    {
        handCardWasted = 0;
        lastCard = targetCard;
        DeskCardsRemove(targetCard.id);
        OpenCardsAdd(targetCard.id);

        CollectDeskCardCommand t = GameObjManager.Instance.PopClass<CollectDeskCardCommand>(true);
        t.Init(targetCard);
        renderQueue.Enqueue(t);

        CheckCollectedValueCard(targetCard);

        if (targetCard.HasLinkRope() && targetCard.CanRemoveLinkRope())
        {
            var linkCard = AllCardsDic[targetCard.cm.LinkRopeCardId];
            lastCard = linkCard;
            DeskCardsRemove(linkCard.id);
            OpenCardsAdd(linkCard.id);
            CollectLinkCardCommand cmd = GameObjManager.Instance.PopClass<CollectLinkCardCommand>(true);
            cmd.Init(targetCard, linkCard);
            renderQueue.Enqueue(cmd);
        }

        CheckSuitRope(targetCard, targetCard);

        if (targetCard.HasTask())
        {
            taskLeftNumber--;
        }
    }

    private void CollectGoldCard(CardData targetCard)
    {
        DeskCardsRemove(targetCard.id);
        OpenCardsAdd(targetCard.id);
        CollectDeskCardCommand t = GameObjManager.Instance.PopClass<CollectDeskCardCommand>(true);
        t.Init(targetCard);
        renderQueue.Enqueue(t);

        CheckSuitRope(targetCard, targetCard);
    }

    private void CollectMonochromeCard(CardData targetCard)
    {
        DeskCardsRemove(targetCard.id);
        OpenCardsAdd(targetCard.id);
        CollectDeskCardCommand t = GameObjManager.Instance.PopClass<CollectDeskCardCommand>(true);
        t.Init(targetCard);
        renderQueue.Enqueue(t);

        CheckSuitRope(targetCard, targetCard);
    }

    private void CollectJokerCard(CardData targetCard)
    {
        DeskCardsRemove(targetCard.id);
        OpenCardsAdd(targetCard.id);
        CollectDeskCardCommand t = GameObjManager.Instance.PopClass<CollectDeskCardCommand>(true);
        t.Init(targetCard);
        renderQueue.Enqueue(t);
    }

    private bool CollectBoomCard(CardData targetCard)
    {
        var boomCenter = new Vector2(targetCard.cm.x, targetCard.cm.y);
        var boomFlyCards = new List<CardData>();
        var iceCards = new List<CardData>();
        var suitCards = new List<CardData>();
        var removeModCards = new List<CardData>();
        var boomRange = battleConfig.cardHeight * 2;
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (cardId != targetCard.id)
            {
                if (Vector2.Distance(new Vector2(card.cm.x, card.cm.y), boomCenter) <= boomRange)
                {
                    if (CanBeBlowAway(card))
                    {
                        boomFlyCards.Add(card);
                    }
                    else
                    {
                        if (CheckTopCard(card))
                        {
                            if (card.HasIce())
                            {
                                iceCards.Add(card);
                            }
                            else if (card.HasSuitRope())
                            {
                                suitCards.Add(card);
                            }
                            else if (card.HasBomb() || card.HasBigBomb() || card.HasLightning())
                            {
                                removeModCards.Add(card);
                            }
                        }
                    }
                }
            }
        }
        var newCards = new List<CardData>();
        foreach (var card in boomFlyCards)
        {
            if (card.HasLinkRope() && card.CanRemoveLinkRope())
            {
                var linkCardId = card.GetLinkRopeCardId();
                bool flag = boomFlyCards.Any(item => item.id == linkCardId);
                newCards.Add(AllCardsDic[linkCardId]);
            }
        }
        boomFlyCards.AddRange(newCards);
        SpecailDeskCardNumber -= boomFlyCards.Count;
        DeskCardsRemove(targetCard.id);
        DiscCards.Add(targetCard.id);
        if (boomFlyCards.Count > 0)
        {
            boomFlyCards.Sort((a, b) =>
            {
                Vector2 aPos = new Vector2(a.cm.x, a.cm.y);
                Vector2 bPos = new Vector2(b.cm.x, b.cm.y);
                return Vector2.Distance(aPos, boomCenter).CompareTo(Vector2.Distance(bPos, boomCenter));
            });

            for (int i = 0; i < boomFlyCards.Count; i++)
            {
                CardData card = boomFlyCards[i];
                DeskCardsRemove(card.id);
                DiscCards.Add(card.id);
            }
        }

        renderQueue.Enqueue(new BoomCardCommand(targetCard, boomFlyCards));

        if (iceCards.Count > 0)
        {
            foreach (var card in iceCards)
            {
                card.BreakIce();
                AddCombo(card);
                renderQueue.Enqueue(new IceBrokenCommand(card));
            }
        }

        if (suitCards.Count > 0)
        {
            foreach (var card in suitCards)
            {
                card.RemoveOneRopeSuit();
            }
            renderQueue.Enqueue(new RopeSuitUpdateCommand(suitCards, false));
        }

        if (removeModCards.Count > 0)
        {
            foreach (var card in removeModCards)
            {
                card.RemoveAllModifier();
            }
            renderQueue.Enqueue(new RemoveModifierCommand(removeModCards));
        }

        foreach (var card in boomFlyCards)
        {
            CheckSuitRope(targetCard, card);
            CheckCollectedValueCard(card, true);
        }

        return boomFlyCards.Count > 0;
    }

    //是否可以被吹走
    private bool CanBeBlowAway(CardData card, bool isWindmill = false)
    {
        if (card.IsLocked)
            return false;

        if (!CheckTopCard(card))
            return false;

        if (card.CardType == CardType.TwoValue ||
            card.CardType == CardType.Gold ||
            card.CardType == CardType.Monochrome)
            return true;

        if (card.CardType == CardType.Value)
        {
            if (card.HasBird())
                return false;

            if (card.HasCloth() && !card.IsClothOpen())
                return false;

            if (card.HasMagicCloth() && !card.IsClothOpen())
                return false;

            if (card.HasLinkRope() && !card.CanRemoveLinkRope())
                return false;

            if (!isWindmill)
            {
                if (card.HasIce())
                    return false;
                if (card.HasSuitRope())
                    return false;
                if (card.HasBomb())
                    return false;
                if (card.HasBigBomb())
                    return false;
                if (card.HasLightning())
                    return false;
            }

            return true;
        }

        return false;
    }

    private void CheckCollectedValueCard(CardData card, bool skipAnim = false)
    {
        if (card.HasWater())
        {
            CardData anchorCard = null;
            var len = float.MaxValue;
            foreach (var _cardId in DeskCards)
            {
                CardData _card = AllCardsDic[_cardId];
                if (_card.CardType == CardType.Anchor)
                {
                    float _len = Vector3.Distance(card.cm.Position, _card.cm.Position);
                    if (_len < len)
                    {
                        len = _len;
                        anchorCard = _card;
                    }
                }
            }
            if (anchorCard != null)
            {
                var broken = anchorCard.CollectWaterAndBreak();
                RefreshAnchorCardCommand cmd = GameObjManager.Instance.PopClass<RefreshAnchorCardCommand>(true);
                cmd.Init(new List<CardData>() { anchorCard }, false, skipAnim);
                renderQueue.Enqueue(cmd);
                if (broken)
                {
                    DeskCardsRemove(anchorCard.id);
                    DiscCards.Add(anchorCard.id);
                    renderQueue.Enqueue(new AnchorCardCommand(anchorCard));
                }
            }
        }
        else if (card.HasLizard())
        {
            lizardCards.Add(card.id);
        }
    }

    private void CollectWindmillCard(CardData targetCard, out List<CardData> windmillFlyCards)
    {
        windmillFlyCards = new List<CardData>();
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (cardId != targetCard.id)
            {
                if (CanBeBlowAway(card, true))
                {
                    windmillFlyCards.Add(card);
                }
            }
        }

        // foreach (var wmFlyCard in windmillFlyCards)
        //     OpenCardsAdd(wmFlyCard.id);

        SpecailDeskCardNumber -= windmillFlyCards.Count;
        DeskCardsRemove(targetCard.id);
        renderQueue.Enqueue(
            new WindmillCardCommand(targetCard, windmillFlyCards));

        foreach (var card in windmillFlyCards)
        {
            DeskCardsRemove(card.id);
        }

        foreach (var card in windmillFlyCards)
        {
            CheckSuitRope(targetCard, card);
            CheckCollectedValueCard(card, true);
        }
    }

    private bool CollectZapCard(CardData targetCard)
    {
        var zapFlyCards = new List<CardData>();
        var iceCards = new List<CardData>();
        var suitCards = new List<CardData>();
        var removeModCards = new List<CardData>();
        var zapRange = battleConfig.cardHeight;
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (cardId != targetCard.id)
            {
                if (Mathf.Abs(card.cm.y - targetCard.cm.y) <= zapRange)
                {
                    if (CanBeBlowAway(card))
                    {
                        zapFlyCards.Add(card);
                    }
                    else
                    {
                        if (CheckTopCard(card))
                        {
                            if (card.HasIce())
                            {
                                iceCards.Add(card);
                            }
                            else if (card.HasSuitRope())
                            {
                                suitCards.Add(card);
                            }
                            else if (card.HasBomb() || card.HasBigBomb() || card.HasLightning())
                            {
                                removeModCards.Add(card);
                            }
                        }
                    }
                }
            }
        }
        var newCards = new List<CardData>();
        foreach (var card in zapFlyCards)
        {
            if (card.HasLinkRope() && card.CanRemoveLinkRope())
            {
                var linkCardId = card.GetLinkRopeCardId();
                bool flag = zapFlyCards.Any(item => item.id == linkCardId);
                newCards.Add(AllCardsDic[linkCardId]);
            }
        }

        zapFlyCards.AddRange(newCards);
        SpecailDeskCardNumber -= zapFlyCards.Count;

        float zapFormX = 1000;
        float speed = 2200 / 1.2f;
        DeskCardsRemove(targetCard.id);
        zapFlyCards.Sort((a, b) => b.cm.x.CompareTo(a.cm.x));
        List<float> delayList = new List<float>(zapFlyCards.Count);
        float lastZapCardTime = 0f;
        for (int i = 0; i < zapFlyCards.Count; i++)
        {
            CardData card = zapFlyCards[i];
            DeskCardsRemove(card.id);
            float zapDelayTime = 1 + (zapFormX - card.cm.x) / speed;
            delayList.Add(zapDelayTime - lastZapCardTime);
            lastZapCardTime = zapDelayTime;
        }

        renderQueue.Enqueue(new ZapCardCommand(targetCard, zapFlyCards));

        if (iceCards.Count > 0)
        {
            foreach (var card in iceCards)
            {
                card.BreakIce();
                AddCombo(card);
                renderQueue.Enqueue(new IceBrokenCommand(card));
            }
        }

        if (suitCards.Count > 0)
        {
            foreach (var card in suitCards)
            {
                card.RemoveOneRopeSuit();
            }
            renderQueue.Enqueue(new RopeSuitUpdateCommand(suitCards, false));
        }

        if (removeModCards.Count > 0)
        {
            foreach (var card in removeModCards)
            {
                card.RemoveAllModifier();
            }
            renderQueue.Enqueue(new RemoveModifierCommand(removeModCards));
        }

        foreach (var card in zapFlyCards)
        {
            CheckSuitRope(targetCard, card);
            CheckCollectedValueCard(card, true);
        }

        return zapFlyCards.Count > 0;
    }

    private bool CollectRudderCard(CardData targetCard)
    {
        var rudderCenter = new Vector2(targetCard.cm.x, targetCard.cm.y);
        var rudderFlyCards = new List<CardData>();
        var targetColor = targetCard.GetCardColor();
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (cardId != targetCard.id)
            {
                if (card.GetCardColor() == targetColor && CanBeBlowAway(card, true))
                {
                    rudderFlyCards.Add(card);
                }
            }
        }
        var newCards = new List<CardData>();
        foreach (var card in rudderFlyCards)
        {
            if (card.HasLinkRope() && card.CanRemoveLinkRope())
            {
                var linkCardId = card.GetLinkRopeCardId();
                bool flag = rudderFlyCards.Any(item => item.id == linkCardId);
                newCards.Add(AllCardsDic[linkCardId]);
            }
        }
        rudderFlyCards.AddRange(newCards);
        SpecailDeskCardNumber -= rudderFlyCards.Count;
        DeskCardsRemove(targetCard.id);
        DiscCards.Add(targetCard.id);
        if (rudderFlyCards.Count > 0)
        {
            rudderFlyCards.Sort((a, b) =>
            {
                Vector2 aPos = new Vector2(a.cm.x, a.cm.y);
                Vector2 bPos = new Vector2(b.cm.x, b.cm.y);
                return Vector2.Distance(aPos, rudderCenter).CompareTo(Vector2.Distance(bPos, rudderCenter));
            });

            for (int i = 0; i < rudderFlyCards.Count; i++)
            {
                CardData card = rudderFlyCards[i];
                DeskCardsRemove(card.id);
                DiscCards.Add(card.id);
            }
        }

        renderQueue.Enqueue(new RudderCardCommand(targetCard, rudderFlyCards));

        foreach (var card in rudderFlyCards)
        {
            CheckSuitRope(targetCard, card);
            CheckCollectedValueCard(card, true);
        }

        return rudderFlyCards.Count > 0;
    }

    private CardData CollectKeyCard(CardData targetCard)
    {
        float minDis = int.MaxValue;
        CardData targetLockCard = null;
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (card.CardType == CardType.Lock && card.IsFaceup && CheckTopCard(card) && !card.IsLocked)
            {
                var dis = Vector3.Distance(targetCard.cm.Position, card.cm.Position);
                if (dis <= minDis)
                {
                    targetLockCard = card;
                    minDis = dis;
                }
            }
        }
        if (targetLockCard == null)
        {
            return null;
        }

        DeskCardsRemove(targetCard.id);
        DiscCards.Add(targetCard.id);
        DeskCardsRemove(targetLockCard.id);
        DiscCards.Add(targetLockCard.id);

        renderQueue.Enqueue(new UnlockCardCommand(targetCard, new List<CardData>() { targetLockCard }));
        FlopAllTopCard();
        return targetLockCard;
    }

    //检测添加丰收牌
    private void CollectThreeCard(CardData targetCard)
    {
        DeskCardsRemove(targetCard.id);
        DiscCards.Add(targetCard.id);
        var newCards = new List<int>();
        var count = Math.Max(targetCard.Value, 1);
        count = Math.Min(count, 5);
        for (int i = 0; i < count; i++)
        {
            var cm = new CardModel(++CardAutoId, CardType.Value);
            var newCard = CreateNewCardData(cm, false);
            newCard.FromId = targetCard.id;
            newCards.Add(newCard.id);
        }

        SpecailHandCardNumber += count;

        foreach (var cardid in newCards)
        {
            HandCardsAdd(cardid);
        }

        renderQueue.Enqueue(new ThreeCardCommand(targetCard.id, newCards, HandCards));
        FlopAllTopCard();
    }

    private void CollectQuestionCard(CardData targetCard)
    {
        DeskCardsRemove(targetCard.id);
        DiscCards.Add(targetCard.id);

        Tuple<CardType, ModifierType> newType = configService.GetQuestionCard();
        // newType = new Tuple<CardType, ModifierType>(CardType.Value, ModifierType.Lightning);
        var cm = new CardModel(++CardAutoId, newType.Item1, faceUp: true, x: targetCard.cm.x, y: targetCard.cm.y,
                    depth: targetCard.cm.depth, angle: targetCard.cm.angle);
        if (newType.Item1 == CardType.Value)
        {
            int value = GenDeskCardValue(cm.id);
            cm.SetValue(value);
            if (newType.Item2 == ModifierType.Bomb)
            {
                cm.BombTimer = 5;
            }
            else if (newType.Item2 == ModifierType.BigBomb)
            {
                cm.BigBombTimer = 5;
            }
            else if (newType.Item2 == ModifierType.Lightning)
            {
                cm.LightningTimer = 5;
            }
            else if (newType.Item2 == ModifierType.Cloth || newType.Item2 == ModifierType.MagicCloth)
            {
                cm.SetClothTimer(newType.Item2, 1);
            }
            else if (newType.Item2 != ModifierType.None)
            {
                cm.SetModifier(newType.Item2);
            }
        }
        else if (newType.Item1 == CardType.Three)
        {
            cm.SetValue(2);
        }
        else if (newType.Item1 == CardType.Gold)
        {
            int value = GameUtils.RandomRange(0, 4);
            cm.suit = value;
            cm.random = false;
        }
        else if (newType.Item1 == CardType.Monochrome)
        {
            int value = GameUtils.RandomRange(0, 2);
            cm.suit = value;
            cm.random = false;
        }
        CardData newCard = CreateNewCardData(cm, true);
        newCard.FromId = targetCard.id;
        DeskCardsAdd(newCard.id);

        renderQueue.Enqueue(new QuestionCardCommand(targetCard.id, newCard.id));
    }

    private void CollectCopyCard(CardData targetCard)
    {
        targetCard.cm.cardType = CardType.Value;
        targetCard.cm.random = false;
        targetCard.cm.SetValue(CurHandCard.Value);
        targetCard.cm.faceUp = true;

        renderQueue.Enqueue(
            new CopyCardCommand(targetCard));
    }

    private bool CollectBananaCard(CardData targetCard, out CardData shortestCard)
    {
        var openMonkeys = new List<CardData>();
        foreach (var monkey in monkeyCards)
        {
            if (monkey.IsFaceup)
            {
                openMonkeys.Add(monkey);
            }
        }

        float shortestDis = -1;
        shortestCard = null;
        if (openMonkeys.Count > 0)
        {
            foreach (var openMonk in openMonkeys)
            {
                float dis = Vector2.Distance(new Vector2(openMonk.cm.x, openMonk.cm.y), new Vector2(targetCard.cm.x, targetCard.cm.y));
                if (shortestDis < 0 || shortestDis > dis)
                {
                    shortestDis = dis;
                    shortestCard = openMonk;
                }
            }

            if (shortestCard != null)
            {
                bananaCards.Remove(targetCard);
                monkeyCards.Remove(shortestCard);
                DeskCardsRemove(targetCard.id);
                DeskCardsRemove(shortestCard.id);
                renderQueue.Enqueue(
                    new MonkeyBananaCardCommand(targetCard, shortestCard));
                return true;
            }
            else
            {
                Debug.LogError($">>>BattleDataMgr  >>CollectBananaCard  >Error");
            }
        }

        return false;
    }

    private bool CollectMonkeyCard(CardData targetCard, out CardData shortestCard)
    {
        var openBananas = new List<CardData>();
        foreach (var banana in bananaCards)
        {
            if (banana.IsFaceup)
            {
                openBananas.Add(banana);
            }
        }

        float shortestDis = -1;
        shortestCard = null;
        if (openBananas.Count > 0)
        {
            foreach (var openBana in openBananas)
            {
                float dis = Vector2.Distance(new Vector2(openBana.cm.x, openBana.cm.y), new Vector2(targetCard.cm.x, targetCard.cm.y));
                if (shortestDis == -1 || shortestDis > dis)
                {
                    shortestDis = dis;
                    shortestCard = openBana;
                }
            }

            if (shortestCard != null)
            {
                monkeyCards.Remove(targetCard);
                bananaCards.Remove(shortestCard);
                DeskCardsRemove(targetCard.id);
                DeskCardsRemove(shortestCard.id);
                renderQueue.Enqueue(
                    new MonkeyBananaCardCommand(targetCard, shortestCard));
                return true;
            }
            else
            {
                Debug.LogError($">>>BattleDataMgr  >>CollectMonkeyCard  >Error");
            }
        }
        return false;
    }

    private void TouchHandCard()
    {
        // if (CurHandCard.CardType == CardType.Joker)
        //     return;
        if(!dataService.IsOverRookie() && AIAction_BestCard() != -1)
        {
            return;
        }

        var roundAddCards = new List<int>();
        foreach (var cardId in DeskCards)
        {
            if (AllCardsDic.ContainsKey(cardId))
            {
                var card = AllCardsDic[cardId];
                if (card.IsFaceup)
                {
                    if (card.HasRising() || card.HasLowering())
                    {
                        roundAddCards.Add(cardId);
                    }
                    else if (CheckTopCard(card))
                    {
                        roundAddCards.Add(cardId);
                    }
                }
            }
        }

        var opt = new FlopHandCardOpt(++Round, HandCards[0], AllCardsDic, DeskCards);
        opt.SetHandCardNumber(HandCards.Count);
        FlopHandCard(opt);
        isMissComboFlag = IsMissCombo();
        var roundAddCards2 = new List<int>();
        foreach (var cardId in roundAddCards)
        {
            if (DeskCardsHash.ContainsKey(cardId))
            {
                roundAddCards2.Add(cardId);
            }
        }
        AddRound(roundAddCards2);
        opt.SetOpenCardNumber(OpenCards.Count);
        RecordOperation(opt);

        CheckAutoUseFuncCard();
        CheckPlayCardLoopSound();
        if (CheckWin())
        {
            renderQueue.Enqueue(new ShowResultCommand(true));
            var sysOpt = new SystemOverOpt { RenderQueue = renderQueue };
            renderQueue.Clear();
            TypeEventSystem.Send<OperatCommandEvent>(new OperatCommandEvent(sysOpt));
        }
    }

    private void AddRound(List<int> roundAddCards = null)
    {
        var nowDeskCards = new List<int>();
        if (roundAddCards == null)
            nowDeskCards = new List<int>(DeskCards);
        else
            nowDeskCards = roundAddCards;

        var bombCards = new List<int>();//炮仗牌最后爆
        foreach (var cardId in nowDeskCards)
        {
            if (AllCardsDic.ContainsKey(cardId))
            {
                var card = AllCardsDic[cardId];
                if (card.IsFaceup)
                {
                    if (card.HasRising() || card.HasLowering())
                    {
                        card.AddRound();
                    }
                    else if (CheckTopCard(card))
                    {
                        if (card.HasBomb())
                            bombCards.Add(card.id);
                        else
                            card.AddRound();
                    }
                }
            }
        }
        foreach (var cardId in bombCards)
        {
            var card = AllCardsDic[cardId];
            card.AddRound();
        }
        FlopAllTopCard();
        CheckGreenLeaf();
    }

    private void SubRound(IBattleOperation opt)
    {
        CardData optCard = null;
        var lastRoundAllCards = opt.allCardData;
        var lastRoundDeskCards = opt.deskCards;
        if (lastRoundAllCards.ContainsKey(opt.cardId))
        {
            optCard = lastRoundAllCards[opt.cardId];
        }
        var nowDeskCards = new List<int>(DeskCards);
        bool birdFlyOut = false;
        bool birdFlyMove = false;
        Vector3 birdFlyTo = Vector3.zero;

        //遍历上一轮的桌面牌，回滚位置
        if (isMovingScene)
        {
            var cardList = new List<CardData>();
            foreach (var cardId in lastRoundDeskCards)
            {
                if (DeskCards.Contains(cardId))
                {
                    AllCardsDic[cardId].IsLocked = lastRoundAllCards[cardId].IsLocked;
                    AllCardsDic[cardId].cm = lastRoundAllCards[cardId].cm.DeepCopy();
                    AllCardsDic[cardId].obb = lastRoundAllCards[cardId].obb;
                    cardList.Add(AllCardsDic[cardId]);
                }
            }
            renderQueue.Enqueue(new UndoMoveSceneCammand(cardList));
        }

        foreach (var cardId in nowDeskCards)
        {
            //遍历现在的桌面牌，找出上一轮同一张牌进行回退
            if (AllCardsDic.ContainsKey(cardId))
            {
                if (lastRoundAllCards.ContainsKey(cardId))
                {
                    var lastRoundCard = lastRoundAllCards[cardId];
                    var thisRoundCard = AllCardsDic[cardId];

                    if (thisRoundCard.IsFaceup)
                    {
                        if (thisRoundCard.HasRising() || thisRoundCard.HasLowering())
                        {
                            if (lastRoundCard.IsFaceup)
                            {
                                thisRoundCard.Value = lastRoundCard.Value;
                                if (thisRoundCard.HasRising())
                                    BattleDataMgr.Instance.AddRenderCommand(new RisingUpdateCommand(new List<CardData>() { thisRoundCard }, true));
                                else if (thisRoundCard.HasLowering())
                                    BattleDataMgr.Instance.AddRenderCommand(new LoweringUpdateCommand(new List<CardData>() { thisRoundCard }, true));
                            }
                        }
                        else
                        {
                            if (thisRoundCard.HasCloth() || thisRoundCard.HasMagicCloth())
                            {
                                if (thisRoundCard.clothOpen != lastRoundCard.clothOpen || thisRoundCard.clothTimer != lastRoundCard.clothTimer)
                                {
                                    thisRoundCard.clothOpen = lastRoundCard.clothOpen;
                                    thisRoundCard.clothTimer = lastRoundCard.clothTimer;
                                    BattleDataMgr.Instance.AddRenderCommand(new ClothRoundUpdateCommand(new List<CardData>() { thisRoundCard }));
                                }
                            }
                        }
                    }

                    //翻牌
                    if (!lastRoundCard.IsFaceup && thisRoundCard.IsFaceup)
                    {
                        FlopDeskCardCommand t = GameObjManager.Instance.PopClass<FlopDeskCardCommand>(true);
                        thisRoundCard.IsFaceup = false;
                        t.Init(thisRoundCard);
                        renderQueue.Enqueue(t);
                    }
                    else
                    {
                        //绿叶瓢虫回退
                        if (thisRoundCard.HasGreenLeaf())
                        {
                            if (thisRoundCard.HasBird())
                            {
                                thisRoundCard.UndoUpdateBirdInterval();
                                if (!lastRoundCard.HasBird())
                                {
                                    birdFlyOut = true;
                                    thisRoundCard.SetBirdState(false);
                                }
                            }
                            if (lastRoundCard.HasBird() && !thisRoundCard.HasBird())
                            {
                                foreach (var _cardId in DeskCards)
                                {
                                    CardData _card = AllCardsDic[_cardId];
                                    if (_card.HasGreenLeaf())
                                    {
                                        _card.SetBirdState(false);
                                    }
                                }
                                thisRoundCard.SetBirdState(true);
                                birdFlyMove = true;
                                birdFlyTo = thisRoundCard.cm.Position;
                                birdFlyTo.z = thisRoundCard.cm.depth - 0.1f;
                            }
                        }
                        //冰冻回退
                        if (lastRoundCard.HasIce() && !thisRoundCard.HasIce())
                        {
                            var _opt = opt as ClickDeskCardOpt;
                            if (_opt.cardId == lastRoundCard.id) //上一把是点击冰冻牌
                            {
                                if (_opt.openCardNumber == 0)
                                {
                                    var nowOpenCardId = OpenCards.Last();
                                    HandCards.Insert(0, nowOpenCardId);
                                    OpenCards.Remove(nowOpenCardId);
                                    renderQueue.Enqueue(new UndoFlopHandCardCommand(HandCards));
                                }
                                var openCard = AllCardsDic[_opt.cardList[0].id];
                                OpenCardsAdd(openCard.id);
                                DiscCards.Remove(openCard.id);
                                thisRoundCard.UndoBreakIce();
                                renderQueue.Enqueue(new UndoBreakIceCommand(lastRoundCard, openCard));
                            }
                            else
                            {
                                thisRoundCard.UndoBreakIce();
                                renderQueue.Enqueue(new UndoBreakIceCommand(lastRoundCard, null));
                            }
                        }
                        //闪电回退
                        if (thisRoundCard.HasLightning())
                        {
                            if (thisRoundCard.LightningTimer != lastRoundCard.LightningTimer)
                            {
                                if (thisRoundCard.LightningTimer > lastRoundCard.LightningTimer)
                                {
                                    if (opt.handCardNumber > 0)
                                    {
                                        DoLightning(thisRoundCard, true);
                                    }
                                }
                                thisRoundCard.SetLightningTimer(lastRoundCard.LightningTimer);
                                AddRenderCommand(new LightningUpdateCommand(new List<CardData>() { thisRoundCard }));
                            }
                        }
                        else if (lastRoundCard.HasLightning() && !thisRoundCard.HasLightning())
                        {
                            thisRoundCard.RecycleLightning();
                            renderQueue.Enqueue(new RecycleModifierCommand(thisRoundCard));
                        }
                        //石头牌回退
                        if (thisRoundCard.CardType == CardType.Anchor)
                        {
                            if (thisRoundCard.WaterNumber != lastRoundCard.WaterNumber)
                            {
                                thisRoundCard.UndoCollectWater();
                                RefreshAnchorCardCommand cmd = GameObjManager.Instance.PopClass<RefreshAnchorCardCommand>(true);
                                cmd.Init(new List<CardData>() { lastRoundCard }, true, false);
                                renderQueue.Enqueue(cmd);
                            }
                        }
                        //花绳子牌回退
                        if (thisRoundCard.HasSuitRope() && thisRoundCard.IsFaceup)
                        {
                            if (lastRoundCard.IsFaceup)
                            {
                                thisRoundCard.SuitRopeStates = new Dictionary<int, bool>();
                                foreach (var item in lastRoundCard.SuitRopeStates)
                                {
                                    thisRoundCard.SuitRopeStates.Add(item.Key, item.Value);
                                }
                                renderQueue.Enqueue(new RefreshSuitRopeCommand(thisRoundCard));
                            }
                        }
                        if (!thisRoundCard.HasSuitRope() && lastRoundCard.HasSuitRope())
                        {
                            thisRoundCard.SuitRopeStates = new Dictionary<int, bool>();
                            foreach (var item in lastRoundCard.SuitRopeStates)
                            {
                                thisRoundCard.SuitRopeStates.Add(item.Key, item.Value);
                            }
                            renderQueue.Enqueue(new RecycleModifierCommand(thisRoundCard));
                            renderQueue.Enqueue(new RefreshSuitRopeCommand(thisRoundCard));
                        }
                        //定时炮仗回退
                        if (thisRoundCard.HasBomb())
                        {
                            if (thisRoundCard.BombTimer < lastRoundCard.BombTimer)
                            {
                                thisRoundCard.UpdateBomb(true);
                                renderQueue.Enqueue(new BombUpdateCommand(new List<CardData>() { thisRoundCard }));
                            }
                        }
                        else if (!thisRoundCard.HasBomb() && lastRoundCard.HasBomb())
                        {
                            thisRoundCard.RecycleBomb();
                            if (lastRoundCard.BombTimer == 1) //倒计时结束回退
                                thisRoundCard.UpdateBomb(true);
                            renderQueue.Enqueue(new RecycleModifierCommand(thisRoundCard));
                            if (thisRoundCard.BombTimer == 1)
                            {
                                var bombCards = new List<int>();
                                foreach (var _cardId in DeskCards)
                                {
                                    CardData _card = AllCardsDic[_cardId];
                                    if (_card.FromId == thisRoundCard.id)
                                    {
                                        bombCards.Add(_card.id);
                                    }
                                }
                                foreach (var _cardId in bombCards)
                                {
                                    DeskCardsRemove(_cardId, false);
                                }
                                renderQueue.Enqueue(new UndoBombUpdateCommand(thisRoundCard.id, bombCards));
                            }
                            renderQueue.Enqueue(new BombUpdateCommand(new List<CardData>() { thisRoundCard }));
                        }
                        //大爆炸回退
                        if (thisRoundCard.HasBigBomb())
                        {
                            if (thisRoundCard.BigBombTimer < lastRoundCard.BigBombTimer)
                            {
                                thisRoundCard.UpdateBigBomb(true);
                                renderQueue.Enqueue(new BigBombUpdateCommand(new List<CardData>() { thisRoundCard }));
                            }
                        }
                        else if (!thisRoundCard.HasBigBomb() && lastRoundCard.HasBigBomb())
                        {
                            thisRoundCard.RecycleBigBomb();
                            renderQueue.Enqueue(new RecycleModifierCommand(thisRoundCard));
                        }
                    }

                }
                else
                {
                }
            }
        }

        //遍历上一轮的桌面牌，找出消除的牌
        foreach (var cardId in lastRoundDeskCards)
        {
            if (!DeskCards.Contains(cardId))
            {
                var lastRoundCard = lastRoundAllCards[cardId];
                //石头牌回退
                if (lastRoundCard.CardType == CardType.Anchor)
                {
                    DeskCardsAdd(cardId);
                    DiscCards.Remove(cardId);
                    renderQueue.Enqueue(new RestoreDeskCardCommand(new List<CardData>() { lastRoundCard }));
                    var thisRoundCard = AllCardsDic[cardId];
                    thisRoundCard.UndoCollectWater();
                    RefreshAnchorCardCommand cmd = GameObjManager.Instance.PopClass<RefreshAnchorCardCommand>(true);
                    cmd.Init(new List<CardData>() { lastRoundCard }, true, false);
                    renderQueue.Enqueue(cmd);
                }
                else if (lastRoundCard.CardType == CardType.Three)//丰收牌回退
                {
                    DeskCardsAdd(cardId);
                    DiscCards.Remove(cardId);
                    renderQueue.Enqueue(new RestoreDeskCardCommand(new List<CardData>() { lastRoundCard }));

                    var removeCards = new List<int>();
                    foreach (var _cardId in HandCards)
                    {
                        if (AllCardsDic[_cardId].FromId == cardId)
                        {
                            removeCards.Add(_cardId);
                        }
                    }
                    if (removeCards.Count > 0)
                    {
                        foreach (var _cardId in removeCards)
                        {
                            HandCards.Remove(_cardId);
                        }
                        renderQueue.Enqueue(new RemoveHandCardCommand(removeCards));
                    }
                }
                else if (lastRoundCard.CardType == CardType.Question)//问号牌回退
                {
                    bool find = false;
                    foreach (var _cardId in nowDeskCards)
                    {
                        if (AllCardsDic[_cardId].FromId == cardId)
                        {
                            find = true;
                            DeskCardsRemove(_cardId, false);
                            DiscCards.Add(_cardId);
                            DeskCardsAdd(cardId);
                            DiscCards.Remove(cardId);
                            renderQueue.Enqueue(new UndoQuestionCardCommand(cardId, _cardId));
                            break;
                        }
                    }
                    if (find == false)
                    {
                        for (int i = DiscCards.Count - 1; i >= 0; i--)
                        {
                            int _cardId = DiscCards[i];
                            if (AllCardsDic[_cardId].FromId == cardId)
                            {
                                DeskCardsRemove(_cardId, false);
                                DiscCards.Add(_cardId);
                                DeskCardsAdd(cardId);
                                DiscCards.Remove(cardId);
                                renderQueue.Enqueue(new UndoQuestionCardCommand(cardId, _cardId));

                                if (AllCardsDic[_cardId].CardType == CardType.Three)
                                {
                                    var removeCards = new List<int>();
                                    foreach (var __cardId in HandCards)
                                    {
                                        if (AllCardsDic[__cardId].FromId == _cardId)
                                        {
                                            removeCards.Add(__cardId);
                                        }
                                    }
                                    if (removeCards.Count > 0)
                                    {
                                        foreach (var __cardId in removeCards)
                                        {
                                            HandCards.Remove(__cardId);
                                        }
                                        renderQueue.Enqueue(new RemoveHandCardCommand(removeCards));
                                    }
                                }

                                break;
                            }
                        }
                    }
                }
            }
        }

        //回退上一轮操作的特殊牌
        if (optCard != null)
        {
            if (optCard.CardType == CardType.Zap || optCard.CardType == CardType.Boom || optCard.CardType == CardType.Rudder)
            {
                DiscCards.Remove(optCard.id);
                var addDeskCards = new List<CardData>();
                foreach (var cardId in lastRoundDeskCards)
                {
                    if (!DeskCards.Contains(cardId) && AllCardsDic.ContainsKey(cardId))
                    {
                        addDeskCards.Add(AllCardsDic[cardId]);
                    }
                }
                if (addDeskCards.Count > 0)
                {
                    foreach (var card in addDeskCards)
                    {
                        DeskCardsAdd(card.id);
                    }
                    renderQueue.Enqueue(new RestoreDeskCardCommand(addDeskCards));
                }
            }
            else if (optCard.CardType == CardType.Key)
            {
                var _opt = opt as ClickDeskCardOpt;
                var lockCard = AllCardsDic[_opt.cardList[0].id];
                DiscCards.Remove(opt.cardId);
                DiscCards.Remove(lockCard.id);
                DeskCardsAdd(opt.cardId);
                DeskCardsAdd(lockCard.id);
                var addDeskCards = new List<int>();
                addDeskCards.Add(opt.cardId);
                addDeskCards.Add(lockCard.id);
                renderQueue.Enqueue(new UndoKeyLockCardCommand(addDeskCards));
            }
            else if (optCard.CardType == CardType.Value && optCard.HasLinkRope())
            {
                var linkCardId = optCard.GetLinkRopeCardId();
                DeskCardsAdd(optCard.id);
                DeskCardsAdd(linkCardId);
                OpenCards.Remove(linkCardId);
                OpenCards.Remove(optCard.id);
                renderQueue.Enqueue(new UndoLinkCardCommand(lastRoundAllCards[optCard.id], lastRoundAllCards[linkCardId]));
                // CheckLinkRope();
            }
            else if (optCard.CardType == CardType.Value && optCard.HasLizard())
            {
                var addDeskCards = new List<CardData>();
                foreach (var cardId in lastRoundDeskCards)
                {
                    if (!DeskCards.Contains(cardId) && AllCardsDic.ContainsKey(cardId))
                    {
                        addDeskCards.Add(AllCardsDic[cardId]);
                    }
                }
                if (addDeskCards.Count > 0)
                {
                    foreach (var card in addDeskCards)
                    {
                        DeskCardsAdd(card.id);
                    }
                    renderQueue.Enqueue(new RestoreDeskCardCommand(addDeskCards));
                }
            }
        }
        if (birdFlyMove)
        {
            renderQueue.Enqueue(new FlyBirdCommand(birdFlyTo));
        }
        else
        {
            if (birdFlyOut)
            {
                renderQueue.Enqueue(new FlyBirdCommand(GameObjTransInfo.BirdPos));
            }
        }
    }

    //翻开所有最上层的牌
    void FlopAllTopCard()
    {
        var cards = new List<CardData>();
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (!card.IsLocked && !card.IsFaceup && CheckTopCard(card))
            {
                AllCardsDic[cardId].IsFaceup = true;
                cards.Add(card);
            }
        }

        foreach (var card in cards)
        {
            card.IsFaceup = true;

            bool genValue = false;
            if (card.cm.random)
            {
                if (card.CardType == CardType.Value)
                {
                    int value = GenDeskCardValue(card.cm.id);
                    card.cm.SetValue(value);
                    card.Value = value;
                    // Debug.LogError($"=========== FlopAllTopCard {card.cm.id}:{card.cm.GetValue()},{card.Value}  {AllCardsDic[card.cm.id].Value}");
                    genValue = true;
                }
                else if (card.CardType == CardType.Gold)
                {
                    int value = GameUtils.RandomRange(0, 4);
                    card.cm.suit = value;
                    genValue = true;
                }
                else if (card.CardType == CardType.Monochrome)
                {
                    int value = GameUtils.RandomRange(0, 2);
                    card.cm.suit = value;
                    genValue = true;
                }
                else if (card.CardType == CardType.TwoValue)
                {
                    if (card.Value == -1)
                    {
                        int value = GenDeskCardValue(card.cm.id);
                        card.cm.SetValue(value);
                        card.Value = value;
                        genValue = true;
                    }
                    if (card.Value2 == -1)
                    {
                        int value = GenDeskCardValue(card.cm.id);
                        card.cm.SetValue2(value);
                        card.Value2 = value;
                        genValue = true;
                    }
                }
                else if (card.CardType == CardType.Rudder)
                {
                    int value = GameUtils.RandomRange(0, 4);
                    card.cm.suit = value;
                    genValue = true;
                }
            }
            if (genValue)
            {
                card.cm.random = false;
                RefreshCardValueCommand t = GameObjManager.Instance.PopClass<RefreshCardValueCommand>(true);
                t.Init(card);
                renderQueue.Enqueue(t);
            }

            FlopDeskCardCommand t1 = GameObjManager.Instance.PopClass<FlopDeskCardCommand>(true);
            t1.Init(card);
            renderQueue.Enqueue(t1);
        }

        if (isMovingScene)
        {
            var minX = int.MaxValue;
            var maxX = int.MinValue;
            foreach (var id in DeskCards)
            {
                CardModel cm = AllCardsDic[id].cm;
                minX = Mathf.Min(cm.x, minX);
                maxX = Mathf.Max(cm.x, maxX);
            }
            if (minX > movingSceneBeginX && maxX >= movingSceneValidX)
            {
                var cardList = new List<CardData>();
                var dis1 = minX - movingSceneBeginX;
                var dis2 = maxX - movingSceneValidX;
                var dis = Mathf.Min(dis1, dis2);
                var flopCards = new List<CardData>();
                foreach (var id in DeskCards)
                {
                    CardData card = AllCardsDic[id];
                    card.cm.x -= dis;
                    var width = battleConfig.cardWidth;
                    var height = battleConfig.cardHeight;
                    if (card.cm.cardType == CardType.TwoValue)
                    {
                        width *= Constants.TwoValueCardSizeScale.x;
                        height *= Constants.TwoValueCardSizeScale.y;
                    }
                    card.obb = CardData.CreateObb(card.cm, width, height);
                    card.IsLocked = card.cm.x > movingSceneValidX;
                    cardList.Add(card);
                }
                renderQueue.Enqueue(new MoveSceneCammand(dis, cardList, dis2 <= dis1));

                foreach (var id in DeskCards)
                {
                    CardData card = AllCardsDic[id];
                    if (!card.IsFaceup && card.cm.x <= movingSceneValidX && CheckTopCard(card))
                    {
                        card.IsFaceup = true;
                        if (card.cm.random)
                        {
                            switch (card.CardType)
                            {
                                case CardType.Value:
                                    if (card.Value == -1)
                                    {
                                        int value = GenDeskCardValue(card.id);
                                        card.cm.SetValue(value);
                                        card.Value = value;
                                    }
                                    break;
                                case CardType.Gold:
                                    card.cm.suit = GameUtils.RandomRange(0, 4);
                                    break;
                                case CardType.Monochrome:
                                    card.cm.suit = GameUtils.RandomRange(0, 2);
                                    break;
                                case CardType.TwoValue:
                                    if (card.Value == -1)
                                    {
                                        int value = GenDeskCardValue(card.id);
                                        card.cm.SetValue(value);
                                        card.Value = value;
                                    }
                                    if (card.Value2 == -1)
                                    {
                                        int value = GenDeskCardValue(card.id);
                                        card.cm.SetValue2(value);
                                        card.Value2 = value;
                                    }
                                    break;
                            }
                            card.cm.random = false;
                            RefreshCardValueCommand t = GameObjManager.Instance.PopClass<RefreshCardValueCommand>(true);
                            t.Init(card);
                            renderQueue.Enqueue(t);
                        }
                        flopCards.Add(card);
                    }
                }
                foreach (var card in flopCards)
                {
                    FlopDeskCardCommand t1 = GameObjManager.Instance.PopClass<FlopDeskCardCommand>(true);
                    t1.Init(card);
                    renderQueue.Enqueue(t1);
                }
            }
        }

        CheckLinkRope();
    }

    //自动使用功能卡
    void CheckAutoUseFuncCard()
    {
        List<int> funcList = GetAllAutoFuncCard();
        while (funcList.Count > 0)
        {
            foreach (var cardId in funcList)
            {
                CardData card = AllCardsDic[cardId];
                if (card.CardType == CardType.Three)
                {
                    CollectThreeCard(card);
                    break;
                }
                else if (card.CardType == CardType.Question)
                {
                    CollectQuestionCard(card);
                    break;
                }
            }
            funcList = GetAllAutoFuncCard();
        }
    }

    //播放特色牌循环音效
    public void CheckPlayCardLoopSound()
    {
        bool hasPlay = false;
        foreach (var id in DeskCards)
        {
            CardData card = AllCardsDic[id];
            if (!card.IsTopCard() || card.IsLocked || !card.IsFaceup) continue;
            if (card.HasLightning())
            {
                SoundPlayer.Instance.PlayLoopSound("shandian_fx_01", 0f, true);
                hasPlay = true;
                break;
            }
            else if (card.HasBigBomb())
            {
                if (card.BigBombTimer <= 3)
                {
                    SoundPlayer.Instance.PlayLoopSound("bomb_ani_shake", 0f, true);
                }
                else
                {
                    SoundPlayer.Instance.PlayLoopSound("fx_huoguang", 0, true);
                }
                hasPlay = true;
                break;
            }
            else if (card.HasBomb())
            {
                SoundPlayer.Instance.PlayLoopSound("fx_huoguang", 0f, true);
                hasPlay = true;
                break;
            }
        }

        if (!hasPlay)
        {
            SoundPlayer.Instance.StopLoopSound();
        }
    }

    void CheckLinkRope()
    {
        Dictionary<int, bool> flags = new Dictionary<int, bool>();
        List<CardData> lockCards = new List<CardData>();
        List<CardData> unlockCards = new List<CardData>();
        foreach (var cardId in DeskCards)
        {
            if (flags.ContainsKey(cardId))
                continue;
            CardData card = AllCardsDic[cardId];
            if (card.HasLinkRope())
            {
                var linkRopeCardId = card.GetLinkRopeCardId();
                var linkRopeCard = AllCardsDic[linkRopeCardId];
                if (CheckTopCard(card) && CheckTopCard(linkRopeCard))
                {
                    unlockCards.Add(card);
                    unlockCards.Add(linkRopeCard);
                }
                else
                {
                    lockCards.Add(card);
                    lockCards.Add(linkRopeCard);
                }
                flags.Add(cardId, true);
                flags.Add(linkRopeCardId, true);
            }
        }
        if (lockCards.Count > 0 || unlockCards.Count > 0)
            renderQueue.Enqueue(new RefreshLinkRopeCommand(lockCards, unlockCards));
    }

    public bool CanRemoveLinkRope(int cardId)
    {
        CardData card = AllCardsDic[cardId];
        if (card != null)
        {
            var linkRopeCardId = card.GetLinkRopeCardId();
            var linkRopeCard = AllCardsDic[linkRopeCardId];
            if (!card.IsLocked && CheckTopCard(card) && !linkRopeCard.IsLocked && CheckTopCard(linkRopeCard))
            {
                return true;
            }
        }
        return false;
    }

    void CheckSuitRope(CardData overCard, CardData targetCard)
    {
        var ropeCards = new List<CardData>();
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            bool isOver = false;
            if (overCard != null && overCard.id != cardId)
            {
                if (OBBCollision.GetCollision(overCard.obb, card.obb) && card.cm.depth > overCard.cm.depth)
                {
                    isOver = true;
                }
            }

            if (!isOver && !card.IsLocked && CheckTopCard(card) && card.HasSuitRope())
            {
                bool matchSuit = false;
                if (targetCard.CardType == CardType.Value)
                {
                    matchSuit = card.CheckSuitRope(targetCard.Value / Constants.ValueCardCount13);
                }
                else if (targetCard.CardType == CardType.TwoValue)
                {
                    var matchSuit1 = card.CheckSuitRope(targetCard.Value / Constants.ValueCardCount13);
                    var matchSuit2 = card.CheckSuitRope(targetCard.Value2 / Constants.ValueCardCount13);
                    matchSuit = matchSuit1 || matchSuit2;
                }
                else if (targetCard.CardType == CardType.Gold)
                {
                    matchSuit = card.CheckSuitRope(targetCard.cm.suit);
                }
                else if (targetCard.CardType == CardType.Monochrome)
                {
                    if (targetCard.cm.suit == 0)
                    {
                        var matchSuit1 = card.CheckSuitRope(0);
                        var matchSuit2 = card.CheckSuitRope(2);
                        matchSuit = matchSuit1 || matchSuit2;
                    }
                    else if (targetCard.cm.suit == 1)
                    {
                        var matchSuit1 = card.CheckSuitRope(1);
                        var matchSuit2 = card.CheckSuitRope(3);
                        matchSuit = matchSuit1 || matchSuit2;
                    }
                }
                if (matchSuit)
                    ropeCards.Add(card);
            }
        }
        if (ropeCards.Count > 0)
        {
            renderQueue.Enqueue(new RopeSuitUpdateCommand(ropeCards, false));
        }
    }

    void CheckGreenLeaf()
    {
        var greenLeafCards = new List<CardData>();
        var faceupLeafCards = new List<CardData>();
        CardData lastBirdCard = null;
        CardData birdCard = null;
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (card.HasGreenLeaf())
            {
                greenLeafCards.Add(card);
                if (card.HasBird())
                    birdCard = card;
                if (!card.IsLocked && CheckTopCard(card) && card.IsFaceup)
                {
                    faceupLeafCards.Add(card);
                }
            }
        }

        if (greenLeafCards.Count == 1)
        {
            greenLeafCards[0].SetBirdState(false);
        }
        else if (greenLeafCards.Count > 1)
        {
            lastBirdCard = birdCard;
            if (birdCard == null)
            {
                if (faceupLeafCards.Count > 0)
                {
                    var card = GameUtils.GetRandomValue(faceupLeafCards);
                    card.SetBirdState(true);
                }
            }
            else
            {
                var change = birdCard.UpdateBirdInterval();
                if (change)
                {
                    foreach (var cardId in DeskCards)
                    {
                        CardData _card = AllCardsDic[cardId];
                        if (_card.HasGreenLeaf())
                        {
                            _card.SetBirdState(false);
                        }
                    }
                    List<CardData> cards = new List<CardData>();
                    if (faceupLeafCards.Count > 1)
                    {
                        foreach (var item in faceupLeafCards)
                        {
                            if (item.id != birdCard.id)
                            {
                                cards.Add(item);
                            }
                        }
                    }
                    else
                    {
                        cards = faceupLeafCards;
                    }
                    if (cards.Count > 0)
                    {
                        var card = GameUtils.GetRandomValue(cards);
                        card.SetBirdState(true);
                    }
                }
            }
        }
        renderQueue.Enqueue(new GreenLeafUpdateCommand(lastBirdCard, greenLeafCards));
    }

    public void AddRenderCommand(IRenderCommand renderCommand)
    {
        renderQueue.Enqueue(renderCommand);
    }

    public void DoBomb(CardData bombCard)
    {
        var posCards = new List<CardData>();
        var newCards = new List<CardData>();
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (card.id != bombCard.id && CheckTopCard(card) && !card.HasBird())
                posCards.Add(card);
        }
        int count = Math.Min(3, posCards.Count);
        SpecailDeskCardNumber += count;
        if (count > 0)
        {
            while (count > 0)
            {
                var idx = GameUtils.RandomRange(0, count);
                var card = posCards[idx];
                var cmid = ++CardAutoId;
                var cm = new CardModel(cmid, CardType.Value, false, GenDeskCardValue(cmid),
                    true, card.cm.x, card.cm.y, card.cm.depth - 1, card.cm.angle + 8);
                CardData newCard = CreateNewCardData(cm, true);
                newCard.FromId = bombCard.id;
                DeskCardsAdd(newCard.id);
                newCards.Add(newCard);
                count--;
                posCards.RemoveAt(idx);
            }
            renderQueue.Enqueue(new BombingCommand(new List<CardData>() { bombCard }, newCards));
        }
    }

    public void DoBigBomb(CardData bigBombCard)
    {
        happendBigBomb = true;
        DeskCardsRemove(bigBombCard.id, false);
        renderQueue.Enqueue(new BigBombingCommand(new List<CardData>() { bigBombCard }));
        renderQueue.Enqueue(new ShowResultCommand(false));
    }

    public void DoLightning(CardData lightningCard, bool undo = false)
    {
        if (!undo)
        {
            if (HandCards.Count == 0)
                return;
            int cardId = HandCards[0];
            CardData card = AllCardsDic[cardId];
            HandCardsRemove(cardId);
            HandRmCards.Add(cardId);
            renderQueue.Enqueue(new LightningCardMissCommand(lightningCard, card, false));
            SpecailHandCardNumber--;
        }
        else
        {
            int cardId = HandRmCards.Last();
            CardData card = AllCardsDic[cardId];
            HandRmCards.Remove(cardId);
            HandCardsInsert(0, cardId);
            renderQueue.Enqueue(new LightningCardMissCommand(lightningCard, card, true));
            SpecailHandCardNumber++;
        }
    }


    public void FlopHandCard(FlopHandCardOpt opt = null)
    {
        if (HandCards.Count == 0)
            return;
        var card = AllCardsDic[HandCards[0]];

        var missCard = GetMissComboCard();
        if (missCard != null)
        {
            renderQueue.Enqueue(
                new ScaleCardCommand(missCard));

            TypeEventSystem.Send<ScaleUndoEvent>();
        }

        card.IsFaceup = true;
        HandCardsRemove(card.id);
        OpenCardsAdd(card.id);
        if (card.cm.random)
        {
            card.cm.random = false;
            RefreshCardValueCommand t2 = GameObjManager.Instance.PopClass<RefreshCardValueCommand>(true);
            if (card.CardType == CardType.Value)
            {
                card.cm.SetValue(GenHandCardValue());
                t2.Init(card);
                renderQueue.Enqueue(t2);
            }
        }
        FlopHandCardCommand cmd1 = GameObjManager.Instance.PopClass<FlopHandCardCommand>(true);
        cmd1.Init(card);
        renderQueue.Enqueue(cmd1);

        if (card.CardType == CardType.Value)
        {
            if (opt != null)
            {
                BreakCombo(opt);
            }
        }
        else if (card.CardType == CardType.Windmill)
        {
            FlopHandCardWindmillCommand cmd2 = GameObjManager.Instance.PopClass<FlopHandCardWindmillCommand>(true);
            OpenCards.Remove(card.id);
            DiscCards.Add(card.id);
            var cardList = new List<CardData>();
            foreach (var item in DeskCards)
            {
                var theCard = AllCardsDic[item];
                if (CanBeBlowAway(theCard, true))
                    cardList.Add(theCard);
            }
            if (cardList.Count > 0)
            {
                cmd2.Init(cardList);
                renderQueue.Enqueue(cmd2);
                foreach (var theCard in cardList)
                {
                    CheckCollectedValueCard(theCard, true);
                    DeskCardsRemove(theCard.id);
                    DiscCards.Add(theCard.id);
                    opt?.AddCard(theCard.id);
                }
                FlopAllTopCard();
            }
            else
            {
                cmd2.Init(null);
                renderQueue.Enqueue(cmd2);
            }
        }

        FlopHandCardEvent t3 = GameObjManager.Instance.PopClass<FlopHandCardEvent>(true);
        t3.Init(OpenCards.Count == 1);
        TypeEventSystem.Send<FlopHandCardEvent>(t3);

        handCardWasted++;
    }

    public bool CanBuyCards()
    {
        return HandCards.Count == 0;
    }

    public void BuyCards(int useTime)
    {
        if (!CanBuyCards()) return;
        for (int i = 0; i < 5; i++)
        {
            var cm = new CardModel(++CardAutoId, CardType.Value);
            var newCard = CreateNewCardData(cm, false);
            newCard.FromId = -3;
            HandCardsAdd(newCard.id);
        }

        if (useTime == 1)
        {
            handCardWasted = 0;
            int[] guarRange = configService.BuyCardGuar[0];
            guarNum = GameUtils.RandomRange(guarRange[0], guarRange[1] + 1);
        }

        renderQueue.Enqueue(new BuyCardsCommand(HandCards.Select(x => AllCardsDic[x]).ToArray().ToList()));
        var opt = new BuyCardOpt();
        RecordOperation(opt);
    }

    public bool CanJoker()
    {
        return !(CurHandCard != null && CurHandCard.CardType == CardType.Joker);
    }

    public void UseJoker()
    {
        if (!CanJoker())
            return;

        var cm = new CardModel(++CardAutoId, CardType.Joker, faceUp: true);
        var newCard = CreateNewCardData(cm, false);
        newCard.FromId = -3;
        OpenCardsAdd(newCard.id);
        AddCombo(newCard, true);
        renderQueue.Enqueue(new BuyJokerCommand(newCard));

        var opt = new BuyJokerOpt(Round, cm.id, AllCardsDic, DeskCards);
        RecordOperation(opt);
    }

    public bool CanUndo()
    {
        if (IsFinish)
            return false;
        if (OperatStack.Count == 0)
            return false;
        var battleOperation = OperatStack.Peek();
        return !(battleOperation is SystemStartOpt);
        // if (battleOperation is CollectCardOpt)
        // {
        //     CardData card = allCardDic[(battleOperation as CollectCardOpt).cardId];
        //     if (card.HasBomb())
        //         return false;
        // }
        // return
        //     battleOperation is CollectCardOpt ||
        //     battleOperation is FlopHandCardOpt
        // // battleOperation is ClickCopyCardOpt ||
        // // battleOperation is ClickWindmillCardOpt ||
        // // battleOperation is ClickMonkeyBananaCardOpt
        // ;
    }

    //撤回操作
    public void UseUndo()
    {
        if (!CanUndo())
            return;

        var battleOperation = OperatStack.Pop();
        switch (battleOperation)
        {
            case FlopHandCardOpt opt: //手牌
                SubRound(opt);
                var handCardId = opt.cardId;
                var cardData = AllCardsDic[handCardId];
                if (cardData.CardType == CardType.Value || cardData.CardType == CardType.Joker || cardData.CardType == CardType.Monochrome)
                {
                    HandCards.Insert(0, handCardId);
                    OpenCards.Remove(handCardId);
                    renderQueue.Enqueue(new UndoFlopHandCardCommand(HandCards));
                }
                else if (cardData.CardType == CardType.Windmill)
                {
                    // CheckUndoFaceback();
                    HandCards.Insert(0, handCardId);
                    DiscCards.Remove(handCardId);
                    List<CardData> cards = new List<CardData>();
                    foreach (var cardId in opt.cardList)
                    {
                        DeskCardsAdd(cardId);
                        cards.Add(AllCardsDic[cardId]);
                    }
                    renderQueue.Enqueue(new UndoWindmillCardCommand(GameObjTransInfo.OpenCardPos, cardData, cards));
                    renderQueue.Enqueue(new UndoFlopHandCardCommand(HandCards));
                }
                break;

            case ClickDeskCardOpt opt: //桌牌
                SubRound(opt);
                lastCard = AllCardsDic[opt.cardId];
                if (lastCard.CardType == CardType.Three)
                {
                    DeskCardsAdd(opt.cardId);
                    DiscCards.Add(opt.cardId);
                    renderQueue.Enqueue(new UndoDeskCardCommand(AllCardsDic[opt.cardId]));
                }
                else if (lastCard.CardType == CardType.Boom || lastCard.CardType == CardType.Zap)
                {
                    DeskCardsAdd(opt.cardId);
                    DiscCards.Add(opt.cardId);
                    renderQueue.Enqueue(new UndoDeskCardCommand(AllCardsDic[opt.cardId]));
                }
                else if (lastCard.CardType == CardType.Key)
                {
                    DeskCardsAdd(opt.cardId);
                    DiscCards.Add(opt.cardId);
                    renderQueue.Enqueue(new UndoDeskCardCommand(AllCardsDic[opt.cardId]));
                }
                else
                {
                    DeskCardsAdd(opt.cardId);
                    OpenCards.Remove(opt.cardId);
                    renderQueue.Enqueue(new UndoDeskCardCommand(AllCardsDic[opt.cardId]));
                }
                CheckLinkRope();
                break;

            case BuyJokerOpt opt:
                OpenCards.Remove(opt.cardId);
                renderQueue.Enqueue(new UndoBuyJokerCommand(AllCardsDic[opt.cardId]));
                TypeEventSystem.Send<UndoBuyJokerEvent>();
                break;
        }

        UndoOperation(battleOperation);
    }

    void CheckUndoFaceback()
    {
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (!card.cm.faceUp && card.IsFaceup && CheckTopCard(card))
            {
                card.IsFaceup = false;
                FlopDeskCardCommand t = GameObjManager.Instance.PopClass<FlopDeskCardCommand>(true);
                t.Init(card);
                renderQueue.Enqueue(t);
            }
        }
    }

    bool IsJoinControl(CardData card)
    {
        if (card.HasLowering() ||
            card.HasRising() ||
            card.HasCloth() ||
            card.HasMagicCloth() ||
            card.HasBird() ||
            card.HasSuitRope() ||
            card.HasLinkRope() ||
            card.HasIce() ||
            card.HasBomb() ||
            card.HasBigBomb() ||
            card.HasLightning())
            return false;
        return true;
    }

    int[] GetTopCalcValueCard() //参与计算的牌
    {
        bool special = true; // 是否剩余桌面牌都是指定特殊牌
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (!(card.HasIce() || card.HasRising() || card.HasLowering() ||
             card.HasBomb() || card.HasCloth() || card.HasLinkRope() ||
              card.CardType == CardType.Gold || card.CardType == CardType.Monochrome || card.CardType == CardType.TwoValue))
            {
                special = false;
                break;
            }
        }
        List<int> values = new List<int>();
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (!card.IsLocked && CheckTopCard(card) && card.CardType == CardType.Value)
            {
                if (!IsJoinControl(card))
                    continue;
                values.Add(card.Value % Constants.ValueCardCount13);
            }
        }

        if (special)
        {
            foreach (var cardId in DeskCards)
            {
                CardData card = AllCardsDic[cardId];
                if (!card.IsLocked && CheckTopCard(card))
                {
                    if (card.HasIce() || card.HasBomb() || card.HasLinkRope())
                        values.Add(card.Value % Constants.ValueCardCount13);
                    else if (card.HasRising())
                        values.Add((card.Value + 1) % Constants.ValueCardCount52 % Constants.ValueCardCount13);
                    else if (card.HasLowering())
                        values.Add(((card.Value - 1) + Constants.ValueCardCount52) % Constants.ValueCardCount13);
                    else if (card.HasCloth() && !card.IsClothOpen())
                        values.Add(card.Value % Constants.ValueCardCount13);
                    else if (card.CardType == CardType.TwoValue)
                    {
                        values.Add(card.Value % Constants.ValueCardCount13);
                        values.Add(card.Value2 % Constants.ValueCardCount13);
                    }
                }
            }
        }
        return values.ToArray();
    }

    public bool CheckTopCard(CardData target)
    {
        if (DeskCardsHash.ContainsKey(target.id))
        {
            return DeskCardsHash[target.id].parentNodes.Count == 0;
        }

        return true;

        // foreach (var cardId in DeskCards)
        // {
        //     CardData card = AllCardsDic[cardId];
        //     if (target.id != cardId)
        //     {
        //         if (card.cm.depth < target.cm.depth && OBBCollision.GetCollision(target.obb, card.obb))
        //         {
        //             return false;
        //         }
        //     }
        // }

        // return true;
    }

    #region 控牌逻辑


    //局内充值触发
    public void ChargeEvent()
    {
        if (battleConfig.paid)
            return;

        battleConfig.paid = true;
        while (dataService.HandlePaidModelData.Length > 0)
        {
            if (dataService.HandlePaidModelData[0].number <= 0)
            {
                var list = new List<HandlePaidModel>(dataService.HandlePaidModelData);
                list.RemoveAt(0);
                dataService.HandlePaidModelData = list.ToArray();
            }
            else
            {
                var paidId = dataService.HandlePaidModelData[0].id;
                if (configService.HandlePaidConfig.TryGetValue(paidId, out var cfg))
                {
                    var label = cfg.label;
                    configService.HandleLabelConfig.TryGetValue(label, out var hLabelCfg);
                    if (hLabelCfg != null)
                    {
                        var result = GameUtils.RandomIntFromFormatString(hLabelCfg.result);
                        configService.HandleResultConfig.TryGetValue(result, out var hResultCfg);
                        if (hResultCfg != null)
                        {
                            battleConfig.deskCardAmend = hResultCfg.remainDesktop;
                            battleConfig.handCardAmend = hResultCfg.remainHand;
                        }
                    }
                }
                break;
            }
        }
    }

    // 判断局内消耗是否触发必胜
    private bool IsMustWinByConsum()
    {
        return false;

        GameData gameData = Controller.BattleCtrl.gameData;
        int coin = 0;
        coin += (configService.GetBuyCardCost(battleConfig.levelId, 1) * dataService.NowBet) * (gameData.UseBuyCardCount - gameData.BuyCardNum);
        for (int i = 0; i < gameData.BuyCardNum; i++)
        {
            coin += configService.GetBuyCardCost(battleConfig.levelId, i + 1) * dataService.NowBet;
        }
        coin += (configService.GetBuyJokerCost(battleConfig.levelId, 1) * dataService.NowBet) * (gameData.UseJokerCount - gameData.BuyJokerNum);
        for (int i = 0; i < gameData.BuyJokerNum; i++)
        {
            coin += configService.GetBuyJokerCost(battleConfig.levelId, i + 1) * dataService.NowBet;
        }
        int stageCost = configService.GetStageCost(battleConfig.levelId);
        var consumRatio = coin / (float)stageCost;

        configService.HandleConsumConfig.TryGetValue(dataService.NowBet, out var hConsumCfg);
        if (hConsumCfg == null)
        {
            hConsumCfg = configService.HandleConsumConfig.Last().Value;
        }

        return consumRatio >= hConsumCfg.consumRatio;
    }

    // 取一张数值相同且桌面上没出现的牌
    private int GetFilteredCard(int value)
    {
        var idx = GameUtils.RandomRange(0, 4);
        var targetValue = value + idx % 4 * Constants.ValueCardCount13;
        for (int i = 0; i < 4; i++)
        {
            var tempValue = value + (idx + i) % 4 * Constants.ValueCardCount13;
            if (!BitUtils.IsFlag(faceupValueCardBit, tempValue))
            {
                BitUtils.Flag(ref faceupValueCardBit, tempValue);
                targetValue = tempValue;
                break;
            }
        }
        return targetValue;
    }

    // 获取桌面数值牌数量
    private int GetValueCardNum()
    {
        int num = 0;
        foreach (var cardid in DeskCards)
        {
            if (AllCardsDic[cardid].CardType == CardType.Value)
                num++;
        }
        return num;
    }

    public int GenDeskCardValue(int tarCardId)
    {
        CardData tarCard = null;
        if (AllCardsDic.ContainsKey(tarCardId))
        {
            tarCard = AllCardsDic[tarCardId];
        }
        if (battleConfig.random || GameCommon.IsRandomMode || (tarCard != null && !IsJoinControl(tarCard)))
        {
            var randomResult = GameUtils.RandomRange(0, Constants.ValueCardCount13);
            var _result = GetFilteredCard(randomResult);
            Debug.Log($"<color=#FFE53D><关卡控制信息>翻桌面牌 {tarCardId}:  {_result} </color>\n" +
                $"特殊牌触发纯随机 ：{(tarCard != null && !IsJoinControl(tarCard))}");
            return _result;
        }
        string combokvStr = "";

        GameData gameData = Controller.BattleCtrl.gameData;
        float nowDeskHandAmend = battleConfig.deskCardAmend;
        float nowHandCardAmend = battleConfig.handCardAmend;
        float targetRate = 1;
        float _nowDeskCardAmend = Math.Max(nowDeskHandAmend, 1);
        float _nowHandCardAmend = Math.Max(nowHandCardAmend, 1);
        targetRate = _nowDeskCardAmend / _nowHandCardAmend;

        bool forceHandle = false; // 强控标记
        bool doFindLink = false; // 是否翻出连通牌
        bool isMustWinByConsum = IsMustWinByConsum();
        int valueCardNum = GetValueCardNum();
        int stepNum = ComboAlgorithm.CalculateNeedStep(AllCardsDic.Values.Where(x => DeskCards.Contains(x.id)).ToList());
        stepNum = Math.Max(1, stepNum);
        float ds = (stepNum - SpecailDeskCardNumber) / (float)Math.Max(1, HandCards.Count - SpecailHandCardNumber); //动态 桌面牌/手牌 参考值
        if (!isMustWinByConsum)
        {
            doFindLink = ds >= targetRate;
            if (doFindLink)
            {
                forceHandle = DeskCards.Count <= nowDeskHandAmend || HandCards.Count <= nowHandCardAmend;
            }
        }
        else
        {
            doFindLink = true;
        }

        var faceNumbers = GetTopCalcValueCard();
        var nums = new List<int>(faceNumbers);
        if (CurHandCard != null && CurHandCard.CardType == CardType.Value)
            nums.Add(CurHandCard.Value % Constants.ValueCardCount13);
        var linkDic = ComboAlgorithm.FindLink(nums.ToArray());

        // Debug.Log($"comboLead==1 {triggerComboLimit} {gameData.ComboNum < battleConfig.comboLimitHandleNum} {valueCardNum >= 9}"); 
        // Debug.Log($"comboLead==2 {!isMustWinByConsum} {!forceHandle} {gameData.ComboNum < battleConfig.comboLimitRate.Length} {valueCardNum / (float)Math.Max(HandCards.Count, 1) > 1.5f}"); 

        bool comboLead = triggerComboLimit && gameData.ComboNum < battleConfig.comboLimitHandleNum &&
            !isMustWinByConsum && !forceHandle &&
            !(valueCardNum < 9 && valueCardNum / (float)Math.Max(HandCards.Count, 1) < 1.5f);
        var kvList = new List<int>(); //目标牌组
        if (doFindLink)
        {
            //触发消费必赢 或者 进入combo次数控制 或者 可连通且强控时 ，找最长连通牌 
            if (isMustWinByConsum || comboLead || forceHandle)
            {
                int maxLen = -1;
                foreach (var pair in linkDic)
                {
                    if (maxLen > pair.Value)
                        continue;
                    else if (maxLen < pair.Value)
                    {
                        maxLen = pair.Value;
                    }
                }
                foreach (var pair in linkDic)
                {
                    if (pair.Value == maxLen)
                        kvList.Add(pair.Key);
                }

                if (comboLead)
                {
                    float comboRate = battleConfig.comboLimitRate[gameData.ComboNum];
                    if (comboRate > 0)
                    {
                        int newCount = (int)(kvList.Count / comboRate) - kvList.Count;
                        int startIdx = GameUtils.RandomRange(0, Constants.ValueCardCount13);
                        for (int i = startIdx; i < startIdx + Constants.ValueCardCount13; i++)
                        {
                            if (newCount <= 0)
                                break;
                            int value = i % Constants.ValueCardCount13;
                            if (!kvList.Contains(value))
                            {
                                kvList.Add(value);
                                newCount--;
                                combokvStr += (value + 1) + "  ";
                            }
                        }
                    }
                }
            }
            else //可连通且非强控时，找所有解
            {
                foreach (var element in linkDic)
                {
                    if (element.Value > 0)
                    {
                        kvList.Add(element.Key);
                    }
                }
            }
        }
        else
        {
            //不可连通且非强控，找所有无解/最小/次小连通牌
            int minLen = int.MaxValue;
            int minLen2 = int.MaxValue;
            foreach (var pair in linkDic)
            {
                if (minLen < pair.Value)
                    continue;
                else if (minLen > pair.Value)
                {
                    minLen2 = minLen;
                    minLen = pair.Value;
                }
            }
            foreach (var pair in linkDic)
            {
                if (pair.Value <= minLen || pair.Value <= minLen2)
                    kvList.Add(pair.Key);
            }
            for (int i = 0; i < Constants.ValueCardCount13; i++)
            {
                if (linkDic[i] == 0 && !kvList.Contains(i))
                {
                    kvList.Add(i);
                }
            }
        }

        var result = 0;
        var tryCount = 5;
        //取出的牌如果桌面上已经存在，再重新取一次牌
        while (tryCount > 0)
        {
            if (kvList.Count == 0) //没找到牌则随机一张
                result = GameUtils.RandomRange(0, Constants.ValueCardCount13);
            else
                result = kvList[GameUtils.RandomRange(0, kvList.Count)];
            var flag = false;
            foreach (var cardId in DeskCards)
            {
                CardData card = AllCardsDic[cardId];
                if (card.IsFaceup && card.Value % Constants.ValueCardCount13 == result % Constants.ValueCardCount13)
                {
                    flag = true;
                    break;
                }
            }
            if (!flag || kvList.Count <= 1)
            {
                break;
            }
            tryCount--;
        }

        string kvStr = "";
        kvList.ForEach(x => kvStr += (x + 1) + "  ");
        Debug.Log($"<color=#FFE53D><关卡控制信息>翻桌面牌 {tarCardId}</color> stepNum={stepNum}\n" +
            $"<color=#FFE53D>消费金币是否触发必胜 = {isMustWinByConsum}</color>\n" +
            $"<color=#FFE53D>combo奖励配置是否触发连击 = {comboLead}</color>\n" +
            $"<color=#FFE53D>计算后目标集合 = {kvStr}</color>\n" +
            $"<color=#FFE53D>包含命中combo不连接 = {combokvStr}</color>\n" +
            $"<color=#FFE53D>计算是否连通 = {doFindLink}  最终目标值 = {result + 1}</color>\n" +
            $"<color=#FFE53D>剩余桌面牌目标值 = {nowDeskHandAmend}  剩余手牌目标值 = {nowHandCardAmend}</color>\n" +
            $"<color=#FFE53D>当前桌面牌剩余数 = {DeskCards.Count}   当前手牌剩余数 = {HandCards.Count}</color>\n");
        return GetFilteredCard(result);
    }

    public int GenHandCardValue()
    {
        if (battleConfig.random || GameCommon.IsRandomMode)
        {
            var randomResult = GameUtils.RandomRange(0, Constants.ValueCardCount13);
            Debug.Log($"<color=#FFE53D><关卡控制信息>翻手牌 纯随机 {randomResult} </color>\n");
            return GetFilteredCard(randomResult);
        }
        string combokvStr = "";
        bool triggerManyHandLinkRate = false;
        GameData gameData = Controller.BattleCtrl.gameData;
        int useBuyCardCount = gameData.UseBuyCardCount; //买手牌的次数
        float nowDeskCardAmend = battleConfig.deskCardAmend;
        float nowHandCardAmend = battleConfig.handCardAmend;
        float targetRate = 1;
        float _nowDeskCardAmend = Math.Max(nowDeskCardAmend, 1);
        float _nowHandCardAmend = Math.Max(nowHandCardAmend, 1);
        targetRate = _nowDeskCardAmend / _nowHandCardAmend;
        int valueCardNum = GetValueCardNum();

        int minGuar = battleConfig.minGuar;
        int maxGuar = battleConfig.maxGuar + 1;
        if (useBuyCardCount > 0)
        {
            int[] guarRange = configService.BuyCardGuar[Math.Min(useBuyCardCount - 1, configService.BuyCardGuar.Count - 1)];
            minGuar = guarRange[0];
            maxGuar = guarRange[1] + 1;
        }

        bool forceHandle = false; //强控标记
        int stepNum = ComboAlgorithm.CalculateNeedStep(AllCardsDic.Values.Where(x => DeskCards.Contains(x.id)).ToList());
        stepNum = Math.Max(1, stepNum);
        float ds = (stepNum - SpecailDeskCardNumber) / (float)Math.Max(1, HandCards.Count - SpecailHandCardNumber); //动态 桌面牌/手牌 参考值
        bool doFindCombo = false; //是否翻出连通牌
        bool isMustWinByConsum = IsMustWinByConsum();
        bool triggerGuar = handCardWasted >= guarNum; //是否触发保底:无效的手牌数大于保底值

        if (!isMustWinByConsum)
        {
            if (triggerGuar)
                doFindCombo = true;
            else
            {
                doFindCombo = ds >= targetRate;
                if (doFindCombo)
                    forceHandle = DeskCards.Count <= nowDeskCardAmend || HandCards.Count <= nowHandCardAmend;
            }

            if (triggerGuar)
            {
                guarNum = GameUtils.RandomRange(minGuar, maxGuar);
                handCardWasted = 0;
            }
            else
            {
                if (doFindCombo && isMissComboFlag)
                {
                    //如果触发漏牌，则1/3概率改连接牌为不连接
                    doFindCombo = GameUtils.RandomRange(0, 3) < 2;
                }
            }
        }
        else
        {
            doFindCombo = true;
        }

        int result = 0;
        var kvList = new List<int>();
        var faceNumbers = GetTopCalcValueCard();
        if (faceNumbers.Length == 0)
        {
            //桌面上没有明牌的数值牌时，随机一张
            faceNumbers = new[] { GameUtils.RandomRange(0, Constants.ValueCardCount13) };
        }
        var dic = ComboAlgorithm.FindCombo(faceNumbers);

        bool comboLead = triggerComboLimit && gameData.ComboNum < battleConfig.comboLimitHandleNum &&
            !isMustWinByConsum && !forceHandle &&
            !(valueCardNum < 9 && valueCardNum / (float)Math.Max(HandCards.Count, 1) < 1.5f);
        if (doFindCombo)
        {
            //触发消费必赢 或者 进入combo次数控制 或者 可连通且强控时，找最优解组
            if (isMustWinByConsum || comboLead || forceHandle)
            {
                int maxLen = int.MinValue;
                foreach (var pair in dic)
                {
                    foreach (var list in pair.Value)
                    {
                        if (list.Length <= maxLen)
                            continue;
                        if (list.Length > maxLen)
                        {
                            maxLen = list.Length;
                        }
                    }
                }
                foreach (var pair in dic)
                {
                    foreach (var list in pair.Value)
                    {
                        if (list.Length == maxLen)
                        {
                            kvList.Add(pair.Key);
                        }
                    }
                }

                if (comboLead)
                {
                    float comboRate = battleConfig.comboLimitRate[gameData.ComboNum];
                    if (comboRate > 0)
                    {
                        int newCount = (int)(kvList.Count / comboRate) - kvList.Count;
                        int startIdx = GameUtils.RandomRange(0, Constants.ValueCardCount13);
                        for (int i = startIdx; i < startIdx + Constants.ValueCardCount13; i++)
                        {
                            if (newCount <= 0)
                                break;
                            int value = i % Constants.ValueCardCount13;
                            if (!kvList.Contains(value))
                            {
                                kvList.Add(value);
                                newCount--;
                                combokvStr += (value + 1) + "  ";
                            }
                        }
                    }
                }
            }
            else
            {
                //可连接且非强控，找所有解
                foreach (var element in dic)
                {
                    if (element.Value.Count > 0)
                        kvList.Add(element.Key);
                }
            }
        }
        else
        {
            List<int> comboKeyList = new List<int>();
            int key = -1;
            int minLength = int.MaxValue;
            foreach (var pair in dic)
            {
                foreach (var list in pair.Value)
                {
                    if (list.Length >= 1)
                    {
                        comboKeyList.Add(pair.Key);
                        if (list.Length < minLength)
                        {
                            minLength = list.Length;
                            key = pair.Key;
                        }
                    }
                }
            }
            var manyHandLinkRate = battleConfig.manyHandLinkRate;
            if (HandCards.Count > battleConfig.levelModel.settings.cards_in_stack.Length * manyHandLinkRate.Item1 / 100f)
                doFindCombo = GameUtils.RandomRange(0f, 1f) < manyHandLinkRate.Item2 / 100f;
            if (!doFindCombo)
            {
                for (int i = 0; i < Constants.ValueCardCount13; i++)
                {
                    if (!comboKeyList.Contains(i))
                    {
                        kvList.Add(i);
                    }
                }
            }
            else
            {
                triggerManyHandLinkRate = true;
                if (key != -1)
                {
                    kvList.Add(key);
                }
            }
        }

        if (kvList.Count > 0)
            result = kvList[GameUtils.RandomRange(0, kvList.Count)];
        else
            result = GameUtils.RandomRange(0, Constants.ValueCardCount13);

        //重牌判断
        bool repeatFlag = false;
        if (!doFindCombo)
        {
            int repeatTimes = 0;
            for (int i = handcardValues.Count - 1; i >= 0; i--)
            {
                if (handcardValues[i] == result)
                    repeatTimes++;
                else
                    break;
            }
            if (repeatTimes == 2) //加入最小连通牌
            {
                int comboNum = int.MaxValue;
                foreach (var element in dic)
                {
                    if (element.Value.Count > 0)
                    {
                        if (comboNum > element.Value.Count)
                        {
                            comboNum = element.Value.Count;
                        }
                    }
                }
                foreach (var element in dic)
                {
                    if (element.Value.Count > 0)
                    {
                        if (comboNum == element.Value.Count)
                        {
                            kvList.Add(element.Key);
                        }
                    }
                }
                repeatFlag = true;
            }
            else if (repeatTimes > 2) //加入最小/次小连通牌
            {
                if (repeatTimes > 3)
                    kvList.Clear();
                int comboNum1 = int.MaxValue;
                foreach (var element in dic)
                {
                    if (element.Value.Count > 0)
                    {
                        if (comboNum1 > element.Value.Count)
                        {
                            comboNum1 = element.Value.Count;
                        }
                    }
                }
                int comboNum2 = comboNum1;
                foreach (var element in dic)
                {
                    if (element.Value.Count > comboNum2)
                    {
                        if (comboNum2 > element.Value.Count)
                        {
                            comboNum2 = element.Value.Count;
                        }
                    }
                }
                foreach (var element in dic)
                {
                    if (element.Value.Count > 0)
                    {
                        if (comboNum1 == element.Value.Count || comboNum2 == element.Value.Count)
                        {
                            kvList.Add(element.Key);
                        }
                    }
                }
                repeatFlag = true;
            }
            if (kvList.Count > 0)
                result = kvList[GameUtils.RandomRange(0, kvList.Count)];
            else
                result = GameUtils.RandomRange(0, Constants.ValueCardCount13);
        }
        handcardValues.Add(result);

        string kvStr = "";
        kvList.ForEach(x => kvStr += (x + 1) + "  ");

        // string teststr = "";
        // DeskCards.ForEach(x => teststr += $"{x}:{(AllCardsDic[x].Value%Constants.ValueCardCount13)+1}" + "  ");
        // Debug.Log(teststr);

        Debug.Log($"<color=#FFE53D><关卡控制信息>翻手牌</color> stepNum={stepNum}\n" +
            $"<color=#FFE53D>消费金币是否触发必胜 = {isMustWinByConsum}</color>\n" +
            $"<color=#FFE53D>触发多手牌保连接 = {triggerManyHandLinkRate}</color>\n" +
            $"<color=#FFE53D>combo奖励配置是否触发连击 = {comboLead}</color>\n" +
            $"<color=#FFE53D>是否触发保底 = {triggerGuar} </color>\n" +
            $"<color=#FFE53D>计算后目标集合 = {kvStr}</color>\n" +
            $"<color=#FFE53D>触发重复牌逻辑 = {repeatFlag}</color>\n" +
            $"<color=#FFE53D>包含命中combo不连接 = {combokvStr}</color>\n" +
            $"<color=#FFE53D>计算是否连通 = {doFindCombo}  最终目标值 = {result + 1}</color>\n" +
            $"<color=#FFE53D>剩余桌面牌目标值 = {nowDeskCardAmend}  剩余手牌目标值 = {nowHandCardAmend}</color>\n" +
            $"<color=#FFE53D>当前桌面牌剩余数 = {DeskCards.Count}   当前手牌剩余数 = {HandCards.Count}</color>\n");

        return GetFilteredCard(result);
    }

    #endregion

    //检测添加Combo奖励的牌
    public int[] AddComboCards(int count, CardType cardType, float waitTime)
    {
        int[] newCards = new int[count];
        for (int i = 0; i < count; i++)
        {
            var cm = new CardModel(++CardAutoId, cardType);
            var newCard = CreateNewCardData(cm, false);
            newCard.FromId = -2;
            newCards[i] = newCard.id;
        }
        comboAddCards.Add(newCards.ToList());

        foreach (var cardid in newCards)
        {
            HandCardsAdd(cardid);
        }
        renderQueue.Enqueue(new AddComboCardCommand(newCards, HandCards, waitTime));

        var opt = new SystemEmptyOpt();
        opt.RenderQueue = renderQueue;
        renderQueue.Clear();
        TypeEventSystem.Send<OperatCommandEvent>(new OperatCommandEvent(opt));

        return newCards;
    }

    public void UndoComboCards()
    {
        var cards = comboAddCards[comboAddCards.Count - 1];
        comboAddCards.RemoveAt(comboAddCards.Count - 1);
        foreach (var cardId in cards)
            HandCardsRemove(cardId);
        renderQueue.Enqueue(new UndoComboCardCommand(cards));
    }

    public CardData GetCanCollectCard(CardData targetCard = null)
    {
        if (targetCard == null)
            targetCard = CurHandCard;
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (!card.IsLocked && CheckTopCard(card))
            {
                if (card.CardType == CardType.Joker)
                //  ||
                //         card.CardType == CardType.Boom ||
                //         card.CardType == CardType.Zap ||
                //         card.CardType == CardType.Three ||
                //         card.CardType == CardType.Windmill)
                {
                    return card;
                }
                else if (card.CardType == CardType.Key)
                {
                    foreach (var _cardId in DeskCards)
                    {
                        CardData _card = AllCardsDic[_cardId];
                        if (_card.CardType == CardType.Lock && CheckTopCard(_card))
                        {
                            return card;
                        }
                    }
                }
                else
                {
                    if (card.IsFaceup && CheckBingo(card, targetCard))
                        return card;
                }
            }

        }

        return null;
    }

    // true为红色, false为黑色, null不匹配颜色
    public CardData GetSameComboCard()
    {
        if (comboColorList.Count == 0)
            return null;
        var color = comboColorList[0];
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (!card.IsLocked && card.IsFaceup && CheckTopCard(card) && CheckBingo(card, CurHandCard))
            {
                int? suit = card.GetCardSuit();
                if ((suit == 1 || suit == 3) == color)
                    return card;
            }
        }
        return null;
    }

    public CardData GetHandCard()
    {
        if (HandCards.Count == 0) return null;
        return AllCardsDic[HandCards[0]];
    }

    public CardData GetLastHandCard()
    {
        if (OpenCards.Count <= 1 || OperatStack.Count == 0)
            return null;
        return AllCardsDic[OpenCards[OpenCards.Count - 2]];
    }

    public bool IsMissCombo()
    {
        if (OpenCards.Count <= 1 || OperatStack.Count == 0)
            return false;
        var lastOpt = OperatStack.Peek();
        if (lastOpt is FlopHandCardOpt)
        {
            var lastCard = AllCardsDic[OpenCards[OpenCards.Count - 2]];
            var missCard = GetCanCollectCard(lastCard);
            return missCard != null;
        }
        return false;
    }

    public CardData GetMissComboCard()
    {
        if (OpenCards.Count <= 1)
            return null;

        var lastCard = AllCardsDic[OpenCards[OpenCards.Count - 1]];
        var missCard = GetCanCollectCard(lastCard);
        return missCard;
    }

    public bool CheckMissJoker()
    {
        if (CanJoker() && DeskCards.Count <= 3)
            return true;
        return false;
    }

    public CardData GetTargetTypeCard(string _type)
    {
        Constants.String2CardTypeDic.TryGetValue(_type, out var cardType);
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (card.IsFaceup && CheckTopCard(card))
            {
                var modifier = card.HasBomb() ? Constants.ModifierTypeBomb :
                        card.HasBigBomb() ? Constants.ModifierTypeBigBomb :
                        card.HasRising() ? Constants.ModifierTypeRising :
                        card.HasLowering() ? Constants.ModifierTypeLowering :
                        card.HasWater() ? Constants.ModifierTypeWater :
                        card.HasIce() ? Constants.ModifierTypeIce :
                        card.HasLightning() ? Constants.ModifierTypeLightning :
                        card.HasGreenLeaf() ? Constants.ModifierTypeGreenLeaf :
                        card.HasCloth() ? Constants.ModifierTypeCloth :
                        card.HasMagicCloth() ? Constants.ModifierTypeMagicCloth :
                        card.HasSuitRope() ? Constants.ModifierTypeRope :
                        card.HasLizard() ? Constants.ModifierTypeLizard :
                        "";
                if (card.CardType == cardType || modifier.Equals(_type))
                {
                    return card;
                }
            }
        }
        return null;
    }

    private long guideCardTime;
    public void CheckGuideCard(long now)
    {
        if (OperatStack.Count == 0 || OpenCards.Count == 0)
            return;
        var opt = OperatStack.Peek();
        var inter = 6;
        if (now - opt.time > inter && now - guideCardTime > inter)
        {
            CardData targetCard = GetCanCollectCard();
            if (targetCard != null)
            {
                TypeEventSystem.Send<RenderCommandEvent>(new RenderCommandEvent(new ScaleCardCommand(targetCard)));
                guideCardTime = now;
            }
            else
            {
                TypeEventSystem.Send<CheckGuideJokerEvent>();
                guideCardTime = now;
            }
        }
    }

    int GetCoverNum(CardData card)
    {
        if (!card.cm.faceUp) return 0;
        return DeskCards.Count(x =>
        {
            if (card.id == x) return false;
            CardData c = AllCardsDic[x];
            return OBBCollision.GetCollision(card.obb, c.obb) && c.cm.depth > card.cm.depth;
        });
    }

    public void CheckItem(List<int> itemArray)
    {
        if (itemArray == null || itemArray.Count == 0) return;

        if (itemArray.Contains((int)PropEnum.ItemWindmill) || itemArray.Contains((int)PropEnum.TimeItemWindmill))
            ItemWindmill();

        if (itemArray.Contains((int)PropEnum.ItemEliminate) || itemArray.Contains((int)PropEnum.TimeItemEliminate))
            ItemEliminate();

        ItemWithCardAttch(itemArray.Contains((int)PropEnum.ItemJoker) ||
         itemArray.Contains((int)PropEnum.TimeItemJoker),
          itemArray.Contains((int)PropEnum.ItemCactus) ||
           itemArray.Contains((int)PropEnum.TimeItemCactus));
    }

    //开局风车道具
    private void ItemWindmill()
    {
        var newCards = new List<int>();
        var cm = new CardModel(++CardAutoId, CardType.Windmill, faceUp: true);
        var newCard = CreateNewCardData(cm, false);
        newCard.FromId = -4;
        newCards.Add(newCard.id);
        var idx = GameUtils.RandomRange(HandCards.Count * 0.3f, HandCards.Count * 0.5f);
        if (idx > HandCards.Count)
            idx = HandCards.Count - 1;
        if (idx < 0)
            idx = 0;
        HandCards.Insert((int)idx, newCard.id);

        // HandCardsAdd(newCard.id);
        renderQueue.Enqueue(new ItemWindmillCardCommand(newCards, HandCards));

        SendComboEvent(false);
    }

    //开局消牌道具
    private void ItemEliminate()
    {
        int eliminateCount = 3;
        List<CardData> eliminateLits = new List<CardData>(eliminateCount);
        foreach (var cardId in DeskCards)
        {
            CardData card = AllCardsDic[cardId];
            if (CanBeBlowAway(card))
            {
                eliminateLits.Add(card);
            }
            else
            {
                if (CheckTopCard(card))
                {
                    if (card.HasIce())
                    {
                        eliminateLits.Add(card);
                    }
                    else if (card.HasSuitRope())
                    {
                        eliminateLits.Add(card);
                    }
                    else if (card.HasBomb() || card.HasBigBomb() || card.HasLightning())
                    {
                        eliminateLits.Add(card);
                    }
                }
            }
        }
        if (eliminateLits.Count > eliminateCount)
        {
            GameUtils.Shuffle(eliminateLits);
            eliminateLits = eliminateLits.GetRange(0, eliminateCount);
        }

        var newCards = new List<CardData>();
        foreach (var card in eliminateLits)
        {
            if (card.HasLinkRope() && card.CanRemoveLinkRope())
            {
                var linkCardId = card.GetLinkRopeCardId();
                bool flag = eliminateLits.Any(item => item.id == linkCardId);
                newCards.Add(AllCardsDic[linkCardId]);
            }
        }
        eliminateLits.AddRange(newCards);
        SpecailDeskCardNumber -= eliminateLits.Count;

        ItemEliminateDeskCardCommand t = GameObjManager.Instance.PopClass<ItemEliminateDeskCardCommand>(true);
        t.Init(eliminateLits);
        renderQueue.Enqueue(t);

        List<CardData> removeCards = new List<CardData>();
        if (eliminateLits.Count > 0)
        {
            for (int i = 0; i < eliminateLits.Count; i++)
            {
                CardData card = eliminateLits[i];
                if (card.HasIce())
                {
                    AllCardsDic[card.id].BreakIce();
                    AddCombo(card);
                    renderQueue.Enqueue(new IceBrokenCommand(card));
                }
                else if (card.HasSuitRope())
                {
                    AllCardsDic[card.id].RemoveOneRopeSuit();
                    renderQueue.Enqueue(new RopeSuitUpdateCommand(new List<CardData>() { AllCardsDic[card.id] }, false));
                }
                else if (card.HasBomb() || card.HasBigBomb() || card.HasLightning())
                {
                    AllCardsDic[card.id].RemoveAllModifier();
                    renderQueue.Enqueue(new RemoveModifierCommand(new List<CardData>() { card }));
                }
                else
                {
                    DeskCardsRemove(card.id);
                    removeCards.Add(card);
                }
            }
        }

        foreach (var card in removeCards)
        {
            CheckSuitRope(null, card);
            CheckCollectedValueCard(card, true);
        }

        SendComboEvent(false);
    }

    //开局需要附着卡牌的道具
    private void ItemWithCardAttch(bool runJoker, bool runCactus)
    {
        if (!runJoker && !runCactus) return;
        int jokerCount = 2;
        int cactusCount = 2;
        int realCount = (runJoker ? jokerCount : 0) + (runCactus ? cactusCount : 0);
        Dictionary<int, List<CardData>> depthDic = new Dictionary<int, List<CardData>>();
        foreach (int cardId in DeskCards)
        {
            CardData cardData = AllCardsDic[cardId];
            int depth = cardData.cm.depth;
            if (!depthDic.ContainsKey(depth))
                depthDic.Add(depth, new List<CardData>());
            depthDic[depth].Add(cardData);
        }
        List<int> sortDepth = depthDic.Keys.ToList();
        sortDepth.Sort();
        List<CardData> attachCards = new List<CardData>();
        for (int i = 0; i < Math.Min(3, sortDepth.Count); i++)
            attachCards.AddRange(depthDic[sortDepth[i]]);
        if (attachCards.Count < realCount)
        {
            attachCards.Clear();
            foreach (var pair in depthDic)
                attachCards.AddRange(pair.Value);
        }
        GameUtils.Shuffle(attachCards);
        List<CardData> jokerCardList = new List<CardData>(jokerCount);
        List<CardData> cactusCardList = new List<CardData>(cactusCount);
        int nowSelectIndex = 0;
        if (runJoker)
        {
            for (int i = 0; i < jokerCount; i++)
            {
                int index = nowSelectIndex % attachCards.Count;
                CardData attachCard = attachCards[index];
                var cm = new CardModel(++CardAutoId, CardType.Joker, faceUp: true, x: attachCard.cm.x, y: attachCard.cm.y,
                    depth: attachCard.cm.depth + 1, angle: attachCard.cm.angle);
                CardData newCard = CreateNewCardData(cm, true);
                newCard.FromId = -4;
                jokerCardList.Add(newCard);
                DeskCardsAdd(newCard.id);
                nowSelectIndex++;
            }
            // for (int i = 0; i < jokerCardList.Count; i++)
            // {
            //     int checkDepth = jokerCardList[i].cm.depth;
            //     foreach (int id in DeskCards)
            //     {
            //         CardData thisData = AllCardsDic[id];
            //         if (jokerCardList[i].id != id && thisData.cm.depth >= checkDepth)
            //             AllCardsDic[id].cm.depth++;
            //     }
            // }
        }
        if (runCactus)
        {
            for (int i = 0; i < cactusCount; i++)
            {
                int index = nowSelectIndex % attachCards.Count;
                CardData attachCard = attachCards[index];
                var cm = new CardModel(++CardAutoId, CardType.Boom, faceUp: true, x: attachCard.cm.x, y: attachCard.cm.y,
                    depth: attachCard.cm.depth + 1, angle: attachCard.cm.angle);
                CardData newCard = CreateNewCardData(cm, true);
                newCard.FromId = -4;
                cactusCardList.Add(newCard);
                DeskCardsAdd(newCard.id);
                nowSelectIndex++;
            }
            for (int i = 0; i < cactusCardList.Count; i++)
            {
                int checkDepth = cactusCardList[i].cm.depth;
                foreach (int id in DeskCards)
                {
                    CardData thisData = AllCardsDic[id];
                    if (cactusCardList[i] != thisData && thisData.cm.depth >= checkDepth)
                        thisData.cm.depth++;
                }
            }
        }

        foreach (int id in DeskCards)
        {
            RefreshCardPositionCommand t3 = GameObjManager.Instance.PopClass<RefreshCardPositionCommand>(true);
            t3.Init(AllCardsDic[id]);
            renderQueue.Enqueue(t3);
        }

        ItemJokerCommand t1 = GameObjManager.Instance.PopClass<ItemJokerCommand>(true);
        t1.Init(jokerCardList);
        renderQueue.Enqueue(t1);

        ItemCactusCommand t2 = GameObjManager.Instance.PopClass<ItemCactusCommand>(true);
        t2.Init(cactusCardList);
        renderQueue.Enqueue(t2);

        foreach (int id in DeskCards)
        {
            RefreshCardPositionCommand t3 = GameObjManager.Instance.PopClass<RefreshCardPositionCommand>(true);
            t3.Init(AllCardsDic[id]);
            renderQueue.Enqueue(t3);
        }
    }

    //检测添加连胜卡
    private void CheckWinStreakCards(List<CardType> cards)
    {
        if (cards == null || cards.Count == 0)
            return;

        int[] suits = { 0, 1 };
        int suitIdx = 0;
        var newCards = new List<int>();
        foreach (var ct in cards)
        {
            var random = false;
            var suit = -1;
            if (ct == CardType.Monochrome)
            {
                suit = suits[suitIdx++];
            }
            var cm = new CardModel(++CardAutoId, ct, random);
            cm.suit = suit;
            var newCard = CreateNewCardData(cm, false);
            newCard.FromId = -4;
            newCards.Add(newCard.id);
        }

        int[] pos = { 2, 4, 6 };
        int posIdx = 0;
        foreach (var cardid in newCards)
        {
            HandCardsInsert(pos[posIdx++], cardid);
        }
        SpecailHandCardNumber += newCards.Count;

        renderQueue.Enqueue(new WinStreakCardsCommand(newCards, HandCards));
    }

    public void CheckActivity(ActivityType activityType)
    {
        if (GameCommon.IsAiMode)
            return;
        if (activityType == ActivityType.limitPk)
        {
            if (ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).state != ActivityState.underWay) return;
            renderQueue.Enqueue(new CheckLimitPkPopupCommand(activityType));
        }
        else if (activityType == ActivityType.rabbitGift)
        {
            if (!ActivityManager.Instance.RabbitGiftActivity.IsOpenActivity()) return;
            var modelList = ActivityManager.Instance.RabbitGiftActivity.GetCardList();
            if (modelList != null)
            {
                var newCards = new List<int>();
                foreach (var cardModel in modelList)
                {
                    cardModel.id = ++CardAutoId;
                    var newCard = CreateNewCardData(cardModel, false);
                    newCard.FromId = -5;
                    newCards.Add(newCard.id);
                    HandCardsAdd(newCard.id);
                }
                SpecailHandCardNumber += modelList.Count;
                renderQueue.Enqueue(new RabbitCardCommand(newCards, HandCards));
            }
        }
    }

    public void CheckSpecialCardTip()
    {
        renderQueue.Enqueue(new CheckSpecialCardTipCommand());
    }

    public void ExitBattle()
    {
        aborted = true;
        DeskCards.Clear();
        renderQueue.Enqueue(
            new ExitBattleCommand());
        var opt = new SystemOverOpt();
        opt.RenderQueue = renderQueue;
        renderQueue.Clear();
        TypeEventSystem.Send<OperatCommandEvent>(new OperatCommandEvent(opt));
    }

    public void GmActionWin()
    {
        DeskCards.Clear();
        if (CheckWin())
        {
            renderQueue.Enqueue(
                new ExitBattleCommand());
            renderQueue.Enqueue(
                new ShowResultCommand(true));
            var opt = new SystemOverOpt();
            opt.RenderQueue = renderQueue;
            renderQueue.Clear();
            TypeEventSystem.Send<OperatCommandEvent>(new OperatCommandEvent(opt));
        }
    }

    private void ReprotNoHandCard()
    {
        UniRx.Observable.NextFrame().Subscribe(_ =>
        {
            if (HandCards.Count == 0 && GetCanCollectCard() == null)
            {
                noHandCardTime++;
                var level = dataService.MaxLevel;
                var level_type = 1;
                if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel) != null &&
                    ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
                {
                    level = dataService.EndlessLevelProgress.ViewMaxLayer;
                    level_type = 2;
                }
                Dictionary<string, object> dict1 = new Dictionary<string, object>
                {
                    { AnalyticsKey.StageType, level_type },
                    { AnalyticsKey.StageId, level},
                    { AnalyticsKey.NoHandCardTimes, noHandCardTime },
                    { AnalyticsKey.CurrentCoin, dataService.Coin },
                    { AnalyticsKey.CurrentFreeBuyCard, dataService.GetPropNum((int)PropEnum.FreeBuyCard) },
                    { AnalyticsKey.CurrentFreeUndo, dataService.GetPropNum((int)PropEnum.FreeUndo) },
                    { AnalyticsKey.CurrentFreeWild, dataService.GetPropNum((int)PropEnum.FreeJoker) },
                    { AnalyticsKey.CurrentDeskCards, DeskCards.Count },
                };
                AnalyticUtils.ReportEvent(AnalyticsKey.SoliNoHandCardInGame, dict1);
            }
        });
    }

    public int CollectCardNum()
    {
        return OperatStack.Count(x => x is ClickDeskCardOpt);
    }

    //获取最上面可以点击的功能卡
    public List<int> GetAllAutoFuncCard()
    {
        List<int> funcCards = new List<int>();
        foreach (var id in DeskCards)
        {
            CardData card = AllCardsDic[id];
            var cardType = card.CardType;
            int cardId = -1;
            if (!card.IsLocked && CheckTopCard(card))
            {
                if (cardType == CardType.Three || cardType == CardType.Question)
                {
                    cardId = card.id;
                }
            }
            if (cardId != -1)
            {
                funcCards.Add(cardId);
            }
        }
        return funcCards;
    }

    private void AddCombo(CardData carddata, bool repeat = false)
    {
        bool red = carddata.GetCardColor();
        if (!repeat)
        {
            optComboColorList.Add(red);
        }
        else
        {
            if (optComboColorList.Count > 0)
            {
                optComboColorList.Add(optComboColorList[optComboColorList.Count - 1]);
            }
            else
            {
                if (comboColorList.Count > 0)
                {
                    optComboColorList.Add(comboColorList[comboColorList.Count - 1]);
                }
                else
                {
                    optComboColorList.Add(red);
                }
            }
        }

        GameData gameData = Controller.BattleCtrl.gameData;
        ++ComboCount;
        //消牌奖励
        // int level = gameData.Level;
        // int comboRewardNum = configService.GetComboReward(level, ComboCount) * dataService.NowBet;
        // FlowAddEvent t = GameObjManager.Instance.PopClass<FlowAddEvent>(true);
        // t.Init(comboRewardNum, 1, new Vector3(carddata.cm.x, carddata.cm.y, carddata.cm.depth), PropEnum.Coin, 0);
        // t.cardId = carddata.id;
        // FlowAddQueueEvent t2 = GameObjManager.Instance.PopClass<FlowAddQueueEvent>(true);
        // t2.Init(t);
        // TypeEventSystem.Send<FlowAddQueueEvent>(t2);

        //星星积分
        gameData.AddSmallCombo(ComboCount);
    }

    private void BreakCombo(IBattleOperation opt)
    {
        ComboCount = 0;
        // comboColorList.Clear();
        // optComboColorList.Clear();
    }

    public bool IsHandCard(int cardId)
    {
        return HandCards.Contains(cardId);
    }

    public bool IsWillCombo()
    {
        var comboLimit = initComboSteps[initComboSteps.Length - 1];
        if (comboStepIdx < initComboSteps.Length)
        {
            comboLimit = initComboSteps[comboStepIdx];
        }
        return comboColorList.Count == comboLimit - 1;
    }

    public bool IsWillSameColorCombo()
    {
        bool sameColor = comboColorList.Count > 0;
        // foreach (var c in comboColorList)
        // {
        //     if (c != comboColorList[0])
        //     {
        //         sameColor = false;
        //         break;
        //     }
        // }
        // if (sameColor)
        // {
        //     var comboLimit = initComboSteps[initComboSteps.Length - 1];
        //     if (comboStepIdx < initComboSteps.Length)
        //     {
        //         comboLimit = initComboSteps[comboStepIdx];
        //     }
        //     return comboColorList.Count == comboLimit - 1;
        // }
        sameColor = false; //屏蔽同色combo
        return false;
    }

    public Tuple<int, int> GetTaskProcess()
    {
        return new Tuple<int, int>(taskTotalNumber - taskLeftNumber, taskTotalNumber);
    }

    #region AI数据接口
    public void AIAction_EndBattle()
    {
        var opt = new SystemOverOpt();
        TypeEventSystem.Send<OperatCommandEvent>(new OperatCommandEvent(opt));
        BattleDataMgr.Instance.Clean();
    }

    public int AIAction_BestCard() //底牌是数值牌
    {
        var cardId = -1;
        if (CurHandCard == null ||
            !(CurHandCard.CardType == CardType.Value ||
            CurHandCard.CardType == CardType.TwoValue))
            return cardId;

        var val = -1;
        var len = 0;
        var curval = CurHandCard.Value % Constants.ValueCardCount13;
        var numbers = GetTopCalcValueCard();

        var dic = ComboAlgorithm.FindCombo(numbers);
        foreach (var v in dic[curval])
        {
            if (v.Length > 0 && v.Length > len)
            {
                len = v.Length;
                val = v[1] % Constants.ValueCardCount13;
            }
        }

        if (val == -1 && CurHandCard.CardType == CardType.TwoValue)
        {
            curval = CurHandCard.Value2 % Constants.ValueCardCount13;
            foreach (var v in dic[curval])
            {
                if (v.Length > 0 && v.Length > len)
                {
                    len = v.Length;
                    val = v[1] % Constants.ValueCardCount13;
                }
            }
        }

        if (val != -1)
        {
            var cards = new List<CardData>();
            foreach (var id in DeskCards)
            {
                CardData card = AllCardsDic[id];
                if (card.HasCloth() && !card.IsClothOpen())
                    continue;
                if (card.HasMagicCloth() && !card.IsClothOpen())
                    continue;
                if (card.HasBird())
                    continue;
                if (card.HasLinkRope() && !card.CanRemoveLinkRope())
                    continue;
                if (card.HasSuitRope())
                    continue;

                if (!card.IsLocked && CheckTopCard(card) &&
                    card.CardType == CardType.Value &&
                    card.Value % Constants.ValueCardCount13 == val)
                {
                    cards.Add(card);
                }
            }

            var coverNum = 0;
            foreach (var card in cards)
            {
                var num = GetCoverNum(card);
                if (num >= coverNum)
                {
                    cardId = card.id;
                    coverNum = num;
                }
            }
        }

        return cardId;
    }

    public int AIAction_GoodCard()
    {
        var cardId = -1;
        if (CurHandCard == null)
            return cardId;

        var cards = new List<CardData>();
        foreach (var id in DeskCards)
        {
            CardData card = AllCardsDic[id];
            if (card.HasCloth() && !card.IsClothOpen())
                continue;
            if (card.HasMagicCloth() && !card.IsClothOpen())
                continue;
            if (card.HasBird())
                continue;
            if (card.HasLinkRope() && !card.CanRemoveLinkRope())
                continue;
            if (card.HasSuitRope())
                continue;
            if (!card.IsLocked && CheckTopCard(card) && CheckBingo(card, CurHandCard))
            {
                cards.Add(card);
            }
        }

        var coverNum = 0;
        foreach (var card in cards)
        {
            var num = GetCoverNum(card);
            if (num >= coverNum)
            {
                cardId = card.id;
                coverNum = num;
            }
        }

        return cardId;
    }

    public int AIAction_FuncCard()
    {
        var cardId = -1;
        if (CurHandCard == null)
            return cardId;

        foreach (var id in DeskCards)
        {
            CardData card = AllCardsDic[id];
            var cardType = card.CardType;
            if (!card.IsLocked && CheckTopCard(card))
            {
                if (cardType == CardType.Joker ||
                    cardType == CardType.Boom ||
                    cardType == CardType.Zap ||
                    cardType == CardType.Three ||
                    card.CardType == CardType.Windmill ||
                    card.CardType == CardType.Rudder ||
                    (cardType == CardType.Copy && CurHandCard.CardType == CardType.Value)
                    )
                {
                    cardId = card.id;
                    break;
                }
                else if (card.CardType == CardType.Key)
                {
                    foreach (var _cardId in DeskCards)
                    {
                        CardData _card = AllCardsDic[_cardId];
                        if (_card.CardType == CardType.Lock && CheckTopCard(_card))
                        {
                            cardId = card.id;
                            break;
                        }
                    }
                }
                else if (cardType == CardType.Banana)
                {
                    cardId = DeskCards.Find(x =>
                    {
                        CardData card2 = AllCardsDic[x];
                        return card2.CardType == CardType.Monkey && CheckTopCard(card2);
                    });
                }
                else if (cardType == CardType.Monkey)
                {
                    cardId = DeskCards.Find(x =>
                    {
                        CardData card2 = AllCardsDic[x];
                        return card2.CardType == CardType.Banana && CheckTopCard(card2);
                    });
                }
            }
        }
        return cardId;
    }

    public bool AIAction_FlopHandCard()
    {
        if (HandCards.Count > 0)
        {
            TouchHandCard();
            // FlopHandCard();
            return true;
        }
        return false;
    }

    public void AIAction_UnlimitedHandCard()
    {
        if (HandCards.Count > 0)
        {
            FlopHandCard();
            return;
        }

        var cm = new CardModel(++CardAutoId, CardType.Value, false, GenHandCardValue(), true);
        OpenCardsAdd(CreateNewCardData(cm, false).id);
        handCardWasted++;
    }

    public int AIAction_NeedStep()
    {
        if (DeskCards.Count == 0)
            return 0;
        int stepNum = ComboAlgorithm.CalculateNeedStep(AllCardsDic.Values.Where(x => DeskCards.Contains(x.id)).ToList());
        return Math.Max(1, stepNum);
    }

    #endregion

    public void Test()
    {
        var str = "";
        foreach (var item in comboColorList)
        {
            str = str + $", {item}";
        }
        Debug.LogError("test === " + str);
    }
}
