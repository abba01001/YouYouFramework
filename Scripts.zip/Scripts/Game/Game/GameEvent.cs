using UnityEngine;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System;
using OBBUtils;
using Doozy.Engine.UI.Animation;
using Doozy.Engine.UI;
using SoliUtils;

public class GameEvent { }

public class ConfigUpdateFinishEvent : GameEvent { }

public class StartGameEvent : GameEvent
{
    public readonly int level;
    public readonly LevelModel levelModel;
    public readonly long ticketNum;
    public readonly long enterCoin;

    public readonly string[] winStreakCards;
    public readonly List<int> item;

    public StartGameEvent(int _level, LevelModel b, long _ticketNum, long _enterCoin, string[] _wsCards, List<int> _item)
    {
        level = _level;
        levelModel = b;
        ticketNum = _ticketNum;
        enterCoin = _enterCoin;
        winStreakCards = _wsCards;
        item = _item;
    }
}

public class EndGameEvent : GameEvent
{
    public readonly BattleConfig config;
    public EndGameEvent(BattleConfig _config) => config = _config;
}

public class GameInitFinishEvent : GameEvent
{
    public GameData gameData;
    public GameInitFinishEvent(GameData b)
    {
        gameData = b;
    }
}

public class PlayGameExitAnim : GameEvent
{
}

public class PlayGameEntryAnim : GameEvent
{
}

public class ShowGameSkipBtn : GameEvent
{
    public bool isShow;
    public ShowGameSkipBtn(bool _isShow)
    {
        isShow = _isShow;
    }

}

public class HandCardChangeEvent : GameEvent
{
    public int handCardNum;
    public HandCardChangeEvent(int a)
    {
        handCardNum = a;
    }
}

public class MoveGameViewBottom : GameEvent
{

}

public class CleanGameEvent : GameEvent
{
}

public class UndoEvent : GameEvent
{
}

public class UpdateAdRewardPanel : GameEvent
{

}

public class JokerEvent : GameEvent
{
}
public class UndoBuyJokerEvent : GameEvent
{
}

public class AddCollectCoinMod
{
    public CardData coinModCard;

    //public AddCollectCoinMod(CardData _coinModCard) => coinModCard = _coinModCard;
    public void Init(CardData _coinModCard)
    {
        coinModCard = _coinModCard;
    }
}

public class UndoCollectCoinMod
{
    public CardData coinModCard;

    public UndoCollectCoinMod(CardData _coinModCard) => coinModCard = _coinModCard;
}

public class CopyCardEvent : GameEvent
{
    public string cardType;
    public int cardID;

    public CopyCardEvent(string i, int cardId)
    {
        cardType = i;
        cardID = cardId;
    }
}

public class GameRewardChangeEvent : GameEvent
{
    public int oldNum;
    public int newNum;
    public bool isAdd;
    public int prop;
    public PropChangeWay changeWay;
    public object[] param;
    public void Init(int _prop, int _oldCoin, int _newCoin, PropChangeWay _changeWay, object[] _param)
    {
        oldNum = _oldCoin;
        newNum = _newCoin;
        isAdd = _oldCoin < _newCoin;
        prop = _prop;
        changeWay = _changeWay;
        param = _param;
    }
}

public class RefreshGameViewEvent : GameEvent
{
    public GameData gameData;
    public void Init(GameData a)
    {
        gameData = a;
    }
}

public class UpdateUndoBtnState : GameEvent
{
}

public class UpdateCurRewardState : GameEvent
{
    public bool state;

    public UpdateCurRewardState(bool _show)
    {
        state = _show;
    }
}

public class AddComboFinishCoinEvent : GameEvent
{
    public int addCoin;

    public void Init(int a)
    {
        addCoin = a;
    }
}

public class ComboChangeEvent : GameEvent
{
    public int comboStep;
    public int comboCount;
    public int comboLimit;
    public List<bool> colors;

    public ComboChangeEvent(int comboStep, int comboCount, int comboLimit, List<bool> colors)
    {
        this.comboStep = comboStep;
        this.comboCount = comboCount;
        this.comboLimit = comboLimit;
        this.colors = new List<bool>(colors);
    }
}

public class ComboUndoRewardEvent : GameEvent
{
    public readonly int starNum;
    public readonly int coinNum;
    public readonly List<int> cardIDArray;
    public ComboUndoRewardEvent(int _starNum, int _coinNum, List<int> _cardIDArray)
    {
        starNum = _starNum;
        coinNum = _coinNum;
        if (_cardIDArray != null)
            cardIDArray = new List<int>(_cardIDArray);
    }
}

public class TouchCardEvent : GameEvent
{
    public int cardId;
    public void Init(int _carId)
    {
        cardId = _carId;
    }
}


public class BuyCardsEvent : GameEvent
{
}

public class BuyPlus5Event : GameEvent
{
}

public class HideGiftDragPopup : GameEvent
{
}

public class HideGiftPlusPopup : GameEvent
{
}

public class UpdateRankViewEvent : GameEvent
{
}

public class UpdateCookFinishEvent : GameEvent
{
}

public class UpdateSeasonViewEvent : GameEvent
{
}

public class UpdateCollectFlowerInfoEvent : GameEvent
{
}


public class UpdateEmailInfoEvent : GameEvent
{
}

public class UpdateWheelEvent : GameEvent
{

}

public class UpdateEndlessRankInfoEvent : GameEvent
{

}

public class RefreshActivityRank : GameEvent
{
}

public class AddFlowerEvent : GameEvent
{
    public int addCount;
    public AddFlowerEvent(int _addCount)
    {
        addCount = _addCount;
    }
}

public class UpdateCollectLoveCardViewEvent : GameEvent
{
}

public class CookGetProgressCoin : GameEvent
{
}

public class FlowAddEvent : GameEvent
{
    public int cardId;
    public int num;
    public int multiple;
    public Vector3 pos;
    public float delayTime;
    public bool needAddAnim;
    public PropEnum propEnum;
    public bool needAddData;
    public void Init(int _num, int _multiple, Vector3 _pos, PropEnum _propEnum, float _delayTime = 0, bool _needAddAnim = false, bool _needAddData = true)
    {
        num = _num;
        multiple = _multiple;
        pos = _pos;
        delayTime = _delayTime;
        needAddAnim = _needAddAnim;
        propEnum = _propEnum;
        needAddData = _needAddData;
    }
}

public class ResetBattleRenderTimeEvent : GameEvent
{

}

public class FlowAddQueueEvent : GameEvent
{
    public FlowAddEvent flowAddEvent;
    public void Init(FlowAddEvent flowAddEvent)
    {
        this.flowAddEvent = flowAddEvent;
    }
}

public class MusicMuteEvent : GameEvent
{
    public bool isMute;
    public MusicMuteEvent(bool _isMute) => isMute = _isMute;
}

public class SoundMuteEvent : GameEvent
{
    public bool isMute;
    public SoundMuteEvent(bool _isMute) => isMute = _isMute;
}

public class FbLinkStateRefreshEvent : GameEvent { } // Fb关联状态

public class ActivityTimerRefresh : GameEvent // 赛季时间刷新
{
    public int remainTime;
    public ActivityType acType;

    public void Init(ActivityType acType, int remainTime)
    {
        this.remainTime = remainTime;
        this.acType = acType;
    }
}

public class SeasonGetRewardEvent : GameEvent
{
    public Vector3 pos;
    public List<SeasonLvRewardItem> rewards;
    public string boxIcon;

    public SeasonGetRewardEvent(Vector3 pos, List<SeasonLvRewardItem> rewards, string boxIcon = "")
    {
        this.pos = pos;
        this.rewards = rewards;
        this.boxIcon = boxIcon;
    }
}

public class SeasonExpRefresh : GameEvent { }

public class GlobalTimerRefreshEvent : GameEvent { } // 全局定时器刷新

public class PlayGetLoveCardReward : GameEvent
{
    public int propEnum;
    public int count;
    public bool needPlay;
    public PlayGetLoveCardReward(int _propEnum, int _count, bool _needPlay)
    {
        propEnum = _propEnum;
        count = _count;
        needPlay = _needPlay;
    }
}

public class PlayGetMusicReward : GameEvent
{
    public int propEnum;
    public int count;
    public bool needPlay;
    public PlayGetMusicReward(int _propEnum, int _count, bool _needPlay)
    {
        propEnum = _propEnum;
        count = _count;
        needPlay = _needPlay;
    }
}

public class NewDayChangeEvent : GameEvent { } // 新的一天

public class RefreshUserInfoCoin : GameEvent
{
    public readonly long oldCoin;
    public readonly long newCoin;
    public readonly PropChangeWay getWay;
    public object[] param;
    public RefreshUserInfoCoin(long _old, long _new, PropChangeWay _getWay, params object[] _param)
    {
        oldCoin = _old;
        newCoin = _new;
        getWay = _getWay;
        param = _param;
    }
}

public class RefreshUserInfoBuildCoin : GameEvent
{
    public long oldCoin;
    public long newCoin;
    public PropChangeWay getWay;
    public object[] param;
    public void Init(long _old, long _new, PropChangeWay _getWay, params object[] _param)
    {
        oldCoin = _old;
        newCoin = _new;
        getWay = _getWay;
        param = _param;
    }
}

public class RefreshUserInfoEnergy : GameEvent
{
    public readonly long oldValue;
    public readonly long newValue;
    public RefreshUserInfoEnergy(long _old, long _new)
    {
        oldValue = _old;
        newValue = _new;
    }
}

public class GameFinishEvent : GameEvent
{
    public GameData gameData;
    public void Init(GameData a)
    {
        gameData = a;
    }
}

public class ViewRefreshEvent : GameEvent
{

}

public class GameCleanEvent : GameEvent
{
}

public class UpdateFarmingPanelEvent : GameEvent
{

}

public class MatchSucessEvent : GameEvent
{

}

public class HarvestPlant : GameEvent
{
    public readonly int landId;

    public HarvestPlant(int _landId) => landId = _landId;
}

public class HomeHarvestEvent : GameEvent
{
    public readonly int harvestCoin;

    public HomeHarvestEvent(int _harvestCoin) => harvestCoin = _harvestCoin;
}

public class StageStarChange
{
    public readonly long oldStar;
    public readonly long newStar;
    public StageStarChange(long _old, long _new)
    {
        oldStar = _old;
        newStar = _new;
    }
}

public class FlowerStageStarChange
{
    public readonly int oldStar;
    public readonly int newStar;
    public FlowerStageStarChange(int _old, int _new)
    {
        oldStar = _old;
        newStar = _new;
    }
}

public class NextBuildChange
{
    public readonly int oldNextBuild;
    public readonly int newNextBuild;
    public NextBuildChange(int _old, int _new)
    {
        oldNextBuild = _old;
        newNextBuild = _new;
    }
}

public class BuildChoiceChange
{
    public readonly int buildId;
    public readonly int? oldChoice;
    public readonly int newChoice;
    public readonly Action onBuildEnd;
    public BuildChoiceChange(int _buildId, int? _oldChoice, int _newChoice, Action _onBuildEnd)
    {
        buildId = _buildId;
        oldChoice = _oldChoice;
        newChoice = _newChoice;
        onBuildEnd = _onBuildEnd;
    }
}

public class UpdateSelectItem : GameEvent { }

public class PropChangeEvent : GameEvent
{
    public int prop;
    public long oldNum;
    public long newNum;

    public void Init(int _prop, long _oldNum, long _newNum)
    {
        prop = _prop;
        oldNum = _oldNum;
        newNum = _newNum;
    }
}

public class PowerupTimeItemEndEvent : GameEvent
{
    public readonly int prop;
    public readonly long startTime;
    public readonly long endTime;

    public PowerupTimeItemEndEvent(int _prop, long _startTime, long _endTime)
    {
        prop = _prop;
        startTime = _startTime;
        endTime = _endTime;
    }
}

public class CanUndoChangeEvent : GameEvent
{
    public bool canUndo;
    public GameData gameData;
    public CanUndoChangeEvent(bool a, GameData b)
    {
        canUndo = a;
        gameData = b;
    }
}

public class GM_WinGame : GameEvent
{
    public readonly int winStar;
    public GM_WinGame(int _winStar) => winStar = _winStar;
}

public class GM_HideUI : GameEvent
{
    public bool isVisibel;
    public GM_HideUI(bool a)
    {
        isVisibel = a;
    }
}

public class CheckGuideJokerEvent : GameEvent { }
public class ScaleJokerEvent : GameEvent { }
public class ScaleUndoEvent : GameEvent { }

public class DownloadLevelJsonResultEvent : GameEvent
{
    public readonly string url;
    public readonly int code;
    public readonly bool success;

    public DownloadLevelJsonResultEvent(string url, int code, bool success)
    {
        this.url = url;
        this.code = code;
        this.success = success;
    }
}

public class DownloadLevelJsonUpdateEvent : GameEvent
{
    public readonly string url;
    public readonly long downloaded;
    public readonly long length;

    public DownloadLevelJsonUpdateEvent(string url, long downloaded, long length)
    {
        this.url = url;
        this.downloaded = downloaded;
        this.length = length;
    }
}

public class WheelStarChange : GameEvent
{
    public readonly long oldStar;
    public readonly long newStar;
    public WheelStarChange(long _old, long _new)
    {
        oldStar = _old;
        newStar = _new;
    }
}

public class SaverShowChange : GameEvent
{
    public readonly bool shouldShow;

    public SaverShowChange(bool _shouldShow)
    {
        shouldShow = _shouldShow;
    }
}

public class VipStateChange : GameEvent
{
}

public class PopPushGift : GameEvent
{
    public string productId;
    public GiftType giftType;
    public PopPushGift(string _productId, GiftType _giftType)
    {
        productId = _productId;
        giftType = _giftType;
    }
}

public class RefreshEndlessLevel : GameEvent
{

}

public class RefreshHeartBeatGift : GameEvent
{

}

public class RefreshActivityTimer : GameEvent
{
    public ActivityType activityType = ActivityType.none;
    public void Init(ActivityType _activityType = ActivityType.none)
    {
        activityType = _activityType;
    }
}

public class CollectFarmingCoin : GameEvent
{
    public int count;
    public bool playBeforeAnim;
    public PropChangeWay propChangeWay;
    public CollectFarmingCoin(int _count, bool _playBeforeAnim, PropChangeWay _propChangeWay)
    {
        count = _count;
        playBeforeAnim = _playBeforeAnim;
        propChangeWay = _propChangeWay;
    }
}

public class SendUpdateSeasonRemid : GameEvent
{

}

public class UpdateGradientGift : GameEvent
{

}

public class HideDiscountGiftPopup : GameEvent
{

}
public class UpdateGiftDigProgress : GameEvent
{

}
public class UpdateGiftDig : GameEvent
{

}
public class UpdateGiftCookProgress : GameEvent
{

}


public class UpdateGiftCook : GameEvent
{

}

public class CheckAddCollectItem : GameEvent
{

}

public class JumpNextTreasure : GameEvent
{
    public float delayPlay;
    public JumpNextTreasure(float _delayPlay)
    {
        delayPlay = _delayPlay;
    }
}

public class PlayGetTreasure : GameEvent
{
    public float delayPlay;
    public int propIndex;
    public PlayGetTreasure(int _propIndex, float _delayPlay)
    {
        propIndex = _propIndex;
        delayPlay = _delayPlay;
    }
}

public class PurchaseSuccess : GameEvent
{
    // public readonly string productKey;
    // public readonly Product purchasedProduct;
    // public PurchaseSuccess(Product _purchasedProduct, string _productKey)
    // {
    //     productKey = _productKey;
    //     purchasedProduct = _purchasedProduct;
    // }
}

public class PurchaseFailed : GameEvent
{
    // public readonly Product product;
    // public readonly PurchaseFailureReason failureReason;
    // public PurchaseFailed(Product _product, PurchaseFailureReason _failureReason)
    // {
    //     product = _product;
    //     failureReason = _failureReason;
    // }
}

public class DoTurnCardEvent : GameEvent
{
}

public class ChangeDeviceOrientationEvent : GameEvent
{
}

public class RookieTriggerBeginEvent : GameEvent
{
    public RookieModel.RookieType rookieType;
    public int rookieId;
    public Vector2 pos;
    public Rect touchRect;
    public List<GameObject> objs;

    public RookieDialogueDicModel dialogueDicModel;
    public RookieDragModel dragModel;
    public RookieAnimModel animModel;
    public void Init(int a, Vector2 b, Rect c)
    {
        rookieType = RookieModel.RookieType.Click;
        rookieId = a;
        pos = b;
        touchRect = c;
    }

    public void Init2(int rookieId, RookieDialogueDicModel dialogueDicModel)
    {
        rookieType = RookieModel.RookieType.Dialogue;
        this.rookieId = rookieId;
        this.dialogueDicModel = dialogueDicModel;
    }

    public void Init3(int rookieId, RookieDragModel dragModel, List<GameObject> objs)
    {
        rookieType = RookieModel.RookieType.Drag;
        this.dragModel = dragModel;
        this.rookieId = rookieId;
        this.objs = objs;
    }

    public void Init4(int rookieId, RookieAnimModel animModel)
    {
        rookieType = RookieModel.RookieType.Anim;
        this.rookieId = rookieId;
        this.animModel = animModel;
    }
}

public class RookieTriggerEndEvent : GameEvent
{
    public RookieModel.RookieType rookieType;
    public int rookieId;
    public Vector2 clickPos;
    public void Init(int rookieId, Vector2 clickPos)
    {
        rookieType = RookieModel.RookieType.Click;
        this.rookieId = rookieId;
        this.clickPos = clickPos;
    }

    public void Init2(int rookieId)
    {
        rookieType = RookieModel.RookieType.Dialogue;
        this.rookieId = rookieId;
    }

    public void Init3(int rookieId)
    {
        rookieType = RookieModel.RookieType.Drag;
        this.rookieId = rookieId;
    }
    public void Init4(int rookieId)
    {
        rookieType = RookieModel.RookieType.Anim;
        this.rookieId = rookieId;
    }
}

public class RookieMergeEndEvent : GameEvent
{
    public int startGridId;
    public int endGridId;
    public RookieMergeEndEvent(int startGridId, int endGridId)
    {
        this.startGridId = startGridId;
        this.endGridId = endGridId;
    }
}


public class BattleCommandEvent : GameEvent
{
    public BattleCommand command;
    public BattleConfig battleConfig;
}


public class OperatCommandEvent : GameEvent
{
    public IBattleOperation operation;
    public OperatCommandEvent(IBattleOperation a)
    {
        operation = a;
    }
}

public class RenderCommandEvent
{
    public IRenderCommand renderCmd;
    public RenderCommandEvent(IRenderCommand a)
    {
        renderCmd = a;
    }
}

public class ComboEvent : GameEvent
{
    public CardData card;
    public int round;
    public bool done;
    public ComboEvent(CardData a, int round, bool done)
    {
        card = a;
        this.round = round;
        this.done = done;
    }
}

public class FlopHandCardEvent : GameEvent
{
    public bool isFirstFlop;
    public void Init(bool _isFirstFlop) => isFirstFlop = _isFirstFlop;
}

public class BattleResultEvent : GameEvent
{
    public float delayTime;
    public List<BaseCard> cards;
    public void Init(List<BaseCard> a, float b)
    {
        cards = a;
        delayTime = b;
    }
}

public class HandleLeftCardEvent : GameEvent
{

}

public class HomeViewPigEvent : GameEvent
{
    public bool top;
    public Action callback;
    public HomeViewPigEvent(bool a, Action b = null)
    {
        top = a;
        callback = b;
    }
}

public class TriggrePopupEvent : GameEvent
{

}

public class TogglePopupEvent : GameEvent
{
    public bool isShow;
    public string popupName;
}

public class HomeViewSeasonPassEvent : GameEvent
{
    public bool top;
    public Action callback;
    public HomeViewSeasonPassEvent(bool a, Action b = null)
    {
        top = a;
        callback = b;
    }
}

public class UIPopupEvent : GameEvent
{
    public UIPopup popup;
    public AnimationType animationType;
    public void Init(UIPopup a, AnimationType b)
    {
        popup = a;
        animationType = b;
    }
}

public class LevelRankingEvent : GameEvent
{
    public int rankType;
    public string data;
}

public class BackGroundLoadedEvent : GameEvent
{
}

public class RechargeEvent : GameEvent
{
    public bool ret;
    public string product_id;
    public string paramex;
}

public class GameRechargeEvent : GameEvent
{
}

public class JumpResultView : GameEvent
{

}

public class GameUpdateItemEvent : GameEvent
{
}

public class BigBombEvent : GameEvent
{
    public bool show;
    public BigBombEvent(bool a)
    {
        show = a;
    }
}

public class ShowHomeViewEvent : GameEvent
{

}

public class CreateMergeItemEvent : GameEvent
{
    public int gridId;
    public CreateMergeItemEvent(int grid_id)
    {
        this.gridId = grid_id;
    }
}

public class CreateMergeBubbleEvent : GameEvent
{
    public MergeBubbleModel mergeBubbleModel;
    public CreateMergeBubbleEvent(MergeBubbleModel mergeBubbleModel)
    {
        this.mergeBubbleModel = mergeBubbleModel;
    }
}

public class CreateMergeHotAirBallEvent : GameEvent
{
    public MergeHotAirBallModel mergeHotAirBallModel;
    public CreateMergeHotAirBallEvent(MergeHotAirBallModel mergeHotAirBallModel)
    {
        this.mergeHotAirBallModel = mergeHotAirBallModel;
    }
}

public class MainCamerOrthographicSizeEvent : GameEvent
{
    public int orthographicSize;
    public MainCamerOrthographicSizeEvent(int a)
    {
        this.orthographicSize = a;
    }
}

public class MainCamerResetEvent : GameEvent
{
}

public class RemoveMergeItemEvent : GameEvent
{
    public int gridId;
    public RemoveMergeItemEvent(int grid_id)
    {
        gridId = grid_id;
    }
}

public class FlyBuildExpEvent : GameEvent
{
    public int gridId;
    public int itemId;
    public int stars;
    public FlyBuildExpEvent(int grid_id, int item_id)
    {
        gridId = grid_id;
        itemId = item_id;
        int[] _stars = { 1, 4, 6, 8, 10 };
        int lv = Math.Clamp(item_id - 20001 + 1, 1, 5);
        stars = _stars[lv - 1];
    }
}

public class OpenMergeBubbleEvent : GameEvent
{
    public int bubbleId;
    public List<int> newItemGrids;
    public OpenMergeBubbleEvent(int bubbleId, List<int> newItemGrids)
    {
        this.bubbleId = bubbleId;
        this.newItemGrids = newItemGrids;
    }
}

public class GetOrderRewardsEvent : GameEvent
{
    public int npcGridId;
    public List<int> newItemGrids;
    public int coin;
    public int buildCoin;
    public GetOrderRewardsEvent(int npcGridId, List<int> newItemGrids, int coin, int buildCoin)
    {
        this.npcGridId = npcGridId;
        this.newItemGrids = newItemGrids;
        this.coin = coin;
        this.buildCoin = buildCoin;
    }
}

public class GetRegionRewardsEvent : GameEvent
{
    public int region_id;
    public List<int> items;
    public GetRegionRewardsEvent(int region_id, List<int> items)
    {
        this.region_id = region_id;
        this.items = items;
    }
}

public class UnlockCloudEvent : GameEvent
{
    public int cloud_id;
    public UnlockCloudEvent(int cloud_id)
    {
        this.cloud_id = cloud_id;
    }
}

public class UnlockBuildEvent : GameEvent
{
    public int region_id;
    public int build_lv;
    public UnlockBuildEvent(int region_id, int build_lv)
    {
        this.region_id = region_id;
        this.build_lv = build_lv;
    }
}

public class FlyGridExpEvent : GameEvent
{
    public int fromGridId;
    public Dictionary<int, int> oriGridExp;
    public Dictionary<int, int> newGridExp;
    public FlyGridExpEvent(int fromGridId, Dictionary<int, int> oriGridExp, Dictionary<int, int> newGridExp)
    {
        this.fromGridId = fromGridId;
        this.oriGridExp = oriGridExp;
        this.newGridExp = newGridExp;
    }
}

public class PutLevelBoxEvent : GameEvent
{
    public int grid_id;
    public Vector3 fromPos;
    public PutLevelBoxEvent(int grid_id, Vector3 fromPos)
    {
        this.grid_id = grid_id;
        this.fromPos = fromPos;
    }
}

public class OpenMergeBoxEvent : GameEvent
{
    public int grid_id;
    public List<int> newItemGrids;
    public OpenMergeBoxEvent(int grid_id, List<int> newItemGrids)
    {
        this.grid_id = grid_id;
        this.newItemGrids = newItemGrids;
    }
}

public class BuyItemFromMergeShop : GameEvent
{
    public int idx;
    public BuyItemFromMergeShop(int idx)
    {
        this.idx = idx;
    }
}

public class SeasonPassPaidEvent : GameEvent
{
    public bool active;
    public SeasonPassPaidEvent(bool active)
    {
        this.active = active;
    }
}

public class CheckHotAirBallEvent : GameEvent
{
    public int ballId;
    public CheckHotAirBallEvent(int ballId)
    {
        this.ballId = ballId;
    }
}

public class CollectTaskCardEvent : GameEvent
{
    public Vector3 pos;
    public CollectTaskCardEvent(Vector3 a)
    {
        pos = a;
    }
}


public class RookieStoryOverEvent : GameEvent
{
}

public class UnlockMergeItemEvent : GameEvent
{
    public int itemId;
    public int gridId;
    public UnlockMergeItemEvent(int itemId,int gridId)
    {
        this.itemId = itemId;
        this.gridId = gridId;
    }
}

public class MoveCameraToGridEvent : GameEvent
{
    public int gridId;
    public float time;
    public MoveCameraToGridEvent(int gridId, float time = 0.8f)
    {
        this.gridId = gridId;
        this.time = time; 
    }
}

public class PressMergeItemEvent : GameEvent
{
    public MergeItem item;
    //public PressMergeItemEvent(MergeItem item)
    //{
    //    this.item = item;
    //}
}

public class DragMergeItemEvent : GameEvent
{
    public int itemId;
}

#region AI编辑器
public class AIStartLevelEvent : GameEvent
{
    public int level1;
    public int level2;
    public float linkRate;
    public float comboRate;
    public int itemCount;
    public int runTimes;
    public bool unlimitHandCard;
    public AIStartLevelEvent(int a1, int a2, float b, float c, int d, int e, bool f = false)
    {
        level1 = a1;
        level2 = a2;
        linkRate = b;
        comboRate = c;
        itemCount = d;
        runTimes = e;
        unlimitHandCard = f;
    }
}

public class AIEditorStartLevelEvent : GameEvent
{
    public LevelModel levelModel;
    public int itemCount;
    public int runTimes;
    public bool isRandom;
    public bool isResult;
    public bool isLevel;
    public int result;
    public int level;
    public AIEditorStartLevelEvent(LevelModel lm, int item, int times,
     bool random, bool isRes, bool isLev, int res, int lev)
    {
        levelModel = lm;
        itemCount = item;
        runTimes = times;
        isRandom = random;
        isResult = isRes;
        isLevel = isLev;
        result = res;
        level = lev;
    }
}

public class AIEditorLevelResultEvent : GameEvent
{
    public float winRate;
    public AIEditorLevelResultEvent(float a)
    {
        winRate = a;
    }
}

public class AIStartGameEvent : GameEvent
{
    public int level;
    public int runTimes;
    public bool dao;
    public bool joker;
    public bool windmill;
    public bool win1;
    public bool win2;
    public bool win3;
    public AIStartGameEvent(int level, int runTimes, bool dao, bool joker, bool windmill, bool win1, bool win2, bool win3)
    {
        this.level = level;
        this.runTimes = runTimes;
        this.dao = dao;
        this.joker = joker;
        this.windmill = windmill;
        this.win1 = win1;
        this.win2 = win2;
        this.win3 = win3;
    }
}
#endregion

#region 关卡编辑器
public class EditorSelectedCardEvent : GameEvent
{
    public Transform card;
}

public class EditorShowCardInfoEvent : GameEvent
{
}

public class EditorRectCardsEvent : GameEvent
{
    public OBB obb;
    public EditorRectCardsEvent(OBB _obb)
    {
        obb = _obb;
    }
}

public class EditorMoveCardEvent : GameEvent
{
    public Transform card;
    public EditorMoveCardEvent(Transform a)
    {
        card = a;
    }
}

public class EditorMoveSceneEvent : GameEvent
{
    public bool show;
    public EditorMoveSceneEvent(bool a)
    {
        show = a;
    }
}

public class EditorSelectedLockItemEvent : GameEvent
{
    public bool sel;
    public EditorSelectedLockItemEvent(bool a)
    {
        sel = a;
    }
}

public class EditorShowLockInfoEvent : GameEvent
{
    public bool sel;
    public EditorShowLockInfoEvent(bool a)
    {
        sel = a;
    }
}


#endregion