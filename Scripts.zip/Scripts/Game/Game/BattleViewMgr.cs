using System;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using QFramework;
using UnityEngine;
using UniRx;
using Game.Cards;
using SoliUtils;
using Activities;
using Model;
using UnityEngine.Rendering;

public class BattleViewMgr : ISingleton
{
    //private int cardBackId;
    //private int betValue;

    private Dictionary<int, BaseCard> AllCardsDic = new Dictionary<int, BaseCard>();
    private List<CardData> RecordInitdeskCards = new List<CardData>();
    private List<int> DeskCards = new List<int>();
    private List<int> HandCards = new List<int>();
    private List<int> HandRmCards = new List<int>();
    private List<int> OpenCards = new List<int>();
    private List<int> DiscCards = new List<int>();
    private Dictionary<Tuple<int, int>, GameObject> LinkRopeItems = new Dictionary<Tuple<int, int>, GameObject>();


    private Queue<IRenderCommand> renderCommandQueue = new Queue<IRenderCommand>();
    private bool renderBlock;
    private float renderDuration;
    private float blockDuration;

    private Vector3 lastWaterPos;
    private BaseCard lastCardObj;
    // private GameObject movBeginItem;
    // private GameObject movEndItem;
    private GameObject movGrass;

    private GameObject birdInst;
    private List<GameObject> handAddFlyCard = new List<GameObject>();
    private List<FlowAddEvent> flowAddEventList = new List<FlowAddEvent>();

    public static BattleViewMgr Instance
    {
        get { return SingletonProperty<BattleViewMgr>.Instance; }
    }

    public void OnSingletonInit()
    {
    }
    private BattleViewMgr()
    {
    }

    public void CleanOtherCard()
    {
        BaseCard lastCard = GetLastCardObject();
        if (lastCard != null)
        {
            foreach (var card in AllCardsDic)
            {
                if (card.Value.CardId == lastCard.CardId) continue;
                if (OpenCards.Contains(card.Value.CardId))
                {
                    card.Value.RemoveAllModifier();
                    GameObjManager.Instance.PushGameObject(card.Value.gameObject);
                }
            }
            foreach (var VARIABLE in OpenCards)
            {
                AllCardsDic.Remove(VARIABLE);
            }
            AllCardsDic.TryAdd(lastCard.CardId, lastCard);
        }
    }

    private void CheckRecoveryLastCard()
    {
        BaseCard lastCard = GetLastCardObject();
        if (lastCard)
        {
            lastCard.transform.localScale = Vector3.one;
        }
        lastCard = null;
    }

    private void OnFlowAddQueueEvent(FlowAddQueueEvent e)
    {
        flowAddEventList.Add(e.flowAddEvent);
    }

    public void Clean()
    {
        TypeEventSystem.Send<GameCleanEvent>(new GameCleanEvent());
        CheckRecoveryLastCard();
        foreach (var card in AllCardsDic)
        {
            card.Value.RemoveAllModifier();
            GameObjManager.Instance.PushGameObject(card.Value.gameObject);
        }
        DeskCards.Clear();
        HandCards.Clear();
        HandRmCards.Clear();
        OpenCards.Clear();
        DiscCards.Clear();
        AllCardsDic.Clear();
        renderCommandQueue.Clear();
        renderBlock = false;
        renderDuration = 0;
        // if (movBeginItem != null)
        // {
        //     UnityEngine.Object.Destroy(movBeginItem);
        //     movBeginItem = null;
        // }
        // if (movEndItem != null)
        // {
        //     UnityEngine.Object.Destroy(movEndItem);
        //     movEndItem = null;
        // }
        if (movGrass != null)
        {
            UnityEngine.Object.Destroy(movGrass);
            movGrass = null;
        }
        if (birdInst != null)
        {
            UnityEngine.Object.Destroy(birdInst);
            birdInst = null;
        }

        foreach (var item in LinkRopeItems)
        {
            GameObject.Destroy(item.Value);
        }
        LinkRopeItems.Clear();
        handAddFlyCard.Clear();
        flowAddEventList.Clear();
        TypeEventSystem.UnRegister<FlowAddQueueEvent>(OnFlowAddQueueEvent);
        TypeEventSystem.UnRegister<ResetBattleRenderTimeEvent>(ResetRenderTime);
    }

    public void AddRenderCommand(Queue<IRenderCommand> e)
    {
        foreach (var cmd in e)
        {
            renderCommandQueue.Enqueue(cmd);
        }
    }
    public void AddRenderCommand(IRenderCommand e)
    {
        renderCommandQueue.Enqueue(e);
    }

    public bool IsRendering()
    {
        return renderDuration > 0;
    }

    public bool IsRenderBlock()
    {
        return renderBlock;
    }

    public void Render()
    {
        if (renderDuration > 0)
            renderDuration -= Time.deltaTime;
        if (blockDuration > 0)
            blockDuration -= Time.deltaTime;
        else
            renderBlock = false;
        while (renderCommandQueue.Count > 0 && !renderBlock)
        {
            var renderCommand = renderCommandQueue.Dequeue();
            var duration = 0f;
            renderBlock = renderCommand.block;

            switch (renderCommand)
            {
                case NewCreateCardCommand cmd:
                    AllCardsDic.Add(cmd.CardId, CreateCard(cmd.CardId, cmd.CardData, cmd.BackId, cmd.BetValue));
                    duration = DoRefreshCardPositionCommand(cmd.CardData);
                    break;

                case InitBattleCommand cmd:
                    duration = DoInitBattleCommand(cmd.DeskCards, cmd.HandCards, cmd.isMovingScene);
                    break;

                case AddMoveSceneCammand cmd:
                    duration = DoAddMoveSceneCammand(cmd.startPos, cmd.endPos);
                    break;

                case AddLockItemCammand cmd:
                    duration = DoAddLockItemCammand(cmd.data);
                    break;

                case ItemEliminateDeskCardCommand cmd:
                    duration = DoItemEliminateDeskCardCommand(cmd.eliminateList);
                    break;

                case ItemJokerCommand cmd:
                    duration = DoItemJokerCommand(cmd.jokerCardList);
                    break;

                case ItemCactusCommand cmd:
                    duration = DoItemCactusCommand(cmd.cactusCardList);
                    break;

                case WinStreakCardsCommand cmd:
                    duration = DoWinStreakCardsCommand(cmd.newCards, cmd.handCards);
                    break;

                case CheckLimitPkPopupCommand cmd:
                    duration = DoCheckActivityCommand(cmd.activityType);
                    break;

                case CheckSpecialCardTipCommand cmd:
                    duration = DoCheckSpecialCardTpCommand(cmd);
                    break;

                case RefreshCardValueCommand cmd:
                    duration = DoRefreshCardValueCommand(cmd.cardData);
                    break;

                case RefreshCardPositionCommand cmd:
                    duration = DoRefreshCardPositionCommand(cmd.card);
                    break;

                case FlopHandCardCommand cmd:
                    duration = DoFlopHandCardCommand(cmd.cardData);
                    break;

                case FlopHandCardWindmillCommand cmd:
                    duration = DoFlopHandCardWindmillCommand(cmd.cardList);
                    break;

                case CollectDeskCardCommand cmd:
                    duration = DoCollectDeskCardCommand(cmd.cardData);
                    break;

                case FlopDeskCardCommand cmd:
                    duration = DoFlopDeskCardCommand(cmd.cardData);
                    break;

                case BoomCardCommand cmd:
                    duration = DoBoomCardCommand(cmd.boomCard, cmd.boomFlyCards);
                    break;

                case WindmillCardCommand cmd:
                    duration = DoWindmillCardCommand(cmd.windmillCard, cmd.windmillFlyCards);
                    break;

                case MonkeyBananaCardCommand cmd:
                    duration = DoMonkeyBananaCardCommand(cmd.clickCard, cmd.pairCard);
                    break;

                case ZapCardCommand cmd:
                    duration = DoZapCardCommand(cmd.zapCard, cmd.zapFlyCards);
                    break;

                case UnlockCardCommand cmd:
                    duration = DoUnlockCardCommand(cmd.keyCard, cmd.lockCards);
                    break;

                case BombUpdateCommand cmd:
                    duration = DoBombUpdateCommand(cmd.bombCards);
                    break;

                case BigBombUpdateCommand cmd:
                    duration = DoBigBombUpdateCommand(cmd.bigBombCards);
                    break;

                case BombingCommand cmd:
                    duration = DoBombingCommand(cmd.bombCards, cmd.newCards);
                    break;

                case BigBombingCommand cmd:
                    duration = DoBigBombingCommand(cmd.bigBombCards);
                    break;

                case RisingUpdateCommand cmd:
                    duration = DoRisingUpdateCommand(cmd.risingCards, cmd.undo);
                    break;

                case LoweringUpdateCommand cmd:
                    duration = DoLoweringUpdateCommand(cmd.loweringCards, cmd.undo);
                    break;

                case ThreeCardCommand cmd:
                    duration = DoThreeCardCommand(cmd.threeCard, cmd.newCards, cmd.handCards);
                    break;

                case AnchorCardCommand cmd:
                    duration = DoAnchorCardCommand(cmd.anchorCard);
                    break;

                case CopyCardCommand cmd:
                    duration = DoCopyCardCommand(cmd.copyCard);
                    break;

                case IceBrokenCommand cmd:
                    duration = DoIceBrokenCommand(cmd.iceCard);
                    break;

                case BreakIceByHandCardCommand cmd:
                    duration = DoBreakIceByHandCardCommand(cmd.iceCard);
                    break;

                case UndoFlopHandCardCommand cmd:
                    duration = DoUndoFlopHandCardCommand(cmd.handCards);
                    break;

                case UndoDeskCardCommand cmd:
                    duration = DoUndoDeskCardCommand(cmd.card);
                    break;

                case UndoBreakIceCommand cmd:
                    duration = DoUndoBreakIceCommand(cmd.iceCard, cmd.openCard);
                    break;

                // case UndoCopyCardCommand cmd:
                //     duration = DoUndoCopyCardCommand(cmd.card,cmd.cardOperate);
                //     break;

                case UndoWindmillCardCommand cmd:
                    duration = DoUndoWindmillCardCommand(cmd.pos, cmd.windmillCard, cmd.windmillFlyCards);
                    break;

                case UndoMonkeyBananaCardCommand cmd:
                    duration = DoUndoMonkeyBananaCardCommand(cmd.monkeyCard, cmd.bananaCard);
                    break;

                case BuyJokerCommand cmd:
                    duration = DoBuyJokerCommand(cmd.card);
                    break;

                case UndoBuyJokerCommand cmd:
                    duration = UndoBuyJokerCommand(cmd.card);
                    break;

                case BuyCardsCommand cmd:
                    duration = DoBuyCardsCommand(cmd.cards);
                    break;

                case AddComboCardCommand cmd:
                    DoAddComboCardCommand(cmd.newCards, cmd.handCards, cmd.waitTime);
                    break;

                case UndoComboCardCommand cmd:
                    duration = DoUndoComboCardCommand(cmd.removeCards);
                    break;

                case ShakeCardCommand cmd:
                    duration = DoShakeCardCommand(cmd.card);
                    break;

                case ScaleCardCommand cmd:
                    duration = DoScaleCardCommand(cmd.cardData);
                    break;

                case MoveSceneCammand cmd:
                    duration = DoMoveSceneCammand(cmd.distance, cmd.cards, cmd.hide);
                    break;

                case UndoMoveSceneCammand cmd:
                    duration = UndoMoveSceneCammand(cmd.cards);
                    break;

                case ShowResultCommand cmd:
                    DoShowResultCommand(cmd.win, renderDuration);
                    break;

                case ExitBattleCommand cmd:
                    DoExitBattleCommand();
                    break;

                case RopeSuitUpdateCommand cmd:
                    DoRopeSuitUpdateCommand(cmd.cardList, cmd.resetValue);
                    break;

                case ClothRoundUpdateCommand cmd:
                    DoUpdateClothStateSwitchRoundCommand(cmd);
                    break;

                case GreenLeafUpdateCommand cmd:
                    duration = DoGreenLeafUpdateCommand(cmd.lastBirdCard, cmd.cardList);
                    break;

                case ShowBirdCommand cmd:
                    duration = DoShowBirdCommand(cmd.pos);
                    break;


                case FlyBirdCommand cmd:
                    duration = DoFlyBirdCommand(cmd.toPos);
                    break;

                case LightningUpdateCommand cmd:
                    DoUpdateLightningTimerCommand(cmd.cardList);
                    break;

                case LightningCardMissCommand cmd:
                    duration = DoLightningCardMissingCommand(cmd.lightningCard, cmd.handCard, cmd.undo);
                    break;

                case ItemWindmillCardCommand cmd:
                    DoItemWindmillCardCommand(cmd.newCards.ToArray(), cmd.handCards, 0.3f);
                    break;
                case RabbitCardCommand cmd:
                    DoAddRabitCardCommand(cmd.newCards.ToArray(), cmd.handCards, 0.3f);
                    break;
                case RefreshLinkRopeCommand cmd:
                    DoRefreshLinkRopeCommand(cmd.lockCards, cmd.unlockCards);
                    break;

                case CollectLinkCardCommand cmd:
                    duration = DoCollectLinkCardCommand(cmd.firstCard, cmd.lastCard);
                    break;

                case RefreshAnchorCardCommand cmd:
                    DoRefreshAnchorCardCommand(cmd.cards, cmd.undo, cmd.skipAnim);
                    break;

                case SortHandCardCommand cmd:
                    TypeEventSystem.Send<HandCardChangeEvent>(new HandCardChangeEvent(cmd.handCardNumber));
                    HandCardIndentAction();
                    break;

                case RemoveHandCardCommand cmd:
                    DoRemoveHandCardCommand(cmd.removeHandCards);
                    break;

                case RestoreDeskCardCommand cmd:
                    DoRestoreDeskCardCommand(cmd.deskHandCards);
                    break;

                case UndoKeyLockCardCommand cmd:
                    UndoKeyLockCardCommand(cmd.deskHandCards);
                    break;

                case RefreshSuitRopeCommand cmd:
                    DoRefreshSuitRopeCommand(cmd.card);
                    break;

                case UndoBombUpdateCommand cmd:
                    UndoBombUpdateCommand(cmd.bombCardId, cmd.bombCards);
                    break;

                case UndoLinkCardCommand cmd:
                    duration = UndoLinkCardCommand(cmd.clickCard, cmd.linkCard);
                    break;

                case RemoveModifierCommand cmd:
                    DoRemoveModifierCommand(cmd.cards);
                    break;

                case RecycleModifierCommand cmd:
                    DoRecycleModifierCommand(cmd.card);
                    break;

                case ComboViewCommand cmd:
                    DoComboViewCommand(cmd);
                    break;

                case QuestionCardCommand cmd:
                    duration = DoQuestionCardCommand(cmd);
                    break;

                case UndoQuestionCardCommand cmd:
                    duration = UndoQuestionCardCommand(cmd);
                    break;

                case RudderCardCommand cmd:
                    duration = DoRudderCardCommand(cmd.rudderCard, cmd.rudderFlyCards);
                    break;

                case LizardCardCommand cmd:
                    duration = DoLizardCardCommand(cmd.lizardCards, cmd.removeCards);
                    break;

            }
            if (renderBlock)
            {
                blockDuration = Math.Max(blockDuration, duration);
            }
            renderDuration = Math.Max(renderDuration, duration);
        }
    }

    private float DoScaleCardCommand(CardData targetCard)
    {
        AllCardsDic[targetCard.id].DoScaleAnim();
        return 0;
    }

    private float DoMoveSceneCammand(float distance, List<CardData> cards, bool hide)
    {
        float t = 0.5f;
        foreach (var cardId in DeskCards)
        {
            BaseCard card = AllCardsDic[cardId];
            var posx = card.transform.position.x - distance;
            card.transform.DOMoveX(posx, t).SetEase(Ease.InQuad);
            if (card.CardData.HasBird())
            {
                if (birdInst != null)
                {
                    var birdPos = birdInst.transform.position;
                    birdPos.x = posx;
                    birdInst.GetComponent<SortingGroup>().sortingOrder = 31;
                    birdInst.transform.DOMove(birdPos, t).OnComplete(() =>
                    {
                        birdInst.GetComponent<SortingGroup>().sortingOrder = 0;
                    });
                    birdInst.GetComponent<Animator>().Play("Card_Bird_fly");
                    SoundPlayer.Instance.PlayMainSound("Ladybug_Fly");
                }
            }
        }
        foreach (var card in cards)
        {
            if (AllCardsDic.TryGetValue(card.id, out var tarCard) && !card.IsLocked)
            {
                tarCard.DoAlphaAnim(1);
            }
        }
        // if (movBeginItem != null)
        // {
        //     movBeginItem.SetActive(!hide);
        // }
        // if (movEndItem != null)
        // {
        //     var posx = movEndItem.transform.position.x - distance;
        //     movEndItem.transform.DOMoveX(posx, t).SetEase(Ease.InQuad);
        // }
        if (movGrass != null && Math.Abs(distance) > 10)
        {
            var animtors = movGrass.GetComponentsInChildren<Animator>();
            foreach (var animator in animtors)
            {
                animator.SetTrigger("moving");
            }
        }
        return t;
    }

    private float UndoMoveSceneCammand(List<CardData> cards)
    {
        float t = 0.5f;
        float distance = 0f;
        foreach (var cardData in cards)
        {
            BaseCard card = AllCardsDic[cardData.id];
            distance = cardData.cm.Position.x - card.transform.position.x;
            card.transform.DOMoveX(cardData.cm.Position.x, t).SetEase(Ease.InQuad);
            if (cardData.IsLocked)
                card.DoAlphaAnim(0.2f, 0);
        }

        foreach (var cardId in DeskCards)
        {
            BaseCard card = AllCardsDic[cardId];
            if (card.CardData.HasBird())
            {
                if (birdInst != null)
                {
                    var birdPos = birdInst.transform.position;
                    birdPos.x += distance;
                    birdInst.GetComponent<SortingGroup>().sortingOrder = 31;
                    birdInst.transform.DOMove(birdPos, t).OnComplete(() =>
                    {
                        birdInst.GetComponent<SortingGroup>().sortingOrder = 0;
                    });
                    birdInst.GetComponent<Animator>().Play("Card_Bird_fly");
                    SoundPlayer.Instance.PlayMainSound("Ladybug_Fly");
                }
            }
        }

        // if (movBeginItem != null)
        // {
        //     movBeginItem.SetActive(true);
        // }
        // if (movEndItem != null)
        // {
        //     var posx = movEndItem.transform.position.x + distance;
        //     movEndItem.transform.DOMoveX(posx, t).SetEase(Ease.InQuad);
        // }
        if (movGrass != null && Math.Abs(distance) > 10)
        {
            var animtors = movGrass.GetComponentsInChildren<Animator>();
            foreach (var animator in animtors)
            {
                animator.SetTrigger("moving");
            }
        }

        return t;
    }

    private void DoShowResultCommand(bool win, float time)
    {
        if (win)
        {
            BoxBuilder.HideExitGameTipPopup();
            List<BaseCard> baseCards = HandCards.Select(x => AllCardsDic[x]).ToList();
            BattleResultEvent t = GameObjManager.Instance.PopClass<BattleResultEvent>();
            t.Init(baseCards, time);
            TypeEventSystem.Send<BattleResultEvent>(t);
        }
        else
        {
            Sequence seq = DOTween.Sequence();
            seq.AppendInterval(0.4f);
            GameController.Instance.ExitBattle();
            MoveGameViewBottom t = GameObjManager.Instance.PopClass<MoveGameViewBottom>(true);
            TypeEventSystem.Send<MoveGameViewBottom>(t);
            TypeEventSystem.Send(new BattleCommandEvent() { command = BattleCommand.LoseGame });
            //ActivityManager.Instance.CheckOpenActivity(false);
            seq.AppendInterval(1f);
            seq.AppendCallback(() =>
            {
                if (ActivityManager.Instance.LavaPassActivity.CheckShowLavaPopup(BoxBuilder.ShowRestartPopup)) return;
                BoxBuilder.ShowRestartPopup();
            });
            var dataService = MainContainer.Container.Resolve<IDataService>();
            dataService.SaveData(true);
        }
    }

    private void DoExitBattleCommand()
    {
        foreach (var cardId in DeskCards)
        {
            BaseCard card = AllCardsDic[cardId];
            var pos = new Vector3(UnityEngine.Random.Range(-50, 50), UnityEngine.Random.Range(20, 50), 0);
            card.DoBeBoomAnim(card.transform.position + pos);
        }
        foreach (var cardId in HandCards)
        {
            BaseCard card = AllCardsDic[cardId];
            var pos = new Vector3(UnityEngine.Random.Range(-50, 50), UnityEngine.Random.Range(20, 50), 0);
            card.DoBeBoomAnim(card.transform.position + pos);
        }
        foreach (var cardId in OpenCards)
        {
            BaseCard card = AllCardsDic[cardId];
            var pos = new Vector3(UnityEngine.Random.Range(-50, 50), UnityEngine.Random.Range(20, 50), 0);
            card.DoBeBoomAnim(card.transform.position + pos);
        }
        DeskCards.Clear();
        HandCards.Clear();
        OpenCards.Clear();
    }

    private float DoShakeCardCommand(CardData _card)
    {
        AllCardsDic[_card.id].DoErrorCardAnim();
        return 0f;
    }

    private float DoAddComboCardCommand(int[] newCards, List<int> handCards, float waitTime)
    {
        int otherCommandCount = renderCommandQueue.Count(x => x is AddComboCardCommand) - 1;
        var handCardNum = handCards.Count;

        for (int i = 0; i < newCards.Length; i++)
        {
            int cardId = newCards[i];
            var toIndex = handCards.IndexOf(cardId);
            HandCards.Insert(toIndex, cardId);
        }
        HandCardIndentAction();

        var t1 = waitTime + 0.3f;
        var t2 = 0f;
        for (int i = 0; i < newCards.Length; i++)
        {
            var cardId = newCards[i];
            var cardObj = AllCardsDic[cardId];
            cardObj.gameObject.SetActive(true);
            var toIndex = handCards.IndexOf(cardId);
            Vector3Int toPos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * toIndex + new Vector3Int(0, 0, toIndex - handCardNum);
            Vector3 formPos = GameObjTransInfo.ComboAddCardPos - new Vector3(0, 0, otherCommandCount);
            t2 = cardObj.DoComboAddCardAnim(formPos, toPos, t1, 0.4f * i + otherCommandCount * 0.4f);
            handAddFlyCard.Add(cardObj.gameObject);
            Observable.Timer(TimeSpan.FromSeconds(t1 + t2)).Subscribe(_ =>
            {
                for (int i = 0; i < newCards.Length; i++)
                {
                    var _cardId = newCards[i];
                    if (AllCardsDic.ContainsKey(_cardId))
                    {
                        var _cardObj = AllCardsDic[_cardId];
                        handAddFlyCard.Remove(_cardObj.gameObject);
                    }
                }
                HandCardIndentAction();
            });
        }
        Observable.Timer(TimeSpan.FromSeconds(2f)).Subscribe(_ =>
        {
            foreach (var card in AllCardsDic)
            {
                if (handAddFlyCard.Contains(card.Value.gameObject))
                {
                    handAddFlyCard.Remove(card.Value.gameObject);
                }
            }
        });

        // AddRenderCommand(new SortHandCardCommand(handCardNum));
        TypeEventSystem.Send<HandCardChangeEvent>(new HandCardChangeEvent(handCards.Count));

        return t1 + t2;
    }

    private float DoUndoComboCardCommand(List<int> removeCards)
    {
        foreach (var cardId in removeCards)
        {
            HandCards.Remove(cardId);
            HandRmCards.Remove(cardId);
            AllCardsDic[cardId].gameObject.SetActive(false);
        }

        var handCardNum = HandCards.Count;
        for (int i = 0; i < HandCards.Count; i++)
        {
            int cardId = HandCards[i];
            BaseCard card = AllCardsDic[cardId];
            Vector3Int toPos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * i + new Vector3Int(0, 0, i - handCardNum);
            card.transform.DOLocalMove(toPos, 0.5f);
        }

        AddRenderCommand(new SortHandCardCommand(HandCards.Count));

        return 0;
    }

    //购买手牌
    private float DoBuyCardsCommand(List<CardData> handCards)
    {
        var duration = 0f;

        foreach (var cardData in handCards)
        {
            AllCardsDic[cardData.id].gameObject.SetActive(true);
            HandCards.Add(cardData.id);
        }

        duration = ShowBuyHandsCard(handCards);
        // AddRenderCommand(new SortHandCardCommand(handCards.Count));
        TypeEventSystem.Send<HandCardChangeEvent>(new HandCardChangeEvent(handCards.Count));

        return duration;
    }

    private float DoBuyJokerCommand(CardData card)
    {
        var jokerCard = AllCardsDic[card.id];
        jokerCard.gameObject.SetActive(true);
        var openCardPos = GameObjTransInfo.OpenCardPos;
        if (OpenCards.Count > 0)
            openCardPos.z = (int)(AllCardsDic[OpenCards[0]].transform.position.z - OpenCards.Count);
        float duration = (float)((jokerCard as JokerCard)?.DoJokerToHandCards(GameObjTransInfo.JokerPos, openCardPos));
        OpenCardsAdd(card.id);

        return duration;
    }

    private float UndoBuyJokerCommand(CardData card)
    {
        var jokerCard = AllCardsDic[card.id];

        var openCardPos = GameObjTransInfo.OpenCardPos;
        if (OpenCards.Count > 0)
            openCardPos.z = (int)(AllCardsDic[OpenCards[0]].transform.position.z - OpenCards.Count);
        float duration = (float)((jokerCard as JokerCard)?.UndoJokerToHandCards(openCardPos, GameObjTransInfo.JokerPos));
        OpenCardsRemove(card.id);

        return duration;
    }

    private float DoUndoCopyCardCommand(CardData card, int cardOpt)
    {
        var duration = 0f;
        if (cardOpt == 1)
        {
            TypeEventSystem.Send(new CopyCardEvent(Constants.CardTypeCopy, card.cm.id));
        }
        else if (cardOpt == 2)
        {
            if (OpenCards.Count == 0)
                return duration;

            int curCardId = OpenCards[OpenCards.Count - 1];
            var curCard = AllCardsDic[curCardId];
            if (curCardId == card.id)
            {
                DeskCardsAdd(curCardId, true);
                OpenCardsRemove(curCardId);
                duration = curCard.UndoOpenCardFromDesktop();
                DoRefreshCardValueCommand(card);
                curCard.ResetModifier();
            }
        }

        return duration;
    }

    private float DoUndoWindmillCardCommand(Vector3 pos, CardData windmillCard, List<CardData> windmillFlyCards)
    {
        var duration = 0f;

        var wmCardMono = AllCardsDic[windmillCard.id];
        OpenCardsAdd(windmillCard.id);
        DiscCards.Remove(windmillCard.id);
        duration = (wmCardMono as WindmillCard)?.UndoAnim(pos) ?? duration;
        duration += 0.1f;

        var wmFlyCardMonos = new List<BaseCard>();

        foreach (var wmFlyCard in windmillFlyCards)
        {
            int wmFlyCardId = wmFlyCard.id;
            var tempMono = AllCardsDic[wmFlyCardId];
            tempMono.CardData = wmFlyCard;
            tempMono.UndoFlyOutByWindmill();
            wmFlyCardMonos.Add(tempMono);
            DeskCardsAdd(wmFlyCardId, true);
            DiscCards.Remove(wmFlyCardId);
            // DoRefreshCardValueCommand(wmFlyCard);
        }

        return duration;
    }

    private float DoUndoMonkeyBananaCardCommand(CardData monkeyCard, CardData bananaCard)
    {
        var duration = 0f;

        var monkCardMono = AllCardsDic[monkeyCard.id];
        monkCardMono.gameObject.SetActive(true);
        DeskCardsAdd(monkeyCard.id, true);
        OpenCardsRemove(monkeyCard.id);

        var banaCardMono = AllCardsDic[bananaCard.id];
        banaCardMono.gameObject.SetActive(true);
        DeskCardsAdd(bananaCard.id, true);
        OpenCardsRemove(bananaCard.id);

        return duration;
    }

    private float DoUndoDeskCardCommand(CardData card)
    {
        var duration = 0f;
        if (OpenCards.Count == 0)
            return duration;

        var curCardId = OpenCards.Last();
        if (curCardId == card.id)
        {
            DeskCardsAdd(curCardId, true);
            OpenCardsRemove(curCardId);
            BaseCard curCard = AllCardsDic[curCardId];
            duration = curCard.UndoOpenCardFromDesktop();
            // _ = DoRefreshCardValueCommand(card);
            curCard.ShowModifier(true);
        }
        else
        {
            DiscCards.Remove(card.id);
            DeskCardsAdd(card.id, true);
            BaseCard curCard = AllCardsDic[card.id];
            if (card.CardType == CardType.Three)
                (curCard as ThreeCard).DoTriggerThreeCard(true);
            else if (card.CardType == CardType.Zap || card.CardType == CardType.Boom)
            {
                curCard.UndoCollectedCard();
            }
            else if (card.CardType == CardType.Key)
            {
                curCard.UndoCollectedCard();
            }
        }

        return duration;
    }

    private float DoUndoFlopHandCardCommand(List<int> handCards)
    {
        var duration = 0f;
        if (OpenCards.Count == 0)
            return duration;

        var curCardId = OpenCards[OpenCards.Count - 1];
        if (curCardId == handCards[0])
        {
            var handCardNum = handCards.Count;
            var cardIdx = 0;
            var pos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * cardIdx + new Vector3Int(0, 0, cardIdx - handCardNum);
            HandCards.Insert(0, curCardId);
            OpenCardsRemove(curCardId);
            duration = AllCardsDic[curCardId].UndoOpenCardFromHandCards(pos);
            AddRenderCommand(new SortHandCardCommand(handCardNum));
        }

        return duration;
    }


    private float DoInitBattleCommand(List<CardData> deskCards, List<CardData> handCards, bool isMovingScene)
    {
        TypeEventSystem.Register<FlowAddQueueEvent>(OnFlowAddQueueEvent);
        TypeEventSystem.Register<ResetBattleRenderTimeEvent>(ResetRenderTime);
        return InitCards(deskCards, handCards, isMovingScene);
    }

    private float DoAddMoveSceneCammand(Vector3 startPos, Vector3 endPos)
    {
        var scene = Camera.main.transform.parent;
        // _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/Item/MovItemBegin.prefab", (obj) =>
        // {
        //     movBeginItem = obj;
        //     movBeginItem.transform.SetParent(scene);
        //     movBeginItem.transform.position = startPos;
        // });
        // _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/Item/MovItemEnd.prefab", (obj) =>
        // {
        //     movEndItem = obj;
        //     movEndItem.transform.SetParent(scene);
        //     movEndItem.transform.position = endPos;
        // });
        _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/grass.prefab", (obj) =>
        {
            movGrass = obj;
            movGrass.transform.SetParent(scene);
            // movEndItem.transform.position = endPos;
        });

        // movBeginItem = UnityEngine.Object.Instantiate(GlobalRes.Load<GameObject>("Assets/Res/Prefabs/Item/MovItemBegin.prefab"), scene);
        // movBeginItem.transform.position = startPos;
        // movEndItem = UnityEngine.Object.Instantiate(GlobalRes.Load<GameObject>("Assets/Res/Prefabs/Item/MovItemEnd.prefab"), scene);
        // movEndItem.transform.position = endPos;
        return 0;
    }

    private float DoAddLockItemCammand(LockModel data)
    {
        var scene = Camera.main.transform.parent;
        _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/Item/LockItem.prefab", (lockItem) =>
        {
            lockItem.GetComponent<LockItem>().Show(data);
            lockItem.transform.SetParent(scene);
        });
        // var lockItem = UnityEngine.Object.Instantiate(GlobalRes.Load<GameObject>("Assets/Res/Prefabs/Item/LockItem.prefab"), scene);
        // lockItem.GetComponent<LockItem>().Show(data);
        return 0;
    }

    private float DoItemEliminateDeskCardCommand(List<CardData> eliminateList)
    {
        GameObject cardChipItem = null;
        _ = GlobalRes.DynamicLoadPrefab(Constants.cardChipItemStr, (obj) =>
        {
            cardChipItem = obj;
            cardChipItem.SetActive(true);
            cardChipItem.transform.SetParent(GameObjTransInfo.DefaultScene);
            cardChipItem.transform.position = Vector3.zero;
            cardChipItem.transform.localScale = Vector3.zero;
            cardChipItem.GetComponent<SortingGroup>().sortingOrder = BaseCard.FxSortOrder;
            var animtor = cardChipItem.GetComponent<Animator>();
            animtor.enabled = true;
            SoundPlayer.Instance.PlayMainSound("Zap_appear");
            Sequence seq = DOTween.Sequence();
            seq.SetId(cardChipItem);
            animtor.SetTrigger("ShowItemCard");
            float delay = 1.5f;
            seq.AppendInterval(delay);
            seq.AppendCallback(() =>
            {
            });
            int x = 999999;
            float moveTime = 0f;
            for (int i = 0; i < eliminateList.Count; i++)
            {
                var cardData = eliminateList[i];
                if (DeskCards.Contains(cardData.id))
                {
                    float perWaitTime = 0.5f;
                    float waitTime = perWaitTime * (i + 1) + delay;
                    var card = AllCardsDic[cardData.id];
                    bool hasIce = cardData.HasIce();
                    bool hasSuit = cardData.HasSuitRope();
                    bool hasBomb = cardData.HasBomb();
                    bool hasBigBomb = cardData.HasBigBomb();
                    bool hasLightning = cardData.HasLightning();
                    bool remove = !hasIce && !hasSuit && !hasBomb && !hasBigBomb && !hasLightning;
                    card.DoItemEliminate(waitTime, remove);
                    if (cardData.HasLinkRope())
                    {
                        var cardId1 = cardData.id;
                        var cardId2 = cardData.GetLinkRopeCardId();
                        Observable.Timer(TimeSpan.FromSeconds(waitTime + 0.1f)).Subscribe(_ =>
                        {
                            RemoveLinkRope(cardId1, cardId2);
                        });
                    }

                    seq.AppendInterval(perWaitTime - moveTime);
                    if (x == 999999)
                    {
                        x = card.transform.position.x > 0 ? 700 : -700;
                    }
                    else
                    {
                        x *= -1;
                    }
                    var y = card.transform.position.y;
                    var curX = x;
                    seq.JoinCallback(() =>
                    {
                        if (curX < 0)
                        {
                            animtor.SetTrigger("ElimCutRight");
                        }
                        else
                        {
                            animtor.SetTrigger("ElimCutLeft");
                        }
                    });
                    moveTime = 0.2f;
                    var idx = i;
                    seq.Append(cardChipItem.transform.DOMove(new Vector3(x, y, 0), moveTime)
                        .SetEase(Ease.OutQuad).OnComplete(() =>
                        {
                            if (remove)
                                DeskCardsRemove(cardData.id);
                        }));
                }
            }
            seq.AppendCallback(() =>
            {
                GameObject.Destroy(cardChipItem);
                // GlobalRes.Release<GameObject>(Constants.cardChipItemStr);
            });
        });

        return 5f;
    }

    private float DoItemJokerCommand(List<CardData> jokerList)
    {
        float waitTime = 0;
        int count = jokerList.Count;
        for (int i = 0; i < count; i++)
        {
            CardData cardData = jokerList[i];
            if (!DeskCards.Contains(cardData.id))
                DeskCardsAdd(cardData.id);
            BaseCard cardObj = AllCardsDic[cardData.id];
            cardObj.CardData = cardData;
            Vector3 startPos = new Vector3(400 * ((count - 1) / 2f - i), 0, 0);
            waitTime = (cardObj as JokerCard).DoPowerItemEnter(startPos, 0.2f * i);
        }
        SoundPlayer.Instance.PlayMainSound("Wild_appear");
        return waitTime;
    }

    private float DoItemCactusCommand(List<CardData> cactusList)
    {
        float waitTime = 0;
        int count = cactusList.Count;
        for (int i = 0; i < count; i++)
        {
            CardData cardData = cactusList[i];
            if (!DeskCards.Contains(cardData.id))
                DeskCardsAdd(cardData.id);
            BaseCard cardObj = AllCardsDic[cardData.id];
            cardObj.gameObject.SetActive(true);
            Vector3 startPos = new Vector3(400 * ((count - 1) / 2f - i), 0, 0);
            waitTime = (cardObj as BoomCard).DoPowerItemEnter(startPos, 0.2f * i);
        }
        return waitTime;
    }

    //特色牌新手引导说明弹窗
    private float DoCheckSpecialCardTpCommand(CheckSpecialCardTipCommand cmd)
    {
        float time = 0;
        if (CheckSpecialCardTip(RecordInitdeskCards))
        {
            time = 99999f;
        }
        return time;
    }

    //拳击赛活动弹窗
    private float DoCheckActivityCommand(ActivityType activityType)
    {
        float time = 0;
        LimitPkData data = ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).localData as LimitPkData;
        if (data.PopUI)
        {
            time = 99999f;
            BoxBuilder.ShowStartLimitPkPopup("battle",true);
            ActivityManager.Instance.SaveActivityData();
        }
        return time;
    }

   

    private void ResetRenderTime(ResetBattleRenderTimeEvent obj)
    {
        renderDuration = 0;
        blockDuration = 0;
    }

    //添加连胜获得的卡牌
    private float DoWinStreakCardsCommand(List<int> newCards, List<int> handCards)
    {
        AddRenderCommand(new SortHandCardCommand(handCards.Count));

        _ = GlobalRes.DynamicLoadPrefab("Assets/Res/ArtRes/Prefabs/FX/combox.prefab", (obj) =>
        {
            var t1 = 0.7f;
            var t2 = 0.4f / (newCards.Count + 1);
            var fx = obj;//GameObjManager.Instance.PopGameObject(GameObjType.WinStreakBoxFx);

            var configService = MainContainer.Container.Resolve<IConfigService>();
            var dataService = MainContainer.Container.Resolve<IDataService>();
            var fillAmount = configService.GetWinStreakIdx(dataService.SuccessiveVictory, out var stepIdx);
            int level = stepIdx < 2 ? 1 : (stepIdx < 4 ? 2 : 3);
            _ = fx.Get<SpriteRenderer>("box_back").SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, $"he{level}_2");
            _ = fx.Get<SpriteRenderer>("box_front").SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, $"he{level}_1");
            fx.SetActive(true);
            fx.transform.SetParent(GameObjTransInfo.DefaultScene);
            fx.GetComponent<Animator>().Play("combox");
            var fxPox = fx.transform.position;
            fxPox.z = -80;
            fx.transform.position = fxPox;

            var handCardNum = handCards.Count;
            Vector3 oriCardPos = Vector3.zero;
            Sequence seq = DOTween.Sequence();
            seq.AppendInterval(t1);
            for (int i = 0; i < newCards.Count; i++)
            {
                int cardId = newCards[i];
                var cardObj = AllCardsDic[cardId];
                cardObj.SetStreakBack();
                cardObj.gameObject.SetActive(true);
                var idx = Math.Min(i + 1, 5); //i + 1 > 4 ? 4 : i + 1;
                cardObj.transform.SetParent(fx.transform.Find("box_back/card" + idx));
                cardObj.transform.localPosition = Vector3.zero;
                cardObj.transform.localEulerAngles = Vector3.zero;

                var toIndex = handCards.IndexOf(cardId);
                HandCards.Insert(toIndex, cardId);
                Vector3Int toPos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * toIndex + new Vector3Int(0, 0, toIndex - handCardNum);
                seq.AppendInterval(i * t2);
                seq.AppendCallback(() =>
                {
                    var cardPos = cardObj.transform.position;
                    cardPos.z = -200;
                    cardObj.transform.position = cardPos;
                    cardObj.transform.eulerAngles = Vector3.zero;
                    cardObj.transform.SetParent(Camera.main.transform.parent);
                    cardObj.DoWinStreakToHandCardsAnim(toPos);
                });
            }

            seq.AppendInterval(0.9f);
            seq.OnComplete(() =>
            {
                GameObject.Destroy(fx, 1f);
                // GlobalRes.Release<GameObject>("Assets/Res/ArtRes/Prefabs/FX/combox.prefab");
                GameObjManager.Instance.PushGameObject(fx, 1);
            });
        });
        return 2f;
    }

    private float DoRefreshCardValueCommand(CardData cardData)
    {
        // Debug.LogError($"DoRefreshCardValueCommand {cardData.id} : {cardData.Value},{cardData.cm.GetValue()}");
        var cardId = cardData.id;
        var isDeskCard = DeskCards.Contains(cardId);
        var isHandCard = HandCards.Contains(cardId);
        var isOpenCard = OpenCards.Contains(cardId);
        if (isDeskCard || isHandCard || isOpenCard)
        {
            BaseCard card = AllCardsDic[cardData.id];
            card.CardData = cardData;
            switch (card)
            {
                case ValueCard c:
                    c.SetValue();
                    break;

                case GoldCard c:
                    c.SetGold();
                    if (isDeskCard)
                        c.ShowEff(true);
                    else if (isHandCard || isOpenCard)
                        c.ShowEff(false);
                    break;
                case MonochromeCard c:
                    c.SetMonochrome();
                    break;

                case TwoValueCard c:
                    c.SetValue();
                    break;
            }
        }
        return 0;
    }

    private float DoRefreshCardPositionCommand(CardData card)
    {
        if (!AllCardsDic.ContainsKey(card.id)) return 0;
        BaseCard baseCard = AllCardsDic[card.id];
        baseCard.CardData = card;
        baseCard.SetPosition(card.cm.x, card.cm.y, card.cm.depth, card.cm.angle, card.IsFaceup);
        return 0;
    }

    private float DoFlopHandCardCommand(CardData cardData)
    {
        return FlopHandCard(cardData.id);
    }

    private float DoFlopHandCardWindmillCommand(List<CardData> cardList)
    {
        var duration = 0f;

        var windCard = AllCardsDic[OpenCards[OpenCards.Count - 1]];
        duration += (windCard as WindmillCard).DoTriggerFlyAnim();
        OpenCardsRemove(windCard.CardId);

        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(duration);
        var idx = 0;
        foreach (var cardData in cardList)
        {
            idx++;
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.DoFlyOutByWindmill(1);
                DeskCardsRemove(cardData.id);
                DiscCards.Add(cardData.id);
            }
        }

        for (int i = 0; i < cardList.Count; i++)
        {
            var card = cardList[i];
            if (card.HasLinkRope())
            {
                RemoveLinkRope(card.id, card.GetLinkRopeCardId());
            }
        }

        TypeEventSystem.Send<BigBombEvent>(new BigBombEvent(false));
        return duration;
    }

    //点击桌卡
    private float DoCollectDeskCardCommand(CardData cardData)
    {
        var duration = 0f;
        if (DeskCards.Contains(cardData.id))
        {
            BaseCard card = AllCardsDic[cardData.id];
            var openCardPos = GameObjTransInfo.OpenCardPos;
            if (OpenCards.Count > 0)
                openCardPos.z = (int)(AllCardsDic[OpenCards[0]].transform.position.z - OpenCards.Count);
            DeskCardsRemove(cardData.id);
            OpenCardsAdd(cardData.id);
            duration = card.MoveToOpenCardFromDesktop(openCardPos);
            DoRefreshCardValueCommand(cardData);
            // card.ActiveAllModifier(false);
            card.ShowModifier(false);
            TypeEventSystem.Send<BigBombEvent>(new BigBombEvent(false));

            if(cardData.HasTask())
            {
                TypeEventSystem.Send<CollectTaskCardEvent>(new CollectTaskCardEvent(card.transform.position));
            }
        }
        return duration;
    }

    private float DoFlopDeskCardCommand(CardData cardData)
    {
        var duration = 0f;
        if (DeskCards.Contains(cardData.id))
        {
            BaseCard card = AllCardsDic[cardData.id];
            card.CardData = cardData;
            if (cardData.IsFaceup)
            {
                duration = card.FlopCard(true);
            }
            else
            {
                duration = card.FlopCard(false);
            }
        }
        return duration;
    }

    private float DoBoomCardCommand(CardData _boomCard, List<CardData> boomFlyCards)
    {
        var duration = 0f;
        var t1 = 0.4f;
        var t2 = 0.5f;

        if (!DeskCards.Contains(_boomCard.id))
            return duration;

        BaseCard boomCard = AllCardsDic[_boomCard.id];
        DeskCardsRemove(_boomCard.id);

        FxMaskView.Instance.DoFade(1f);
        duration += (boomCard as BoomCard).DoTriggerBoomCard();
        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(duration);

        var idx = 0;
        foreach (var cardData in boomFlyCards)
        {
            idx++;
            if (DeskCards.Contains(cardData.id))
            {
                var idx2 = idx;
                BaseCard card = AllCardsDic[cardData.id];
                seq.InsertCallback(t1, () =>
                {
                    card.DoBeBoomAnim(boomCard.transform.position);
                    DeskCardsRemove(cardData.id);
                });
            }
        }
        seq.Append(FxMaskView.Instance.DoFade(0, t2));

        duration += t1 + t2;

        for (int i = 0; i < boomFlyCards.Count; i++)
        {
            var card = boomFlyCards[i];
            Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_ =>
            {
                if (card.HasLinkRope())
                {
                    RemoveLinkRope(card.id, card.GetLinkRopeCardId());
                }
            });
        }

        return duration;
    }

    private float DoWindmillCardCommand(CardData _windmillCard, List<CardData> _windmillFlyCards)
    {
        var duration = 0f;

        if (!DeskCards.Contains(_windmillCard.id))
            return duration;

        BaseCard windCard = AllCardsDic[_windmillCard.id];
        OpenCardsRemove(_windmillCard.id);
        DiscCards.Add(_windmillCard.id);

        duration += (windCard as WindmillCard).DoTriggerFlyAnim();
        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(duration);
        var idx = 0;
        foreach (var cardData in _windmillFlyCards)
        {
            idx++;
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.DoFlyOutByWindmill(1);
                DeskCardsRemove(cardData.id);
                DiscCards.Add(cardData.id);
            }
        }

        for (int i = 0; i < _windmillFlyCards.Count; i++)
        {
            var card = _windmillFlyCards[i];
            Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_ =>
            {
                if (card.HasLinkRope())
                {
                    RemoveLinkRope(card.id, card.GetLinkRopeCardId());
                }
            });
        }

        TypeEventSystem.Send<BigBombEvent>(new BigBombEvent(false));

        return duration;
    }

    private float DoMonkeyBananaCardCommand(CardData clickCard, CardData pairCard)
    {
        var t1 = 0f;
        var t2 = 0f;
        var duration = 0f;
        if (DeskCards.Contains(clickCard.id) && DeskCards.Contains(pairCard.id))
        {
            t1 = 0.8f;
            t2 = 0.5f;
            BaseCard card1 = AllCardsDic[clickCard.id];
            BaseCard card2 = AllCardsDic[pairCard.id];
            var pos1 = card1.transform.position;
            var pos2 = card2.transform.position;

            Sequence seq = DOTween.Sequence();
            seq.AppendCallback(() =>
            {
                card1.MoveToOpenCardFromDesktop(pos2);
            });
            seq.AppendInterval(t1);
            seq.AppendCallback(() =>
            {
                card1.DoBeMonkeyBananaAnim(pos2, pos1);
                card2.DoBeMonkeyBananaAnim(pos2, pos1);
                DeskCardsRemove(clickCard.id);
                DeskCardsRemove(pairCard.id);
            });

        }
        duration += t1 + t2;

        return duration;
    }

    private float DoZapCardCommand(CardData _zapCard, List<CardData> _zapFlyCards)
    {
        var duration = 0f;
        var t1 = 0f;
        var t2 = 1.2f;
        var t3 = 0.8f;

        if (!DeskCards.Contains(_zapCard.id))
            return duration;

        BaseCard zapCard = AllCardsDic[_zapCard.id];
        DeskCardsRemove(_zapCard.id);
        var idx = 0;
        var zapFlyCards = new List<BaseCard>();
        foreach (var cardData in _zapFlyCards)
        {
            idx++;
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.SetSortingOrder(BaseCard.DefaultSortOrder);
                zapFlyCards.Add(card);
                DeskCardsRemove(cardData.id);
            }
        }
        t1 = (zapCard as ZapCard).DoTriggerZapCard();
        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(t1);
        seq.Join(FxMaskView.Instance.DoFade(0.4f));

        _ = GlobalRes.DynamicLoadPrefab(Constants.flyZapFxStr, (obj) =>
        {
            GameObject flyZap = obj;
            flyZap.transform.position = new Vector3(1000, zapCard.transform.position.y, 0);
            flyZap.transform.localScale = Vector3.one * 0.8f;
            Tween flyTween = flyZap.transform.DOMoveX(-1200f, t2).OnUpdate(() =>
            {
                foreach (var beZapCard in zapFlyCards)
                {
                    if (flyZap.transform.position.x - beZapCard.transform.position.x + 50 < 0)
                    {
                        zapFlyCards.Remove(beZapCard);
                        beZapCard.DoBeZapped();
                        break;
                    }
                }
            });
            seq.Append(flyTween);
            seq.AppendInterval(t3);
            seq.OnComplete(() =>
            {
                FxMaskView.Instance.DoFade(0, 0.2f);
                GameObject.Destroy(flyZap, 3f);
                // GlobalRes.Release<GameObject>(Constants.flyZapFxStr);
            });

            for (int i = 0; i < zapFlyCards.Count; i++)
            {
                var card = zapFlyCards[i];
                Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_ =>
                {
                    if (card.CardData.HasLinkRope())
                    {
                        RemoveLinkRope(card.CardData.id, card.CardData.GetLinkRopeCardId());
                    }
                });
            }
        });

        duration = t1 + t2 + t3;

        return duration;
    }

    private float DoUnlockCardCommand(CardData _keyCard, List<CardData> _keyFlyCards)
    {
        var duration = 0f;
        var t1 = 0f;
        var t2 = 0.4f;

        if (!DeskCards.Contains(_keyCard.id))
            return duration;

        BaseCard keyCard = AllCardsDic[_keyCard.id];
        DeskCardsRemove(_keyCard.id);

        var idx = 0;
        var lockCards = new List<BaseCard>();
        foreach (var cardData in _keyFlyCards)
        {
            idx++;
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                lockCards.Add(card);
                DeskCardsRemove(cardData.id);
            }
        }

        FxMaskView.Instance.DoFade(0.2f);
        t1 = (keyCard as KeyCard).DoTriggerKeyCard(lockCards) + 0.4f;
        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(t1);
        seq.Append(FxMaskView.Instance.DoFade(0, t2));

        duration = t1 + t2;
        return duration;
    }

    private float DoBombUpdateCommand(List<CardData> _boomCards)
    {
        foreach (var cardData in _boomCards)
        {
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.UpdateBomb(cardData.BombTimer);
            }
        }
        return 0;
    }

    private float DoBigBombUpdateCommand(List<CardData> _boomCards)
    {
        bool showRed = false;
        foreach (var cardData in _boomCards)
        {
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.UpdateBigBomb(cardData.BigBombTimer);
                if (cardData.BigBombTimer <= 3)
                    showRed = true;
            }
        }
        TypeEventSystem.Send<BigBombEvent>(new BigBombEvent(showRed));

        return 0;
    }

    private float DoBigBombingCommand(List<CardData> _bombCards)
    {
        float duration = 0.6f;

        if (birdInst != null)
        {
            birdInst.GetComponent<SortingGroup>().sortingOrder = 31;
            birdInst.transform.DOMove(GameObjTransInfo.BirdPos, 1).OnComplete(() =>
            {
                birdInst.GetComponent<SortingGroup>().sortingOrder = 0;
            });
            birdInst.GetComponent<Animator>().Play("Card_Bird_fly");
            SoundPlayer.Instance.PlayMainSound("Ladybug_Fly");
        }

        var idx = 0;
        foreach (var cardData in _bombCards)
        {
            idx++;
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.DoTriggerBigBombCard();
                DeskCardsRemove(cardData.id);
            }
        }

        Sequence seq = DOTween.Sequence();
        seq.InsertCallback(duration + 0.6f, () =>
        {
            TypeEventSystem.Send<BigBombEvent>(new BigBombEvent(false));
        });
        return duration;
    }

    private float DoBombingCommand(List<CardData> bombCards, List<CardData> newCards)
    {
        float duration = 3f;
        int idx = 0;
        foreach (var cardData in bombCards)
        {
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                List<Vector3> poses = new List<Vector3>();
                for (int i = idx * 3; i < Math.Min(newCards.Count, idx * 3 + 3); i++)
                {
                    poses.Add(newCards[i].cm.Position);
                }
                idx++;
                card.DoTriggerBombCard(poses.ToArray(), duration);
            }
        }

        Sequence seq = DOTween.Sequence();
        foreach (var card in newCards)
        {
            var cardObj = AllCardsDic[card.id];
            cardObj.gameObject.SetActive(false);
            DeskCardsAdd(card.id);
            seq.InsertCallback(duration, () =>
            {
                cardObj.SetVisible(true);
                cardObj.gameObject.SetActive(true);
                cardObj.DoShowBombCardAnim();
            });
        }

        return duration;
    }

    private float DoRisingUpdateCommand(List<CardData> _risingCards, bool undo = false)
    {
        foreach (var cardData in _risingCards)
        {
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.CardData = cardData;
                card.CardData.Value = cardData.Value;
                (card as ValueCard).ShowRisingEff(() => (card as ValueCard).SetValue(), undo);
            }
        }
        return 0;
    }

    private float DoLoweringUpdateCommand(List<CardData> _loweringCards, bool undo = false)
    {
        foreach (var cardData in _loweringCards)
        {
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.CardData = cardData;
                card.CardData.Value = cardData.Value;
                (card as ValueCard).ShowLoweringEff(() => (card as ValueCard).SetValue(), undo);
            }
        }
        return 0;
    }

    //添加功能牌（+3张牌）
    private float DoThreeCardCommand(int threeCardId, List<int> newCards, List<int> handCards)
    {
        // AddRenderCommand(new SortHandCardCommand(handCards.Count));
        var duration = 0f;
        var t1 = 0.1f;
        var interval = 0.1f;

        if (!DeskCards.Contains(threeCardId))
            return duration;

        DeskCardsRemove(threeCardId);
        DiscCards.Add(threeCardId);

        var handCardNum = handCards.Count;

        BaseCard threeCard = AllCardsDic[threeCardId];
        Vector3 threeCardPos = threeCard.transform.position;
        Sequence seq = DOTween.Sequence();
        (threeCard as ThreeCard).DoTriggerThreeCard();
        seq.AppendInterval(0.3f);
        //seq.Join(FxMaskView.Instance.DoFade(0.2f));
        // FxMaskView.Instance.SetAlpha(0);
        for (int i = 0; i < newCards.Count; i++)
        {
            int cardId = newCards[i];
            var toIndex = handCards.IndexOf(cardId);
            HandCards.Insert(toIndex, cardId);
        }
        HandCardIndentAction();
        for (int i = 0; i < newCards.Count; i++)
        {
            int cardId = newCards[i];
            var toIndex = handCards.IndexOf(cardId);
            var cardObj = AllCardsDic[cardId];
            cardObj.gameObject.SetActive(true);
            cardObj.SetVisible(false);
            Vector3Int toPos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * toIndex + new Vector3Int(0, 0, toIndex - handCardNum);
            // Debug.LogError($"============== toIndex:{toIndex}, handCardNum:{handCardNum} toPos:{toPos.z}");
            Vector3 formPos = threeCardPos;// + new Vector3Int(200 * i - 200, 0, 0);
            handAddFlyCard.Add(cardObj.gameObject);
            cardObj.DoThreeAnim(threeCardPos, t1 + i * interval, formPos, toPos).OnComplete(() =>
            {
                handAddFlyCard.Remove(cardObj.gameObject);
                HandCardIndentAction();
            });
        }
        Observable.Timer(TimeSpan.FromSeconds(2f)).Subscribe(_ =>
        {
            foreach (var card in AllCardsDic)
            {
                if (handAddFlyCard.Contains(card.Value.gameObject))
                {
                    handAddFlyCard.Remove(card.Value.gameObject);
                }
            }
        });

        TypeEventSystem.Send<HandCardChangeEvent>(new HandCardChangeEvent(HandCards.Count));

        duration = t1 + interval * newCards.Count;
        return duration;
    }

    private float DoAnchorCardCommand(CardData anchorCard)
    {
        var duration = 0f;

        if (DeskCards.Contains(anchorCard.id))
        {
            BaseCard card = AllCardsDic[anchorCard.id];
            duration = (card as AnchorCard).DoTriggerAnchor(lastWaterPos, true);
            DeskCardsRemove(anchorCard.id);
        }

        return duration;
    }

    private float DoCopyCardCommand(CardData copyCard)
    {
        if (DeskCards.Contains(copyCard.id))
        {
            BaseCard card = AllCardsDic[copyCard.id];
            DeskCardsRemove(copyCard.id);
            card.gameObject.SetActive(false);
            var copyCardObj = AllCardsDic[copyCard.id];
            copyCardObj.gameObject.SetActive(true);
            DeskCardsAdd(copyCard.id);
        }
        return 0f;
    }

    private float DoIceBrokenCommand(CardData _iceCard)
    {
        var duration = 0f;

        if (DeskCards.Contains(_iceCard.id))
        {
            BaseCard iceCard = AllCardsDic[_iceCard.id];
            (iceCard as ValueCard)?.BreakIce();
        }

        return duration;
    }

    private float DoBreakIceByHandCardCommand(CardData _iceCard)
    {
        var duration = 0f;

        if (DeskCards.Contains(_iceCard.id))
        {
            BaseCard iceCard = AllCardsDic[_iceCard.id];
            var matchCardId = OpenCards[OpenCards.Count - 1];
            OpenCardsRemove(matchCardId);
            DiscCards.Add(matchCardId);
            duration = AllCardsDic[matchCardId].DoIceMove(iceCard, null);
        }

        return duration;
    }

    private float DoUndoBreakIceCommand(CardData iceCard, CardData openCard)
    {
        var duration = 0f;
        if (openCard != null)
        {
            var openCardPos = GameObjTransInfo.OpenCardPos;
            if (OpenCards.Count > 0)
                openCardPos.z = (int)(AllCardsDic[OpenCards[0]].transform.position.z - OpenCards.Count);
            var openCardObj = AllCardsDic[openCard.id];
            OpenCardsAdd(openCard.id);
            DiscCards.Remove(openCard.id);
            duration = openCardObj.UndoIceMove(openCardPos.z);
        }
        var iceCardObj = AllCardsDic[iceCard.id];
        iceCardObj.CardData = iceCard;
        // (iceCardObj as ValueCard)?.UndoBreakIce();
        iceCardObj.ShowModifier(true);

        return duration;
    }

    private void DoRopeSuitUpdateCommand(List<CardData> list, bool resetValue)
    {
        foreach (var cardData in list)
        {
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.CardData = cardData;
                (card as ValueCard).SetRopeSuits(cardData);
            }
        }
    }

    private void DoUpdateClothStateSwitchRoundCommand(ClothRoundUpdateCommand cmd)
    {
        foreach (var cardData in cmd.cardList)
        {
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.CardData = cardData;
                if (cardData.HasMagicCloth())
                    (card as ValueCard).SetMagicClothOpen(cardData.IsClothOpen(), cardData.IsClothOpen());
                else
                    (card as ValueCard).SetClothOpen(cardData.IsClothOpen(), false);
            }
        }
    }

    private float DoGreenLeafUpdateCommand(CardData lastBirdCard, List<CardData> greenLeafCards)
    {
        float duration = 0.5f;
        CardData nowBirdCard = null;
        int faceupCount = 0;
        foreach (var cardData in greenLeafCards)
        {
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                // card.CardData = cardData;
                (card as ValueCard).SetGreenLeafBird(cardData.HasBird());
                if (cardData.HasBird())
                    nowBirdCard = cardData;
            }
            if (cardData.IsFaceup && cardData.IsTopCard())
            {
                faceupCount++;
            }
        }

        if (greenLeafCards.Count == 1)
        {
            if (birdInst != null)
            {
                duration = 1f;
                birdInst.GetComponent<SortingGroup>().sortingOrder = 31;
                if (lastBirdCard != null)
                {
                    AllCardsDic[lastBirdCard.id].DoScaleAnim();
                    AllCardsDic[lastBirdCard.id].PlayGreanLeafEf(1);
                }
                birdInst.transform.DOMove(GameObjTransInfo.BirdPos, duration)
                    .OnComplete(() =>
                    {
                        birdInst.GetComponent<SortingGroup>().sortingOrder = 0;
                    });
                if (nowBirdCard != null)
                {
                    AllCardsDic[nowBirdCard.id].DestroyGreanLeafEf();
                }
                if (birdInst.transform.position != GameObjTransInfo.BirdPos) SoundPlayer.Instance.PlayMainSound("Ladybug_Fly");
                birdInst.GetComponent<Animator>().Play("Card_Bird_fly");
            }
        }
        else
        {
            if (faceupCount > 0)
            {
                if (birdInst == null)
                {
                    birdInst = GameObjManager.Instance.PopGameObject(GameObjType.Bird);
                    birdInst.transform.parent = GameObjTransInfo.DefaultScene;
                    birdInst.transform.position = GameObjTransInfo.BirdPos;
                    birdInst.SetActive(true);
                }
                else
                {
                    // birdInst.SetActive(true);
                }
            }
            else
            {
                if (birdInst != null)
                {
                    // birdInst.SetActive(false);
                }
            }

            if (birdInst != null && nowBirdCard != null)
            {
                if (lastBirdCard != null && nowBirdCard.id != lastBirdCard.id)
                {
                    birdInst.GetComponent<SortingGroup>().sortingOrder = 31;
                    AllCardsDic[lastBirdCard.id].DoScaleAnim();
                    AllCardsDic[lastBirdCard.id].PlayGreanLeafEf(1);
                    birdInst.transform.DOMove(new Vector3(nowBirdCard.cm.Position.x, nowBirdCard.cm.Position.y, nowBirdCard.cm.depth - 0.1f), duration)
                        .OnComplete(() =>
                        {
                            birdInst.GetComponent<SortingGroup>().sortingOrder = 0;
                            AllCardsDic[nowBirdCard.id].DoScaleAnim();
                            AllCardsDic[nowBirdCard.id].PlayGreanLeafEf(2);
                        });
                    birdInst.GetComponent<Animator>().Play("Card_Bird_fly");
                    SoundPlayer.Instance.PlayMainSound("Ladybug_Fly");
                }
                else
                {
                    if (Vector2.Distance(birdInst.transform.position, new Vector2(nowBirdCard.cm.Position.x, nowBirdCard.cm.Position.y)) > 1)
                    {
                        birdInst.GetComponent<SortingGroup>().sortingOrder = 31;
                        if (lastBirdCard != null)
                        {
                            AllCardsDic[lastBirdCard.id].DoScaleAnim();
                            AllCardsDic[lastBirdCard.id].PlayGreanLeafEf(1);
                        }
                        birdInst.transform.DOMove(new Vector3(nowBirdCard.cm.Position.x, nowBirdCard.cm.Position.y, nowBirdCard.cm.depth - 0.1f), duration)
                            .OnComplete(() =>
                            {
                                birdInst.GetComponent<SortingGroup>().sortingOrder = 0;
                                AllCardsDic[nowBirdCard.id].DoScaleAnim();
                                AllCardsDic[nowBirdCard.id].PlayGreanLeafEf(2);
                            });
                        birdInst.GetComponent<Animator>().Play("Card_Bird_fly");
                        SoundPlayer.Instance.PlayMainSound("Ladybug_Fly");
                    }
                    else
                    {
                        birdInst.transform.position = new Vector3(nowBirdCard.cm.Position.x, nowBirdCard.cm.Position.y, nowBirdCard.cm.depth - 0.1f);
                    }
                }
            }
        }

        return duration;
    }

    private float DoShowBirdCommand(Vector3 pos)
    {
        float duration = 0f;
        if (birdInst != null)
        {
            birdInst.transform.position = pos;
            birdInst.GetComponent<Animator>().Play("Card_Bird_fly");
            SoundPlayer.Instance.PlayMainSound("Ladybug_Fly");
        }
        return duration;
    }

    private float DoFlyBirdCommand(Vector3 toPos)
    {
        float duration = 0.7f;
        if (birdInst != null)
        {
            birdInst.GetComponent<SortingGroup>().sortingOrder = 31;
            birdInst.transform.DOMove(new Vector3(toPos.x, toPos.y, toPos.z), duration).OnComplete(() =>
            {
                birdInst.GetComponent<SortingGroup>().sortingOrder = 0;
            });
            birdInst.GetComponent<Animator>().Play("Card_Bird_fly");
            SoundPlayer.Instance.PlayMainSound("Ladybug_Fly");
        }
        return duration;
    }

    private void DoUpdateLightningTimerCommand(List<CardData> list)
    {
        foreach (var cardData in list)
        {
            if (DeskCards.Contains(cardData.id))
            {
                BaseCard card = AllCardsDic[cardData.id];
                card.CardData = cardData;
                (card as ValueCard)?.SetLightningTimer(cardData.LightningTimer);
            }
        }
    }

    private float DoLightningCardMissingCommand(CardData lightningCardData, CardData handCardData, bool fallback = false)
    {
        float duration = 0.1f;
        int cardId = handCardData.id;
        BaseCard cardObj = AllCardsDic[cardId];
        if (fallback)
        {
            // cardObj.CardData = handCardData;
            duration = cardObj.DoLightningHitCardEffect(fallback);
            HandRmCards.Remove(cardId);
            HandCards.Insert(0, cardId);
            AddRenderCommand(new SortHandCardCommand(HandCards.Count));
        }
        else
        {
            if (HandCards.Contains(cardId))
            {
                if (lightningCardData != null)
                {
                    _ = GlobalRes.DynamicLoadPrefab(Constants.lightningFx03, (obj) =>
                    {
                        obj.SetActive(true);
                        var scene = Camera.main.transform.parent;
                        obj.transform.SetParent(scene);
                        obj.transform.position = lightningCardData.cm.Position;
                        obj.GetComponent<ChainLightning>().SetData(lightningCardData.cm.Position, cardObj.transform.position, null);
                    }, true, 1f);

                    // _ = GlobalRes.DynamicLoadPrefab(Constants.lightningFx01, (obj) =>
                    // {
                    //     obj.SetActive(true);
                    //     var scene = Camera.main.transform.parent;
                    //     obj.transform.SetParent(scene);
                    //     obj.transform.position = lightningCardData.cm.Position;
                    //     Observable.Timer(TimeSpan.FromSeconds(2)).Subscribe(_ =>
                    //     {
                    //         GameObject.Destroy(obj);
                    //     }).AddTo(scene);
                    // });
                }

                // cardObj.CardData = handCardData;
                duration = cardObj.DoLightningHitCardEffect(fallback);
                HandRmCards.Add(cardId);
                HandCards.Remove(cardId);

                AddRenderCommand(new SortHandCardCommand(HandCards.Count));
            }
        }
        return duration;
    }

    //添加兔子连胜获得的卡牌
    private float DoAddRabitCardCommand(int[] newCards, List<int> handCards, float waitTime)
    {
        float time = 0;
        var handCardNum = handCards.Count;
        for (int i = 0; i < newCards.Length; i++)
        {
            int cardId = newCards[i];
            var toIndex = handCards.IndexOf(cardId);
            HandCards.Insert(toIndex, cardId);
        }
        HandCardIndentAction(false);

        var t1 = waitTime + 0.3f;
        var t2 = 0f;
        for (int i = 0; i < newCards.Length; i++)
        {
            var cardId = newCards[i];
            var cardObj = AllCardsDic[cardId];
            cardObj.gameObject.SetActive(true);
            cardObj.SetVisible(true);
            var toIndex = handCards.IndexOf(cardId);
            Vector3Int toPos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * toIndex + new Vector3Int(0, 0, toIndex - handCardNum);
            Vector3 formPos = Vector3.zero;
            t2 = 1f + 0.4f * i + 0.8f;
            cardObj.DoItemAddHandCard(formPos, toPos);
        }
        return t1 + t2;
    }
    
    private float DoItemWindmillCardCommand(int[] newCards, List<int> handCards, float waitTime)
    {
        var handCardNum = handCards.Count;

        for (int i = 0; i < newCards.Length; i++)
        {
            int cardId = newCards[i];
            var toIndex = handCards.IndexOf(cardId);
            HandCards.Insert(toIndex, cardId);
        }
        HandCardIndentAction(false);

        var t1 = waitTime + 0.3f;
        var t2 = 0f;
        for (int i = 0; i < newCards.Length; i++)
        {
            var cardId = newCards[i];
            var cardObj = AllCardsDic[cardId];
            cardObj.gameObject.SetActive(true);
            cardObj.SetVisible(true);
            var toIndex = handCards.IndexOf(cardId);
            Vector3Int toPos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * toIndex + new Vector3Int(0, 0, toIndex - handCardNum);
            Vector3 formPos = Vector3.zero;
            t2 = 1f + 0.4f * i + 0.8f;
            cardObj.DoItemAddHandCard(formPos, toPos);
        }
        SoundPlayer.Instance.PlayMainSound("Windmill_appear");
        return t1 + t2;
    }

    private float DoRefreshLinkRopeCommand(List<CardData> lockCards, List<CardData> unlockCards)
    {
        foreach (var item in lockCards)
        {
            var cardObj = AllCardsDic[item.id];
            cardObj.ShowLockStatue(true);
            Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
            {
                ChangeLinkRopeStatus(cardObj.gameObject, false);
            });
        }
        foreach (var item in unlockCards)
        {
            var cardObj = AllCardsDic[item.id];
            cardObj.ShowLockStatue(false);
            CreateLinkRope(item.id, item.GetLinkRopeCardId());
            Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
            {
                ChangeLinkRopeStatus(cardObj.gameObject, true);
            });
        }
        return 0;
    }

    private float DoCollectLinkCardCommand(CardData firstCard, CardData lastCard)
    {
        float duration = 0.5f;
        if (DeskCards.Contains(lastCard.id))
        {
            SoundPlayer.Instance.PlayMainSound("LinkRope_Remove");
            BaseCard card = AllCardsDic[lastCard.id];
            Vector3Int openCardPos = GameObjTransInfo.OpenCardPos;
            if (OpenCards.Count > 0)
                openCardPos.z = (int)(AllCardsDic[OpenCards[0]].transform.position.z - OpenCards.Count);

            DeskCardsRemove(lastCard.id);
            OpenCardsAdd(lastCard.id);
            duration = card.MoveToOpenCardByLinkRope(openCardPos);
            Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_ =>
            {
                RemoveLinkRope(firstCard.id, lastCard.id);
            });
        }
        return duration;
    }

    private void DoRefreshAnchorCardCommand(List<CardData> cards, bool undo = false, bool skipAnim = false)
    {
        foreach (var cd in cards)
        {
            BaseCard card = AllCardsDic[cd.id];
            card.CardData = cd;
            (card as AnchorCard)?.SetProcess(cd.WaterNumber, cd.WaterTotal);
            if (!undo && cd.WaterNumber > 0 && !skipAnim)
                (card as AnchorCard)?.DoTriggerAnchor(lastWaterPos, false);
        }
    }

    private void DoRemoveHandCardCommand(List<int> cards)
    {
        foreach (var cardId in cards)
        {
            HandCards.Remove(cardId);
            DiscCards.Add(cardId);
            BaseCard card = AllCardsDic[cardId];
            card.DoAlphaAnim(0).OnComplete(() =>
            {
                card.gameObject.SetActive(false);
            });
        }
        AddRenderCommand(new SortHandCardCommand(HandCards.Count));
    }

    private void DoRestoreDeskCardCommand(List<CardData> cards)
    {
        foreach (var cd in cards)
        {
            DeskCardsAdd(cd.id, true);
            DiscCards.Remove(cd.id);
            BaseCard card = AllCardsDic[cd.id];
            card.CardData = cd;
            card.UndoBlowAwayCard();
        }
    }

    private void UndoKeyLockCardCommand(List<int> cards)
    {
        foreach (var cardId in cards)
        {
            DeskCardsAdd(cardId, true);
            DiscCards.Remove(cardId);
            BaseCard card = AllCardsDic[cardId];
            card.UndoKeyLockCard();
        }
    }

    private void DoRefreshSuitRopeCommand(CardData cardData)
    {
        BaseCard card = AllCardsDic[cardData.id];
        (card as ValueCard).RefreshSuitRope(cardData.SuitRopeSuits, cardData.SuitRopeStates);
    }

    private void UndoBombUpdateCommand(int bombCardId, List<int> cards)
    {
        BaseCard bombCard = AllCardsDic[bombCardId];
        foreach (var cardId in cards)
        {
            DeskCardsRemove(cardId, true);
            BaseCard card = AllCardsDic[cardId];
            card.UndoBombCards(bombCard.transform.position);
        }
    }

    private float UndoLinkCardCommand(CardData clickCard, CardData linkCard)
    {
        float duration = 0;
        duration += DoUndoDeskCardCommand(linkCard);
        duration += DoUndoDeskCardCommand(clickCard);
        // Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_=>{
        //     checklin
        // });
        return duration / 2;
    }

    private void DoRemoveModifierCommand(List<CardData> cards)
    {
        foreach (var cardData in cards)
        {
            BaseCard card = AllCardsDic[cardData.id];
            card.ShowModifier(false);
        }
    }

    private void DoRecycleModifierCommand(CardData cardData)
    {
        BaseCard card = AllCardsDic[cardData.id];
        card.CardData = cardData;
        card.ShowModifier(true);
    }

    private void DoComboViewCommand(ComboViewCommand cmd)
    {
        TypeEventSystem.Send<ComboChangeEvent>(new ComboChangeEvent(cmd.comboStep, cmd.comboCount, cmd.comboLimit, cmd.colors));
    }

    private float DoQuestionCardCommand(QuestionCardCommand cmd)
    {
        float duration = 0;
        if (!DeskCards.Contains(cmd.newCard))
            DeskCardsAdd(cmd.newCard);

        DeskCardsRemove(cmd.questionCard);
        DiscCards.Add(cmd.questionCard);

        var questionCard = AllCardsDic[cmd.questionCard];
        var newCard = AllCardsDic[cmd.newCard];

        newCard.DoAlphaAnim(0, 0);

        var delay = (questionCard as QuestionCard).DoTriggerQuestionCard();
        duration += delay;
        UniRx.Observable.Timer(TimeSpan.FromSeconds(delay)).Subscribe(_ =>
        {
            newCard.DoAlphaAnim(1, 0f);
            newCard.DoQuestionNewCard();
            newCard.ShowModifier(true);
        });
        duration += 18/60f;

        return duration;
    }

    private float UndoQuestionCardCommand(UndoQuestionCardCommand cmd)
    {
        float duration = 0.1f;

        DeskCardsAdd(cmd.questionCardId);
        DiscCards.Remove(cmd.questionCardId);
        DeskCardsRemove(cmd.newCardId, true);
        DiscCards.Add(cmd.newCardId);

        var questionCard = AllCardsDic[cmd.questionCardId];
        questionCard.UndoQuestionCard();
        var questionNewCard = AllCardsDic[cmd.newCardId];
        questionNewCard.UndoQuestionNewCard();

        return duration;
    }

    public float InitCards(List<CardData> deskCards, List<CardData> handCards, bool isMovingScene)
    {
        RecordInitdeskCards = deskCards;
        //cardBackId = backId;
        //betValue = bet;
        //生成桌牌
        foreach (var card in deskCards)
        {
            var cardObj = AllCardsDic[card.id];
            if (card.IsLocked)
                cardObj.DoAlphaAnim(0.2f, 0);
            DeskCardsAdd(card.id);
        }
        //生成手牌
        foreach (var card in handCards)
            HandCards.Add(card.id);
        var t1 = 0f;
        if (isMovingScene)
            t1 = ShowMovingDeskCards(); //展示桌牌
        else
            t1 = ShowDeskCards(); //展示桌牌
        var t2 = ShowHandCards(handCards, 1.5f); //展示手牌
        var duration = Math.Max(t1, t2);
        Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_ =>
        {
            GameCommon.IsShowCarding = false;
            BattleDataMgr.Instance.CheckPlayCardLoopSound();
            CheckPlayLockKeyAnim();
            TypeEventSystem.Send<PlayGameEntryAnim>();
        });
        return duration;
    }

    BaseCard CreateCard(int cardId, CardData cardData, int cardBackId, int betValue)
    {
        var gameObjType = Constants.CardType2ObjDic[cardData.CardType];
        var card = GameObjManager.Instance.PopGameObject(gameObjType);
        card.transform.parent = Camera.main.transform.parent;
        card.transform.localEulerAngles = Vector3.zero;
        card.transform.localScale = Vector3.one;
        card.SetActive(true);
        var cardMono = card.GetComponent<BaseCard>();
        cardMono.CardId = cardId;
        cardMono.Reset();
        cardMono.SetData(cardData, cardBackId, betValue);
        cardMono.ResetVisible();

        return cardMono;
    }

    static int SortCards(BaseCard p1, BaseCard p2)
    {
        if (p2.CardData.cm.depth == p1.CardData.cm.depth)
            return p1.CardData.cm.x.CompareTo(p2.CardData.cm.x);
        return p2.CardData.cm.depth.CompareTo(p1.CardData.cm.depth);
    }

    float ShowMovingDeskCards()
    {
        return ShowDeskCards();
    }

    float ShowDeskCards()
    {
        float duration = 0f;
        float blackTime = 1f * GameCommon.CardAnimScale;//进场黑幕时间
        float wholeTime = 2.0f * GameCommon.CardAnimScale;
        float moveTime = 1.5f * GameCommon.CardAnimScale;  //下落移动时间

        float singleTime = Math.Min(wholeTime / DeskCards.Count, 0.1f);
        List<BaseCard> cardList = DeskCards.Select(x => AllCardsDic[x]).ToList();
        cardList.Sort(SortCards);
        Sequence rootSeq = DOTween.Sequence();
        rootSeq.AppendInterval(blackTime);
        rootSeq.AppendCallback(() =>
        {
            SoundPlayer.Instance.PlayFapai();
        });

        int fallCount = 0;
        float waitTime = 0;
        foreach (var card in cardList)
        {
            waitTime = Math.Max(waitTime, card.DoGameStartFallAnim(blackTime, singleTime, moveTime, fallCount));
            fallCount++;
        }
        rootSeq.AppendInterval(waitTime);

        duration = blackTime + wholeTime + moveTime;
        int turnCount = 0;
        float intervalTime = 0.05f;
        foreach (var card in cardList)
        {
            card.FlopCard(false);
            if (card.CardData.IsFaceup)
            {
                turnCount++;
                rootSeq.InsertCallback(blackTime + wholeTime + moveTime + intervalTime * turnCount, () =>
                {
                    card.FlopCard(true);
                    card.ShowModifier(true);
                });
            }
        }
        duration += intervalTime * turnCount;

        Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_ =>
        {
            foreach (var card in cardList)
            {
                if (card.CardData.HasLinkRope())
                {
                    CreateLinkRope(card.CardData.id, card.CardData.GetLinkRopeCardId());
                }
            }
        });

        return duration;
    }

    void CreateLinkRope(int cardId1, int cardId2)
    {
        var key1 = Tuple.Create(cardId1, cardId2);
        var key2 = Tuple.Create(cardId2, cardId1);
        if (!LinkRopeItems.ContainsKey(key1) && !LinkRopeItems.ContainsKey(key2))
        {
            LinkRopeItems.Add(key1, null);
            var scene = Camera.main.transform.parent;
            _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Cards/Prefabs/LinkRopeItem.prefab", (obj) =>
            {
                var linkRopeItem = obj;
                linkRopeItem.transform.SetParent(scene);
                LinkRopeItems.Remove(key1);
                LinkRopeItems.Add(key1, linkRopeItem);

                Vector3 p1 = AllCardsDic[cardId1].transform.position - new Vector3(0, Constants.CardSize.y * Constants.CardSizeScale.y / 2, 0);
                Vector3 p3 = AllCardsDic[cardId2].transform.position - new Vector3(0, Constants.CardSize.y * Constants.CardSizeScale.y / 2, 0);
                Vector3 p2 = (p1 + p3) / 2 + new Vector3(0, -100, 0);
                List<Vector3> nodes = new List<Vector3>();
                nodes.Add(p1);
                nodes.Add(p2);
                nodes.Add(p3);

                var ropeItem = linkRopeItem.GetComponent<LinkRopeItem>();
                ropeItem.ConnectEnds(AllCardsDic[cardId1].transform.GetChild(0).GetChild(0), AllCardsDic[cardId2].transform.GetChild(0).GetChild(0));
            });
        }
    }

    void RemoveLinkRope(int cardId1, int cardId2)
    {
        var key1 = Tuple.Create(cardId1, cardId2);
        var key2 = Tuple.Create(cardId2, cardId1);
        if (LinkRopeItems.ContainsKey(key1))
        {
            GameObject.Destroy(LinkRopeItems[key1]);
            LinkRopeItems.Remove(key1);
        }
        if (LinkRopeItems.ContainsKey(key2))
        {
            GameObject.Destroy(LinkRopeItems[key2]);
            LinkRopeItems.Remove(key2);
        }
    }

    void ChangeLinkRopeStatus(GameObject obj, bool green)
    {
        foreach (var item in LinkRopeItems)
        {
            if (item.Value != null)
            {
                var linkRopeItem = item.Value.GetComponent<LinkRopeItem>();
                if (linkRopeItem != null)
                    linkRopeItem.ChangeEndState(obj, green);
            }
        }
    }

    float ShowBuyHandsCard(List<CardData> handCards, float _moveTime = 0)
    {
        var moveTime = _moveTime * GameCommon.CardAnimScale;
        var intervalTime = 0.05f;
        var handCardNum = handCards.Count;
        Vector3Int formPos = GameObjTransInfo.HandPos - new Vector3Int(0, 0, 0);
        for (int i = 0; i < handCardNum; i++)
        {
            BaseCard cardObj = AllCardsDic[handCards[i].id];
            Vector3Int toPos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * i +
                               new Vector3Int(0, 0, i - handCardNum);
            cardObj.DoBuyHandCardsAnim(formPos, toPos, moveTime + intervalTime * (handCardNum - i),i == 0);
        }

        return moveTime + intervalTime * handCardNum;
    }

    float ShowHandCards(List<CardData> handCards, float _moveTime = 0)
    {
        var moveTime = _moveTime * GameCommon.CardAnimScale;
        var intervalTime = 0.08f;
        var handCardNum = handCards.Count;
        Vector3Int formPos = GameObjTransInfo.HandPos - new Vector3Int(0, 200, 0);
        for (int i = 0; i < handCardNum; i++)
        {
            BaseCard cardObj = AllCardsDic[handCards[i].id];
            Vector3Int toPos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * i + new Vector3Int(0, 0, i - handCardNum);
            cardObj.DoHandCardsInitAnim(formPos, toPos, moveTime + 0.08f * (handCardNum - i));
        }
        return moveTime + intervalTime * handCardNum;
    }

    private void DeskCardsAdd(int cardId, bool undo = false)
    {
        DeskCards.Add(cardId);
        if (undo)
        {
            BaseCard card = AllCardsDic[cardId];
            if (card.CardData.HasLinkRope())
            {
                Observable.Timer(TimeSpan.FromSeconds(0.1f)).Subscribe(_ =>
                {
                    CreateLinkRope(card.CardData.id, card.CardData.GetLinkRopeCardId());
                    ChangeLinkRopeStatus(card.gameObject, true);
                });
            }
            card.PlayShowEf();
            Observable.NextFrame().Subscribe(_ => CheckPlayLockKeyAnim());
            lastCardObj = card;
            ActivityManager.Instance.ClearActivityCard(card);
            BattleDataMgr.Instance.CheckPlayCardLoopSound();
            TypeEventSystem.Send<UpdateUndoBtnState>();
        }
    }

    private void CheckPlayLockKeyAnim()
    {
        bool hasKeyCard = false;
        bool hasLockCard = false;
        bool canPlayKeyAnim = false;
        bool canPlayLockAnim = false;
        foreach (var VARIABLE in AllCardsDic)
        {
            if (VARIABLE.Value.CardData.CardType == CardType.Key)
            {
                hasKeyCard = true;
                if (VARIABLE.Value.CardData.IsFaceup) canPlayKeyAnim = true;
            }

            if (VARIABLE.Value.CardData.CardType == CardType.Lock)
            {
                hasLockCard = true;
                if (VARIABLE.Value.CardData.IsFaceup) canPlayLockAnim = true;
            }
            if (canPlayKeyAnim && canPlayLockAnim) break;
        }

        if (hasKeyCard && hasLockCard)
        {
            foreach (var VARIABLE in AllCardsDic)
            {
                if (VARIABLE.Value.CardData.CardType == CardType.Key ||
                    VARIABLE.Value.CardData.CardType == CardType.Lock)
                {
                    bool isKey = VARIABLE.Value.CardData.CardType == CardType.Key;
                    if (canPlayKeyAnim && canPlayLockAnim)
                    {
                        if (isKey) (VARIABLE.Value as KeyCard).PlayShowKeyAnim();
                        else (VARIABLE.Value as LockCard).PlayLockAnim();
                    }
                    else
                    {
                        if (isKey) (VARIABLE.Value as KeyCard).DestroyKeyAnim();
                        else (VARIABLE.Value as LockCard).DestroyLockAnim();
                    }
                }
            }
        }
    }

    private void OpenCardsAdd(int cardId)
    {
        OpenCards.Add(cardId);
        bool flag = false;
        for (int i = OpenCards.Count - 1; i >= 0; i--)
        {
            var obj = AllCardsDic[OpenCards[i]].gameObject;
            if (flag)
            {
                obj.SetActive(false);
            }
            else
            {
                if (!obj.activeSelf)
                    break;
                if (obj.activeSelf && Vector2.Distance(obj.transform.position, new Vector2(GameObjTransInfo.OpenCardPos.x, GameObjTransInfo.OpenCardPos.y)) < 5)
                {
                    flag = true;
                }
            }
        }
    }

    private void OpenCardsRemove(int cardId)
    {
        var obj = AllCardsDic[cardId].gameObject;
        obj.SetActive(true);
        OpenCards.Remove(cardId);
        for (int i = OpenCards.Count - 1; i >= 0; i--)
        {
            obj = AllCardsDic[OpenCards[i]].gameObject;
            if (!obj.activeSelf)
                obj.SetActive(true);
            else
                break;
        }
    }

    private void DeskCardsRemove(int cardId, bool undo = false)
    {
        if (DeskCards.Contains(cardId))
        {
            BaseCard card = AllCardsDic[cardId];
            if (!undo)
            {
                if (card.CardData.CardType == CardType.Value ||
                    card.CardData.CardType == CardType.TwoValue ||
                    card.CardData.CardType == CardType.Gold ||
                    card.CardData.CardType == CardType.Monochrome)
                {
                    ActivityManager.Instance.CheckActivityCard(card);
                    TypeEventSystem.Send<UpdateUndoBtnState>();
                    SoundPlayer.Instance.PlayNote(BattleDataMgr.Instance.ComboCount, GameUtils.CheckSpecialCard(card.CardData));
                }
            }
            if (card.CardData.HasWater())
                lastWaterPos = card.transform.position;
            Observable.NextFrame().Subscribe(_ => CheckPlayLockKeyAnim());
            card.PlayDisappearEf();
            card.PlayDisappearSound();
            if (card.CardData.HasGreenLeaf())
            {
                card.PlayDisappearGreanLeafEf();
                card.DestroyGreanLeafEf();
            }
            lastCardObj = card;
            DeskCards.Remove(cardId);
            foreach (var flowAddEvent in flowAddEventList)
            {
                if (flowAddEvent.cardId == cardId)
                {
                    TypeEventSystem.Send<FlowAddEvent>(flowAddEvent);
                    flowAddEventList.Remove(flowAddEvent);
                    break;
                }
            }
        }
    }

    //翻手牌动画
    public float FlopHandCard(int cardId)
    {
        if (!HandCards.Contains(cardId))
            return 0;
        Vector3Int openCardPos = GameObjTransInfo.OpenCardPos;
        if (OpenCards.Count > 0)
            openCardPos.z = (int)(AllCardsDic[OpenCards[0]].transform.position.z - OpenCards.Count);
        var card = AllCardsDic[cardId];
        lastCardObj = card;
        HandCards.Remove(cardId);
        OpenCardsAdd(cardId);

        // AddRenderCommand(new SortHandCardCommand(HandCards.Count));
        HandCardIndentAction();
        if (HandCards.Count == 0)
        {
            TypeEventSystem.Send<HandCardChangeEvent>(new HandCardChangeEvent(0));
        }
        TypeEventSystem.Send<UpdateUndoBtnState>();
        return card.MoveToOpenCardFromHandCards(openCardPos);
    }

    private void HandCardIndentAction(bool anim = true)
    {
        var handCardNum = HandCards.Count;
        for (int i = 0; i < handCardNum; i++)
        {
            int cardId = HandCards[i];
            if (HandCards.Contains(cardId))
            {
                BaseCard cardObj = AllCardsDic[cardId];
                if (!handAddFlyCard.Contains(cardObj.gameObject))
                {
                    Vector3Int toPos = GameObjTransInfo.HandPos + GameObjTransInfo.HandCardInterval * i + new Vector3Int(0, 0, i - handCardNum);
                    if (anim)
                        cardObj.MoveInHandCards(toPos, 0.1f);
                    else
                        cardObj.transform.localPosition = toPos;
                }
            }
        }
    }

    public GameObject GetDeskCardObject(int cardId)
    {
        // if (IsRendering())
        //     return null;
        if (DeskCards.Contains(cardId))
            return AllCardsDic[cardId].gameObject;
        return null;
    }

    public GameObject GetHandCardObject(int cardId)
    {
        if (IsRendering())
            return null;
        if (HandCards.Contains(cardId))
            return AllCardsDic[cardId].gameObject;
        return null;
    }

    public BaseCard GetLastCardObject()
    {
        return lastCardObj;
    }

    private bool CheckSpecialCardTip(List<CardData> deskCards)
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        foreach (var card in deskCards)
        {
            if (dataService.CheckSpecialCardTip(card.cm.cardType, card.cm.modifiers))
            {
                GameCommon.IsShowSpeialCardTiping = true;
                BoxBuilder.ShowSpecialCardTipPopup(card);
                return true;
            }
        }
        return false;
    }

    public bool IsHandCardAdding()
    {
        return handAddFlyCard.Count > 0;
    }

    private float DoRudderCardCommand(CardData _rudderCard, List<CardData> rudderFlyCards)
    {
        var duration = 0f;
        var t1 = 2f;
        var t2 = 0.5f;

        if (!DeskCards.Contains(_rudderCard.id))
            return duration;

        BaseCard rudderCard = AllCardsDic[_rudderCard.id];
        DeskCardsRemove(_rudderCard.id);

        // FxMaskView.Instance.DoFade(1f);
        duration += (rudderCard as RudderCard).DoTriggerRudderCard();
        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(duration);

        var idx = 0;
        foreach (var cardData in rudderFlyCards)
        {
            idx++;
            if (DeskCards.Contains(cardData.id))
            {
                var idx2 = idx;
                BaseCard card = AllCardsDic[cardData.id];
                seq.InsertCallback(t1, () =>
                {
                    card.DoBeRudderAnim();
                    DeskCardsRemove(cardData.id);
                });
            }
        }
        // seq.Append(FxMaskView.Instance.DoFade(0, t2));
        // duration += t1 + t2;

        for (int i = 0; i < rudderFlyCards.Count; i++)
        {
            var card = rudderFlyCards[i];
            Observable.Timer(TimeSpan.FromSeconds(duration)).Subscribe(_ =>
            {
                if (card.HasLinkRope())
                {
                    RemoveLinkRope(card.id, card.GetLinkRopeCardId());
                }
            });
        }

        return duration;
    }

    private float DoLizardCardCommand(List<int> lizardCards, List<int> removeCards)
    {
        float duration = 2f;

        foreach (var cardId in removeCards)
        {
            BaseCard card = AllCardsDic[cardId];
            card.UndoQuestionNewCard();
            DeskCardsRemove(cardId);
        }

        return duration;
    }
}
