using System;
using DG.Tweening;
using QFramework;
using UnityEngine;
using UniRx;
using System.Linq;
using System.Collections.Generic;
using Doozy.Engine;
using SoliUtils;
using System.Globalization;
using Activities;

public class BattleController
{
    private IConfigService configService;
    private IDataService dataService;
    private long startGameTime;

    // public GameCombo gameCombo;
    public GameData gameData;
    public int BattleLevel { get; set; }
    public bool IsPlaying { get; private set; }
    private List<CardData> comboCards = new List<CardData>();
    public void CleanUp()
    {
        TypeEventSystem.UnRegister<UndoEvent>(OnUndoEvent);
        TypeEventSystem.UnRegister<JokerEvent>(OnJokerEvent);
        TypeEventSystem.UnRegister<UndoBuyJokerEvent>(OnUndoBuyJokerEvent);
        TypeEventSystem.UnRegister<BuyCardsEvent>(OnBuyCardsEvent);
        TypeEventSystem.UnRegister<FlopHandCardEvent>(OnFlopHandCardEvent);
        TypeEventSystem.UnRegister<BattleResultEvent>(OnBattleResultEvent);
        TypeEventSystem.UnRegister<CheckGuideJokerEvent>(OnCheckGuideJokerEvent);
        TypeEventSystem.UnRegister<AddCollectCoinMod>(OnAddCollectCoinMod);
        TypeEventSystem.UnRegister<UndoCollectCoinMod>(OnUndoCollectCoinMod);
        TypeEventSystem.UnRegister<ComboUndoRewardEvent>(OnComboUndoRewardEvent);
        TypeEventSystem.UnRegister<GameRechargeEvent>(OnGameRechargeEvent);
        //TypeEventSystem.UnRegister<JumpResultView>(OnJumpResultview);
        BattleDataMgr.Instance.Clean();
        BattleViewMgr.Instance.Clean();
        // gameCombo = null;
        gameData = null;
        comboCards.Clear();
    }

    public BattleController()
    {
        TypeEventSystem.Register<UndoEvent>(OnUndoEvent);
        TypeEventSystem.Register<JokerEvent>(OnJokerEvent);
        TypeEventSystem.Register<UndoBuyJokerEvent>(OnUndoBuyJokerEvent);
        TypeEventSystem.Register<BuyCardsEvent>(OnBuyCardsEvent);
        TypeEventSystem.Register<FlopHandCardEvent>(OnFlopHandCardEvent);
        TypeEventSystem.Register<BattleResultEvent>(OnBattleResultEvent);
        TypeEventSystem.Register<CheckGuideJokerEvent>(OnCheckGuideJokerEvent);
        TypeEventSystem.Register<AddCollectCoinMod>(OnAddCollectCoinMod);
        TypeEventSystem.Register<UndoCollectCoinMod>(OnUndoCollectCoinMod);
        TypeEventSystem.Register<ComboUndoRewardEvent>(OnComboUndoRewardEvent);
        TypeEventSystem.Register<GameRechargeEvent>(OnGameRechargeEvent);
        //TypeEventSystem.Register<JumpResultView>(OnJumpResultview);

        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
    }

    public void Update()
    {
        if (IsPlaying && !BattleViewMgr.Instance.IsRendering())
        {
            var now = TimeUtils.UtcNow();
            BattleDataMgr.Instance.CheckGuideCard(now);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            BattleDataMgr.Instance.Test();
        }
    }

    private static LevelConfigBase GetHandleLevelConfig(int level)
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        if (!GameCommon.IsAiMode && ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
        {
            level = ActivityManager.Instance.EndlessLevelActivity.GetMyData().level;
            configService.HandleEndlessLevelConfig.TryGetValue(level, out var cfg);
            if (cfg == null)
            {
                cfg = configService.HandleEndlessLevelConfig.Last().Value;
            }
            return cfg;
        }
        else
        {
            configService.HandleLevelConfig.TryGetValue(level, out var hLevelCfg);
            if (hLevelCfg == null)
            {
                hLevelCfg = configService.HandleLevelConfig.Last().Value;
            }
            return hLevelCfg;
        }
    }

    public static BattleConfig GenBattleConfig(int level, LevelModel lm, List<int> items, List<CardType> winstreakCards = null, int defResult = -1, bool random = false)
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var hLevelCfg = GetHandleLevelConfig(level);


        bool isFailResult = false;
        var result = -1;
        int label = -1;
        bool paid = false;

        if (defResult != -1)
        {
            result = defResult;
        }

        if (result == -1 && label == -1 && dataService.HandlePaidModelData != null)
        {
            // Debug.LogError("========== dataService.HandlePaidModelData");
            // Debug.LogError($"========== dataService.HandlePaidModelData2 {dataService.HandlePaidModelData}");
            while (dataService.HandlePaidModelData.Length > 0)
            {
                if (dataService.HandlePaidModelData[0].number <= 0)
                {
                    var list = new List<HandlePaidModel>(dataService.HandlePaidModelData);
                    list.RemoveAt(0);
                    dataService.HandlePaidModelData = list.ToArray();
                }
                else
                {
                    var paidId = dataService.HandlePaidModelData[0].id;
                    if (configService.HandlePaidConfig.TryGetValue(paidId, out var cfg))
                    {
                        label = cfg.label;
                        dataService.HandlePaidModelData[0].number -= 1;
                        paid = true;
                    }
                    break;
                }
            }
        }

        if (result == -1 && label == -1)
        {
            var failResult = hLevelCfg.failResult;
            string[] failResults = failResult.Split(";");
            foreach (var resArr in failResults)
            {
                var res = Array.ConvertAll(resArr.Split(","), (str) => int.Parse(str, CultureInfo.InvariantCulture));
                if (dataService.FailSameLevelTimes >= res[0])
                {
                    result = res[1];
                    isFailResult = true;
                }
                else if (dataService.FailSameLevelTimes < res[0])
                {
                    break;
                }
            }
        }

        if (result == -1)
        {
            if (label == -1)
                label = GameUtils.RandomIntFromFormatString(hLevelCfg.group);

            configService.HandleLabelConfig.TryGetValue(label, out var hLabelCfg);
            if (hLabelCfg == null)
            {
                hLabelCfg = configService.HandleLabelConfig.Last().Value;
            }
            result = GameUtils.RandomIntFromFormatString(hLabelCfg.result);
        }

        configService.HandleResultConfig.TryGetValue(result, out var hResultCfg);
        if (hResultCfg == null)
        {
            hResultCfg = configService.HandleResultConfig.Last().Value;
        }
        var maxGuarTuple = configService.GenHandCardMaxGuar(level);
        var comboSteps = configService.GenComboStep(level);
        var comboLimitRateStr = hResultCfg.connectWeight;
        float[] comboLimitRate = new float[hResultCfg.comboLimit];
        for (int i = 0; i < hResultCfg.comboLimit; i++)
        {
            comboLimitRate[i] = GameUtils.RandomFloatFromFormatString(comboLimitRateStr);
        }
        var manyHandLinkRates = Array.ConvertAll(hResultCfg.manyHandLinkRate.Split(",", StringSplitOptions.RemoveEmptyEntries), float.Parse);
        var manyHandLinkRate = new Tuple<float, float>(manyHandLinkRates[0], manyHandLinkRates[1]);

        var levModel = lm.DeepCopy();
        foreach (var card in levModel.cards)
        {
            card.depth *= 10;//中间会动态插入道具牌
        }
        var battleConfig = new BattleConfig()
        {
            random = random,
            levelId = level,
            levelModel = levModel,
            deskCardAmend = hResultCfg.remainDesktop,
            handCardAmend = hResultCfg.remainHand,
            minGuar = maxGuarTuple.Item1,
            maxGuar = maxGuarTuple.Item2,
            cardBackId = dataService.CardBackId,
            betValue = dataService.NowBet,
            itemList = items,
            isGuarantee = false,
            comboLimitHandleNum = hResultCfg.comboLimit,
            comboLimitRate = comboLimitRate,
            comboSteps = comboSteps,
            paid = paid,
            manyHandLinkRate = manyHandLinkRate
        };
        if (!GameCommon.IsAiMode)
            Debug.Log($"<color=#FFE53D>关卡控制配置=> random:{random}, level:{level}, label:{label}, result:{result}, 连续失败控制:{isFailResult}, 付费控制:{paid}</color>\n");
        return battleConfig;
    }

    public void StartGame(StartGameEvent e)
    {
        BattleCenter.Instance.Clean();
        BattleLevel = e.level;
        TypeEventSystem.Send<BattleCommandEvent>(new BattleCommandEvent
        {
            command = BattleCommand.StartGame,
            battleConfig = GenBattleConfig(e.level, e.levelModel, e.item)
        });
        // gameCombo = new GameCombo(e.level);
        gameData = new GameData(configService, dataService, e.level, e.item);
        gameData.EnterCoin = e.enterCoin;
        startGameTime = TimeUtils.UtcNow();
        TypeEventSystem.Send<GameInitFinishEvent>(new GameInitFinishEvent(gameData));
        IsPlaying = true;
    }

    public void EndGame(BattleConfig config = null)
    {
        Debug.Log("========= EndGame");
        if (config != null)
        {
            if (dataService.MaxLevel >= configService.InterAdOpenlv)
            {
                if (dataService.InterAdInterval == -1)
                {
                    dataService.InterAdInterval = configService.GetInterAdInterval();
                }
                else
                {
                    dataService.InterAdInterval++;
                }
            }
        }

        if (!dataService.IsOverRookie())
        {
            GameFinishEvent t = GameObjManager.Instance.PopClass<GameFinishEvent>(true);
            t.Init(gameData);
            TypeEventSystem.Send<GameFinishEvent>(t);
            ReportGameResultEvent();
            CleanUp();
            return;
        }

        if (IsWin())
        {
            GameEventMessage.SendEvent(Constants.DoozyEvent.GameResult);
            GameFinishEvent t = GameObjManager.Instance.PopClass<GameFinishEvent>(true);
            t.Init(gameData);
            TypeEventSystem.Send<GameFinishEvent>(t);
        }
        else
        {
            ActivityManager.Instance.ClearResultAddCount();
        }
        ReportGameResultEvent();
        CleanUp();
    }

    public bool IsWin()
    {
        return BattleDataMgr.Instance.CheckWin();
    }

    private void OnUndoEvent(GameEvent e)
    {
        if (!BattleDataMgr.Instance.CanUndo())
            return;
        if (!gameData.BuyUndo())
            return;
        // if (BattleDataMgr.Instance.CanUndoCombo())
        //     gameCombo.UndoCombo();
        BattleCenter.Instance.OnUndoEvent();
        RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
        t.Init(gameData);
        TypeEventSystem.Send<RefreshGameViewEvent>(t);
    }

    private void OnJokerEvent(GameEvent e)
    {
        if (!BattleDataMgr.Instance.CanJoker())
            return;
        if (!gameData.BuyJoker())
            return;
        BattleCenter.Instance.OnJokerEvent();
        RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
        t.Init(gameData);
        TypeEventSystem.Send<RefreshGameViewEvent>(t);
    }

    private void OnUndoBuyJokerEvent(GameEvent e)
    {
        gameData.UndoBuyJoker();
        RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
        t.Init(gameData);
        TypeEventSystem.Send<RefreshGameViewEvent>(t);
    }

    //买牌自动使用
    private void OnBuyCardsEvent(GameEvent e)
    {
        if (!BattleDataMgr.Instance.CanBuyCards())
            return;
        if (!gameData.BuyCard())
            return;
        BattleCenter.Instance.OnBuyCardsEvent(gameData.UseBuyCardCount);
        RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
        t.Init(gameData);
        TypeEventSystem.Send<RefreshGameViewEvent>(t);
    }

    private void OnAddCollectCoinMod(AddCollectCoinMod addEvent)
    {
        CardModel cm = addEvent.coinModCard.cm;
        ModifierModel coinModifierModel = cm.modifiers.First(x => x.modType == ModifierType.Coin);
        Vector3 cardPos = new Vector3(cm.x, cm.y, cm.depth);
        gameData.AddRewardCoin(PropChangeWay.CoinMod, coinModifierModel.properties.param1 * dataService.NowBet, cardPos);
    }

    private void OnUndoCollectCoinMod(UndoCollectCoinMod undoEvent)
    {
        CardModel cm = undoEvent.coinModCard.cm;
        ModifierModel coinModifierModel = cm.modifiers.First(x => x.modType == ModifierType.Coin);
        Vector3 cardPos = new Vector3(cm.x, cm.y, cm.depth);
        gameData.ReduceRewardCoin(PropChangeWay.CoinMod, coinModifierModel.properties.param1);
    }

    private void OnComboUndoRewardEvent(ComboUndoRewardEvent undoEvent)
    {
        if (undoEvent.coinNum > 0)
        {
            dataService.ConsumeCoin(undoEvent.coinNum, PropChangeWay.ComboStep);
            // gameData.ReduceRewardCoin(PropChangeWay.ComboStep, undoEvent.coinNum);
        }
        if (undoEvent.starNum > 0)
            gameData.ReduceRewardStar(undoEvent.starNum);
        if (undoEvent.cardIDArray != null)
        {
            //BattleDataMgr.Instance.UndoComboCards(undoEvent.cardIDArray.ToList());
        }
    }

    private void OnFlopHandCardEvent(FlopHandCardEvent e)
    {
        // if (!e.isFirstFlop)
        //     gameCombo.SetComboBreak();
    }


    private void OnBattleResultEvent(BattleResultEvent e)
    {
        IsPlaying = false;
        TypeEventSystem.Send<PlayGameExitAnim>();

        float waitTime = 0f;
        var cards = e.cards;
        if (e.cards != null) cards.Sort((BaseCard p1, BaseCard p2) => p2.transform.position.x.CompareTo(p1.transform.position.x));

        Sequence seq = DOTween.Sequence();
        waitTime = CheckNoHandCardAnim(e);
        seq.AppendInterval(waitTime);
        seq.AppendCallback(() =>
        {
            TypeEventSystem.Send<ShowGameSkipBtn>(new ShowGameSkipBtn(true));
            waitTime = PlayLeftCardAnim(e);
            Sequence tempSeq = DOTween.Sequence();
            tempSeq.AppendInterval(waitTime + 0.2f);
            tempSeq.AppendCallback(() =>
            {
                TypeEventSystem.Send<PlayGameExitAnim>();
                gameData?.HandleResultProp(e);
                TypeEventSystem.Send<ShowGameSkipBtn>(new ShowGameSkipBtn(false));
                Observable.NextFrame().Subscribe((x) =>
                {
                    HandleMaxLevel();
                });
                TypeEventSystem.Send<BattleCommandEvent>(new BattleCommandEvent()
                {
                    command = BattleCommand.WinGame
                });
            });
        });
        
    }

    private void HandleMaxLevel()
    {
        if (dataService.IsRookieStatus())
            return;

        if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
        {
            if (ActivityManager.Instance.EndlessLevelActivity.GetMyData().level <= BattleLevel)
            {
                ActivityManager.Instance.EndlessLevelActivity.LevelUp();
                WeChatMiniGame.ReportLevelRanking();
                WeChatMiniGame.ReportLevelUp();
            }
        }
        else
        {
            if (dataService.MaxLevel <= BattleLevel)
            {
                dataService.MaxLevel = Math.Min(BattleLevel + 1, configService.GetStageConfig.Last().Value.id);
                WeChatMiniGame.ReportLevelRanking();
                WeChatMiniGame.ReportLevelUp();
            }
        }
    }

    //剩余手牌动画
    private float PlayLeftCardAnim(BattleResultEvent e)
    {
        float time = 0f;
        if (e.cards != null && e.cards.Count > 0)
        {
            int addIntegral = 0;
            int myIntegral = 0;
            if (gameData != null)
            {
                addIntegral = gameData.GetLeftCardIntegral(e) / e.cards.Count;
                myIntegral = gameData.BattleIntegral;
            }
            for (int i = 0; i < e.cards.Count; i++)
            {
                int index = i;
                var card = e.cards[index];
                //e.delayTime + 0.3f * i
                //0.3f * i
                float delayTime = 0.2f * i;
                if (delayTime > 1.4f) delayTime = 1.4f;
                float animTime = card.DoFinishRecycleCard(delayTime, i, myIntegral + addIntegral * (index + 1), () =>
                {
                    var configService = MainContainer.Container.Resolve<IConfigService>();
                    int rewardNum = configService.GetRemainReward(BattleLevel, index + 1) * dataService.NowBet;
                    int multiple = card.GetCardType() == CardType.Value ? 1 : 2;
                    FlowAddEvent t = GameObjManager.Instance.PopClass<FlowAddEvent>(true);
                    t.Init(0, 0, card.transform.position, PropEnum.Coin, 0f, false, false);
                    TypeEventSystem.Send<FlowAddEvent>(t);
                });
                if (animTime > time) time = animTime;
            }
        }
        return time + 0.4f;
    }

    //最后一张牌动画
    private float CheckNoHandCardAnim(BattleResultEvent e)
    {
        float waitTime = 0f;
        BaseCard card = BattleViewMgr.Instance.GetLastCardObject();
        if (card != null)
        {
            TypeEventSystem.Send<MoveGameViewBottom>(GameObjManager.Instance.PopClass<MoveGameViewBottom>(true));
            Sequence tempSeq = DOTween.Sequence();
            tempSeq.AppendInterval(0.9f);
            tempSeq.AppendCallback(() =>
            {
                BattleViewMgr.Instance.CleanOtherCard();
                _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/Card_lastcard_tx.prefab", (obj) =>
                {
                    SoundPlayer.Instance.PlayMainSound("Card_lastcard_tx");
                    obj.transform.SetParent(card.transform);
                    obj.transform.localPosition = Vector3.zero;
                    obj.transform.localScale = Vector3.one;

                    Sequence temp = DOTween.Sequence();
                    temp.AppendInterval(1.2f);
                    temp.Append(card.transform.DOScale(Vector3.zero, 0.6f));
                    temp.AppendCallback(() =>
                    {
                        GameObject.Destroy(obj);
                        // GlobalRes.Release<GameObject>("Assets/Res/Prefabs/FX/Card_lastcard_tx.prefab");
                    });
                });
            });
            waitTime = 2.2f;
        }
        return waitTime;
    }

    private void OnCheckGuideJokerEvent(GameEvent e)
    {
        if (BattleViewMgr.Instance.IsRendering() || IsWin())
            return;
        if (BattleDataMgr.Instance.IsWillCombo())
            TypeEventSystem.Send<ScaleJokerEvent>();
    }

    public void ReportGameResultEvent(bool forceQuit = false)
    {
        var reason = IsWin() ? 1 : 2;
        reason = forceQuit ? 3 : reason;

        var configService = MainContainer.Container.Resolve<IConfigService>();
        //List<int> starScoreList = configService.GetStarRequestList(NowLevel);
        //for (int i = 0; i < starScoreList.Count; i++)
        //{
        //    if(NowStarProgress >= starScoreList[i])
        //        stars++;
        //}
        //List<int> starRewardList = configService.GetStarRewardList(NowLevel);
        //var starReward = stars < 1 ? 0 : starRewardList[stars - 1];
        int defaultCost = configService.GetStageCost(BattleLevel);
        int nowUseBet = dataService.NowBet;

        var buyCardCost = 0;
        for (int i = 1; i <= gameData.BuyCardNum; i++)
            buyCardCost += configService.GetBuyCardCost(BattleLevel, i) * nowUseBet;

        var buyUndoCost = 0;
        for (int i = 1; i <= gameData.BuyUndoNum; i++)
            buyUndoCost += configService.GetUndoCost(BattleLevel, i) * nowUseBet;

        var buyJokerCost = 0;
        for (int i = 1; i <= gameData.BuyJokerNum; i++)
            buyJokerCost += configService.GetBuyJokerCost(BattleLevel, i) * nowUseBet;

        configService.GetWinStreakIdx(dataService.SuccessiveVictory, out var stepIdx);

        var win_coin = gameData.GetCoin() + gameData.GetLeftCardCoin();

        var level = BattleLevel;
        var level_type = 1;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel) != null &&
            ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
        {
            level = dataService.EndlessLevelProgress.ViewMaxLayer;
            level_type = 2;
        }
        var json = "";
        if (configService.GetStageConfig.TryGetValue(BattleLevel, out StageModel stage))
        {
            json = stage.json;
        }

        var msg = new Dictionary<string, object>
        {
            { AnalyticsKey.StageStartDefaultCost, defaultCost },
            { AnalyticsKey.StageType, level_type },
            { AnalyticsKey.StageId, level },
            { AnalyticsKey.StageEndReason, reason },
            { AnalyticsKey.WinstreakLevel, stepIdx },
            { AnalyticsKey.WinstreakTimes, dataService.SuccessiveVictory },
            { AnalyticsKey.StageEndAddcoinMatch, gameData.GetCoin(PropChangeWay.Combo) },
            { AnalyticsKey.StageEndAddcoinComboreward, gameData.GetCoin(PropChangeWay.ComboStep) },
            // { AnalyticsKey.StageEndAddCoin, configService.StageConfig[BattleLevel].winCoin },
            // { AnalyticsKey.StageEndComboMax, gameCombo.MaxComboNum },
            // { AnalyticsKey.StageEndComborewardTimes, gameCombo.FinishComboNum },
            // { AnalyticsKey.StageEndOnecolorComborewardTime, gameCombo.FinishOneColorComboNum },
            { AnalyticsKey.StageEndGetStar, gameData.StarRewardNum },
            { AnalyticsKey.StageEndJokerComborewardTime, gameData.ComboJokerRewardNum },
            { AnalyticsKey.StageEndItemUndoTimes, gameData.UseUndoCount },
            { AnalyticsKey.StageEndItemFillTimes, gameData.UseBuyCardCount },
            { AnalyticsKey.StageEndItemJokerTimes, gameData.UseJokerCount },
            { AnalyticsKey.StageEndRemaincardsDesk, BattleDataMgr.Instance.GetDeskCardsNum() },
            { AnalyticsKey.StageEndRemaincardsHand, BattleDataMgr.Instance.GetHandCardsNum() },
            { AnalyticsKey.StageEndAddCoinTotal, win_coin },//局内添加的所有金币
            { AnalyticsKey.StageEndUseCoinTotal, gameData.EnterCoin + buyCardCost + buyUndoCost + buyJokerCost },
            { AnalyticsKey.StagePowerupDelthreeUse, gameData.itemList?.Contains((int)PropEnum.ItemEliminate) == true ? 1 : 0 },
            { AnalyticsKey.StagePowerupWildUse, gameData.itemList?.Contains((int)PropEnum.ItemJoker) == true ? 1 : 0 },
            { AnalyticsKey.StagePowerupCactusUse, gameData.itemList?.Contains((int)PropEnum.ItemCactus) == true ? 1 : 0 },
            { AnalyticsKey.StagePowerupWindmillUse, gameData.itemList?.Contains((int)PropEnum.ItemWindmill) == true ? 1 : 0 },
            { AnalyticsKey.StagePowerupDelthreeLimitless, gameData.itemList?.Contains((int)PropEnum.TimeItemEliminate) == true ? 1 : 0 },
            { AnalyticsKey.StagePowerupWildLimitless, gameData.itemList?.Contains((int)PropEnum.TimeItemJoker) == true ? 1 : 0 },
            { AnalyticsKey.StagePowerupCactusLimitless, gameData.itemList?.Contains((int)PropEnum.TimeItemCactus) == true ? 1 : 0 },
            { AnalyticsKey.StagePowerupWindmillLimitless, gameData.itemList?.Contains((int)PropEnum.TimeItemWindmill) == true ? 1 : 0 },
            { AnalyticsKey.MultiplyFactor, nowUseBet },
            { AnalyticsKey.BattleDuration, TimeUtils.UtcNow() - startGameTime },
            { AnalyticsKey.Coin, dataService.Coin},//当局结算完后的金币
            { AnalyticsKey.LevelJson, json}
        };
        AnalyticUtils.ReportEvent(AnalyticsKey.SoliBattleEnd, msg);
        AnalyticUtils.ReportUser_Add(AnalyticsKey.BattleSingleTime, TimeUtils.UtcNow() - startGameTime);
    }

    public GameObject RookieFunc_GetBingoCard(float delay)
    {
        var card = BattleDataMgr.Instance.GetCanCollectCard();
        if (card != null)
        {
            if (BattleDataMgr.Instance.OperatStack.Count > 0)
            {
                var opt = BattleDataMgr.Instance.OperatStack.Peek();
                if (TimeUtils.UtcNow() - opt.time < 6)
                {
                    return null;
                }
            }
            var cardObj = BattleViewMgr.Instance.GetDeskCardObject(card.id);
            if (cardObj != null)
                return cardObj;
        }
        return null;
    }

    public GameObject RookieFunc_GetHandCard(float delay = 2f)
    {
        if (BattleViewMgr.Instance.IsRendering() || IsWin())
            return null;
        var comboCard = BattleDataMgr.Instance.GetCanCollectCard();
        if (comboCard != null)
            return null;
        var card = BattleDataMgr.Instance.GetHandCard();
        if (card != null)
        {
            var cardObj = BattleViewMgr.Instance.GetHandCardObject(card.id);
            if (cardObj != null)
                return cardObj;
        }
        return null;
    }

    public bool RookieFunc_JokerCard(float delay = 1f)
    {
        if (BattleViewMgr.Instance.IsRendering() || IsWin()) return false;
        var card = BattleDataMgr.Instance.GetCanCollectCard();
        bool jokerAble = configService.GetBuyJokerCost(BattleLevel, 1) > 0 && dataService.Coin >= gameData.GetNowBuyJokerCost();
        return card == null && jokerAble;
    }

    public bool RookieFunc_Undo(float delay = 1f)
    {
        if (BattleViewMgr.Instance.IsRendering() || IsWin()) return false;
        var undoAble = BattleDataMgr.Instance.CanUndo() && dataService.Coin >= gameData.GetNowUndoCost();
        return BattleDataMgr.Instance.IsMissCombo() && undoAble;
    }

    public bool RookieFunc_BuyCard(float delay = 1f)
    {
        if (BattleViewMgr.Instance.IsRendering() || IsWin()) return false;
        bool buycardAble = configService.GetBuyCardCost(BattleLevel, 1) > 0 && dataService.Coin >= gameData.GetNowBuyCardCost();
        if (BattleDataMgr.Instance.GetHandCardsNum() == 0 && buycardAble)
        {
            var card = BattleDataMgr.Instance.GetCanCollectCard();
            return card == null;
        }

        return false;
    }

    public GameObject RookieFunc_GetCard(string cardType, float delay = 0.5f)
    {
        if (BattleViewMgr.Instance.IsRendering() || IsWin()) return null;
        var card = BattleDataMgr.Instance.GetTargetTypeCard(cardType);
        if (card != null)
            return BattleViewMgr.Instance.GetDeskCardObject(card.id);
        return null;
    }

    public bool RookieFunc_MatchLastSameColorGuide()
    {
        return BattleDataMgr.Instance.IsWillSameColorCombo();
    }

    public GameObject RookieFunc_GetMatchSameColorComboCard(float delay = 1f)
    {
        // if (BattleViewMgr.Instance.IsRendering() || IsWin())
        //     return null;
        if (IsWin())
            return null;
        CardData card = BattleDataMgr.Instance.GetSameComboCard();
        if (card != null)
            return BattleViewMgr.Instance.GetDeskCardObject(card.id);
        return null;
    }

    private void OnGameRechargeEvent(GameRechargeEvent e)
    {
        if (IsPlaying)
            BattleDataMgr.Instance.ChargeEvent();
    }
}