﻿using Doozy.Engine;
using QFramework;
using System;
using System.Linq;
using System.Collections;
using UnityEngine;
using UniRx;
using System.Collections.Generic;
using Activities;
using UnityEngine.UI;
using SoliUtils;

public class BackdropMono : MonoBehaviour, ISingleton
{
    string nowGameStr;
    string nowHomeStr;

    [SerializeField]
    private GameObject nowGameBack;
    [SerializeField]
    private GameObject nowHomeBack;


    public static BackdropMono Instance
    {
        get { return MonoSingletonProperty<BackdropMono>.Instance; }
    }

    public void OnSingletonInit()
    {
        Message.AddListener<GameEventMessage>(OnDoozyMessage);
    }

    private void OnDoozyMessage(GameEventMessage obj)
    {
        switch (obj.EventName)
        {
            case Constants.DoozyEvent.GameEnd:
                ChangeBackdropState(false);
                break;
            case Constants.DoozyEvent.StartGame:
                ChangeBackdropState(true);
                break;
            default:
                break;
        }
    }

    public void SetBuildShow(int buildId, int? selectIndex)
    {
        // IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        // BuildModel buildModel = configService.BuildConfig[buildId];
        // nowGameBack.transform.FindOrNull(buildModel.origGameRes)?.gameObject.SetActive(!selectIndex.HasValue);
        // for (int i = 1; i <= 3; i++)
        // {
        //     nowGameBack.transform.FindOrNull(buildModel.GetIndexRes(i, true))?.gameObject.SetActive(false);
        // }
        //
        // if (!selectIndex.HasValue) return;
        // Transform buildSelectTrans = nowHomeBack.transform.FindOrNull(buildModel.GetIndexRes(selectIndex.Value, false));
        // if (buildSelectTrans != null)
        // {
        //     buildSelectTrans.gameObject.SetActive(true);
        //     buildSelectTrans.GetComponent<Animator>().Play("Stay");
        // }
        //
        // buildSelectTrans = nowGameBack.transform.FindOrNull(buildModel.GetIndexRes(selectIndex.Value, true));
        // if (buildSelectTrans != null)
        //     buildSelectTrans.gameObject.SetActive(true);
    }

    public void SwitchBackdrop()
    {
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        int mapId = dataService.FarmingProgress?.curMapId ?? 1;
        int themeId = dataService.FarmingProgress?.curThemeId ?? 1;
        // FarmingModel model = configService.GetFarmingModel(mapId, themeId, 1);
        // SetBackdrop(model.homeBg, model.battleBg);
        
        SetBackdrop("Assets/Res/Textures/Background/Map1_1/zybj_1_1.jpg", "Assets/Res/Textures/Background/Map1_1/zdbj_1_1.jpg");

        SetBackdropScale();
    }

    public void CheckSetLavaGameBg(ref string newGameBg)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass) != null &&
            ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state == ActivityState.underWay)
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            if (dataService.LavaPassProgress.isFailState != 1)
            {
                newGameBg = "Assets/Res/Textures/Background/Activity/zdbj_ry.jpg";
            }
        }
    }

    public void SetBackdrop(string newHomeBG, string newGameBg)
    {
        CheckSetLavaGameBg(ref newGameBg);
        if (nowGameStr != newGameBg || nowHomeStr != newHomeBG)
        {
            nowGameStr = newGameBg;
            nowHomeStr = newHomeBG;

            SpriteUtils.GetTextureAsyncByPath(newGameBg, (obj) =>
            {
                nowGameBack.GetComponent<RawImage>().texture = obj;
                nowGameBack.SetActive(GameController.Instance.IsPlaying);
                nowGameBack.GetComponent<RawImage>().color = Color.white;
                SetBackdropScale();
            });
            // SpriteUtils.GetTextureAsyncByPath(newHomeBG, (obj) =>
            // {
            //     nowHomeBack.GetComponent<RawImage>().texture = obj;
            //     nowHomeBack.SetActive(!GameController.Instance.IsPlaying);
            //     nowHomeBack.GetComponent<RawImage>().color = Color.white;
            //     SetBackdropScale();
            //     TypeEventSystem.Send<BackGroundLoadedEvent>();
            // });
        }
    }

    public void SetBackdropDefault(string gameBg, string homeBg)
    {
        SpriteUtils.GetTextureAsyncByPath(gameBg, (obj) =>
        {
            nowGameBack.GetComponent<RawImage>().texture = obj;
            nowGameBack.SetActive(GameController.Instance.IsPlaying);
            nowGameBack.GetComponent<RawImage>().color = Color.white;
            SetBackdropScale();
        });
        // SpriteUtils.GetTextureAsyncByPath(homeBg, (obj) =>
        // {
        //     nowHomeBack.GetComponent<RawImage>().texture = obj;
        //     nowHomeBack.GetComponent<RawImage>().color = Color.white;
        //     nowHomeBack.SetActive(!GameController.Instance.IsPlaying);
        //     SetBackdropScale();
        // });
    }

    public void SetBackdropWhite()
    {
        IStorageService storageService = MainContainer.Container.Resolve<IStorageService>();
        storageService.LoadResource<GameObject>("Assets/Res/Prefabs/Map/White.prefab",
            res =>
            {
                nowGameBack = Instantiate(res, transform, false);
                nowGameBack.SetActive(GameController.Instance.IsPlaying);
                // nowHomeBack = Instantiate(res, transform, false);
                // nowHomeBack.SetActive(!GameController.Instance.IsPlaying);
                SetBackdropScale();
            });
    }

    public void SetBackdropGreen()
    {
        IStorageService storageService = MainContainer.Container.Resolve<IStorageService>();
        storageService.LoadResource<GameObject>("Assets/Res/Prefabs/Map/Green.prefab",
            res =>
            {
                nowGameBack = Instantiate(res, transform, false);
                nowGameBack.SetActive(GameController.Instance.IsPlaying);
                // nowHomeBack = Instantiate(res, transform, false);
                // nowHomeBack.SetActive(!GameController.Instance.IsPlaying);
                SetBackdropScale();
            });
    }

    public void ChangeBackdropState(bool isToGame)
    {
        if (nowGameBack)
            nowGameBack.SetActive(isToGame);
        if (nowHomeBack)
            nowHomeBack.SetActive(!isToGame);
    }

    public string GetNowBackdrop(bool isGaming) => isGaming ? nowGameStr : nowHomeStr;

    private void SetBackdropScale()
    {
        if (nowGameBack == null) return; //|| nowHomeBack == null
        float scale = DeviceUtils.GetScreenScale();
        nowGameBack.transform.localScale = Vector3.one;// * scale;
        // if (nowHomeBack)
        // {
        //     nowHomeBack.transform.localScale = Vector3.one;// * scale;
        // }
    }

    private void OnDestroy()
    {
        Message.RemoveListener<GameEventMessage>(OnDoozyMessage);
    }
}