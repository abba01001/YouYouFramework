﻿using Activities;
using QFramework;
using UnityEngine;

public class GameOption
{
    public CardModel cm;
    public long stamptime;
}

public class GameController : MonoBehaviour, ISingleton, IController
{
    private IConfigService configService;
    private IDataService dataService;
    public BattleController BattleCtrl { get; set; }

    public bool IsPlaying
    {
        get
        {
            return BattleCtrl != null && BattleCtrl.IsPlaying;
        }
    }

    public bool IsRendering
    {
        get
        {
            return BattleViewMgr.Instance.IsRendering();
        }
    }

    public void OnApplicationQuitEvent()
    {
        if (BattleCtrl != null && BattleCtrl.IsPlaying)
        {
            if (ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.winStreak))
            {
                dataService.ActivitySaveData.winStreak.WinCount = 0;
            }
            EndBattle(null);
        }
    }

    void Awake()
    {
        TypeEventSystem.Register<StartGameEvent>(OnStartGameEvent);
        TypeEventSystem.Register<EndGameEvent>(OnEndGameEvent);
        TypeEventSystem.Register<GM_WinGame>(OnGM_WinGame);


        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
    }

    void OnDestroy()
    {
        TypeEventSystem.UnRegister<StartGameEvent>(OnStartGameEvent);
        TypeEventSystem.UnRegister<EndGameEvent>(OnEndGameEvent);
        TypeEventSystem.UnRegister<GM_WinGame>(OnGM_WinGame);
    }

    private void Update()
    {
        if (IsPlaying)
        {
            BattleCtrl.Update();
        }
    }

    private void OnStartGameEvent(StartGameEvent e)
    {
        StartBattle(e);
    }

    private void OnEndGameEvent(EndGameEvent e)
    {
        EndBattle(e.config);
    }

    private void StartBattle(StartGameEvent e)
    {
        dataService.IsFinishBattle = false;
        BattleCtrl = new BattleController();
        BattleCtrl.StartGame(e);
    }

    private void EndBattle(BattleConfig config)
    {
        dataService.IsFinishBattle = true;
        if (BattleCtrl != null)
        {
            BattleCtrl.gameData.RemainDeskCardNum = BattleDataMgr.Instance.GetDeskCardsNum();
            BattleCtrl.gameData.RemainHandCardNum = BattleDataMgr.Instance.GetHandCardsNum();
            BattleCtrl.gameData.RemainStepNum = BattleDataMgr.Instance.AIAction_NeedStep();
            BattleCtrl.EndGame(config);
        }

        BattleCtrl = null;
    }

    public void ExitBattle()
    {
        if (BattleCtrl != null)
        {
            BattleDataMgr.Instance.ExitBattle();
        }
    }

    public void OnSingletonInit()
    {

    }

    public static GameController Instance
    {
        get { return MonoSingletonProperty<GameController>.Instance; }
    }

    private void OnGM_WinGame(GM_WinGame obj)
    {
        if (!BattleCtrl.IsPlaying)
            return;

        BattleCtrl.gameData.AddRewardStar(obj.winStar);
        BattleDataMgr.Instance.GmActionWin();
    }

}
