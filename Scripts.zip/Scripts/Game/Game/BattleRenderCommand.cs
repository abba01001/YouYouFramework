using System.Collections.Generic;
using System.Linq;
using Doozy.Engine.Extensions;
using UnityEngine;
using SoliUtils;

public class IRenderCommand
{
    public bool block = false;
}

public class NewCreateCardCommand : IRenderCommand
{
    private int cardId;
    private int backId;
    private int betValue;
    private CardData cardData;

    public int CardId => cardId;
    public int BackId => backId;
    public int BetValue => betValue;
    public CardData CardData => cardData;

    public void Init(int _cardId, CardData _cardData, int _backId, int _betValue)
    {
        cardId = _cardId;
        cardData = _cardData?.Copy();
        backId = _backId;
        betValue = _betValue;
    }
}

public class InitBattleCommand : IRenderCommand
{

    public List<CardData> DeskCards;
    public List<CardData> HandCards;
    public bool isMovingScene = false;
    public void Init(List<CardData> _deskCards, List<CardData> _handCards, bool isMovingScene)
    {
        DeskCards = GameUtils.CloneCardDataList(_deskCards);
        HandCards = GameUtils.CloneCardDataList(_handCards);
        this.isMovingScene = isMovingScene;
        block = true;
    }
}

public class FlopHandCardCommand : IRenderCommand
{
    public CardData cardData;
    public void Init(CardData a)
    {
        cardData = a?.Copy();
        block = true;
    }
}

public class FlopHandCardWindmillCommand : IRenderCommand
{
    public List<CardData> cardList;
    public void Init(List<CardData> a)
    {
        cardList = GameUtils.CloneCardDataList(a);
        block = true;
    }
}

public class ItemEliminateDeskCardCommand : IRenderCommand
{
    public List<CardData> eliminateList;
    public void Init(List<CardData> a)
    {
        eliminateList = GameUtils.CloneCardDataList(a);
        block = true;
    }
}


public class ItemJokerCommand : IRenderCommand
{
    public List<CardData> jokerCardList;
    public void Init(List<CardData> _jokerCardList)
    {
        jokerCardList = GameUtils.CloneCardDataList(_jokerCardList);
        block = true;
    }
}

public class ItemCactusCommand : IRenderCommand
{
    public List<CardData> cactusCardList;
    public void Init(List<CardData> _cactusCardList)
    {
        cactusCardList = GameUtils.CloneCardDataList(_cactusCardList);
        block = true;
    }
}

public class RefreshCardValueCommand : IRenderCommand
{
    public CardData cardData;
    public void Init(CardData a)
    {
        cardData = a?.Copy();
    }
}

public class RefreshCardPositionCommand : IRenderCommand
{
    public CardData card;
    public void Init(CardData card) => this.card = card?.Copy();
}


public class CollectDeskCardCommand : IRenderCommand
{
    public CardData cardData;
    public void Init(CardData a)
    {
        cardData = a?.Copy();
        block = false;
    }
}

public class CheckLimitPkPopupCommand : IRenderCommand
{
    public ActivityType activityType;
    public CheckLimitPkPopupCommand(ActivityType _activityType)
    {
        activityType = _activityType;
        block = true;
    }
}

public class CheckSpecialCardTipCommand : IRenderCommand
{
    public CheckSpecialCardTipCommand()
    {
        block = true;
    }
}

public class CopyCardCommand : IRenderCommand
{
    public CardData copyCard;
    public CopyCardCommand(CardData a)
    {
        copyCard = a?.Copy();
    }
}

public class FlopDeskCardCommand : IRenderCommand
{
    public CardData cardData;
    public void Init(CardData a)
    {
        cardData = a?.Copy();
    }
}

public class BoomCardCommand : IRenderCommand
{
    public CardData boomCard;
    public List<CardData> boomFlyCards;
    public BoomCardCommand(CardData a, List<CardData> b)
    {
        boomCard = a?.Copy();
        boomFlyCards = GameUtils.CloneCardDataList(b);
        block = true;
    }
}

public class WindmillCardCommand : IRenderCommand
{
    public CardData windmillCard;
    public List<CardData> windmillFlyCards;

    public WindmillCardCommand(CardData a, List<CardData> b)
    {
        windmillCard = a?.Copy();
        windmillFlyCards = GameUtils.CloneCardDataList(b);
        block = true;
    }
}

public class ZapCardCommand : IRenderCommand
{
    public CardData zapCard;
    public List<CardData> zapFlyCards;
    public ZapCardCommand(CardData a, List<CardData> b)
    {
        zapCard = a?.Copy();
        zapFlyCards = GameUtils.CloneCardDataList(b);
        block = true;
    }
}

public class MonkeyBananaCardCommand : IRenderCommand
{
    public CardData clickCard;
    public CardData pairCard;

    public MonkeyBananaCardCommand(CardData click, CardData pair)
    {
        clickCard = click?.Copy();
        pairCard = pair?.Copy();
        block = true;
    }
}

public class UnlockCardCommand : IRenderCommand
{
    public CardData keyCard;
    public List<CardData> lockCards;
    public UnlockCardCommand(CardData a, List<CardData> b)
    {
        keyCard = a?.Copy();
        lockCards = GameUtils.CloneCardDataList(b);
        block = true;
    }
}

public class BombUpdateCommand : IRenderCommand
{
    public List<CardData> bombCards;
    public BombUpdateCommand(List<CardData> a)
    {
        bombCards = GameUtils.CloneCardDataList(a);
    }
}

public class UndoBombUpdateCommand : IRenderCommand
{
    public int bombCardId;
    public List<int> bombCards;
    public UndoBombUpdateCommand(int cardId, List<int> a)
    {
        bombCardId = cardId;
        bombCards = new List<int>(a);
    }
}

public class BigBombUpdateCommand : IRenderCommand
{
    public List<CardData> bigBombCards;
    public BigBombUpdateCommand(List<CardData> a)
    {
        bigBombCards = GameUtils.CloneCardDataList(a);
    }
}

public class BigBombingCommand : IRenderCommand
{
    public List<CardData> bigBombCards;
    public BigBombingCommand(List<CardData> a)
    {
        bigBombCards = GameUtils.CloneCardDataList(a);
        block = true;
    }
}

public class BombingCommand : IRenderCommand
{
    public List<CardData> bombCards;
    public List<CardData> newCards;
    public BombingCommand(List<CardData> a, List<CardData> b)
    {
        bombCards = GameUtils.CloneCardDataList(a);
        newCards = GameUtils.CloneCardDataList(b);
        block = true;
    }
}

public class RisingUpdateCommand : IRenderCommand
{
    public List<CardData> risingCards;
    public bool undo;
    public RisingUpdateCommand(List<CardData> a, bool b = false)
    {
        risingCards = GameUtils.CloneCardDataList(a);
        undo = b;
    }
}

public class LoweringUpdateCommand : IRenderCommand
{
    public List<CardData> loweringCards;
    public bool undo;
    public LoweringUpdateCommand(List<CardData> a, bool b = false)
    {
        loweringCards = GameUtils.CloneCardDataList(a);
        undo = b;
    }
}

public class ThreeCardCommand : IRenderCommand
{
    public int threeCard;
    public List<int> newCards;
    public List<int> handCards;
    public ThreeCardCommand(int a, List<int> b, List<int> c)
    {
        threeCard = a;
        newCards = new List<int>(b);
        handCards = new List<int>(c);
        // block = true;
    }
}

public class QuestionCardCommand : IRenderCommand
{
    public int questionCard;
    public int newCard;
    public QuestionCardCommand(int questionCard, int newCard)
    {
        this.questionCard = questionCard;
        this.newCard = newCard;
        block = true;
    }
}

public class AnchorCardCommand : IRenderCommand
{
    public CardData anchorCard;
    public AnchorCardCommand(CardData card)
    {
        anchorCard = card?.Copy();
        block = true;
    }
}

public class BreakIceByHandCardCommand : IRenderCommand
{
    public CardData iceCard;
    public BreakIceByHandCardCommand(CardData a)
    {
        iceCard = a?.Copy();
        block = true;
    }
}

public class IceBrokenCommand : IRenderCommand
{
    public CardData iceCard;
    public IceBrokenCommand(CardData a)
    {
        iceCard = a?.Copy();
    }
}

public class UndoFlopHandCardCommand : IRenderCommand
{
    public List<int> handCards;
    public UndoFlopHandCardCommand(List<int> a)
    {
        handCards = new List<int>(a);
        block = true;
    }
}

public class UndoDeskCardCommand : IRenderCommand
{
    public CardData card;
    public UndoDeskCardCommand(CardData _card)
    {
        card = _card?.Copy();
        block = true;
    }
}

public class UndoBreakIceCommand : IRenderCommand
{

    public CardData iceCard;
    public CardData openCard;
    public UndoBreakIceCommand(CardData iceCard, CardData openCard)
    {
        this.iceCard = iceCard?.Copy();
        this.openCard = openCard?.Copy();
        block = true;
    }
}

public class UndoCopyCardCommand : IRenderCommand
{
    public CardData card;

    public int cardOperate;  //该次Copy牌的操作  1-变成其它牌复制  2-从桌面飞入手中
    public UndoCopyCardCommand(CardData a, int b)
    {
        card = a?.Copy();
        cardOperate = b;
    }
}

public class UndoMonkeyBananaCardCommand : IRenderCommand
{
    public CardData monkeyCard;
    public CardData bananaCard;

    public UndoMonkeyBananaCardCommand(CardData monkey, CardData banana)
    {
        monkeyCard = monkey?.Copy();
        bananaCard = banana?.Copy();
    }
}

public class UndoWindmillCardCommand : IRenderCommand
{
    public Vector3 pos;
    public CardData windmillCard;
    public List<CardData> windmillFlyCards;

    public UndoWindmillCardCommand(Vector3 pos, CardData windmill, List<CardData> windmillFly)
    {
        this.pos = pos;
        windmillCard = windmill?.Copy();
        windmillFlyCards = GameUtils.CloneCardDataList(windmillFly);
        block = true;
    }
}

public class BuyJokerCommand : IRenderCommand
{
    public CardData card;
    public BuyJokerCommand(CardData a)
    {
        card = a;
        block = true;
    }
}

public class UndoBuyJokerCommand : IRenderCommand
{
    public CardData card;
    public UndoBuyJokerCommand(CardData a)
    {
        card = a?.Copy();
        block = true;
    }
}

public class BuyCardsCommand : IRenderCommand
{
    public List<CardData> cards;
    public BuyCardsCommand(List<CardData> a)
    {
        cards = GameUtils.CloneCardDataList(a);
        block = true;
    }
}

public class ShowResultCommand : IRenderCommand
{
    public bool win = true;
    public ShowResultCommand(bool _win)
    {
        win = _win;
    }
}

public class AddComboCardCommand : IRenderCommand
{
    public int[] newCards;
    public List<int> handCards;
    public float waitTime;
    public AddComboCardCommand(int[] a, List<int> b, float _waitTime)
    {
        newCards = a;
        handCards = b;
        waitTime = _waitTime;
    }
}

public class UndoComboCardCommand : IRenderCommand
{
    public List<int> removeCards;
    public UndoComboCardCommand(List<int> a) => removeCards = a;
}

public class ShakeCardCommand : IRenderCommand
{
    public CardData card;
    public ShakeCardCommand(CardData a)
    {
        card = a?.Copy();
    }
}

public class ScaleCardCommand : IRenderCommand
{
    public CardData cardData;
    public ScaleCardCommand(CardData a)
    {
        cardData = a?.Copy();
    }
}

public class WinStreakCardsCommand : IRenderCommand
{
    public List<int> newCards;
    public List<int> handCards;
    public WinStreakCardsCommand(List<int> a, List<int> b)
    {
        newCards = a;
        handCards = new List<int>(b);
        block = true;
    }
}

public class RabbitCardCommand : IRenderCommand
{
    public List<int> newCards;
    public List<int> handCards;
    public RabbitCardCommand(List<int> a, List<int> b)
    {
        newCards = a;
        handCards = new List<int>(b);
        block = true;
    }
}

public class ItemWindmillCardCommand : IRenderCommand
{
    public List<int> newCards;
    public List<int> handCards;
    public ItemWindmillCardCommand(List<int> a, List<int> b)
    {
        newCards = a;
        handCards = new List<int>(b);
        block = true;
    }
}


public class ExitBattleCommand : IRenderCommand
{
    public ExitBattleCommand()
    {
        block = true;
    }
}

public class AddMoveSceneCammand : IRenderCommand
{
    public Vector3 startPos;
    public Vector3 endPos;
    public AddMoveSceneCammand(Vector3 a, Vector3 b)
    {
        startPos = a;
        endPos = b;
    }

}

public class MoveSceneCammand : IRenderCommand
{
    public float distance;
    public List<CardData> cards;
    public bool hide;
    public MoveSceneCammand(float a, List<CardData> b, bool c)
    {
        distance = a;
        cards = GameUtils.CloneCardDataList(b);
        hide = c;
        block = true;
    }
}

public class UndoMoveSceneCammand : IRenderCommand
{
    public List<CardData> cards;
    public UndoMoveSceneCammand(List<CardData> cards)
    {
        this.cards = GameUtils.CloneCardDataList(cards);
        block = true;
    }
}

public class AddLockItemCammand : IRenderCommand
{
    public LockModel data;
    public AddLockItemCammand(LockModel a)
    {
        data = a;
    }

}

public class RopeSuitUpdateCommand : IRenderCommand
{
    public readonly List<CardData> cardList;
    public readonly bool resetValue;

    public RopeSuitUpdateCommand(List<CardData> list, bool resetValue)
    {
        cardList = GameUtils.CloneCardDataList(list);
        this.resetValue = resetValue;
    }
}

public class ClothRoundUpdateCommand : IRenderCommand
{
    public readonly List<CardData> cardList;

    public ClothRoundUpdateCommand(List<CardData> cardList)
    {
        this.cardList = GameUtils.CloneCardDataList(cardList);
    }
}

public class GreenLeafUpdateCommand : IRenderCommand
{
    public readonly CardData lastBirdCard;
    public readonly List<CardData> cardList;

    public GreenLeafUpdateCommand(CardData lastBirdCard, List<CardData> cardList)
    {
        this.lastBirdCard = lastBirdCard?.Copy();
        this.cardList = GameUtils.CloneCardDataList(cardList);
    }
}

public class ShowBirdCommand : IRenderCommand
{
    public readonly Vector3 pos;

    public ShowBirdCommand(Vector3 pos)
    {
        this.pos = pos;
    }
}

public class FlyBirdCommand : IRenderCommand
{
    public readonly Vector3 toPos;

    public FlyBirdCommand(Vector3 toPos)
    {
        this.toPos = toPos;
    }
}

public class LightningUpdateCommand : IRenderCommand
{
    public readonly List<CardData> cardList;

    public LightningUpdateCommand(List<CardData> cardList)
    {
        this.cardList = GameUtils.CloneCardDataList(cardList);
    }
}

public class LightningCardMissCommand : IRenderCommand
{
    public readonly CardData lightningCard;
    public readonly CardData handCard;
    public readonly bool undo;

    public LightningCardMissCommand(CardData lightningCard, CardData handCard, bool undo)
    {
        this.lightningCard = lightningCard?.Copy();
        this.handCard = handCard?.Copy();
        this.undo = undo;
        block = true;
    }
}

public class RefreshLinkRopeCommand : IRenderCommand
{
    public readonly List<CardData> lockCards;
    public readonly List<CardData> unlockCards;

    public RefreshLinkRopeCommand(List<CardData> lockCards, List<CardData> unlockCards)
    {
        this.lockCards = GameUtils.CloneCardDataList(lockCards);
        this.unlockCards = GameUtils.CloneCardDataList(unlockCards);
    }
}

public class CollectLinkCardCommand : IRenderCommand
{
    public CardData firstCard;
    public CardData lastCard;

    public void Init(CardData card1, CardData card2)
    {
        firstCard = card1?.Copy();
        lastCard = card2?.Copy();
        block = true;
    }
}

public class RefreshAnchorCardCommand : IRenderCommand
{
    public List<CardData> cards;
    public bool undo;
    public bool skipAnim;

    public void Init(List<CardData> _cards, bool undo, bool skipAnim)
    {
        cards = GameUtils.CloneCardDataList(_cards);
        this.undo = undo;
        this.skipAnim = skipAnim;
    }
}

public class SortHandCardCommand : IRenderCommand
{
    public int handCardNumber;
    public SortHandCardCommand(int handCardNumber)
    {
        this.handCardNumber = handCardNumber;
    }
}

public class RemoveHandCardCommand : IRenderCommand
{
    public List<int> removeHandCards;
    public RemoveHandCardCommand(List<int> removeHandCards)
    {
        this.removeHandCards = removeHandCards;
    }
}

public class RestoreDeskCardCommand : IRenderCommand
{
    public List<CardData> deskHandCards;
    public RestoreDeskCardCommand(List<CardData> deskHandCards)
    {
        this.deskHandCards = GameUtils.CloneCardDataList(deskHandCards);
    }
}

public class UndoKeyLockCardCommand : IRenderCommand
{
    public List<int> deskHandCards;
    public UndoKeyLockCardCommand(List<int> deskHandCards)
    {
        this.deskHandCards = deskHandCards;
    }
}

public class RefreshSuitRopeCommand : IRenderCommand
{
    public CardData card;
    public RefreshSuitRopeCommand(CardData card)
    {
        this.card = card?.Copy();
    }
}

public class UndoLinkCardCommand : IRenderCommand
{
    public CardData clickCard;
    public CardData linkCard;
    public UndoLinkCardCommand(CardData clickCard, CardData linkCard)
    {
        this.clickCard = clickCard?.Copy();
        this.linkCard = linkCard?.Copy();
        block = true;
    }
}

public class RemoveModifierCommand : IRenderCommand
{

    public List<CardData> cards;
    public RemoveModifierCommand(List<CardData> cards)
    {
        this.cards = GameUtils.CloneCardDataList(cards);
    }
}

public class RecycleModifierCommand : IRenderCommand
{

    public CardData card;
    public RecycleModifierCommand(CardData card)
    {
        this.card = card?.Copy();
    }
}

public class ComboViewCommand : IRenderCommand
{
    public int comboStep;
    public int comboCount;
    public int comboLimit;
    public List<bool> colors;

    public ComboViewCommand(int comboStep, int comboCount, int comboLimit, List<bool> colors)
    {
        // Debug.LogError($"ComboViewCommand {comboStep} => {comboCount} / {comboLimit}");
        this.comboStep = comboStep;
        this.comboCount = comboCount;
        this.comboLimit = comboLimit;
        this.colors = new List<bool>(colors);
    }
}
public class UndoQuestionCardCommand : IRenderCommand
{
    public int questionCardId;
    public int newCardId;
    public UndoQuestionCardCommand(int questionCardId, int newCardId)
    {
        this.questionCardId = questionCardId;
        this.newCardId = newCardId;
    }
}

public class RudderCardCommand : IRenderCommand
{
    public CardData rudderCard;
    public List<CardData> rudderFlyCards;
    public RudderCardCommand(CardData a, List<CardData> b)
    {
        rudderCard = a?.Copy();
        rudderFlyCards = GameUtils.CloneCardDataList(b);
        block = true;
    }
}

public class LizardCardCommand : IRenderCommand
{
    public List<int> lizardCards;
    public List<int> removeCards;
    public LizardCardCommand(List<int> lizardCards, List<int> removeCards)
    {
        this.lizardCards = new List<int>(lizardCards);
        this.removeCards = new List<int>(removeCards);
        block = true;
    }
}