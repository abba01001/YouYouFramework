using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using QFramework;
using System.Linq;
using Doozy.Engine.UI;
using Doozy.Engine.Nody;
using System;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class RookieMgr : MonoBehaviour
{
    private IConfigService configService;
    private IDataService dataService;
    private Dictionary<int, float> repeatDic = new Dictionary<int, float>();
    public GraphController graphController;
    private int currentRookieId = -1;
    private BaseCard rookieCard;
    private bool isRookie;
    private Dictionary<int, RookieDialogueDicModel> dialogueConfigDic;
    private Dictionary<string, int> triggerItemDic = new Dictionary<string, int>();
    private Dictionary<string, float> delayDic = new Dictionary<string, float>();
    void Start()
    {
        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
        InitDialogueConfigDic();
        TypeEventSystem.Register<RookieTriggerBeginEvent>(OnRookieTriggerBeginEvent);
        TypeEventSystem.Register<RookieTriggerEndEvent>(OnRookieTriggerEndEvent);
        TypeEventSystem.Register<DoTurnCardEvent>(OnDoTurnCardEvent);
        TypeEventSystem.Register<UnlockMergeItemEvent>(OnUnlockMergeItemEvent);
        TypeEventSystem.Register<ShowHomeViewEvent>(OnShowHomeViewEvent);
        TypeEventSystem.Register<RookieStoryOverEvent>(OnRookieStoryOverEvent);
        TypeEventSystem.Register<DragMergeItemEvent>(OnDragMergeItemEvent); 
    }

    private void InitDialogueConfigDic()
    {
        dialogueConfigDic = new Dictionary<int, RookieDialogueDicModel>();
        foreach (var item in configService.RookieDialogueConfig)
        {
            int mainId = item.Key / 100;
            int stepId = item.Key % 100;
            if (!dialogueConfigDic.ContainsKey(mainId))
            {
                dialogueConfigDic.Add(mainId, new RookieDialogueDicModel(mainId));

            }
            dialogueConfigDic[mainId].Add(stepId, item.Value);
        }
    }

    void OnDestroy()
    {
        TypeEventSystem.UnRegister<RookieTriggerBeginEvent>(OnRookieTriggerBeginEvent);
        TypeEventSystem.UnRegister<RookieTriggerEndEvent>(OnRookieTriggerEndEvent);
        TypeEventSystem.UnRegister<DoTurnCardEvent>(OnDoTurnCardEvent);
        TypeEventSystem.UnRegister<UnlockMergeItemEvent>(OnUnlockMergeItemEvent);
        TypeEventSystem.UnRegister<ShowHomeViewEvent>(OnShowHomeViewEvent);
        TypeEventSystem.UnRegister<RookieStoryOverEvent>(OnRookieStoryOverEvent);
        TypeEventSystem.UnRegister<DragMergeItemEvent>(OnDragMergeItemEvent);
    }

    public void OnRookieTriggerBeginEvent(RookieTriggerBeginEvent e)
    {
        isRookie = true;
    }

    public void OnRookieTriggerEndEvent(RookieTriggerEndEvent e)
    {
        // MergeGameController.Instance.SetTouchAble(true);
        Debug.Log("引导结束 id=========="+ currentRookieId);
        isRookie = false;
        if (!configService.RookieConfig.ContainsKey(currentRookieId))
            return;

        var rookieModel = configService.RookieConfig[currentRookieId];
        if (rookieCard != null)
        {
            var box2d = rookieCard.GetComponentInChildren<BoxCollider2D>();
            Vector2 pos;
            var screenpos = Camera.main.WorldToScreenPoint(rookieCard.transform.position);
            RectTransformUtility.ScreenPointToLocalPointInRectangle(UICanvas.MasterCanvas.Canvas.transform as RectTransform,
             screenpos, Camera.main, out pos);

            if (e.clickPos.x > pos.x - box2d.size.x / 2 && e.clickPos.x < pos.x + box2d.size.x / 2 &&
                e.clickPos.y > pos.y - box2d.size.y / 2 && e.clickPos.y < pos.y + box2d.size.y / 2)
            {
                TouchCardEvent t = GameObjManager.Instance.PopClass<TouchCardEvent>(true);
                t.Init(rookieCard.CardId);
                TypeEventSystem.Send<TouchCardEvent>(t);
            }
        }

        if (rookieModel.repeat == 0)
        {
            dataService.MarkRookieTipFlag(currentRookieId);
        }
        currentRookieId = -1;
        rookieCard = null;
        dataService.PrintRookieTipFlag();
    }

    public void OnDoTurnCardEvent(GameEvent e)
    {
    }

    private void OnUnlockMergeItemEvent(UnlockMergeItemEvent e)
    {
        AddTriggerItem("item_unlock", e.itemId);
    }

    private void OnDragMergeItemEvent(DragMergeItemEvent e)
    {
        AddTriggerItem("item_drag", e.itemId);
    }

    private void OnShowHomeViewEvent(ShowHomeViewEvent e)
    {
        AddTriggerItem("mergemap_enter", 1);
        Observable.Timer(TimeSpan.FromSeconds(3f)).Subscribe(_ =>
        {
            RemoveTriggerItem("mergemap_enter");
        });
    }

    private void OnRookieStoryOverEvent(RookieStoryOverEvent e)
    {
        AddTriggerItem("rookie_complete", 1);
        Observable.Timer(TimeSpan.FromSeconds(3f)).Subscribe(_ =>
        {
            RemoveTriggerItem("rookie_complete");
        });
    }

    private void AddTriggerItem(string key,int value)
    {
        if (!triggerItemDic.ContainsKey(key))
        {
            triggerItemDic.Add(key, value);
        }
        else
        {
            triggerItemDic[key] = value;
        }
    }

    void LateUpdate()
    {
        if (isRookie)
            return;

        if (BattleViewMgr.Instance.IsRenderBlock())
            return;
        
        if (!FxMaskView.Inited)
        {
            return;
        }

        if (currentRookieId != -1)
            return;

        var nowLv = dataService.MaxLevel;
        var nextRookieId = 1;
        while (configService.RookieConfig.ContainsKey(nextRookieId))
        {
            var rookieId = nextRookieId;
            nextRookieId = rookieId + 1;

            if (repeatDic.ContainsKey(rookieId))
                continue;

            if (dataService.IsRookieShowed(rookieId))
            {
                repeatDic.Add(rookieId, 0);
                continue;
            }

            var rookieModel = configService.RookieConfig[rookieId];
            if (rookieModel.pre_rookie != 0 && !dataService.IsRookieShowed(rookieModel.pre_rookie))
                continue;

            if (rookieModel.triggerLevel != null && (nowLv < rookieModel.triggerLevel.Item1 || nowLv > rookieModel.triggerLevel.Item2))
                continue;

            if (!CheckTriggerParam(rookieModel))
            {
                continue;
            }

            //Transform targetView = null;
            bool trigger = false;
            switch (rookieModel.rookieType)
            {
                case RookieModel.RookieType.Click:
                    RookieClickModel rookieClickModel = configService.RookieClickConfig[rookieModel.sub_id];
                    trigger = CheckTriggerClick(rookieClickModel, rookieModel.repeat);
                    break;
                case RookieModel.RookieType.Dialogue:
                    RookieDialogueDicModel dialogueDicModel = dialogueConfigDic[rookieModel.sub_id];
                    trigger = CheckTriggerDialogue(rookieId, dialogueDicModel);
                    break;
                case RookieModel.RookieType.Drag:
                    RookieDragModel rookieDragModel = configService.RookieDragConfig[rookieModel.sub_id];
                    trigger = CheckTriggerDrag(rookieId, rookieDragModel);
                    break;
                case RookieModel.RookieType.Anim:
                    RookieAnimModel rookieAnimModel = configService.RookieAnimConfig[rookieModel.sub_id];
                    trigger = CheckTriggerAnim(rookieId, rookieAnimModel);
                    break;
            }

            if (trigger)
            {
                currentRookieId = rookieId;
                Debug.Log("触发引导..................." + rookieId+"  time="+Time.time);
                CheckRemoveTriggerItem(rookieModel.triggerParam);
                repeatDic.Add(rookieModel.id, rookieModel.repeat);
                break;
            }
        }

        foreach (var item in repeatDic)
        {
            if (repeatDic[item.Key] == 0)
                continue;

            repeatDic[item.Key] -= Time.deltaTime;
            if (repeatDic[item.Key] <= 0)
            {
                repeatDic.Remove(item.Key);
                break;
            }
        }
    }



    //public void Test()
    //{
    //    RookieDialogueDicModel dialogueDicModel = dialogueConfigDic[201];
    //    CheckTriggerDialogue(1, dialogueDicModel);
    //}



    private bool CheckTriggerParam(RookieModel rookieModel)
    {
        if(rookieModel.triggerParam == null)
        {
            return true;
        }
        foreach(var param in rookieModel.triggerParam)
        {
            if (!CheckTriggerParamSingle(rookieModel, param.Key, param.Value))
            {
                return false;
            }
            
        }
        return true;
    }

    

    private bool CheckTriggerParamSingle(RookieModel rookieModel,string key,int value)
    {
        switch (key)
        {
            case "level_complete":
                return dataService.MaxLevel > value;
            case "box_own":
                int boxNum = dataService.GetUnPutLevelBoxNumber();
                return boxNum > 0;
            case "order_complete":
                bool orderComplete = dataService.CheckMergeRookieOrder();
                if (orderComplete)
                {
                    if (!delayDic.ContainsKey(key))
                    {
                        //派发移动镜头事件
                        RookieClickModel rookieClickModel = configService.RookieClickConfig[rookieModel.sub_id];
                        int itemId = int.Parse(rookieClickModel.pams[1]);
                        MergeItem mergeItem = GetMergeItemById(itemId);
                        MoveCameraToGridEvent evt = new MoveCameraToGridEvent(mergeItem.GridId, 1f);
                        TypeEventSystem.Send<MoveCameraToGridEvent>(evt);
                    }
                    return CheckDelayComplete(key,1.1f);
                }
                return false;
            case "cloud_unlock":
                return CheckDelayComplete(key,2f);
            default:
                if (triggerItemDic.ContainsKey(key))
                {
                    return triggerItemDic[key] == value;
                }
                return false;
        }
    }

    //判断延时是否完成
    private bool CheckDelayComplete(string key,float delay)
    {
        if (!delayDic.ContainsKey(key))
        {
            delayDic.Add(key, Time.time + delay);
        }
        if (Time.time >= delayDic[key])
        {
            delayDic.Remove(key);
            return true;
        }
        return false;
    }


    //清除单次触发的事件
    private void CheckRemoveTriggerItem(Dictionary<string, int> triggerParamDic)
    {
        if (triggerParamDic == null)
        {
            return;
        }
        foreach (var param in triggerParamDic)
        {
            switch(param.Key)
            {
                case "level_complete":
                case "box_own":
                case "order_complete":
                case "cloud_unlock":
                    break;
                default:
                    RemoveTriggerItem(param.Key);
                    break;
            }
        }
    }

    private void RemoveTriggerItem(string key)
    {
        if (triggerItemDic.ContainsKey(key))
        {
            triggerItemDic[key] = 0;
        }
    }



    private bool CheckTriggerClick(RookieClickModel rookieModel, float repeat)
    {
        bool trigger = false;
        Transform targetView = null;
        switch (rookieModel.scene)
        {
            case RookieClickModel.TriggerScene.Battle:
                if (UIPopup.AnyPopupVisible)
                    break;
                if (GameCommon.IsShowSpeialCardTiping)
                    break;
                if (CheckCard(rookieModel) || CheckRule(rookieModel, repeat) || CheckGrid(rookieModel))
                    trigger = true;
                break;

            case RookieClickModel.TriggerScene.View:
                if (UIPopup.AnyPopupVisible)
                    break;
                var viewName = rookieModel.nodyName;
                List<UIView> list = UIView.GetViews(Doozy.Engine.UI.Base.NamesDatabase.GENERAL, viewName);
                if (list.Count != 0)
                {
                    var view = list[0];
                    targetView = view != null ? view.transform : null;
                    if (!CheckViewRookieAble(targetView, rookieModel))
                        break;
                    trigger = targetView.gameObject.activeSelf && CheckWidget(targetView, rookieModel);
                }
                else
                {
                    if (CheckIsGameView(viewName))
                        break;
                    var views = UIView.GetViews(Doozy.Engine.UI.Base.NamesDatabase.GENERAL, viewName);
                    if (views.Count > 0)
                    {
                        var view = UIView.GetViews(Doozy.Engine.UI.Base.NamesDatabase.GENERAL, viewName)[0];
                        targetView = view != null ? view.transform : null;
                        if (!CheckViewRookieAble(targetView, rookieModel))
                            break;
                        trigger = targetView.gameObject.activeSelf && CheckWidget(targetView, rookieModel);
                    }
                }
                break;

            case RookieClickModel.TriggerScene.Popue:
                if (UIPopupManager.PopupQueue.Count <= 0) break;
                var popName = rookieModel.nodyName;
                UIPopupQueueData topPopup = UIPopupManager.PopupQueue.Last();
                if (topPopup?.PopupName != popName) break;
                var popue = BoxBuilder.GetPopup(popName);
                if (popue != null && popue.IsHidden || popue.IsShowing) break;
                targetView = popue.transform;
                trigger = targetView.gameObject.activeSelf && CheckWidget(targetView, rookieModel);
                break;
        }
        return trigger;
    }

    private bool CheckTriggerDialogue(int rookieId, RookieDialogueDicModel dialogueDicModel)
    {
        GlobalRes.DynamicLoadView(Constants.DoozyView.Dialogue, () =>
        {
            RookieTriggerBeginEvent t = GameObjManager.Instance.PopClass<RookieTriggerBeginEvent>(true);
            t.Init2(rookieId, dialogueDicModel);
            TypeEventSystem.Send<RookieTriggerBeginEvent>(t);

        });
        return true;
    }

    private bool CheckTriggerDrag(int rookieId, RookieDragModel rookieDragModel)
    {
        List<GameObject> objs = GetMergeObjs(rookieDragModel);//
        if (objs == null || objs.Count < 2)
        {
            return false;
        }
        // MergeGameController.Instance.SetTouchAble(false);
        RookieTriggerBeginEvent t = GameObjManager.Instance.PopClass<RookieTriggerBeginEvent>(true);
        t.Init3(rookieId, rookieDragModel, objs);
        TypeEventSystem.Send<RookieTriggerBeginEvent>(t);
        return true;
    }

    private bool CheckTriggerAnim(int rookieId, RookieAnimModel rookieAnimModel)
    {
        RookieTriggerBeginEvent t = GameObjManager.Instance.PopClass<RookieTriggerBeginEvent>(true);
        t.Init4(rookieId, rookieAnimModel);
        TypeEventSystem.Send<RookieTriggerBeginEvent>(t);
        return true;
    }


    private List<GameObject> GetMergeObjs(RookieDragModel rookieDragModel)
    {
        MergeItem startItem = GetMergeItemByGrid(rookieDragModel.start_id);
        if (startItem == null)
        {
            return null;
        }
        MergeItem endItem = GetMergeItemByGrid(rookieDragModel.end_ids[0]);
        if (endItem == null)
        {
            return null;
        }

        List<GameObject> objs = new List<GameObject>();
        objs.Add(startItem.gameObject);
        objs.Add(endItem.gameObject);
        return objs;
    }


    private MergeItem GetMergeItemByGrid(int gridId)
    {
        MergeItem[] items = GetItems();
        if (items == null)
        {
            return null;
        }
        MergeItem mergeItem;
        for (int i = 0; i < items.Length; i++)
        {
            mergeItem = items[i];
            if (mergeItem.GridId == gridId)
            {
                return mergeItem;
            }
        }
        return null;
    }

    private MergeItem GetMergeItemById(int itemId)
    {
        MergeItem[] items = GetItems();
        if (items == null)
        {
            return null;
        }
        MergeItem mergeItem;
        for (int i = 0; i < items.Length; i++)
        {
            mergeItem = items[i];
            if (mergeItem.GetItemId() == itemId)
            {
                return mergeItem;
            }
        }
        return null;
    }

    private MergeItem[] GetItems()
    {
        if (MergeGameController.Instance == null)
        {
            return null;
        }
        Transform transform = MergeGameController.Instance.transform;
        MergeItem[] items = transform.GetComponentsInChildren<MergeItem>(false);
        if (items == null || items.Length == 0)
        {
            return null;
        }
        return items;
    }










    //�����Զ�����GameView
    bool CheckIsGameView(string viewName)
    {
        return viewName == Constants.DoozyView.Game;
    }

    bool CheckViewRookieAble(Transform targetView, RookieClickModel rookieModel)
    {
        if (rookieModel.nodyName == "Home")
        {
            return targetView.GetComponent<HomeView>().RookieAble;
        }
        return true;
    }

    bool CheckWidget(Transform targetView, RookieClickModel rookieModel)
    {
        if (rookieModel.pams.Length > 0)
        {
            var specailRule = rookieModel.pams[0];
            switch (specailRule)
            {
                case "wild":
                    if (GameController.Instance.BattleCtrl == null ||
                        !GameController.Instance.BattleCtrl.RookieFunc_JokerCard())
                        return false;
                    break;
                case "undo":
                    if (GameController.Instance.BattleCtrl == null ||
                        !GameController.Instance.BattleCtrl.RookieFunc_Undo())
                        return false;
                    break;
                case "buycard":
                    if (GameController.Instance.BattleCtrl == null ||
                        !GameController.Instance.BattleCtrl.RookieFunc_BuyCard())
                        return false;
                    break;
                case "combo":
                    if (GameController.Instance.BattleCtrl == null)
                        return false;
                    break;
                case "SameColorCombo":
                    if (GameController.Instance.BattleCtrl == null ||
                        !GameController.Instance.BattleCtrl.RookieFunc_MatchLastSameColorGuide())
                        return false;
                    break;
                    // case "betx4":
                    //     if (dataService.NowBet != 2)
                    //         return false;
                    // break;
            }
        }

        Transform tarGo = targetView.Find(rookieModel.widgetName);
        if (tarGo != null)
        {
            var go = tarGo.gameObject;
            if (!go.activeInHierarchy)
                return false;
            if (go.GetComponent<Button>() != null && !go.GetComponent<Button>().interactable)
                return false;

            Rect touchRect = GetComponent<RectTransform>().rect;
            touchRect.x = touchRect.y = 0;
            // if(rookieModel.force)
            // {
            touchRect = TransformUtils.GetUIRect(go.GetComponent<RectTransform>(), UICanvas.MasterCanvas.Canvas);
            // }
            touchRect.x -= Screen.width/2;
            touchRect.y -= Screen.height/2;
            var pos = go.transform.position;

            RookieTriggerBeginEvent t = GameObjManager.Instance.PopClass<RookieTriggerBeginEvent>(true);
            t.Init(rookieModel.id, pos, touchRect);
            TypeEventSystem.Send<RookieTriggerBeginEvent>(t);
        }

        return tarGo != null;
    }


    bool CheckRule(RookieClickModel rookieModel, float repeat)
    {
        if (GameController.Instance.BattleCtrl == null)
            return false;

        string ruleType = rookieModel.pams[0];
        GameObject target = null;
        Rect touchRect = new Rect();
        switch (ruleType)
        {
            case "click_desk":
                //var repeat = rookieModel.repeat;
                target = GameController.Instance.BattleCtrl.RookieFunc_GetBingoCard(repeat);
                break;

            case "click_stack":
                target = GameController.Instance.BattleCtrl.RookieFunc_GetHandCard();
                break;
        }

        if (target != null)
        {
            touchRect = GetComponent<RectTransform>().rect;
            touchRect.x = touchRect.y = 0;
            // if(rookieModel.force)
            // {
            var box2d = target.GetComponentInChildren<BoxCollider2D>();
            Vector2 pos = Camera.main.WorldToScreenPoint(target.transform.position);
            // var screenpos = Camera.main.WorldToScreenPoint(target.transform.position);
            // RectTransformUtility.ScreenPointToLocalPointInRectangle(UICanvas.MasterCanvas.Canvas.transform as RectTransform,
            //  screenpos, Camera.main, out pos);

            touchRect.x = pos.x - Screen.width/2;
            touchRect.y = pos.y - Screen.height/2;
            touchRect.width = box2d.size.x;
            touchRect.height = box2d.size.y;
            // }

            RookieTriggerBeginEvent t = GameObjManager.Instance.PopClass<RookieTriggerBeginEvent>(true);
            t.Init(rookieModel.id, target.transform.position, touchRect);
            TypeEventSystem.Send<RookieTriggerBeginEvent>(t);
            rookieCard = target.GetComponent<BaseCard>();
        }

        return target != null;
    }

    private bool CheckCard(RookieClickModel rookieModel)
    {
        if (GameController.Instance.BattleCtrl == null) return false;

        string thisPam = rookieModel.pams[0];
        GameObject target = null;
        switch (thisPam)
        {
            case "MatchSameColorCombo":
                // GameCombo gameCombo = GameController.Instance.BattleCtrl.gameCombo;
                // if (gameCombo?.IsAllSame() != true) break;
                // if (gameCombo.NowListNum != gameCombo.NowComboStep - 1) break;
                target = GameController.Instance.BattleCtrl.RookieFunc_GetMatchSameColorComboCard();
                break;
            default:
                target = GameController.Instance.BattleCtrl.RookieFunc_GetCard(thisPam);
                break;
        }

        if (target != null)
        {
            Rect touchRect = GetComponent<RectTransform>().rect;
            touchRect.x = touchRect.y = 0;
            // if(rookieModel.force)
            // {
            var box2d = target.GetComponentInChildren<BoxCollider2D>();
            // var screenpos = Camera.main.WorldToScreenPoint(target.transform.position);
            // RectTransformUtility.ScreenPointToLocalPointInRectangle(UICanvas.MasterCanvas.Canvas.transform as RectTransform,
            //     screenpos, Camera.main, out Vector2 pos);
            
            Vector2 pos = Camera.main.WorldToScreenPoint(target.transform.position); 
            touchRect.x = pos.x - Screen.width/2;
            touchRect.y = pos.y - Screen.height/2;
            touchRect.width = box2d.size.x;
            touchRect.height = box2d.size.y;
            // }
            RookieTriggerBeginEvent t = GameObjManager.Instance.PopClass<RookieTriggerBeginEvent>(true);
            t.Init(rookieModel.id, target.transform.position, touchRect);
            TypeEventSystem.Send<RookieTriggerBeginEvent>(t);
            rookieCard = target.GetComponent<BaseCard>();
        }

        return target != null;
    }

    private bool CheckGrid(RookieClickModel rookieModel)
    {
        string thisPam = rookieModel.pams[0];
        MergeItem target;
        if (thisPam == "grid") {
            int gridId = int.Parse(rookieModel.pams[1]);
            target = GetMergeItemByGrid(gridId);
        }
        else if (thisPam == "item")
        {
            int itemId = int.Parse(rookieModel.pams[1]);
            target = GetMergeItemById(itemId);
        }
        else
        {
            return false;
        }
        if (target != null)
        {
            RookieItem rookieItem = target.gameObject.GetComponent<RookieItem>();
            if (rookieItem == null)
            {
                rookieItem = target.gameObject.AddComponent<RookieItem>();
            }
            if (rookieItem.staticTime < 0.5f)
            {
                return false;
            }
            Rect touchRect = GetComponent<RectTransform>().rect;
            touchRect.x = touchRect.y = 0;

            // var screenpos = Camera.main.WorldToScreenPoint(target.transform.position);
            // RectTransformUtility.ScreenPointToLocalPointInRectangle(UICanvas.MasterCanvas.Canvas.transform as RectTransform,
            //     screenpos, Camera.main, out Vector2 pos);

            Vector2 pos = Camera.main.WorldToScreenPoint(target.transform.position); 
            touchRect.x = pos.x - Screen.width / 2;
            touchRect.y = pos.y - Screen.height / 2;
            touchRect.width = 100;
            touchRect.height = 100;
            
            RookieTriggerBeginEvent t = GameObjManager.Instance.PopClass<RookieTriggerBeginEvent>(true);
            t.Init(rookieModel.id, target.transform.position, touchRect);
            TypeEventSystem.Send<RookieTriggerBeginEvent>(t);
        }

        return target != null;
    }


    public class RookieItem : MonoBehaviour
    {
        public float staticTime = 0;
        private Vector3 lastPos;

        private void OnEnable()
        {
            staticTime = 0;
            lastPos = transform.position;
        }
        private void Update()
        {
            if (transform.position == lastPos)
            {
                staticTime += Time.deltaTime;
            }
            else
            {
                staticTime = 0;
            }
            lastPos = transform.position;
        }
    }




}
