using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using Doozy.Engine.Extensions;
using Newtonsoft.Json;
using OBBUtils;
using UnityEngine;
using SoliUtils;

[Serializable]
public class CardData : ICloneable
{
    [SerializeField] public int id;
    [SerializeField] public int FromId = -1; //来源，-1是关卡布局，-2是combo, -3是买牌, -4是道具牌, -5是兔子连胜活动牌
    [SerializeField] private int round = 0;
    [SerializeField] public CardModel cm;
    [SerializeField] public OBB obb;
    [SerializeField] private int value = -1;
    [SerializeField] private int value2 = -1;

    [SerializeField] public bool IsLocked;
    [SerializeField] public bool IsFaceup;
    [SerializeField] private bool hasIce;
    [SerializeField] public int clothTimer;
    [SerializeField] public bool clothOpen = false;
    [SerializeField] private bool hasBird;
    [SerializeField] private readonly int BirdInterval = 3;
    [SerializeField] private int birdInterval = 3;
    [SerializeField] public int WaterTotal { get; private set; }
    [SerializeField] public int WaterNumber { get; private set; }
    [SerializeField] private bool hasBomb;
    [SerializeField] private int bombTimer = 0;
    [SerializeField] private bool hasBigBomb;
    [SerializeField] private int bigBombTimer = 0;
    [SerializeField] private bool hasLightning;
    [SerializeField] private int lightningTimer = 0;

    [SerializeField] public Dictionary<int, int> SuitRopeSuits = new Dictionary<int, int>();
    [SerializeField] public Dictionary<int, bool> SuitRopeStates = new Dictionary<int, bool>();
    [SerializeField] private bool hasLizard;
    [SerializeField] private bool hasTask;

    public void PrintInfo()
    {
        Debug.Log($"CardData <color=cyan>id={id}, value={Value} </color>");
    }

    public object Clone()
    {
        var newOne = new CardData();
        newOne.id = this.id;
        newOne.FromId = this.FromId;
        newOne.round = this.round;
        newOne.cm = this.cm.DeepCopy();
        newOne.obb = this.obb;
        newOne.value = this.value;
        newOne.value2 = this.value2;
        newOne.IsLocked = this.IsLocked;
        newOne.IsFaceup = this.IsFaceup;
        newOne.hasIce = this.hasIce;
        newOne.clothTimer = this.clothTimer;
        newOne.clothOpen = this.clothOpen;
        newOne.hasBird = this.hasBird;
        newOne.birdInterval = this.birdInterval;
        newOne.WaterTotal = this.WaterTotal;
        newOne.WaterNumber = this.WaterNumber;
        newOne.hasBomb = this.hasBomb;
        newOne.bombTimer = this.bombTimer;
        newOne.hasBigBomb = this.hasBigBomb;
        newOne.bigBombTimer = this.bigBombTimer;
        newOne.hasLightning = this.hasLightning;
        newOne.lightningTimer = this.lightningTimer;
        newOne.SuitRopeSuits = new Dictionary<int, int>();
        foreach (var item in this.SuitRopeSuits)
        {
            newOne.SuitRopeSuits.Add(item.Key, item.Value);
        }
        newOne.SuitRopeStates = new Dictionary<int, bool>();
        foreach (var item in this.SuitRopeStates)
        {
            newOne.SuitRopeStates.Add(item.Key, item.Value);
        }
        newOne.hasLizard = this.hasLizard;
        newOne.hasTask = this.hasTask;
        return newOne;
    }

    public CardData()
    {

    }

    public CardData Copy()
    {
        return Clone() as CardData;
    }

    public CardData(int _id, CardModel _cm, OBB _obb = null)
    {
        id = _id;
        round = 0;

        cm = _cm == null ? new CardModel(id) : _cm;
        obb = _obb;
        value = cm.GetValue();
        value2 = cm.GetValue2();
        IsFaceup = cm.faceUp;
        hasIce = cm.HasIce();
        IsLocked = false;
        clothTimer = 0;
        clothOpen = false;
        hasBird = false;
        birdInterval = BirdInterval;
        WaterNumber = 0;
        WaterTotal = 0;
        SuitRopeSuits.Clear();
        SuitRopeStates.Clear();

        if (cm.HasSuitRope())
        {
            var suits = GetSuitRopeSuits();
            for (int i = 0; i < suits.Count; i++)
            {
                SuitRopeSuits.Add(i, suits[i]);
                SuitRopeStates.Add(i, false);
            }
        }

        if (cm.HasCloth())
        {
            clothOpen = cm.GetClothOpen(ModifierType.Cloth);
            clothTimer = clothOpen ? 0 : cm.GetClothTimer(ModifierType.Cloth);
        }

        if (cm.HasMagicCloth())
        {
            clothOpen = cm.GetClothOpen(ModifierType.MagicCloth);
            clothTimer = clothOpen ? 0 : cm.GetClothTimer(ModifierType.MagicCloth);
        }

        hasBomb = cm.HasBomb();
        if (hasBomb)
        {
            bombTimer = cm.BombTimer;
        }

        hasBigBomb = cm.HasBigBomb();
        if (hasBigBomb)
        {
            bigBombTimer = cm.BigBombTimer;
        }

        hasLightning = cm.HasLightning();
        if (hasLightning)
        {
            lightningTimer = cm.LightningTimer;
        }

        hasLizard = cm.HasLizard();

        hasTask = cm.HasTask();
    }

    public static OBB CreateObb(CardModel cm, float cardWidth, float cardHeight)
    {
        var obb = new OBB();
        obb.Pos = new Vec3(cm.x, cm.y, 0);
        obb.Half_size = new Vec3(cardWidth / 2, cardHeight / 2, 0);
        obb.AxisX = new Vec3(1, 0, 0);
        obb.AxisY = new Vec3(0, 1, 0);
        obb.AxisZ = new Vec3(0, 0, 1);

        var arcAngle = cm.angle * 3.14f / 180.0f;
        obb.AxisX = new Vec3(obb.AxisX.X * Mathf.Cos(arcAngle) - obb.AxisX.Y * Mathf.Sin(arcAngle),
                    obb.AxisX.X * Mathf.Sin(arcAngle) + obb.AxisX.Y * Mathf.Cos(arcAngle),
                    0);
        obb.AxisY = new Vec3(obb.AxisY.X * Mathf.Cos(arcAngle) - obb.AxisY.Y * Mathf.Sin(arcAngle),
                    obb.AxisY.X * Mathf.Sin(arcAngle) + obb.AxisY.Y * Mathf.Cos(arcAngle),
                    0);
        return obb;
    }

    public void AddRound()
    {
        if (!IsLocked)
        {
            if (HasRising())
            {
                this.value = (this.value + 1) % Constants.ValueCardCount52;
                BattleDataMgr.Instance.AddRenderCommand(new RisingUpdateCommand(new List<CardData>() { this }));
            }
            if (HasLowering())
            {
                this.value = ((this.value - 1) + Constants.ValueCardCount52) % Constants.ValueCardCount52;
                BattleDataMgr.Instance.AddRenderCommand(new LoweringUpdateCommand(new List<CardData>() { this }));
            }
            if (HasBomb() && bombTimer > 0)
            {
                bool trigger = UpdateBomb();
                BattleDataMgr.Instance.AddRenderCommand(new BombUpdateCommand(new List<CardData>() { this }));
                if (trigger)
                {
                    hasBomb = false;
                    BattleDataMgr.Instance.DoBomb(this);
                }
            }
            if (HasBigBomb())
            {
                bool trigger = UpdateBigBomb();
                if (trigger)
                {
                    hasBigBomb = false;
                    BattleDataMgr.Instance.DoBigBomb(this);
                }
                else
                {
                    BattleDataMgr.Instance.AddRenderCommand(new BigBombUpdateCommand(new List<CardData>() { this }));
                }
            }
            if (HasCloth())
            {
                UpdateClothSwitchRound();
                BattleDataMgr.Instance.AddRenderCommand(new ClothRoundUpdateCommand(new List<CardData>() { this }));
            }
            if (HasMagicCloth())
            {
                UpdateClothSwitchRound();
                if (IsClothOpen())
                {
                    this.value = BattleDataMgr.Instance.GenDeskCardValue(id);
                }
                BattleDataMgr.Instance.AddRenderCommand(new ClothRoundUpdateCommand(new List<CardData>() { this }));
            }
            if (HasLightning())
            {
                bool trigger = UpdateLightningTimer();
                BattleDataMgr.Instance.AddRenderCommand(new LightningUpdateCommand(new List<CardData>() { this }));
                if (trigger)
                {
                    BattleDataMgr.Instance.DoLightning(this);
                }
            }
            round++;
        }
    }


    public void SubRound()
    {
        if (!IsLocked)
        {
            // if (HasRising())
            // {
            //     this.value = ((this.value - 1) + Constants.ValueCardCount52) % Constants.ValueCardCount52;
            //     BattleDataMgr.Instance.AddRenderCommand(new RisingUpdateCommand(new List<CardData>() { this }));
            // }
            // if (HasLowering())
            // {
            //     this.value = (this.value + 1) % Constants.ValueCardCount52;
            //     BattleDataMgr.Instance.AddRenderCommand(new LoweringUpdateCommand(new List<CardData>() { this }));
            // }
            // if (HasCloth())
            // {
            //     UpdateClothSwitchRound(true);
            //     BattleDataMgr.Instance.AddRenderCommand(new ClothRoundUpdateCommand(new List<CardData>() { this }));
            // }
            // if (HasMagicCloth())
            // {
            //     UpdateClothSwitchRound(true);
            //     BattleDataMgr.Instance.AddRenderCommand(new ClothRoundUpdateCommand(new List<CardData>() { this }));
            // }
            round--;
        }
    }

    public CardType CardType
    {
        get { return cm.cardType; }
    }

    public int Value
    {
        get
        {
            if (value == -1)
            {
                value = cm.GetValue();
            }
            return value;
        }

        set
        {
            this.value = value;
        }
    }

    public int Value2
    {
        get
        {
            if (value2 == -1)
            {
                value2 = cm.GetValue();
            }
            return value2;
        }

        set
        {
            this.value2 = value;
        }
    }

    public bool IsTopCard()
    {
        return BattleDataMgr.Instance.CheckTopCard(this);
    }

    public int? GetCardSuit()
    {
        return cm.cardType switch
        {
            CardType.Value => Value / Constants.ValueCardCount13,
            CardType.Gold => cm.suit,
            CardType.TwoValue => Value / Constants.ValueCardCount13,
            CardType.Monochrome => cm.suit,
            CardType.Rudder => cm.suit,
            _ => null,
        };
    }

    public bool GetCardColor()
    {
        var suit = GetCardSuit();
        return suit == 1 || suit == 3;
    }

    public bool HasBomb()
    {
        return hasBomb;
    }

    public bool HasBigBomb()
    {
        return hasBigBomb;
    }

    public bool HasIce()
    {
        if (!cm.HasIce())
            return false;

        return hasIce;
    }

    public void BreakIce()
    {
        hasIce = false;
    }

    public void UndoBreakIce()
    {
        hasIce = true;
    }

    public bool HasSuitRope()
    {
        if (!cm.HasSuitRope())
            return false;

        foreach (var st in SuitRopeStates)
        {
            if (!st.Value)
                return true;
        }
        return false;
    }

    public bool CheckSuitRope(int suit)
    {
        for (int i = 3; i >= 0; i--)
        {
            if (SuitRopeSuits.ContainsKey(i))
            {
                if (SuitRopeStates[i] == false && SuitRopeSuits[i] == suit)
                {
                    SuitRopeStates[i] = true;
                    return true;
                }
            }
        }
        return false;
    }

    public void RemoveOneRopeSuit()
    {
        for (int i = 3; i >= 0; i--)
        {
            if (SuitRopeSuits.ContainsKey(i))
            {
                if (SuitRopeStates[i] == false)
                {
                    SuitRopeStates[i] = true;
                    break;
                }
            }
        }
    }

    public bool HasLinkRope()
    {
        return cm.HasLinkRope();
    }

    public bool CanRemoveLinkRope()
    {
        return cm.HasLinkRope() && BattleDataMgr.Instance.CanRemoveLinkRope(id);
    }

    public int GetLinkRopeCardId()
    {
        return cm.LinkRopeCardId;
    }

    public bool HasLowering()
    {
        return cm.HasLowering();
    }

    public bool HasRising()
    {
        return cm.HasRising();
    }

    public bool HasCloth()
    {
        return cm.HasCloth();
    }

    public bool HasMagicCloth()
    {
        return cm.HasMagicCloth();
    }

    public bool IsClothOpen()
    {
        return clothOpen;
    }

    public int UpdateClothSwitchRound()
    {
        if (clothOpen)
        {
            clothOpen = false;
            if (HasCloth())
            {
                clothTimer = cm.GetClothTimer(ModifierType.Cloth);
            }
            else if (HasMagicCloth())
            {
                clothTimer = cm.GetClothTimer(ModifierType.MagicCloth);
            }
        }
        else
        {
            clothTimer--;
            if (clothTimer == 0)
            {
                clothOpen = true;
            }
        }

        return clothTimer;
    }

    public bool HasGreenLeaf()
    {
        return cm.HasGreenLeaf();
    }

    public bool HasBird()
    {
        return hasBird;
    }

    public void SetBirdState(bool bird)
    {
        hasBird = bird;
        if (hasBird)
        {
            birdInterval = BirdInterval;
        }
    }

    public void UndoUpdateBirdInterval()
    {
        birdInterval = Math.Min(++birdInterval, BirdInterval);
    }

    public bool UpdateBirdInterval()
    {
        birdInterval--;
        return birdInterval <= 0;
    }

    public bool HasWater()
    {
        return cm.HasWater();
    }

    public void SetWaterTotal(int number)
    {
        WaterTotal = number;
        WaterNumber = 0;
    }

    public bool CollectWaterAndBreak()
    {
        WaterNumber++;
        return WaterNumber == WaterTotal;
    }

    public void UndoCollectWater()
    {
        WaterNumber = Math.Max(--WaterNumber, 0);
    }

    public bool HasLightning()
    {
        return hasLightning;
    }

    public bool UpdateBomb(bool undo = false)
    {
        if (undo)
            bombTimer++;
        else
            bombTimer--;
        return bombTimer <= 0;
    }

    public int BombTimer
    {
        get => bombTimer;
    }

    public bool UpdateBigBomb(bool undo = false)
    {
        if (undo)
            bigBombTimer++;
        else
            bigBombTimer--;
        return bigBombTimer <= 0;
    }

    public int BigBombTimer
    {
        get => bigBombTimer;
    }

    public List<int> GetSuitRopeSuits()
    {
        return cm.GetSuitRopeSuits();
    }

    public int LightningTimer
    {
        get => lightningTimer;
    }

    public bool UpdateLightningTimer()
    {
        lightningTimer--;
        if (lightningTimer == 0)
        {
            lightningTimer = cm.LightningInterval;
            return true;
        }
        return false;
    }

    public void SetLightningTimer(int time)
    {
        lightningTimer = time;
    }

    public void RemoveAllModifier()
    {
        hasBomb = false;
        hasBigBomb = false;
        hasLightning = false;
        hasLizard = false;
        hasTask = false;
    }

    public void RecycleBomb()
    {
        hasBomb = true;
    }

    public void RecycleBigBomb()
    {
        hasBigBomb = true;
    }

    public void RecycleLightning()
    {
        hasLightning = true;
    }

    //编辑器用
    public void ResetSuitRope()
    {
        if (cm.HasSuitRope())
        {
            var suits = GetSuitRopeSuits();
            for (int i = 0; i < suits.Count; i++)
            {
                SuitRopeSuits.TryAdd(i, suits[i]);
                SuitRopeStates.TryAdd(i, false);
            }
        }
    }

    public bool HasLizard()
    {
        return hasLizard;
    }

    public bool HasTask()
    {
        return hasTask;
    }

}
