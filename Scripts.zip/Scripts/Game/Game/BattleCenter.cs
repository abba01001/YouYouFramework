using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Activities;
using Doozy.Engine;
using QFramework;
using UnityEngine;
using UniRx;
using SoliUtils;

public enum BattleCommand
{
    StartGame,
    LoseGame,
    WinGame,
    Over
}

public enum BattleState
{
    Unknow = 0,
    Init,
    Render,
    Start,
    Playing,
    End
}

public class BattleCenter : ISingleton
{
    public BattleState BattleState;
    private BattleConfig battleConfig;
    private bool reported = false;
    private int timer;

    public static BattleCenter Instance
    {
        get { return SingletonProperty<BattleCenter>.Instance; }
    }

    public void OnSingletonInit()
    {
        TypeEventSystem.Register<BattleCommandEvent>(OnBattleCommandEvent);
        TypeEventSystem.Register<TouchCardEvent>(OnTouchCardEvent);
        TypeEventSystem.Register<OperatCommandEvent>(OnOperatCommandEvent);
        TypeEventSystem.Register<RenderCommandEvent>(OnRenderCommandEvent);
    }

    private void Dispose()
    {
        TypeEventSystem.UnRegister<BattleCommandEvent>(OnBattleCommandEvent);
        TypeEventSystem.UnRegister<TouchCardEvent>(OnTouchCardEvent);
        TypeEventSystem.UnRegister<OperatCommandEvent>(OnOperatCommandEvent);
        TypeEventSystem.UnRegister<RenderCommandEvent>(OnRenderCommandEvent);
    }

    BattleCenter()
    {

    }

    public void Init()
    {
        Debug.Log("BattleCenter.Init");
    }


    public void Clean()
    {
        BattleState = BattleState.Unknow;
        BattleDataMgr.Instance.Clean();
        BattleViewMgr.Instance.Clean();
        battleConfig = null;
    }

    private void OnBattleCommandEvent(BattleCommandEvent e)
    {
        switch (e.command)
        {
            case BattleCommand.StartGame:
                battleConfig = e.battleConfig;
                BattleState = BattleState.Init;
                timer = TimeUtils.UtcNow();
                break;

            case BattleCommand.LoseGame:
            case BattleCommand.WinGame:
                BattleState = BattleState.End;
                GameCommon.SetGameFinish(e.command == BattleCommand.WinGame, TimeUtils.UtcNow() - timer);
                TypeEventSystem.Send<EndGameEvent>(new EndGameEvent(battleConfig));
                if(!GameUtils.IsSpecialLevel()) ActivityManager.Instance.CheckOpenActivity(e.command == BattleCommand.WinGame);
                Clean();
                break;
        }
    }

    private void OnTouchCardEvent(TouchCardEvent e)
    {
        if (BattleViewMgr.Instance.IsRenderBlock())
            return;
        if (BattleDataMgr.Instance.IsTopHandCard(e.cardId) && BattleViewMgr.Instance.IsHandCardAdding())
            return;
        BattleDataMgr.Instance.TouchCard(e.cardId);

        if (battleConfig.levelId == 1 && !reported)
        {
            WeChatMiniGame.ReportCreateRole();
            var msg = new Dictionary<string, object>{};
            AnalyticUtils.ReportEvent(AnalyticsKey.SoliCreateRole, msg);
            reported = true;
        }
    }

    private void OnOperatCommandEvent(OperatCommandEvent e)
    {
        if (GameCommon.IsAiMode)
            return;
        BattleViewMgr.Instance.AddRenderCommand(e.operation.RenderQueue);
    }

    private void OnRenderCommandEvent(RenderCommandEvent e)
    {
        if (GameCommon.IsAiMode)
            return;
        BattleViewMgr.Instance.AddRenderCommand(e.renderCmd);
    }

    public void OnUndoEvent()
    {
        BattleDataMgr.Instance.UseUndo();
    }

    public void OnJokerEvent()
    {
        BattleDataMgr.Instance.UseJoker();
    }

    public void OnBuyCardsEvent(int useTime)
    {
        BattleDataMgr.Instance.BuyCards(useTime);
    }

    public void Update()
    {
        ReceiveInput();
        Running();
        BattleViewMgr.Instance.Render();
    }

    private void ReceiveInput()
    {
        if (BattleState == BattleState.Unknow)
            return;
    }

    private void Running()
    {
        if (BattleState == BattleState.Unknow)
            return;

        switch (BattleState)
        {
            case BattleState.Init:
                BattleState = BattleState.Render;
                BattleDataMgr.Instance.LoadGame(battleConfig);
                if (BattleDataMgr.Instance.IsFinish && !BattleViewMgr.Instance.IsRendering())
                {
                    BattleState = BattleState.End;
                }
                break;

            case BattleState.Render:
                break;

            case BattleState.End:
                break;

        }
    }

}
