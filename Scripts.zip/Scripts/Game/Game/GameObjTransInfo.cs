using UnityEngine;

public class GameObjTransInfo
{
    public static readonly Vector3Int HandCardInterval = new Vector3Int(-12, 0, 0);
    public static readonly Vector3Int OpenCardPos = new Vector3Int(65, -299, -300);
    public static readonly Vector3Int HandPos = new Vector3Int(-80, -299, -100);
    public static readonly Vector3Int BirdPos = new Vector3Int(500, 800, 99);
    

    public static Vector3 ComboAddCardPos;
    public static Vector3 UndoPos;
    public static Vector3 JokerPos;
    public static Vector3 BuyCardsPos;
    public static Transform DefaultScene;
    
}