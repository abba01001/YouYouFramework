using UnityEngine;
using UnityEngine.Tilemaps;

[CreateAssetMenu(fileName = "New Grayscale Tile", menuName = "Tiles/Grayscale Tile")]
public class GrayscaleTile : Tile
{
    public override void GetTileData(Vector3Int position, ITilemap tilemap, ref TileData tileData)
    {
        base.GetTileData(position, tilemap, ref tileData);

        // 将 Tile 的 Sprite 变为灰度
        if (tileData.sprite != null)
        {
            tileData.sprite = ConvertToGrayscale(tileData.sprite);
        }
    }

    // 转换为灰度的函数
    private Sprite ConvertToGrayscale(Sprite originalSprite)
    {
        Texture2D originalTexture = originalSprite.texture;
        Texture2D grayscaleTexture = new Texture2D(originalTexture.width, originalTexture.height);

        // 遍历像素并转换为灰度
        for (int x = 0; x < originalTexture.width; x++)
        {
            for (int y = 0; y < originalTexture.height; y++)
            {
                Color originalColor = originalTexture.GetPixel(x, y);
                float gray = (originalColor.r + originalColor.g + originalColor.b) / 3f;
                grayscaleTexture.SetPixel(x, y, new Color(gray, gray, gray, originalColor.a));
            }
        }

        grayscaleTexture.Apply();
        return Sprite.Create(grayscaleTexture, originalSprite.rect, new Vector2(0.5f, 0.5f), originalSprite.pixelsPerUnit);
    }
}
