using UnityEngine;
using Sirenix.OdinInspector;
using UnityEngine.Tilemaps;
using System.Collections.Generic;
using System.Linq;
using System;


[Serializable]
public class GraphDir
{
    public int up = -1;
    public int down = -1;
    public int left = -1;
    public int right = -1;

    public GraphDir(int up, int down, int left, int right)
    {
        this.up = up;
        this.down = down;
        this.left = left;
        this.right = right;
    }
}

[Serializable]
public class RegionInfo
{
    public int id;
    public int gridId;
}


public class MapMono : MonoBehaviour
{
    [SerializeField]
    public List<int> Keys = new List<int>();
    [SerializeField]
    public List<GraphDir> Values = new List<GraphDir>();
    [SerializeField]
    public List<RegionInfo> RegionStartGridIds = new List<RegionInfo>();

    private Dictionary<int, GraphDir> Graph = new Dictionary<int, GraphDir>();

    
    [SerializeField]
    public TileBase Region1TileAn;
    [SerializeField]
    public TileBase Region1TileLigng;
    [SerializeField]
    public TileBase Region2TileAn;
    [SerializeField]
    public TileBase Region2TileLigng;
    [SerializeField]
    public TileBase GrayTileAn;
    [SerializeField]
    public TileBase GrayTileLiang;

    [Button("生成地图连通性配置")]
    public void CustomButtonFunction()
    {
        Graph.Clear();
        Keys.Clear();
        Values.Clear();
        var gridTilemap = transform.Find("Grid").GetComponent<Tilemap>();
        List<Vector3Int> tiles = new List<Vector3Int>();
        foreach (Vector3Int pos in gridTilemap.cellBounds.allPositionsWithin)
        {
            if (gridTilemap.HasTile(pos))
            {
                tiles.Add(pos);
            }
        }
        tiles = tiles.OrderByDescending(entry => entry.y).ThenByDescending(entry => entry.x).ToList();

        int GetPointNumber(int x, int y)
        {
            int rowNumber = 1000 - y;
            int columnNumber = 1000 - x;
            int number = rowNumber * 2001 + columnNumber + 1;
            return number;
        }

        Dictionary<int, Vector3Int> tileData = new Dictionary<int, Vector3Int>();
        foreach (var pos in tiles)
        {
            tileData.Add(GetPointNumber(pos.x, pos.y), pos);
        }

        foreach (var pair1 in tileData)
        {
            Graph.Add(pair1.Key, new GraphDir(-1, -1, -1, -1));
            foreach (var pair2 in tileData)
            {
                if (pair1.Key != pair2.Key)
                {
                    var pos1 = tileData[pair1.Key];
                    var pos2 = tileData[pair2.Key];
                    var tuple = Graph[pair1.Key];
                    if (pos2.x + 2 == pos1.x && pos2.y - 1 == pos1.y)
                    {
                        Graph[pair1.Key] = new GraphDir(pair2.Key, tuple.down, tuple.left, tuple.right);
                    }
                    else if (pos2.x - 2 == pos1.x && pos2.y + 1 == pos1.y)
                    {
                        Graph[pair1.Key] = new GraphDir(tuple.up, pair2.Key, tuple.left, tuple.right);
                    }
                    else if (pos2.x + 6 == pos1.x && pos2.y == pos1.y)
                    {
                        Graph[pair1.Key] = new GraphDir(tuple.up, tuple.down, pair2.Key, tuple.right);
                    }
                    else if (pos2.x - 6 == pos1.x && pos2.y == pos1.y)
                    {
                        Graph[pair1.Key] = new GraphDir(tuple.up, tuple.down, tuple.left, pair2.Key);
                    }
                }
            }
        }

        foreach (var pair in Graph)
        {
            Keys.Add(pair.Key);
            Values.Add(pair.Value);
        }

        foreach (var regionInfo in RegionStartGridIds)
        {
            Debug.LogError($"================= region id: {regionInfo.id}");
            Dictionary<int, bool> find = new Dictionary<int, bool>();
            List<int> grids = MergeGameController.Instance.GetNearShapeGrids(regionInfo.gridId, 11);
            grids.Insert(0, regionInfo.gridId);
            while (grids.Count > 0)
            {
                List<int> nextGrids = new List<int>();
                foreach (var _gridId in grids)
                {
                    if (_gridId == -1 || find.ContainsKey(_gridId))
                        continue;
                    find.TryAdd(_gridId, true);
                    List<int> _grids = MergeGameController.Instance.GetNearShapeGrids(_gridId, 11);
                    foreach (var id in _grids)
                    {
                        if (id != -1 && !find.ContainsKey(id))
                        {
                            nextGrids.Add(id);
                        }
                    }
                }
                grids = nextGrids;
            }
            var ids = find.Keys.ToList();
            ids.Sort();
            var str = "";
            foreach (var item in ids)
            {
                str += $";{item}";
            }
            Debug.LogError(str);
        }
    }
}

// 创建自定义Editor
// [CustomEditor(typeof(MapTools))]
// public class MapToolsEditor : OdinEditor
// {
//     public override void OnInspectorGUI()
//     {
//         // 绘制默认的Inspector
//         base.OnInspectorGUI();

//         // 添加自定义按钮
//         MapTools prefab = (MapTools)target;
//         if (GUILayout.Button("自定义按钮"))
//         {
//             prefab.CustomButtonFunction(); // 调用Prefab中的方法
//         }
//     }
// }
