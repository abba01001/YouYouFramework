using System;
using System.Collections.Generic;
using DG.Tweening;
using SoliUtils;
using Spine;
using Spine.Unity;
using UniRx;
using UnityEngine;
using UnityEngine.EventSystems;

public class BubbleItem : MonoBehaviour
{
    public int BubbleId;
    private long clickInterval;
    private List<int> items;
    private bool light;
    private GameObject lightFx;
    private bool dispear;
    private float interval;

    public void SetBubbleId(int bubbleId)
    {
        this.BubbleId = bubbleId;
    }

    public void ShowWhite()
    {
        var skel = GetComponentInChildren<SkeletonAnimation>();
        Skeleton skeleton = skel.skeleton;
        Skin newSkin = skeleton.Data.FindSkin("white");
        skeleton.SetSkin(newSkin);
        skeleton.SetSlotsToSetupPose();
        skel.AnimationState.Apply(skeleton);
        skel.state.SetAnimation(0, "paopao_anim", true);
    }

    public void ShowYellow()
    {
        var skel = GetComponentInChildren<SkeletonAnimation>();
        Skeleton skeleton = skel.skeleton;
        Skin newSkin = skeleton.Data.FindSkin("yellow");
        skeleton.SetSkin(newSkin);
        skeleton.SetSlotsToSetupPose();
        skel.AnimationState.Apply(skeleton);
        skel.state.SetAnimation(0, "paopao_anim", true);
    }

    public void ShowItems(List<int> _items = null)
    {
        if (dispear)
            return;
        interval = 3f;
        if (_items != null)
            items = _items;
        int randomIndex = UnityEngine.Random.Range(0, items.Count);
        var itemId = items[randomIndex];
        Transform IconTrans = transform.Get<Transform>("Node/Icon");
        SpriteRenderer itemSprite = IconTrans.Get<SpriteRenderer>("ItemSprite");
        IconTrans.DOKill();
        IconTrans.DOScale(Vector3.one * 0.1f, 0.3f).SetTarget(IconTrans).SetEase(Ease.InOutBounce).OnComplete(() =>
        {
            if (dispear)
                return;
            IconTrans.DOScale(Vector3.one, 0.3f).SetTarget(IconTrans).SetEase(Ease.InOutBounce);
            float targetWidth = 90f;
            float targetHeight = 90f;
            itemSprite.LoadPropSprite(itemId, true, () =>
                {
                    if (dispear)
                        return;
                    float originalWidth = itemSprite.sprite.textureRect.size.x;
                    float originalHeight = itemSprite.sprite.textureRect.size.y;
                    float scaleX = targetWidth / originalWidth;
                    float scaleY = targetHeight / originalHeight;
                    float scaleFactor = Mathf.Min(scaleX, scaleY);
                    itemSprite.transform.localScale = new Vector3(scaleFactor, scaleFactor, 1f);
                });
        });
    }

    void Update()
    {
        if (interval > 0)
        {
            interval -= Time.deltaTime;
        }
        if (interval <= 0)
        {
            ShowItems();
        }
    }

    public async void ShowLight(bool vis)
    {
        light = vis;
        if (!vis)
        {
            if (lightFx != null)
            {
                GameObject.Destroy(lightFx);
                lightFx = null;
            }
            return;
        }
        await GlobalRes.DynamicLoadPrefab($"Assets/Res/Prefabs/FX/tx_MergerGame_10.prefab", (obj) =>
        {
            if (!light)
            {
                GameObject.Destroy(obj);
                return;
            }
            lightFx = obj;
            obj.transform.SetParent(transform);
            obj.transform.localPosition = Vector3.zero;
            obj.SetActive(true);
        });
    }

    public void Dispear()
    {
        dispear = true;
        GameObject.Destroy(gameObject, 0.1f);
    }

    void OnMouseDown()
    {
        if (dispear)
            return;
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }
        clickInterval = TimeUtils.Timestamp();
        ShowLight(false);
    }

    void OnMouseUp()
    {
        if (dispear)
            return;
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }
        clickInterval = TimeUtils.Timestamp() - clickInterval;
        if (clickInterval < 150)
        {
            var dataService = MainContainer.Container.Resolve<IDataService>();
            if (!dataService.OpenMergeBubble(BubbleId))
            {
                BoxBuilder.ShowToast("空间不足");
            }
        }
    }
}
