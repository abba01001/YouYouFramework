using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using QFramework;
using SoliUtils;
using TMPro;
using UniRx;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;

public class CloudItem : MonoBehaviour
{
    private long clickInterval;
    private bool isClickIt;
    private int cloudId;
    private GameObject lockObj;
    private GameObject infoObj;
    private SpriteRenderer proSpr;
    private TextMeshPro proText;

    void Awake()
    {
        TypeEventSystem.Register<UnlockCloudEvent>(OnUnlockCloudEvent);
        TypeEventSystem.Register<FlyBuildExpEvent>(OnFlyBuildExpEvent);
        lockObj = transform.Find("cloud_lock").gameObject;
        lockObj.SetActive(false);
        infoObj = lockObj.transform.Find("info").gameObject;
        proSpr = transform.Get<SpriteRenderer>("cloud_lock/info/pro_img");
        proText = transform.Get<TextMeshPro>("cloud_lock/info/pro_text");
    }

    void OnDestroy()
    {
        TypeEventSystem.UnRegister<UnlockCloudEvent>(OnUnlockCloudEvent);
        TypeEventSystem.UnRegister<FlyBuildExpEvent>(OnFlyBuildExpEvent);
    }

    private void OnUnlockCloudEvent(UnlockCloudEvent e)
    {
        if (e.cloud_id == cloudId)
        {
            Camera.main.transform.DOCurMove(lockObj.transform.position, 0.8f).SetEase(Ease.InSine).OnComplete(() =>
            {
                SpriteRenderer[] sprs = transform.GetComponentsInChildren<SpriteRenderer>();
                foreach (var spr in sprs)
                {
                    Color spriteColor = spr.color;
                    spr.DOColor(new Color(spriteColor.r, spriteColor.g, spriteColor.b, 0), 0.8f);
                }
            });
            GameObject.Destroy(gameObject, 1.7f);
        }
        else if (e.cloud_id + 1 == cloudId)
        {
            Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe((_) =>
            {
                lockObj.SetActive(true);
            });
        }
    }

    private void OnFlyBuildExpEvent(FlyBuildExpEvent e)
    {
        Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe((_) =>
        {
            if (lockObj.activeSelf)
                ShowPro();
        });
    }

    public void SetCloudId(int id)
    {
        cloudId = id;
    }

    public void ShowLock(bool vis)
    {
        lockObj.SetActive(vis);
        if (vis)
        {
            ShowPro();
        }
    }

    void ShowPro()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        int region_id = dataService.GetRegionId();
        var info = dataService.GetRegionInfo(region_id);
        if (info != null)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            int key = region_id * 1000 + info.level;
            int nextKey = key;
            int needExp = 0;
            int nowExp = info.exp;
            if (configService.MergeRegionRewardsConfig.TryGetValue(key, out var cfg))
            {
                if (cfg.cloud_id == 0)
                {
                    while (configService.MergeRegionRewardsConfig.TryGetValue(nextKey, out cfg))
                    {
                        if (cfg.cloud_id > 0)
                        {
                            break;
                        }
                        nextKey--;
                        needExp += cfg.exp;
                        nowExp += cfg.exp;
                    }
                }
            }

            nextKey = key + 1;
            bool flag = false;
            while (configService.MergeRegionRewardsConfig.TryGetValue(nextKey, out cfg))
            {
                needExp += cfg.exp;
                if (cfg.cloud_id > 0)
                {
                    flag = true;
                    break;
                }
                nextKey++;
            }
            if (!flag)
            {
                region_id += 1;
                nextKey = region_id * 1000 + 1;
                while (configService.MergeRegionRewardsConfig.TryGetValue(nextKey, out cfg))
                {
                    needExp += cfg.exp;
                    if (cfg.cloud_id > 0)
                    {
                        break;
                    }
                    nextKey++;
                }
            }

            proText.text = $"{nowExp}/{needExp}";
            var size = proSpr.size;
            proSpr.size = new Vector2(1.8f * (nowExp / (float)needExp), size.y);

            if (nowExp >= needExp)
            {
                ShowLock(false);
            }
        }
    }

    void Update()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }

        if (Input.GetMouseButtonDown(0))
        {
            isClickIt = false;
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            RaycastHit2D[] hits = Physics2D.RaycastAll(mousePos, Vector2.zero);
            foreach (var hit in hits)
            {
                if (hit.collider.gameObject == this.gameObject)
                {
                    clickInterval = TimeUtils.Timestamp();
                    isClickIt = true;
                    break;
                }
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            if (isClickIt)
            {
                Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                RaycastHit2D[] hits = Physics2D.RaycastAll(mousePos, Vector2.zero);
                foreach (var hit in hits)
                {
                    if (hit.collider.gameObject == this.gameObject)
                    {
                        clickInterval = TimeUtils.Timestamp() - clickInterval;
                        if (clickInterval < 150)
                        {
                            for (int i = 0; i < transform.childCount; i++)
                            {
                                var child = transform.GetChild(i);
                                if (child.name != "cloud_lock")
                                {
                                    child.DOKill(true);
                                    var scale = child.localScale;
                                    child.DOPunchScale(new Vector3(0.5f, 0.5f, 0), 0.3f, 1).OnComplete(() =>
                                    {
                                        child.localScale = scale;
                                    }).OnKill(() =>
                                    {
                                        child.localScale = scale;
                                    });
                                }
                            }
                            break;
                        }
                    }
                }
            }
            isClickIt = false;
        }
    }

}
