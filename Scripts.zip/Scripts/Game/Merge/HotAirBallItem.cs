using System;
using System.Collections.Generic;
using DG.Tweening;
using SoliUtils;
using Spine;
using Spine.Unity;
using TMPro;
using UniRx;
using UnityEngine;
using UnityEngine.EventSystems;

public class HotAirBallItem : MonoBehaviour
{
    public int BallId;
    public SkeletonAnimation topAni;
    public SkeletonAnimation bottomAni;
    private long clickInterval;


    public void Show(MergeHotAirBallModel model)
    {
        BallId = model.id;
        var configService = MainContainer.Container.Resolve<IConfigService>();
        if (configService.MergeHotAirBallConfig.TryGetValue(model.cfgId, out var cfg))
        {
            string[] param = cfg.reward.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
            int reward_item_id = int.Parse(param[0]);
            if (configService.MergeItemConfig[reward_item_id].itemType == (int)Constants.MergeItemType.AllMerge)
            {
                Skeleton skeleton = topAni.skeleton;
                Skin newSkin = skeleton.Data.FindSkin("feiji");
                skeleton.SetSkin(newSkin);
                skeleton.SetSlotsToSetupPose();
                topAni.AnimationState.Apply(skeleton);
                topAni.state.SetAnimation(0, "qiqiu_feiji", true);
            }
            else if (configService.MergeItemConfig[reward_item_id].itemType == (int)Constants.MergeItemType.Normal)
            {
                if (cfg.purchase_type == 3)
                {
                    Skeleton skeleton = topAni.skeleton;
                    Skin newSkin = skeleton.Data.FindSkin("purple");
                    skeleton.SetSkin(newSkin);
                    skeleton.SetSlotsToSetupPose();
                    topAni.AnimationState.Apply(skeleton);
                    topAni.state.SetAnimation(0, "qiqiu_purple_ui", true);
                }
                else
                {
                    Skeleton skeleton = topAni.skeleton;
                    Skin newSkin = skeleton.Data.FindSkin("green");
                    skeleton.SetSkin(newSkin);
                    skeleton.SetSlotsToSetupPose();
                    topAni.AnimationState.Apply(skeleton);
                    topAni.state.SetAnimation(0, "qiqiu_green", true);
                }
            }

            SpriteRenderer ItemSprite = transform.Get<SpriteRenderer>("Node/Icon/ItemSprite");
            float targetWidth = 100f;
            float targetHeight = 100f;
            ItemSprite.LoadPropSprite(reward_item_id, true, () =>
                {
                    float originalWidth = ItemSprite.sprite.textureRect.size.x;
                    float originalHeight = ItemSprite.sprite.textureRect.size.y;
                    float scaleX = targetWidth / originalWidth;
                    float scaleY = targetHeight / originalHeight;
                    float scaleFactor = Mathf.Min(scaleX, scaleY);
                    ItemSprite.transform.localScale = new Vector3(scaleFactor, scaleFactor, 1f);
                });


            TextMeshPro timeText = transform.Get<TextMeshPro>("Node/clock/time");
            Observable.Interval(System.TimeSpan.FromSeconds(1))
                .Subscribe(_ =>
                {
                    var now = TimeUtils.UtcNow();
                    var left_second = cfg.time - (now - model.time);
                    if (left_second > 0)
                        timeText.text = $"{left_second / 60:D2}:{left_second % 60:D2}";
                    else
                    {
                        timeText.text = $"00:00";
                        var dataService = MainContainer.Container.Resolve<IDataService>();
                        dataService.CheckHotAirBall();
                    }
                }).AddTo(this);
        }
    }


    void OnMouseDown()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }
        clickInterval = TimeUtils.Timestamp();
    }

    void OnMouseUp()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }
        clickInterval = TimeUtils.Timestamp() - clickInterval;
        if (clickInterval < 150)
        {
            BoxBuilder.ShowHotAirBallPopup(BallId);
        }
    }
}
