using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using SoliUtils;
using TMPro;
using UniRx;
using UnityEngine;
using UnityEngine.Rendering;

public class NpcPaoPao : MonoBehaviour
{

    private List<int> items;
    private bool dispear;
    Sequence seq;
    private int itemIndex = 0;
    private int npcId;


    void Start()
    {

    }

    // public void ShowPaoPao(int npcId, int orderIndex = 0)
    // {
    //     SpriteRenderer bg = transform.Find("paopao_bg").GetComponent<SpriteRenderer>();
    //     SpriteRenderer icon = transform.Find("paopao_icon").GetComponent<SpriteRenderer>();

    //     int sortOrder = orderIndex + 1;
    //     bg.sortingOrder = sortOrder;
    //     icon.sortingOrder = sortOrder + 1;

    //     var dataService = MainContainer.Container.Resolve<IDataService>();
    //     var order = dataService.GetMergeOrder(npcId, out var _);

    //     int processMax = 0;
    //     int processNow = 0;
    //     for (int i = 0; i < order.items.Length; i++)
    //     {
    //         processMax += order.count[i];
    //         processNow += Math.Min(order.process[i], order.count[i]);
    //     }

    //     float targetWidth = 71f;
    //     float targetHeight = 68f;
    //     int order_id = order.id;
    //     var configService = MainContainer.Container.Resolve<IConfigService>();
    //     var orderInfo = configService.MergeOrderListConfig[order_id];
    //     string rewards_str = orderInfo.rewards;
    //     string[] rewardGroups = rewards_str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
    //     string[] rewards = rewardGroups[0].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
    //     int reward_item_id = int.Parse(rewards[0]);
    //     icon.LoadPropSprite(reward_item_id, true, () =>
    //         {
    //             Sprite sprite = icon.sprite;
    //             Vector2[] uv = sprite.uv;
    //             Vector2 uvMin = uv[0];
    //             Vector2 uvMax = uv[0];
    //             foreach (Vector2 v in uv)
    //             {
    //                 uvMin = Vector2.Min(uvMin, v);
    //                 uvMax = Vector2.Max(uvMax, v);
    //             }
    //             icon.material.SetVector("_UVMin", uvMin);
    //             icon.material.SetVector("_UVMax", uvMax);

    //             icon.material.SetFloat("_Progress", processNow / (float)processMax);
    //         });

    //     if (processNow < processMax)
    //     {
    //         Observable.Timer(TimeSpan.FromSeconds(5)).Subscribe(_ =>
    //             {
    //                 gameObject.SetActive(false);
    //                 var paobox = transform.GetComponent<BoxCollider2D>();
    //                 if (paobox != null)
    //                     paobox.enabled = false;
    //                 transform.Find("ani_Idle").gameObject.SetActive(false);
    //             });
    //     }
    // }

    public void ShowPaoPao(int npc_id, int orderIndex = 0)
    {
        npcId = npc_id;
        SpriteRenderer bg = transform.Find("paopao_bg").GetComponent<SpriteRenderer>();
        SpriteRenderer icon = bg.transform.Find("paopao_item/paopao_icon").GetComponent<SpriteRenderer>();
        SpriteRenderer gou = bg.transform.Find("paopao_item/paopao_gou").GetComponent<SpriteRenderer>();
        int sortOrder = orderIndex + 1;
        bg.sortingOrder = sortOrder;
        icon.sortingOrder = sortOrder + 1;
        gou.sortingOrder = sortOrder + 2;

        var dataService = MainContainer.Container.Resolve<IDataService>();
        var orderInfo = dataService.GetMergeOrder(npcId, out _);
        if (orderInfo != null && !orderInfo.over)
        {
            List<int> items = new List<int>();
            for (int i = 0; i < orderInfo.items.Length; i++)
            {
                if (orderInfo.process[i] < orderInfo.count[i])
                {
                    items.Add(i);
                }
            }
            if (items.Count == 0)
            {
                for (int i = 0; i < orderInfo.items.Length; i++)
                {
                    items.Add(i);
                }
            }
            ShowItems(items);
        }
        else
        {
            HidePaoPao();
        }
    }

    public void ShowItems(List<int> _items = null)
    {
        if (dispear)
            return;
        if (seq != null)
        {
            DOTween.Kill(seq);
            seq = null;
        }
        if (_items != null)
            items = _items;

        var dataService = MainContainer.Container.Resolve<IDataService>();
        var orderInfo = dataService.GetMergeOrder(npcId, out _);
        if(orderInfo == null || orderInfo.over)
            return;

        itemIndex = (++itemIndex) % items.Count;
        var idx = _items[itemIndex];
        bool finish = orderInfo.process[idx] >= orderInfo.count[idx];

        var itemId = orderInfo.items[idx];
        var itemTrans = transform.Get<Transform>("paopao_bg/paopao_item");
        SpriteRenderer itemSprite = itemTrans.Get<SpriteRenderer>("paopao_icon");
        SpriteRenderer gouSprite = itemTrans.Get<SpriteRenderer>("paopao_gou");
        // gouSprite.transform.localScale = Vector3.one * 3.1f;
        // gouSprite.transform.localPosition = new Vector3(1, -1, 0);

        gouSprite.gameObject.SetActive(finish);
        itemTrans.DOKill();
        itemTrans.DOScale(Vector3.one * 0.1f, 0.2f).SetTarget(itemTrans).SetEase(Ease.InSine).OnComplete(() =>
        {
            if (dispear)
                return;
            itemTrans.DOScale(Vector3.one, 0.2f).SetTarget(itemTrans).SetEase(Ease.InSine).OnComplete(() =>
            {
                if (seq != null)
                {
                    DOTween.Kill(seq);
                    seq = null;
                }
                seq = DOTween.Sequence();
                seq.AppendInterval(3);
                seq.AppendCallback(() =>
                {
                    var orderInfo = dataService.GetMergeOrder(npcId, out _);
                    if (orderInfo != null && !orderInfo.over)
                    {
                        List<int> _items = new List<int>();
                        for (int i = 0; i < orderInfo.items.Length; i++)
                        {
                            if (orderInfo.process[i] < orderInfo.count[i])
                            {
                                _items.Add(i);
                            }
                        }
                        if (_items.Count == 0)
                        {
                            for (int i = 0; i < orderInfo.items.Length; i++)
                            {
                                _items.Add(i);
                            }
                        }
                        ShowItems(_items);
                    }
                    seq = null;
                });
                seq.SetTarget(seq);
            });

            float targetWidth = 70f;
            float targetHeight = 70f;
            itemSprite.LoadPropSprite(itemId, true, () =>
                {
                    if (dispear)
                        return;
                    float originalWidth = itemSprite.sprite.textureRect.size.x;
                    float originalHeight = itemSprite.sprite.textureRect.size.y;
                    float scaleX = targetWidth / originalWidth;
                    float scaleY = targetHeight / originalHeight;
                    float scaleFactor = Mathf.Min(scaleX, scaleY);
                    itemSprite.transform.localScale = new Vector3(scaleFactor, scaleFactor, 1f);
                });
        });
    }

    public void HidePaoPao()
    {
        gameObject.SetActive(false);
        var paobox = transform.parent.GetComponent<BoxCollider2D>();
        if (paobox != null)
            paobox.enabled = false;
        transform.Find("ani_Idle").gameObject.SetActive(false);
    }

    public void ShowIdle()
    {
        var paobox = transform.parent.GetComponent<BoxCollider2D>();
        if (paobox != null)
            paobox.enabled = true;
        transform.Find("ani_Idle").gameObject.SetActive(true);
    }
}
