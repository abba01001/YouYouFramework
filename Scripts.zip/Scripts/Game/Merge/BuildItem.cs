using System.Collections.Generic;
using SoliUtils;
using UnityEngine;
using UnityEngine.EventSystems;

public class BuildItem : MonoBehaviour
{
    public int RegionId;
    public int BuildId;
    private long clickInterval;
    private bool isClickIt;


    void Update()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }
        if (Input.GetMouseButtonDown(0))
        {
            isClickIt = false;
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            RaycastHit2D[] hits = Physics2D.RaycastAll(mousePos, Vector2.zero);
            foreach (var hit in hits)
            {
                if (hit.collider.gameObject == this.gameObject)
                {
                    clickInterval = TimeUtils.Timestamp();
                    isClickIt = true;
                    break;
                }
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            if (isClickIt)
            {
                Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                RaycastHit2D[] hits = Physics2D.RaycastAll(mousePos, Vector2.zero);
                foreach (var hit in hits)
                {
                    if (hit.collider.gameObject == this.gameObject)
                    {
                        clickInterval = TimeUtils.Timestamp() - clickInterval;
                        if (clickInterval < 150)
                        {
                            if (BuildId == 1)
                            {
                                BoxBuilder.ShowRegionRewardsPopup(RegionId);
                            }
                            break;
                        }
                    }
                }
            }
            isClickIt = false;
        }
    }

    public Vector3 GetBuildStarPos(int index)
    {
        var starTrans = transform.Find($"star{index}");
        if (starTrans != null)
        {
            return starTrans.position;
        }
        return transform.position;
    }

    public void RefreshBuildStar()
    {
        if(BuildId != 1)
            return;
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();

        var _info = dataService.GetRegionInfo(RegionId);
        if(_info == null)
            return;
        var info = new MergeRegionModel(_info);
        int nextId = info.id * 1000 + info.level + 1;
        List<int> builds = new List<int>();
        while (info.addExp > 0 && configService.MergeRegionRewardsConfig.ContainsKey(nextId))
        {
            var m = configService.MergeRegionRewardsConfig[nextId];
            int needExp = m.exp - info.exp;
            if (info.addExp >= needExp)
            {
                info.level++;
                info.exp = 0;
                info.addExp -= needExp;
                if (m.build_lv > 0)
                {
                    builds.Add(m.build_lv);
                }
                nextId = m.id * 1000 + m.level + 1;
            }
            else
            {
                info.exp += info.addExp;
                info.addExp = 0;
            }
        }

        var regionInfo = info;
        int buildLv = 0;
        int regionLv = regionInfo.level;
        int key = RegionId * 1000 + regionLv;
        while (configService.MergeRegionRewardsConfig.ContainsKey(key) && regionLv > 0)
        {
            var cfg = configService.MergeRegionRewardsConfig[key];
            if (cfg.build_lv > 0)
            {
                buildLv = cfg.build_lv;
                break;
            }
            key = RegionId * 1000 + (--regionLv);
        }

        int totalExp = 0;
        int nowExp = regionInfo.exp;
        key ++;
        while (configService.MergeRegionRewardsConfig.ContainsKey(key))
        {
            var cfg = configService.MergeRegionRewardsConfig[key];
            totalExp += cfg.exp;
            if (regionInfo.level >= cfg.level)
            {
                nowExp += cfg.exp;
            }
            if (cfg.build_lv > 0 && cfg.build_lv != buildLv)
            {
                break;
            }
            key++;
        }

        for (int i = 1; i <= 5; i++)
        {
            var starTrans = transform.Find($"star{i}");
            if (starTrans != null)
            {
                SpriteRenderer icon = starTrans.Find("dy_qs_xx_1").GetComponent<SpriteRenderer>();
                Sprite sprite = icon.sprite;
                Vector2[] uv = sprite.uv;
                Vector2 uvMin = uv[0];
                Vector2 uvMax = uv[0];
                foreach (Vector2 v in uv)
                {
                    uvMin = Vector2.Min(uvMin, v);
                    uvMax = Vector2.Max(uvMax, v);
                }
                icon.material.SetVector("_UVMin", uvMin);
                icon.material.SetVector("_UVMax", uvMax);

                if (i <= buildLv)
                    icon.material.SetFloat("_Progress", 1);
                else if (i == buildLv + 1)
                {
                    icon.material.SetFloat("_Progress", nowExp / (float)totalExp);
                }
                else
                {
                    icon.material.SetFloat("_Progress", 0);
                }
            }
        }
    }

}
