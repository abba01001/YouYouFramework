using System;
using Cysharp.Threading.Tasks;
using Doozy.Engine.Extensions;
using QFramework;
using SoliUtils;
using TMPro;
using UniRx;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;

public class MergeItem : MonoBehaviour
{
    public int GridId;
    private int ItemId;
    private GameObject selectObj = null;
    private bool isLoad = false;
    private bool isVisible = false;
    private Constants.MergeItemType itemType;
    private long clickInterval;

    private Material defaultMaterial;
    private Material grayscaleMaterial;
    public bool IsGray = false;

    private GameObject npcPaopao;

    private async void Awake()
    {
        var task = await GlobalRes.LoadAssetAsync<Material>("Assets/Res/Materials/GrayscaleMat.mat");
        grayscaleMaterial = task.Result;
    }

    public async void SetGrayscale(bool isGrayscale)
    {
        IsGray = isGrayscale;
        while (grayscaleMaterial == null)
        {
            await UniTask.Delay(100);
        }
        SpriteRenderer[] spriteRenderers = GetComponentsInChildren<SpriteRenderer>();

        foreach (var spriteRenderer in spriteRenderers)
        {
            if (isGrayscale)
            {
                if (defaultMaterial == null)
                {
                    defaultMaterial = spriteRenderer.material;
                }
                spriteRenderer.material = grayscaleMaterial;
            }
            else
            {
                if (defaultMaterial != null)
                {
                    spriteRenderer.material = defaultMaterial;
                }
            }
        }
    }

    public void SetItemId(int id, int orderIndex = 0)
    {
        ItemId = id;
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        itemType = (Constants.MergeItemType)configService.MergeItemConfig[id].itemType;
        UniRx.Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe(_ =>
        {
            ShowPaoPao(orderIndex);
        });
    }

    public int GetItemId()
    {
        return ItemId;
    }

    public void HidePaoPao()
    {
        if (itemType == Constants.MergeItemType.Npc)
        {
            if (npcPaopao != null)
            {
                npcPaopao.GetComponent<NpcPaoPao>().HidePaoPao();
            }
        }
    }

    public async void ShowPaoPao(int orderIndex = 0)
    {
        if (itemType == Constants.MergeItemType.Npc)
        {
            if (npcPaopao == null)
            {
                await GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/npc_paopao.prefab", (obj) =>
                {
                    obj.transform.SetParent(transform, true);
                    obj.transform.localScale = Vector3.one;
                    obj.transform.localPosition = Vector3.zero;
                    obj.transform.localEulerAngles = Vector3.zero;
                    npcPaopao = obj;
                    var paobox = transform.GetComponent<BoxCollider2D>();
                    if (paobox != null)
                        obj.transform.localPosition += new Vector3(0, paobox.offset.y - 204, 0);
                    npcPaopao.GetComponent<NpcPaoPao>().ShowIdle();
                });
            }

            npcPaopao.SetActive(true);
            npcPaopao.GetComponent<NpcPaoPao>().ShowPaoPao(ItemId, orderIndex);
        }
    }

    public void ShowSelected(bool selected)
    {
        isVisible = selected;
        if (selectObj != null)
        {
            selectObj.SetActive(selected);
            return;
        }
        var configService = MainContainer.Container.Resolve<IConfigService>();
        int shape = configService.MergeItemConfig[ItemId].shape;
        if (selected)
        {
            if (!isLoad)
            {
                var gObj = gameObject;
                _ = GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/Selected{shape}.prefab", (obj) =>
                {
                    if (gObj == null)
                    {
                        GameObject.Destroy(obj);
                        return;
                    }
                    obj.transform.SetParent(transform);
                    obj.SetActive(isVisible);
                    obj.transform.localPosition = Vector3.zero;
                    selectObj = obj;
                });
            }
            isLoad = true;
        }
    }

    void OnMouseDown()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }
        clickInterval = TimeUtils.Timestamp();
        if (npcPaopao != null)
        {
            npcPaopao.SetActive(false);
            npcPaopao.GetComponent<NpcPaoPao>().HidePaoPao();
        }
        PressMergeItemEvent evt = GameObjManager.Instance.PopClass<PressMergeItemEvent>(true);
        evt.item = this;
        TypeEventSystem.Send<PressMergeItemEvent>(evt);
    }


    async void OnMouseUp()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return;
        }
        var dataService = MainContainer.Container.Resolve<IDataService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        clickInterval = TimeUtils.Timestamp() - clickInterval;
        if (clickInterval < 100)
        {
            if (itemType == Constants.MergeItemType.Npc)
            {
                // var order = dataService.GetMergeOrder(ItemId, out var _);
                // if (order != null && !order.over)
                    BoxBuilder.ShowMergeOrderPopup(ItemId);
            }
            else if (itemType == Constants.MergeItemType.Exp)
            {
                if (dataService.UseExpMergeItem(GridId))
                {
                    
                }
            }
            else if (itemType == Constants.MergeItemType.LevelBox)
            {
                if (!dataService.OpenMergeLevelBox(GridId))
                {
                    BoxBuilder.ShowToast("打开宝箱失败");
                }
            }
            else if (itemType == Constants.MergeItemType.MapBox)
            {
                if (!dataService.OpenMergeMapBox(GridId))
                {
                    BoxBuilder.ShowToast("打开宝箱失败");
                }
            }
            else if (itemType == Constants.MergeItemType.BuildCoinBox)
            {
                BoxBuilder.ShowBuyMergeItemPopup(ItemId, GridId);
            }
            else
            {
                PlayClickAnim();
            }
        }

        if (itemType == Constants.MergeItemType.Npc)
        {
            ShowPaoPao(MergeGameController.Instance.GetItemSortOrder(GridId));
        }
    }

    public async void PlayClickAnim()
    {
        var animator = GetComponent<Animator>();
        if (animator == null)
        {
            animator = gameObject.AddComponent<Animator>();
            await GlobalRes.DynamicLoadAnimator("Assets/Res/Animations/Item/Merge_Obj.controller", (ac) =>
            {
                animator.runtimeAnimatorController = ac;
                animator.Play("ani_obj_click", -1, 0);
            });
        }
        else
        {
            animator.Play("ani_obj_click", -1, 0);
        }
    }

    public async void PlayMergeShowAnim()
    {
        var animator = GetComponent<Animator>();
        if (animator == null)
        {
            animator = gameObject.AddComponent<Animator>();
            await GlobalRes.DynamicLoadAnimator("Assets/Res/Animations/Item/Merge_Obj.controller", (ac) =>
            {
                animator.runtimeAnimatorController = ac;
                animator.Play("ani_obj_in", -1, 0);
            });
        }
        else
        {
            animator.Play("ani_obj_in", -1, 0);
        }
    }
}
