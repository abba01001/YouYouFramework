using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using Doozy.Engine.Extensions;
using Doozy.Engine.UI;
using QFramework;
using SoliUtils;
using UniRx;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;
using UnityEngine.Tilemaps;


public class MergeGameController : MonoBehaviour, ISingleton
{
    private IConfigService configService;
    private IDataService dataService;

    private GameObject mapObj;
    private Tilemap groundTilemap;
    private Tilemap gridTilemap;
    private Transform buildTrans;
    private Dictionary<int, TileBase> oriTileBase = new Dictionary<int, TileBase>();
    private Dictionary<int, Vector3Int> tileData = new Dictionary<int, Vector3Int>();
    private Dictionary<int, GameObject> itemObjs = new Dictionary<int, GameObject>();
    private Dictionary<int, GameObject> bubbleObjs = new Dictionary<int, GameObject>();
    private Dictionary<int, GameObject> hotAirBallObjs = new Dictionary<int, GameObject>();
    private Dictionary<string, GameObject> buildObjs = new Dictionary<string, GameObject>();
    private Dictionary<int, GameObject> npcObjs = new Dictionary<int, GameObject>();
    private Dictionary<int, GameObject> npcCloud = new Dictionary<int, GameObject>();
    private Dictionary<int, List<int>> mapGraph = new Dictionary<int, List<int>>();
    private List<Tuple<int, int>> moveEvents = new List<Tuple<int, int>>();
    private List<Tuple<int, int>> regionStartGridIds = new List<Tuple<int, int>>();
    private Dictionary<int, int> gridOrderSort = new Dictionary<int, int>();
    private readonly string MergeTag = "Merge";
    private readonly string BubbleTag = "Bubble";
    private readonly string HotAirBallTag = "HotAirBall";


    private readonly int TopLayerSort = 32767;
    private Vector3 _cameraRecord = new Vector3();


    void Awake()
    {
        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();

        TypeEventSystem.Register<BattleCommandEvent>(OnBattleCommandEvent);
        TypeEventSystem.Register<ShowHomeViewEvent>(OnShowHomeViewEvent);
        TypeEventSystem.Register<CreateMergeBubbleEvent>(OnCreateMergeBubbleEvent);
        TypeEventSystem.Register<RemoveMergeItemEvent>(OnRemoveMergeItemEvent);
        TypeEventSystem.Register<OpenMergeBubbleEvent>(OnOpenMergeBubbleEvent);
        TypeEventSystem.Register<GetOrderRewardsEvent>(OnGetOrderRewardsEvent);
        TypeEventSystem.Register<UnlockCloudEvent>(OnUnlockCloudEvent);
        TypeEventSystem.Register<FlyGridExpEvent>(OnFlyGridExpEvent);
        TypeEventSystem.Register<UnlockBuildEvent>(OnUnlockBuildEvent);
        TypeEventSystem.Register<PutLevelBoxEvent>(OnPutLevelBoxEvent);
        TypeEventSystem.Register<OpenMergeBoxEvent>(OnOpenMergeBoxEvent);
        TypeEventSystem.Register<FlyBuildExpEvent>(OnFlyBuildExpEvent);
        TypeEventSystem.Register<CreateMergeHotAirBallEvent>(OnCreateMergeHotAirBallEvent);
        TypeEventSystem.Register<CheckHotAirBallEvent>(OnCheckHotAirBallEvent);
        TypeEventSystem.Register<RookieMergeEndEvent>(OnRookieMergeEndEvent);
        TypeEventSystem.Register<UnlockMergeItemEvent>(OnUnlockMergeItemEvent);
        TypeEventSystem.Register<MoveCameraToGridEvent>(OnMoveCameraToGridEvent);

    }

    void OnDestroy()
    {
        TypeEventSystem.UnRegister<BattleCommandEvent>(OnBattleCommandEvent);
        TypeEventSystem.UnRegister<ShowHomeViewEvent>(OnShowHomeViewEvent);
        TypeEventSystem.UnRegister<CreateMergeBubbleEvent>(OnCreateMergeBubbleEvent);
        TypeEventSystem.UnRegister<RemoveMergeItemEvent>(OnRemoveMergeItemEvent);
        TypeEventSystem.UnRegister<OpenMergeBubbleEvent>(OnOpenMergeBubbleEvent);
        TypeEventSystem.UnRegister<GetOrderRewardsEvent>(OnGetOrderRewardsEvent);
        TypeEventSystem.UnRegister<UnlockCloudEvent>(OnUnlockCloudEvent);
        TypeEventSystem.UnRegister<FlyGridExpEvent>(OnFlyGridExpEvent);
        TypeEventSystem.UnRegister<UnlockBuildEvent>(OnUnlockBuildEvent);
        TypeEventSystem.UnRegister<PutLevelBoxEvent>(OnPutLevelBoxEvent);
        TypeEventSystem.UnRegister<OpenMergeBoxEvent>(OnOpenMergeBoxEvent);
        TypeEventSystem.UnRegister<FlyBuildExpEvent>(OnFlyBuildExpEvent);
        TypeEventSystem.UnRegister<CreateMergeHotAirBallEvent>(OnCreateMergeHotAirBallEvent);
        TypeEventSystem.UnRegister<CheckHotAirBallEvent>(OnCheckHotAirBallEvent);
        TypeEventSystem.UnRegister<RookieMergeEndEvent>(OnRookieMergeEndEvent);
        TypeEventSystem.UnRegister<UnlockMergeItemEvent>(OnUnlockMergeItemEvent);
        TypeEventSystem.UnRegister<MoveCameraToGridEvent>(OnMoveCameraToGridEvent);

    }

    private void OnFlyBuildExpEvent(FlyBuildExpEvent e)
    {
        int gridId = e.gridId;
        _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Merge/mofabang/mofabang.prefab", (obj) =>
        {
            obj.SetActive(true);
            obj.transform.SetParent(transform);
            obj.transform.position = GetGridCenterPos(gridId);

            bool findBuild = false;
            Vector3 targetPos = Vector3.one;

            for (int i = 1; i <= Constants.RegionNum; i++)
            {
                var regionInfo = dataService.GetRegionInfo(i);
                if (regionInfo == null)
                {
                    continue;
                }
                int regionLv = regionInfo.level;
                int key = i * 1000 + regionLv + 1;
                if (configService.MergeRegionRewardsConfig.ContainsKey(key))
                {
                    BuildItem target = null;
                    foreach (var item in buildObjs)
                    {
                        target = item.Value.GetComponent<BuildItem>();
                        if (target.RegionId == i && target.BuildId == 1)
                        {
                            findBuild = true;
                            int buildLv = 0;
                            key--;
                            while (configService.MergeRegionRewardsConfig.ContainsKey(key) && regionLv > 0)
                            {
                                var cfg = configService.MergeRegionRewardsConfig[key];
                                if (cfg.build_lv > 0)
                                {
                                    buildLv = cfg.build_lv;
                                    break;
                                }
                                key = i * 1000 + (--regionLv);
                            }
                            targetPos = target.GetBuildStarPos(buildLv + 1);
                            break;
                        }
                    }

                    if (findBuild)
                    {
                        for (int j = 0; j < e.stars - 1; j++)
                        {
                            var _obj = GameObject.Instantiate(obj, obj.transform.parent);
                            var pos = _obj.transform.localPosition;
                            _obj.transform.localPosition = new Vector3(GameUtils.RandomRange(-50f, 50f) + pos.x,
                                GameUtils.RandomRange(-50f, 50f) + pos.y,
                                pos.z
                            );
                            _obj.transform.localScale = Vector3.one * GameUtils.RandomRange(0.1f, 0.3f);
                            _obj.transform.DOScale(Vector3.one * 1.5f, 0.5f).SetDelay(j * 0.1f).OnComplete(() =>
                            {
                                _obj.transform.DOScale(Vector3.one * 0.5f, 1.5f);
                                _obj.transform.DOCurMove(targetPos, 1.5f).OnComplete(() =>
                                {
                                    GameObject.Destroy(_obj, 0.5f);
                                });
                            });

                        }
                        obj.transform.localScale = Vector3.one * GameUtils.RandomRange(0.1f, 0.3f);
                        obj.transform.DOScale(Vector3.one * 1.5f, 0.5f).OnComplete(() =>
                        {
                            obj.transform.DOScale(Vector3.one * 0.5f, 1.5f);
                            obj.transform.DOCurMove(targetPos, 1.5f).OnComplete(() =>
                            {
                                GameObject.Destroy(obj, 0.5f);
                                if (target != null)
                                    target.RefreshBuildStar();
                            });
                        });

                        break;
                    }
                }
            }

        });
    }

    private void OnOpenMergeBoxEvent(OpenMergeBoxEvent e)
    {
        if (itemObjs.ContainsKey(e.grid_id))
        {
            Destroy(itemObjs[e.grid_id]);
            itemObjs.Remove(e.grid_id);
        }

        foreach (var gridId in e.newItemGrids)
        {
            var itemId = dataService.GetGridItemId(gridId, out var _);
            CreateItem(gridId, itemId, e.grid_id);
        }
    }

    private void OnPutLevelBoxEvent(PutLevelBoxEvent e)
    {
        CreateItem(e.grid_id, Constants.MergeLevelBoxItemId, e.fromPos);
    }

    private void OnUnlockBuildEvent(UnlockBuildEvent e)
    {
        var buildKey = e.region_id * 100 + e.build_lv;
        var lastBuildKey = e.region_id * 100 + e.build_lv - 1;

        List<string> newBuilds = new List<string>();
        List<string> lastBuilds = new List<string>();

        if (configService.MergeBuildConfig.ContainsKey(buildKey))
        {
            var buildResListStr = configService.MergeBuildConfig[buildKey].res_list;
            newBuilds = buildResListStr.Split(GameUtils.FirstSeparator).ToList();
        }
        if (configService.MergeBuildConfig.ContainsKey(lastBuildKey))
        {
            var buildResListStr = configService.MergeBuildConfig[lastBuildKey].res_list;
            lastBuilds = buildResListStr.Split(GameUtils.FirstSeparator).ToList();
        }

        List<string> commonBuilds = newBuilds.Intersect(lastBuilds).ToList();
        newBuilds = newBuilds.Except(commonBuilds).ToList();
        lastBuilds = lastBuilds.Except(commonBuilds).ToList();

        foreach (var lastKey in lastBuilds)
        {
            if (buildObjs.ContainsKey(lastKey))
            {
                GameObject.Destroy(buildObjs[lastKey]);
                buildObjs.Remove(lastKey);
            }
        }

        foreach (var newKey in newBuilds)
        {
            _ = GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/builds/{newKey}.prefab", (_obj) =>
            {
                _obj.SetActive(true);
                _obj.transform.SetParent(buildTrans, false);
                buildObjs.TryAdd(newKey, _obj);

                // GlobalRes.DynamicLoadPrefab($"Assets/Res/Prefabs/FX/tx_MergerGame_02.prefab", (_obj2) =>
                // {
                //     _obj2.transform.SetParent(_obj.transform, false);
                //     _obj2.SetActive(true);
                // });

            });
        }
    }

    private void OnFlyGridExpEvent(FlyGridExpEvent e)
    {
        foreach (var item in e.oriGridExp)
        {
            int gridId = item.Key;
            _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_MergerGame_01.prefab", (obj) =>
            {
                obj.SetActive(true);
                obj.transform.SetParent(transform);
                obj.transform.position = GetGridCenterPos(e.fromGridId);

                int ori = e.oriGridExp[gridId];
                int now = e.newGridExp[gridId];
                int max = configService.MergeMapConfig[gridId].unlock_exp;

                obj.transform.DOCurMove(GetGridCenterPos(gridId), 1f).OnComplete(() =>
                {
                    GameObject.Destroy(obj);

                    GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_MergerGame_03.prefab", (_obj) =>
                    {
                        _obj.SetActive(true);
                        _obj.transform.SetParent(transform);
                        _obj.transform.position = GetGridCenterPos(gridId);
                        _obj.transform.position = GetGridCenterPos(gridId);
                        GameObject.Destroy(_obj, 2f);
                    });
                    GlobalRes.DynamicLoadPrefab("Assets/Res/Merge/grid_exp_bar.prefab", (_obj) =>
                    {
                        _obj.SetActive(true);
                        _obj.transform.SetParent(transform);
                        _obj.transform.position = GetGridCenterPos(gridId);
                        var gridExpBar = _obj.GetComponent<GridExpBar>();
                        gridExpBar.Show(ori, now, max, 0.5f, TopLayerSort);
                    });
                    if (now >= max && dataService.IsUnlockGrid(gridId))
                    {
                        UniRx.Observable.Timer(TimeSpan.FromSeconds(0.5f)).Subscribe((x) =>
                        {
                            var pos = tileData[gridId];
                            gridTilemap.SetTile(pos, oriTileBase[gridId]);
                            gridTilemap.RefreshTile(pos);
                            if (itemObjs.ContainsKey(gridId))
                            {
                                itemObjs[gridId].GetComponent<MergeItem>()?.SetGrayscale(false);
                            }
                        });
                    }
                });

            });

        }
    }

    private async void OnUnlockCloudEvent(UnlockCloudEvent e)
    {
        int delay = 2;

        var mergeData = dataService.GetMergeData();
        var grids = mergeData.Keys;
        foreach (var gridId in grids)
        {
            if (mergeData.TryGetValue(gridId, out int itemId) && configService.MergeMapConfig[gridId].cloud_id == e.cloud_id)
            {
                var itemObj = await CreateItem(gridId, itemId);
                SetItemSortOrder(itemObj, 0);
                UniRx.Observable.Timer(TimeSpan.FromSeconds(delay)).Subscribe(_ =>
                {
                    SetItemSortOrder(itemObj, gridOrderSort[gridId]);
                });
            }
        }

        List<int> gridIdList = configService.MergeMapConfig.Values
                .Where(config => config.cloud_id == e.cloud_id && config.unlock_exp == 0)
                .Select(config => config.id)
                .ToList();
        foreach (var _gridId in gridIdList)
        {
            if (dataService.IsUnlockGrid(_gridId))
            {
                gridTilemap.SetTile(tileData[_gridId], oriTileBase[_gridId]);
                if (itemObjs.ContainsKey(_gridId))
                {
                    itemObjs[_gridId].GetComponent<MergeItem>()?.SetGrayscale(false);
                }
            }
        }
    }

    private void OnGetOrderRewardsEvent(GetOrderRewardsEvent e)
    {
        foreach (var gridId in e.newItemGrids)
        {
            var itemId = dataService.GetGridItemId(gridId, out var _);
            CreateItem(gridId, itemId, e.npcGridId);
        }

        var npcId = dataService.GetGridItemId(e.npcGridId, out _);
        var pos = npcObjs[npcId].transform.position;

        if (e.coin > 0)
            GoldView.Instance.ThreePowerBeizerFlyCoinFromWorldPos((int)PropEnum.Coin, dataService.Coin - e.coin, dataService.Coin, pos);
        if (e.buildCoin > 0)
            GoldView.Instance.ThreePowerBeizerFlyCoinFromWorldPos((int)PropEnum.BuildCoin, dataService.BuildCoin - e.buildCoin, dataService.BuildCoin, pos);
    }

    private void OnOpenMergeBubbleEvent(OpenMergeBubbleEvent e)
    {
        if (bubbleObjs.ContainsKey(e.bubbleId))
        {
            foreach (var gridId in e.newItemGrids)
            {
                var itemId = dataService.GetGridItemId(gridId, out var _);
                var pos = bubbleObjs[e.bubbleId].transform.position;
                CreateItem(gridId, itemId, pos);
            }
            if (!dataService.HasMergeBubble(e.bubbleId))
            {
                var mi = bubbleObjs[e.bubbleId].GetComponent<BubbleItem>();
                mi.Dispear();
                bubbleObjs.Remove(e.bubbleId);
            }
            else
            {
                var bubbleData = dataService.GetMergeBubbleData();
                if (bubbleData.TryGetValue(e.bubbleId, out var data))
                {
                    var mi = bubbleObjs[e.bubbleId].GetComponent<BubbleItem>();
                    mi.ShowItems(data.items.ToList());
                }
            }
        }
    }

    private void OnCreateMergeHotAirBallEvent(CreateMergeHotAirBallEvent e)
    {
        CreateHotAirBall(e.mergeHotAirBallModel);
    }

    private void OnCheckHotAirBallEvent(CheckHotAirBallEvent e)
    {
        if (hotAirBallObjs.ContainsKey(e.ballId))
        {
            GameObject.Destroy(hotAirBallObjs[e.ballId]);
            hotAirBallObjs.Remove(e.ballId);
            BoxBuilder.HideHotAirBallPopup();
        }
    }

    private void OnRemoveMergeItemEvent(RemoveMergeItemEvent e)
    {
        if (itemObjs.ContainsKey(e.gridId))
        {
            GameObject.Destroy(itemObjs[e.gridId]);
            itemObjs.Remove(e.gridId);
        }
    }

    private void OnCreateMergeBubbleEvent(CreateMergeBubbleEvent e)
    {
        CreateBubble(e.mergeBubbleModel, true);
    }

    private void OnBattleCommandEvent(BattleCommandEvent e)
    {
        switch (e.command)
        {
            case BattleCommand.StartGame:
                Camera.main.transform.position = Vector3.zero;
                int battleOs = 400;
                if (Screen.width / (float)Screen.height < 1334f / 750)
                {
                    battleOs = (int)(battleOs / (Screen.width / (float)Screen.height) * (1334f / 750));
                }
                TypeEventSystem.Send<MainCamerOrthographicSizeEvent>(new MainCamerOrthographicSizeEvent(battleOs));
                gameObject.SetActive(false);
                break;
        }
    }
    private void OnShowHomeViewEvent(ShowHomeViewEvent e)
    {
        TypeEventSystem.Send<MainCamerResetEvent>();
        if (mapObj != null)
            gameObject.SetActive(true);
    }

    private void OnRookieMergeEndEvent(RookieMergeEndEvent e)
    {
        int gridId1 = e.startGridId;
        int gridId2 = e.endGridId;
        List<int> removes;
        List<Tuple<int, int>> adds;
        var ret = dataService.DoMerge(gridId1, gridId2, out removes, out adds);
        if (ret)
        {
            foreach (var item in removes)
            {
                RemoveItem(item, gridId2);
            }
            var newGridId = -1;
            foreach (var item in adds)
            {
                CreateItem(item.Item1, item.Item2, gridId2, 0.3f);
                _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_MergerGame_02.prefab", (obj) =>
                {
                    obj.SetActive(true);
                    obj.transform.SetParent(transform);
                    obj.transform.position = GetGridCenterPos(item.Item1);
                    GameObject.Destroy(obj, 2f);
                });
            }
        }

    }

    private void OnUnlockMergeItemEvent(UnlockMergeItemEvent e)
    {
        if (configService.MergeItemConfig.TryGetValue(e.itemId, out var cfg))
        {
            if (cfg.itemType == (int)Constants.MergeItemType.Npc && npcCloud.TryGetValue(e.itemId, out var obj))
            {
                Camera.main.transform.DOCurMove(obj.transform.position, 0.8f).SetEase(Ease.InSine).OnComplete(() =>
                {
                    SpriteRenderer[] sprs = obj.transform.GetComponentsInChildren<SpriteRenderer>();
                    foreach (var spr in sprs)
                    {
                        Color spriteColor = spr.color;
                        spr.DOColor(new Color(spriteColor.r, spriteColor.g, spriteColor.b, 0), 0.8f);
                    }
                });
                GameObject.Destroy(obj, 1.7f);
                UniRx.Observable.Timer(TimeSpan.FromSeconds(1.7f)).Subscribe((_) =>
                {
                    Camera.main.transform.DOCurMove(npcObjs[e.itemId].transform.position, 0.8f).SetEase(Ease.InSine);
                });
            }
        }
    }

    private void OnMoveCameraToGridEvent(MoveCameraToGridEvent e)
    {
        var pos = GetGridCenterPos(e.gridId);
        Camera.main.transform.DOCurMove(pos, e.time).SetEase(Ease.InSine);
    }

    // void Start()
    // {
    // }

    public void Init()
    {

    }

    public void Show(bool vis)
    {
        gameObject.SetActive(vis);
    }

    int GetPointNumber(int x, int y)
    {
        int rowNumber = 1000 - y;
        int columnNumber = 1000 - x;
        int number = rowNumber * 2001 + columnNumber + 1;
        return number;
    }

    public async Task Load()
    {
        _cameraRecord = dataService.CameraRecord;
        mapObj = await GlobalRes.DynamicLoadPrefab("Assets/Res/Merge/MergeMap.prefab");
        mapObj.SetActive(true);
        mapObj.transform.SetParent(transform);
        mapObj.transform.localScale = Vector3.one * 100;

        var grid = mapObj.GetComponent<Grid>();
        groundTilemap = mapObj.transform.Find("Ground").GetComponent<Tilemap>();
        gridTilemap = mapObj.transform.Find("Grid").GetComponent<Tilemap>();

        List<Vector3Int> tiles = new List<Vector3Int>();
        foreach (Vector3Int pos in gridTilemap.cellBounds.allPositionsWithin)
        {
            if (gridTilemap.HasTile(pos))
            {
                tiles.Add(pos);
            }
        }

        tiles = tiles.OrderByDescending(entry => entry.y).ThenByDescending(entry => entry.x).ToList();
        int grid_id = 0;
        Color originalColor = Color.white;

        foreach (var pos in tiles)
        {
            grid_id = GetPointNumber(pos.x, pos.y);
            tileData.Add(grid_id, pos);
        }

        MapMono mm = mapObj.GetComponent<MapMono>();
        for (int i = 0; i < mm.Keys.Count; i++)
        {
            if (!mapGraph.ContainsKey(mm.Keys[i]))
            {
                List<int> list = new List<int>() { mm.Values[i].up, mm.Values[i].down, mm.Values[i].left, mm.Values[i].right };
                mapGraph.Add(mm.Keys[i], list);
            }
        }
        foreach (var item in mm.RegionStartGridIds)
        {
            regionStartGridIds.Add(new Tuple<int, int>(item.id, item.gridId));
        }

        var grids = configService.MergeMapConfig.Keys.ToList();
        grids.Sort();
        var sortOrder = 1;
        foreach (var gridId in grids)
        {
            gridOrderSort.Add(gridId, 6000 + sortOrder++);
        }

        int cloudId = 0;
        foreach (var item in dataService.GetMergeData())
        {
            cloudId = configService.MergeMapConfig[item.Key].cloud_id;
            if (cloudId == 0 || dataService.IsUnlockCloud(cloudId))
                await CreateItem(item.Key, item.Value);
        }

        foreach (var pos in tiles)
        {
            grid_id = GetPointNumber(pos.x, pos.y);
            if (!dataService.IsUnlockGrid(grid_id))
            {
                var name = gridTilemap.GetTile(pos).name;
                if (name == "green_an")
                    oriTileBase.Add(grid_id, mm.Region1TileAn);
                else if (name == "green_liang")
                    oriTileBase.Add(grid_id, mm.Region1TileLigng);
                else if (name == "yellow_an")
                    oriTileBase.Add(grid_id, mm.Region2TileAn);
                else if (name == "yellow_liang")
                    oriTileBase.Add(grid_id, mm.Region2TileLigng);
                if (name.Contains("_an"))
                    gridTilemap.SetTile(pos, mm.GrayTileAn);
                else
                    gridTilemap.SetTile(pos, mm.GrayTileLiang);
            }
        }

        List<int> cloudList = configService.MergeRegionRewardsConfig.Values
            .Where(config => config.cloud_id > 0)
            .Select(config => config.cloud_id)
            .ToList();
        cloudList.Sort();
        bool showLock = false;
        foreach (var cloud_id in cloudList)
        {
            if (!dataService.IsUnlockCloud(cloud_id))
            {
                int id = cloud_id;
                await GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/cloud/cloud_{id}.prefab", (_obj) =>
                {
                    _obj.SetActive(true);
                    _obj.transform.SetParent(mapObj.transform, false);
                    var cloudItem = _obj.GetComponent<CloudItem>();
                    cloudItem.SetCloudId(id);
                    if (!showLock)
                    {
                        showLock = true;
                        cloudItem.ShowLock(true);
                    }
                });
            }
        }

        int[] cloud_npcs = { 30003, 50005 };
        foreach (var npc_id in cloud_npcs)
        {
            if (!dataService.IsUnlockNpc(npc_id))
            {
                await GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/cloud/cloud_npc_{npc_id}.prefab", (_obj) =>
                {
                    _obj.SetActive(true);
                    _obj.transform.SetParent(mapObj.transform, false);
                    npcCloud.TryAdd(npc_id, _obj);
                });
            }
        }

        buildTrans = mapObj.transform.Find("Builds");
        for (int i = 1; i <= Constants.RegionNum; i++)
        {
            var regionInfo = dataService.GetRegionInfo(i);
            int buildLv = 1;
            int regionLv = 0;
            if (regionInfo != null)
                regionLv = regionInfo.level;
            int key = i * 1000 + regionLv;
            while (configService.MergeRegionRewardsConfig.ContainsKey(key) && regionLv > 0)
            {
                var cfg = configService.MergeRegionRewardsConfig[key];
                if (cfg.build_lv > 0)
                {
                    buildLv = cfg.build_lv;
                    break;
                }
                key = i * 1000 + (--regionLv);
            }
            var buildKey = i * 100 + buildLv;
            if (configService.MergeBuildConfig.ContainsKey(buildKey))
            {
                var buildResListStr = configService.MergeBuildConfig[buildKey].res_list;
                string[] resList = buildResListStr.Split(GameUtils.FirstSeparator);
                foreach (var res in resList)
                {
                    await GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/builds/{res}.prefab", (_obj) =>
                    {
                        _obj.transform.SetParent(buildTrans, false);
                        _obj.SetActive(true);
                        buildObjs.TryAdd(res, _obj);
                        _obj.GetComponent<BuildItem>().RefreshBuildStar();
                    });
                }
            }
        }

        foreach (var item in dataService.GetMergeBubbleData())
        {
            await CreateBubble(item.Value, false);
        }

        foreach (var item in dataService.GetMergeHotAirBallData())
        {
            await CreateHotAirBall(item.Value);
        }
    }


    public void OnSingletonInit()
    {

    }

    public static MergeGameController Instance
    {
        get { return MonoSingletonProperty<MergeGameController>.Instance; }
    }

    private Vector3 _mapDragOrigin; // 拖拽起点
    private bool _isMapDragging;
    private Vector3 _mapDragPos;


    private int selectedGridId = -1; // 当前选中的物体的初始格子
    private int movingGridId = -1; // 选中时移动到的格子
    private GameObject selectedObject; // 当前选中的物体
    private List<GameObject> canMergeObjList = new List<GameObject>();
    private bool _isObjDragging = false; // 标识对象是否正在被拖拽

    private Vector3 objOffset;

    private GameObject selectedBubble; // 当前选中的气泡
    private bool _isBubbleDragging = false;
    private Vector3 bubbleOffset;

    private GameObject selectedHotAirBall; // 当前选中的气球
    private bool _isHotAirBallDragging = false;
    private Vector3 hotAirBallOffset;
    private bool touchAble = true;



    [SerializeField] private float zoomSpeed = 100f; // 缩放速度
    [SerializeField] private float minZoom = 440f;    // 最小缩放
    [SerializeField] private float maxZoom = 1000f;   // 最大缩放
    async void Update()
    {
        if (!dataService.IsHasFirstNpc() && !dataService.IsRookieShowed(17))
            return;
        if (!touchAble)
            return;
        await HandleObjMoving();
        if (_isBubbleDragging || _isHotAirBallDragging || _isObjDragging)
            return;
        HandleMapDragging();
        HandleLockGrid();
        HandleMapZooming();


        if (Input.GetKeyDown(KeyCode.F1))
        {
            dataService.AddMergeLevelBox();
        }
    }

    private void CheckNpcOrderPro()
    {
        foreach (var item in npcObjs)
        {
            dataService.GetMergeOrder(item.Key, out bool newPro);
            if (newPro)
            {
                var mi = item.Value.GetComponent<MergeItem>();
                mi.ShowPaoPao(gridOrderSort[mi.GridId]);
            }
        }
    }

    async Task<GameObject> CreateItem(int gridId, int itemId, int fromGridId = -1, float delay = 0f)
    {
        if (gridId == -1)
            return null;

        CheckNpcOrderPro();

        return await GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/objs/{itemId}.prefab", (obj) =>
        {
            obj.transform.SetParent(transform);
            var pos = GetGridCenterPos(gridId);
            obj.transform.position = pos;
            obj.SetActive(false);
            itemObjs.Add(gridId, obj);
            var mi = obj.AddComponent<MergeItem>();
            mi.SetItemId(itemId, gridOrderSort[gridId]);
            mi.GridId = gridId;
            if (!dataService.IsUnlockGrid(gridId))
                mi.SetGrayscale(true);
            SetItemSortOrder(obj, gridOrderSort[gridId]);
            Observable.Timer(TimeSpan.FromSeconds(delay)).Subscribe(_ =>
            {
                obj.SetActive(true);
                if (fromGridId != -1)
                {
                    Vector3 center = gridTilemap.GetCellCenterWorld(tileData[fromGridId]);
                    obj.transform.position = center;
                    GameObject fxObj = null;
                    GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_MergerGame_05.prefab", (_obj) =>
                    {
                        fxObj = _obj;
                        fxObj.transform.SetParent(obj.transform);
                        fxObj.transform.localPosition = Vector3.zero;
                    });
                    mi.PlayMergeShowAnim();
                    obj.transform.DOCurMove(pos, 0.5f).OnComplete(() =>
                    {
                        if (fxObj != null)
                        {
                            GameObject.Destroy(fxObj, 0.2f);
                        }

                        GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_MergerGame_06.prefab", (_obj) =>
                        {
                            _obj.transform.SetParent(obj.transform);
                            _obj.transform.localPosition = Vector3.zero;
                            GameObject.Destroy(_obj, 2f);
                        });
                    });
                }
            });

            var itemType = (Constants.MergeItemType)configService.MergeItemConfig[itemId].itemType;
            if (itemType == Constants.MergeItemType.Npc)
            {
                npcObjs.TryAdd(itemId, obj);
            }
        });
    }

    async Task<GameObject> CreateItem(int gridId, int itemId, Vector3 fromPos)
    {
        if (gridId == -1)
            return null;

        CheckNpcOrderPro();

        return await GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/objs/{itemId}.prefab", (obj) =>
        {
            obj.transform.SetParent(transform);
            var pos = GetGridCenterPos(gridId);
            obj.transform.position = pos;
            obj.SetActive(false);
            itemObjs.Add(gridId, obj);
            var mi = obj.AddComponent<MergeItem>();
            mi.SetItemId(itemId, gridOrderSort[gridId]);
            mi.GridId = gridId;
            if (!dataService.IsUnlockGrid(gridId))
                mi.SetGrayscale(true);
            SetItemSortOrder(obj, gridOrderSort[gridId]);

            GameObject fxObj = null;
            GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_MergerGame_05.prefab", (_obj) =>
            {
                fxObj = _obj;
                fxObj.transform.SetParent(obj.transform);
                fxObj.transform.localPosition = Vector3.zero;
            });

            obj.SetActive(true);
            SetItemSortOrder(obj, TopLayerSort);
            obj.transform.position = fromPos;

            mi.PlayMergeShowAnim();
            obj.transform.DOCurMove(pos, 0.5f).OnComplete(() =>
            {
                SetItemSortOrder(obj, gridOrderSort[gridId]);
                if (fxObj != null)
                {
                    GameObject.Destroy(fxObj, 0.2f);
                }

                GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_MergerGame_06.prefab", (_obj) =>
                {
                    _obj.transform.SetParent(obj.transform);
                    _obj.transform.localPosition = Vector3.zero;
                    GameObject.Destroy(_obj, 2f);
                });
            });


        });
    }

    void RemoveItem(int gridId, int moveToGridId)
    {
        if (!itemObjs.ContainsKey(gridId))
            return;
        var obj = itemObjs[gridId];

        Vector3 center = gridTilemap.GetCellCenterWorld(tileData[moveToGridId]);
        obj.transform.DOCurMove(center, 0.3f).OnComplete(() =>
        {
            GameObject.Destroy(obj);
        });
        itemObjs.Remove(gridId);
    }

    async Task<GameObject> CreateBubble(MergeBubbleModel model, bool vis)
    {
        return await GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/MergeBubble.prefab", (obj) =>
        {
            obj.transform.SetParent(transform);
            obj.transform.position = new Vector3(model.x, model.y, -500);
            bubbleObjs.Add(model.id, obj);
            var mi = obj.AddComponent<BubbleItem>();
            mi.SetBubbleId(model.id);
            mi.ShowWhite();
            mi.ShowItems(model.items.ToList());
            if (vis)
                mi.ShowLight(true);
            obj.SetActive(true);
        });
    }

    async Task<GameObject> CreateHotAirBall(MergeHotAirBallModel model)
    {
        return await GlobalRes.DynamicLoadPrefab($"Assets/Res/Merge/bubble/HotAirBall.prefab", (obj) =>
        {
            obj.transform.SetParent(transform);
            obj.transform.position = new Vector3(model.x, model.y, -500);
            hotAirBallObjs.Add(model.id, obj);
            var mi = obj.GetComponent<HotAirBallItem>();
            mi.Show(model);
            obj.SetActive(true);
        });
    }

    int GetObjGridId(GameObject obj)
    {
        foreach (var item in itemObjs)
        {
            if (item.Value == obj)
                return item.Key;
        }
        return -1;
    }

    int GetNearUnlockGridId(Vector3 worldpos)
    {
        float dis = int.MaxValue;
        int gridId = -1;
        int tarGridId = -1;
        float d = 0f;
        foreach (var pair in tileData)
        {
            gridId = pair.Key;
            Vector3 center = gridTilemap.GetCellCenterWorld(tileData[gridId]);
            d = Vector3.Distance(worldpos, center);
            if (dataService.IsUnlockGrid(gridId) && d < dis)
            {
                dis = d;
                tarGridId = gridId;
            }
        }
        return tarGridId;
    }

    public int GetNearGridId(int gridId, List<int> gridIds)
    {
        float dis = int.MaxValue;
        int targetGridId = -1;
        Vector3 fromPos = gridTilemap.GetCellCenterWorld(tileData[gridId]);
        foreach (var id in gridIds)
        {
            Vector3 center = gridTilemap.GetCellCenterWorld(tileData[id]);
            float d = Vector3.Distance(fromPos, center);
            if (d < dis)
            {
                dis = d;
                targetGridId = id;
            }
        }
        return targetGridId;
    }

    Vector3 GetNearPosition(Vector3 worldpos)
    {
        float dis = int.MaxValue;
        // int tileId = -1;
        Vector3 pos = Vector3.zero;
        foreach (var pair in tileData)
        {
            Vector3 center = gridTilemap.GetCellCenterWorld(tileData[pair.Key]);
            float d = Vector3.Distance(worldpos, center);
            if (d < dis)
            {
                dis = d;
                pos = center;
                // tileId = pair.Key;
            }
        }
        return pos;
    }

    void OnGUI()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            GUIStyle style = new GUIStyle();
            style.fontSize = 30;
            style.normal.textColor = Color.red;
            style.alignment = TextAnchor.MiddleCenter;

            foreach (var pair in tileData)
            {
                Vector3 worldPosition = gridTilemap.GetCellCenterWorld(pair.Value);
                Vector2 screenPosition = Camera.main.WorldToScreenPoint(worldPosition);
                // string gridId = $"{pair.Key}-({pair.Value.x},{pair.Value.y})";
                string gridId = $"{pair.Key}";
                GUI.Label(new Rect(screenPosition.x - 50, Screen.height - screenPosition.y - 10, 100, 20), gridId, style);
            }
        }
    }

    void HandleLockGrid()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (EventSystem.current.IsPointerOverGameObject())
            {
                return;
            }
            Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            mouseWorldPos.z = 0;
            Vector3Int gridPos = gridTilemap.WorldToCell(mouseWorldPos);
            var grid_id = -1;
            Vector3Int newGridPos;
            for (int i = -2; i <= 2; i++)
            {
                newGridPos = new Vector3Int(gridPos.x + i, gridPos.y);
                grid_id = GetPointNumber(newGridPos.x, newGridPos.y);
                TileBase clickedTile = gridTilemap.GetTile(newGridPos);
                if (clickedTile != null)
                {
                    if (!dataService.IsUnlockGrid(grid_id))
                    {
                        int cloud_id = configService.MergeMapConfig[grid_id].cloud_id;
                        if (cloud_id == 0 || dataService.IsUnlockCloud(cloud_id))
                        {
                            BoxBuilder.ShowMergeUnlockGridPopup(grid_id);
                        }
                    }
                    break;
                }
            }
        }
    }

    void HandleMapDragging()
    {
        if (Input.touchCount >= 2)
        {
            _isMapDragging = false;
            return;
        }
        if (Input.GetMouseButtonDown(0))
        {
            if (EventSystem.current.IsPointerOverGameObject())
            {
                return;
            }

            Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mousePosition2D = new Vector2(mouseWorldPosition.x, mouseWorldPosition.y);
            RaycastHit2D hit = Physics2D.Raycast(mousePosition2D, Vector2.zero);
            if (hit.collider != null && !hit.collider.CompareTag(BubbleTag) && !hit.collider.CompareTag(HotAirBallTag) && !hit.collider.CompareTag(MergeTag))
            {
                _mapDragOrigin = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                _isMapDragging = true;
            }
        }

        if (Input.GetMouseButtonUp(0))
        {
            _isMapDragging = false;
        }

        if (_isMapDragging)
        {
            _mapDragPos = Camera.main.transform.position + (_mapDragOrigin - Camera.main.ScreenToWorldPoint(Input.mousePosition));
            if(_mapDragPos.x < -3065 )
                _mapDragPos.x = -3065;
            if(_mapDragPos.x > 4214 )
                _mapDragPos.x = 4214;
            if(_mapDragPos.y < -777 )
                _mapDragPos.y = -777;
            if(_mapDragPos.y > 3018 )
                _mapDragPos.y = 3018;

            Camera.main.transform.position = _mapDragPos;
            _cameraRecord.x = Camera.main.transform.position.x;
            _cameraRecord.y = Camera.main.transform.position.y;
            dataService.CameraRecord = _cameraRecord;
        }
    }

    void HandleMapZooming()
    {
        if (Input.GetKey(KeyCode.LeftControl))
        {
            float scrollData = Input.GetAxis("Mouse ScrollWheel");
            if (scrollData != 0)
                Zoom(scrollData, zoomSpeed);
        }

        if (Input.touchCount == 2)
        {
            Touch touch1 = Input.GetTouch(0);
            Touch touch2 = Input.GetTouch(1);

            Vector2 touch1PrevPos = touch1.position - touch1.deltaPosition;
            Vector2 touch2PrevPos = touch2.position - touch2.deltaPosition;

            float prevMagnitude = (touch1PrevPos - touch2PrevPos).magnitude;
            float currentMagnitude = (touch1.position - touch2.position).magnitude;

            Zoom((prevMagnitude - currentMagnitude) * 0.01f, zoomSpeed);
        }
    }

    void Zoom(float increment, float speed)
    {
        Vector3 mousePosition = Input.mousePosition;

        float screenWidth = Screen.width;
        float screenHeight = Screen.height;

        bool isInScreen = mousePosition.x >= 0 && mousePosition.x <= screenWidth &&
                          mousePosition.y >= 0 && mousePosition.y <= screenHeight;
        if (isInScreen)
            Camera.main.orthographicSize = Mathf.Clamp(Camera.main.orthographicSize - increment * speed, minZoom, maxZoom);

        _cameraRecord.z = Camera.main.orthographicSize;
        dataService.CameraRecord = _cameraRecord;
    }

    async Task HandleObjMoving()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (EventSystem.current.IsPointerOverGameObject())
            {
                selectedObject = null;
                selectedGridId = -1;
                _isBubbleDragging = false;
                selectedBubble = null;
                _isHotAirBallDragging = false;
                selectedHotAirBall = null;
                return;
            }
            Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mousePosition2D = new Vector2(mouseWorldPosition.x, mouseWorldPosition.y);

            RaycastHit2D[] hits = Physics2D.RaycastAll(mousePosition2D, Vector2.zero);
            if (hits.Length > 1)
            {
                bool touchBubble = false;
                bool touchHotAirBall = false;
                foreach (var hit in hits)
                {
                    if (hit.collider.gameObject != mapObj)
                    {
                        if (hit.collider.CompareTag(BubbleTag))
                        {
                            selectedBubble = hit.collider.gameObject;
                            _isBubbleDragging = true;
                            bubbleOffset = selectedBubble.transform.position - mouseWorldPosition;
                            touchBubble = true;
                            break;
                        }
                        else if (hit.collider.CompareTag(HotAirBallTag))
                        {
                            selectedHotAirBall = hit.collider.gameObject;
                            _isHotAirBallDragging = true;
                            hotAirBallOffset = selectedHotAirBall.transform.position - mouseWorldPosition;
                            touchHotAirBall = true;
                            break;
                        }
                    }
                }

                if (!touchBubble && !touchHotAirBall)
                {
                    _isBubbleDragging = false;
                    selectedBubble = null;
                    _isHotAirBallDragging = false;
                    selectedHotAirBall = null;
                    bool hitMergeItem = false;
                    Vector3 targetPos = new Vector3(0, int.MaxValue, 0);
                    foreach (var hit in hits)
                    {
                        if (hit.collider.CompareTag(MergeTag) && hit.collider.gameObject != mapObj &&
                            hit.collider.transform.position.y < targetPos.y)
                        {
                            var obj = hit.collider.gameObject;
                            if (!obj.GetComponent<MergeItem>().IsGray)
                            {
                                targetPos = hit.collider.transform.position;
                                hitMergeItem = true;
                                selectedObject = hit.collider.gameObject;
                                selectedObject.GetComponent<MergeItem>().HidePaoPao();
                            }
                        }
                    }
                    if (hitMergeItem)
                    {
                        _isObjDragging = true;
                        objOffset = selectedObject.transform.position - mouseWorldPosition;
                        selectedGridId = GetObjGridId(selectedObject);
                        SetItemSortOrder(selectedObject, TopLayerSort);
                        // selectedObject.GetComponent<MergeItem>().ShowPaoPao(TopLayerSort);
                    }
                    else
                    {
                        selectedObject = null;
                        selectedGridId = -1;
                    }
                }
            }
            else
            {
                selectedObject = null;
                selectedGridId = -1;
                _isBubbleDragging = false;
                selectedBubble = null;
                _isHotAirBallDragging = false;
                selectedHotAirBall = null;
            }
        }

        if (_isBubbleDragging && selectedBubble != null)
        {
            if (Input.GetMouseButton(0))
            {
                Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                Vector3 pos = mouseWorldPosition + bubbleOffset;
                selectedBubble.transform.position = pos;
                var bi = selectedBubble.GetComponent<BubbleItem>();
                dataService.MoveMergeBubble(bi.BubbleId, pos);
            }
        }

        else if (_isHotAirBallDragging && selectedHotAirBall != null)
        {
            if (Input.GetMouseButton(0))
            {
                Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                Vector3 pos = mouseWorldPosition + hotAirBallOffset;
                selectedHotAirBall.transform.position = pos;
                var bi = selectedHotAirBall.GetComponent<HotAirBallItem>();
                dataService.MoveMergeHotAirBall(bi.BallId, pos);
            }
        }

        else if (_isObjDragging && selectedObject != null)
        {
            if (Input.GetMouseButton(0))
            {
                Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                Vector3 pos = mouseWorldPosition + objOffset;
                pos.z = -1;
                selectedObject.transform.position = pos;
                MergeItem mi = selectedObject.GetComponent<MergeItem>();
                mi?.ShowSelected(true);

                var curMovingGridId = GetNearUnlockGridId(pos);
                if (curMovingGridId != movingGridId)
                {
                    foreach (var obj in canMergeObjList)
                    {
                        obj.GetComponent<MergeItem>()?.ShowSelected(false);
                    }
                    canMergeObjList.Clear();
                    movingGridId = curMovingGridId;
                    List<int> itemGrids = dataService.GetMergeGrids(selectedGridId, movingGridId);
                    if (itemGrids.Count >= 2)
                    {
                        foreach (var _gridId in itemGrids)
                        {
                            if (itemObjs.ContainsKey(_gridId))
                            {
                                var obj = itemObjs[_gridId];
                                obj.GetComponent<MergeItem>()?.ShowSelected(true);
                                canMergeObjList.Add(obj);
                            }
                        }
                    }

                    DragMergeItemEvent evt = GameObjManager.Instance.PopClass<DragMergeItemEvent>(true);
                    evt.itemId = mi.GetItemId();
                    TypeEventSystem.Send<DragMergeItemEvent>(evt);
                }
            }

            if (Input.GetMouseButtonUp(0))
            {
                Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                mouseWorldPosition.z = 0;
                var toGridId = GetNearUnlockGridId(selectedObject.transform.position);
                SetItemSortOrder(selectedObject, gridOrderSort[toGridId]);
                _isObjDragging = false;
                selectedObject.GetComponent<MergeItem>()?.ShowSelected(false);

                bool checkMerge = canMergeObjList.Count >= 2;
                foreach (var obj in canMergeObjList)
                {
                    obj.GetComponent<MergeItem>()?.ShowSelected(false);
                }
                canMergeObjList.Clear();

                if (checkMerge)
                {
                    int gridId1 = selectedGridId;
                    int gridId2 = toGridId;
                    List<int> removes;
                    List<Tuple<int, int>> adds;
                    var ret = dataService.DoMerge(gridId1, gridId2, out removes, out adds);
                    while (ret)
                    {
                        foreach (var item in removes)
                        {
                            RemoveItem(item, gridId2);
                        }
                        var newGridId = -1;
                        foreach (var item in adds)
                        {
                            CreateItem(item.Item1, item.Item2, gridId2, 0.3f);
                            if (newGridId == -1 && item.Item1 != toGridId)
                                newGridId = item.Item1;
                            _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_MergerGame_02.prefab", (obj) =>
                            {
                                obj.SetActive(true);
                                obj.transform.SetParent(transform);
                                obj.transform.position = GetGridCenterPos(item.Item1);
                                GameObject.Destroy(obj, 2f);
                            });
                        }
                        if (newGridId == -1)
                            break;

                        //屏蔽循环合成
                        break;
                        // await Task.Delay(500);
                        // ret = dataService.DoMerge(toGridId, newGridId, out removes, out adds);
                    }
                }
                else
                {
                    dataService.MoveMergeItem(selectedGridId, toGridId);
                }

                movingGridId = -1;

            }
        }
    }

    public Vector3 GetGridCenterPos(int gridId)
    {
        var pos = gridTilemap.GetCellCenterWorld(tileData[gridId]);
        pos.z = -1;
        return pos;
    }

    public int GetNewItemGridId()
    {
        int gridId = GetScreenCenterGridId();
        return gridId;
    }

    public int GetScreenCenterGridId()
    {
        Vector3 screenCenter = new Vector3(Screen.width / 2, Screen.height / 2, 0);
        Vector3 worldPosition = Camera.main.ScreenToWorldPoint(screenCenter);
        worldPosition.z = 0;
        return GetNearUnlockGridId(worldPosition);
    }

    public int GetPosGridId(Vector3 worldPosition)
    {
        worldPosition.z = 0;
        return GetNearUnlockGridId(worldPosition);
    }

    public void AddMoveObject(int fromGridId, int toGridId)
    {
        StartCoroutine(MoveObject(fromGridId, toGridId));
    }

    public IEnumerator MoveObject(int fromGridId, int toGridId)
    {
        // Debug.LogError($"MoveObject {fromGridId} => {toGridId}");
        moveEvents.Add(new Tuple<int, int>(fromGridId, toGridId));
        yield return new WaitForEndOfFrame();

        if (moveEvents.Count == 0)
            yield return null;

        List<GameObject> moveObjs = new List<GameObject>();
        List<int> moveFromGrids = new List<int>();
        List<int> moveToGrids = new List<int>();
        foreach (var item in moveEvents)
        {
            if (itemObjs.ContainsKey(item.Item1))
            {
                var obj = itemObjs[item.Item1];
                moveObjs.Add(obj);
                moveFromGrids.Add(item.Item1);
                moveToGrids.Add(item.Item2);

                float duration = Vector3.Distance(obj.transform.position, GetGridCenterPos(item.Item2)) / 800;
                duration = Math.Min(0.8f, duration);
                obj.transform.DOCurMove(GetGridCenterPos(item.Item2), duration);
                SetItemSortOrder(obj, gridOrderSort[item.Item2]);
            }
        }

        for (int i = 0; i < moveObjs.Count; i++)
        {
            var _fromoGridId = moveFromGrids[i];
            if (itemObjs.ContainsKey(_fromoGridId))
            {
                itemObjs.Remove(_fromoGridId);
            }
        }

        for (int i = 0; i < moveObjs.Count; i++)
        {
            var _obj = moveObjs[i];
            var _toGridId = moveToGrids[i];
            if (itemObjs.ContainsKey(_toGridId))
            {
                itemObjs[_toGridId] = _obj;
            }
            else
            {
                itemObjs.Add(_toGridId, _obj);
            }
            _obj.GetComponent<MergeItem>().GridId = _toGridId;
        }

        moveEvents.Clear();
    }

    public List<int> GetAroundGrids(int gridId, int shape = 11)
    {
        if (shape == 11)
        {
            int up = mapGraph[gridId][0];
            int down = mapGraph[gridId][1];
            int left = mapGraph[gridId][2];
            int right = mapGraph[gridId][3];
            return new List<int>() { up, down, left, right };
        }
        else if (shape == 21)
        {
            int up = mapGraph[gridId][0];
            int down = mapGraph[gridId][1];
            int left = mapGraph[gridId][2];
            int up2 = -1;
            int down2 = -1;
            int right2 = -1;
            int right = mapGraph[gridId][3];
            if (right != -1)
            {
                up2 = mapGraph[right][0];
                down2 = mapGraph[right][1];
                right2 = mapGraph[right][3];
            }
            var grids = new List<int>();
            grids.Add(up);
            grids.Add(down);
            grids.Add(left);
            grids.Add(up2);
            grids.Add(down2);
            grids.Add(right2);
            return grids;
        }
        else if (shape == 22)
        {
            int up1 = -1;
            int up2 = -1;
            int down1 = mapGraph[gridId][1];
            int down2 = -1;
            int left1 = -1;
            int left2 = mapGraph[gridId][2];
            int right1 = -1;
            int right2 = -1;

            int temp = mapGraph[gridId][3];
            if (temp != -1)
            {
                down2 = mapGraph[temp][1];
                right2 = mapGraph[temp][3];
            }
            temp = mapGraph[gridId][0];
            if (temp != -1)
            {
                left1 = mapGraph[temp][2];
                up1 = mapGraph[temp][0];
                temp = mapGraph[temp][3];
                if (temp != -1)
                {
                    up2 = mapGraph[temp][0];
                    right1 = mapGraph[temp][3];
                }
            }
            var grids = new List<int>();
            grids.Add(up1);
            grids.Add(up2);
            grids.Add(down1);
            grids.Add(down2);
            grids.Add(left1);
            grids.Add(left2);
            grids.Add(right1);
            grids.Add(right2);
        }

        return new List<int>() { };
    }

    public List<int> GetNearShapeGrids(int gridId, int shape = 11)
    {
        if (shape == 11)
        {
            int up = mapGraph[gridId][0];
            int down = mapGraph[gridId][1];
            int left = mapGraph[gridId][2];
            int right = mapGraph[gridId][3];
            return new List<int>() { up, down, left, right };
        }
        else if (shape == 21)
        {
            var grids = new List<int>();
            // var _shape = new List<int> { gridId, mapGraph[gridId][3] };
            var _shape = new List<int> { gridId };
            foreach (var _grid_id in _shape)
            {
                if (_grid_id == -1)
                    continue;
                int up = mapGraph[_grid_id][0];
                int down = mapGraph[_grid_id][1];
                int left = mapGraph[_grid_id][2];
                if (left != -1)
                {
                    left = mapGraph[left][2];
                }
                int right = mapGraph[_grid_id][3];
                if (right != -1)
                {
                    right = mapGraph[right][3];
                }
                grids.Add(up);
                grids.Add(down);
                grids.Add(left);
                grids.Add(right);
            }
            return grids;
        }
        else if (shape == 22)
        {
            var grids = new List<int>();
            var _shape = new List<int> { gridId };
            // int _shape_up = mapGraph[gridId][0];
            // int _shape_right = mapGraph[gridId][3];
            // int _shape_right_up = -1;
            // if (_shape_right != -1)
            //     _shape_right_up = mapGraph[_shape_right][0];
            // _shape.Add(_shape_up);
            // _shape.Add(_shape_right);
            // _shape.Add(_shape_right_up);
            foreach (var _grid_id in _shape)
            {
                if (_grid_id == -1)
                    continue;
                int up = mapGraph[_grid_id][0];
                if (up != -1)
                {
                    up = mapGraph[up][0];
                }
                int down = mapGraph[_grid_id][1];
                if (down != -1)
                {
                    down = mapGraph[down][1];
                }
                int left = mapGraph[_grid_id][2];
                if (left != -1)
                {
                    left = mapGraph[left][2];
                }
                int right = mapGraph[_grid_id][3];
                if (right != -1)
                {
                    right = mapGraph[right][3];
                }
                grids.Add(up);
                grids.Add(down);
                grids.Add(left);
                grids.Add(right);
            }
            return grids;
        }

        return new List<int>() { -1, -1, -1, -1 };
    }

    public int GetUpGrid(int gridId)
    {
        if (!mapGraph.ContainsKey(gridId))
            return -1;
        var upGridId = mapGraph[gridId][0];
        return upGridId;
    }

    public int GetDownGrid(int gridId)
    {
        if (!mapGraph.ContainsKey(gridId))
            return -1;
        var downGridId = mapGraph[gridId][1];
        return downGridId;
    }

    public int GetLeftGrid(int gridId)
    {
        if (!mapGraph.ContainsKey(gridId))
            return -1;
        var leftGridId = mapGraph[gridId][2];
        return leftGridId;
    }

    public int GetRightGrid(int gridId)
    {
        if (!mapGraph.ContainsKey(gridId))
            return -1;
        var rightGridId = mapGraph[gridId][3];
        return rightGridId;
    }

    public int GetNextItemId(int itemId)
    {
        return configService.MergeItemConfig[itemId].nextItemId;
    }

    public List<Tuple<int, int>> GetRegionStartGridIds()
    {
        return regionStartGridIds;
    }

    public int GetItemSortOrder(int grid_id)
    {
        return gridOrderSort[grid_id];
    }

    private void SetItemSortOrder(GameObject obj, int sortOrder)
    {
        var sprites = obj.GetComponentsInChildren<SpriteRenderer>();
        var _sortOrder = sortOrder;
        foreach (var item in sprites)
        {
            if (item.name.StartsWith("paopao_"))
                continue;
            _sortOrder = Math.Min(_sortOrder, TopLayerSort);
            _sortOrder = Math.Max(_sortOrder, 1);
            item.sortingOrder = _sortOrder;
            if (item.name.StartsWith("Selected"))
                item.sortingOrder = 0;
        }
        var sortGroups = obj.GetComponentsInChildren<SortingGroup>();
        foreach (var item in sortGroups)
        {
            _sortOrder = Math.Min(_sortOrder, TopLayerSort);
            _sortOrder = Math.Max(_sortOrder, 1);
            item.sortingOrder = _sortOrder;
        }

        var ps = obj.GetComponentsInChildren<ParticleSystem>(true);
        foreach (var p in ps)
        {
            ParticleSystemRenderer r = p.GetComponent<ParticleSystemRenderer>();
            r.sortingLayerName = "Merge";
            r.sortingOrder = sortOrder + 1;
        }
    }

    private void MoveSightToGrid()
    {

    }

    public Vector3 GetGridWorldPos(int gridId)
    {
        Vector3 pos = gridTilemap.GetCellCenterWorld(tileData[gridId]);
        return pos;
    }

    public void SetTouchAble(bool able)
    {
        touchAble = able;
    }
}
