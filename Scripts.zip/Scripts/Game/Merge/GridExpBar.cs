using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.Rendering;

public class GridExpBar : MonoBehaviour
{

    public TextMeshPro proText;
    public SpriteRenderer proBgSprite;
    public SpriteRenderer proFgSprite;


    void Start()
    {

    }

    public void Show(int pro_ori, int pro_now, int pro_max, float time, int layer_sort)
    {
        proText.text = $"{pro_ori} / {pro_max}";
        float pro = pro_ori;
        var size = proFgSprite.size;
        proFgSprite.size = new Vector2(120 * (pro_ori / (float)pro_max), size.y);
        DOTween.To(() => pro, x =>
        {
            pro = x;
            proText.text = $"{(int)pro} / {pro_max}";
            proFgSprite.size = new Vector2(120 * (pro / (float)pro_max), size.y);
        }, pro_now, time);

        var textSort = proText.GetComponent<SortingGroup>();
        textSort.sortingOrder = layer_sort - 1;
        proBgSprite.sortingOrder = layer_sort - 1;
        proFgSprite.sortingOrder = layer_sort;
        GameObject.Destroy(gameObject, time + 0.3f);
    }
}
