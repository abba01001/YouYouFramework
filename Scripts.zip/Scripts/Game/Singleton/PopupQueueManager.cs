using System;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using QFramework;
using SoliUtils;

public class TaskData
{
    public enum TaskType
    {
        Popup,
        Tween
    }
    public TaskType Type { get; }
    public Action Action { get; }
    public int Priority { get; set; }

    public TaskData(TaskType type, Action action, int inputPriority = 0)
    {
        Type = type;
        Action = action;
        Priority = inputPriority;
    }
}

public class PopupQueueManager : MonoBehaviour,ISingleton
{
    private float checkInterval = 0.04f; // 检测间隔秒数
    private float elapsedTime = 0f;
    private List<TaskData> taskList = new List<TaskData>();
    private List<TaskData> readyAddTaskList = new List<TaskData>();
    private bool isHandlingQueue = false;
    public static PopupQueueManager Instance
    {
        get { return MonoSingletonProperty<PopupQueueManager>.Instance; }
    }
    
    public void OnSingletonInit()
    {
    }
    
    public void Init()
    {
        Debug.Log("PopupQueueManager.Init");
    }
    
    private void Update()
    {
        elapsedTime += Time.deltaTime;

        if (elapsedTime >= checkInterval)
        {
            HandleReadyAddTaskList(); // 检查准备添加的任务
            HandleTaskQueue(); // 处理任务队列
            elapsedTime = 0f; // 重置计时器
        }
    }

    // 添加弹窗任务
    public void AddPopupTask(string popupName, Action action, bool isInsert = false, int inputPriority = 999)
    {
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        if (popupName == Constants.DoozyView.RewardPopup) isInsert = true;
        var task = new TaskData(TaskData.TaskType.Popup, () => ViewQueueManager.Instance.AddWaitPopupViewClose(popupName, action,isInsert), inputPriority);
        // 检查优先级
        if (configService.PopupPriorityConfig.TryGetValue(popupName, out PopupPriorityModel model))
        {
            task.Priority = model.priority;
        }
        readyAddTaskList.Add(task);
    }
    
    // 添加Tween任务
    public void AddTweenTask(Func<Tween> tweenFunc, int priority = 999)
    {
        var task = new TaskData(TaskData.TaskType.Tween, () => ViewQueueManager.Instance.AddWaitTween(tweenFunc), priority);
        readyAddTaskList.Add(task);
    }

    private void HandleReadyAddTaskList()
    {
        foreach (var data in readyAddTaskList)
        {
            taskList.Add(data);
        }
        readyAddTaskList.Clear(); // 清空已处理的列表
    }

    private void HandleTaskQueue()
    {
        if (isHandlingQueue || taskList.Count == 0)
            return;
        isHandlingQueue = true;
        taskList.Sort((a, b) => a.Priority.CompareTo(b.Priority));

        foreach (var taskData in taskList)
        {
            taskData.Action.Invoke();
        }
        taskList.Clear();
        isHandlingQueue = false; // 处理完成
    }
}
