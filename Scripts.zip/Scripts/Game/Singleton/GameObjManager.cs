using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using QFramework;
using UniRx;
using UnityEngine;
using SoliUtils;

public enum GameObjType
{
    None,
    ValueCard,
    BoomCard,
    ZapCard,
    LockCard,
    KeyCard,
    ThreeCard,
    AnchorCard,
    WindmillCard,
    GoldCard,
    JokerCard,
    MonochromeCard,
    TwoValueCard,
    CopyCard,
    BananaCard,
    MonkeyCard,
    QuestionCard,
    RudderCard,
    CannonCard,

    BombMod,
    BigBombMod,
    IceMod,
    LoweringMod,
    RisingMod,
    WaterMod,
    LightningMod,
    GreenLeafMod,
    Bird,
    VictoryCoin,
    TreasureGrid,
    TreasureReward,
    LavaHead,
    ClothMod,
    MagicClothMod,
    SuitRopeMod,
    CoinMod,
    LizardMod,
    TaskMod,

    EmailTagItem,
    DialogueItem,
    CoinItem,
    BuildCoinItem,
    FlowAddGold,
    FlowAddFarmingCollect,
    HomeFlowAdd,
    FlyStarItem,
    FlyFlowerItem,
    FlyLoveCardItem,
    FlyFarmingItem,
    AddCoinTextFx,
    StartTuoWeiFx,
    WinStreakBoxFx,
    LavaDropFx,
    TreasureFlyReward,
    CollectItemFx,
    RewardItem,
    BubbleRewardItem,
    BubbleItem,
    RookieTipItem,
    PassRankItem,
    CarRankItem,
    EndlessLevelRankItem,
    CollectFlowerItem,
    LoveCardItem,
    AdRewardItem,
    SeasonPassItem,
    HomeMapItem,
    BigShopItem,
    LimitShopItem,
    PassShopItem,
    SmallShopItem,
    SeasonPassShopItem,
    StartActivityItem,
    IllustratedNPCItem,
    IllustratedGoodsItem,
    RedDotItem,
    RewardBoxItem,
    GemStoneAnimItem,
    UnlockMergeTipItem,
}

public class GameObjTypeMono : MonoBehaviour
{
    public GameObjType gameObjType;
}

public class ClassPoolObject<T>
{
    public T GameObject { get; set; }
    public DateTime Timestamp { get; set; }
    public ClassPoolObject(T obj)
    {
        GameObject = obj;
        Timestamp = DateTime.Now;
    }
}

[MonoSingletonPath("[Singleton]/GameObjManager")]
public class GameObjManager : MonoBehaviour, ISingleton
{
    private Dictionary<GameObjType, GameObject> _goTypeResDic = new Dictionary<GameObjType, GameObject>();
    private Dictionary<GameObjType, Stack<GameObject>> _poolDic = new Dictionary<GameObjType, Stack<GameObject>>();
    private Dictionary<GameObjType, GameObject> _singlePoolDic = new Dictionary<GameObjType, GameObject>();
    private Dictionary<Type, Stack<object>> _classPool = new Dictionary<Type, Stack<object>>();

    private float poolLifeTime = 5f;//池物体存活时间秒数
    private float checkInterval = 10f; //检测间隔秒数
    private float elapsedTime = 0f;
    public static GameObjManager Instance
    {
        get { return MonoSingletonProperty<GameObjManager>.Instance; }
    }

    public void Init()
    {
        Debug.Log("GameObjManager.Init");
    }

    private void Update()
    {
        elapsedTime += Time.deltaTime;
        if (elapsedTime >= checkInterval)
        {
            CheckDestroyPoolObject();
            elapsedTime = 0f;
        }
    }

    //TODO 释放资源
    private static void CheckDestroyPoolObject()
    {

    }

    public void PrintPoolInfo()
    {
        StringBuilder builder = new StringBuilder();
        builder.AppendLine("池信息：");
        foreach (var pair in _poolDic)
        {
            GameObjType type = pair.Key;
            Stack<GameObject> stack = pair.Value;
            builder.AppendLine($"类型: {type}, 数量: {stack.Count}");
        }
        GameUtils.LogError(builder.ToString());
    }

    public static bool IsNull()
    {
        return MonoSingletonProperty<GameObjManager>.IsNull();
    }

    public void OnSingletonInit()
    {
        //        _goTypeResDic.Add(GameObjType.ValueCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/ValueCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.BoomCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/BoomCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.ZapCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/ZapCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.LockCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/LockCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.KeyCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/KeyCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.ThreeCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/ThreeCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.AnchorCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/AnchorCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.WindmillCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/WindmillCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.GoldCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/GoldCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.JokerCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/JokerCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.MonochromeCard, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/MonochromeCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.TwoValueCard,GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/TwoValueCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.CopyCard,GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/CopyCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.BananaCard,GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/BananaCard.prefab"));
        //        _goTypeResDic.Add(GameObjType.MonkeyCard,GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/MonkeyCard.prefab"));
        //        
        //        _goTypeResDic.Add(GameObjType.BombMod, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/BombMod.prefab"));
        //        _goTypeResDic.Add(GameObjType.IceMod, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/IceMod.prefab"));
        //        _goTypeResDic.Add(GameObjType.LoweringMod, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/LoweringMod.prefab"));
        //        _goTypeResDic.Add(GameObjType.RisingMod, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/RisingMod.prefab"));
        //        _goTypeResDic.Add(GameObjType.WaterMod, GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/WaterMod.prefab"));
        //
        //        _goTypeResDic.Add(GameObjType.DialogueItem, GlobalRes.Load<GameObject>("Assets/Res/Prefabs/Item/DialogueItem.prefab"));
        //        _goTypeResDic.Add(GameObjType.CoinItem, GlobalRes.Load<GameObject>("Assets/Res/Prefabs/FX/jinbi_zhuan_01_0.prefab"));
        //        _goTypeResDic.Add(GameObjType.FlowAddGold, GlobalRes.Load<GameObject>("Assets/Res/Prefabs/Item/FlowAddGold.prefab"));
        //        _goTypeResDic.Add(GameObjType.FlyStarItem, GlobalRes.Load<GameObject>("Assets/Res/Prefabs/FX/xing_fei.prefab"));
        //        _goTypeResDic.Add(GameObjType.AddCoinTextFx, GlobalRes.Load<GameObject>("Assets/Res/Prefabs/FX/jinbi_ziyuan_tx_01.prefab"));
        //        _goTypeResDic.Add(GameObjType.WinStreakBoxFx, GlobalRes.Load<GameObject>("ArtRes/Prefabs/FX/combox.prefab"));
    }

    Dictionary<GameObjType, string> mapPre = new Dictionary<GameObjType, string>
    {
        [GameObjType.DialogueItem] = "Assets/Res/Prefabs/Item/DialogueItem.prefab",
        [GameObjType.CoinItem] = "Assets/Res/Prefabs/FX/jinbi_zhuan_01_0.prefab",
        [GameObjType.BuildCoinItem] = "Assets/Res/Prefabs/FX/jianzaobi_zhuan_01_0.prefab",
        [GameObjType.FlowAddGold] = "Assets/Res/Prefabs/Item/FlowAddGold.prefab",
        [GameObjType.BubbleItem] = "Assets/Res/Prefabs/Item/BubbleItem.prefab",
        [GameObjType.StartActivityItem] = "Assets/Res/Prefabs/Item/StartActivityItem.prefab",
        [GameObjType.FlowAddFarmingCollect]  = "Assets/Res/Prefabs/Item/FarmingAddGold.prefab",
        [GameObjType.HomeFlowAdd] = "Assets/Res/Prefabs/Item/HomeFlowAdd.prefab",
        [GameObjType.FlyStarItem] = "Assets/Res/Prefabs/FX/xing_fei.prefab",
        [GameObjType.FlyFlowerItem] = "Assets/Res/Prefabs/FX/flower_fei.prefab",
        [GameObjType.FlyLoveCardItem] = "Assets/Res/Prefabs/FX/card_fei.prefab",
        [GameObjType.FlyFarmingItem] = "Assets/Res/Prefabs/FX/farming_collect.prefab",
        [GameObjType.AddCoinTextFx] = "Assets/Res/Prefabs/FX/jinbi_ziyuan_tx_01.prefab",
        [GameObjType.StartTuoWeiFx] = "Assets/Res/Prefabs/FX/star_tuowei_tx_01.prefab",
        //[GameObjType.WinStreakBoxFx] = "Assets/Res/ArtRes/Prefabs/FX/combox.prefab",
        [GameObjType.CoinMod] = "Assets/Res/Cards/Prefabs/CoinMod.prefab",
        [GameObjType.RedDotItem] = "Assets/Res/Prefabs/Item/RedDotItem.prefab",
        [GameObjType.RewardBoxItem] = "Assets/Res/Prefabs/Item/RewardBoxItem.prefab",
        [GameObjType.GemStoneAnimItem] = "Assets/Res/Prefabs/Item/GemStoneAnimItem.prefab",
        [GameObjType.UnlockMergeTipItem] = "Assets/Res/Prefabs/Item/UnlockMergeTipItem.prefab",
        
    };

    Dictionary<GameObjType, string> map = new Dictionary<GameObjType, string>
    {
        [GameObjType.ValueCard] = "Assets/Res/Cards/Prefabs/ValueCard.prefab",
        [GameObjType.BoomCard] = "Assets/Res/Cards/Prefabs/BoomCard.prefab",
        [GameObjType.ZapCard] = "Assets/Res/Cards/Prefabs/ZapCard.prefab",
        [GameObjType.LockCard] = "Assets/Res/Cards/Prefabs/LockCard.prefab",
        [GameObjType.KeyCard] = "Assets/Res/Cards/Prefabs/KeyCard.prefab",
        [GameObjType.ThreeCard] = "Assets/Res/Cards/Prefabs/ThreeCard.prefab",
        [GameObjType.AnchorCard] = "Assets/Res/Cards/Prefabs/AnchorCard.prefab",
        [GameObjType.WindmillCard] = "Assets/Res/Cards/Prefabs/WindmillCard.prefab",
        [GameObjType.GoldCard] = "Assets/Res/Cards/Prefabs/GoldCard.prefab",
        [GameObjType.JokerCard] = "Assets/Res/Cards/Prefabs/JokerCard.prefab",
        [GameObjType.MonochromeCard] = "Assets/Res/Cards/Prefabs/MonochromeCard.prefab",
        [GameObjType.TwoValueCard] = "Assets/Res/Cards/Prefabs/TwoValueCard.prefab",
        [GameObjType.CopyCard] = "Assets/Res/Cards/Prefabs/CopyCard.prefab",
        [GameObjType.BananaCard] = "Assets/Res/Cards/Prefabs/BananaCard.prefab",
        [GameObjType.MonkeyCard] = "Assets/Res/Cards/Prefabs/MonkeyCard.prefab",
        [GameObjType.QuestionCard] = "Assets/Res/Cards/Prefabs/QuestionCard.prefab",
        [GameObjType.RudderCard] = "Assets/Res/Cards/Prefabs/RudderCard.prefab",
        [GameObjType.CannonCard] = "Assets/Res/Cards/Prefabs/CannonCard.prefab",

        [GameObjType.BombMod] = "Assets/Res/Cards/Prefabs/BombMod.prefab",
        [GameObjType.BigBombMod] = "Assets/Res/Cards/Prefabs/BigBombMod.prefab",
        [GameObjType.IceMod] = "Assets/Res/Cards/Prefabs/IceMod.prefab",
        [GameObjType.LoweringMod] = "Assets/Res/Cards/Prefabs/LoweringMod.prefab",
        [GameObjType.RisingMod] = "Assets/Res/Cards/Prefabs/RisingMod.prefab",
        [GameObjType.WaterMod] = "Assets/Res/Cards/Prefabs/WaterMod.prefab",
        [GameObjType.LightningMod] = "Assets/Res/Cards/Prefabs/LightningMod.prefab",
        [GameObjType.GreenLeafMod] = "Assets/Res/Cards/Prefabs/GreenLeafMod.prefab",
        [GameObjType.Bird] = "Assets/Res/Cards/Prefabs/Bird.prefab",
        [GameObjType.ClothMod] = "Assets/Res/Cards/Prefabs/ClothMod.prefab",
        [GameObjType.MagicClothMod] = "Assets/Res/Cards/Prefabs/MagicClothMod.prefab",
        [GameObjType.SuitRopeMod] = "Assets/Res/Cards/Prefabs/SuitRopeMod.prefab",
        [GameObjType.LizardMod] = "Assets/Res/Cards/Prefabs/LizardMod.prefab",
        [GameObjType.TaskMod] = "Assets/Res/Cards/Prefabs/TaskMod.prefab",
    };

    private Dictionary<GameObjType, string> singleMap = new Dictionary<GameObjType, string>
    {
        [GameObjType.StartActivityItem] = Constants.ItemNamePath.StartActivityItem,
    };

    public async Task PreLoad()
    {
        Debug.Log(">>> GameObjManager >> PreLoad ... LoadStart");
        foreach (var item in mapPre)
        {
            var go = await AddressableUtils.LoadAsync<GameObject>(item.Value);
            _goTypeResDic.TryAdd(item.Key, go);
        }
        Debug.Log(">>> GameObjManager >> PreLoad ... LoadFinish");
    }

    public async void LoadCardsObj()
    {
        Debug.Log(">>> GameObjManager >> LoadCardsObj ... LoadStart");
        foreach (var item in map)
        {
            var go = await AddressableUtils.LoadAsync<GameObject>(item.Value);
            _goTypeResDic.TryAdd(item.Key, go);
        }
        Debug.Log(">>> GameObjManager >> LoadCardsObj ... LoadFinish");
    }

    // 打印类池内容
    public void PrintClassPool()
    {
        StringBuilder sb = new StringBuilder();
        foreach (var kvp in _classPool)
        {
            sb.AppendLine($"类名:{kvp.Key.Name}个数:{kvp.Value.Count}");
        }
        GameUtils.LogError("类池内容:\n" + sb.ToString());
    }

    public T PopClass<T>(bool autoPush = false) where T : class, new()
    {
        void AutoPushInPool(bool autoPush, T t)
        {
            if (!autoPush) return;
            UniRx.Observable.Timer(TimeSpan.FromSeconds(10f)).Subscribe(_ =>
            {
                PushClass(t);
            });
        }
        Type type = typeof(T);
        T t = null;
        if (_classPool.ContainsKey(type) && _classPool[type].Count > 0)
        {
            t = (T)_classPool[type].Pop();
            AutoPushInPool(autoPush, t);
            return t;
        }
        else
        {
            t = new T();
            AutoPushInPool(autoPush, t);
            return t;
        }
    }

    public void PushClass<T>(T obj) where T : class
    {
        Type type = typeof(T);
        if (!_classPool.ContainsKey(type))
        {
            _classPool[type] = new Stack<object>();
        }
        _classPool[type].Push(obj);
    }

    public bool CheckPoolHasGameObject(GameObjType gotype)
    {
        if (_poolDic.TryGetValue(gotype, out var stack))
        {
            if (stack.Count > 0)
            {
                return true;
            }
        }
        else
        {
            return false;
        }
        return false;
    }

    public GameObject PopGameObject(GameObjType gotype, GameObject obj)
    {
        if (_poolDic.TryGetValue(gotype, out var stack))
        {
            if (stack.Count > 0)
            {
                return stack.Pop();
            }
        }
        else
        {
            _poolDic.Add(gotype, new Stack<GameObject>());
        }
        var newObj = Instantiate(obj, transform);
        newObj.AddComponent<GameObjTypeMono>().gameObjType = gotype;
        newObj.SetActive(false);
        return newObj;
    }

    public void PopSingleGameObject(GameObjType gotype,Action<GameObject> action)
    {
        if (_singlePoolDic.TryGetValue(gotype, out var obj))
        {
            action(obj);
            _singlePoolDic.Remove(gotype);
            return;
        }
        if (singleMap.TryGetValue(gotype, out string assetPath))
        {
            GlobalRes.DynamicLoadPrefab(assetPath, (obj) =>
            {
                obj.AddComponent<GameObjTypeMono>().gameObjType = gotype;
                action(obj);
            });
        }
    }

    public void PushSingleGameObject(GameObject obj)
    {
        var gameObjTypeMono = obj.GetComponent<GameObjTypeMono>();
        if (gameObjTypeMono == null)
        {
            Destroy(obj);
            return;
        }
        var gotype = gameObjTypeMono.gameObjType;
        obj.transform.SetParent(transform, false);
        obj.SetActive(false);
        _singlePoolDic.TryAdd(gotype,obj);
    }
    
    public GameObject PopGameObject(GameObjType gotype)
    {
        if (_poolDic.TryGetValue(gotype, out var stack))
        {
            if (stack.Count > 0)
            {
                return stack.Pop();
            }
        }
        else
        {
            _poolDic.Add(gotype, new Stack<GameObject>());
        }

        if (!_goTypeResDic.ContainsKey(gotype))
        {
            string res = mapPre.TryGetValue(gotype, out var value) ? value : map[gotype];
            _goTypeResDic.Add(gotype, GlobalRes.Load<GameObject>(res));
        }
        var go = _goTypeResDic[gotype];
        var newObj = Instantiate(go, transform);
        newObj.AddComponent<GameObjTypeMono>().gameObjType = gotype;
        newObj.SetActive(false);
        return newObj;
    }

    public async void PushGameObject(GameObject obj, int delay = 0)
    {
        var gameObjTypeMono = obj.GetComponent<GameObjTypeMono>();
        if (gameObjTypeMono == null)
        {
            Destroy(obj);
            return;
        }
        if (delay != 0)
        {
            await UniTask.Delay(delay * 1000);
        }
        
        var gotype = gameObjTypeMono.gameObjType;
        if(!_poolDic.ContainsKey(gotype)) return;
        var stack = _poolDic[gotype];
        foreach (var item in stack)
        {
            if(item == obj)
            {
                return;
            }
        }
        obj.transform.SetParent(transform, false);
        obj.SetActive(false);
        stack.Push(obj);
    }

    public bool CheckGoHasPreLoad(GameObjType gameObjType)
    {
        return _goTypeResDic.ContainsKey(gameObjType);
    }

    public GameObject Instantiate(string res)
    {
        return Instantiate(GlobalRes.Load<GameObject>(res));
    }
}