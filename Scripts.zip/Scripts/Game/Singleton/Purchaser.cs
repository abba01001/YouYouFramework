// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;
// using UnityEngine.Purchasing;
// using QFramework;
// using System;
// using System.Linq;
//
// [MonoSingletonPath("[Singleton]/Purchaser")]
// public class Purchaser : MonoBehaviour, ISingleton, IStoreListener
// {
//     class ProductInitInfo
//     {
//         public string productKey;
//         public string productID;
//         public ProductType productType;
//
//         public ProductInitInfo(string key, string id, ProductType type)
//         {
//             productKey = key;
//             productID = id;
//             productType = type;
//         }
//     }
//
//     private IStoreController mStoreController;
//     private IExtensionProvider mExtensionProvider;
//     private SubscriptionManager vipSubscriptionMgr;
//
//     public const string FirstChargeProductKey = "product_1";
//     public const string BattlePassProductKey = "product_season";
//     private static readonly Dictionary<string, ProductInitInfo> ProductDic = new Dictionary<string, ProductInitInfo>()
//     {
//         { FirstChargeProductKey,  new ProductInitInfo("product_1", "com.eyu.solitaire.product_1", ProductType.Consumable) },
//         { "product_2",  new ProductInitInfo("product_2", "com.eyu.solitaire.product_2", ProductType.Consumable) },
//         { "product_3",  new ProductInitInfo("product_3", "com.eyu.solitaire.product_3", ProductType.Consumable) },
//         { "product_4",  new ProductInitInfo("product_4", "com.eyu.solitaire.product_4", ProductType.Consumable) },
//         { "product_5",  new ProductInitInfo("product_5", "com.eyu.solitaire.product_5", ProductType.Consumable) },
//         { "product_6",  new ProductInitInfo("product_6", "com.eyu.solitaire.product_6", ProductType.Consumable) },
//         { "product_7",  new ProductInitInfo("product_7", "com.eyu.solitaire.product_7", ProductType.Consumable) },
//         { "product_8",  new ProductInitInfo("product_8", "com.eyu.solitaire.product_8", ProductType.Consumable) },
//         { "product_9",  new ProductInitInfo("product_9", "com.eyu.solitaire.product_9", ProductType.Consumable) },
//         { "product_saver",  new ProductInitInfo("product_saver", "com.eyu.solitaire.product_saver", ProductType.Consumable) },
//         { "product_wheel",  new ProductInitInfo("product_wheel", "com.eyu.solitaire.product_wheel", ProductType.Consumable) },
//         { BattlePassProductKey,  new ProductInitInfo("product_season", "com.eyu.solitaire.product_season", ProductType.Consumable) },
//         { "one_month_vip",  new ProductInitInfo("one_month_vip", "com.eyu.solitaire.one_month_vip", ProductType.Consumable) },
//         { "trigger_1",  new ProductInitInfo("trigger_1", "com.eyu.solitaire.trigger_1", ProductType.Consumable) },
//         { "trigger_2",  new ProductInitInfo("trigger_2", "com.eyu.solitaire.trigger_2", ProductType.Consumable) },
//         { "trigger_3",  new ProductInitInfo("trigger_3", "com.eyu.solitaire.trigger_3", ProductType.Consumable) },
//
//         { "vip_2",  new ProductInitInfo("vip_2", "com.eyu.solitaire.vip_2", ProductType.Subscription) },
//     };
//
//     public void Init()
//     {
//         Debug.Log("MonoBehaviour.Init");
//     }
//
//     public static bool IsNull()
//     {
//         return MonoSingletonProperty<Purchaser>.IsNull();
//     }
//     
//     public static Purchaser Instance
// 	{
// 		get { return MonoSingletonProperty<Purchaser>.Instance; }
// 	}
// 	
// 	public void OnSingletonInit()
//     {
//     }
//     
//     // Start is called before the first frame update
//     void Start()
//     {
//         InitPurchasing();
//     }
//
//     IGooglePlayStoreExtensions m_AppleExtensions;
//     public void InitPurchasing()
//     {
//         return;
//         //   Use the `GoogleProductMetadata` of `product.metadata.GetGoogleProductMetadata()` from `IStoreController.products`"
//         //m_AppleExtensions.GetProductJSONDictionary();
//         //string intro_json = (introductory_info_dict == null || !introductory_info_dict.ContainsKey(item.definition.storeSpecificId)) ? null : introductory_info_dict[item.definition.storeSpecificId];
//
//         if (IsInitialized()) return;
//         Debug.Log("Purchaser InitPurchasing");
//         var builder = ConfigurationBuilder.Instance(StandardPurchasingModule.Instance());
//         //添加商品ID和类型 对应定义的商品ID
//         foreach (var item in ProductDic.Values)
//             builder.AddProduct(item.productID, item.productType, new IDs { { item.productID, GooglePlay.Name } });
//
//         UnityPurchasing.Initialize(this, builder);
//     }
//
//     public void BuyProduct(string productKey)
//     {
//         var msg = new Dictionary<string, object> { { AnalyticsKey.PurchaseSku, productKey } };
//         AnalyticeUtils.ReportEvent(AnalyticsKey.SoliClickPurchase, msg);
//         if (!IsInitialized())
//         {
//             Debug.Log("Purchaser, GetProduct FAIL. Not initialized.");
//             TypeEventSystem.Send<PurchaseFailed>(new PurchaseFailed(null, PurchaseFailureReason.PurchasingUnavailable));
//             return;
//         }
//         if (!ProductDic.ContainsKey(productKey))
//         {
//             Debug.Log("Error ProductID FAIL.");
//             TypeEventSystem.Send<PurchaseFailed>(new PurchaseFailed(null, PurchaseFailureReason.ProductUnavailable));
//             return;
//         }
//
//         Product produdt = mStoreController.products.WithID(ProductDic[productKey].productID);
//         if (produdt != null && produdt.availableToPurchase)
//         {
//             mStoreController.InitiatePurchase(produdt);
//         }
//         else
//         {
//             Debug.Log("fail");
//         }
//     }
//
//     public Product GetProduct(string productKey)
//     {
//         if (IsInitialized())
//         {
//             return mStoreController.products.WithID(ProductDic[productKey].productID);
//         }
//         else
//         {
//             Debug.Log("Purchaser, GetProduct FAIL. Not initialized.");
//             return null;
//         }
//     }
//
//     public string GetProductID(string productKey) => ProductDic.ContainsKey(productKey) ? ProductDic[productKey].productID : null;
//     public string GetProductKey(Product product) => GetProductKey(product.definition.id);
//     public string GetProductKey(string productID) => ProductDic.FirstOrDefault((x) => x.Value.productID == productID).Key;
//
//     //恢复购买
//     public void ReSotre()
//     {
//         if (!IsInitialized())
//         {
//             return;
//         }
//  
//         if (mExtensionProvider != null&& (Application.platform == RuntimePlatform.IPhonePlayer|| Application.platform == RuntimePlatform.OSXPlayer))
//         {
//             var apple = mExtensionProvider.GetExtension<IAppleExtensions>();
//             apple.RestoreTransactions((result) =>
//             {
//                 // Restore purchases initiated. See ProcessPurchase for any restored transacitons.
//                 Debug.Log("Purchaser, RestorePurchases continuing: " + result + ". If no further messages, no purchases available to restore.");
//             });
//         }
//     }
//  
//     public bool IsInitialized()
//     {
//         return mStoreController != null && mExtensionProvider != null;
//     }
//
//     public void OnInitialized(IStoreController controller, IExtensionProvider extensions)
//     {
//         mStoreController = controller;
//         mExtensionProvider = extensions;
//         RefreshVipState("one_month_vip", false);
//     }
//
//     public void OnInitializeFailed(InitializationFailureReason error)
//     {
//         Debug.Log("Purchaser, Purchaser init failed error = " + error);
//     }
//
//     public void OnInitializeFailed(InitializationFailureReason error, string message)
//     {
//         Debug.Log("Purchaser, Purchaser init failed error = " + error);
//     }
//
//     //购买成功和恢复成功的回调，可以根据id的不同进行不同的操作
//     public PurchaseProcessingResult ProcessPurchase(PurchaseEventArgs e)
//     {
//         Debug.Log("Purchaser, ProcessPurchase OK!");
//         mStoreController.ConfirmPendingPurchase(e.purchasedProduct);
//
//         OnPurchase(e.purchasedProduct);
//         string productKey = GetProductKey(e.purchasedProduct);
//         RefreshVipState(productKey, true);
//         TypeEventSystem.Send<PurchaseSuccess>(new PurchaseSuccess(e.purchasedProduct, productKey));
//
//         return PurchaseProcessingResult.Complete;
//     }
//
//     public void OnPurchaseFailed(Product e, PurchaseFailureReason failureReason)
//     {
//         Debug.Log("Purchaser, OnPurchaseFailed failureReason = " + failureReason);
//
//         TypeEventSystem.Send<PurchaseFailed>(new PurchaseFailed(e, failureReason));
//     }
//  
//     private void OnPurchase(Product purchasedProduct)
//     {
//         IDataService dataService = MainContainer.Container.Resolve<IDataService>();
//         IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
//         if (dataService.MaxLevel <= 1) return;
//         string productId = purchasedProduct.definition.id;
//         ShopModel shopModel = configService.ShopConfig[productId];
//         dataService.CumulativeRechargeAmount += shopModel.price;
//         dataService.CumulativeRechargeCount++;
//
//         var msg = new Dictionary<string, object>
//         {
//             { AnalyticsKey.PurchaseSku, productId },
//             { AnalyticsKey.PurchaseCurrencyCode, purchasedProduct.metadata.isoCurrencyCode },
//             { AnalyticsKey.PurchasePriceString, purchasedProduct.metadata.localizedPriceString },
//             { AnalyticsKey.PurchaseLocalPrice, purchasedProduct.metadata.localizedPrice },
//             { AnalyticsKey.PurchaseValueUsd, shopModel.GetReportPrice() },
//             { AnalyticsKey.PurchaseScene, GameController.Instance.IsPlaying ? "game" : "home" },
//             { AnalyticsKey.PurchaseCurrentStage, dataService.MaxLevel },
//             { AnalyticsKey.PurchaseCurrentCoin, dataService.Coin },
//             { AnalyticsKey.PurchaseCurrentWild, dataService.GetPropNum(PropEnum.FreeJoker) },
//             { AnalyticsKey.PurchaseCurrentUndo, dataService.GetPropNum(PropEnum.FreeUndo) },
//             { AnalyticsKey.PurchaseCurrentFill, dataService.GetPropNum(PropEnum.FreeBuyCard) },
//             { AnalyticsKey.PurchaseCurrentPowerupDelthree, dataService.GetPropNum(PropEnum.ItemEliminate) },
//             { AnalyticsKey.PurchaseCurrentPowerupWild, dataService.GetPropNum(PropEnum.ItemJoker) },
//             { AnalyticsKey.PurchaseCurrentPowerupCactus, dataService.GetPropNum(PropEnum.ItemCactus) },
//             { AnalyticsKey.PurchaseTime, dataService.CumulativeRechargeCount },
//         };
//         AnalyticeUtils.ReportEvent(AnalyticsKey.SoliPurchaseSuccess, msg);
//
//         AnalyticeUtils.ReportUser_Add(AnalyticsKey.PurchaseTimes, 1);
//         AnalyticeUtils.ReportUser_Add(AnalyticsKey.PurchaseMoney, (float)purchasedProduct.metadata.localizedPrice);
//     }
//
//     public SubscriptionInfo GetSubscriptionInfo()
//     {
//         if (!IsInitialized()) return null;
//         Product vipSubscriptionProduct = GetProduct("vip_2");
//         if (!vipSubscriptionProduct.hasReceipt) return null;
//         if (vipSubscriptionMgr == null)
//             RefreshVipState("vip_2", false);
//         return vipSubscriptionMgr.getSubscriptionInfo();
//     }
//
//     private void RefreshVipState(string productKey, bool isBuy)
//     {
//         IDataService dataService = MainContainer.Container.Resolve<IDataService>();
//         Product vipProduct = GetProduct(productKey);
//         long nowTime = TimeUtils.UtcNow();
//         if (productKey == "vip_2")
//         {
//             if (vipSubscriptionMgr == null && vipProduct.hasReceipt)
//                 vipSubscriptionMgr = new SubscriptionManager(vipProduct, null);
//             if (vipSubscriptionMgr == null)
//             {
//                 if (dataService.VipBuyType != 0)
//                     ReprotEndVip(vipProduct);
//                 dataService.VipBuyType = 0;
//                 dataService.VipEndTime = 0;
//                 TypeEventSystem.Send<VipStateChange>();
//                 return;
//             }
//             var subscriptionInfo = vipSubscriptionMgr.getSubscriptionInfo();
//             long endTime = TimeUtils.GetDayEndTime(subscriptionInfo.getExpireDate());
//             if (endTime < nowTime)
//             {
//                 if (dataService.VipBuyType != 0)
//                     ReprotEndVip(vipProduct);
//                 dataService.VipBuyType = 0;
//                 dataService.VipEndTime = 0;
//                 TypeEventSystem.Send<VipStateChange>();
//                 return;
//             }
//             if (dataService.VipEndTime != endTime)
//                 dataService.VipEndTime = endTime;
//             if (isBuy && dataService.VipBuyType == 0)
//                 ReprotBuyVip(vipProduct);
//             if (subscriptionInfo.isFreeTrial() == Result.True)
//                 dataService.VipBuyType = 2;
//             else
//             {
//                 int toType = subscriptionInfo.isCancelled() == Result.True ? 3 : 4;
//                 if (dataService.VipBuyType != 4 && toType == 4)
//                     ReprotEndVip(vipProduct);
//                 dataService.VipBuyType = toType;
//             }
//             TypeEventSystem.Send<VipStateChange>();
//         }
//         if (productKey == "one_month_vip")
//         {
//             if (isBuy)
//             {
//                 if (dataService.VipBuyType == 0)
//                     ReprotBuyVip(vipProduct);
//                 long newEndTime = TimeUtils.GetDayEndTime(TimeUtils.GetUtcNowDateTime().AddDays(30));
//                 dataService.VipBuyType = 1;
//                 dataService.VipEndTime = newEndTime;
//                 TypeEventSystem.Send<VipStateChange>();
//                 return;
//             }
//             else if (dataService.VipEndTime < nowTime)
//             {
//                 if (dataService.VipBuyType != 0)
//                     ReprotEndVip(vipProduct);
//                 dataService.VipBuyType = 0;
//                 dataService.VipEndTime = 0;
//                 TypeEventSystem.Send<VipStateChange>();
//                 return;
//             }
//         }
//     }
//
//     private void ReprotBuyVip(Product vipProduct)
//     {
//         IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
//         ShopModel shopModel = configService.ShopConfig[vipProduct.definition.id];
//         SubscriptionInfo info = GetSubscriptionInfo();
//         if (info == null)
//         {
//             var msg = new Dictionary<string, object>
//             {
//                 { AnalyticsKey.PurchaseSku, shopModel.id },
//                 { AnalyticsKey.PurchaseValueUsd, shopModel.price },
//                 { AnalyticsKey.SubscribeDays, 30 },
//                 { AnalyticsKey.TrialStartTime, TimeUtils.UtcNow() },
//                 { AnalyticsKey.TrialEndTime, TimeUtils.ConvertTimestamp(TimeUtils.GetUtcNowDateTime().AddDays(30)) },
//             };
//             AnalyticeUtils.ReportEvent(AnalyticsKey.SoliSubscribeStart, msg);
//         }
//         if (info.isFreeTrial() == Result.True)
//         {
//             var msg = new Dictionary<string, object>
//             {
//                 { AnalyticsKey.PurchaseSku, shopModel.id },
//                 { AnalyticsKey.PurchaseValueUsd, shopModel.price },
//                 { AnalyticsKey.TrialDays, info.getFreeTrialPeriodString() },
//                 { AnalyticsKey.TrialStartTime, TimeUtils.UtcNow() },
//                 { AnalyticsKey.TrialEndTime, TimeUtils.ConvertTimestamp(info.getPurchaseDate().Add(info.getFreeTrialPeriod())) },
//             };
//             AnalyticeUtils.ReportEvent(AnalyticsKey.SoliSubscribeTrial, msg);
//         }
//         else
//         {
//             var msg = new Dictionary<string, object>
//             {
//                 { AnalyticsKey.PurchaseSku, shopModel.id },
//                 { AnalyticsKey.PurchaseValueUsd, shopModel.price },
//                 { AnalyticsKey.SubscribeDays, (info.getExpireDate() - info.getPurchaseDate()).TotalDays },
//                 { AnalyticsKey.TrialStartTime, TimeUtils.UtcNow() },
//                 { AnalyticsKey.TrialEndTime, TimeUtils.ConvertTimestamp(info.getPurchaseDate().Add(info.getFreeTrialPeriod())) },
//             };
//             AnalyticeUtils.ReportEvent(AnalyticsKey.SoliSubscribeStart, msg);
//         }
//     }
//
//     private void ReprotEndVip(Product vipProduct)
//     {
//         IDataService dataService = MainContainer.Container.Resolve<IDataService>();
//         IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
//         ShopModel shopModel = configService.ShopConfig[vipProduct.definition.id];
//         SubscriptionInfo info = GetSubscriptionInfo();
//         if (info == null)
//         {
//             var msg = new Dictionary<string, object>
//             {
//                 { AnalyticsKey.PurchaseSku, shopModel.id },
//                 { AnalyticsKey.PurchaseValueUsd, shopModel.price },
//                 { AnalyticsKey.TrialStartTime, dataService.VipEndTime - 30 * TimeUtils.OneDaySeconds() },
//                 { AnalyticsKey.TrialEndTime, dataService.VipEndTime },
//             };
//             AnalyticeUtils.ReportEvent(AnalyticsKey.SoliSubscribeEnd, msg);
//         }
//         else
//         {
//             var msg = new Dictionary<string, object>
//             {
//                 { AnalyticsKey.PurchaseSku, shopModel.id },
//                 { AnalyticsKey.PurchaseValueUsd, shopModel.price },
//                 { AnalyticsKey.SubscribeDuaration, TimeUtils.ConvertTimestamp(info.getPurchaseDate().Add(info.getFreeTrialPeriod())) },
//             };
//             AnalyticeUtils.ReportEvent(AnalyticsKey.SoliSubscribeCancel, msg);
//         }
//     }
// }