using System;
using System.Collections.Generic;
using System.Diagnostics;
using Activities;
using Model;
using QFramework;
using SoliUtils;

public class PaidManager : ISingleton
{
    public static PaidManager Instance
    {
        get { return SingletonProperty<PaidManager>.Instance; }
    }

    public void OnSingletonInit()
    {

    }

    private PaidManager()
    {

    }

    public void Init()
    {
        TypeEventSystem.Register<RechargeEvent>(OnRechargeEvent);
        TypeEventSystem.Register<PopPushGift>(OnPopPushGiftEvent);
    }

    private void OnPopPushGiftEvent(PopPushGift e)
    {
        if (GameCommon.IsShieldPurchase) return;
        if (e.productId.Contains("BankruptcyPack"))
        {
            BoxBuilder.ShowBroken(e.productId);
        }
        else if (e.productId == Constants.ProductId.AssistancePack_1 ||
                 e.productId == Constants.ProductId.NarrowDefeatPack_1 ||
                 e.productId == Constants.ProductId.NarrowDefeatPack_2 ||
                 e.productId == Constants.ProductId.NarrowDefeatPack_3)
        {
            BoxBuilder.ShowFailGameGift(e.productId);
        }

    }

    private void OnRechargeEvent(RechargeEvent e)
    {
        if (!e.ret)
            return;
        HandleRechargeReward(e.product_id, e.paramex);
        HandleLogic_ChargeEvent(e.product_id);
    }

    public void HandleRechargeReward(string product_id, string paramex)
    {
        var dataSrv = MainContainer.Container.Resolve<IDataService>();
        var configSrv = MainContainer.Container.Resolve<IConfigService>();
        configSrv.ShopConfig.TryGetValue(product_id, out var productCfg);
        if (productCfg == null)
        {
            UnityEngine.Debug.LogError($"product_id : {product_id} is not exsit");
            return;
        }

        string rewardStr = productCfg.reward;
        Dictionary<int, int> reward = GameUtils.AnalysisPropString(rewardStr);

        if (product_id == Constants.ProductId.MonthlySubscription)
        {
            dataSrv.AddProp((int)PropEnum.MonthCard, 30 * TimeUtils.OneDaySeconds(), PropChangeWay.Shop);
        }
        else if (product_id == Constants.ProductId.WeeklySubscription)
        {
            dataSrv.AddProp((int)PropEnum.WeekCard, 7 * TimeUtils.OneDaySeconds(), PropChangeWay.Shop);
        }
        else if (product_id == Constants.ProductId.FirstPayment)
        {
            dataSrv.IsBuyBeginner = true;
            dataSrv.BeginnerGiftEndTime = TimeUtils.UtcNow();
            dataSrv.NowTriggerGiftEndTime = dataSrv.BeginnerGiftEndTime;
        }
        else if (product_id == Constants.ProductId.SmallFirstPayment)
        {
            dataSrv.IsSmallBuyBeginner = true;
        }
        else if (product_id == Constants.ProductId.HeartBeatGift)
        {
            dataSrv.IsBuyHeartBeatGift = true;
        }
        else if (product_id == Constants.ProductId.ShovelGift || product_id == Constants.ProductId.ChefhatGift)
        {
            BoxBuilder.HideGiftBuyItemPopup();
        }
        else if (product_id == Constants.ProductId.SeasonPass)
        {
            dataSrv.SeasonPassProgress.IsPaid = true;
            TypeEventSystem.Send(new SeasonPassPaidEvent(true));
        }
        else if (product_id == Constants.ProductId.PiggyBank)
        {
            ActivityManager.Instance.FinishGetReward(ActivityType.piggy, false);
            reward.Clear();
            reward.Add((int)PropEnum.Coin, dataSrv.PiggyData.piggyCoin);
        }
        else if (product_id == Constants.ProductId.DailyPurchaseLimit_1)
        {
            dataSrv.AddTimeFlag(FlagType.DailyBuy);
        }
        else if (product_id == Constants.ProductId.WeeklyPurchaseLimit_1)
        {
            dataSrv.AddTimeFlag(FlagType.WeekBuy);
        }
        else if (product_id == Constants.ProductId.MonthlyPurchaseLimit_1)
        {
            dataSrv.AddTimeFlag(FlagType.MonthBuy);
        }
        else if (product_id == Constants.ProductId.WheelGiftPack)
        {
            ActivityManager.Instance.WheelActivity.SetPayState(true);
        }
        else if (product_id.Contains("GiftPlus"))
        {
            ActivityManager.Instance.GiftActivity.UpdateGiftPlusData(productCfg);
        }
        else if (product_id == Constants.ProductId.DiscountGift)
        {
            TypeEventSystem.Send<HideDiscountGiftPopup>();
        }
        else if (product_id.Contains("GiftDrag"))
        {
            reward.Clear();
            reward = ActivityManager.Instance.GiftActivity.GetBuyDragOneReward(productCfg);
            ActivityManager.Instance.GiftActivity.UpdateGiftDragData(productCfg);
        }
        else if (product_id.Contains("Gradient"))
        {
            dataSrv.GradientGiftProgress.CurRewardIndex++;
            TypeEventSystem.Send<UpdateGradientGift>();
        }
        else if (product_id.Contains("GiftCook"))
        {
            dataSrv.GiftGradientCookProgress.CurRewardIndex++;
            TypeEventSystem.Send<UpdateGiftCook>();
        }
        else if (product_id.Contains("GiftDig"))
        {
            dataSrv.GiftGradientDigProgress.CurRewardIndex++;
            TypeEventSystem.Send<UpdateGiftDig>();
        }
        else if (product_id.Contains("BankruptcyPack"))
        {
            if (Constants.BankruptcyFlagId.TryGetValue(product_id, out FlagType flagType))
            {
                dataSrv.AddDailyFlag(flagType);
            }
        }

        if (productCfg.product_type == 1)
        {
            int idx = 0;
            foreach (var item in configSrv.ShopConfig)
            {
                if (item.Value.product_type == 1)
                {
                    if (item.Key == product_id)
                        break;
                    idx++;
                }
            }
            dataSrv.BuyRmbMergeShopItem(idx);
            TypeEventSystem.Send<BuyItemFromMergeShop>(new BuyItemFromMergeShop(idx));
        }
        else if (productCfg.product_type == 2)
        {
            var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(paramex);
            if (dic != null)
            {
                dic.TryGetValue("ball_id", out var ball_id);
                dic.TryGetValue("cfg_id", out var cfg_id);
                dataSrv.BuyHotAirBall(int.Parse(ball_id.ToString()), int.Parse(cfg_id.ToString()));
            }
        }
        else
        {
            if (!string.IsNullOrEmpty(rewardStr))
            {
                BoxBuilder.ShowRewardPop(reward, PropChangeWay.Shop);
            }
        }

    }

    //充值触发的控牌逻辑
    public void HandleLogic_ChargeEvent(string product_id)
    {
        var dataSrv = MainContainer.Container.Resolve<IDataService>();
        var configSrv = MainContainer.Container.Resolve<IConfigService>();
        configSrv.ShopConfig.TryGetValue(product_id, out var productCfg);
        if (productCfg == null)
        {
            UnityEngine.Debug.LogError($"product_id : {product_id} is not exsit");
            return;
        }

        var lastChargeTime = dataSrv.LastChargeTime;
        var now = TimeUtils.UtcNow();
        if (TimeUtils.IsSameDay(lastChargeTime, now))
        {
            dataSrv.TodayChargeTimes += 1;
            dataSrv.TodayChargeMoney += productCfg.money;
        }
        else
        {
            dataSrv.TodayChargeTimes = 1;
            dataSrv.TodayChargeMoney = productCfg.money;
            dataSrv.NoTodayChargeTime = lastChargeTime;
        }
        dataSrv.AllChargeMoney += productCfg.money;
        dataSrv.LastChargeTime = now;

        if (product_id == Constants.ProductId.FirstPayment || product_id == Constants.ProductId.SmallFirstPayment)
        {
            HandleLogic_FirstRecharge();
        }
        else if (product_id == Constants.ProductId.WeeklySubscription)
        {
            HandleLogic_WeekVipCard();
        }
        else if (product_id == Constants.ProductId.MonthlySubscription)
        {
            HandleLogic_MonthVipCard();
        }
        else if (product_id == Constants.ProductId.HeartBeatGift)
        {
            HandleLogic_HeartBeat();
        }


        if (dataSrv.TodayChargeTimes == 1)
        {
            HandleLogic_TodayFirstPaid();
        }
        else if (dataSrv.TodayChargeTimes == 2)
        {
            HandleLogic_TodaySecondPaid();
        }
        else if (dataSrv.TodayChargeTimes >= 3)
        {
            HandleLogic_TodayMorePaid();
        }

        if (TimeUtils.GetOffsetDays(dataSrv.NoTodayChargeTime, now) == 1 && dataSrv.TodayChargeTimes == 1)
        {
            HandleLogic_ContinuousPaid();
        }

        HandleLogic_TodayAccumulatedPaid(dataSrv.TodayChargeMoney);

        TypeEventSystem.Send<GameRechargeEvent>();
        dataSrv.SaveData(true);
    }

    private void HandleLogic_AddData(Constants.HandlePaidType paid_type)
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var id = 1;
        var number = 0;
        var priority = 0;
        foreach (var item in configService.HandlePaidConfig)
        {
            if (item.Value.type == (int)paid_type)
            {
                number = item.Value.value;
                id = item.Value.id;
                priority = item.Value.priority;
                break;
            }
        }
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var handlePaid = new HandlePaidModel();
        handlePaid.id = id;
        handlePaid.number = number;
        handlePaid.paidTime = TimeUtils.UtcNow();
        handlePaid.priority = priority;
        List<HandlePaidModel> data = new List<HandlePaidModel>();
        if (dataService.HandlePaidModelData != null)
        {
            data.AddRange(dataService.HandlePaidModelData);
        }
        data.Add(handlePaid);
        data.Sort((x, y) => x.priority.CompareTo(y.priority));
        dataService.HandlePaidModelData = data.ToArray();
    }

    //心动礼包成功后调用
    public void HandleLogic_HeartBeat()
    {
        HandleLogic_AddData(Constants.HandlePaidType.HeartBeatGiftPaid);
    }

    //购买首充礼包成功后调用
    public void HandleLogic_FirstRecharge()
    {
        HandleLogic_AddData(Constants.HandlePaidType.FirstPaidGift);
    }

    //购买周卡后调用
    public void HandleLogic_WeekVipCard()
    {
        HandleLogic_AddData(Constants.HandlePaidType.WeekVipCard);
    }

    //购买月卡后调用
    public void HandleLogic_MonthVipCard()
    {
        HandleLogic_AddData(Constants.HandlePaidType.MonthVipCard);
    }

    //每日首充充值调用
    public void HandleLogic_TodayFirstPaid()
    {
        HandleLogic_AddData(Constants.HandlePaidType.TodayFirstPaid);
    }

    //每日第二次充值调用
    public void HandleLogic_TodaySecondPaid()
    {
        HandleLogic_AddData(Constants.HandlePaidType.TodaySecondPaid);
    }

    //每日2+次充值调用
    public void HandleLogic_TodayMorePaid()
    {
        HandleLogic_AddData(Constants.HandlePaidType.TodayMorePaid);
    }

    //连续每日充值调用
    public void HandleLogic_ContinuousPaid()
    {
        HandleLogic_AddData(Constants.HandlePaidType.ContinuousPaid);
    }

    //当日充值金额满足N调用
    public void HandleLogic_TodayAccumulatedPaid(int money)
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var id = -1;
        var number = 0;
        var lastMoney = 0;
        foreach (var item in configService.HandlePaidConfig)
        {
            if (item.Value.type == (int)Constants.HandlePaidType.TodayAccumulatedPaid
                && money >= item.Value.exparam
                && lastMoney < item.Value.exparam)
            {
                number = item.Value.value;
                id = item.Value.id;
                lastMoney = item.Value.exparam;
            }
        }
        if (id != -1)
        {
            var dataService = MainContainer.Container.Resolve<IDataService>();
            var handlePaid = new HandlePaidModel();
            handlePaid.id = id;
            handlePaid.number = number;
            handlePaid.paidTime = TimeUtils.UtcNow();
            List<HandlePaidModel> data = new List<HandlePaidModel>();
            if (dataService.HandlePaidModelData != null)
            {
                data.AddRange(dataService.HandlePaidModelData);
            }
            data.Add(handlePaid);
            dataService.HandlePaidModelData = data.ToArray();
        }
    }


    void Dispose()
    {
        TypeEventSystem.UnRegister<RechargeEvent>(OnRechargeEvent);
        TypeEventSystem.UnRegister<PopPushGift>(OnPopPushGiftEvent);
    }

}
