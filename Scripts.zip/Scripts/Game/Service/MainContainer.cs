using QFramework;
using UnityEngine;

public class MainContainer : QFrameworkContainer, ISingleton
{
    private MainContainer()
    {
    }

    public static IQFrameworkContainer Container
    {
        get { return SingletonProperty<MainContainer>.Instance; }
    }

    void ISingleton.OnSingletonInit()
    {
        // 注册网络服务模块
        RegisterInstance<INetworkService>(new NetworkService());
        // 注册数据存储模块
        RegisterInstance<IStorageService>(new StorageService());
        // 注册配置读取模块
        RegisterInstance<IConfigService>(new ConfigService());
        // 注册资产更新模块
        RegisterInstance<IAssetService>(new AssetService());
        // 注册玩家数据模块
        RegisterInstance<IDataService>(new DataService());
    }
}