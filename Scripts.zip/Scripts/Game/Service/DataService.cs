using QFramework;
using System.Linq;
using System;
using System.Collections.Generic;
using UnityEngine;
using Model;
using Newtonsoft.Json;
using SoliUtils;
using System.Globalization;
using Activities;
using UnityEditor;
using System.Runtime.InteropServices;

//道具类型
public enum PropEnum
{
    Coin = 1,//金币
    FreeUndo = 2,//免费回退
    FreeJoker = 3,//免费万能牌
    FreeBuyCard = 4,//免费买卡
    FreeTicket = 5,//免费入场券
    BuildCoin = 6,//建造币
    ItemEliminate = 11,//开局消牌
    TimeItemEliminate = 12,//开局消牌（计时）
    ItemJoker = 13,//开局万能牌
    TimeItemJoker = 14,//开局万能牌（计时）
    ItemCactus = 15,//开局仙人掌
    TimeItemCactus = 16,//开局仙人掌（计时）
    TimeItemDouble = 17,//活动道具翻倍

    WeekCard = 18,
    MonthCard = 19,
    ItemWindmill = 20,//开局风车牌
    TimeItemWindmill = 21,//开局风车牌（计时）
    ItemDig = 22,//铲子
    ItemCook = 23,//厨师帽
    ItemWater = 24,//水滴
    ItemHoney = 25,//花蜜
    GradientDig = 26,//寻宝梯度礼包
    Energy = 27,//体力
    EnergyInfinite = 28,//体力无限（计时）
    GradientCook = 29,//寻宝梯度礼包
    BubbleGift = 30,
    EnergyPlus8 = 31,
    StageStar = 100,
    WheelStar = 101,
    BubbleIcon = 102,

    PiggyCoin = 99997,//储蓄罐金币
    Xishu = 99998,
    MultiplyCoin = 99999,//金币(图标不同)
    CollectCard = 800,//活动收集鲜花
    CollectFlower = 801,//活动收集爱心方块卡牌
    CollectRiot = 802,//活动收集鲜花
}

public enum PropChangeWay
{
    GM,

    //Use in Offcourt
    //Get way
    Harvest,
    SignIn,
    Shop,
    Wheel,
    ShopAd,
    FirstCharge,
    CreateRole,
    Saver,
    WinGame,
    BuildReward,
    MapPartReward,
    MapPassReward,
    UnlockPowerItem,
    BattlePassReward,
    BallonGiftAd,
    BrokenReceive,
    UnlockFarmingLand,
    CollectFarmingCoin,
    AfkCoin,
    CollectFlowerReward,
    CollectWaterReward,
    CollectHoneyReward,
    CollectLoveCardReward,
    CollectMuiscReward,
    LavaPassReward,
    TriggerGift,
    EnergyInit,
    EnergyBuy,
    EnergyRecover,
    EnergyAd,
    UnlockMergeItem,

    //Consume way
    BuildConsume,
    WheelConsume,
    BuyPowerItem,
    BuyMergeOrder,
    CookMealCoin,
    CookMealProgressCoin,
    EnergyConsume,
    BuyMergeItem,

    //Use in Game
    //Get way
    CoinMod,
    Combo,
    ComboStep,
    RemainCard,
    Solatium,
    Recycle,

    //Consume way
    EnterGame,
    GameBeforeUseProp,
    BuyHandCard,
    BuyJokerCard,
    BuyUndo,
    WiningStreak,

    WeekReward,
    MonthReward,
    PassRankReward,
    SeasonReward,
    DailyReward,
    FreeWheel,
    PayWheel,
    AfkReward,
    GradientReward,
    GiftGradientCookReward,
    GiftGradientCollectReward,
    GiftGradientDigReward,
    DigTreasureReward,
    MysteriousSeed,
    CookMealReward,
    ReturnReward,
    LevelPassReward,
    LimitPkReward,
    CoinAd,
    FreeCoinAd,
    FreeItemAd,
    Email,
    EndlessLevelReward,
    UndoFreeJokerCard,
    NpcOrder,
    HotAirBall,
    CarRankReward,
    MergeVersion,
}

public interface IDataService
{
    string OpenId { get; set; }
    string UserId { get; set; }
    string UserName { get; set; }
    string UserAvatar { get; set; }
    string UserProvince { get; set; }
    int DataUpdateTime { get; set; }
    int GameVersion { get; set; }
    bool OldDataVersionFlag { get; set; }
    Vector3 CameraRecord { get; set; }
    Dictionary<int, int> RecordBubbleItem { get; set; }
    long Coin { get; }
    long BuildCoin { get; }
    long Energy { get; }
    int CardBackId { get; set; }
    int MaxLevel { get; set; }
    int NowMaxLevel { get; }
    int NowViewMaxLayer { get; }
    int MaxLevelTime { get; }
    int StageLevel { get; set; }
    int NextBuildId { get; set; }
    long StageStar { get; }
    long WheelStar { get; }
    int WheelRequestIndex { get; set; }
    int TodayWatchShopAdTime { get; set; }
    int TodayWatchWheelAdTime { get; set; }
    int TodayBrokenReceiveTime { get; set; }
    short SignDay { get; set; }
    int LastSignTime { get; set; }
    int RegisterTime { get; set; }
    int LastGoldTime { get; set; }
    int LastQuitTime { get; set; }
    string SelectLanguage { get; set; }
    int InterAdInterval { get; set; }
    int LevelExperienceValue { get; set; }

    float CumulativeRechargeAmount { get; set; }
    int CumulativeRechargeCount { get; set; }
    int OpenBetLevel { get; set; }
    int LastShowBetLevel { get; set; }
    int NowBet { get; set; }
    int FailSameLevelTimes { get; set; } // 关卡失败次数
    int IsCurWheelFinish { get; set; } //当前关卡的轮盘是否完成

    int FlowerStageStar { get; set; }
    bool IsFinishBattle { get; set; }

    bool IsSmallBuyBeginner { get; set; }//3块小首充

    bool IsBuyBeginner { get; set; } //首冲是否购买
    bool IsBuyHeartBeatGift { get; set; }//心动礼包
    int BeginnerGiftEndTime { get; set; } //首冲结束时间
    string NowTriggerGiftProductID { get; set; } //当前触发礼包id
    int NowTriggerGiftEndTime { get; set; } //触发礼包结束时间
    int AfkRewardGetTime { get; set; }//领取挂机奖励时间
    int AfkRewardGetCount { get; set; }//每日获取挂机奖励的次数
    int FirstChargeUiOpenLv { get; set; }
    bool MusicMute { get; set; }
    bool SoundMute { get; set; }
    void MarkRookieTipFlag(int rookie_id);
    bool IsRookieShowed(int rookie_id);
    void PrintRookieTipFlag();
    int UserType { get; set; }
    string FbAccount { get; set; }
    string InstallUid { get; set; }
    int SuccessiveVictory { get; }
    ActivitySaveData ActivitySaveData { get; } // 活动相关的本地数据
    FarmingProgress FarmingProgress { get; }
    PassRankProgress PassRankProgress { get; }
    CarRankProgress CarRankProgress { get; }
    LevelPassProgress LevelPassProgress { get; }
    LavaPassProgress LavaPassProgress { get; }
    SeasonPassProgress SeasonPassProgress { get; }
    AdRewardProgress AdRewardProgress { get; }
    CollectFlowerProgress CollectFlowerProgress { get; }
    EndlessLevelProgress EndlessLevelProgress { get; }
    RabitGiftProgress RabitGiftProgress { get; }
    LimitPkData LimitPkData { get; }
    CollectLoveCardProgress CollectLoveCardProgress { get; }
    CollectMusicProgress CollectMusicProgress { get; }
    DigTreasureProgress DigTreasureProgress { get; }
    CookMealProgress CookMealProgress { get; }
    CollectWaterProgress CollectWaterProgress { get; }
    GiftPlusOneData GiftPlusOneData { get; }
    GiftPlusFourData GiftPlusFourData { get; }
    GiftDiscountData GiftDiscountData { get; }
    GiftDragOneData GiftDragOneData { get; }
    GiftDragTwoData GiftDragTwoData { get; }
    GiftDragSixData GiftDragSixData { get; }
    MysteriousSeedProgress MysteriousSeedProgress { get; }
    CollectHoneyProgress CollectHoneyProgress { get; }
    WheelProgress WheelProgress { get; }
    WinStreakData WinStreakData { get; }
    PiggyData PiggyData { get; }
    GradientGiftProgress GradientGiftProgress { get; }
    GiftGradientCookProgress GiftGradientCookProgress { get; }
    GiftGradientDigProgress GiftGradientDigProgress { get; }
    int TodayLevelPassTimes { get; set; } // 每日通关次数
    int TodayLaunchTimes { get; set; } // 每日启动游戏的次数
    int LastRefreshTime { get; set; } // 上一次刷新定时器的时间
    int TodayNotificationCount { get; set; }
    int DailyWinUseTime { get; set; }
    List<EmailInfoModel> EmailList { get; set; }
    List<int> PreAddItem { get; set; }
    int VipBuyType { get; set; } //0=未订阅  1=单月  2=连续但试用  3=月供并连续  4=月供但不连续
    int VipEndTime { get; set; }
    int VipLastRewardTime { get; set; }
    int LastCoinAdTime { get; set; }
    int LastFreeCoinAdTime { get; set; }
    int FreeCoinAdCount { get; set; }
    int FreeItemAdCount { get; set; }
    int FreeItemAdValue { get; set; }
    HandlePaidModel[] HandlePaidModelData { get; set; }
    int LastChargeTime { get; set; } //最近一次付费时间
    int TodayChargeTimes { get; set; } //今日付费次数
    int TodayChargeMoney { get; set; } //今日付费金额
    int AllChargeMoney { get; set; } //累计付费金额
    int NoTodayChargeTime { get; set; } //非今日付费时间
    string[] OrderList { get; set; } //已确认的订单列表
    EnergySaveData EnergySaveData { get; }//体力系统数据


    void UpdateActivitySaveData();

    void Update();
    void ReadLocalData();
    void InitActivitySaveData();
    int GetCollectBet();//获取活动收集倍数
    int GetDobuleCollectTime();//获取双倍收集时间
    bool ReadGameData(object gameData, int localDataUpdateTime, int maxLevel);
    void SyncUserData(string user_id);
    void ReadAccountInfo();
    void SaveData(bool force, bool upload = false);
    void SaveData(string json);
    void SaveRewardData(Dictionary<int, int> rewardDic, PropChangeWay changeWay);
    void HandleBubbleItem(ref Dictionary<int, int> rewardDic);
    void ClearResultProp();
    Dictionary<int, long> GetResultProp();
    void AddFirstPopup(string popupName);
    bool CheckFirstPopup(string popupName);

    void AddDailyFlag(FlagType type);
    bool CheckDailyFlag(FlagType type);
    void ClearDailyFlag();
    void AddTimeFlag(FlagType type);
    Dictionary<FlagType, int> GetTimeFlagDic();
    bool CheckTimeFlag(FlagType type);
    void AddFlyAnimProp(int propEnum, long count);
    bool ConsumeCoin(long consumeNum, PropChangeWay useWay);
    bool ConsumeBuildCoin(long consumeNum, PropChangeWay useWay);
    void AddCoin(long addNum, PropChangeWay getWay, params object[] param);
    void AddBuildCoin(long addNum, PropChangeWay getWay, params object[] param);
    int? GetBuildSelectIndex(int buildId);
    void SetBuildSelectIndex(int buildId, int selectIndex, Action onBuildEnd = null);

    long GetPropNum(int prop);
    long GetPowerItemStartTime(int prop);
    long GetPreAddItemConsume();
    void OperatePreAddItem(int type, int propEnum);
    void AddProps(Dictionary<int, long> props, PropChangeWay getWay, params object[] param);
    void AddProp(int prop, long num, PropChangeWay getWay, params object[] param);
    bool UseProp(int prop, PropChangeWay useWay, long num = 1);

    bool GetPowerItemIsUnlock(int prop);
    void SetUnlockPowerItem(int prop);
    bool IsFreeAd();
    bool IsFirstUseBet(int betNum);

    int CollectFlowerEnableState(); //是否开启鲜花采集活动    //0关闭，1进行，2等待玩家开启
    bool IsConfigMaxLevel();
    void SetFirstUseBet(int betNum, bool state);
    bool CheckSpecialCardTip(CardType cardType, ModifierModel[] modifierType);
    bool CheckClearActivityData();
    void CheckActivityReward();
    int CreateMergeItem(int gridId, int itemId);
    bool MoveMergeItem(int fromGridId, int toGridId);
    List<int> GetMergeGrids(int gridId, int dstGridId);
    bool DoMerge(int gridId, int dstGridId, out List<int> removes, out List<Tuple<int, int>> adds);
    int GetGridItemId(int gridId, out int newGridId);
    void CleanMergeData();
    Dictionary<int, int> GetMergeData();
    Dictionary<int, MergeBubbleModel> GetMergeBubbleData();
    Dictionary<int, MergeHotAirBallModel> GetMergeHotAirBallData();
    bool HasMergeBubble(int bubbleId);
    void MoveMergeBubble(int bubbleId, Vector3 pos);
    bool OpenMergeBubble(int bubbleId);
    void MoveMergeHotAirBall(int ballId, Vector3 pos);
    MergeOrderInfoModel GetMergeOrder(int npc_id, out bool newPro);
    bool CheckMergeRookieOrder();
    bool IsFinishOrder(int npc_id);
    int GetMergeOrderPrice(int npc_id);
    bool CommitMergeOrder(int npc_id);
    bool BuyAndCommitMergeOrder(int npc_id);
    bool ReceiveMergeOrderRewards(int npc_id);
    MergeRegionModel GetRegionInfo(int region_id);
    void GetRegionReward(int region_id, int level);
    bool UseExpMergeItem(int itemId);
    bool RecycleMergeItem(int gridId);
    void RegionLevelUp(int region_id);
    bool IsUnlockCloud(int cloud_id);
    bool IsUnlockGrid(int grid_id);
    int GetGridExp(int grid_id);
    void AddMergeLevelBox();
    int GetUnPutLevelBoxNumber();
    bool PutMergeLevelBox(Vector3 fromPos);
    bool OpenMergeLevelBox(int grid_id);
    bool OpenMergeMapBox(int grid_id);
    List<int> GetUnlockNpcIds();
    int GetMergeItemState(int itemId);
    void SetMergeItemState(int itemId, int state);
    int GetRegionId();
    int GetRegionLevel();
    void ReceiveMergeShopItems();
    MergeShopInfoModel GetMergeShopData();
    void BuyRmbMergeShopItem(int index);
    int BuyMergeShopItem(int date, int index);
    void CheckHotAirBall();
    bool BuyHotAirBall(int ballId, int cfgId);
    void SetRookieStatus(int level);
    int GetRookieStatus();
    bool IsRookieStatus();
    bool IsOverRookie();
    bool IsUnlockNpc(int npc_id);
    bool IsHasFirstNpc();
    string GetOldDataVersionRewards();

    int MergeLevelBoxIndex { get; }
}

public class DataService : IDataService
{
    private IConfigService configService
    {
        get => MainContainer.Container.Resolve<IConfigService>();
    }
    private IStorageService storageService
    {
        get => MainContainer.Container.Resolve<IStorageService>();
    }
    public DataService()
    {
        Debug.Log("DataService init");
        TypeEventSystem.Register<GlobalTimerRefreshEvent>(OnGlobalTimerRefreshEvent);
    }

    public void Update()
    {
    }
    public string DataVersion { get; set; }
    public bool OldDataVersionFlag { get; set; } //合成版本之前的数据转换标识

    private string _open_id = "";
    public string OpenId
    {
        get
        {
#if UNITY_EDITOR
            if (string.IsNullOrEmpty(_open_id))
                _open_id = Guid.NewGuid().ToString("N");
#endif
            return _open_id;
        }
        set
        {
            if (!string.IsNullOrEmpty(value))
                _open_id = value;
        }
    }

    private string _user_id = "";
    public string UserId
    {
        get
        {
#if UNITY_EDITOR
            if (string.IsNullOrEmpty(_user_id))
                _user_id = Guid.NewGuid().ToString("N");
#endif
            return _user_id;
        }
        set
        {
            _user_id = value;
        }
    }
    public string UserName { get; set; }
    public string UserAvatar { get; set; }
    public string UserProvince { get; set; }
    public int DataUpdateTime { get; set; }
    public int GameVersion { get; set; }
    public Vector3 CameraRecord { get; set; }
    public Dictionary<int, int> RecordBubbleItem { get; set; }
    public long Coin
    {
        get => GetPropNum((int)PropEnum.Coin);
    }

    public long BuildCoin
    {
        get => GetPropNum((int)PropEnum.BuildCoin);
    }
    public long Energy
    {
        get => GetPropNum((int)PropEnum.Energy);
    }
    public long StageStar
    {
        get => GetPropNum((int)PropEnum.StageStar);
    }

    public long WheelStar
    {
        get => GetPropNum((int)PropEnum.WheelStar);
    }

    private bool _musicMute;

    public bool MusicMute
    {
        get => _musicMute;
        set
        {
            _musicMute = value;

            storageService.Save(Constants.StorageKey.MusicMute, value);
            TypeEventSystem.Send<MusicMuteEvent>(new MusicMuteEvent(value));
        }
    }

    private bool _soundMute;

    public bool SoundMute
    {
        get => _soundMute;
        set
        {
            _soundMute = value;

            storageService.Save(Constants.StorageKey.SoundMute, value);
            TypeEventSystem.Send<SoundMuteEvent>(new SoundMuteEvent(value));
        }
    }

    private long rookieTipFlag = 0;

    public void MarkRookieTipFlag(int rookie_id)
    {
        BitUtils.Flag(ref rookieTipFlag, rookie_id);
    }

    public bool IsRookieShowed(int rookie_id)
    {
        return BitUtils.IsFlag(rookieTipFlag, rookie_id);
    }

    public void PrintRookieTipFlag()
    {
        string str = "已经完成的引导===";
        for (int i = 0; i < 64; i++)
        {
            if (IsRookieShowed(i))
                str += $"{i}|";
        }
        Debug.Log(str);
    }

    private int _userType;

    public int UserType
    {
        get => _userType;
        set
        {
            _userType = value;

            storageService.Save(Constants.StorageKey.UserType, value);
            Debug.Log($">>> UserType >> Set > {value}");
        }
    }

    private string _fbAccount;

    public string FbAccount
    {
        get => _fbAccount;
        set
        {
            _fbAccount = value;

            storageService.Save(Constants.StorageKey.FbAccount, value);
        }
    }

    private string _installUid;

    public string InstallUid
    {
        get => _installUid;
        set
        {
            _installUid = value;

            storageService.Save(Constants.StorageKey.InstallUid, value);
        }
    }

    private int _todayNotificationCount;

    public int TodayNotificationCount
    {
        get => _todayNotificationCount;
        set
        {
            _todayNotificationCount = value;

            storageService.Save(Constants.StorageKey.TodayNotificationCount, value);
        }
    }

    private bool _isBuyBeginner;
    private bool _isBuyHeartBeatGift;
    private bool _isSmallBuyBeginner;
    private bool _duringCollectLoveCardTime;
    private int _isCurWheelFinish = 0;
    private int _beginnerGiftEndTime;
    private string _nowTriggerGiftProductID;
    private int _nowTriggerGiftEndTime;
    private int _afkRewardGetTime;
    private int _afkRewardGetCount;
    private int _maxLevel;
    private int _maxLevelTime;
    private int _wheelRequestIndex;
    private int _stageLevel;
    private int _cardBackId;
    private int _nextBuildId;
    private short _signDay;
    private int _lastSignTime;
    private int _registerTime;
    private int _lastGoldTime;
    private int _lastQuitTime;
    private int _openBetLevel;
    private int _lastShowBetLevel;
    private int _nowBet;
    private int _todayWatchShopAdTime;
    private int _todayWatchWheelAdTime;
    private int _todayBrokenReceiveTime;

    private string _selectLanguage;
    private int _interAdInterval = -1;
    private int _levelExperienceValue;

    private float _cumulativeRechargeAmount;
    private int _cumulativeRechargeCount;
    private int _failSameLevelTimes;

    private int _firstChargeUiOpenLv;
    private int _successiveVictory;
    private ActivitySaveData _activitySaveData;
    private int _todayLevelPassTimes;
    private int _todayLaunchTimes;
    private FarmingProgress _farmingProgress;
    private int _lastRefreshTime;
    private Dictionary<int, long> propDic;
    private Dictionary<int, int> timePropStartDic;
    private Dictionary<int, int> buildSelectDic;
    private Dictionary<int, bool> powerItemUnlockDic;
    private Dictionary<int, bool> isFirstUseBetDic;
    private Dictionary<string, bool> specialCardDic;
    private Dictionary<int, long> waitAddPropDic;
    private Dictionary<FlagType, bool> dailyFlagDic;  //每日的标记
    private Dictionary<FlagType, int> timeFlagDic;//购买标记
    private Dictionary<string, bool> firstPopupDic;//游戏首次弹窗标记
    private Dictionary<int, int> mergeItemData; //<格子id, 合成物id>
    private Dictionary<int, bool> unlockCloudData; //已解锁的云朵
    private Dictionary<int, bool> unlockGridData; //已解锁的格子
    private Dictionary<int, int> gridExpData; //格子经验
    private Dictionary<int, MergeBubbleModel> mergeBubbleData; //合成物气泡
    private Dictionary<int, MergeOrderInfoModel> mergeOrderData; //合成订单
    private Dictionary<int, MergeRegionModel> mergeRegionData; //不同区域等级经验信息
    private List<int> mergeLevelBoxData; //合成等级宝箱
    private int mergeLevelBoxIndex; //获得关卡宝箱序号
    public int MergeLevelBoxIndex { get => mergeLevelBoxIndex; }
    private Dictionary<int, int> mergeRegionUnlockBoxOrder; //区域解锁时是第几个关卡宝箱
    private float mergeTodayOrderExp; //今日合成订单产生的经验
    private int mergeOrderExpDate; //今日合成订单产生的经验的日期
    private MergeShopInfoModel mergeShopData; //合成物商店信息
    private Dictionary<int, int> mergeItemStateData;//<合成物id,状态>合成物领取状态
    private EnergySaveData _energySaveData;//体力系统数据
    private Dictionary<int, MergeHotAirBallModel> mergeHotAirBallData; //热气球

    private int rookieStatus; //新手剧情状态

    private int _flowerStageStar;
    private int _dailyWinUseTime;
    private bool _isFinishBattle;
    private int _vipBuyType;
    private int _vipEndTime;
    private int _vipLastRewardTime;
    private int _lastCoinAdTime;
    private int _lastFreeCoinAdTime;
    private int _freeCoinAdCount;
    private int _freeItemAdCount;
    private int _freeItemAdValue;
    private List<int> _unlock_npcs = new List<int>();

    private HandlePaidModel[] _handlePaidModelData;

    public int MaxLevel
    {
        get => _maxLevel;
        set
        {
            _maxLevel = value;
            _maxLevelTime = TimeUtils.UtcNow();
            SaveData(true);
            CheckBetOpen("MaxLevel");
            AnalyticUtils.ReportUser_Set(AnalyticsKey.LatestLevel, value);
        }
    }

    public int NowMaxLevel
    {
        get
        {
            if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel) != null &&
                ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
            {
                return ActivityManager.Instance.EndlessLevelActivity.GetMyData().level;
            }
            return _maxLevel;
        }
    }

    public int NowViewMaxLayer
    {
        get
        {
            if (ActivityManager.Instance.EndlessLevelActivity.IsOpenActivity())
            {
                return EndlessLevelProgress.ViewMaxLayer;
            }
            return _maxLevel;
        }
    }

    public int MaxLevelTime
    {
        get => _maxLevelTime;
    }

    public int NextBuildId
    {
        get => _nextBuildId;
        set
        {
            int old = _nextBuildId;
            _nextBuildId = value;
            SaveData();
            TypeEventSystem.Send<NextBuildChange>(new NextBuildChange(old, value));
        }
    }

    public int FlowerStageStar
    {
        get => _flowerStageStar;
        set
        {
            int old = _flowerStageStar;
            _flowerStageStar = value;
            SaveData();
            TypeEventSystem.Send<FlowerStageStarChange>(new FlowerStageStarChange(old, value));
        }
    }

    public float CumulativeRechargeAmount
    {
        get => _cumulativeRechargeAmount;
        set
        {
            _cumulativeRechargeAmount = value;
            SaveData();
            // AnalyticUtils.ReportUser_Set(AnalyticsKey.PurchaseUsdMoney, _cumulativeRechargeAmount);
            // CheckBetOpen("Money");
        }
    }

    public int CumulativeRechargeCount
    {
        get => _cumulativeRechargeCount;
        set
        {
            _cumulativeRechargeCount = value;
            SaveData();
        }
    }

    public void UpdateActivitySaveData()
    {
        SaveData();
    }
    public bool IsBuyBeginner { get => _isBuyBeginner; set { _isBuyBeginner = value; SaveData(); } }
    public bool IsBuyHeartBeatGift { get => _isBuyHeartBeatGift; set { _isBuyHeartBeatGift = value; SaveData(); } }
    public bool IsSmallBuyBeginner { get => _isSmallBuyBeginner; set { _isSmallBuyBeginner = value; SaveData(); } }
    public int BeginnerGiftEndTime { get => _beginnerGiftEndTime; set { _beginnerGiftEndTime = value; SaveData(); } }
    public string NowTriggerGiftProductID { get => _nowTriggerGiftProductID; set { _nowTriggerGiftProductID = value; SaveData(); } }
    public int NowTriggerGiftEndTime { get => _nowTriggerGiftEndTime; set { _nowTriggerGiftEndTime = value; SaveData(); } }
    public int AfkRewardGetTime { get => _afkRewardGetTime; set { _afkRewardGetTime = value; SaveData(); } }
    public int AfkRewardGetCount { get => _afkRewardGetCount; set { _afkRewardGetCount = value; SaveData(); } }
    public int IsCurWheelFinish { get => _isCurWheelFinish; set { _isCurWheelFinish = value; SaveData(); } }
    public int StageLevel { get => _stageLevel; set { _stageLevel = value; SaveData(); } }
    public int CardBackId { get => _cardBackId; set { _cardBackId = value; SaveData(); } }
    public int WheelRequestIndex { get => _wheelRequestIndex; set { _wheelRequestIndex = value; SaveData(); } }
    public short SignDay { get => _signDay; set { _signDay = value; SaveData(true); } }
    public int LastSignTime { get => _lastSignTime; set { _lastSignTime = value; SaveData(); } }
    public int RegisterTime { get => _registerTime; set { _registerTime = value; SaveData(); } }
    public int LastGoldTime { get => _lastGoldTime; set { _lastGoldTime = value; SaveData(); } }
    public int LastQuitTime { get => _lastQuitTime; set { _lastQuitTime = value; SaveData(); } }
    public int TodayWatchShopAdTime { get => _todayWatchShopAdTime; set { _todayWatchShopAdTime = value; SaveData(true); } }
    public int TodayWatchWheelAdTime { get => _todayWatchWheelAdTime; set { _todayWatchWheelAdTime = value; SaveData(true); } }
    public int TodayBrokenReceiveTime { get => _todayBrokenReceiveTime; set { _todayBrokenReceiveTime = value; SaveData(); } }
    public string SelectLanguage { get => _selectLanguage; set { _selectLanguage = value; SaveData(); } }
    public int InterAdInterval { get => _interAdInterval; set { _interAdInterval = value; SaveData(); } }
    public int LevelExperienceValue { get => _levelExperienceValue; set { _levelExperienceValue = value; SaveData(); } }

    public int FirstChargeUiOpenLv
    {
        get => _firstChargeUiOpenLv;
        set
        {
            _firstChargeUiOpenLv = value;
            SaveData();
        }
    }

    public int OpenBetLevel
    {
        get => _openBetLevel;
        set
        {
            _openBetLevel = value;
            SaveData();
        }
    }

    public int LastShowBetLevel
    {
        get => _lastShowBetLevel;
        set
        {
            _lastShowBetLevel = value;
            SaveData();
        }
    }

    public int NowBet
    {
        get => _nowBet;
        set
        {
            _nowBet = value;
            SaveData();
        }
    }

    public int FailSameLevelTimes
    {
        get => _failSameLevelTimes;
        set
        {
            _failSameLevelTimes = value;
            SaveData();
        }
    }

    public int SuccessiveVictory
    {
        get
        {
            if (ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.winStreak))
            {
                return ActivitySaveData.winStreak.WinCount;
            }
            else
            {
                return 0;
            }
        }
    }


    public ActivitySaveData ActivitySaveData => _activitySaveData;
    public FarmingProgress FarmingProgress => _farmingProgress;
    public PassRankProgress PassRankProgress => ActivitySaveData.passRankProgress;
    public CarRankProgress CarRankProgress => ActivitySaveData.carRankProgress;
    public GradientGiftProgress GradientGiftProgress => ActivitySaveData.gradientGiftProgress;
    public GiftGradientCookProgress GiftGradientCookProgress => ActivitySaveData.giftGradientCookProgress;
    public GiftGradientDigProgress GiftGradientDigProgress => ActivitySaveData.giftGradientDigProgress;
    public LimitPkData LimitPkData => ActivitySaveData.limitPkData;
    public CollectFlowerProgress CollectFlowerProgress => ActivitySaveData.flowerProgress;
    public EndlessLevelProgress EndlessLevelProgress => ActivitySaveData.endlessLevelProgress;
    public RabitGiftProgress RabitGiftProgress => ActivitySaveData.rabitGiftProgress;
    public LavaPassProgress LavaPassProgress => ActivitySaveData.lavaPassProgress;
    public LevelPassProgress LevelPassProgress => ActivitySaveData.levelPassProgress;
    public SeasonPassProgress SeasonPassProgress => ActivitySaveData.seasonPassProgress;
    public AdRewardProgress AdRewardProgress => ActivitySaveData.adRewardProgress;
    public PiggyData PiggyData => ActivitySaveData.piggy;
    public WinStreakData WinStreakData => ActivitySaveData.winStreak;
    public CollectLoveCardProgress CollectLoveCardProgress => ActivitySaveData.loveCardProgress;
    public CollectMusicProgress CollectMusicProgress => ActivitySaveData.musicProgress;
    public DigTreasureProgress DigTreasureProgress => ActivitySaveData.digTreasureProgress;
    public CookMealProgress CookMealProgress => ActivitySaveData.cookMealProgress;
    public CollectWaterProgress CollectWaterProgress => ActivitySaveData.waterProgress;
    public GiftPlusOneData GiftPlusOneData => ActivitySaveData.giftPlusOneData;
    public GiftPlusFourData GiftPlusFourData => ActivitySaveData.giftPlusFourData;
    public GiftDiscountData GiftDiscountData => ActivitySaveData.giftDiscountData;
    public GiftDragOneData GiftDragOneData => ActivitySaveData.giftDragOneData;
    public GiftDragTwoData GiftDragTwoData => ActivitySaveData.giftDragTwoData;
    public GiftDragSixData GiftDragSixData => ActivitySaveData.giftDragSixData;
    public MysteriousSeedProgress MysteriousSeedProgress => ActivitySaveData.mysteriousSeedProgress;
    public CollectHoneyProgress CollectHoneyProgress => ActivitySaveData.honeyProgress;
    public WheelProgress WheelProgress => ActivitySaveData.wheelProgress;

    public int TodayLevelPassTimes
    {
        get => _todayLevelPassTimes; set
        {
            _todayLevelPassTimes = value;
            SaveData();
        }
    }
    public int TodayLaunchTimes
    {
        get => _todayLaunchTimes;
        set
        {
            _todayLaunchTimes = value;
            CheckActivityReward();
            SaveData();
        }
    }
    public int LastRefreshTime { get => _lastRefreshTime; set { _lastRefreshTime = value; } }
    public bool IsFinishBattle { get => _isFinishBattle; set { _isFinishBattle = value; SaveData(); } }
    public int DailyWinUseTime { get => _dailyWinUseTime; set { _dailyWinUseTime = value; SaveData(); } }
    public int VipBuyType { get => _vipBuyType; set { _vipBuyType = value; SaveData(); } }
    public int VipEndTime { get => _vipEndTime; set { _vipEndTime = value; SaveData(); } }
    public int VipLastRewardTime { get => _vipLastRewardTime; set { _vipLastRewardTime = value; SaveData(); } }

    public int LastCoinAdTime
    {
        get => _lastCoinAdTime;
        set
        {
            _lastCoinAdTime = value;
            SaveData();
        }
    }

    public int LastFreeCoinAdTime
    {
        get => _lastFreeCoinAdTime;
        set
        {
            _lastFreeCoinAdTime = value;
            SaveData();
        }
    }

    public int FreeCoinAdCount
    {
        get => _freeCoinAdCount;
        set
        {
            _freeCoinAdCount = value;
            SaveData();
        }
    }

    public int FreeItemAdCount
    {
        get => _freeItemAdCount;
        set
        {
            _freeItemAdCount = value;
            SaveData();
        }
    }

    public int FreeItemAdValue
    {
        get => _freeItemAdValue;
        set
        {
            _freeItemAdValue = value;
            SaveData();
        }
    }

    public List<EmailInfoModel> EmailList { get; set; }
    public List<int> PreAddItem { get; set; } = new List<int>();
    public int LastChargeTime { get; set; }
    public int TodayChargeTimes { get; set; }
    public int TodayChargeMoney { get; set; }
    public int AllChargeMoney { get; set; }
    public int NoTodayChargeTime { get; set; }
    public string[] OrderList { get; set; }
    public EnergySaveData EnergySaveData => _energySaveData;


    public void InitActivitySaveData()
    {
        _activitySaveData = new ActivitySaveData();
    }

    public void ReadLocalData()
    {
        Debug.Log("DataService.ReadData");

        var gameDataStr = storageService.Load<string>(Constants.StorageKey.GameData, "");

        Debug.Log($"DataService.ReadData, gameDataStr={gameDataStr}");
        var gameData = string.IsNullOrEmpty(gameDataStr)
            ? new Dictionary<string, object>()
            : (Dictionary<string, object>)MiniJSON.Json.Deserialize(gameDataStr);
        _musicMute = (bool)storageService.Load<object>(Constants.StorageKey.MusicMute, false);
        _soundMute = (bool)storageService.Load<object>(Constants.StorageKey.SoundMute, false);

        gameData.TryGetValue(Constants.StorageKey.UserInfoData, out var userInfoDataObj);
        ReadGameData(userInfoDataObj);
        TodayLaunchTimes++;
        if (TodayLaunchTimes == 1)
            _todayNotificationCount = 0;
        else
            _todayNotificationCount = (int)storageService.Load<object>(Constants.StorageKey.TodayNotificationCount, 0);
    }

    private List<int> GetLocalDataInfo()
    {
        Debug.Log("DataService.GetLocalDataUpdateTime");

        var gameDataStr = storageService.Load<string>(Constants.StorageKey.GameData, "");
        var gameData = string.IsNullOrEmpty(gameDataStr)
            ? new Dictionary<string, object>()
            : (Dictionary<string, object>)MiniJSON.Json.Deserialize(gameDataStr);
        gameData.TryGetValue(Constants.StorageKey.UserInfoData, out var userInfoDataObj);
        List<int> info = new List<int>() { 0, 0 };
        if (userInfoDataObj != null)
        {
            var userInfoData = (Dictionary<string, object>)userInfoDataObj;
            userInfoData.TryGetValue(Constants.StorageKey.DataUpdateTime, out var dataUpdateTime);
            userInfoData.TryGetValue(Constants.StorageKey.MaxLevel, out var maxLevel);
            if (dataUpdateTime != null)
            {
                info[0] = Convert.ToInt32(dataUpdateTime);
            }
            if (maxLevel != null)
            {
                info[1] = Convert.ToInt32(maxLevel);
            }
        }
        return info;
    }

    public void SyncUserData(string user_id)
    {
        // WeChatMiniGame.ReadUserData();
        HuaweiCloudUtils.ReadUserData(user_id, (b, ret) =>
        {
            if (b)
            {
                GameCommon.IsRemoteData = true;
                if (!string.IsNullOrEmpty(ret))
                {
                    var gameData = (Dictionary<string, object>)MiniJSON.Json.Deserialize(ret);
                    if (gameData != null)
                    {
                        var dataInfo = GetLocalDataInfo();
                        var readOk = ReadGameData(gameData, dataInfo[0], dataInfo[1]);
                        if (!readOk)
                        {
                            ReadLocalData();
                        }
                    }
                }
                else
                {
                    SyncUserData(user_id);
                }
            }
            else
            {
                SyncUserData(user_id);
            }
        });
    }

    public void ReadAccountInfo()
    {
    }

    public bool ReadGameData(object userInfoDataObj, int localDataUpdateTime = 0, int localDataMaxLevel = 0)
    {
        var now = TimeUtils.UtcNow();
        if (userInfoDataObj != null)
        {
            object tempObj;
            var userInfoData = (Dictionary<string, object>)userInfoDataObj;
            userInfoData.TryGetValue(Constants.StorageKey.DataVersion, out var dataVersion);
            var dataUpdateTime = userInfoData.TryGetValue(Constants.StorageKey.DataUpdateTime, out tempObj) ? Convert.ToInt32(tempObj) : 0;
            var maxLevel = userInfoData.TryGetValue(Constants.StorageKey.MaxLevel, out tempObj) ? Convert.ToInt32(tempObj) : 0;

            if (localDataUpdateTime != 0 && localDataUpdateTime >= dataUpdateTime && localDataMaxLevel >= maxLevel)
            {
                //本地数据较新
                Debug.Log($"DataUpdateTime ====== localDataUpdateTime:{localDataUpdateTime} dataUpdateTime:{dataUpdateTime} localDataMaxLevel:{localDataMaxLevel} maxLevel:{maxLevel}");
                return false;
            }

            OldDataVersionFlag = userInfoData.TryGetValue(Constants.StorageKey.OldDataVersionFlag, out tempObj) ? Convert.ToBoolean(tempObj) : false;
            if (dataVersion != null && Convert.ToInt32(dataVersion) != Constants.DataVersion)
            {
                //数据版本不一致，需要做数据校对
                int oldVersion = Convert.ToInt32(dataVersion);
                if (oldVersion < 2)
                {
                    OldDataVersionFlag = true;
                }
            }
            OpenId = userInfoData.TryGetValue(Constants.StorageKey.OpenId, out tempObj) ? Convert.ToString(tempObj) : "";
            UserId = userInfoData.TryGetValue(Constants.StorageKey.UserId, out tempObj) ? Convert.ToString(tempObj) : "";
            UserName = userInfoData.TryGetValue(Constants.StorageKey.UserName, out tempObj) ? Convert.ToString(tempObj) : "";
            if (string.IsNullOrEmpty(UserName))
                UserName = GameUtils.GenerateRandomName();
            UserAvatar = userInfoData.TryGetValue(Constants.StorageKey.UserAvatar, out tempObj) ? Convert.ToString(tempObj) : "";
            UserProvince = userInfoData.TryGetValue(Constants.StorageKey.UserProvince, out tempObj) ? Convert.ToString(tempObj) : "";
            DataUpdateTime = userInfoData.TryGetValue(Constants.StorageKey.DataUpdateTime, out tempObj) ? Convert.ToInt32(tempObj) : 0;
            GameVersion = userInfoData.TryGetValue(Constants.StorageKey.GameVersion, out tempObj) ? Convert.ToInt32(tempObj) : 0;

            if (userInfoData.TryGetValue(Constants.StorageKey.CameraRecord, out tempObj) && tempObj != null)
            {
                var _cameraRecord = (string)tempObj;
                string[] record = _cameraRecord.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                CameraRecord = new Vector3(float.Parse(record[0]), float.Parse(record[1]), float.Parse(record[2]));
            }
            else
            {
                CameraRecord = new Vector3(-311, 350, 620);
            }

            rookieTipFlag = userInfoData.TryGetValue(Constants.StorageKey.RookieTipFlag, out tempObj) ? Convert.ToInt64(tempObj) : 0;
            if (string.IsNullOrEmpty(UserProvince))
            {
                DeviceUtils.GetLocationInfo(province =>
                {
                    UserProvince = province;
                });
            }
            _isBuyBeginner = userInfoData.TryGetValue(Constants.StorageKey.IsBuyBeginner, out tempObj) && Convert.ToBoolean(tempObj);

            _isBuyHeartBeatGift = userInfoData.TryGetValue(Constants.StorageKey.IsBuyHeartBeatGift, out tempObj) && Convert.ToBoolean(tempObj);
            _isSmallBuyBeginner = userInfoData.TryGetValue(Constants.StorageKey.IsSmallBuyBeginner, out tempObj) && Convert.ToBoolean(tempObj);
            _isCurWheelFinish = userInfoData.TryGetValue(Constants.StorageKey.IsCurWheelFinish, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _beginnerGiftEndTime = userInfoData.TryGetValue(Constants.StorageKey.BeginnerGiftEndTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _nowTriggerGiftProductID =
                userInfoData.TryGetValue(Constants.StorageKey.NowTriggerGiftProductID, out tempObj)
                    ? Convert.ToString(tempObj)
                    : "";
            _nowTriggerGiftEndTime = userInfoData.TryGetValue(Constants.StorageKey.NowTriggerGiftEndTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _afkRewardGetTime = userInfoData.TryGetValue(Constants.StorageKey.AfkRewardGetTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _afkRewardGetCount = userInfoData.TryGetValue(Constants.StorageKey.AfkRewardGetCount, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _maxLevel = userInfoData.TryGetValue(Constants.StorageKey.MaxLevel, out tempObj)
                ? (Convert.ToInt32(tempObj) == 0 ? 1 : Convert.ToInt32(tempObj))
                : 1;
            _maxLevelTime = userInfoData.TryGetValue(Constants.StorageKey.MaxLevelTime, out tempObj)
                ? (Convert.ToInt32(tempObj) == 0 ? 1 : Convert.ToInt32(tempObj))
                : 1;
            _nextBuildId = userInfoData.TryGetValue(Constants.StorageKey.NextBuildId, out tempObj)
                ? (Convert.ToInt32(tempObj) == 0 ? 1 : Convert.ToInt32(tempObj))
                : 1;
            _wheelRequestIndex = userInfoData.TryGetValue(Constants.StorageKey.WheelRequestIndex, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _stageLevel = userInfoData.TryGetValue(Constants.StorageKey.StageLevel, out tempObj)
                ? (Convert.ToInt32(tempObj) == 0 ? 1 : Convert.ToInt32(tempObj))
                : 1;
            _signDay = userInfoData.TryGetValue(Constants.StorageKey.UserSignDay, out tempObj)
                ? Convert.ToInt16(tempObj)
                : (short)0;
            _lastSignTime = userInfoData.TryGetValue(Constants.StorageKey.UserLastSignTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _registerTime = userInfoData.TryGetValue(Constants.StorageKey.UserInfoRegisterTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : now;
            _lastGoldTime = userInfoData.TryGetValue(Constants.StorageKey.GetGoldTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _lastQuitTime = userInfoData.TryGetValue(Constants.StorageKey.LastQuitTime, out tempObj)
                ? (Convert.ToInt32(tempObj) == 0 ? TimeUtils.UtcNow() : Convert.ToInt32(tempObj))
                : TimeUtils.UtcNow();
            //_cardBackId = userInfoData.TryGetValue(Constants.StorageKey.CardBackId, out tempObj)
            //    ? Convert.ToInt32(tempObj) : Constants.CardBackRes.First().Key;
            _cardBackId = 0;
            _todayWatchShopAdTime = userInfoData.TryGetValue(Constants.StorageKey.TodayWatchShopAdTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _todayWatchWheelAdTime = userInfoData.TryGetValue(Constants.StorageKey.TodayWatchWheelAdTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _todayBrokenReceiveTime = userInfoData.TryGetValue(Constants.StorageKey.TodayBrokenReceiveTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _firstChargeUiOpenLv = userInfoData.TryGetValue(Constants.StorageKey.FirstChargeUiOpenLv, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _openBetLevel = userInfoData.TryGetValue(Constants.StorageKey.OpenBetLevel, out tempObj)
                ? (Convert.ToInt32(tempObj) == 0 ? 1 : Convert.ToInt32(tempObj))
                : 1;
            _lastShowBetLevel = userInfoData.TryGetValue(Constants.StorageKey.LastShowBetLevel, out tempObj)
                ? (Convert.ToInt32(tempObj) == 0 ? 1 : Convert.ToInt32(tempObj))
                : 1;
            _nowBet = userInfoData.TryGetValue(Constants.StorageKey.NowBet, out tempObj)
                ? (Convert.ToInt32(tempObj) == 0 ? 1 : Convert.ToInt32(tempObj))
                : 1;
            _failSameLevelTimes = userInfoData.TryGetValue(Constants.StorageKey.FailSameLevelTimes, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _flowerStageStar = userInfoData.TryGetValue(Constants.StorageKey.FlowerStageStar, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _successiveVictory = userInfoData.TryGetValue(Constants.StorageKey.SuccessiveVictory, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            if (userInfoData.TryGetValue(Constants.StorageKey.ActivitySaveData, out tempObj) && tempObj != null)
            {
                _activitySaveData = JsonConvert.DeserializeObject<ActivitySaveData>((string)tempObj);
            }
            else
            {
                _activitySaveData = new ActivitySaveData();
            }
            if (userInfoData.TryGetValue(Constants.StorageKey.FarmingProgress, out tempObj) && tempObj != null)
            {
                _farmingProgress = JsonConvert.DeserializeObject<FarmingProgress>((string)tempObj);
            }
            else
            {
                _farmingProgress = new FarmingProgress();
            }
            _todayLevelPassTimes = userInfoData.TryGetValue(Constants.StorageKey.TodayLevelPassTimes, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _todayLaunchTimes = userInfoData.TryGetValue(Constants.StorageKey.TodayLaunchTimes, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _lastRefreshTime = userInfoData.TryGetValue(Constants.StorageKey.LastRefreshTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : TimeUtils.UtcNow();
            _isFinishBattle = !userInfoData.TryGetValue(Constants.StorageKey.IsFinishBattle, out tempObj) ||
                              Convert.ToBoolean(tempObj);

            _interAdInterval = userInfoData.TryGetValue(Constants.StorageKey.InterAdInterval, out tempObj)
                ? Convert.ToInt32(tempObj)
                : (_maxLevel == 0 ? -1 : 0);
            _levelExperienceValue = userInfoData.TryGetValue(Constants.StorageKey.LevelExperienceValue, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _cumulativeRechargeAmount =
                userInfoData.TryGetValue(Constants.StorageKey.CumulativeRechargeAmount, out tempObj)
                    ? Convert.ToSingle(tempObj, CultureInfo.InvariantCulture)
                    : 0f;
            _cumulativeRechargeCount =
                userInfoData.TryGetValue(Constants.StorageKey.CumulativeRechargeCount, out tempObj)
                    ? Convert.ToInt32(tempObj)
                    : 0;
            _dailyWinUseTime = userInfoData.TryGetValue(Constants.StorageKey.DailyWinUseTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _vipBuyType = userInfoData.TryGetValue(Constants.StorageKey.VipBuyType, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _vipEndTime = userInfoData.TryGetValue(Constants.StorageKey.VipEndTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _vipLastRewardTime = userInfoData.TryGetValue(Constants.StorageKey.VipLastRewardTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _lastCoinAdTime = userInfoData.TryGetValue(Constants.StorageKey.LastCoinAdTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _lastFreeCoinAdTime = userInfoData.TryGetValue(Constants.StorageKey.LastFreeCoinAdTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _freeCoinAdCount = userInfoData.TryGetValue(Constants.StorageKey.FreeCoinAdCount, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _freeItemAdCount = userInfoData.TryGetValue(Constants.StorageKey.FreeItemAdCount, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            _freeItemAdValue = userInfoData.TryGetValue(Constants.StorageKey.FreeItemAdValue, out tempObj)
                ? (Convert.ToInt32(tempObj) == 0 ? (int)PropEnum.ItemEliminate : Convert.ToInt32(tempObj))
                : (int)PropEnum.ItemEliminate;
            LastChargeTime = userInfoData.TryGetValue(Constants.StorageKey.LastChargeTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            TodayChargeTimes = userInfoData.TryGetValue(Constants.StorageKey.TodayChargeTimes, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            TodayChargeMoney = userInfoData.TryGetValue(Constants.StorageKey.TodayChargeMoney, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            AllChargeMoney = userInfoData.TryGetValue(Constants.StorageKey.TodayChargeMoney, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;
            NoTodayChargeTime = userInfoData.TryGetValue(Constants.StorageKey.NoTodayChargeTime, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;

            if (userInfoData.TryGetValue(Constants.StorageKey.OrderList, out tempObj) && tempObj != null)
            {
                OrderList = JsonConvert.DeserializeObject<string[]>((string)tempObj);
            }

            if (userInfoData.TryGetValue(Constants.StorageKey.MergeItemData, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<int, int>>((string)tempObj);
                mergeItemData = new Dictionary<int, int>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                    {
                        mergeItemData[Convert.ToInt32(pair.Key)] = Convert.ToInt32(pair.Value);
                    }
                }
            }
            else
            {
                mergeItemData = new Dictionary<int, int>();
            }

            if (userInfoData.TryGetValue(Constants.StorageKey.MergeItemStateData, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<int, int>>((string)tempObj);
                mergeItemStateData = new Dictionary<int, int>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                    {
                        mergeItemStateData[Convert.ToInt32(pair.Key)] = Convert.ToInt32(pair.Value);
                    }
                }
            }
            else
            {
                mergeItemStateData = new Dictionary<int, int>();
            }


            if (userInfoData.TryGetValue(Constants.StorageKey.UnlockCloudData, out tempObj) && tempObj != null)
            {
                var unlockCloudList = JsonConvert.DeserializeObject<int[]>((string)tempObj).ToList();
                unlockCloudData = new Dictionary<int, bool>();
                foreach (var cloud_id in unlockCloudList)
                {
                    unlockCloudData.TryAdd(cloud_id, true);
                }
            }
            else
            {
                unlockCloudData = new Dictionary<int, bool>();
            }

            gridExpData = new Dictionary<int, int>();
            if (userInfoData.TryGetValue(Constants.StorageKey.UnlockGridData, out tempObj) && tempObj != null)
            {
                var unlockGridList = JsonConvert.DeserializeObject<int[]>((string)tempObj).ToList();
                unlockGridData = new Dictionary<int, bool>();
                foreach (var grid_id in unlockGridList)
                {
                    unlockGridData.TryAdd(grid_id, true);
                }
            }
            else
            {
                //旧账号初始化
                unlockGridData = new Dictionary<int, bool>();
                foreach (var item in configService.MergeMapConfig)
                {
                    if (item.Value.cloud_id == 0)
                    {
                        if (item.Value.unlock_exp == 0)
                            unlockGridData.TryAdd(item.Value.id, true);
                        else
                            gridExpData.TryAdd(item.Value.id, 0);
                    }
                    if (item.Value.item_id != -1)
                    {
                        mergeItemData.TryAdd(item.Value.id, item.Value.item_id);
                    }
                }
            }

            if (userInfoData.TryGetValue(Constants.StorageKey.GridExpData, out tempObj) && tempObj != null)
            {
                gridExpData = JsonConvert.DeserializeObject<Dictionary<int, int>>((string)tempObj);
            }

            mergeBubbleData = new Dictionary<int, MergeBubbleModel>();
            if (userInfoData.TryGetValue(Constants.StorageKey.MergeBubbleData, out tempObj) && tempObj != null)
            {
                var mergeBubbleList = JsonConvert.DeserializeObject<MergeBubbleModel[]>((string)tempObj);
                foreach (var item in mergeBubbleList)
                {
                    if (item != null)
                        mergeBubbleData.Add(item.id, item);
                }
            }

            mergeOrderData = new Dictionary<int, MergeOrderInfoModel>();
            if (userInfoData.TryGetValue(Constants.StorageKey.MergeOrderData, out tempObj) && tempObj != null)
            {
                var mergeOrderList = JsonConvert.DeserializeObject<MergeOrderInfoModel[]>((string)tempObj);
                foreach (var item in mergeOrderList)
                {
                    if (item != null)
                        mergeOrderData.Add(item.npc_id, item);
                }
            }

            mergeRegionData = new Dictionary<int, MergeRegionModel>();
            if (userInfoData.TryGetValue(Constants.StorageKey.MergeRegionData, out tempObj) && tempObj != null)
            {
                var mergeRegionList = JsonConvert.DeserializeObject<MergeRegionModel[]>((string)tempObj);
                foreach (var item in mergeRegionList)
                {
                    if (item != null)
                        mergeRegionData.Add(item.id, item);
                }
            }

            mergeLevelBoxData = new List<int>();
            if (userInfoData.TryGetValue(Constants.StorageKey.MergeLevelBoxData, out tempObj) && tempObj != null)
            {
                var mergeLevelBoxList = JsonConvert.DeserializeObject<List<int>>((string)tempObj);
                foreach (var item in mergeLevelBoxList)
                {
                    mergeLevelBoxData.Add(item);
                }
            }

            mergeLevelBoxIndex = userInfoData.TryGetValue(Constants.StorageKey.MergeLevelBoxIndex, out tempObj)
                ? Convert.ToInt32(tempObj)
                : 0;

            mergeRegionUnlockBoxOrder = new Dictionary<int, int>();
            if (userInfoData.TryGetValue(Constants.StorageKey.MergeRegionUnlockBoxOrder, out tempObj) && tempObj != null)
            {
                mergeRegionUnlockBoxOrder = JsonConvert.DeserializeObject<Dictionary<int, int>>((string)tempObj);
            }

            mergeTodayOrderExp = userInfoData.TryGetValue(Constants.StorageKey.MergeTodayOrderExp, out tempObj)
            ? Convert.ToSingle(tempObj)
            : 0;

            mergeOrderExpDate = userInfoData.TryGetValue(Constants.StorageKey.MergeOrderExpDate, out tempObj)
            ? Convert.ToInt32(tempObj)
            : 0;

            mergeHotAirBallData = new Dictionary<int, MergeHotAirBallModel>();
            if (userInfoData.TryGetValue(Constants.StorageKey.MergeHotAirBallData, out tempObj) && tempObj != null)
            {
                var mergeHotAirBallList = JsonConvert.DeserializeObject<MergeHotAirBallModel[]>((string)tempObj);
                foreach (var item in mergeHotAirBallList)
                {
                    if (configService.MergeHotAirBallConfig.TryGetValue(item.cfgId, out var cfg))
                    {
                        if (now < item.time + cfg.time)
                            mergeHotAirBallData.Add(item.id, item);
                    }
                }
            }

            if (userInfoData.TryGetValue(Constants.StorageKey.MergeShopData, out tempObj) && tempObj != null)
            {
                mergeShopData = JsonConvert.DeserializeObject<MergeShopInfoModel>((string)tempObj);
            }

            if (userInfoData.TryGetValue(Constants.StorageKey.PropDic, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<string, object>>((string)tempObj);
                propDic = new Dictionary<int, long>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                    {
                        propDic[Convert.ToInt32(pair.Key)] = Convert.ToInt64(pair.Value);
                    }
                }
            }
            else
            {
                propDic = new Dictionary<int, long>();
                foreach (var pair in GameUtils.AnalysisPropString(configService.OriginalItem))
                    AddProp(pair.Key, pair.Value, PropChangeWay.CreateRole);
            }

            if (userInfoData.TryGetValue(Constants.StorageKey.TimePropStartDic, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<string, object>>((string)tempObj);
                timePropStartDic = new Dictionary<int, int>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                        timePropStartDic[Convert.ToInt32(pair.Key)] = Convert.ToInt32(pair.Value);
                }
            }
            else
            {
                timePropStartDic = new Dictionary<int, int>();
            }

            if (userInfoData.TryGetValue(Constants.StorageKey.PowerItemUnlockDic, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<string, object>>((string)tempObj);
                powerItemUnlockDic = new Dictionary<int, bool>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                        powerItemUnlockDic[Convert.ToInt32(pair.Key)] = Convert.ToBoolean(pair.Value);
                }
            }
            else
            {
                powerItemUnlockDic = new Dictionary<int, bool>();

            }

            if (userInfoData.TryGetValue(Constants.StorageKey.DailyFlagDic, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<string, object>>((string)tempObj);
                dailyFlagDic = new Dictionary<FlagType, bool>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                    {
                        FlagType enumValue = (FlagType)Enum.Parse(typeof(FlagType), pair.Key);
                        dailyFlagDic[enumValue] = Convert.ToBoolean(pair.Value);
                    }
                }
            }
            else
            {
                dailyFlagDic = new Dictionary<FlagType, bool>();
            }

            if (userInfoData.TryGetValue(Constants.StorageKey.BuyFlagDic, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<string, object>>((string)tempObj);
                timeFlagDic = new Dictionary<FlagType, int>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                    {
                        FlagType enumValue = (FlagType)Enum.Parse(typeof(FlagType), pair.Key);
                        timeFlagDic[enumValue] = Convert.ToInt32(pair.Value);
                    }
                }
            }
            else
            {
                timeFlagDic = new Dictionary<FlagType, int>();
            }

            if (userInfoData.TryGetValue(Constants.StorageKey.FirstPopupDic, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<string, object>>((string)tempObj);
                firstPopupDic = new Dictionary<string, bool>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                    {
                        firstPopupDic[pair.Key] = Convert.ToBoolean(pair.Value);
                    }
                }
            }
            else
            {
                firstPopupDic = new Dictionary<string, bool>();
            }


            if (userInfoData.TryGetValue(Constants.StorageKey.IsFirstUseBetDic, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<string, object>>((string)tempObj);
                isFirstUseBetDic = new Dictionary<int, bool>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                        isFirstUseBetDic[Convert.ToInt32(pair.Key)] = Convert.ToBoolean(pair.Value);
                }
            }
            else
            {
                isFirstUseBetDic = new Dictionary<int, bool>();
            }
            if (userInfoData.TryGetValue(Constants.StorageKey.SpecialCardDic, out tempObj) && tempObj != null)
            {
                var dicData = JsonConvert.DeserializeObject<Dictionary<string, object>>((string)tempObj);
                specialCardDic = new Dictionary<string, bool>();
                if (dicData != null)
                {
                    foreach (var pair in dicData)
                        specialCardDic[Convert.ToString(pair.Key)] = Convert.ToBoolean(pair.Value);
                }
            }
            else
            {
                specialCardDic = new Dictionary<string, bool>();
            }


            if (userInfoData.TryGetValue(Constants.StorageKey.HandlePaidData, out tempObj) && tempObj != null)
            {
                _handlePaidModelData = JsonConvert.DeserializeObject<HandlePaidModel[]>((string)tempObj);
            }


            if (_registerTime == 0 || _registerTime == now)
            {
                AnalyticUtils.ReportUser_SetOnce(AnalyticsKey.FirstRegisterTime, _registerTime);
            }
            if (userInfoData.TryGetValue(Constants.StorageKey.EnergySaveData, out tempObj) && tempObj != null)
            {
                _energySaveData = JsonConvert.DeserializeObject<EnergySaveData>((string)tempObj);
            }
            else
            {
                _energySaveData = new EnergySaveData();
            }

            rookieStatus = userInfoData.TryGetValue(Constants.StorageKey.RookieStatus, out tempObj)
            ? Convert.ToInt32(tempObj)
            : 0;

        }
        else
        {
            UserName = GameUtils.GenerateRandomName();
            _lastSignTime = 0;
            _registerTime = ActivityManager.Instance.GetActivitySeverTime();
            _lastGoldTime = 0;
            _lastQuitTime = TimeUtils.UtcNow();
            _isBuyBeginner = false;
            _isBuyHeartBeatGift = false;
            _isSmallBuyBeginner = false;
            _duringCollectLoveCardTime = false;
            _beginnerGiftEndTime = 0;
            _nowTriggerGiftProductID = "";
            _nowTriggerGiftEndTime = 0;
            _afkRewardGetTime = 0;
            _afkRewardGetCount = 0;
            _isFinishBattle = true;
            _signDay = 0;
            _maxLevel = 1;
            _nextBuildId = 1;
            _wheelRequestIndex = 0;
            _stageLevel = 1;
            _openBetLevel = 1;
            _lastShowBetLevel = 1;
            _nowBet = 1;
            _failSameLevelTimes = 0;
            _todayWatchShopAdTime = 0;
            _todayWatchWheelAdTime = 0;
            _todayBrokenReceiveTime = 0;
            _firstChargeUiOpenLv = 0;
            _vipBuyType = 0;
            _vipEndTime = 0;
            _vipLastRewardTime = 0;
            _lastCoinAdTime = 0;
            _lastFreeCoinAdTime = 0;
            _freeCoinAdCount = 0;
            _freeItemAdCount = 0;
            _freeItemAdValue = (int)PropEnum.ItemEliminate;

            _flowerStageStar = 0;
            _cardBackId = 0;
            _activitySaveData = new ActivitySaveData();
            _farmingProgress = new FarmingProgress();
            _todayLevelPassTimes = 0;
            _todayLaunchTimes = 0;
            _lastRefreshTime = TimeUtils.UtcNow();
            _cumulativeRechargeAmount = 0f;
            _cumulativeRechargeCount = 0;
            _dailyWinUseTime = 0;
            propDic = new Dictionary<int, long>();
            waitAddPropDic = new Dictionary<int, long>();
            dailyFlagDic = new Dictionary<FlagType, bool>();
            timeFlagDic = new Dictionary<FlagType, int>();
            firstPopupDic = new Dictionary<string, bool>();
            timePropStartDic = new Dictionary<int, int>();
            buildSelectDic = new Dictionary<int, int>();
            powerItemUnlockDic = new Dictionary<int, bool>();
            isFirstUseBetDic = new Dictionary<int, bool>();
            specialCardDic = new Dictionary<string, bool>();
            mergeItemData = new Dictionary<int, int>();
            mergeBubbleData = new Dictionary<int, MergeBubbleModel>();
            mergeOrderData = new Dictionary<int, MergeOrderInfoModel>();
            mergeRegionData = new Dictionary<int, MergeRegionModel>();
            unlockCloudData = new Dictionary<int, bool>();
            unlockGridData = new Dictionary<int, bool>();
            gridExpData = new Dictionary<int, int>();
            mergeLevelBoxData = new List<int>();
            mergeLevelBoxIndex = 0;
            mergeRegionUnlockBoxOrder = new Dictionary<int, int>();
            mergeTodayOrderExp = 0;
            mergeOrderExpDate = 0;
            mergeHotAirBallData = new Dictionary<int, MergeHotAirBallModel>();
            mergeItemStateData = new Dictionary<int, int>();
            foreach (var item in configService.MergeMapConfig)
            {
                if (item.Value.cloud_id == 0)
                {
                    if (item.Value.unlock_exp == 0)
                        unlockGridData.TryAdd(item.Value.id, true);
                    else
                        gridExpData.TryAdd(item.Value.id, 0);
                }
                if (item.Value.item_id != -1)
                {
                    mergeItemData.TryAdd(item.Value.id, item.Value.item_id);
                }
            }

            _interAdInterval = 0;
            _levelExperienceValue = 0;
            foreach (var pair in GameUtils.AnalysisPropString(configService.OriginalItem))
            {
                AddProp(pair.Key, pair.Value, PropChangeWay.CreateRole);
            }
            _handlePaidModelData = null;

            LastChargeTime = 0;
            TodayChargeTimes = 0;
            TodayChargeMoney = 0;
            AllChargeMoney = 0;
            NoTodayChargeTime = 0;
            OrderList = (new List<string>()).ToArray();
            _energySaveData = new EnergySaveData();
            rookieStatus = 0;
            rookieTipFlag = 0;
            CameraRecord = new Vector3(-311, 350, 620);
            SaveData(true, true);
        }

        if (!TimeUtils.IsSameDay(_lastSignTime, now))
        {
            _todayWatchShopAdTime = 0;
            _todayWatchWheelAdTime = 0;
            _todayBrokenReceiveTime = 0;
            _dailyWinUseTime = 0;
        }

        return true;
    }

    public void SaveData(bool force = false, bool upload = false)
    {
        if (MaxLevel == 0)
        {
            Debug.LogError("数据还未初始化时不能调用SaveData ！！！");
            return;
        }

        var unlockCloudList = new List<int>();
        foreach (var item in unlockCloudData)
        {
            unlockCloudList.Add(item.Key);
        }
        var unlockGridList = new List<int>();
        foreach (var item in unlockGridData)
        {
            unlockGridList.Add(item.Key);
        }
        var mergeBubbleList = new List<MergeBubbleModel>();
        foreach (var item in mergeBubbleData)
        {
            mergeBubbleList.Add(item.Value);
        }
        var mergeOrderList = new List<MergeOrderInfoModel>();
        foreach (var item in mergeOrderData)
        {
            mergeOrderList.Add(item.Value);
        }
        var mergeRegionList = new List<MergeRegionModel>();
        foreach (var item in mergeRegionData)
        {
            mergeRegionList.Add(item.Value);
        }
        var mergeHotAirBallList = new List<MergeHotAirBallModel>();
        foreach (var item in mergeHotAirBallData)
        {
            mergeHotAirBallList.Add(item.Value);
        }
        string _cameraRecord = $"{CameraRecord.x},{CameraRecord.y},{CameraRecord.z}";


        var userInfoData = new Dictionary<string, object>()
        {
            {Constants.StorageKey.DataVersion, Constants.DataVersion},
            {Constants.StorageKey.OldDataVersionFlag, OldDataVersionFlag},
            {Constants.StorageKey.OpenId, OpenId},
            {Constants.StorageKey.DeviceId, DeviceUtils.GetDeviceId()},
            {Constants.StorageKey.UserId, UserId},
            {Constants.StorageKey.UserName, UserName},
            {Constants.StorageKey.UserAvatar, UserAvatar},
            {Constants.StorageKey.UserProvince, UserProvince},
            {Constants.StorageKey.DataUpdateTime, TimeUtils.UtcNow()},
            {Constants.StorageKey.GameVersion, GameVersion},
            {Constants.StorageKey.CameraRecord, _cameraRecord},
            {Constants.StorageKey.UserInfoRegisterTime, RegisterTime},
            {Constants.StorageKey.GetGoldTime, LastGoldTime},
            {Constants.StorageKey.LastQuitTime, LastQuitTime},
            {Constants.StorageKey.MaxLevel, MaxLevel},
            {Constants.StorageKey.MaxLevelTime, MaxLevelTime},
            {Constants.StorageKey.NextBuildId, NextBuildId},
            {Constants.StorageKey.IsBuyBeginner, IsBuyBeginner},
            {Constants.StorageKey.IsBuyHeartBeatGift, IsBuyHeartBeatGift},
            {Constants.StorageKey.IsSmallBuyBeginner, IsSmallBuyBeginner},
            {Constants.StorageKey.BeginnerGiftEndTime, BeginnerGiftEndTime},
            {Constants.StorageKey.NowTriggerGiftProductID, NowTriggerGiftProductID},
            {Constants.StorageKey.NowTriggerGiftEndTime, NowTriggerGiftEndTime},
            {Constants.StorageKey.AfkRewardGetTime, AfkRewardGetTime},
            {Constants.StorageKey.AfkRewardGetCount, AfkRewardGetCount},
            {Constants.StorageKey.StageLevel, StageLevel},
            {Constants.StorageKey.IsCurWheelFinish, IsCurWheelFinish},
            {Constants.StorageKey.OpenBetLevel, OpenBetLevel},
            {Constants.StorageKey.LastShowBetLevel, LastShowBetLevel},
            {Constants.StorageKey.WheelRequestIndex, WheelRequestIndex},
            {Constants.StorageKey.NowBet, NowBet},
            {Constants.StorageKey.FailSameLevelTimes, FailSameLevelTimes},
            {Constants.StorageKey.UserSignDay, SignDay},
            {Constants.StorageKey.UserLastSignTime, LastSignTime},
            {Constants.StorageKey.PropDic, JsonConvert.SerializeObject(propDic)},
            {Constants.StorageKey.TimePropStartDic, JsonConvert.SerializeObject(timePropStartDic)},
            {Constants.StorageKey.IsFirstUseBetDic,JsonConvert.SerializeObject(isFirstUseBetDic)},
            {Constants.StorageKey.SpecialCardDic,JsonConvert.SerializeObject(specialCardDic)},
            {Constants.StorageKey.PowerItemUnlockDic, JsonConvert.SerializeObject(powerItemUnlockDic)},
            {Constants.StorageKey.DailyFlagDic, JsonConvert.SerializeObject(dailyFlagDic)},
            {Constants.StorageKey.WaitAddPropDic, JsonConvert.SerializeObject(waitAddPropDic)},
            {Constants.StorageKey.BuyFlagDic, JsonConvert.SerializeObject(timeFlagDic)},
            {Constants.StorageKey.FirstPopupDic, JsonConvert.SerializeObject(firstPopupDic)},
            {Constants.StorageKey.CardBackId, CardBackId},
            {Constants.StorageKey.TodayWatchShopAdTime, TodayWatchShopAdTime},
            {Constants.StorageKey.TodayWatchWheelAdTime, TodayWatchWheelAdTime},
            {Constants.StorageKey.TodayBrokenReceiveTime, TodayBrokenReceiveTime},
            {Constants.StorageKey.SelectLanguage, SelectLanguage},
            {Constants.StorageKey.InterAdInterval, InterAdInterval},
            {Constants.StorageKey.LevelExperienceValue, LevelExperienceValue},
            {Constants.StorageKey.FirstChargeUiOpenLv,FirstChargeUiOpenLv},
            {Constants.StorageKey.SuccessiveVictory, SuccessiveVictory},
            {Constants.StorageKey.FlowerStageStar, FlowerStageStar},
            {Constants.StorageKey.TodayLevelPassTimes, TodayLevelPassTimes},
            {Constants.StorageKey.TodayLaunchTimes, TodayLaunchTimes},
            {Constants.StorageKey.LastRefreshTime, LastRefreshTime},
            {Constants.StorageKey.CumulativeRechargeAmount, CumulativeRechargeAmount},
            {Constants.StorageKey.CumulativeRechargeCount, CumulativeRechargeCount},
            {Constants.StorageKey.IsFinishBattle, IsFinishBattle},
            {Constants.StorageKey.DailyWinUseTime, DailyWinUseTime},
            {Constants.StorageKey.VipBuyType, VipBuyType},
            {Constants.StorageKey.VipEndTime, VipEndTime},
            {Constants.StorageKey.VipLastRewardTime, VipLastRewardTime},
            {Constants.StorageKey.ActivitySaveData, JsonConvert.SerializeObject(ActivitySaveData)},
            {Constants.StorageKey.FarmingProgress, JsonConvert.SerializeObject(FarmingProgress)},
            {Constants.StorageKey.LastCoinAdTime, LastCoinAdTime},
            {Constants.StorageKey.LastFreeCoinAdTime, LastFreeCoinAdTime},
            {Constants.StorageKey.FreeCoinAdCount, FreeCoinAdCount},
            {Constants.StorageKey.FreeItemAdCount, FreeItemAdCount},
            {Constants.StorageKey.FreeItemAdValue, FreeItemAdValue},
            {Constants.StorageKey.HandlePaidData, JsonConvert.SerializeObject(HandlePaidModelData)},
            {Constants.StorageKey.LastChargeTime, LastChargeTime},
            {Constants.StorageKey.TodayChargeTimes, TodayChargeTimes},
            {Constants.StorageKey.TodayChargeMoney, TodayChargeMoney},
            {Constants.StorageKey.AllChargeMoney, AllChargeMoney},
            {Constants.StorageKey.NoTodayChargeTime, NoTodayChargeTime},
            {Constants.StorageKey.OrderList, JsonConvert.SerializeObject(OrderList)},
            {Constants.StorageKey.MergeItemData, JsonConvert.SerializeObject(mergeItemData)},
            {Constants.StorageKey.MergeBubbleData, JsonConvert.SerializeObject(mergeBubbleList.ToArray())},
            {Constants.StorageKey.MergeOrderData, JsonConvert.SerializeObject(mergeOrderList.ToArray())},
            {Constants.StorageKey.MergeRegionData, JsonConvert.SerializeObject(mergeRegionList.ToArray())},
            {Constants.StorageKey.UnlockCloudData, JsonConvert.SerializeObject(unlockCloudList)},
            {Constants.StorageKey.UnlockGridData, JsonConvert.SerializeObject(unlockGridList)},
            {Constants.StorageKey.GridExpData, JsonConvert.SerializeObject(gridExpData)},
            {Constants.StorageKey.MergeLevelBoxData, JsonConvert.SerializeObject(mergeLevelBoxData)},
            {Constants.StorageKey.MergeLevelBoxIndex, mergeLevelBoxIndex},
            {Constants.StorageKey.MergeRegionUnlockBoxOrder, JsonConvert.SerializeObject(mergeRegionUnlockBoxOrder)},
            {Constants.StorageKey.MergeTodayOrderExp, mergeTodayOrderExp},
            {Constants.StorageKey.MergeOrderExpDate, mergeOrderExpDate},
            {Constants.StorageKey.MergeShopData, JsonConvert.SerializeObject(mergeShopData)},
            {Constants.StorageKey.MergeHotAirBallData, JsonConvert.SerializeObject(mergeHotAirBallList.ToArray())},
            {Constants.StorageKey.MergeItemStateData, JsonConvert.SerializeObject(mergeItemStateData)},
            {Constants.StorageKey.EnergySaveData, JsonConvert.SerializeObject(EnergySaveData)},
            {Constants.StorageKey.RookieStatus, rookieStatus},
            {Constants.StorageKey.RookieTipFlag, rookieTipFlag},
        };

        var gameData = new Dictionary<string, object>
        {
            { Constants.StorageKey.UserInfoData, userInfoData },
        };


        string json = MiniJSON.Json.Serialize(gameData);
        storageService.Save<string>(Constants.StorageKey.GameData, json);
        if (force)
        {
            // Debug.LogError("====== savedata =======");
            storageService.SaveData();
        }
        //GameUtils.LogError($"存储数据{json}");

        if (upload)
            HuaweiCloudUtils.ForceWriteUserData(UserId, json);
        else
            if (GameCommon.IsRemoteData)
            HuaweiCloudUtils.WriteUserData(UserId, json);

    }

    public void SaveData(string json)
    {
        // 
        // storageService.Save<string>(Constants.StorageKey.GameData, json);
    }

    public int? GetBuildSelectIndex(int buildId)
    {
        if (!buildSelectDic.ContainsKey(buildId)) return null;
        return buildSelectDic[buildId];
    }

    public void SetBuildSelectIndex(int buildId, int selectIndex, Action onBuildEnd = null)
    {
        int? oldIndex = null;
        if (buildSelectDic.ContainsKey(buildId))
            oldIndex = buildSelectDic[buildId];
        buildSelectDic[buildId] = selectIndex;
        SaveData();
        TypeEventSystem.Send<BuildChoiceChange>(new BuildChoiceChange(buildId, oldIndex, selectIndex, onBuildEnd));
    }

    public bool ConsumeBuildCoin(long consumeNum, PropChangeWay useWay) => UseProp((int)PropEnum.BuildCoin, useWay, consumeNum);
    public bool ConsumeCoin(long consumeNum, PropChangeWay useWay) => UseProp((int)PropEnum.Coin, useWay, consumeNum);

    public void AddCoin(long addNum, PropChangeWay getWay, params object[] param) =>
        AddProp((int)PropEnum.Coin, addNum, getWay, param);

    public void AddBuildCoin(long addNum, PropChangeWay getWay, params object[] param) =>
        AddProp((int)PropEnum.BuildCoin, addNum, getWay, param);

    public void AddFirstPopup(string popupName)
    {
        if (firstPopupDic.TryAdd(popupName, true))
        {
            SaveData(true);
        }
    }
    public bool CheckFirstPopup(string popupName)
    {
        firstPopupDic.TryGetValue(popupName, out bool value);
        return value;
    }

    public void AddDailyFlag(FlagType type)
    {
        if (dailyFlagDic.TryAdd(type, true))
        {
            SaveData(true);
        }
    }

    public Dictionary<FlagType, int> GetTimeFlagDic()
    {
        return timeFlagDic;
    }

    public void AddTimeFlag(FlagType type)
    {
        int endTime = -1;
        DateTime nowTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (type == FlagType.DailyBuy)
        {
            endTime = TimeUtils.DateTimeToLong(new DateTime(nowTime.Year, nowTime.Month, nowTime.Day, 23, 59, 59, DateTimeKind.Local).AddDays(0));
        }
        else if (type == FlagType.WeekBuy)
        {
            endTime = TimeUtils.DateTimeToLong(new DateTime(nowTime.Year, nowTime.Month, nowTime.Day, 23, 59, 59, DateTimeKind.Local).AddDays(6));
        }
        else if (type == FlagType.MonthBuy)
        {
            endTime = TimeUtils.DateTimeToLong(new DateTime(nowTime.Year, nowTime.Month, nowTime.Day, 23, 59, 59, DateTimeKind.Local).AddDays(29));
        }
        else if (type == FlagType.ShowHeartBeatGift)
        {
            endTime = TimeUtils.DateTimeToLong(nowTime.AddSeconds(int.Parse(configService.ValueConfig["HeartBeatGiftSecond"])));
        }
        if (endTime != -1)
        {
            if (!timeFlagDic.ContainsKey(type))
            {
                timeFlagDic.Add(type, endTime);
            }
            else
            {
                timeFlagDic[type] = endTime;
            }
            SaveData(true);
        }
    }

    public bool CheckTimeFlag(FlagType type)
    {
        int value = 0;
        timeFlagDic.TryGetValue(type, out value);
        if (value == 0) return false;
        int nowTime = ActivityManager.Instance.GetActivitySeverTime();
        if (nowTime > value) return false;
        return true;
    }

    public bool CheckDailyFlag(FlagType type)
    {
        dailyFlagDic.TryGetValue(type, out bool value);
        return value;
    }

    public void ClearDailyFlag()
    {
        dailyFlagDic.Clear();
    }

    public void AddFlyAnimProp(int prop, long num)
    {
        waitAddPropDic ??= new Dictionary<int, long>();
        if (waitAddPropDic.ContainsKey(prop))
        {
            waitAddPropDic[prop] += num;
        }
        else
        {
            waitAddPropDic.Add(prop, num);
        }
    }

    public Dictionary<int, long> GetResultProp()
    {
        waitAddPropDic ??= new Dictionary<int, long>();
        return waitAddPropDic;
    }

    public void ClearResultProp()
    {
        waitAddPropDic?.Clear();
    }

    public void HandleBubbleItem(ref Dictionary<int, int> rewardDic)
    {
        if (!rewardDic.ContainsKey((int)PropEnum.BubbleGift)) return;
        foreach (var reward in rewardDic)
        {
            if (reward.Key == (int)PropEnum.BubbleGift)
            {
                int level = GetRegionLevel();
                if (level == 0) level = 1;
                int id = GetRegionId();
                int bubbleCount = reward.Value;
                foreach (var pair in configService.MergeLevelBoxConfig)
                {
                    if (pair.Value.level == level && pair.Value.region_id == id)
                    {
                        Dictionary<int, int> rewards = configService.GetBubbleReward(bubbleCount, pair.Value);
                        foreach (var t in rewards)
                        {
                            if (!rewardDic.ContainsKey(t.Key))
                            {
                                rewardDic.Add(t.Key, t.Value);
                            }
                            else
                            {
                                rewardDic[t.Key] += t.Value;
                            }
                        }
                        RecordBubbleItem = rewards;
                        break;
                    }
                }
                break;
            }
        }
        rewardDic.Remove((int)PropEnum.BubbleGift);
    }

    //保存获得的奖励数据
    public void SaveRewardData(Dictionary<int, int> rewardDic, PropChangeWay changeWay)
    {
        ActivityManager.Instance.HandleActivityItem(ref rewardDic);
        HandleBubbleItem(ref rewardDic);
        Dictionary<int, long> props = new Dictionary<int, long>();
        foreach (var pair in rewardDic)
        {
            props.Add(pair.Key, pair.Value);
        }
        AddProps(props, changeWay, Vector3.zero, false);
        SaveData(true, true);
    }

    public void AddProps(Dictionary<int, long> props, PropChangeWay getWay, params object[] param)
    {
        List<int> items = new List<int>();
        foreach (var pair in props)
        {
            if (configService.MergeItemConfig.ContainsKey(pair.Key))
            {
                for (int i = 0; i < pair.Value; i++)
                {
                    items.Add(pair.Key);
                }
            }
            else
            {
                AddProp(pair.Key, pair.Value, getWay, param);
            }
        }
        if (items.Count > 0)
        {
            int bubbleId = mergeBubbleData.Count;
            while (mergeBubbleData.ContainsKey(bubbleId))
            {
                bubbleId++;
            }
            MergeBubbleModel m = new MergeBubbleModel(bubbleId, items);
            mergeBubbleData.TryAdd(bubbleId, m);
            TypeEventSystem.Send<CreateMergeBubbleEvent>(new CreateMergeBubbleEvent(m));
        }
        SaveData();
    }

    public void AddProp(int prop_id, long num, PropChangeWay getWay, params object[] param)
    {
        if (num <= 0) return;
        if (configService.MergeItemConfig.ContainsKey(prop_id))
        {
            List<int> items = new List<int>();
            for (int i = 0; i < num; i++)
            {
                items.Add(prop_id);
            }
            int bubbleId = mergeBubbleData.Count;
            while (mergeBubbleData.ContainsKey(bubbleId))
            {
                bubbleId++;
            }
            MergeBubbleModel m = new MergeBubbleModel(bubbleId, items);
            mergeBubbleData.TryAdd(bubbleId, m);
            TypeEventSystem.Send<CreateMergeBubbleEvent>(new CreateMergeBubbleEvent(m));
            return;
        }

        long oldNum = 0;
        ItemModel itemModel = configService.ItemConfig[prop_id];
        int nowTime = TimeUtils.UtcNow();
        if (!propDic.ContainsKey(prop_id))
        {
            if (itemModel.type == (int)Constants.ItemType.TimeForceItem)
            {
                oldNum = nowTime;
                propDic.Add(prop_id, num + nowTime);
                timePropStartDic[prop_id] = nowTime;
            }
            else
                propDic.Add(prop_id, num);
        }
        else
        {
            oldNum = propDic[prop_id];
            if (itemModel.type == (int)Constants.ItemType.TimeForceItem)
            {
                if (oldNum == 0) oldNum = nowTime;
                if (oldNum <= nowTime)
                {
                    propDic[prop_id] = nowTime + num;
                    timePropStartDic[prop_id] = nowTime;
                }
                else
                    propDic[prop_id] += num;
            }
            else
                propDic[prop_id] += num;
        }
        SaveData();
        OnPropChange(prop_id, getWay, oldNum, propDic[prop_id], num, itemModel.type, param);
    }

    public long GetPropNum(int prop)
    {
        if (propDic == null)
            return 0;
        int propInt = (int)prop;
        if (propDic.TryGetValue(propInt, out var num))
        {
            return num;
        }
        propDic[propInt] = 0;
        SaveData();
        return 0;
    }

    public long GetPowerItemStartTime(int prop)
    {
        ItemModel itemModel = configService.ItemConfig[prop];
        if (itemModel.type != 4) return 0;
        int propInt = (int)prop;
        if (!timePropStartDic.ContainsKey(propInt)) return 0;
        return timePropStartDic[propInt];
    }

    public long GetPreAddItemConsume()
    {
        int coin = 0;
        foreach (var prop_id in PreAddItem)
        {
            PowerItemModel powerItemModel = configService.PowerItemConfig[prop_id];
            coin += powerItemModel.Price;
        }
        return coin;
    }

    //1添加，2删除某个，3删除全部
    public void OperatePreAddItem(int type, int prop_id)
    {
        if (type == 1)
        {
            if (!PreAddItem.Contains(prop_id))
            {
                PreAddItem.Add(prop_id);
                PowerItemModel powerItemModel = configService.PowerItemConfig[prop_id];
                long oldCoin = GoldView.Instance.GetNowTextCoin();
                GoldView.Instance.SetFakeCoin(oldCoin, oldCoin - powerItemModel.Price);
                TypeEventSystem.Send<UpdateSelectItem>();
                //减少金币
            }
        }
        else if (type == 2)
        {
            if (PreAddItem.Contains(prop_id)) PreAddItem.Remove(prop_id);
            PowerItemModel powerItemModel = configService.PowerItemConfig[prop_id];
            long oldCoin = GoldView.Instance.GetNowTextCoin();
            GoldView.Instance.SetFakeCoin(oldCoin, oldCoin + powerItemModel.Price);
            TypeEventSystem.Send<UpdateSelectItem>();
            //增加金币
        }
        else if (type == 3)
        {
            PreAddItem.Clear();
        }
        else if (type == 4)
        {
            PreAddItem.Clear();
            long oldCoin = GoldView.Instance.GetNowTextCoin();
            GoldView.Instance.SetFakeCoin(oldCoin, Coin);
            TypeEventSystem.Send<UpdateSelectItem>();
        }
    }

    public bool UseProp(int prop_id, PropChangeWay useWay, long num = 1)
    {
        if (num <= 0) return true;

        ItemModel itemModel = configService.ItemConfig[prop_id];
        if (useWay != PropChangeWay.GM && itemModel.type == 4) return true;
        if (!propDic.ContainsKey(prop_id)) return false;
        long oldNum = propDic[prop_id];
        if (oldNum >= num)
        {
            propDic[prop_id] -= num;
            // if (useWay == PropChangeWay.BuyUndo || useWay == PropChangeWay.BuyJokerCard ||
            //     useWay == PropChangeWay.BuyHandCard)
            // {
            //     if (GameController.Instance.IsPlaying)
            //     {
            //         GameController.Instance.BattleCtrl.gameData.AddComsumeCoin((int)num);
            //     }
            // }
        }
        else
            return false;
        SaveData(true);
        OnPropChange(prop_id, useWay, oldNum, propDic[prop_id], -num, itemModel.type, null);
        return true;
    }

    private void OnPropChange(int prop_id, PropChangeWay useWay, long oldNum, long newNum, long addNum, int propType,
        object[] param)
    {
        long diffNum = newNum - oldNum;
        //AnalyticUtils.ReportUser_Add(prop.ToString(), diffNum);
        AnalyticUtils.ReportUser_Set(prop_id.ToString(), newNum);
        if (propType == (int)Constants.ItemType.TimeForceItem)
        {
            if (!timePropStartDic.ContainsKey(prop_id))
                timePropStartDic[prop_id] = TimeUtils.UtcNow();
            int startTime = timePropStartDic[prop_id];
            var powerupMsg = new Dictionary<string, object>
            {
                { AnalyticsKey.PowerupType, prop_id.ToString() },
                { AnalyticsKey.PowerupTimeAdd, addNum },
                { AnalyticsKey.PowerupTimeAfterAdd, newNum - startTime },
                { AnalyticsKey.PowerupTimestampEnd, TimeUtils.GetDateFromTimestamp((int)newNum, "yyyy-MM-dd HH:mm:ss") },
            };
            AnalyticUtils.ReportEvent(AnalyticsKey.SoliPowerupLimitlessTimeAdd, powerupMsg);
        }

        var level = MaxLevel;
        var level_type = 1;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel) != null &&
            ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
        {
            level = EndlessLevelProgress.ViewMaxLayer;
            level_type = 2;
        }
        var msg = new Dictionary<string, object>
        {
            { AnalyticsKey.PropChannel, useWay.ToString() },
            { AnalyticsKey.PropChangeType, diffNum > 0 ? 1 : 2 },
            { AnalyticsKey.PropType, prop_id.ToString() },
            { AnalyticsKey.PropValue, Math.Abs(diffNum) },
            { AnalyticsKey.PropValueBefore, oldNum },
            { AnalyticsKey.StageId, level },
            { AnalyticsKey.StageType, level_type },
            { AnalyticsKey.MultiplyFactor, NowBet },
            { AnalyticsKey.MaxLevel, MaxLevel},
        };
        AnalyticUtils.ReportEvent(AnalyticsKey.SoliPropertyChange, msg);

        var propEnum = (PropEnum)prop_id;
        if (propEnum == PropEnum.Coin)
        {
            TypeEventSystem.Send<RefreshUserInfoCoin>(new RefreshUserInfoCoin(oldNum, newNum, useWay, param));
            CheckBetOpen("Coin");
        }
        if (propEnum == PropEnum.BuildCoin)
        {
            RefreshUserInfoBuildCoin t1 = GameObjManager.Instance.PopClass<RefreshUserInfoBuildCoin>(true);
            t1.Init(oldNum, newNum, useWay, param);
            TypeEventSystem.Send<RefreshUserInfoBuildCoin>(t1);
        }
        if (propEnum == PropEnum.StageStar)
        {
            TypeEventSystem.Send<StageStarChange>(new StageStarChange(oldNum, newNum));
            AnalyticUtils.ReportUser_Set(AnalyticsKey.LatestStars, newNum);
        }
        if (propEnum == PropEnum.WheelStar)
        {
            TypeEventSystem.Send<WheelStarChange>(new WheelStarChange(oldNum, newNum));
        }
        if (propEnum == PropEnum.Energy)
        {
            TypeEventSystem.Send<RefreshUserInfoEnergy>(new RefreshUserInfoEnergy(oldNum, newNum));
        }

        PropChangeEvent t = GameObjManager.Instance.PopClass<PropChangeEvent>(true);
        t.Init(prop_id, oldNum, newNum);
        TypeEventSystem.Send<PropChangeEvent>(t);
    }

    private void OnGlobalTimerRefreshEvent(GlobalTimerRefreshEvent obj)
    {
        if (timePropStartDic == null || timePropStartDic.Count <= 0) return;
        int nowTime = TimeUtils.UtcNow();
        List<int> keyList = timePropStartDic.Keys.ToList();
        foreach (var key in keyList)
        {
            if (propDic.ContainsKey(key) && propDic[key] <= nowTime)
            {
                int startTime = timePropStartDic[key];
                var powerupMsg = new Dictionary<string, object>
                {
                    { AnalyticsKey.PowerupType, ((int)key).ToString() },
                    { AnalyticsKey.PowerupTimeTotal, propDic[key] - startTime },
                    {
                        AnalyticsKey.PowerupTimestampStart,
                        TimeUtils.GetDateFromTimestamp(startTime, "yyyy-MM-dd HH:mm:ss")
                    },
                    {
                        AnalyticsKey.PowerupTimestampEnd,
                        TimeUtils.GetDateFromTimestamp((int)propDic[key], "yyyy-MM-dd HH:mm:ss")
                    },
                };
                AnalyticUtils.ReportEvent(AnalyticsKey.SoliPowerupLimitlessTimeEnd, powerupMsg);
                timePropStartDic.Remove(key);
                TypeEventSystem.Send(new PowerupTimeItemEndEvent((int)key, startTime, propDic[key]));
            }
        }
    }

    public int GetCollectBet()
    {
        if (!propDic.ContainsKey((int)PropEnum.TimeItemDouble)) return 1;
        int nowTime = TimeUtils.UtcNow();
        List<int> keyList = timePropStartDic.Keys.ToList();
        foreach (var key in keyList)
        {
            if ((PropEnum)key == PropEnum.TimeItemDouble)
            {
                return propDic[key] <= nowTime ? 1 : 2;
            }
        }
        return 1;
    }

    public int GetDobuleCollectTime()
    {
        if (!propDic.ContainsKey((int)PropEnum.TimeItemDouble)) return 0;
        int nowTime = TimeUtils.UtcNow();
        List<int> keyList = timePropStartDic.Keys.ToList();
        foreach (var key in keyList)
        {
            if ((PropEnum)key == PropEnum.TimeItemDouble)
            {
                return (int)(propDic[key] <= nowTime ? 0 : propDic[key]);
            }
        }
        return 0;
    }

    //public void AddProp(Dictionary<int, int> propDic)
    //{
    //    foreach (var pair in propDic)
    //    {
    //        int propInt = (int)pair.Key;
    //        if (!this.propDic.ContainsKey(propInt))
    //            this.propDic.Add(propInt, pair.Value);
    //        else
    //            this.propDic[propInt] += pair.Value;
    //    }
    //    SaveData();
    //    if (propDic.ContainsKey(PropEnum.Coin))
    //    {
    //        int coinInt = (int)PropEnum.Coin;
    //        var param = new RefreshUserInfoCoin(this.propDic[coinInt] - propDic[PropEnum.Coin], this.propDic[coinInt]);
    //        TypeEventSystem.Send<RefreshUserInfoCoin>(param);
    //    }
    //    TypeEventSystem.Send<PropChangeEvent>();
    //}


    public bool GetPowerItemIsUnlock(int prop)
    {
        int key = (int)prop;
        if (!powerItemUnlockDic.ContainsKey(key)) return false;
        return powerItemUnlockDic[key];
    }

    public void SetUnlockPowerItem(int prop)
    {
        powerItemUnlockDic[(int)prop] = true;
        SaveData();
    }

    private void CheckBetOpen(string reason)
    {
        BetModel finalModel = configService.BetConfig.Last().Value;
        if (OpenBetLevel == finalModel.id) return;
        for (int i = OpenBetLevel + 1; i <= finalModel.id; i++)
        {
            BetModel checkModel = configService.BetConfig[i];
            bool isOpen = reason switch
            {
                "Money" => CumulativeRechargeAmount >= checkModel.moneyRequest,
                "Coin" => Coin >= checkModel.coinRequest,
                "MaxLevel" => MaxLevel >= checkModel.levelRequest,
                _ => false,
            };
            if (isOpen)
            {
                var msg = new Dictionary<string, object>
                {
                    { AnalyticsKey.MultiplyFactor, checkModel.bet },
                    { AnalyticsKey.MultiplyUnlockType, reason },
                    { AnalyticsKey.MultiplyUnlockCurrentStage, MaxLevel },
                    { AnalyticsKey.MultiplyUnlockCurrentCoin, Coin },
                };
                AnalyticUtils.ReportEvent(AnalyticsKey.SoliUnlockBet, msg);
                OpenBetLevel = checkModel.id;
            }
            else
                break;
        }
    }

    public bool IsFreeAd()
    {
        int seconds = (int)GetPropNum((int)PropEnum.WeekCard) - TimeUtils.UtcNow();
        if (seconds > 0) return true;
        seconds = (int)GetPropNum((int)PropEnum.MonthCard) - TimeUtils.UtcNow();
        if (seconds > 0) return true;
        return false;
    }

    public bool IsFirstUseBet(int betNum)
    {
        if (betNum == 1) return false;
        if (!isFirstUseBetDic.ContainsKey(betNum)) return true;
        return isFirstUseBetDic[betNum];
    }

    public int CollectFlowerEnableState()
    {
        int result = 0;
        if (CollectFlowerProgress == null) return result;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state == ActivityState.underWay)
        {
            result = 1;
        }
        else if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state == ActivityState.waitOpen)
        {
            result = 2;
        }
        return result;
    }

    //是否达到当前版本最高关卡
    public bool IsConfigMaxLevel()
    {
        return true;
    }

    public void SetFirstUseBet(int betNum, bool state)
    {
        isFirstUseBetDic[betNum] = state;
        SaveData();
    }

    public bool CheckSpecialCardTip(CardType cardType, ModifierModel[] modifierType)
    {
        foreach (var VARIABLE in modifierType)
        {
            if (Constants.SpecialModTypeList.Contains(VARIABLE.modType) && !specialCardDic.ContainsKey(Constants.ModType2StringDic[VARIABLE.modType]))
            {
                specialCardDic.Add(Constants.ModType2StringDic[VARIABLE.modType], true);
                GameUtils.HandlePairCard(VARIABLE.modType, ref specialCardDic);
                return true;
            }
        }
        if (Constants.SpecialCardList.Contains(cardType) && !specialCardDic.ContainsKey(Constants.CardType2StringDic[cardType]))
        {
            specialCardDic.Add(Constants.CardType2StringDic[cardType], true);
            GameUtils.HandlePairCard(cardType, ref specialCardDic);
            return true;
        }
        return false;
    }

    //TODO 获取微信游戏版本号
    public bool CheckClearActivityData()
    {
        int localVersion = GameVersion;
        int remoteVersion = DeviceUtils.GetVersionNum();
        GameVersion = remoteVersion;
        return localVersion != remoteVersion;
    }

    public HandlePaidModel[] HandlePaidModelData
    {
        get => _handlePaidModelData;
        set
        {
            _handlePaidModelData = value;
            SaveData();
        }
    }

    //TODO 检测结束的活动，有奖励则发放奖励并重置活动
    public void CheckActivityReward()
    {

    }

    public void CleanMergeData()
    {
        mergeItemData.Clear();
    }

    public Dictionary<int, int> GetMergeData()
    {
        return mergeItemData;
    }

    public Dictionary<int, MergeBubbleModel> GetMergeBubbleData()
    {
        return mergeBubbleData;
    }

    public Dictionary<int, MergeHotAirBallModel> GetMergeHotAirBallData()
    {
        return mergeHotAirBallData;
    }

    public bool HasMergeBubble(int bubbleId)
    {
        return mergeBubbleData.ContainsKey(bubbleId);
    }

    public void MoveMergeBubble(int bubbleId, Vector3 pos)
    {
        if (mergeBubbleData.ContainsKey(bubbleId))
        {
            mergeBubbleData[bubbleId].x = pos.x;
            mergeBubbleData[bubbleId].y = pos.y;
        }
    }

    public bool OpenMergeBubble(int bubbleId)
    {
        if (!mergeBubbleData.ContainsKey(bubbleId))
            return false;
        int emptyNumber = GetEmptyGridNumber();
        if (emptyNumber == 0)
            return false;

        int nearGridId = GetPosNearGrid(new Vector3(mergeBubbleData[bubbleId].x, mergeBubbleData[bubbleId].y, 0));
        nearGridId = GetNearEmptyGrid(nearGridId);

        List<int> newItems = new List<int>();
        List<int> items = mergeBubbleData[bubbleId].items.ToList();
        for (int i = 0; i < emptyNumber; i++)
        {
            if (items.Count > 0)
            {
                int new_grid_id = CreateMergeItem(nearGridId, items[0]);
                if (new_grid_id != -1)
                {
                    newItems.Add(new_grid_id);
                    items.RemoveAt(0);
                }
            }
        }

        if (newItems.Count == 0)
            return false;

        if (items.Count == 0)
            mergeBubbleData.Remove(bubbleId);
        else
            mergeBubbleData[bubbleId].items = items.ToArray();
        TypeEventSystem.Send<OpenMergeBubbleEvent>(new OpenMergeBubbleEvent(bubbleId, newItems));

        return true;
    }

    public void MoveMergeHotAirBall(int ballId, Vector3 pos)
    {
        if (mergeHotAirBallData.ContainsKey(ballId))
        {
            mergeHotAirBallData[ballId].x = pos.x;
            mergeHotAirBallData[ballId].y = pos.y;
        }
    }

    public int CreateMergeItem(int gridId, int itemId)
    {

        int shape = configService.MergeItemConfig[itemId].shape;
        int _gridId = GetNearEmptyGrid(gridId, shape);
        if (_gridId != -1)
            AddMergeItem(_gridId, itemId);
        return _gridId;
    }

    private void AddMergeItem(int gridId, int itemId)
    {
        mergeItemData.TryAdd(gridId, itemId);
        if (IsUnlockGrid(gridId))
        {
            UnlockMergeItem(itemId, gridId);
        }

        var cfgs = configService.MergeHotAirBallConfig.Values.Where(cfg => cfg.item_id == itemId).ToList();
        int number = GetMapMergeItemNumber(itemId);
        if (number == 1)
        {
            foreach (var _cfg in cfgs)
            {
                string[] param = _cfg.reward.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                int reward_item_id = int.Parse(param[0]);
                if (configService.MergeItemConfig[reward_item_id].itemType == (int)Constants.MergeItemType.AllMerge)
                {
                    int hotAirBallId = mergeHotAirBallData.Count;
                    while (mergeHotAirBallData.ContainsKey(hotAirBallId))
                    {
                        hotAirBallId++;
                    }
                    int time = TimeUtils.UtcNow();
                    MergeHotAirBallModel model = new MergeHotAirBallModel(hotAirBallId, _cfg.id, time);
                    mergeHotAirBallData.TryAdd(hotAirBallId, model);
                    TypeEventSystem.Send<CreateMergeHotAirBallEvent>(new CreateMergeHotAirBallEvent(model));
                    break;
                }
            }
        }
        else if (number == 2)
        {
            foreach (var _cfg in cfgs)
            {
                string[] param = _cfg.reward.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                int reward_item_id = int.Parse(param[0]);
                if (configService.MergeItemConfig[reward_item_id].itemType != (int)Constants.MergeItemType.AllMerge)
                {
                    int hotAirBallId = mergeHotAirBallData.Count;
                    while (mergeHotAirBallData.ContainsKey(hotAirBallId))
                    {
                        hotAirBallId++;
                    }
                    int time = TimeUtils.UtcNow();
                    MergeHotAirBallModel model = new MergeHotAirBallModel(hotAirBallId, _cfg.id, time);
                    mergeHotAirBallData.TryAdd(hotAirBallId, model);
                    TypeEventSystem.Send<CreateMergeHotAirBallEvent>(new CreateMergeHotAirBallEvent(model));
                    break;
                }
            }
        }
    }

    private void UnlockMergeItem(int itemId,int gridId = -1)
    {
        Debug.Log("UnlockMergeItem = " + itemId);
        //TODO 解锁相关
        if (!mergeItemStateData.ContainsKey(itemId))
        {
            mergeItemStateData.Add(itemId, 1);
        }
        TypeEventSystem.Send<UnlockMergeItemEvent>(new UnlockMergeItemEvent(itemId, gridId));
    }

    public int GetMergeItemState(int itemId)
    {
        if (mergeItemStateData.ContainsKey(itemId))
        {
            return mergeItemStateData[itemId];
        }
        return 0;
    }

    public void SetMergeItemState(int itemId, int state)
    {
        if (mergeItemStateData.ContainsKey(itemId))
        {
            mergeItemStateData[itemId] = state;
        }
    }

    public bool CheckGridIsEmpty(int gridId)
    {
        if (!unlockGridData.ContainsKey(gridId))
            return false;
        if (gridId == -1 || mergeItemData.ContainsKey(gridId))
            return false;
        int itemId = GetGridItemId(gridId, out var _);
        return itemId == -1;
    }

    public bool CheckCanPutTarget(int gridId, int shape)
    {
        if (!CheckGridIsEmpty(gridId))
            return false;

        int u1GridId = MergeGameController.Instance.GetUpGrid(gridId);
        int u2GridId = MergeGameController.Instance.GetUpGrid(u1GridId);
        int r1GridId = MergeGameController.Instance.GetRightGrid(gridId);
        int r2GridId = MergeGameController.Instance.GetRightGrid(r1GridId);
        int u1r1GridId = MergeGameController.Instance.GetRightGrid(u1GridId);
        int u1r2GridId = MergeGameController.Instance.GetRightGrid(u1r1GridId);
        int u2r1GridId = MergeGameController.Instance.GetRightGrid(u2GridId);
        int u2r2GridId = MergeGameController.Instance.GetRightGrid(u2r1GridId);

        if (shape == 12)
        {
            if (u1GridId == -1)
                return false;
            if (!CheckGridIsEmpty(u1GridId))
                return false;
        }
        else if (shape == 21)
        {
            if (r1GridId == -1)
                return false;
            if (!CheckGridIsEmpty(r1GridId))
                return false;
        }
        else if (shape == 22)
        {
            if (u1GridId == -1 || r1GridId == -1 || u1r1GridId == -1)
                return false;
            if (!CheckGridIsEmpty(u1GridId) ||
                !CheckGridIsEmpty(r1GridId) ||
                !CheckGridIsEmpty(u1r1GridId))
                return false;
        }
        else if (shape == 23)
        {
            if (u1GridId == -1 || r1GridId == -1 || u1r1GridId == -1 ||
                u2GridId == 1 || u2r1GridId == -1)
                return false;
            if (!CheckGridIsEmpty(u1GridId) ||
                !CheckGridIsEmpty(r1GridId) ||
                !CheckGridIsEmpty(u1r1GridId) ||
                !CheckGridIsEmpty(u2GridId) ||
                !CheckGridIsEmpty(u2r1GridId))
                return false;
        }
        else if (shape == 32)
        {
            if (u1GridId == -1 || r1GridId == -1 || u1r1GridId == -1 ||
                r2GridId == -1 || u1r2GridId == -1)
                return false;
            if (!CheckGridIsEmpty(u1GridId) ||
                !CheckGridIsEmpty(r1GridId) ||
                !CheckGridIsEmpty(u1r1GridId) ||
                !CheckGridIsEmpty(r2GridId) ||
                !CheckGridIsEmpty(u1r2GridId))
                return false;
        }
        else if (shape == 33)
        {
            if (u1GridId == -1 || r1GridId == -1 || u1r1GridId == -1 ||
                r2GridId == -1 || u1r2GridId == -1 || u2GridId == -1 ||
                u2r1GridId == -1 || u2r2GridId == -1)
                return false;
            if (!CheckGridIsEmpty(u1GridId) ||
                !CheckGridIsEmpty(r1GridId) ||
                !CheckGridIsEmpty(u1r1GridId) ||
                !CheckGridIsEmpty(r2GridId) ||
                !CheckGridIsEmpty(u1r2GridId) ||
                !CheckGridIsEmpty(u2GridId) ||
                !CheckGridIsEmpty(u2r1GridId) ||
                !CheckGridIsEmpty(u2r2GridId))
                return false;
        }

        return true;
    }

    public int GetRigionStartGridId(int gridId)
    {
        int max = 500;
        while (gridId != -1)
        {
            gridId = MergeGameController.Instance.GetRightGrid(gridId);
            if (gridId == -1)
                gridId = MergeGameController.Instance.GetUpGrid(gridId);
            max--;
            if (max <= 0)
                break;
        }
        return gridId;
    }

    public int GetPosNearGrid(Vector3 pos)
    {
        var gridId = MergeGameController.Instance.GetPosGridId(pos);
        return gridId;
    }

    public int GetNearEmptyGrid(int sGridId, int shape = 11, Dictionary<int, bool> exincludes = null)
    {
        Dictionary<int, bool> find = new Dictionary<int, bool>();
        if (exincludes == null)
            exincludes = new Dictionary<int, bool>();
        int DoFind(int gridId)
        {
            List<int> grids = MergeGameController.Instance.GetNearShapeGrids(gridId, 11);
            grids.Insert(0, gridId);
            while (grids.Count > 0)
            {
                List<int> nextGrids = new List<int>();
                foreach (var _gridId in grids)
                {
                    if (_gridId == -1 || find.ContainsKey(_gridId))
                        continue;
                    if (!unlockGridData.ContainsKey(_gridId))
                        continue;
                    if (!exincludes.ContainsKey(_gridId) && CheckCanPutTarget(_gridId, shape))
                    {
                        return _gridId;
                    }
                    find.TryAdd(_gridId, true);

                    List<int> _grids = MergeGameController.Instance.GetNearShapeGrids(_gridId, 11);
                    foreach (var id in _grids)
                    {
                        if (id != -1 && !find.ContainsKey(id))
                        {
                            nextGrids.Add(id);
                        }
                    }
                }
                grids = nextGrids;
            }
            return -1;
        }
        int value = DoFind(sGridId);
        if (value != -1)
            return value;
        else
        {
            int regionStartGridId = GetRigionStartGridId(sGridId);
            foreach (var regionInfo in MergeGameController.Instance.GetRegionStartGridIds())
            {
                if (regionInfo.Item2 != regionStartGridId)
                {
                    value = DoFind(regionInfo.Item2);
                    if (value != -1)
                        return value;
                }
            }
        }

        return -1;
    }

    public bool MoveMergeItem(int fromGridId, int toGridId)
    {
        if (CheckGridIsEmpty(fromGridId))
            return false;

        int firstFromGridId = fromGridId;
        int firstToGridId = toGridId;
        int fromItemId = GetGridItemId(fromGridId, out fromGridId);

        if (fromItemId == -1)
            return false;
        int shape = configService.MergeItemConfig[fromItemId].shape;

        mergeItemData.Remove(fromGridId);
        if (CheckCanPutTarget(toGridId, shape))
        {
            mergeItemData.TryAdd(toGridId, fromItemId);
            MergeGameController.Instance.AddMoveObject(fromGridId, toGridId);
            return true;
        }
        else
        {
            if (fromGridId == toGridId)
            {
                mergeItemData.TryAdd(fromGridId, fromItemId);
                MergeGameController.Instance.AddMoveObject(fromGridId, toGridId);
                return true;
            }
            else
            {
                List<int> targetGrids = new List<int>(); //目标格子
                int u1GridId = MergeGameController.Instance.GetUpGrid(toGridId);
                int u2GridId = MergeGameController.Instance.GetUpGrid(u1GridId);
                int r1GridId = MergeGameController.Instance.GetRightGrid(toGridId);
                int r2GridId = MergeGameController.Instance.GetRightGrid(r1GridId);
                int u1r1GridId = MergeGameController.Instance.GetRightGrid(u1GridId);
                int u1r2GridId = MergeGameController.Instance.GetRightGrid(u1r1GridId);
                int u2r1GridId = MergeGameController.Instance.GetRightGrid(u2GridId);
                int u2r2GridId = MergeGameController.Instance.GetRightGrid(u2r1GridId);

                if (shape == 11)
                {
                    targetGrids.Add(toGridId);
                }
                else if (shape == 12)
                {
                    if (u1GridId != -1)
                    {
                        targetGrids.Add(toGridId);
                        targetGrids.Add(u1GridId);
                    }
                }
                else if (shape == 21)
                {
                    if (r1GridId != -1)
                    {
                        targetGrids.Add(toGridId);
                        targetGrids.Add(r1GridId);
                    }
                }
                else if (shape == 22)
                {
                    if (u1GridId != -1 && r1GridId != -1 && u1r1GridId != -1)
                    {
                        targetGrids.Add(toGridId);
                        targetGrids.Add(u1GridId);
                        targetGrids.Add(r1GridId);
                        targetGrids.Add(u1r1GridId);
                    }
                }
                else if (shape == 23)
                {
                    if (u1GridId != -1 && r1GridId != -1 && u1r1GridId != -1 &&
                        u2GridId != 1 && u2r1GridId != -1)
                    {
                        targetGrids.Add(u1GridId);
                        targetGrids.Add(r1GridId);
                        targetGrids.Add(u1r1GridId);
                        targetGrids.Add(u2GridId);
                        targetGrids.Add(u2r1GridId);
                    }
                }
                else if (shape == 32)
                {
                    if (u1GridId != -1 && r1GridId != -1 && u1r1GridId != -1 &&
                        r2GridId != -1 && u1r2GridId != -1)
                    {
                        targetGrids.Add(u1GridId);
                        targetGrids.Add(r1GridId);
                        targetGrids.Add(u1r1GridId);
                        targetGrids.Add(r2GridId);
                        targetGrids.Add(u1r2GridId);
                    }
                }
                else if (shape == 33)
                {
                    if (u1GridId != -1 && r1GridId != -1 && u1r1GridId != -1 &&
                        r2GridId != -1 && u1r2GridId != -1 && u2GridId != -1 &&
                        u2r1GridId != -1 && u2r2GridId != -1)
                    {
                        targetGrids.Add(u1GridId);
                        targetGrids.Add(r1GridId);
                        targetGrids.Add(u1r1GridId);
                        targetGrids.Add(r2GridId);
                        targetGrids.Add(u1r2GridId);
                        targetGrids.Add(u2GridId);
                        targetGrids.Add(u2r1GridId);
                        targetGrids.Add(u2r2GridId);
                    }
                }

                bool unlock = true;
                foreach (var grid_id in targetGrids)
                {
                    if (!unlockGridData.ContainsKey(grid_id))
                    {
                        unlock = false;
                        break;
                    }
                }

                if (targetGrids.Count > 0 && unlock)
                {
                    List<Tuple<int, int>> itemGrids = new List<Tuple<int, int>>();
                    //将目标格子的物品暂时移除
                    foreach (var gridId in targetGrids)
                    {
                        int _gridId = -1;
                        int _toItemId = GetGridItemId(gridId, out _gridId);
                        if (_toItemId != -1)
                        {
                            itemGrids.Add(new Tuple<int, int>(_gridId, _toItemId));
                            mergeItemData.Remove(_gridId);
                        }
                    }
                    //将目标物品放入目标格子
                    mergeItemData.TryAdd(toGridId, fromItemId);
                    //检查是否可以将移除的物品放入周围的空格
                    bool hasSpace = true;
                    Dictionary<int, bool> exincludes = new Dictionary<int, bool>();
                    foreach (var item in itemGrids)
                    {
                        int _shape = configService.MergeItemConfig[item.Item2].shape;
                        var _toGridId = GetNearEmptyGrid(item.Item1, _shape, exincludes);
                        if (_toGridId == -1)
                        {
                            hasSpace = false;
                            break;
                        }
                        exincludes.Add(_toGridId, true);
                    }
                    if (hasSpace)
                    {
                        //将移除的物品放入周围的空格
                        foreach (var item in itemGrids)
                        {
                            int _shape = configService.MergeItemConfig[item.Item2].shape;
                            var _toGridId = GetNearEmptyGrid(item.Item1, _shape);
                            mergeItemData.TryAdd(_toGridId, item.Item2);
                            MergeGameController.Instance.AddMoveObject(item.Item1, _toGridId);
                        }
                        MergeGameController.Instance.AddMoveObject(fromGridId, firstToGridId);
                    }
                    else
                    {
                        //空位不够
                        //还原移除的物件的位置
                        mergeItemData.Remove(toGridId);
                        foreach (var item in itemGrids)
                        {
                            mergeItemData.TryAdd(item.Item1, item.Item2);
                        }
                        //还原要移除的物件的位置
                        mergeItemData.TryAdd(fromGridId, fromItemId);
                    }
                }
                else
                {
                    //寻找最近的空位
                    var _toGridId = GetNearEmptyGrid(toGridId, shape);
                    if (_toGridId == -1)
                    {
                        mergeItemData.TryAdd(fromGridId, fromItemId);
                        MergeGameController.Instance.AddMoveObject(fromGridId, fromGridId);
                    }
                    else
                    {
                        mergeItemData.TryAdd(_toGridId, fromItemId);
                        MergeGameController.Instance.AddMoveObject(fromGridId, _toGridId);
                    }
                }
            }
        }

        return false;
    }

    public List<int> GetMergeGrids(int oriGridId, int dstGridId)
    {

        List<int> itemGrids = new List<int>();
        int oriItemId = GetGridItemId(oriGridId, out oriGridId);
        int dstItemId = GetGridItemId(dstGridId, out dstGridId);
        if (oriItemId == -1 || dstItemId == -1 || oriGridId == dstGridId)
            return itemGrids;

        int shape = 11;
        List<int> grids = new List<int>();
        //检测万能水晶
        if (oriItemId != -1 &&
            configService.MergeItemConfig[oriItemId].itemType == (int)Constants.MergeItemType.AllMerge)
        {
            shape = configService.MergeItemConfig[dstItemId].shape;
            grids = MergeGameController.Instance.GetNearShapeGrids(dstGridId, shape);
            if (configService.MergeItemConfig[dstItemId].itemType == (int)Constants.MergeItemType.Normal)
            {
                //检查目标高级状态是否普通合成物
                bool isAwaylsNormalItem = configService.GetMergeItemEndType(dstItemId) == Constants.MergeItemType.Normal;
                if (isAwaylsNormalItem)
                {
                    //检查目标周围是否有一样的物品
                    foreach (var grid_id in grids)
                    {
                        if (grid_id != oriGridId)
                        {
                            int _grid_id = grid_id;
                            int _dstItemId = GetGridItemId(_grid_id, out _grid_id);
                            if (_grid_id == grid_id && _dstItemId == dstItemId)
                            {
                                itemGrids.Add(dstGridId);
                                itemGrids.Add(_grid_id);
                                return itemGrids;
                            }
                        }
                    }

                    //检查目标周围是否有万能水晶
                    var _grids = MergeGameController.Instance.GetAroundGrids(dstGridId, shape);
                    foreach (var grid_id in _grids)
                    {
                        if (grid_id != oriGridId && grid_id != dstGridId)
                        {
                            int _grid_id = grid_id;
                            int _dstItemId = GetGridItemId(_grid_id, out _grid_id);
                            if (_grid_id == grid_id && _dstItemId != -1)
                            {
                                if (configService.MergeItemConfig[_dstItemId].itemType == (int)Constants.MergeItemType.AllMerge)
                                {
                                    itemGrids.Add(dstGridId);
                                    itemGrids.Add(_grid_id);
                                    return itemGrids;
                                }
                            }
                        }
                    }

                }
            }
        }
        else if (configService.MergeItemConfig[oriItemId].itemType == (int)Constants.MergeItemType.Normal)
        {
            shape = configService.MergeItemConfig[oriItemId].shape;
            grids = MergeGameController.Instance.GetNearShapeGrids(dstGridId, shape);
            //检查本身高级状态是否普通合成物
            bool isAwaylsNormalItem = true;
            var maxLvItemId = configService.MergeItemConfig[oriItemId].nextItemId;
            while (maxLvItemId != -1)
            {
                if (configService.MergeItemConfig[maxLvItemId].itemType != (int)Constants.MergeItemType.Normal)
                {
                    isAwaylsNormalItem = false;
                    break;
                }
                maxLvItemId = configService.MergeItemConfig[maxLvItemId].nextItemId;
            }
            if (isAwaylsNormalItem)
            {
                //检查目标是否一样的普通合成物且带有一个万能水晶
                if (dstItemId == oriItemId)
                {
                    foreach (var grid_id in grids)
                    {
                        if (grid_id != oriGridId && grid_id != dstGridId)
                        {
                            int _grid_id = grid_id;
                            int _dstItemId = GetGridItemId(_grid_id, out _grid_id);
                            if (_grid_id == grid_id && _dstItemId != -1)
                            {
                                if (configService.MergeItemConfig[_dstItemId].itemType == (int)Constants.MergeItemType.AllMerge)
                                {
                                    itemGrids.Add(dstGridId);
                                    itemGrids.Add(_grid_id);
                                    return itemGrids;
                                }
                            }
                        }
                    }
                }

                //检查目标以及周围是否有2个万能水晶
                if (configService.MergeItemConfig[dstItemId].itemType == (int)Constants.MergeItemType.AllMerge)
                {
                    int _shape = 11;
                    var _grids = MergeGameController.Instance.GetNearShapeGrids(dstGridId, _shape);
                    foreach (var grid_id in _grids)
                    {
                        if (grid_id != oriGridId)
                        {
                            int _grid_id = grid_id;
                            int _dstItemId = GetGridItemId(_grid_id, out _grid_id);
                            if (_grid_id == grid_id && _dstItemId != -1)
                            {
                                if (configService.MergeItemConfig[_dstItemId].itemType == (int)Constants.MergeItemType.AllMerge)
                                {
                                    itemGrids.Add(dstGridId);
                                    itemGrids.Add(_grid_id);
                                    return itemGrids;
                                }
                            }
                        }
                    }
                }
            }
        }

        if (oriItemId != dstItemId)
        {
            return itemGrids;
        }

        int nextItemId = MergeGameController.Instance.GetNextItemId(oriItemId);
        if (nextItemId == -1)
        {
            return itemGrids;
        }

        grids = MergeGameController.Instance.GetNearShapeGrids(dstGridId, shape);
        Dictionary<int, bool> find = new Dictionary<int, bool>();
        find.Add(oriGridId, true);
        find.Add(dstGridId, true);
        itemGrids.Add(dstGridId);
        while (grids.Count > 0)
        {
            List<int> nextGrids = new List<int>();
            for (int i = 0; i < grids.Count; i++)
            {
                var _gridId = grids[i];
                if (_gridId == -1 || find.ContainsKey(_gridId))
                    continue;
                int _itemId = GetGridItemId(_gridId, out _gridId);
                if (_itemId == oriItemId && !itemGrids.Contains(_gridId))
                {
                    itemGrids.Add(_gridId);
                    List<int> _grids = MergeGameController.Instance.GetNearShapeGrids(_gridId, shape);
                    foreach (var id in _grids)
                    {
                        if (id != -1 && !find.ContainsKey(id) && !nextGrids.Contains(id))
                        {
                            nextGrids.Add(id);
                        }
                    }
                    find.TryAdd(_gridId, true);
                }
            }
            grids = nextGrids;
        }

        return itemGrids;
    }

    public int GetGridItemId(int gridId, out int newGridId)
    {
        newGridId = gridId;
        if (unlockGridData.ContainsKey(gridId) && mergeItemData.ContainsKey(gridId))
            return mergeItemData[gridId];



        int d1GridId = MergeGameController.Instance.GetDownGrid(gridId);
        int d2GridId = MergeGameController.Instance.GetDownGrid(d1GridId);
        int l1GridId = MergeGameController.Instance.GetLeftGrid(gridId);
        int l2GridId = MergeGameController.Instance.GetLeftGrid(l1GridId);
        int d1l1GridId = MergeGameController.Instance.GetLeftGrid(d1GridId);
        int d1l2GridId = MergeGameController.Instance.GetLeftGrid(d1l1GridId);
        int d2l1GridId = MergeGameController.Instance.GetLeftGrid(d2GridId);
        int d2l2GridId = MergeGameController.Instance.GetLeftGrid(d2l1GridId);

        int itemId = -1;
        int shape = -1;
        if (d1GridId != -1)
        {
            if (unlockGridData.ContainsKey(d1GridId) && mergeItemData.ContainsKey(d1GridId))
            {
                itemId = mergeItemData[d1GridId];
                shape = configService.MergeItemConfig[itemId].shape;
                if (shape % 10 > 1)
                {
                    newGridId = d1GridId;
                    return itemId;
                }
            }
        }
        if (d2GridId != -1)
        {
            if (unlockGridData.ContainsKey(d2GridId) && mergeItemData.ContainsKey(d2GridId))
            {
                itemId = mergeItemData[d2GridId];
                shape = configService.MergeItemConfig[itemId].shape;
                if (shape % 10 > 2)
                {
                    newGridId = d2GridId;
                    return itemId;
                }
            }
        }
        if (l1GridId != -1)
        {
            if (unlockGridData.ContainsKey(l1GridId) && mergeItemData.ContainsKey(l1GridId))
            {
                itemId = mergeItemData[l1GridId];
                shape = configService.MergeItemConfig[itemId].shape;
                if (shape / 10 > 1)
                {
                    newGridId = l1GridId;
                    return itemId;
                }
            }
        }
        if (l2GridId != -1)
        {
            if (unlockGridData.ContainsKey(l2GridId) && mergeItemData.ContainsKey(l2GridId))
            {
                itemId = mergeItemData[l2GridId];
                shape = configService.MergeItemConfig[itemId].shape;
                if (shape / 10 > 2)
                {
                    newGridId = l2GridId;
                    return itemId;
                }
            }
        }
        if (d1l1GridId != -1)
        {
            if (unlockGridData.ContainsKey(d1l1GridId) && mergeItemData.ContainsKey(d1l1GridId))
            {
                itemId = mergeItemData[d1l1GridId];
                shape = configService.MergeItemConfig[itemId].shape;
                if (shape % 10 > 1 && shape / 10 > 1)
                {
                    newGridId = d1l1GridId;
                    return itemId;
                }
            }
        }
        if (d1l2GridId != -1)
        {
            if (unlockGridData.ContainsKey(d1l2GridId) && mergeItemData.ContainsKey(d1l2GridId))
            {
                itemId = mergeItemData[d1l2GridId];
                shape = configService.MergeItemConfig[itemId].shape;
                if (shape % 10 > 1 && shape / 10 > 2)
                {
                    newGridId = d1l2GridId;
                    return itemId;
                }
            }
        }
        if (d2l1GridId != -1)
        {
            if (unlockGridData.ContainsKey(d2l1GridId) && mergeItemData.ContainsKey(d2l1GridId))
            {
                itemId = mergeItemData[d2l1GridId];
                shape = configService.MergeItemConfig[itemId].shape;
                if (shape % 10 > 2 && shape / 10 > 1)
                {
                    newGridId = d2l1GridId;
                    return itemId;
                }
            }
        }
        if (d2l2GridId != -1)
        {
            if (unlockGridData.ContainsKey(d2l2GridId) && mergeItemData.ContainsKey(d2l2GridId))
            {
                itemId = mergeItemData[d2l2GridId];
                shape = configService.MergeItemConfig[itemId].shape;
                if (shape % 10 > 2 && shape / 10 > 2)
                {
                    newGridId = d2l2GridId;
                    return itemId;
                }
            }
        }

        return -1;
    }

    public bool DoMerge(int gridId, int dstGridId, out List<int> removes, out List<Tuple<int, int>> adds)
    {
        List<int> grids = GetMergeGrids(gridId, dstGridId);
        removes = new List<int>();
        adds = new List<Tuple<int, int>>();
        if (grids.Count < 2)
            return false;

        int itemId = GetGridItemId(gridId, out gridId);
        int gridIdx = 0;
        while (configService.MergeItemConfig[itemId].itemType == (int)Constants.MergeItemType.AllMerge)
        {
            itemId = GetGridItemId(grids[gridIdx++], out _);
        }
        int nextItemId = MergeGameController.Instance.GetNextItemId(itemId);
        if (nextItemId == -1)
            return false;

        //将待合成的物品移除
        grids.Insert(0, gridId);
        foreach (var _gridId in grids)
        {
            mergeItemData.Remove(_gridId);
            removes.Add(_gridId);
        }

        int newItemCount = grids.Count / 3;
        int oldItemCount = grids.Count % 3;
        int new_grid_id = -1;
        int addMergeExp = 0;
        for (int i = 0; i < newItemCount; i++)
        {
            var newGridId = CreateMergeItem(dstGridId, nextItemId);
            adds.Add(new Tuple<int, int>(newGridId, nextItemId));
            addMergeExp += configService.MergeItemConfig[nextItemId].exp;
            new_grid_id = newGridId;
        }
        for (int i = 0; i < oldItemCount; i++)
        {
            var newGridId = CreateMergeItem(dstGridId, itemId);
            adds.Add(new Tuple<int, int>(newGridId, itemId));
        }

        //挑选锁住的格子
        List<int> addExpGrids = new List<int>();
        List<int> lockGrids = gridExpData.Keys.ToList();

        //从初始解锁区域挑格子
        foreach (var grid_id in lockGrids)
        {
            if (configService.MergeMapConfig[grid_id].cloud_id == 0)
            {
                addExpGrids.Add(grid_id);
            }
        }

        Dictionary<int, int> oriGridExp = new Dictionary<int, int>();
        Dictionary<int, int> newGridExp = new Dictionary<int, int>();

        if (addMergeExp > 0)
        {
            while (addExpGrids.Count < 4 && lockGrids.Count > 0)
            {
                int lock_grid_id = MergeGameController.Instance.GetNearGridId(new_grid_id, lockGrids);
                if (lock_grid_id != -1)
                {
                    addExpGrids.Add(lock_grid_id);
                    lockGrids.Remove(lock_grid_id);
                }
            }
            addExpGrids.Sort((a, b) =>
            {
                int a_max = configService.MergeMapConfig[a].unlock_exp;
                int a_now = gridExpData[a];
                int a_need = a_max - a_now;
                int b_max = configService.MergeMapConfig[b].unlock_exp;
                int b_now = gridExpData[b];
                int b_need = b_max - b_now;
                if (a_need < b_need)
                    return 1;
                return -1;
            });
            //分配经验
            for (int i = 0; i < addExpGrids.Count; i++)
            {
                int _gridId = addExpGrids[i];
                int avg = (int)Math.Ceiling(addMergeExp / (float)(addExpGrids.Count - i));
                int now = gridExpData[_gridId];
                int max = configService.MergeMapConfig[_gridId].unlock_exp;
                int need = max - now;
                int use;
                if (avg > need)
                    use = need;
                else
                    use = avg;
                if (oriGridExp.ContainsKey(_gridId))
                    oriGridExp[_gridId] = gridExpData[_gridId];
                else
                    oriGridExp.Add(_gridId, gridExpData[_gridId]);
                gridExpData[_gridId] += use;
                if (newGridExp.ContainsKey(_gridId))
                    newGridExp[_gridId] = gridExpData[_gridId];
                else
                    newGridExp.Add(_gridId, gridExpData[_gridId]);
                addMergeExp -= use;
            }
        }

        List<int> unlockGrids = new List<int>();
        foreach (var item in gridExpData)
        {
            int now = item.Value;
            int max = configService.MergeMapConfig[item.Key].unlock_exp;
            if (now >= max)
            {
                unlockGrids.Add(item.Key);
                unlockGridData.TryAdd(item.Key, true);
                if (mergeItemData.ContainsKey(item.Key))
                    UnlockMergeItem(mergeItemData[item.Key]);
            }
        }
        foreach (var _gridId in unlockGrids)
        {
            gridExpData.Remove(_gridId);
        }

        TypeEventSystem.Send<FlyGridExpEvent>(new FlyGridExpEvent(new_grid_id, oriGridExp, newGridExp));

        SaveData();
        return true;
    }

    public int GetMapMergeItemNumber(int item_id)
    {
        int number = 0;
        MergeItemConfig cfg;
        foreach (var pair in mergeItemData)
        {
            if (unlockGridData.ContainsKey(pair.Key) && pair.Value == item_id)
            {
                number++;
                if (configService.MergeItemConfig.TryGetValue(item_id, out cfg))
                {
                    if (cfg.itemType == (int)Constants.MergeItemType.Npc)
                    {
                        _unlock_npcs.Add(item_id);
                    }
                }
            }
        }
        return number;
    }

    public int GetBubbleMergeItemNumber(int item_id)
    {
        int number = 0;
        foreach (var pair in mergeBubbleData)
        {
            foreach (var itemId in pair.Value.items)
            {
                if (itemId == item_id)
                {
                    number++;
                }
            }
        }
        return number;
    }

    public int GetEmptyGridNumber()
    {
        int count = 0;
        foreach (var item in unlockGridData)
        {
            if (item.Value == true && !mergeItemData.ContainsKey(item.Key))
            {
                count++;
            }
        }
        return count;
    }

    private MergeOrderInfoModel GenNewMergeOrder(int npc_id, int index = 1)
    {


        var cfgs = configService.MergeOrderDegreeConfig.Where(cfg => cfg.npc_id == npc_id).ToList();
        cfgs = cfgs.OrderBy(cfg => cfg.level).ToList();
        var regionId = cfgs[0].id;
        var limit = cfgs[0].limit == 1;
        var weightStr = cfgs[0].weight;
        var regionInfo = GetRegionInfo(regionId);

        float remainder = float.MaxValue;
        if (limit)
        {
            int key = regionId * 1000 + regionInfo.level + 1;
            while (!configService.MergeRegionRewardsConfig.ContainsKey(key))
                key--;
            int max = configService.MergeRegionRewardsConfig[key].limit;
            int time = TimeUtils.UtcNow();
            if (!TimeUtils.IsSameDay(time, mergeOrderExpDate))
            {
                mergeOrderExpDate = time;
                mergeTodayOrderExp = 0;
            }

            float now = mergeTodayOrderExp;
            remainder = max - now;
            if (remainder <= 0)
            {
                var m = new MergeOrderInfoModel(npc_id, 0, index);
                m.over = true;
                return m;
            }
        }

        foreach (var cfg in cfgs)
        {
            if (cfg.index == index)
            {
                weightStr = cfg.weight;
                break;
            }
            if (cfg.index == 0 && cfg.level > regionInfo.level)
                break;
            weightStr = cfg.weight;
        }

        string[] orderGroup = weightStr.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        List<int> orderIds = new List<int>();
        List<int> orderWeights = new List<int>();
        foreach (var info in orderGroup)
        {
            string[] param = info.Split(GameUtils.FirstSeparator);
            orderIds.Add(int.Parse(param[0]));
            orderWeights.Add(int.Parse(param[1]));
        }

        List<int> targetOrderIds = new List<int>();
        List<int> targetOrderWeights = new List<int>();
        for (int i = 0; i < orderIds.Count; i++)
        {
            int orderId = orderIds[i];
            var rewardsStr = configService.MergeOrderListConfig[orderId].rewards;
            string[] rewardsGroup = rewardsStr.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            if (limit)
            {
                float exp = 0;
                string[] param = rewardsGroup[0].Split(GameUtils.FirstSeparator);
                int itemId = int.Parse(param[0]);
                int itemNum = int.Parse(param[1]);
                if (itemId >= Constants.MergeExpBar1ItemId && itemId <= Constants.MergeExpBar5ItemId)
                {
                    exp = Mathf.Pow(3, itemId - Constants.MergeExpBar1ItemId) * (256f / 81f) * itemNum;
                    if (exp <= remainder)
                    {
                        targetOrderIds.Add(orderId);
                        targetOrderWeights.Add(orderWeights[i]);
                    }
                }
            }
            else
            {
                targetOrderIds.Add(orderId);
                targetOrderWeights.Add(orderWeights[i]);
            }
        }

        if (targetOrderIds.Count > 0)
        {
            int totalWeight = targetOrderWeights.Sum();
            float randomValue = GameUtils.RandomRange(0f, totalWeight);
            var targetOrderId = targetOrderIds[0];
            int cumulativeWeight = 0;
            for (int i = 0; i < targetOrderIds.Count; i++)
            {
                cumulativeWeight += targetOrderWeights[i];
                if (randomValue < cumulativeWeight)
                {
                    targetOrderId = targetOrderIds[i];
                    break;
                }
            }

            var target_rewardsStr = configService.MergeOrderListConfig[targetOrderId].rewards;
            string[] target_rewardsGroup = target_rewardsStr.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            string[] target_param = target_rewardsGroup[0].Split(GameUtils.FirstSeparator);
            int target_itemId = int.Parse(target_param[0]);
            int target_itemNum = int.Parse(target_param[1]);
            if (target_itemId >= Constants.MergeExpBar1ItemId && target_itemId <= Constants.MergeExpBar5ItemId)
            {
                var target_exp = Mathf.Pow(3, target_itemId - Constants.MergeExpBar1ItemId) * (256f / 81f) * target_itemNum;
                mergeTodayOrderExp += target_exp;
            }

            string item_group = configService.MergeOrderListConfig[targetOrderId].group;
            string[] group = item_group.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            List<int> itemLevel = new List<int>();
            List<int> itemCount = new List<int>();
            foreach (var info in group)
            {
                string[] param = info.Split(GameUtils.FirstSeparator);
                itemLevel.Add(int.Parse(param[0]));
                itemCount.Add(int.Parse(param[1]));
            }

            List<int> targetItemIds = new List<int>();
            string item_weight = configService.MergeOrderListConfig[targetOrderId].item_weight;
            string[] itemWeight = item_weight.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            List<int> itemIds = new List<int>();
            List<int> itemWeights = new List<int>();
            foreach (var info in itemWeight)
            {
                string[] param = info.Split(GameUtils.FirstSeparator);
                itemIds.Add(int.Parse(param[0]));
                itemWeights.Add(int.Parse(param[1]));
            }
            var tempItemIds = new List<int>(itemIds);
            var tempItemWeights = new List<int>(itemWeights);
            for (int i = 0; i < itemLevel.Count; i++)
            {
                int itemId = tempItemIds[0];
                if (targetOrderId < 10000)
                {
                    cumulativeWeight = 0;
                    totalWeight = tempItemWeights.Sum();
                    randomValue = GameUtils.RandomRange(0f, totalWeight);
                    for (int j = 0; j < tempItemWeights.Count; j++)
                    {
                        cumulativeWeight += tempItemWeights[j];
                        if (randomValue <= cumulativeWeight)
                        {
                            itemId = tempItemIds[j];
                            tempItemIds.RemoveAt(j);
                            tempItemWeights.RemoveAt(j);
                            break;
                        }
                    }
                }
                else
                {
                    //订单id大于10000的特殊处理
                    itemId = tempItemIds[i];
                }
                targetItemIds.Add(itemId + itemLevel[i] - 1);
                if (tempItemIds.Count == 0)
                {
                    tempItemIds = new List<int>(itemIds);
                    tempItemWeights = new List<int>(itemWeights);
                }
            }
            var m = new MergeOrderInfoModel(npc_id, targetOrderId, index);
            m.count = itemCount.ToArray();
            m.items = targetItemIds.ToArray();
            List<int> process = new List<int>();
            for (int i = 0; i < m.items.Length; i++)
            {
                process.Add(Math.Min(m.count[i], GetMapMergeItemNumber(m.items[i])));
            }
            m.process = process.ToArray();
            return m;
        }
        else
        {
            var m = new MergeOrderInfoModel(npc_id, 0, index);
            m.over = true;
            return m;
        }

        return null;
    }

    public MergeOrderInfoModel GetMergeOrder(int npc_id, out bool newPro)
    {
        newPro = false;
        if (mergeOrderData.ContainsKey(npc_id))
        {
            var order = mergeOrderData[npc_id];
            if (order != null)
            {
                if (order.over)
                {
                    order = GenNewMergeOrder(npc_id, order.index);
                }
                if (!order.over)
                {
                    int lastPro = 0;
                    int nowPro = 0;
                    for (int i = 0; i < order.items.Length; i++)
                    {
                        lastPro += order.process[i];
                        order.process[i] = Math.Min(order.count[i], GetMapMergeItemNumber(order.items[i]));
                        nowPro += order.process[i];
                    }
                    newPro = nowPro > lastPro;
                }
            }
            return order;
        }
        MergeOrderInfoModel firstOrder = GenNewMergeOrder(npc_id, 1);
        mergeOrderData.Add(npc_id, firstOrder);
        return firstOrder;
    }

    public bool CheckMergeRookieOrder()
    {
        return IsFinishOrder(30003);
    }

    public bool IsFinishOrder(int npc_id)
    {
        var order = GetMergeOrder(npc_id, out bool _);
        if (order == null)
            return false;
        for (int i = 0; i < order.items.Length; i++)
        {
            int count = order.count[i];
            int process = order.process[i];
            if (process < count)
            {
                return false;
            }
        }

        return true;
    }

    public int GetMergeOrderPrice(int npc_id)
    {

        var order = GetMergeOrder(npc_id, out bool _);
        var price = 0;
        for (int i = 0; i < order.items.Length; i++)
        {
            int itemId = order.items[i];
            int count = order.count[i];
            int process = order.process[i];
            if (process < count)
            {
                int _price = configService.MergeItemConfig[itemId].price;
                price += _price * (count - process);
            }
        }
        return price;
    }

    public bool CommitMergeOrder(int npc_id)
    {
        var order = GetMergeOrder(npc_id, out var _);
        for (int i = 0; i < order.count.Length; i++)
        {
            int count = order.count[i];
            int process = order.process[i];
            if (process < count)
            {
                return false;
            }
        }

        List<int> removeGrids = new List<int>();
        foreach (var item in mergeItemData)
        {
            if (unlockGridData.ContainsKey(item.Key) && !removeGrids.Contains(item.Key))
            {
                for (int i = 0; i < order.items.Length; i++)
                {
                    int itemId = order.items[i];
                    int process = order.process[i];
                    if (process > 0 && item.Value == itemId)
                    {
                        order.process[i]--;
                        removeGrids.Add(item.Key);
                        break;
                    }
                }

                int totalProcess = 0;
                foreach (var pro in order.process)
                {
                    totalProcess += pro;
                }
                if (totalProcess == 0)
                    break;
            }
        }

        foreach (var gridId in removeGrids)
        {
            mergeItemData.Remove(gridId);
            TypeEventSystem.Send<RemoveMergeItemEvent>(new RemoveMergeItemEvent(gridId));
        }

        ReceiveMergeOrderRewards(npc_id);

        return true;
    }

    public bool BuyAndCommitMergeOrder(int npc_id)
    {
        int price = GetMergeOrderPrice(npc_id);
        if (Coin >= price)
        {
            var order = GetMergeOrder(npc_id, out var _);
            List<int> removeGrids = new List<int>();
            foreach (var item in mergeItemData)
            {
                for (int i = 0; i < order.items.Length; i++)
                {
                    int itemId = order.items[i];
                    int process = order.process[i];
                    if (process > 0 && item.Value == itemId)
                    {
                        order.process[i]--;
                        removeGrids.Add(item.Key);
                        break;
                    }
                }

                int totalProcess = 0;
                foreach (var pro in order.process)
                {
                    totalProcess += pro;
                }
                if (totalProcess == 0)
                    break;
            }

            foreach (var gridId in removeGrids)
            {
                mergeItemData.Remove(gridId);
                TypeEventSystem.Send<RemoveMergeItemEvent>(new RemoveMergeItemEvent(gridId));
            }
            ConsumeCoin(price, PropChangeWay.BuyMergeOrder);

            ReceiveMergeOrderRewards(npc_id);
            return true;
        }
        return false;
    }

    public bool ReceiveMergeOrderRewards(int npc_id)
    {

        var order = GetMergeOrder(npc_id, out var _);
        int order_id = order.id;
        var orderInfo = configService.MergeOrderListConfig[order_id];
        string rewards_str = orderInfo.rewards;
        string[] rewardGroups = rewards_str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        string[] rewards = rewardGroups[0].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);

        int npc_grid_id = -1;
        foreach (var item in mergeItemData)
        {
            if (item.Value == npc_id)
            {
                npc_grid_id = item.Key;
                break;
            }
        }

        List<int> bubbleItems = new List<int>();
        List<int> itemGrids = new List<int>();

        int coin = 0;
        int buildCoin = 0;
        int reward_item_id = -1;
        int reward_item_num = 0;
        for (int i = 0; i < rewardGroups.Length; i++)
        {
            rewards = rewardGroups[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
            reward_item_id = int.Parse(rewards[0]);
            reward_item_num = int.Parse(rewards[1]);
            if (configService.MergeItemConfig.ContainsKey(reward_item_id))
            {
                for (int j = 0; j < reward_item_num; j++)
                {
                    var grid_id = CreateMergeItem(npc_grid_id, reward_item_id);
                    if (grid_id == -1)
                    {
                        bubbleItems.Add(reward_item_id);
                    }
                    else
                    {
                        itemGrids.Add(grid_id);
                    }
                }
            }
            else
            {
                if (reward_item_id == (int)PropEnum.Coin)
                {
                    coin += reward_item_num;
                }
                else if (reward_item_id == (int)PropEnum.BuildCoin)
                {
                    buildCoin += reward_item_num;
                }
                AddProp(reward_item_id, reward_item_num, PropChangeWay.NpcOrder);
            }
        }

        if (bubbleItems.Count > 0)
        {
            int bubbleId = mergeBubbleData.Count;
            while (mergeBubbleData.ContainsKey(bubbleId))
            {
                bubbleId++;
            }
            MergeBubbleModel m = new MergeBubbleModel(bubbleId, bubbleItems);
            mergeBubbleData.TryAdd(bubbleId, m);
            var pos = MergeGameController.Instance.GetGridWorldPos(npc_grid_id);
            m.x = pos.x;
            m.y = pos.y;
            TypeEventSystem.Send<CreateMergeBubbleEvent>(new CreateMergeBubbleEvent(m));
        }

        var index = mergeOrderData.ContainsKey(npc_id) ? mergeOrderData[npc_id].index + 1 : 1;
        MergeOrderInfoModel newOrder = GenNewMergeOrder(npc_id, index);
        if (mergeOrderData.ContainsKey(npc_id))
            mergeOrderData[npc_id] = newOrder;
        else
            mergeOrderData.Add(npc_id, newOrder);
        TypeEventSystem.Send<GetOrderRewardsEvent>(
            new GetOrderRewardsEvent(npc_grid_id, itemGrids, coin, buildCoin));

        SaveData();

        return true;
    }

    public MergeRegionModel GetRegionInfo(int region_id)
    {
        MergeRegionModel info = null;
        if (mergeRegionData.ContainsKey(region_id))
            info = mergeRegionData[region_id];
        else if (region_id == 1)
        {
            info = new MergeRegionModel();
            info.id = region_id;
            info.level = 0;
            info.exp = 0;
            info.addExp = 0;
            info.rewardLv = new int[] { };
            mergeRegionData.Add(region_id, info);
        }
        else
        {
            var lastRegionId = region_id - 1;
            if (mergeRegionData.ContainsKey(lastRegionId))
            {

                var cfg = configService.MergeRegionRewardsConfig.Values.Where(f => f.id == lastRegionId).Last();
                if (cfg.level == mergeRegionData[lastRegionId].level)
                {
                    info = new MergeRegionModel();
                    info.id = region_id;
                    info.level = 0;
                    info.exp = 0;
                    info.addExp = 0;
                    info.rewardLv = new int[] { };
                    mergeRegionData.Add(region_id, info);
                }
            }
        }

        if (info != null && !mergeRegionUnlockBoxOrder.ContainsKey(region_id))
        {
            mergeRegionUnlockBoxOrder.Add(region_id, mergeLevelBoxIndex);
            SaveData(true);
        }

        return info;
    }

    public bool UseExpMergeItem(int gridId)
    {

        var item_id = GetGridItemId(gridId, out var _);
        if (item_id == -1)
            return false;
        var itemType = (Constants.MergeItemType)configService.MergeItemConfig[item_id].itemType;
        if (itemType == Constants.MergeItemType.Exp)
        {
            //TODO 检查使用所有经验棒是否可以升级满建筑，可以的话，一键使用

            mergeItemData.Remove(gridId);
            int exp = int.Parse(configService.MergeItemConfig[item_id].exparams);
            AddRegionExp(exp);
            TypeEventSystem.Send<RemoveMergeItemEvent>(new RemoveMergeItemEvent(gridId));
            TypeEventSystem.Send<FlyBuildExpEvent>(new FlyBuildExpEvent(gridId, item_id));
            SaveData();
            return true;
        }
        return false;
    }

    public bool RecycleMergeItem(int gridId)
    {

        var itemId = GetGridItemId(gridId, out var _);
        MergeItemConfig config = configService.MergeItemConfig[itemId];
        string[] sale = config.sale.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
        int price = int.Parse(sale[1]);
        mergeItemData.Remove(gridId);
        AddBuildCoin(price, PropChangeWay.Recycle);
        TypeEventSystem.Send<RemoveMergeItemEvent>(new RemoveMergeItemEvent(gridId));
        SaveData();
        return true;
    }

    private void AddRegionExp(int exp)
    {

        int addExp = exp;
        for (int i = 1; i <= Constants.RegionNum; i++)
        {
            var info = GetRegionInfo(i);
            var regionNextKey = i * 1000 + info.level + 1;
            if (configService.MergeRegionRewardsConfig.ContainsKey(regionNextKey))
            {
                info.addExp += addExp;
                break;
            }
            else
            {
                addExp += info.addExp;
            }
        }

        for (int i = 1; i <= Constants.RegionNum; i++)
        {
            RegionLevelUp(i);
        }
        SaveData();
    }

    public void RegionLevelUp(int region_id)
    {

        var info = GetRegionInfo(region_id);
        if (info == null)
            return;
        int nextId = info.id * 1000 + info.level + 1;
        List<int> items = new List<int>();
        List<int> clouds = new List<int>();
        List<int> builds = new List<int>();
        while (info.addExp > 0 && configService.MergeRegionRewardsConfig.ContainsKey(nextId))
        {
            var m = configService.MergeRegionRewardsConfig[nextId];
            int needExp = m.exp - info.exp;
            if (info.addExp >= needExp)
            {
                info.level++;
                info.exp = 0;
                info.addExp -= needExp;
                if (!string.IsNullOrEmpty(m.rewards))
                {
                    string rewards_str = m.rewards;
                    string[] rewards = rewards_str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                    rewards = rewards[0].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                    for (int i = 0; i < int.Parse(rewards[1]); i++)
                    {
                        items.Add(int.Parse(rewards[0]));
                    }
                    List<int> rewardLv = new List<int>(info.rewardLv);
                    rewardLv.Add(m.level);
                    info.rewardLv = rewardLv.ToArray();
                }
                if (m.cloud_id > 0)
                {
                    clouds.Add(m.cloud_id);
                }
                if (m.build_lv > 0)
                {
                    builds.Add(m.build_lv);
                }
                nextId = m.id * 1000 + m.level + 1;
            }
            else
            {
                info.exp += info.addExp;
                info.addExp = 0;
            }
        }

        if (clouds.Count > 0)
        {
            foreach (var cloud_id in clouds)
            {
                unlockCloudData.TryAdd(cloud_id, true);
                foreach (var item in configService.MergeMapConfig.Values)
                {
                    if (item.unlock_exp == 0)
                    {
                        unlockGridData.TryAdd(item.id, true);
                        UnlockMergeItem(item.id);
                    }
                    else if (item.cloud_id == cloud_id)
                    {
                        gridExpData.TryAdd(item.id, 0);
                    }
                }
            }
            foreach (var cloud_id in clouds)
            {
                TypeEventSystem.Send<UnlockCloudEvent>(new UnlockCloudEvent(cloud_id));
            }
        }

        if (builds.Count > 0)
        {
            foreach (var build_lv in builds)
            {
                TypeEventSystem.Send<UnlockBuildEvent>(new UnlockBuildEvent(region_id, build_lv));
            }
        }
    }



    public void GetRegionReward(int region_id, int level)
    {

        var info = GetRegionInfo(region_id);
        List<int> items = new List<int>();
        for (int i = 0; i < info.rewardLv.Length; i++)
        {
            int lv = info.rewardLv[i];
            if (lv == level)
            {
                var key = region_id * 1000 + level;
                var m = configService.MergeRegionRewardsConfig[key];
                if (!string.IsNullOrEmpty(m.rewards))
                {
                    string rewards_str = m.rewards;
                    string[] rewards = rewards_str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                    rewards = rewards[0].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                    for (int j = 0; j < int.Parse(rewards[1]); j++)
                    {
                        items.Add(int.Parse(rewards[0]));
                    }
                    List<int> rewardLv = new List<int>(info.rewardLv);
                    rewardLv.Remove(level);
                    info.rewardLv = rewardLv.ToArray();
                }
                break;
            }
        }
        if (items.Count > 0)
        {
            int bubbleId = mergeBubbleData.Count;
            while (mergeBubbleData.ContainsKey(bubbleId))
            {
                bubbleId++;
            }
            MergeBubbleModel m = new MergeBubbleModel(bubbleId, items);
            mergeBubbleData.TryAdd(bubbleId, m);
            TypeEventSystem.Send<CreateMergeBubbleEvent>(new CreateMergeBubbleEvent(m));
            // TypeEventSystem.Send<GetRegionRewardsEvent>(new GetRegionRewardsEvent(region_id, items));   
        }
        SaveData();
    }

    public bool IsUnlockCloud(int cloud_id)
    {
        return unlockCloudData.ContainsKey(cloud_id);
    }

    public bool IsUnlockGrid(int grid_id)
    {
        return unlockGridData.ContainsKey(grid_id);
    }

    public int GetGridExp(int grid_id)
    {
        if (gridExpData.ContainsKey(grid_id))
            return gridExpData[grid_id];
        return 0;
    }

    public int GetRegionId()
    {
        int region_id = 1;
        int region_level = 1;
        for (int i = 1; i <= Constants.RegionNum; i++)
        {
            var info = GetRegionInfo(i);
            if (info != null)
            {
                region_id = i;
                region_level = info.level;

                var cfg = configService.MergeRegionRewardsConfig.Values.Where(f => f.id == region_id).Last();
                if (cfg.level >= region_level)
                {
                    break;
                }
            }
        }
        return region_id;
    }

    public int GetRegionLevel()
    {
        int region_id = 1;
        int region_level = 1;
        for (int i = 1; i <= Constants.RegionNum; i++)
        {
            var info = GetRegionInfo(i);
            if (info != null)
            {
                region_id = i;
                region_level = info.level;

                var cfg = configService.MergeRegionRewardsConfig.Values.Where(f => f.id == region_id).Last();
                if (cfg.level >= region_level)
                {
                    break;
                }
            }
        }
        return region_level;
    }

    public void AddMergeLevelBox()
    {
        mergeLevelBoxIndex++;



        foreach (var item in configService.MergeLevelBoxConfig)
        {
            if (item.Value.order == mergeLevelBoxIndex)
            {
                mergeLevelBoxData.Add(item.Key);
                return;
            }
        }

        int region_id = 1;
        int region_level = 1;
        for (int i = 1; i <= Constants.RegionNum; i++)
        {
            var info = GetRegionInfo(i);
            if (info != null && info.level > 0)
            {
                region_id = i;
                region_level = info.level;
            }
            else
            {
                break;
            }
        }

        foreach (var item in configService.MergeLevelBoxConfig)
        {
            if (item.Value.region_id == region_id && item.Value.level == region_level)
            {
                mergeLevelBoxData.Add(item.Key);
                break;
            }
        }
        SaveData();
    }

    public int GetUnPutLevelBoxNumber()
    {
        int num1 = mergeLevelBoxData.Count;
        int num2 = 0;
        foreach (var item in mergeItemData)
        {
            if (item.Value == Constants.MergeLevelBoxItemId)
            {
                num2++;
            }
        }
        return num1 - num2;
    }

    public int GetUnPutLevelBoxIndex()
    {
        int num1 = 0;
        foreach (var item in mergeItemData)
        {
            if (item.Value == Constants.MergeLevelBoxItemId)
            {
                num1++;
            }
        }
        return num1;
    }

    public bool PutMergeLevelBox(Vector3 fromPos)
    {
        int num = GetUnPutLevelBoxNumber();
        if (num > 0)
        {
            int gridId = -1;
            int index = GetUnPutLevelBoxIndex();
            int boxId = mergeLevelBoxData[index];
            if (boxId < 0)
            {
                //新手宝箱位置特殊处理

                int order = configService.MergeLevelBoxConfig[boxId].order;
                if (order == 1)
                    gridId = 1994001;
                else if (order == 2)
                    gridId = 1996000;
                else if (order == 3)
                    gridId = 1997999;
            }
            if (gridId == -1)
                gridId = MergeGameController.Instance.GetNewItemGridId();
            gridId = CreateMergeItem(gridId, Constants.MergeLevelBoxItemId);
            if (gridId == -1)
                return false;
            else
            {
                TypeEventSystem.Send<PutLevelBoxEvent>(new PutLevelBoxEvent(gridId, fromPos));
                SaveData();
                return true;
            }
        }
        return false;
    }

    public bool OpenMergeLevelBox(int gridId)
    {
        if (mergeLevelBoxData.Count == 0)
            return false;

        mergeItemData.Remove(gridId);
        int emptyNumber = GetEmptyGridNumber();


        List<int> targetItemIds = new List<int>();

        int boxId = mergeLevelBoxData[0];

        if (boxId < 0)
        {
            string rewards_str = configService.MergeLevelBoxConfig[boxId].rewards;
            string[] rewards = rewards_str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            foreach (var item in rewards)
            {
                string[] param = item.Split(GameUtils.FirstSeparator);
                var itemId = int.Parse(param[0]);
                var itemNumber = int.Parse(param[1]);
                for (int i = 0; i < itemNumber; i++)
                {
                    targetItemIds.Add(itemId);
                }
            }
        }
        else
        {
            string item_weight = configService.MergeLevelBoxConfig[boxId].rewards;
            string[] itemWeight = item_weight.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            List<int> itemIds = new List<int>();
            List<int> itemWeights = new List<int>();
            foreach (var info in itemWeight)
            {
                string[] param = info.Split(GameUtils.FirstSeparator);
                itemIds.Add(int.Parse(param[0]));
                itemWeights.Add(int.Parse(param[1]));
            }
            int number = configService.MergeLevelBoxConfig[boxId].number;

            for (int i = 0; i < number; i++)
            {
                float cumulativeWeight = 0;
                float totalWeight = itemWeights.Sum();
                float randomValue = GameUtils.RandomRange(0f, totalWeight);
                int itemId = itemIds[0];
                for (int j = 0; j < itemWeights.Count; j++)
                {
                    cumulativeWeight += itemWeights[j];
                    if (randomValue < cumulativeWeight)
                    {
                        itemId = itemIds[j];
                        break;
                    }
                }
                targetItemIds.Add(itemId);
            }
        }

        //道具npc产出处理
        foreach (var cfg in configService.MergeItemNpcConfig)
        {
            int npc_id = cfg.Value.npc_id;
            if (GetMapMergeItemNumber(npc_id) > 0 || GetBubbleMergeItemNumber(npc_id) > 0)
            {
                continue;
            }
            if (mergeRegionUnlockBoxOrder.TryGetValue(cfg.Value.region_id, out var idx))
            {
                int order = mergeLevelBoxIndex - mergeLevelBoxData.Count + 1 - idx;
                if (order == cfg.Value.order)
                {
                    string[] reward_groups = cfg.Value.rewards.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var reward_str in reward_groups)
                    {
                        string[] param = reward_str.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                        int reward_item_id = int.Parse(param[0]);
                        int reward_item_number = int.Parse(param[1]);
                        for (int i = 0; i < reward_item_number; i++)
                        {
                            targetItemIds.Add(reward_item_id);
                        }
                    }
                }
            }
        }

        //新手特殊处理
        bool rookie_flag = false;
        int box_order = 0;
        if (boxId < 0)
        {
            box_order = configService.MergeLevelBoxConfig[boxId].order;
            if (box_order == 1 || box_order == 2 || box_order == 3)
                rookie_flag = true;
        }

        List<int> newItems = new List<int>();
        if (rookie_flag)
        {
            if (box_order == 1)
            {
                CreateMergeItem(1994019, targetItemIds[0]);
                CreateMergeItem(1994013, targetItemIds[1]);
                CreateMergeItem(1994001, targetItemIds[2]);
                newItems.Add(1994019);
                newItems.Add(1994013);
                newItems.Add(1994001);
            }
            else if (box_order == 2)
            {
                CreateMergeItem(1996018, targetItemIds[0]);
                CreateMergeItem(1996012, targetItemIds[1]);
                CreateMergeItem(1996000, targetItemIds[2]);
                newItems.Add(1996018);
                newItems.Add(1996012);
                newItems.Add(1996000);
            }
            else if (box_order == 3)
            {
                CreateMergeItem(1998017, targetItemIds[0]);
                CreateMergeItem(1998011, targetItemIds[1]);
                CreateMergeItem(1997999, targetItemIds[2]);
                newItems.Add(1998017);
                newItems.Add(1998011);
                newItems.Add(1997999);
            }
        }
        else
        {
            int nearGridId = GetNearEmptyGrid(gridId);
            List<int> items = targetItemIds;
            for (int i = 0; i < emptyNumber; i++)
            {
                if (items.Count > 0)
                {
                    int new_grid_id = CreateMergeItem(nearGridId, items[0]);
                    if (new_grid_id != -1)
                    {
                        newItems.Add(new_grid_id);
                        items.RemoveAt(0);
                    }
                }
            }
            if (items.Count > 0)
            {
                int bubbleId = mergeBubbleData.Count;
                while (mergeBubbleData.ContainsKey(bubbleId))
                {
                    bubbleId++;
                }
                MergeBubbleModel m = new MergeBubbleModel(bubbleId, items);
                mergeBubbleData.TryAdd(bubbleId, m);
                var pos = MergeGameController.Instance.GetGridWorldPos(gridId);
                m.x = pos.x;
                m.y = pos.y;
                TypeEventSystem.Send<CreateMergeBubbleEvent>(new CreateMergeBubbleEvent(m));
            }
        }

        mergeLevelBoxData.RemoveAt(0);
        TypeEventSystem.Send<OpenMergeBoxEvent>(new OpenMergeBoxEvent(gridId, newItems));

        SaveData();
        return true;
    }

    public bool OpenMergeMapBox(int gridId)
    {
        if (!IsUnlockGrid(gridId))
            return false;

        int emptyNumber = GetEmptyGridNumber();
        if (emptyNumber == 0)
            return false;

        int boxId = mergeItemData[gridId];


        string exparams = configService.MergeItemConfig[boxId].exparams;
        string[] exparams2 = exparams.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        List<int> targetItemIds = new List<int>();
        foreach (var rewards in exparams2)
        {
            string[] param = rewards.Split(GameUtils.FirstSeparator);
            int num = int.Parse(param[1]);
            for (int i = 0; i < num; i++)
            {
                targetItemIds.Add(int.Parse(param[0]));
            }
        }

        int nearGridId = GetNearEmptyGrid(gridId);
        List<int> newItems = new List<int>();
        List<int> items = targetItemIds;
        for (int i = 0; i < emptyNumber; i++)
        {
            if (items.Count > 0)
            {
                int new_grid_id = CreateMergeItem(nearGridId, items[0]);
                if (new_grid_id != -1)
                {
                    newItems.Add(new_grid_id);
                    items.RemoveAt(0);
                }
            }
        }

        mergeItemData.Remove(gridId);
        if (items.Count > 0)
        {
            int bubbleId = mergeBubbleData.Count;
            while (mergeBubbleData.ContainsKey(bubbleId))
            {
                bubbleId++;
            }
            MergeBubbleModel m = new MergeBubbleModel(bubbleId, items);
            mergeBubbleData.TryAdd(bubbleId, m);
            var pos = MergeGameController.Instance.GetGridWorldPos(gridId);
            m.x = pos.x;
            m.y = pos.y;
            TypeEventSystem.Send<CreateMergeBubbleEvent>(new CreateMergeBubbleEvent(m));
        }

        TypeEventSystem.Send<OpenMergeBoxEvent>(new OpenMergeBoxEvent(gridId, newItems));

        SaveData();
        return true;
    }


    public List<int> GetUnlockNpcIds()
    {

        var npcIds = configService.MergeItemConfig.Values
            .Where(cfg => cfg.itemType == (int)Constants.MergeItemType.Npc)
            .Select(cfg => cfg.id)
            .ToList();

        var npcList = new List<int>();
        foreach (var npc_id in npcIds)
        {
            foreach (var item in mergeItemData)
            {
                if (unlockGridData.ContainsKey(item.Key) && item.Value == npc_id)
                {
                    npcList.Add(npc_id);
                }
            }
        }

        return npcList;
    }

    public void ReceiveMergeShopItems()
    {
        if (mergeShopData == null)
            return;
        if (mergeShopData.storage != null)
        {
            Dictionary<int, long> props = new Dictionary<int, long>();
            foreach (var itemId in mergeShopData.storage)
            {
                if (props.ContainsKey(itemId))
                {
                    props[itemId]++;
                }
                else
                {
                    props.Add(itemId, 1);
                }
            }
            mergeShopData.storage = null;
            if (props.Count > 0)
            {
                AddProps(props, PropChangeWay.Shop);
            }
        }
    }

    public MergeShopInfoModel GetMergeShopData()
    {
        int now = TimeUtils.UtcNow();
        if (mergeShopData == null || !TimeUtils.IsSameDay(mergeShopData.date, now))
        {
            if (mergeShopData != null)
            {
                ReceiveMergeShopItems();
            }

            mergeShopData = new MergeShopInfoModel();
            mergeShopData.date = now;
            var regionId = GetRegionId();
            var regionLevel = GetRegionLevel();
            var key = regionId * 1000 + regionLevel;
            if (configService.MergeShopConfig.ContainsKey(key))
            {
                var shopCfg = configService.MergeShopConfig[key];
                var shopInfo = shopCfg.CreateShopInfo();
                List<int> items = new List<int>();
                List<int> limits = new List<int>();
                List<float> offs = new List<float>();
                List<string> products = new List<string>();

                foreach (var item in configService.ShopConfig)
                {
                    if (item.Value.product_type == 1)
                    {
                        string[] rewards = item.Value.reward.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                        string[] param = rewards[0].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                        items.Add(int.Parse(param[0]));
                        limits.Add(int.Parse(param[1]));
                        products.Add(item.Key);
                        offs.Add(1);
                    }
                }

                foreach (var item in shopInfo)
                {
                    items.Add(item.Item1);
                    limits.Add(item.Item2);
                    products.Add("");
                    offs.Add(item.Item3);
                }
                mergeShopData.items = items.ToArray();
                mergeShopData.limits = limits.ToArray();
                mergeShopData.products = products.ToArray();
                mergeShopData.offs = offs.ToArray();
                List<int> boughts = new List<int>();
                for (int i = 0; i < limits.Count; i++)
                {
                    boughts.Add(0);
                }
                mergeShopData.boughts = boughts.ToArray();
            }
            else
            {
                mergeShopData = null;
            }
            SaveData(true);
        }
        return mergeShopData;
    }

    public void BuyRmbMergeShopItem(int index)
    {
        List<int> storate = new List<int>();
        if (mergeShopData.storage != null)
            storate.AddRange(mergeShopData.storage);
        storate.Add(mergeShopData.items[index]);
        mergeShopData.storage = storate.ToArray();
        mergeShopData.boughts[index]++;
    }

    public int BuyMergeShopItem(int date, int index)
    {

        MergeShopInfoModel info = GetMergeShopData();

        if (!TimeUtils.IsSameDay(mergeShopData.date, date))
        {
            return 2;
        }

        int itemId = info.items[index];
        int price = (int)(configService.MergeItemConfig[itemId].price * info.offs[index]);
        if (BuildCoin < price)
            return 1;

        ConsumeBuildCoin(price, PropChangeWay.Shop);
        List<int> storate = new List<int>();
        if (mergeShopData.storage != null)
            storate.AddRange(mergeShopData.storage);
        storate.Add(mergeShopData.items[index]);
        mergeShopData.storage = storate.ToArray();
        mergeShopData.boughts[index]++;

        return 0;
    }

    public void CheckHotAirBall()
    {
        var now = TimeUtils.UtcNow();
        List<int> removes = new List<int>();
        foreach (var item in mergeHotAirBallData)
        {
            if (configService.MergeHotAirBallConfig.TryGetValue(item.Key, out var cfg))
            {
                if (now >= item.Value.time + cfg.time)
                {
                    removes.Add(item.Key);
                }
            }
        }

        foreach (var key in removes)
        {
            mergeHotAirBallData.Remove(key);
            TypeEventSystem.Send<CheckHotAirBallEvent>(new CheckHotAirBallEvent(key));
        }
    }

    public bool BuyHotAirBall(int ballId, int cfgId)
    {
        // if (mergeHotAirBallData.TryGetValue(ballId, out var data))
        // {
        //     
        //     if (configService.MergeHotAirBallConfig.TryGetValue(cfgId, out var cfg))
        //     {
        //         var now = TimeUtils.UtcNow();
        //         if (now > data.time + cfg.time)
        //         {
        //             return false;
        //         }
        //         if (cfg.purchase_type == 1)
        //             ConsumeBuildCoin(cfg.price, PropChangeWay.HotAirBall);
        //         else if (cfg.purchase_type == 2)
        //             ConsumeCoin(cfg.price, PropChangeWay.HotAirBall);
        //     }
        // }
        // else
        // {

        // }

        if (configService.MergeHotAirBallConfig.TryGetValue(cfgId, out var cfg))
        {
            if (cfg.purchase_type == 1)
                ConsumeBuildCoin(cfg.price, PropChangeWay.HotAirBall);
            else if (cfg.purchase_type == 2)
                ConsumeCoin(cfg.price, PropChangeWay.HotAirBall);

            string[] param = cfg.reward.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
            int reward_item_id = int.Parse(param[0]);
            int reward_item_count = int.Parse(param[1]);
            Dictionary<int, long> props = new Dictionary<int, long>();
            props.Add(reward_item_id, reward_item_count);
            AddProps(props, PropChangeWay.HotAirBall);
            if (mergeHotAirBallData.ContainsKey(ballId))
            {
                mergeHotAirBallData.Remove(ballId);
                TypeEventSystem.Send<CheckHotAirBallEvent>(new CheckHotAirBallEvent(ballId));
            }

            return true;
        }

        return false;
    }

    public void SetRookieStatus(int level)
    {
        if (level < rookieStatus)
            return;
        rookieStatus = level;
        SaveData();
    }

    public int GetRookieStatus()
    {
        return rookieStatus;
    }

    public bool IsRookieStatus()
    {
        return rookieStatus <= 3;
    }

    public bool IsOverRookie()
    {
        return rookieStatus > 3;
    }

    public bool IsUnlockNpc(int npc_id)
    {
        if (_unlock_npcs.Contains(npc_id))
            return true;
        int num = GetMapMergeItemNumber(npc_id);
        return num > 0;
    }

    public bool IsHasFirstNpc()
    {
        return IsUnlockNpc(30003);
    }

    public string GetOldDataVersionRewards()
    {
        Dictionary<int, string> cfg = new Dictionary<int, string>();
        cfg.Add(0, "1,1000;28,1800;12,600;14,600;21,600;4,1;2,1;6,1000");
        cfg.Add(10, "1,2000;28,1800;12,1200;14,1200;21,1200;4,1;3,1;2,1;6,2000");
        cfg.Add(50, "1,3000;28,1800;12,1800;14,1800;21,1800;4,1;3,1;2,2;6,8000");
        cfg.Add(100, "1,4000;28,3600;12,2400;14,2400;21,2400;4,1;3,1;2,3;6,15000");
        cfg.Add(200, "1,5000;28,3600;12,3000;14,3000;21,3000;4,1;3,1;2,4;6,20000");
        cfg.Add(500, "1,6000;28,3600;12,3600;14,3600;21,3600;4,2;3,2;2,5;6,30000");
        cfg.Add(1000, "1,7000;28,5400;12,4200;14,4200;21,4200;4,3;3,3;2,6;6,40000");
        cfg.Add(2000, "1,8000;28,5400;12,4800;14,4800;21,4800;4,4;3,4;2,7;6,50000");
        cfg.Add(3000, "1,10000;28,5400;12,5400;14,5400;21,5400;4,5;3,5;2,8;6,60000");

        var amounts = cfg.Keys.ToList();
        amounts.Sort();
        string rewards = cfg[0];
        foreach (var money in amounts)
        {
            if (AllChargeMoney >= money)
                rewards = cfg[money];
            else
                break;
        }
        return rewards;
    }

    ~DataService()
    {
        TypeEventSystem.UnRegister<GlobalTimerRefreshEvent>(OnGlobalTimerRefreshEvent);
    }
}