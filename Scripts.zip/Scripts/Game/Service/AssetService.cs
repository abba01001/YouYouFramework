using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Activities;
using Doozy.Engine;
using QFramework;
using UniRx;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using SoliUtils;


public interface IAssetService
{
    void LoadRemoteAssetConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadCollectFlowerConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadRobotConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadValueConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadLocalStageConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadEndlessLevelRewardConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadWheelRewardConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadEndlessStageOneConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadEndlessStageTwoConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadCardRemainConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadComboRewardConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadSignInConfig();
    // Task<AsyncOperationHandle<TextAsset>> LoadWheelConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadShopConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadRookieConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadRookieClickConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadRookieDialogueConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadRookieDragConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadRookieAnimConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadBetConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadItemConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadPowerItemConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadLocalAssetConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadActivitiesConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadSeasonRewardConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadActivitiesSwitchConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadCollectLoveCardConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadCollectMusicConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadDigTreasureRewardConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadLevelPassConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadLavaPassConfig();
    // Task<AsyncOperationHandle<TextAsset>> LoadFarmingConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadCookMealConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMysteriousSeedConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadUnlockConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMagicNectarConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadRainbowDropsConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadPopupPriorityConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadAdRewardConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadPassRankRobotConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadCarRankRobotConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadGradientConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadGiftGradientCookConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadGiftGradientDigConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadPassRankRewardConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadCarRankRewardConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadLimitPkConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadPushGiftConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadSoundConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadCardDescConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadSeasonPassConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadNewUserSeasonPassConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadSeasonExpConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadTimingMessageConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadHandleEndlessLevelConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadHandleLevelConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadHandleResultConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadHandleLabelConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadHandleConsumConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadHandlePaidConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeItemConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeMapConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeRegionRewardsConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeOrderDegreeConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeOrderListConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeBuildConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeLevelBoxConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeShopConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeHotAirBallConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeItemNpcConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadMergeIllustratedConfig();
    Task<AsyncOperationHandle<TextAsset>> LoadEnergyConfig();

    void CheckAssetConfigLastUpdate();

    bool IsLocalLevelJson(string assetId);
    bool IsLatestLevelJson(string assetId, bool doUpdate = true);

    AssetItemVersionModel GetAssetVersionInfo(string assetId);
}

public class AssetService : IAssetService
{
    private Dictionary<string, AssetItemVersionModel> _assetItemVersionInfo =
        new Dictionary<string, AssetItemVersionModel>();
    private List<AssetItemVersionModel> _updatingAssets = new List<AssetItemVersionModel>();
    private Dictionary<AssetItemVersionModel, byte[]> _updatedAssets = new Dictionary<AssetItemVersionModel, byte[]>();


    public void LoadRemoteAssetConfig()
    {
        Debug.Log("LoadRemoteAssetConfig");
        var storageService = MainContainer.Container.Resolve<IStorageService>();

        _updatingAssets.Clear();
        if (storageService.KeyExists(Constants.StorageKey.RemoteAssetConfig))
        {
            var json = storageService.Load<string>(Constants.StorageKey.RemoteAssetConfig, null);
            if (!string.IsNullOrEmpty(json))
            {
                var assetConfigModel = JsonUtility.FromJson<AssetConfigModel>(json);
                if (assetConfigModel != null)
                {
                    storageService.Save<long>(Constants.StorageKey.AssetVersion, assetConfigModel.vers);
                    foreach (var itemModel in assetConfigModel.items)
                    {
                        if (string.IsNullOrEmpty(itemModel.path)) continue;
                        if (_assetItemVersionInfo.TryGetValue(itemModel.path, out var verModel))
                        {
                            verModel.remote_version = itemModel.version;
                            _assetItemVersionInfo[itemModel.path] = verModel;
                        }
                        else
                        {
                            verModel = new AssetItemVersionModel()
                            {
                                item = itemModel,
                                remote_version = itemModel.version
                            };
                            _assetItemVersionInfo.Add(itemModel.path, verModel);
                        }

                        if (isNeedUpdateAsset(verModel))
                        {
                            _updatedAssets.Remove(verModel);
                            _updatingAssets.Add(verModel);
                        }
                    }
                }
            }
            else
            {
                LoadDefaultRemoteAssetConfig();
            }
        }
        else
        {
            LoadDefaultRemoteAssetConfig();
        }
    }


    private void LoadDefaultRemoteAssetConfig()
    {
        Debug.Log("LoadDefaultRemoteAssetConfig");
        var storageService = MainContainer.Container.Resolve<IStorageService>();
        AssetConfigModel assetConfigModel =
            (AssetConfigModel)storageService.LoadJsonResource(
                $"Assets/Res/Configs/{Constants.DefaultAssetVersionConfigFile}",
                typeof(AssetConfigModel));
        if (assetConfigModel != null)
        {
            foreach (var itemModel in assetConfigModel.items)
            {
                if (string.IsNullOrWhiteSpace(itemModel.path)) continue;
                if (_assetItemVersionInfo.TryGetValue(itemModel.path, out var verModel))
                {
                    verModel.remote_version = itemModel.version;
                    _assetItemVersionInfo[itemModel.path] = verModel;
                }
                else
                {
                    verModel = new AssetItemVersionModel()
                    {
                        item = itemModel,
                        remote_version = itemModel.version
                    };
                    _assetItemVersionInfo.Add(itemModel.path, verModel);
                }
            }
        }
    }


    public void CheckAssetConfigLastUpdate()
    {
        Debug.Log("CheckAssetConfigLastUpdate start");
        var networkService = MainContainer.Container.Resolve<INetworkService>();
        var storageService = MainContainer.Container.Resolve<IStorageService>();

        //        BoxBuilder.SetLoadingPopShow(true, 7f, true, () => GameEventMessage.SendEvent(Constants.DoozyEvent.ConfigInitFinish), true);

        networkService.Get(Constants.CnfAssetUrl + Constants.AssetLastUpdateFile,
            delegate (byte[] response, int code, bool success, string url)
            {
                if (success && code == Constants.HttpResponseOk)
                {
                    var json = System.Text.Encoding.UTF8.GetString(response);
                    var assetLastUpdateModel = JsonUtility.FromJson<AssetLastUpdateModel>(json);
                    var remoteVersion = assetLastUpdateModel.asset_last_update;
                    var localVersion = (long)storageService.Load<object>(Constants.StorageKey.PatchAssetVersion, 0L);
                    Debug.Log($" version localVersion={localVersion} remoteVersion={remoteVersion} ");
                    if (remoteVersion > localVersion)
                    {
                        LoadRemoteAssetConfigFormService(remoteVersion);
                    }
                    else
                    {
                        UpdateAsset();
                    }
                }
                else
                {
                    UpdateAsset();
                }
            });
    }

    private void LoadRemoteAssetConfigFormService(long remoteVersion)
    {
        Debug.Log($"LoadRemoteAssetConfigFormService remoteVersion = {remoteVersion}");
        var networkService = MainContainer.Container.Resolve<INetworkService>();
        var storageService = MainContainer.Container.Resolve<IStorageService>();

        networkService.Get(Constants.CnfAssetUrl + Constants.AssetVersionConfigFile,
            delegate (byte[] response, int code, bool success, string url)
            {
                if (success && code == Constants.HttpResponseOk)
                {
                    var json = System.Text.Encoding.UTF8.GetString(response);
                    storageService.SaveWithoutCache<string>(Constants.StorageKey.RemoteAssetConfig, json);
                    storageService.SaveWithoutCache<long>(Constants.StorageKey.PatchAssetVersion, remoteVersion);
                    Debug.Log($"LoadRemoteAssetConfigFormService update PatchAssetVersion = {remoteVersion}");

                    LoadRemoteAssetConfig();
                    UpdateAsset();
                }
                else
                {
                    BoxBuilder.SetLoadingPopShow(false);
                    TypeEventSystem.Send<ConfigUpdateFinishEvent>();
                    // GameEventMessage.SendEvent(Constants.DoozyEvent.ConfigInitFinish);
                }
            });
    }

    private bool isNeedUpdateAsset(AssetItemVersionModel verModel)
    {
        long localVersion = verModel.local_version;
        long patchVersion = verModel.patch_version;
        long remoteVersion = verModel.remote_version;
        long curVersion = Math.Max(localVersion, patchVersion);
        return verModel.item.path.Contains(Constants.AssetTypeExcel) && remoteVersion > curVersion;
    }


    public async Task<AsyncOperationHandle<TextAsset>> LoadLocalAssetConfig()
    {
        var handle = Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.AssetVersionConfigFile}");
        await handle.Task;

        if (handle.IsDone)
        {
            var storageService = MainContainer.Container.Resolve<IStorageService>();
            if (JsonUtility.FromJson(handle.Result.text, typeof(AssetConfigModel)) is AssetConfigModel assetConfigModel)
            {
                var assetVersion =
                    (long)storageService.Load<object>(Constants.StorageKey.AssetVersion, assetConfigModel.vers);
                storageService.Save<long>(Constants.StorageKey.AssetVersion, assetVersion);
                foreach (var itemModel in assetConfigModel.items)
                {
                    if (itemModel.path.Equals("") || _assetItemVersionInfo.ContainsKey(itemModel.path)) continue;
                    var verModel = new AssetItemVersionModel()
                    {
                        item = itemModel,
                        local_version = itemModel.version
                    };
                    _assetItemVersionInfo.Add(itemModel.path, verModel);
                }

                var patchAssetJson = (string)storageService.Load<object>(Constants.StorageKey.PatchAssetConfig, "");
                if (!string.IsNullOrEmpty(patchAssetJson))
                {
                    var patchAssetConfigModel = JsonUtils.ArrayFromJson<AssetItemModel>(patchAssetJson).ToList();
                    foreach (var itemModel in patchAssetConfigModel)
                    {
                        if (string.IsNullOrWhiteSpace(itemModel.path)) continue;
                        if (_assetItemVersionInfo.TryGetValue(itemModel.path, out var verModel))
                        {
                            verModel.patch_version = itemModel.version;
                            _assetItemVersionInfo[itemModel.path] = verModel;
                        }
                        else
                        {
                            verModel = new AssetItemVersionModel()
                            {
                                item = itemModel,
                                patch_version = itemModel.version
                            };
                            _assetItemVersionInfo.Add(itemModel.path, verModel);
                        }
                    }
                }
            }
            Debug.Log("========= LoadLocalAssetConfig Done");
        }

        return handle;
    }

    private void HandleAssetUpdateResponse(AssetItemVersionModel verModel, byte[] data)
    {
        _updatedAssets.Remove(verModel);
        _updatedAssets.Add(verModel, data);
        bool isAllUpdated = true;
        foreach (var updatingAssetEntity in _updatingAssets)
        {
            if (!_updatedAssets.ContainsKey(updatingAssetEntity))
            {
                isAllUpdated = false;
                break;
            }
        }

        if (isAllUpdated)
        {
            var storageService = MainContainer.Container.Resolve<IStorageService>();
            var configService = MainContainer.Container.Resolve<IConfigService>();
            foreach (var kv in _updatedAssets)
            {
                var valueStr = System.Text.Encoding.UTF8.GetString(kv.Value);
                switch (Path.GetFileNameWithoutExtension(kv.Key.item.path))
                {
                    case Constants.StorageKey.StageConfig:
                        configService.StageConfig = JsonUtils.ArrayFromJson<StageModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.EndlessStageOneConfig:
                        configService.EndlessStageOneConfig = JsonUtils.ArrayFromJson<StageModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.EndlessStageTwoConfig:
                        configService.EndlessStageTwoConfig = JsonUtils.ArrayFromJson<StageModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.ValueConfig:
                        configService.ValueConfig = JsonUtils.ArrayFromJson<ValueConfigModel>(valueStr)
                            .ToDictionary(model => model.id, model => model.value);
                        break;
                    case Constants.StorageKey.CollectFlowerConfig:
                        configService.CollectFlowerConfig = JsonUtils.ArrayFromJson<CollectFlowerConfigModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.RobotConfig:
                        var robotBaseArray = JsonUtils.ArrayFromJson<RobotConfigModel>(valueStr);
                        List<RobotConfigModel> robotConfig = new List<RobotConfigModel>(robotBaseArray.Length);
                        foreach (var item in robotBaseArray)
                            robotConfig.Add(new RobotConfigModel(item));
                        configService.RobotConfig = robotConfig;
                        configService.RobotConfig.Sort((a, b) => int.Parse(a.id).CompareTo(int.Parse(b.id)));
                        break;
                    // case Constants.StorageKey.HandleConfig:
                    //     configService.HandleConfig = JsonUtils.ArrayFromJson<HandleModel>(valueStr)
                    //         .ToDictionary(model => model.level, model => model);
                    //     break;
                    case Constants.StorageKey.SignInConfig:
                        configService.SignInConfig = JsonUtils.ArrayFromJson<SignInModel>(valueStr)
                            .ToDictionary(model => model.grid, model => model);
                        break;
                    // case Constants.StorageKey.WheelConfig:
                    //     configService.WheelConfig = JsonUtils.ArrayFromJson<WheelModel>(valueStr)
                    //         .ToDictionary(model => model.id, model => model);
                    //     break;
                    case Constants.StorageKey.ShopConfig:
                        configService.ShopConfig = JsonUtils.ArrayFromJson<ShopModel>(valueStr)
                            .ToDictionary(model => model.product_id, model => model);
                        break;
                    case Constants.StorageKey.CardRemainConfig:
                        configService.CardRemainConfig = JsonUtils.ArrayFromJson<CardRemainModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.ComboRewardConfig:
                        configService.ComboRewardConfig = JsonUtils.ArrayFromJson<ComboRewardModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.RookieConfig:
                        configService.RookieConfig = JsonUtils.ArrayFromJson<RookieBaseModel>(valueStr)
                            .ToDictionary(model => model.id, model => new RookieModel(model));
                        break;
                    case Constants.StorageKey.RookieClickConfig:
                        configService.RookieClickConfig = JsonUtils.ArrayFromJson<RookieClickBaseModel>(valueStr)
                            .ToDictionary(model => model.id, model => new RookieClickModel(model));
                        break;
                    case Constants.StorageKey.RookieDialogueConfig:
                        configService.RookieDialogueConfig = JsonUtils.ArrayFromJson<RookieDialogueModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.RookieDragConfig:
                        configService.RookieDragConfig = JsonUtils.ArrayFromJson<RookieDragModelBase>(valueStr)
                            .ToDictionary(model => model.id, model => new RookieDragModel(model));
                        break;
                    case Constants.StorageKey.RookieAnimConfig:
                        configService.RookieAnimConfig = JsonUtils.ArrayFromJson<RookieAnimModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                        
                    case Constants.StorageKey.ActivitiesConfig:
                        configService.ActivitiesConfig = JsonUtils.ArrayFromJson<ActivityModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        ActivityManager.Instance.RefreshConfig();
                        break;
                    case Constants.StorageKey.ActivitiesSwitchConfig:
                        configService.ActivitiesSwitchConfig = JsonUtils.ArrayFromJson<ActivitiesSwitchModel>(valueStr)
                            .ToDictionary(model => model.id, model => model.Parse());
                        ActivityManager.Instance.RefreshConfig();
                        break;
                    case Constants.StorageKey.CollectLoveCardConfig:
                        configService.CollectLoveCardConfig = JsonUtils.ArrayFromJson<CollectLoveCardModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.CollectMusicConfig:
                        configService.CollectMusicConfig = JsonUtils.ArrayFromJson<CollectMusicModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.DigTreasureRewardConfig:
                        configService.DigTreasureRewardConfig = JsonUtils.ArrayFromJson<DigTreasureRewardModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.LevelPassConfig:
                        configService.LevelPassConfig = JsonUtils.ArrayFromJson<LevelPassModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.LavaPassConfig:
                        configService.LavaPassConfig = JsonUtils.ArrayFromJson<LavaPassModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    // case Constants.StorageKey.FarmingConfig:
                    //     configService.FarmingConfig = JsonUtils.ArrayFromJson<FarmingModel>(valueStr)
                    //         .ToDictionary(model => model.id, model => model);
                    //     break;
                    case Constants.StorageKey.UnlockConfig:
                        configService.UnlockConfig = JsonUtils.ArrayFromJson<UnlockModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.CookMealConfig:
                        configService.CookMealConfig = JsonUtils.ArrayFromJson<CookMealModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.MysteriousSeedConfig:
                        configService.MysteriousSeedConfig = JsonUtils.ArrayFromJson<MysteriousSeedModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.MagicNectarConfig:
                        configService.MagicNectarConfig = JsonUtils.ArrayFromJson<MagicNectarModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.RainbowDropsConfig:
                        configService.RainbowDropsConfig = JsonUtils.ArrayFromJson<RainbowDropsModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.PopupPriorityConfig:
                        configService.PopupPriorityConfig = JsonUtils.ArrayFromJson<PopupPriorityModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.AdRewardConfig:
                        configService.AdRewardConfig = JsonUtils.ArrayFromJson<AdRewardModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;

                    case Constants.StorageKey.PassRankRobotConfig:
                        configService.PassRankRobotConfig = JsonUtils.ArrayFromJson<PassRankRobotModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.CarRankRobotConfig:
                        configService.CarRankRobotConfig = JsonUtils.ArrayFromJson<CarRankRobotModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.GradientConfig:
                        configService.GradientConfig = JsonUtils.ArrayFromJson<GradientModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.GiftGradientCookConfig:
                        configService.GiftGradientCookConfig = JsonUtils.ArrayFromJson<GradientModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.GiftGradientDigConfig:
                        configService.GiftGradientDigConfig = JsonUtils.ArrayFromJson<GradientModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.PassRankRewardConfig:
                        configService.PassRankRewardConfig = JsonUtils.ArrayFromJson<PassRankRewardModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.CarRankRewardConfig:
                        configService.CarRankRewardConfig = JsonUtils.ArrayFromJson<CarRankRewardModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.LimitPkConfig:
                        configService.LimitPkConfig = JsonUtils.ArrayFromJson<LimitPkModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.PushGiftConfig:
                        configService.PushGiftConfig = JsonUtils.ArrayFromJson<PushGiftModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.SoundConfig:
                        configService.SoundConfig = JsonUtils.ArrayFromJson<SoundModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.CardDescConfig:
                        configService.CardDescConfig = JsonUtils.ArrayFromJson<CardDescModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.SeasonPassConfig:
                        configService.SeasonPassConfig = JsonUtils.ArrayFromJson<SeasonPassModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.NewUserSeasonPassConfig:
                        configService.NewUserSeasonPassConfig = JsonUtils.ArrayFromJson<SeasonPassModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.SeasonRewardConfig:
                        configService.SeasonRewardConfig = JsonUtils.ArrayFromJson<SeasonRewardModel>(valueStr)
                            .ToDictionary(model => model.id, model => model.Parse());
                        ActivityManager.Instance.RefreshConfig();
                        break;
                    case Constants.StorageKey.SeasonExpConfig:
                        configService.SeasonExpConfig = JsonUtils.ArrayFromJson<SeasonExpModel>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.MergeIllustratedConfig:
                        configService.MergeIllustratedConfig = JsonUtils.ArrayFromJson<MergeIllustratedConfig>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;
                    case Constants.StorageKey.EnergyConfig:
                        configService.EnergyConfig = JsonUtils.ArrayFromJson<EnergyConfig>(valueStr)
                            .ToDictionary(model => model.id, model => model);
                        break;

                }

                storageService.SaveWithoutCache(kv.Key.item.path, valueStr);
                _assetItemVersionInfo[kv.Key.item.path].patch_version = kv.Key.remote_version;
            }

            SaveAsset();
            BoxBuilder.SetLoadingPopShow(false);
            TypeEventSystem.Send<ConfigUpdateFinishEvent>();
            // GameEventMessage.SendEvent(Constants.DoozyEvent.ConfigInitFinish);
        }
    }

    private void SaveAsset()
    {
        var storageService = MainContainer.Container.Resolve<IStorageService>();
        var patchAssetData = new List<string>();
        foreach (var assetKv in _assetItemVersionInfo)
        {
            if (assetKv.Value.patch_version != -1)
            {
                var item = new AssetItemModel
                {
                    path = assetKv.Value.item.path,
                    version = assetKv.Value.patch_version
                };
                patchAssetData.Add(JsonUtility.ToJson(item));
            }
        }

        var patchAssetJson = string.Join(",", patchAssetData);
        storageService.SaveWithoutCache(Constants.StorageKey.PatchAssetConfig, $"[{patchAssetJson}]");
    }

    private void UpdateAsset()
    {
        var networkService = MainContainer.Container.Resolve<INetworkService>();
        foreach (var verModel in _updatingAssets)
        {
            Debug.Log($"AssetService.UpdateAsset =========== {verModel.item.path}");
            networkService.Get(Constants.CnfAssetUrl + verModel.item.path,
                delegate (byte[] response, int code, bool success, string url)
                {
                    if (success && code == Constants.HttpResponseOk)
                    {
                        HandleAssetUpdateResponse(verModel, response);
                    }
                    else
                    {
                        BoxBuilder.SetLoadingPopShow(false);
                        TypeEventSystem.Send<ConfigUpdateFinishEvent>();
                        // GameEventMessage.SendEvent(Constants.DoozyEvent.ConfigInitFinish);
                    }
                });
        }

        if (_updatingAssets.Count < 1)
        {
            BoxBuilder.SetLoadingPopShow(false);
            TypeEventSystem.Send<ConfigUpdateFinishEvent>();
            // GameEventMessage.SendEvent(Constants.DoozyEvent.ConfigInitFinish);
        }
    }

    
    public async Task<AsyncOperationHandle<TextAsset>> LoadCollectFlowerConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.CollectFlowerConfig}.json");
        await handle.Task;

        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<CollectFlowerConfigModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.CollectFlowerConfig = cfg;
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadRobotConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.RobotConfig}.json");
        await handle.Task;

        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<RobotConfigModel>(handle.Result.text);
            List<RobotConfigModel> robotConfig = new List<RobotConfigModel>();
            foreach (var item in cfg)
                robotConfig.Add(new RobotConfigModel(item));
            robotConfig.Sort((a, b) => int.Parse(a.id).CompareTo(int.Parse(b.id)));
            configService.RobotConfig = robotConfig;
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadValueConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.ValueConfig}.json");
        await handle.Task;

        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<ValueConfigModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model.value);
            configService.ValueConfig = cfg;
            Debug.Log("========= LoadValueConfig Done");
        }

        return handle;
    }


    public async Task<AsyncOperationHandle<TextAsset>> LoadEndlessLevelRewardConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.EndlessLevelRewardConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<EndlessLevelRewardModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.EndlessLevelRewardConfig = cfg;
            Debug.Log("========= LoadEndlessLevelRewardConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadWheelRewardConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.WheelRewardConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<WheelRewardModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.WheelRewardConfig = cfg;
            Debug.Log("========= WheelRewardConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadEndlessStageOneConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.EndlessStageOneConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<StageModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.EndlessStageOneConfig = cfg;
            Debug.Log("========= LoadEndlessStageOneConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadEndlessStageTwoConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.EndlessStageTwoConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<StageModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.EndlessStageTwoConfig = cfg;
            Debug.Log("========= LoadEndlessStageTwoConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadLocalStageConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.StageConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<StageModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.StageConfig = cfg;
            Debug.Log("========= LoadLocalStageConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadCardRemainConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.CardRemainConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<CardRemainModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.CardRemainConfig = cfg;
            Debug.Log("========= LoadCardRemainConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadComboRewardConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.ComboRewardConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<ComboRewardModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.ComboRewardConfig = cfg;
            Debug.Log("========= LoadComboRewardConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadSignInConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.SignInConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<SignInModel>(handle.Result.text)
                .ToDictionary(model => model.grid, model => model);
            configService.SignInConfig = cfg;
            Debug.Log("========= LoadSignInConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadRookieConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.RookieConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<RookieBaseModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => new RookieModel(model));
            configService.RookieConfig = cfg;
            Debug.Log("========= LoadRookieConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadRookieClickConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.RookieClickConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<RookieClickBaseModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => new RookieClickModel(model));
            configService.RookieClickConfig = cfg;
            Debug.Log("========= LoadRookieClickConfig Done");
        }
        return handle;
    }
    public async Task<AsyncOperationHandle<TextAsset>> LoadRookieDialogueConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.RookieDialogueConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<RookieDialogueModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.RookieDialogueConfig = cfg;
            Debug.Log("========= LoadRookieDialogueConfig Done");
        }
        return handle;
    }
    public async Task<AsyncOperationHandle<TextAsset>> LoadRookieDragConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.RookieDragConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<RookieDragModelBase>(handle.Result.text)
                .ToDictionary(model => model.id, model => new RookieDragModel(model));
            configService.RookieDragConfig = cfg;
            Debug.Log("========= LoadRookieDragConfig Done");
        }
        return handle;
    }
    public async Task<AsyncOperationHandle<TextAsset>> LoadRookieAnimConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.RookieAnimConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<RookieAnimModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.RookieAnimConfig = cfg;
            Debug.Log("========= LoadRookieAnimConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadBetConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.BetConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<BetModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.BetConfig = cfg;
            Debug.Log("========= LoadBetConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadItemConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.ItemConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<ItemModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.ItemConfig = cfg;
            Debug.Log("========= LoadItemConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadPowerItemConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.PowerItemConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<PowerItemModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.PowerItemConfig = cfg;
            Debug.Log("========= LoadPowerItemConfig Done");
        }

        return handle;
    }

    // public async Task<AsyncOperationHandle<TextAsset>> LoadWheelConfig()
    // {
    //     var handle =
    //         Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.WheelConfig}.json");
    //     await handle.Task;
    //     if (handle.IsDone)
    //     {
    //         var configService = MainContainer.Container.Resolve<IConfigService>();
    //         var cfg = JsonUtils.ArrayFromJson<WheelModel>(handle.Result.text)
    //             .ToDictionary(model => model.id, model => model);
    //         configService.WheelConfig = cfg;
    //         Debug.Log("========= LoadWheelConfig Done");
    //     }

    //     return handle;
    // }

    public async Task<AsyncOperationHandle<TextAsset>> LoadShopConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Configs/{Constants.StorageKey.ShopConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<ShopModel>(handle.Result.text)
                .ToDictionary(model => model.product_id, model => model);
            configService.ShopConfig = cfg;
            Debug.Log("========= LoadShopConfig Done");
        }

        return handle;
    }


    public async Task<AsyncOperationHandle<TextAsset>> LoadActivitiesConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.ActivitiesConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<ActivityModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.ActivitiesConfig = cfg;
            Debug.Log("========= LoadActivitiesConfig Done");
        }

        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadSeasonRewardConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.SeasonRewardConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<SeasonRewardModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model.Parse());
            configService.SeasonRewardConfig = cfg;
            Debug.Log("========= LoadSeasonRewardConfig Done");
        }

        return handle;
    }


    public async Task<AsyncOperationHandle<TextAsset>> LoadActivitiesSwitchConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.ActivitiesSwitchConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<ActivitiesSwitchModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model.Parse());
            configService.ActivitiesSwitchConfig = cfg;
            Debug.Log("========= LoadActivitiesSwitchConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadCollectLoveCardConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.CollectLoveCardConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<CollectLoveCardModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.CollectLoveCardConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadCollectMusicConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.CollectMusicConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<CollectMusicModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.CollectMusicConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadDigTreasureRewardConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.DigTreasureRewardConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<DigTreasureRewardModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.DigTreasureRewardConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadLevelPassConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.LevelPassConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<LevelPassModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.LevelPassConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadLavaPassConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.LavaPassConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<LavaPassModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.LavaPassConfig = cfg;
        }
        return handle;
    }

    // public async Task<AsyncOperationHandle<TextAsset>> LoadFarmingConfig()
    // {
    //     var handle =
    //         Addressables.LoadAssetAsync<TextAsset>(
    //             $"Assets/Res/Configs/{Constants.StorageKey.FarmingConfig}.json");
    //     await handle.Task;
    //     if (handle.IsDone)
    //     {
    //         var configService = MainContainer.Container.Resolve<IConfigService>();
    //         var cfg = JsonUtils.ArrayFromJson<FarmingModel>(handle.Result.text)
    //             .ToDictionary(model => model.id, model => model);
    //         configService.FarmingConfig = cfg;
    //     }
    //     return handle;
    // }
    
    public async Task<AsyncOperationHandle<TextAsset>> LoadUnlockConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.UnlockConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<UnlockModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.UnlockConfig = cfg;
        }
        return handle;
    }
    

    public async Task<AsyncOperationHandle<TextAsset>> LoadMysteriousSeedConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MysteriousSeedConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MysteriousSeedModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.MysteriousSeedConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadCookMealConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.CookMealConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<CookMealModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.CookMealConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMagicNectarConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MagicNectarConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MagicNectarModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.MagicNectarConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadRainbowDropsConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.RainbowDropsConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<RainbowDropsModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.RainbowDropsConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadPopupPriorityConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.PopupPriorityConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<PopupPriorityModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.PopupPriorityConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadAdRewardConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.AdRewardConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<AdRewardModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.AdRewardConfig = cfg;
        }
        return handle;
    }


    public async Task<AsyncOperationHandle<TextAsset>> LoadPassRankRobotConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.PassRankRobotConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<PassRankRobotModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.PassRankRobotConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadCarRankRobotConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.CarRankRobotConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<CarRankRobotModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.CarRankRobotConfig = cfg;
        }
        return handle;
    }
    
    public async Task<AsyncOperationHandle<TextAsset>> LoadGradientConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.GradientConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<GradientModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.GradientConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadGiftGradientCookConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.GiftGradientCookConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<GradientModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.GiftGradientCookConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadGiftGradientDigConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.GiftGradientDigConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<GradientModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.GiftGradientDigConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadPassRankRewardConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.PassRankRewardConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<PassRankRewardModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.PassRankRewardConfig = cfg;
        }
        return handle;
    }
    
    public async Task<AsyncOperationHandle<TextAsset>> LoadCarRankRewardConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.CarRankRewardConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<CarRankRewardModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.CarRankRewardConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadLimitPkConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.LimitPkConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<LimitPkModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.LimitPkConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadPushGiftConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.PushGiftConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<PushGiftModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.PushGiftConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadSoundConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.SoundConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<SoundModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.SoundConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadCardDescConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.CardDescConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<CardDescModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.CardDescConfig = cfg;
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadSeasonPassConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.SeasonPassConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<SeasonPassModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.SeasonPassConfig = cfg;
        }
        return handle;
    }


    public async Task<AsyncOperationHandle<TextAsset>> LoadNewUserSeasonPassConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.NewUserSeasonPassConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<SeasonPassModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.NewUserSeasonPassConfig = cfg;
        }
        return handle;
    }


    public async Task<AsyncOperationHandle<TextAsset>> LoadSeasonExpConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.SeasonExpConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<SeasonExpModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.SeasonExpConfig = cfg;
            Debug.Log("========= LoadSeasonExpConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadTimingMessageConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.TimingMessageConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<TimingMessageConfigModel>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.TimingMessageConfig = new Dictionary<int, TimingMessageConfigModel>(cfg);
            Debug.Log("========= LoadTimingMessageConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadHandleEndlessLevelConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.HandleEndlessLevelConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<HandleEndlessLevelConfig>(handle.Result.text)
                .ToDictionary(model => model.level, model => model);
            configService.HandleEndlessLevelConfig = new Dictionary<int, HandleEndlessLevelConfig>(cfg);
            Debug.Log("========= LoadHandleEndlessLevelConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadHandleLevelConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.HandleLevelConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<HandleLevelConfig>(handle.Result.text)
                .ToDictionary(model => model.level, model => model);
            configService.HandleLevelConfig = new Dictionary<int, HandleLevelConfig>(cfg);
            Debug.Log("========= LoadHandleLevelConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadHandleResultConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.HandleResultConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<HandleResultConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.HandleResultConfig = new Dictionary<int, HandleResultConfig>(cfg);
            Debug.Log("========= LoadHandleResultConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadHandleLabelConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.HandleLabelConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<HandleLabelConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.HandleLabelConfig = new Dictionary<int, HandleLabelConfig>(cfg);
            Debug.Log("========= LoadHandleLabelConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadHandleConsumConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.HandleConsumConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<HandleConsumConfig>(handle.Result.text)
                .ToDictionary(model => model.bet, model => model);
            configService.HandleConsumConfig = new Dictionary<int, HandleConsumConfig>(cfg);
            Debug.Log("========= LoadHandleConsumConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadHandlePaidConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.HandlePaidConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<HandlePaidConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.HandlePaidConfig = new Dictionary<int, HandlePaidConfig>(cfg);
            Debug.Log("========= LoadHandlePaidConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMergeItemConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeItemConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeItemConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            foreach (var item in cfg)
            {
                if(cfg[item.Key].mergeItem != -1)
                {
                    cfg[cfg[item.Key].mergeItem].nextItemId = item.Key;
                }
            }
            configService.MergeItemConfig = new Dictionary<int, MergeItemConfig>(cfg);
            Debug.Log("========= MergeItemConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMergeMapConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeMapConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeMapConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.MergeMapConfig = new Dictionary<int, MergeMapConfig>(cfg);
            Debug.Log("========= MergeMapConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMergeRegionRewardsConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeRegionRewardsConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeRegionRewardsConfig>(handle.Result.text)
                .ToDictionary(model => model.id * 1000 + model.level, model => model);
            configService.MergeRegionRewardsConfig = new Dictionary<int, MergeRegionRewardsConfig>(cfg);
            Debug.Log("========= MergeRegionRewardsConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMergeOrderDegreeConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeOrderDegreeConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeOrderDegreeConfig>(handle.Result.text)
                .ToList();
            configService.MergeOrderDegreeConfig = cfg;
            Debug.Log("========= MergeOrderDegreeConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMergeOrderListConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeOrderListConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeOrderListConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.MergeOrderListConfig = new Dictionary<int, MergeOrderListConfig>(cfg);
            Debug.Log("========= MergeOrderListConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMergeBuildConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeBuildConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeBuildConfig>(handle.Result.text)
                .ToDictionary(model => model.id * 100 + model.build_lv, model => model);
            configService.MergeBuildConfig = new Dictionary<int, MergeBuildConfig>(cfg);
            Debug.Log("========= MergeBuildConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMergeLevelBoxConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeLevelBoxConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeLevelBoxConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.MergeLevelBoxConfig = new Dictionary<int, MergeLevelBoxConfig>(cfg);
            Debug.Log("========= MergeLevelBoxConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMergeShopConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeShopConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeShopConfig>(handle.Result.text)
                .ToDictionary(model => model.region_id * 1000 + model.level, model => new MergeShopConfigEx(model));
            configService.MergeShopConfig = new Dictionary<int, MergeShopConfigEx>(cfg);
            Debug.Log("========= MergeShopConfig Done");
        }
        return handle;
    }
    
    public async  Task<AsyncOperationHandle<TextAsset>> LoadMergeHotAirBallConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeHotAirBallConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeHotAirBallConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.MergeHotAirBallConfig = new Dictionary<int, MergeHotAirBallConfig>(cfg);
            Debug.Log("========= MergeHotAirBallConfig Done");
        }
        return handle;
    }

    public async  Task<AsyncOperationHandle<TextAsset>> LoadMergeItemNpcConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeItemNpcConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeItemNpcConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.MergeItemNpcConfig = new Dictionary<int, MergeItemNpcConfig>(cfg);
            Debug.Log("========= MergeItemNpcConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadMergeIllustratedConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.MergeIllustratedConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<MergeIllustratedConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.MergeIllustratedConfig = new Dictionary<int, MergeIllustratedConfig>(cfg);
            Debug.Log("========= MergeIllustratedConfig Done");
        }
        return handle;
    }

    public async Task<AsyncOperationHandle<TextAsset>> LoadEnergyConfig()
    {
        var handle =
            Addressables.LoadAssetAsync<TextAsset>(
                $"Assets/Res/Configs/{Constants.StorageKey.EnergyConfig}.json");
        await handle.Task;
        if (handle.IsDone)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var cfg = JsonUtils.ArrayFromJson<EnergyConfig>(handle.Result.text)
                .ToDictionary(model => model.id, model => model);
            configService.EnergyConfig = new Dictionary<int, EnergyConfig>(cfg);
            Debug.Log("========= EnergyConfig Done");

        }
        return handle;
    }

    public bool IsLocalLevelJson(string level)
    {
        if (_assetItemVersionInfo.TryGetValue(level, out var verModel))
            return verModel.local_version >= verModel.patch_version;
        return false;
    }

    public bool IsLatestLevelJson(string levelJsonName, bool doUpdate = true)
    {
        var storageService = MainContainer.Container.Resolve<IStorageService>();

        var assetId = $"assets/level/{levelJsonName}.json";
        if (_assetItemVersionInfo.TryGetValue(assetId, out var verModel))
        {
            string localFilePath = $"Levels/{levelJsonName}";
            string downloadFilePath = storageService.LevelJsonDownloadPath(levelJsonName);
            if (verModel.remote_version != -1)
            {
                var currentVersion = Math.Max(verModel.patch_version, verModel.local_version);
                if (verModel.remote_version > currentVersion)
                {
                    if (doUpdate)
                        UpdateLevelJson(assetId, storageService.LevelJsonDownloadPath(levelJsonName));
                    return false;
                }
            }
            else
            {
                if (verModel.local_version > verModel.patch_version)
                {
                    if (!storageService.ResourceFileExists(localFilePath))
                    {
                        verModel.local_version = -1;
                        if (verModel.remote_version != -1 && doUpdate)
                            UpdateLevelJson(assetId, storageService.LevelJsonDownloadPath(levelJsonName));
                        return false;
                    }
                }
                else
                {
                    if (!storageService.FileExists(downloadFilePath))
                    {
                        verModel.patch_version = -1;
                        if (verModel.remote_version != -1 && doUpdate)
                            UpdateLevelJson(assetId, storageService.LevelJsonDownloadPath(levelJsonName));
                        return false;
                    }
                }
            }
        }

        //else
        //{
        //    Debug.Log($"AssetService.IsLatestAsset : assetId is not exist, assetId = {levelJsonName}");
        //    return false;
        //}
        return true;
    }

    private void UpdateLevelJson(string assetId, string assetDir)
    {
        var networkService = MainContainer.Container.Resolve<INetworkService>();

        if (!_assetItemVersionInfo.TryGetValue(assetId, out var verModel))
            return;

        var downloadUrl = Constants.CnfAssetUrl + verModel.item.path;
        networkService.DownloadAsset(downloadUrl, assetDir, verModel.remote_version,
            delegate (byte[] response, int code, bool success, string url)
            {
                if (success && (code == Constants.HttpResponseOk || code == Constants.HttpResponseOkPartial ||
                                code == Constants.HttpResponseNotModified))
                {
                    verModel.patch_version = verModel.remote_version;
                    _assetItemVersionInfo[assetId] = verModel;
                    SaveAsset();
                }

                var param = new DownloadLevelJsonResultEvent(url, code, success);
                TypeEventSystem.Send<DownloadLevelJsonResultEvent>(param);
            }, delegate (string url, long downloaded, long length)
            {
                var param = new DownloadLevelJsonUpdateEvent(url, downloaded, length);
                TypeEventSystem.Send<DownloadLevelJsonUpdateEvent>(param);
            });
    }

    public AssetItemVersionModel GetAssetVersionInfo(string assetId)
    {
        if (_assetItemVersionInfo.TryGetValue(assetId, out var verModel))
            return verModel;
        return null;
    }
}