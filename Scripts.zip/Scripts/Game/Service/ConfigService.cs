using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using System.Globalization;
using SoliUtils;
using Activities;
using static Constants;

public interface IConfigService
{
    string OriginalItem { get; }
    int SaverAfterfullPopInterval { get; }
    int SaverWarning { get; }
    int FirstChargeOpenInterval { get; }
    int TriggerGiftTimeInterval { get; }
    int TriggerGiftCoinNum { get; }
    int UpdateTipsOpenLv { get; }
    int CoinRewardVideoValue { get; }
    int CoinRewardVideoDailyTimes { get; }
    int BrokenCoinNum { get; }
    int SaverRewardConstant { get; }
    int SaverInitial { get; }
    int SaverBankMin { get; }
    int SaverBankMax { get; }

    int[] WheelOpenInterval { get; }
    int InterAdOpenlv { get; }
    int InterAdCooldown { get; }
    int InterAdCooldownPayinguser { get; }
    int FailSameLevelShowRookie { get; }
    List<int[]> BuyCardGuar { get; }
    float[] LevelCardCoinDistribute { get; }
    int[] WinningStreakOpenTime { get; }
    float[] WinstreakRemainFactor { get; }
    float WildComboRemainFactor { get; }
    float WildFreeRemainFactor { get; }
    float WildBuyRemainFactor { get; }

    int MessageLimit { get; }
    string ReturnReward { get; }
    Dictionary<int, int> GetSeasonPassRation { get; }
    Dictionary<int, int> GetIntegralCardRule { get; }
    Dictionary<int, int> GetBigIntegralComboRule { get; }
    Dictionary<int, int> GetSmallIntegralComboRule { get; }
    Dictionary<int, PassRankRobotRuleModel> PassRankRobotRule { get; }
    Dictionary<int, CarRankRobotRuleModel> CarRankRobotRule { get; }
    Dictionary<int, RobotConfigModel> RobotList { get; }
    Dictionary<int, int> GetSeasonBoxReward { get; }
    int ReturnTime { get; }
    int DailyWinTimes { get; }

    Dictionary<string, string> ValueConfig { get; set; }
    Dictionary<int, CollectFlowerConfigModel> CollectFlowerConfig { get; set; }
    List<RobotConfigModel> RobotConfig { get; set; }
    Dictionary<int, StageModel> StageConfig { get; set; }
    Dictionary<int, StageModel> EndlessStageOneConfig { get; set; }
    Dictionary<int, StageModel> EndlessStageTwoConfig { get; set; }
    Dictionary<int, StageModel> GetStageConfig { get; }
    Dictionary<int, EndlessLevelRewardModel> EndlessLevelRewardConfig { get; set; }
    Dictionary<int, WheelRewardModel> WheelRewardConfig { get; set; }
    // Dictionary<int, HandleModel> HandleConfig { get; set; }
    Dictionary<int, SignInModel> SignInConfig { get; set; }
    // Dictionary<int, WheelModel> WheelConfig { get; set; }
    Dictionary<string, ShopModel> ShopConfig { get; set; }
    Dictionary<int, CardRemainModel> CardRemainConfig { get; set; }
    Dictionary<int, ComboRewardModel> ComboRewardConfig { get; set; }
    Dictionary<int, RookieModel> RookieConfig { get; set; }
    Dictionary<int, RookieClickModel> RookieClickConfig { get; set; }
    Dictionary<int, RookieDialogueModel> RookieDialogueConfig { get; set; }
    Dictionary<int, RookieDragModel> RookieDragConfig { get; set; }
    Dictionary<int, RookieAnimModel> RookieAnimConfig { get; set; }
    Dictionary<int, BetModel> BetConfig { get; set; }
    Dictionary<int, ItemModel> ItemConfig { get; set; }
    Dictionary<int, PowerItemModel> PowerItemConfig { get; set; }
    Dictionary<int, ActivityModel> ActivitiesConfig { get; set; }
    Dictionary<int, SeasonRewardModel> SeasonRewardConfig { get; set; }
    Dictionary<int, ActivitiesSwitchModel> ActivitiesSwitchConfig { get; set; }
    Dictionary<int, CollectLoveCardModel> CollectLoveCardConfig { get; set; }
    Dictionary<int, CollectMusicModel> CollectMusicConfig { get; set; }
    Dictionary<int, DigTreasureRewardModel> DigTreasureRewardConfig { get; set; }
    Dictionary<int, LevelPassModel> LevelPassConfig { get; set; }
    Dictionary<int, LavaPassModel> LavaPassConfig { get; set; }
    // Dictionary<int, FarmingModel> FarmingConfig { get; set; }
    Dictionary<int, UnlockModel> UnlockConfig { get; set; }
    Dictionary<int, CookMealModel> CookMealConfig { get; set; }
    Dictionary<int, MysteriousSeedModel> MysteriousSeedConfig { get; set; }
    Dictionary<int, MagicNectarModel> MagicNectarConfig { get; set; }
    Dictionary<int, RainbowDropsModel> RainbowDropsConfig { get; set; }
    Dictionary<string, PopupPriorityModel> PopupPriorityConfig { get; set; }
    Dictionary<int, AdRewardModel> AdRewardConfig { get; set; }
    Dictionary<int, PassRankRobotModel> PassRankRobotConfig { get; set; }
    Dictionary<int, CarRankRobotModel> CarRankRobotConfig { get; set; }
    Dictionary<int, GradientModel> GradientConfig { get; set; }
    Dictionary<int, GradientModel> GiftGradientCookConfig { get; set; }
    Dictionary<int, GradientModel> GiftGradientDigConfig { get; set; }
    Dictionary<int, PassRankRewardModel> PassRankRewardConfig { get; set; }
    Dictionary<int, CarRankRewardModel> CarRankRewardConfig { get; set; }
    Dictionary<int, LimitPkModel> LimitPkConfig { get; set; }
    Dictionary<string, SoundModel> SoundConfig { get; set; }
    Dictionary<int, PushGiftModel> PushGiftConfig { get; set; }
    Dictionary<int, CardDescModel> CardDescConfig { get; set; }
    Dictionary<int, SeasonPassModel> SeasonPassConfig { get; set; }
    Dictionary<int, SeasonPassModel> NewUserSeasonPassConfig { get; set; }
    Dictionary<int, SeasonExpModel> SeasonExpConfig { get; set; }
    Dictionary<int, TimingMessageConfigModel> TimingMessageConfig { get; set; }

    Dictionary<int, HandleEndlessLevelConfig> HandleEndlessLevelConfig { get; set; }
    Dictionary<int, HandleLevelConfig> HandleLevelConfig { get; set; }
    Dictionary<int, HandleResultConfig> HandleResultConfig { get; set; }
    Dictionary<int, HandleLabelConfig> HandleLabelConfig { get; set; }
    Dictionary<int, HandleConsumConfig> HandleConsumConfig { get; set; }
    Dictionary<int, HandlePaidConfig> HandlePaidConfig { get; set; }
    Dictionary<int, MergeItemConfig> MergeItemConfig { get; set; }
    Dictionary<int, MergeMapConfig> MergeMapConfig { get; set; }
    Dictionary<int, MergeRegionRewardsConfig> MergeRegionRewardsConfig { get; set; }//key:id*1000+level
    List<MergeOrderDegreeConfig> MergeOrderDegreeConfig { get; set; }
    Dictionary<int, MergeOrderListConfig> MergeOrderListConfig { get; set; }
    Dictionary<int, MergeBuildConfig> MergeBuildConfig { get; set; }
    Dictionary<int, MergeLevelBoxConfig> MergeLevelBoxConfig { get; set; }
    Dictionary<int, MergeShopConfigEx> MergeShopConfig { get; set; }
    Dictionary<int, MergeHotAirBallConfig> MergeHotAirBallConfig { get; set; }
    Dictionary<int, MergeItemNpcConfig> MergeItemNpcConfig { get; set; }
    Dictionary<int, MergeIllustratedConfig> MergeIllustratedConfig { get; set; }
    Dictionary<int, EnergyConfig> EnergyConfig { get; set; }

    string GetLevelJsonName(int stageId);
    int GetUndoCost(int stageId, int undoTime);
    int GetBuyJokerCost(int stageId, int buyTime);
    int GetBuyCardCost(int stageId, int buyTime);
    string GetGrid(int propId);
    int GetComboReward(int stageId, int comboNum);
    ComboRewardModel GetComboItemReward(int stageId, int step);
    int GetStageCost(int stageId);
    int GetStageHard(int stageId);
    Dictionary<int, int> GetResultReward(int stageId);
    int GetRemainReward(int stageId, int remainIndex);
    System.Tuple<int, int> GenHandCardMaxGuar(int stageId);
    int[] GenComboStep(int stageId);
    int GetInterAdInterval();
    Dictionary<int, float> GetBuildCoinRate();
    // Dictionary<int, Dictionary<int, FarmingModel>> GetHomeMapModel();
    Dictionary<int, int> GetLavaReward();
    FarmingModel GetFarmingModel(int mapId, int themeId, int landId);
    float GetWinStreakIdx(int winCount, out int stepIdx);
    string[] GetWinStreakRewardCards(int winCount, int idx);
    int GetCoinFlyCount(long coinNum);
    Dictionary<int, int> GetBubbleReward(int bubbleCount, MergeLevelBoxConfig model);
    Dictionary<int, CardRemainModel> GetCardRemainConfigType1();
    Dictionary<int, CardRemainModel> GetCardRemainConfigType2();

    Tuple<CardType, ModifierType> GetQuestionCard();

    string GetItemName(int itemId);
    MergeItemType GetMergeItemEndType(int itemId);

}

public class ConfigService : IConfigService
{
    public Dictionary<int, List<SeasonLvRewardItem>> _passRankReward;
    public Dictionary<int, List<SeasonLvRewardItem>> _collectFlowerReward;
    public Dictionary<int, List<object>> _collectLoveCardRule;
    public Dictionary<int, int> _getSeasonPassRation;
    public Dictionary<int, Dictionary<int, FarmingModel>> _getHomeMapData;
    public Dictionary<int, int> _getIntegralCardRule;
    public Dictionary<int, int> _getBigIntegralComboRule;
    public Dictionary<int, int> _getSmallIntegralComboRule;
    public Dictionary<int, PassRankRobotRuleModel> _passRankRobotRule;
    public Dictionary<int, CarRankRobotRuleModel> _carRankRobotRule;
    public Dictionary<int, RobotConfigModel> _robotList;
    private int? _saverAfterfullPopInterval = null;
    private int? _saverWarning = null;
    private List<int> _coinFlyCountList = null;
    private List<int[]> _buyCardGuar = null;
    private float[] _levelCardCoinDistribute = null;

    private int? _saverRewardConstant = null;
    private int? _saverInitial = null;
    private int? _saverBankMin = null;
    private int? _saverBankMax = null;

    private int[] _wheelOpenInterval = null;

    private int? _afkRewardOpenLv = null;
    private int? _afkRewardGetTime = null;
    private int? _afkRewardGetCount = null;
    private int? _firstChargeOpenInterval = null;
    private int? _triggerGiftTimeInterval = null;
    private int? _triggerGiftCoinNum = null;
    private int? _updateTipsOpenLv = null;
    private int? _coinRewardVideoValue = null;
    private int? _coinRewardVideoDailyTimes = null;
    private int? _brokenCoinNum = null;

    private int? _interAdOpenlv = null;
    private int? _interAdCooldown = null;
    private int? _interAdCooldownPayinguser = null;
    private int? _failSameLevelShowRookie = null;
    private int? _dailyWinTimes = null;

    private int? _passRankOpenLv = null;
    private float? _perIsPlay = null;
    private int? _randomPlayCount = null;
    private float[] _winstreakRemainFactor = null;
    private int[] _winningStreakOpenTime = null;
    private int[] _randomCupFactor = null;
    private int[] _passRankOpenTime = null;
    private DateTime[] _passRankTime = null;
    private float? _wildComboRemainFactor = null;
    private float? _wildFreeRemainFactor = null;
    private float? _wildBuyRemainFactor = null;

    private int? _messageLimit = null;
    private int? _returnTime = null;



    public Dictionary<string, string> ValueConfig { get; set; }
    public Dictionary<int, CollectFlowerConfigModel> CollectFlowerConfig { get; set; }
    public List<RobotConfigModel> RobotConfig { get; set; }
    public Dictionary<int, StageModel> StageConfig { get; set; }

    public Dictionary<int, EndlessLevelRewardModel> EndlessLevelRewardConfig { get; set; }
    public Dictionary<int, WheelRewardModel> WheelRewardConfig { get; set; }
    public Dictionary<int, StageModel> EndlessStageOneConfig { get; set; }
    public Dictionary<int, StageModel> EndlessStageTwoConfig { get; set; }
    // public Dictionary<int, HandleModel> HandleConfig { get; set; }
    public Dictionary<int, SignInModel> SignInConfig { get; set; }
    // public Dictionary<int, WheelModel> WheelConfig { get; set; }
    public Dictionary<string, ShopModel> ShopConfig { get; set; }
    public Dictionary<int, CardRemainModel> CardRemainConfig { get; set; }
    public Dictionary<int, ComboRewardModel> ComboRewardConfig { get; set; }
    public Dictionary<int, RookieModel> RookieConfig { get; set; }
    public Dictionary<int, RookieClickModel> RookieClickConfig { get; set; }
    public Dictionary<int, RookieDialogueModel> RookieDialogueConfig { get; set; }
    public Dictionary<int, RookieDragModel> RookieDragConfig { get; set; }
    public Dictionary<int, RookieAnimModel> RookieAnimConfig { get; set; }
    public Dictionary<int, BetModel> BetConfig { get; set; }
    public Dictionary<int, ItemModel> ItemConfig { get; set; }
    public Dictionary<int, PowerItemModel> PowerItemConfig { get; set; }
    public Dictionary<int, ActivityModel> ActivitiesConfig { get; set; }
    public Dictionary<int, SeasonRewardModel> SeasonRewardConfig { get; set; }
    public Dictionary<int, ActivitiesSwitchModel> ActivitiesSwitchConfig { get; set; }
    public Dictionary<int, CollectLoveCardModel> CollectLoveCardConfig { get; set; }
    public Dictionary<int, CollectMusicModel> CollectMusicConfig { get; set; }
    public Dictionary<int, DigTreasureRewardModel> DigTreasureRewardConfig { get; set; }
    public Dictionary<int, LevelPassModel> LevelPassConfig { get; set; }
    public Dictionary<int, LavaPassModel> LavaPassConfig { get; set; }
    // public Dictionary<int, FarmingModel> FarmingConfig { get; set; }
    public Dictionary<int, UnlockModel> UnlockConfig { get; set; }
    public Dictionary<int, CookMealModel> CookMealConfig { get; set; }
    public Dictionary<int, MysteriousSeedModel> MysteriousSeedConfig { get; set; }
    public Dictionary<int, MagicNectarModel> MagicNectarConfig { get; set; }
    public Dictionary<int, RainbowDropsModel> RainbowDropsConfig { get; set; }
    public Dictionary<string, PopupPriorityModel> PopupPriorityConfig { get; set; }

    public Dictionary<int, AdRewardModel> AdRewardConfig { get; set; }

    public Dictionary<int, PassRankRobotModel> PassRankRobotConfig { get; set; }
    public Dictionary<int, CarRankRobotModel> CarRankRobotConfig { get; set; }
    public Dictionary<int, GradientModel> GradientConfig { get; set; }
    public Dictionary<int, GradientModel> GiftGradientCookConfig { get; set; }
    public Dictionary<int, GradientModel> GiftGradientDigConfig { get; set; }
    public Dictionary<int, PassRankRewardModel> PassRankRewardConfig { get; set; }
    public Dictionary<int, CarRankRewardModel> CarRankRewardConfig { get; set; }
    public Dictionary<int, LimitPkModel> LimitPkConfig { get; set; }
    public Dictionary<int, PushGiftModel> PushGiftConfig { get; set; }
    public Dictionary<string, SoundModel> SoundConfig { get; set; }
    public Dictionary<int, CardDescModel> CardDescConfig { get; set; }
    public Dictionary<int, SeasonPassModel> SeasonPassConfig { get; set; }
    public Dictionary<int, SeasonPassModel> NewUserSeasonPassConfig { get; set; }
    public Dictionary<int, SeasonExpModel> SeasonExpConfig { get; set; }
    public Dictionary<int, TimingMessageConfigModel> TimingMessageConfig { get; set; }
    public Dictionary<int, HandleLevelConfig> HandleLevelConfig { get; set; }
    public Dictionary<int, HandleEndlessLevelConfig> HandleEndlessLevelConfig { get; set; }
    public Dictionary<int, HandleResultConfig> HandleResultConfig { get; set; }
    public Dictionary<int, HandleLabelConfig> HandleLabelConfig { get; set; }
    public Dictionary<int, HandleConsumConfig> HandleConsumConfig { get; set; }
    public Dictionary<int, HandlePaidConfig> HandlePaidConfig { get; set; }
    public Dictionary<int, MergeItemConfig> MergeItemConfig { get; set; }
    public Dictionary<int, MergeMapConfig> MergeMapConfig { get; set; }
    public Dictionary<int, MergeRegionRewardsConfig> MergeRegionRewardsConfig { get; set; }
    public List<MergeOrderDegreeConfig> MergeOrderDegreeConfig { get; set; }
    public Dictionary<int, MergeOrderListConfig> MergeOrderListConfig { get; set; }
    public Dictionary<int, MergeBuildConfig> MergeBuildConfig { get; set; }
    public Dictionary<int, MergeLevelBoxConfig> MergeLevelBoxConfig { get; set; }
    public Dictionary<int, MergeShopConfigEx> MergeShopConfig { get; set; }
    public Dictionary<int, MergeHotAirBallConfig> MergeHotAirBallConfig { get; set; }
    public Dictionary<int, MergeItemNpcConfig> MergeItemNpcConfig { get; set; }
    public Dictionary<int, MergeIllustratedConfig> MergeIllustratedConfig { get; set; }
    public Dictionary<int, EnergyConfig> EnergyConfig { get; set; }



    public Dictionary<int, StageModel> GetStageConfig
    {
        get
        {
            if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel) != null &&
                ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
            {
                var dataService = MainContainer.Container.Resolve<IDataService>();
                if (dataService.EndlessLevelProgress.SubActivityType == 1)
                {
                    return EndlessStageOneConfig;
                }
                else
                {
                    return EndlessStageTwoConfig;
                }
            }
            else
            {
                return StageConfig;
            }
        }
    }
    public string OriginalItem
    {
        get
        {
            if (!ValueConfig.ContainsKey(Constants.ValueConfigKey.OriginalItem))
                return "1,10000; 2,5; 3,3; 4,3";
            return ValueConfig[Constants.ValueConfigKey.OriginalItem];
        }
    }

    public string ReturnReward
    {
        get
        {
            return ValueConfig[Constants.ValueConfigKey.ReturnReward];
        }
    }

    public Dictionary<int, RobotConfigModel> RobotList
    {
        get
        {
            if (_robotList == null)
            {
                _robotList = new Dictionary<int, RobotConfigModel>();
                foreach (var item in RobotConfig)
                {
                    _robotList.Add(int.Parse(item.id), item);
                }
            }
            return _robotList;
        }
    }

    public Dictionary<int, int> GetSmallIntegralComboRule
    {
        get
        {
            if (_getSmallIntegralComboRule == null)
            {
                _getSmallIntegralComboRule = new Dictionary<int, int>();
                string[] propArray = ValueConfig["SmallIntegralComboRule"].Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                foreach (var propInfo in propArray)
                {
                    string[] rewardParam = propInfo.Split(GameUtils.FirstSeparator);
                    int key = int.Parse(rewardParam[0]);
                    int value = int.Parse(rewardParam[1]);
                    _getSmallIntegralComboRule.Add(key, value);
                }
            }
            return _getSmallIntegralComboRule;
        }
    }

    public Dictionary<int, PassRankRobotRuleModel> PassRankRobotRule
    {
        get
        {
            if (_passRankRobotRule == null)
            {
                _passRankRobotRule = new Dictionary<int, PassRankRobotRuleModel>();
                int index = 0;
                int robotType = 1;
                foreach (var model in PassRankRobotConfig)
                {
                    List<PassRankRobotRuleModel> rangeList = new List<PassRankRobotRuleModel>();
                    foreach (var temp in model.Value.range.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries))
                    {
                        PassRankRobotRuleModel ruleModel = new PassRankRobotRuleModel();
                        string[] range = temp.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                        foreach (var value in range)
                        {
                            ruleModel.range.Add(int.Parse(value));
                        }
                        rangeList.Add(ruleModel);
                    }

                    int rangeIndex = 0;
                    foreach (var node in model.Value.node.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries))
                    {
                        rangeList[rangeIndex].robotType = robotType;
                        rangeList[rangeIndex].node = int.Parse(node);
                        rangeList[rangeIndex].amount = model.Value.amount;
                        _passRankRobotRule.TryAdd(index, rangeList[rangeIndex]);
                        rangeIndex++;
                        index++;
                    }
                    robotType++;
                }
            }
            return _passRankRobotRule;
        }
    }

    public Dictionary<int, CarRankRobotRuleModel> CarRankRobotRule
    {
        get
        {
            if (_carRankRobotRule == null)
            {
                _carRankRobotRule = new Dictionary<int, CarRankRobotRuleModel>();
                int index = 0;
                int robotType = 1;
                foreach (var model in CarRankRobotConfig)
                {
                    List<CarRankRobotRuleModel> rangeList = new List<CarRankRobotRuleModel>();
                    foreach (var temp in model.Value.range.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries))
                    {
                        CarRankRobotRuleModel ruleModel = new CarRankRobotRuleModel();
                        string[] range = temp.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                        foreach (var value in range)
                        {
                            ruleModel.range.Add(int.Parse(value));
                        }
                        rangeList.Add(ruleModel);
                    }

                    int rangeIndex = 0;
                    foreach (var node in model.Value.node.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries))
                    {
                        rangeList[rangeIndex].robotType = robotType;
                        rangeList[rangeIndex].node = int.Parse(node);
                        rangeList[rangeIndex].amount = model.Value.amount;
                        _carRankRobotRule.TryAdd(index, rangeList[rangeIndex]);
                        rangeIndex++;
                        index++;
                    }
                    robotType++;
                }
            }
            return _carRankRobotRule;
        }
    }
    
    public Dictionary<int, int> GetSeasonPassRation
    {
        get
        {
            if (_getSeasonPassRation == null)
            {
                _getSeasonPassRation = new Dictionary<int, int>();
                string[] propArray = ValueConfig["SeasonPassRation"].Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                foreach (var propInfo in propArray)
                {
                    string[] rewardParam = propInfo.Split(GameUtils.FirstSeparator);
                    int key = int.Parse(rewardParam[0]);
                    int value = int.Parse(rewardParam[1]);
                    _getSeasonPassRation.Add(key, value);
                }
            }
            return _getSeasonPassRation;
        }
    }

    public Dictionary<int, float> GetBuildCoinRate()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        int stageId = Mathf.Max(dataService.NowMaxLevel, 1);
        if (GetStageConfig.ContainsKey(stageId) && GetStageConfig.TryGetValue(stageId, out var stageCnf) && stageCnf.RewardRate.Count > 0)
        {
            return stageCnf.RewardRate;
        }
        return null;
    }

    // public Dictionary<int, Dictionary<int, FarmingModel>> GetHomeMapModel()
    // {
    //     if (_getHomeMapData == null)
    //     {
    //         _getHomeMapData = new Dictionary<int, Dictionary<int, FarmingModel>>();
    //         foreach (var VARIABLE in FarmingConfig)
    //         {
    //             FarmingModel model = VARIABLE.Value;
    //             if (!_getHomeMapData.ContainsKey(VARIABLE.Value.mapId))
    //             {
    //                 Dictionary<int, FarmingModel> dict = new Dictionary<int, FarmingModel>();
    //                 dict.Add(model.themeId, model);
    //                 _getHomeMapData.Add(model.mapId, dict);
    //             }
    //             else
    //             {
    //                 if (!_getHomeMapData[model.mapId].ContainsKey(model.themeId))
    //                 {
    //                     _getHomeMapData[model.mapId].Add(model.themeId, model);
    //                 }
    //             }
    //         }
    //     }
    //     return _getHomeMapData;
    // }


    public Dictionary<int, int> GetIntegralCardRule
    {
        get
        {
            if (_getIntegralCardRule == null)
            {
                _getIntegralCardRule = new Dictionary<int, int>();
                string[] propArray = ValueConfig["IntegralCardRule"].Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                foreach (var propInfo in propArray)
                {
                    string[] rewardParam = propInfo.Split(GameUtils.FirstSeparator);
                    int key = int.Parse(rewardParam[0]);
                    int value = int.Parse(rewardParam[1]);
                    _getIntegralCardRule.Add(key, value);
                }
            }
            return _getIntegralCardRule;
        }
    }

    public Dictionary<int, int> GetBigIntegralComboRule
    {
        get
        {
            if (_getBigIntegralComboRule == null)
            {
                _getBigIntegralComboRule = new Dictionary<int, int>();
                string[] propArray = ValueConfig["BigIntegralComboRule"].Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                foreach (var propInfo in propArray)
                {
                    string[] rewardParam = propInfo.Split(GameUtils.FirstSeparator);
                    int key = int.Parse(rewardParam[0]);
                    int value = int.Parse(rewardParam[1]);
                    _getBigIntegralComboRule.Add(key, value);
                }
            }
            return _getBigIntegralComboRule;
        }
    }


    public Dictionary<int, int> GetSeasonBoxReward
    {
        get
        {
            (_, Dictionary<int, int> reward) = GameUtils.AnalysisWeightPropString(ValueConfig["SeasonPassBoxReward"]);
            return reward;
        }
    }

    public int SaverAfterfullPopInterval
    {
        get
        {
            if (!_saverAfterfullPopInterval.HasValue)
                _saverAfterfullPopInterval = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.SaverAfterfullPopInterval]);
            return _saverAfterfullPopInterval.Value;
        }
    }

    public int SaverWarning
    {
        get
        {
            if (!_saverWarning.HasValue)
                _saverWarning = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.SaverWarning]);
            return _saverWarning.Value;
        }
    }

    public int[] WheelOpenInterval
    {
        get
        {
            if (_wheelOpenInterval == null)
                _wheelOpenInterval = Array.ConvertAll(ValueConfig[Constants.ValueConfigKey.WheelOpenInterval].Split(GameUtils.FirstSeparator), (str) => int.Parse(str, CultureInfo.InvariantCulture));
            return _wheelOpenInterval;
        }
    }

    public int SaverRewardConstant
    {
        get
        {
            if (!_saverRewardConstant.HasValue)
                _saverRewardConstant = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.SaverRewardConstant]);
            return _saverRewardConstant.Value;
        }
    }

    public int SaverInitial
    {
        get
        {
            if (!_saverInitial.HasValue)
                _saverInitial = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.SaverInitial]);
            return _saverInitial.Value;
        }
    }

    public int SaverBankMin
    {
        get
        {
            Dictionary<int, int> reward = GameUtils.AnalysisPropString(ValueConfig[Constants.ValueConfigKey.SaverBankMin]);
            reward.TryGetValue((int)PropEnum.Coin, out int count);
            return count;
        }
    }

    public int SaverBankMax
    {
        get
        {
            Dictionary<int, int> reward = GameUtils.AnalysisPropString(ValueConfig[Constants.ValueConfigKey.SaverBankMax]);
            reward.TryGetValue((int)PropEnum.Coin, out int count);
            return count;
        }
    }

    public int FirstChargeOpenInterval
    {
        get
        {
            if (!_firstChargeOpenInterval.HasValue)
                _firstChargeOpenInterval = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.FirstChargeOpenInterval]);
            return _firstChargeOpenInterval.Value;
        }
    }

    public int TriggerGiftTimeInterval
    {
        get
        {
            return 20;
            if (!_triggerGiftTimeInterval.HasValue)
                _triggerGiftTimeInterval = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.TriggerGiftTimeInterval]);
            return _triggerGiftTimeInterval.Value;
        }
    }

    public int TriggerGiftCoinNum
    {
        get
        {
            if (!_triggerGiftCoinNum.HasValue)
                _triggerGiftCoinNum = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.TriggerGiftCoinNum]);
            return _triggerGiftCoinNum.Value;
        }
    }

    public int UpdateTipsOpenLv
    {
        get
        {
            if (!_updateTipsOpenLv.HasValue)
                _updateTipsOpenLv = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.UpdateTipsOpenLv]);
            return _updateTipsOpenLv.Value;
        }
    }

    public int CoinRewardVideoValue
    {
        get
        {
            if (!_coinRewardVideoValue.HasValue)
                _coinRewardVideoValue = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.CoinRewardVideoValue]);
            return _coinRewardVideoValue.Value;
        }
    }

    public int CoinRewardVideoDailyTimes
    {
        get
        {
            if (!_coinRewardVideoDailyTimes.HasValue)
                _coinRewardVideoDailyTimes = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.CoinRewardVideoDailyTimes]);
            return _coinRewardVideoDailyTimes.Value;
        }
    }

    public int BrokenCoinNum
    {
        get
        {
            if (!_brokenCoinNum.HasValue)
                _brokenCoinNum = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.BrokenCoinNum]);
            return _brokenCoinNum.Value;
        }
    }

    public int[] WinningStreakOpenTime
    {
        get
        {
            if (_winningStreakOpenTime == null)
                _winningStreakOpenTime = Array.ConvertAll(ValueConfig[Constants.ValueConfigKey.WinningStreakOpenTime].Split(GameUtils.FirstSeparator), (str) => int.Parse(str, CultureInfo.InvariantCulture));
            return _winningStreakOpenTime;
        }
    }

    public float[] WinstreakRemainFactor
    {
        get
        {
            if (_winstreakRemainFactor == null)
                _winstreakRemainFactor = Array.ConvertAll(ValueConfig[Constants.ValueConfigKey.WinstreakRemainFactor].Split(GameUtils.FirstSeparator), (str) => float.Parse(str, CultureInfo.InvariantCulture));
            return _winstreakRemainFactor;
        }
    }

    public float WildComboRemainFactor
    {
        get
        {
            if (!_wildComboRemainFactor.HasValue)
                _wildComboRemainFactor = Convert.ToSingle(ValueConfig[Constants.ValueConfigKey.WildComboRemainFactor]);
            return _wildComboRemainFactor.Value;
        }
    }

    public float WildFreeRemainFactor
    {
        get
        {
            if (!_wildFreeRemainFactor.HasValue)
                _wildFreeRemainFactor = Convert.ToSingle(ValueConfig[Constants.ValueConfigKey.WildFreeRemainFactor]);
            return _wildFreeRemainFactor.Value;
        }
    }

    public float WildBuyRemainFactor
    {
        get
        {
            if (!_wildBuyRemainFactor.HasValue)
                _wildBuyRemainFactor = Convert.ToSingle(ValueConfig[Constants.ValueConfigKey.WildBuyRemainFactor]);
            return _wildBuyRemainFactor.Value;
        }
    }

    public int InterAdOpenlv
    {
        get
        {
            if (!_interAdOpenlv.HasValue)
                _interAdOpenlv = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.InterAdOpenlv]);
            return _interAdOpenlv.Value;
        }
    }

    public int InterAdCooldown
    {
        get
        {
            if (!_interAdCooldown.HasValue)
                _interAdCooldown = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.InterAdCooldown]);
            return _interAdCooldown.Value;
        }
    }

    public int InterAdCooldownPayinguser
    {
        get
        {
            if (!_interAdCooldownPayinguser.HasValue)
                _interAdCooldownPayinguser = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.InterAdCooldownPayinguser]);
            return _interAdCooldownPayinguser.Value;
        }
    }

    public int FailSameLevelShowRookie
    {
        get
        {
            if (!_failSameLevelShowRookie.HasValue)
                _failSameLevelShowRookie = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.FailSameLevelShowRookie]);
            return _failSameLevelShowRookie.Value;
        }
    }

    public List<int[]> BuyCardGuar
    {
        get
        {
            if (_buyCardGuar == null)
            {
                _buyCardGuar = new List<int[]>();
                string str = ValueConfig[Constants.ValueConfigKey.BuyCardGuar];
                string[] propArray = str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                foreach (var propInfo in propArray)
                {
                    string[] rewardParam = propInfo.Split(GameUtils.FirstSeparator);
                    _buyCardGuar.Add(Array.ConvertAll(rewardParam, int.Parse));
                }
            }
            return _buyCardGuar;
        }
    }

    public float[] LevelCardCoinDistribute
    {
        get
        {
            if (_levelCardCoinDistribute == null)
                _levelCardCoinDistribute = Array.ConvertAll(ValueConfig[Constants.ValueConfigKey.LevelCardCoinDistribute].Split(GameUtils.FirstSeparator), (str) => float.Parse(str, CultureInfo.InvariantCulture));
            return _levelCardCoinDistribute;
        }
    }

    public int MessageLimit
    {
        get
        {
            if (!_messageLimit.HasValue)
                _messageLimit = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.MessageLimit]);
            return _messageLimit.Value;
        }
    }

    public int ReturnTime
    {
        get
        {
            if (!_returnTime.HasValue)
                _returnTime = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.ReturnTime]);
            return _returnTime.Value;
        }
    }

    public int DailyWinTimes
    {
        get
        {
            if (!_dailyWinTimes.HasValue)
                _dailyWinTimes = Convert.ToInt32(ValueConfig[Constants.ValueConfigKey.DailyWinTimes]);
            return _dailyWinTimes.Value;
        }
    }
    public int GetUndoCost(int stageId, int undoTime)
    {
        if (undoTime <= 0) throw new Exception("GetUndoCost => parameter is invaild");
        StageModel stage = stageId > GetStageConfig.Count ? GetStageConfig[GetStageConfig.Count - 1] : GetStageConfig[stageId];
        return stage.undoCostStart + (undoTime - 1) * stage.undoCostAdd;
    }

    public int GetBuyJokerCost(int stageId, int buyTime)
    {
        if (buyTime <= 0) throw new Exception("GetBuyJokerCost => parameter is invaild");
        StageModel stage = stageId > GetStageConfig.Count ? GetStageConfig[GetStageConfig.Count - 1] : GetStageConfig[stageId];
        return stage.jokerCostStart + (buyTime - 1) * stage.jokerCostAdd;
    }

    public int GetBuyCardCost(int stageId, int buyTime)
    {
        if (buyTime <= 0) throw new Exception("GetBuyCardCost => parameter is invaild");
        StageModel stage = stageId > GetStageConfig.Count ? GetStageConfig[GetStageConfig.Count - 1] : GetStageConfig[stageId];
        return stage.fillCostStart + (buyTime - 1) * stage.fillCostAdd;
    }

    public string GetGrid(int propId)
    {
        if (ItemConfig.TryGetValue(propId, out ItemModel model1)) return model1.grid;
        if (MergeItemConfig.TryGetValue(propId, out MergeItemConfig model2)) return model2.grid;
        return "";
    }

    public int GetComboReward(int stageId, int comboNum)
    {
        if (comboNum == 0)
            return 0;
        StageModel stage = stageId > GetStageConfig.Count ? GetStageConfig[GetStageConfig.Count - 1] : GetStageConfig[stageId];
        return stage.comboStart + (comboNum - 1) * stage.comboAdd;
    }

    public int GetStageCost(int stageId)
    {
        if (!GetStageConfig.ContainsKey(stageId))
            return GetStageConfig.Last().Value.stageCost;
        return GetStageConfig[stageId].stageCost;
    }
    
    public int GetStageHard(int stageId)
    {
        if (!GetStageConfig.ContainsKey(stageId))
            return GetStageConfig.Last().Value.hard;
        return GetStageConfig[stageId].hard;
    }

    public Dictionary<int, int> GetResultReward(int stageId)
    {
        if (!GetStageConfig.ContainsKey(stageId))
        {
            Dictionary<int, int> dic = GameUtils.AnalysisPropString(GetStageConfig.Last().Value.reward);
            return dic;
        }
        else
        {
            Dictionary<int, int> dic = GameUtils.AnalysisPropString(GetStageConfig[stageId].reward);
            return dic;
        }
    }

    public int GetRemainReward(int stageId, int remainIndex)
    {
        if (remainIndex <= 0) throw new Exception("GetRemainReward => parameter is invaild");
        if(!GetStageConfig.ContainsKey(stageId))
            stageId = GetStageConfig.Last().Key;
        StageModel stage = GetStageConfig[stageId];
        return stage.remainStart + (remainIndex - 1) * stage.remainAdd;
    }

    public string GetLevelJsonName(int stageId)
    {
        if (!GetStageConfig.ContainsKey(stageId)) throw new Exception("GetLevelJsonName => parameter is invaild");
        return GetStageConfig[stageId].json;
    }

    public System.Tuple<int, int> GenHandCardMaxGuar(int stageId)
    {
        if(!GetStageConfig.ContainsKey(stageId))
            stageId = GetStageConfig.Last().Key;
        StageModel stage = GetStageConfig[stageId];
        string[] array = stage.handCardGuar.Split(GameUtils.FirstSeparator);
        if (array.Length == 2)
            return new System.Tuple<int, int>(Convert.ToInt32(array[0]), Convert.ToInt32(array[1]));
        return new System.Tuple<int, int>(-1, -1);
    }

    public int[] GenComboStep(int stageId)
    {
        if(!GetStageConfig.ContainsKey(stageId))
            stageId = GetStageConfig.Last().Key;
        StageModel stage = GetStageConfig[stageId];
        var comboStep = stage.comboStep;
        if (string.IsNullOrEmpty(stage.comboStep))
            comboStep = $"{int.MaxValue}";
        int[] array = Array.ConvertAll(comboStep.Split(GameUtils.FirstSeparator), (str) => int.Parse(str, CultureInfo.InvariantCulture));
        return array;
    }

    public int GetInterAdInterval()
    {
        var interval = InterAdCooldown;
        var dataService = MainContainer.Container.Resolve<IDataService>();
        if (dataService.CumulativeRechargeAmount > 0)
            interval = InterAdCooldownPayinguser;
        return interval;
    }

    public Dictionary<int, int> GetLavaReward()
    {
        Dictionary<int, int> reward = new Dictionary<int, int>();
        foreach (var model in LavaPassConfig)
        {
            if (model.Value.reward != "")
            {
                reward = GameUtils.AnalysisPropString(model.Value.reward);
                break;
            }
        }
        return reward;
    }

    public FarmingModel GetFarmingModel(int mapId, int themeId, int landId)
    {
        // var configService = MainContainer.Container.Resolve<IConfigService>();
        // foreach (var item in configService.FarmingConfig)
        // {
        //     if (item.Value.mapId == mapId && item.Value.themeId == themeId && item.Value.landId == landId)
        //     {
        //         return item.Value;
        //         break;
        //     }
        // }
        return null;
    }

    public float GetWinStreakIdx(int winCount, out int stepIdx)
    {
        stepIdx = Math.Min(winCount, 5);
        return stepIdx / 5f;
    }
    public string[] GetWinStreakRewardCards(int stageId, int winStreakIdx)
    {
        string[] rewards = null;
        if (GetStageConfig.ContainsKey(stageId) && winStreakIdx > 0 &&
            GetStageConfig.TryGetValue(stageId, out var stageCnf) && stageCnf.WinStreakReward.Count > 0)
        {
            var max = Math.Min(winStreakIdx, stageCnf.WinStreakReward.Count) - 1;
            rewards = stageCnf.WinStreakReward[max].ToArray();
        }
        return rewards;
    }

    public int GetCoinFlyCount(long coinNum)
    {
        if (_coinFlyCountList == null)
        {
            string[] strArray = ValueConfig[Constants.ValueConfigKey.CoinFlyCountList].Split(GameUtils.FirstSeparator);
            _coinFlyCountList = new List<int>(strArray.Length);
            foreach (var str in strArray)
                _coinFlyCountList.Add(Convert.ToInt32(str));
        }
        int count = _coinFlyCountList.FindIndex(x => x >= coinNum);
        if (count < 0) return _coinFlyCountList.Count;
        return count;
    }

    public Dictionary<int, int> GetBubbleReward(int bubbleCount,MergeLevelBoxConfig model)
    {
        Dictionary<int, int> rewards = new Dictionary<int, int>();
        for (int i = 0; i < bubbleCount; i++)
        {
            foreach (var pair in GameUtils.AnalysisBubblePropString(model.rewards))
            {
                if (rewards.ContainsKey(pair.Key))
                {
                    rewards[pair.Key] += pair.Value;
                }
                else
                {
                    rewards.Add(pair.Key,pair.Value);
                }
            }
        }
        return rewards;
    }

    Dictionary<int, CardRemainModel> cardRemainConfigType1;
    Dictionary<int, CardRemainModel> cardRemainConfigType2;
    public Dictionary<int, CardRemainModel> GetCardRemainConfigType1()
    {
        if (cardRemainConfigType1 != null) return cardRemainConfigType1;
        cardRemainConfigType1 = CardRemainConfig.Where(x => x.Value.useType == 1).ToDictionary(x => x.Key, y => y.Value);
        return cardRemainConfigType1;
    }
    public Dictionary<int, CardRemainModel> GetCardRemainConfigType2()
    {
        if (cardRemainConfigType2 != null) return cardRemainConfigType2;
        cardRemainConfigType2 = CardRemainConfig.Where(x => x.Value.useType == 2).ToDictionary(x => x.Key, y => y.Value);
        return cardRemainConfigType2;
    }

    public ComboRewardModel GetComboItemReward(int level, int step)
    {
        StageModel stage = GetStageConfig[level];
        int[] stepArray;
        if (string.IsNullOrEmpty(stage.comboStep))
            stepArray = new int[] { };
        else
            stepArray = Array.ConvertAll(stage.comboStep.Split(GameUtils.FirstSeparator), int.Parse);

        if (!string.IsNullOrEmpty(stage.comboForceReward))
        {
            string[] tempArray = stage.comboForceReward.Split(GameUtils.SecondSeparator);
            if (step >= tempArray.Length)
                step = tempArray.Length - 1;
            int[] temp = Array.ConvertAll(tempArray[step].Split(GameUtils.FirstSeparator), int.Parse);
            return new ComboRewardModel()
            {
                rewardType = temp[0],
                rewardNum = temp[1]
            };
        }
        return null;
    }

    public Tuple<CardType, ModifierType> GetQuestionCard()
    {
        var str = ValueConfig[Constants.ValueConfigKey.QuestionCard];
        string[] tempArray = str.Split(";");
        List<Tuple<CardType, int>> list = new List<Tuple<CardType, int>>();
        int total = 0;
        foreach (var item in tempArray)
        {
            string[] temp = item.Split(",");
            int weight = Convert.ToInt32(temp[1]);
            total += weight;
        }
        float value = GameUtils.RandomRange(0f, 1f) * total;
        total = 0;
        Tuple<CardType, ModifierType> target = new Tuple<CardType, ModifierType>(CardType.Value, ModifierType.None);
        foreach (var item in tempArray)
        {
            string[] temp = item.Split(",");
            string typeStr = temp[0];
            int weight = Convert.ToInt32(temp[1]);
            total += weight;
            if (value < total)
            {
                if (Constants.String2CardTypeDic.TryGetValue(typeStr, out CardType ct))
                {
                    target = new Tuple<CardType, ModifierType>(ct, ModifierType.None);
                }
                else if (Constants.String2ModTypeDic.TryGetValue(typeStr, out ModifierType mt))
                {
                    target = new Tuple<CardType, ModifierType>(CardType.Value, mt);
                }
                break;
            }
        }

        return target;
    }

    public string GetItemName(int itemId)
    {
        if (!MergeItemConfig.ContainsKey(itemId))
        {
            return ItemConfig[itemId].name;
        }
        else
        {
            return MergeItemConfig[itemId].name;
        }
    }

    public MergeItemType GetMergeItemEndType(int itemId)
    {
        MergeItemType _type = (MergeItemType)MergeItemConfig[itemId].itemType;
        var maxLvItemId = MergeItemConfig[itemId].nextItemId;
        while (maxLvItemId != -1)
        {
            _type = (MergeItemType)MergeItemConfig[maxLvItemId].itemType;
            maxLvItemId = MergeItemConfig[maxLvItemId].nextItemId;
        }
        return _type;
    }
}
