﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using SoliUtils;
using Object = UnityEngine.Object;
#if UNITY_WEBGL
using WeChatWASM;
#endif

public interface IStorageService
{
    T LoadResource<T>(string path) where T : Object;
    void LoadResource<T>(string path, Action<T> callback) where T : Object;
    object LoadJsonResource(string filepath, Type type);
    Sprite LoadPropSprite(int propEnum);

    string LevelJsonDownloadPath(string url);
    bool ResourceFileExists(string path);

    T[] ArrayFromJsonFile<T>(string filepath);
    T Load<T>(string key, T value) where T : class;
    bool KeyExists(string key);

    void Save<T>(string key, T value);
    void SaveWithoutCache<T>(string key, T value);
    void SaveData();

    string GetUserDataPath();
    bool FolderExists(string folder);
    void MkFolder(string folder);
    bool FileExists(string folder);
}

public class StorageService : IStorageService
{
    public T LoadResource<T>(string path) where T : Object
    {
        return GlobalRes.Load<T>(path);
    }

    public void LoadResource<T>(string path, Action<T> callback) where T : Object
    {
        GlobalRes.LoadAsset(path, callback);
    }

    public object LoadJsonResource(string filepath, Type type)
    {
        var targetFile = Resources.Load<TextAsset>(filepath.Replace(".json", ""));
        return targetFile == null ? null : JsonUtility.FromJson(targetFile.text, type);
    }

    public Sprite LoadPropSprite(int propEnum)
    {
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        string icon = configService.ItemConfig[(int)propEnum].icon;
//        return LoadResource<Sprite>($"Textures/Prop/{icon}");
        return SpriteUtils.LoadSpriteByAtlas(Constants.AtlasNamePath.PropsAtlas, icon);
    }

    public T[] ArrayFromJsonFile<T>(string filepath)
    {
        var targetFile = Resources.Load<TextAsset>(filepath.Replace(".json", ""));
        return targetFile == null ? null : JsonUtils.ArrayFromJson<T>(targetFile.text);
    }

    public string LevelJsonDownloadPath(string url)
    {
        string dataPath = GetUserDataPath();
        string path = Path.Combine(dataPath, "Level");
        if (!FolderExists(path))
            MkFolder(path);
        return Path.Combine(path, url + ".json");
    }

    public string GetUserDataPath()
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        return WX.env.USER_DATA_PATH;
#else
        return Application.persistentDataPath;
#endif
    }

    public bool FolderExists(string folder)
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        WXFileSystemManager fs = WX.GetFileSystemManager();
        return fs.AccessSync(folder).Equals("access:ok");
#else
        return Directory.Exists(folder);
#endif
    }

    public void MkFolder(string folder)
    {
        if (FolderExists(folder))
            return;
        
#if UNITY_WEBGL && !UNITY_EDITOR
        WXFileSystemManager fs = WX.GetFileSystemManager();
        fs.MkdirSync(folder, true);
#else
        Directory.CreateDirectory(folder);
#endif
    }

    public bool FileExists(string path)
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        WXFileSystemManager fs = WX.GetFileSystemManager();
        return fs.AccessSync(path).Equals("access:ok");
#else
        return File.Exists(path);
#endif
    }

    public bool ResourceFileExists(string path)
    {
        var targetFile = Resources.Load(path);
        return targetFile != null;
    }

    private Dictionary<string, object> mData = new Dictionary<string, object>();

    public T Load<T>(string key, T defaultValue) where T : class
    {
        if (mData.TryGetValue(key, out var value))
        {
            return value as T;
        }

        string valueStr;
        if (PlayerPrefs.HasKey(key))
        {
            valueStr = PlayerPrefs.GetString(key, null);
        }
        else
        {
            return defaultValue;
        }

        object convertedValue = null;
        Type t = defaultValue.GetType();
        try
        {
            if (t == typeof(string))
            {
                convertedValue = valueStr;
            }
            else if (t == typeof(bool))
            {
                convertedValue = Convert.ToBoolean(valueStr);
            }
            else if (t == typeof(int))
            {
                convertedValue = Convert.ToInt32(valueStr);
            }
            else if (t == typeof(long))
            {
                convertedValue = Convert.ToInt64(valueStr);
            }
            else if (t == typeof(float))
            {
                convertedValue = Convert.ToSingle(valueStr);
            }
            else
            {
                Debug.LogError($"StorageService.Load1 key={key} {t}");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"StorageService.Load2 key={key} {t} {valueStr} {defaultValue}, Exception:{e}");
            return defaultValue;
        }

        if (convertedValue != null)
        {
            mData[key] = convertedValue;
            return convertedValue as T;
        }

        return defaultValue;
    }

    public bool KeyExists(string key)
    {
        return mData.ContainsKey(key) || PlayerPrefs.HasKey(key);
    }

    public void Save<T>(string key, T value)
    {
        mData[key] = value;
        // PlayerPrefs.SetString(key, value.ToString());
    }

    public void SaveWithoutCache<T>(string key, T value)
    {
        Debug.LogError("StorageService SaveWithoutCache");
        //TODO PlayerPrefs在WEB端的存储上限是1M, 这个方法得修改, 目前配置未做更新，先不处理
        PlayerPrefs.SetString(key, value.ToString());
    }

    public void SaveData()
    {
        foreach (var data in mData)
        {
            PlayerPrefs.SetString(data.Key, data.Value.ToString());
        }
    }
}