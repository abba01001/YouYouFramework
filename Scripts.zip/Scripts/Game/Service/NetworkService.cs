using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using SoliUtils;

public delegate void OnDownloadProgressDelegate(string url, long downloaded, long downloadLength);

public delegate void OnResponseDelegate(byte[] response, int statusCode, bool isSuccess, string url);

public interface INetworkService
{
    void Get(string url, OnResponseDelegate callback);

    void Post(string url, Dictionary<string, string> requestParams, OnResponseDelegate callback);

    void Download(string url, string destFilePath, OnResponseDelegate callback);

    void DownloadAsset(string url, string destFilePath, long version, OnResponseDelegate callback,
        OnDownloadProgressDelegate onProgress);
}

public class NetworkService : INetworkService
{
    private static int connectTimeout = 6, requestTimeout = 6; //unit second

    //只有get请求需要合并，post请求不需要也不能合并
    private Dictionary<string, List<OnResponseDelegate>> urlToCallbackDict =
        new Dictionary<string, List<OnResponseDelegate>>();

    private Dictionary<string, List<OnDownloadProgressDelegate>> urlToOnProgressDict =
        new Dictionary<string, List<OnDownloadProgressDelegate>>();

    public NetworkService()
    {
    }

    private void UpdateDownloadProgress(string url, long downloaded, long length)
    {
    }


    public void Get(string url, OnResponseDelegate callback)
    {
    }

    public void Post(string url, Dictionary<string, string> requestParams, OnResponseDelegate callback)
    {
    }

    public void Download(string url, string destFilePath, OnResponseDelegate callback)
    {
        DownloadAsset(url, destFilePath, 0, callback, null);
    }

    public void DownloadAsset(string url, string destFilePath, long version, OnResponseDelegate callback,
        OnDownloadProgressDelegate onProgress)
    {

    }
}