public interface IController
{
    BattleController BattleCtrl {get; set;}
}