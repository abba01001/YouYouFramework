using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

[System.Serializable]
public class LevelModel
{
    public CardModel[] cards;
    public SettingsModel settings;
    public LockModel[] locks;

    public LevelModel DeepCopy()
    {
        // BinaryFormatter bFormatter = new BinaryFormatter();
        // MemoryStream stream = new MemoryStream();
        // bFormatter.Serialize(stream, this);
        // stream.Seek(0, SeekOrigin.Begin);
        // return (LevelModel)bFormatter.Deserialize(stream);
        LevelModel lm = new LevelModel();

        var cms = new List<CardModel>();
        for (int i = 0; i < this.cards.Length; i++)
        {
            cms.Add(this.cards[i].DeepCopy());
        }
        lm.cards = cms.ToArray();
        lm.settings = this.settings.DeepCopy();

        return lm;
    }
}
