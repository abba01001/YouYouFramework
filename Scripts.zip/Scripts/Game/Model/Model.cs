using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;
using SoliUtils;

public interface IRandomWight
{
    int GetWight();
}

[Serializable]
public class AssetLastUpdateModel
{
    public long asset_last_update;
}

[Serializable]
public class AssetItemModel
{
    public string path;
    public long version;
}

[Serializable]
public class AssetItemVersionModel
{
    public AssetItemModel item;
    public long local_version = -1;
    public long patch_version = -1;
    public long remote_version = -1;
}

[Serializable]
public class AssetConfigModel
{
    public long vers;
    public long lastupdate;
    public AssetItemModel[] items;
}

[Serializable]
public class ValueConfigModel
{
    public string id;
    public string value;
}

[Serializable]
public class CollectFlowerConfigModel
{
    public int id;

    public int level;
    public int node;
    public int robotFlowerFloor;
    public int robotFlowerCeil;
    public int entryBet;
    public int flowerBet;
    public int comboCount;
    public int flowerCount;
    public string reward;
}

[Serializable]
public class RobotConfigModel
{
    public string id;
    public string name;
    public RobotConfigModel(RobotConfigModel mod = null)
    {
        if (mod != null)
        {
            id = mod.id;
            name = mod.name;
        }
    }
}


[Serializable]
public class BetModel
{
    public int id;
    public int bet;
    public int levelRequest;
    public long coinRequest;
    public float moneyRequest;
    public string showTextKey;
}


[Serializable]
public class StageModel
{
    public int id;
    public string json;
    public int hard;
    public int stageCost;
    public int comboStart;
    public int comboAdd;
    public int remainStart;
    public int remainAdd;
    public int undoCostStart;
    public int undoCostAdd;
    public int fillCostStart;
    public int fillCostAdd;
    public int jokerCostStart;
    public int jokerCostAdd;
    public string handCardGuar;
    public string reward;

    public int winCoin;
    public int comboType;
    public string comboStep;
    public string comboForceReward;
    public string itemList;
    public int starIntegralRatioControl;

    private List<int> __itemList = new List<int>();
    public List<int> ItemList
    {
        get
        {
            if (string.IsNullOrWhiteSpace(itemList))
                return __itemList;
            if (__itemList.Count == 0)
            {
                var temp = Array.ConvertAll(itemList.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
                __itemList.AddRange(temp);
            }
            return __itemList;
        }
    }

    public string winStreakReward;
    private List<List<string>> __winStreakRewardList = new List<List<string>>();
    public List<List<string>> WinStreakReward
    {
        get
        {
            if (string.IsNullOrWhiteSpace(winStreakReward))
                return __winStreakRewardList;
            if (__winStreakRewardList.Count == 0)
            {
                var temps = winStreakReward.Split(';');
                for (int i = 0; i < temps.Length; i++)
                {
                    var temp = Array.ConvertAll(temps[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), (value) => { return value; });
                    __winStreakRewardList.Add(temp.ToList());
                }
            }
            return __winStreakRewardList;
        }
    }

    public string starIntegralRatio;
    private Dictionary<int, int> starIntegralRatioDic = new Dictionary<int, int>();
    public Dictionary<int, int> StarIntegralRatio
    {
        get
        {
            if (starIntegralRatioDic.Count == 0)
            {
                Dictionary<int, int> result = new Dictionary<int, int>();
                string[] propArray = starIntegralRatio.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                foreach (var propInfo in propArray)
                {
                    string[] rewardParam = propInfo.Split(GameUtils.FirstSeparator);
                    int index = int.Parse(rewardParam[0]);
                    int count = int.Parse(rewardParam[1]);

                    if (starIntegralRatioDic.ContainsKey(index))
                        starIntegralRatioDic[index] += count;
                    else
                        starIntegralRatioDic.Add(index, count);
                }
            }
            return starIntegralRatioDic;
        }
    }

    public string rewardrate;
    private Dictionary<int, float> rewardrateDic = new Dictionary<int, float>();
    public Dictionary<int, float> RewardRate
    {
        get
        {
            if (rewardrateDic.Count == 0)
            {
                Dictionary<int, float> result = new Dictionary<int, float>();
                string[] propArray = rewardrate.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
                foreach (var propInfo in propArray)
                {
                    string[] rewardParam = propInfo.Split(GameUtils.FirstSeparator);
                    int index = int.Parse(rewardParam[0]);
                    float count = float.Parse(rewardParam[1]);

                    if (rewardrateDic.ContainsKey(index))
                        rewardrateDic[index] += count;
                    else
                        rewardrateDic.Add(index, count);
                }
            }
            return rewardrateDic;
        }
    }

}

// [Serializable]
// public class HandleModel
// {
//     public int level;
//     public float linkRate;
//     public float comboRate;
//     public float linkRate2;
//     public float comboRate2;

//     public int dynamicControl;
//     public int win_ManyStack;
//     public int win_ZeroStack;
//     public int end_OneDesktop;
//     public int end_TwoDesktop;
//     public int end_ManyDesktop;
// }

[Serializable]
public class CardRemainModel : IRandomWight
{
    public int id;
    public int remainNum;
    public int weight;
    public int useType;

    public int GetWight() => weight;
}

[Serializable]
public class StarStageBaseModel
{
    public int id;
    public int starRequest;
    public string flowerNameKey;
    public string flowerDesKey;
    public string nowBigIcon;
    public string nowIcon;
    public string nextIcon;
    public string nowHomeBG;
    public string nowGameBG;
    public string finishedReward;
    public string midRewardCondition;
    public string midReward;
}


[Serializable]
public class SignInModel
{
    public int grid;
    public string reward;
    public float weight;
}

[Serializable]
public class WheelModel : IRandomWight
{
    public int id;
    public int wight;
    public int levelRequest;
    public string reward;

    public int GetWight()
    {
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        if (dataService.MaxLevel < levelRequest) return 0;
        return wight;
    }
}

[Serializable]
public class EmailInfoModel
{
    public string mid;
    public string time;
    public string title;
    public string content;
    public string rewards;
    public int read;
    public int receive;
}


[Serializable]
public class ShopModel
{
    public string product_id;
    public int money;
    public int game_gold;
    public string product_name;
    public string product_desc;
    public string reward;
    public string rewardFree;
    public string daily_reward;

    public int extea;
    public int Quality;
    public int shopShow;
    public int discount;
    public string showPrice;
    public string pre_product;
    public float price;
    public string showPriceBr;
    public float priceBr;
    public int priority;
    public int duaration;
    public string Description;
    public int unlock;
    public int product_type;

    public string PushConditions;
    public int[] _pushConditions;
    public int[] PushConditionDict
    {
        get
        {
            if (string.IsNullOrEmpty(PushConditions)) return null;
            if (_pushConditions == null)
            {
                _pushConditions = Array.ConvertAll(PushConditions.Split(GameUtils.FirstSeparator), (str) => int.Parse(str, CultureInfo.InvariantCulture));
            }
            return _pushConditions;
        }
    }


    public string charge_range;
    private float[] _chargeRange;
    public float[] ChargeRange
    {
        get
        {
            if (string.IsNullOrEmpty(charge_range)) return null;
            if (_chargeRange == null)
                _chargeRange = Array.ConvertAll(charge_range.Split(GameUtils.FirstSeparator), (str) => float.Parse(str, CultureInfo.InvariantCulture));
            return _chargeRange;
        }
    }

    public string GetShowPrice()
    {
        if (DeviceUtils.GetRegionCode() == "BR")
            return showPriceBr;
        else
            return showPrice;
    }

    public float GetReportPrice()
    {
        if (DeviceUtils.GetRegionCode() == "BR")
            return priceBr;
        else
            return price;
    }
}

[Serializable]
public class ComboRewardModel : IRandomWight
{
    public int id;
    public int wight;
    public int rewardType;
    public int rewardNum;

    public int GetWight()
    {
        if (!GameController.Instance.IsPlaying) return 0;
        if (rewardType == 3)
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            return configService.GetBuyJokerCost(GameController.Instance.BattleCtrl.BattleLevel, 1) > 0 ? wight : 0;
        }
        return wight;
    }
}

[Serializable]
public class ItemModel
{
    public int id;
    public int type;
    public string name;
    public string desc;
    public string icon;
    public float beishu;
    public int special;
    public string grid;
}

[Serializable]
public class PowerItemModel
{
    public int id;
    public int bundle;
    public int relateItem;
    public int unlockLevel;
    public int unlockReward;
    public float experienceValueFactor;
    public string price;
    public int Price
    {
        get
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            int coin = 0;
            Dictionary<int, int> reward = GameUtils.AnalysisPropString(price);
            foreach (var pair in reward)
            {
                coin = pair.Value;
            }
            return coin * dataService.NowBet;
        }
    }
}


[Serializable]
public class RookieBaseModel
{
    public int id;
    public int pre_rookie;
    public int rookie_type;
    public int sub_id;
    public float repeat;
    public string trigger_level;
    public string trigger_param;
    public string complete_action;
}

[Serializable]
public class RookieModel
{
    public enum RookieType
    {
        Click = 1,
        Dialogue = 2,
        Drag = 3,
        Anim = 4,
    }
    public int id;
    public int pre_rookie;
    public RookieType rookieType;
    public int sub_id;
    public float repeat;
    public System.Tuple<int, int> triggerLevel;
    public Dictionary<string, int> triggerParam;
    public string complete_action;


    public RookieModel(RookieBaseModel mod)
    {
        id = mod.id;
        rookieType = (RookieType)(mod.rookie_type);
        pre_rookie = mod.pre_rookie;
        sub_id = mod.sub_id;
        repeat = mod.repeat;
        if (!string.IsNullOrEmpty(mod.trigger_level))
        {
            var lvRange = mod.trigger_level.Split(GameUtils.FirstSeparator);
            triggerLevel = new System.Tuple<int, int>(Convert.ToInt32(lvRange[0]), Convert.ToInt32(lvRange[1]));
        }
        
        
        if (!string.IsNullOrEmpty(mod.trigger_param))
        {
            triggerParam = new Dictionary<string, int>();
            string[] items = mod.trigger_param.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            foreach (var item in items)
            {
                string[] param = item.Split(GameUtils.FirstSeparator);
                if (param.Length < 2)
                {
                    triggerParam.Add(param[0], 1);
                }
                else
                {
                    triggerParam.Add(param[0], int.Parse(param[1]));
                }
                
            }
        }
        complete_action = mod.complete_action;
    }

}

[Serializable]
public class RookieClickBaseModel
{
    public int id;
    public int scene;
    public string nodyName;
    public string widgetName;
    public string pams;
    public int force;
    public float touchMaskTime;
    public string tipTranslateKey;
    public int view_size;
    public int arrow_pos;
}

[Serializable]
public class RookieClickModel
{
    public enum TriggerScene
    {
        Battle = 0,
        View,
        Popue
    }
    public int id;
    public TriggerScene scene;
    public string nodyName;
    public string widgetName;
    public string[] pams;
    public bool force;
    public float touchMaskTime;
    public string tipTranslateKey;
    public int view_size;
    public int arrow_pos;

    public RookieClickModel(RookieClickBaseModel mod)
    {
        id = mod.id;
        scene = (TriggerScene)(mod.scene);
        nodyName = mod.nodyName;
        widgetName = mod.widgetName;
        force = mod.force == 1;
        touchMaskTime = mod.touchMaskTime;
        pams = mod.pams.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
        tipTranslateKey = mod.tipTranslateKey;
        view_size = mod.view_size;
        arrow_pos = mod.arrow_pos;
    }
}

[Serializable]
public class RookieDialogueModel
{
    public int id;
    public int position;
    public int item_id;
    public string text;
}

[Serializable]
public class RookieDialogueDicModel
{
    public int mainId;
    public Dictionary<int, RookieDialogueModel> dic;
    public RookieDialogueDicModel(int mainId)
    {
        this.mainId = mainId;
        dic = new Dictionary<int, RookieDialogueModel>();
    }

    public void Add(int stepId, RookieDialogueModel dialogueModel)
    {
        dic.Add(stepId, dialogueModel);
    }
}

[Serializable]
public class RookieDragModelBase
{
    public int id;
    public string pams;
    public int start_id;
    public string end_id;
    public int item_id;
    public string text;
}
[Serializable]
public class RookieDragModel
{
    public RookieDragModel(RookieDragModelBase mod)
    {
        id = mod.id;
        pams = mod.pams;
        start_id = mod.start_id;
        item_id = mod.item_id;
        text = mod.text;
        string[] ids = mod.end_id.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
        end_ids = new List<int>();
        for (int i=0;i< ids.Length; i++)
        {
            end_ids.Add(int.Parse(ids[i]));
        }
    }
    public int id;
    public string pams;
    public int start_id;
    public List<int> end_ids;
    public int item_id;
    public string text;
}

[Serializable]
public class RookieAnimModel
{
    public int id;
    public string prefab;
    public string animation;
    public int loop_count;
}


[Serializable]
public class ActivityModel // 活动通用 model
{
    public int id;
    public int activityId;
    public string activity_chargeId;
    public string activityBg;
    public string rewardList;
    public string extend_icon1;
}

[Serializable]
public class PassRankReward
{
    public string level;
    public string collectCount;
    public List<SeasonLvRewardItem> rewardList;
}


[Serializable]
public class SeasonRewardModel // 赛季奖励 model
{
    public int id;
    public int activityId;
    public int activityLv;
    public int exp;
    public string freeReward;
    public string goldReward;
    public SeasonLvReward freeLvReward;
    public SeasonLvReward goldLvReward;

    public SeasonRewardModel Parse()
    {
        freeLvReward = JsonUtility.FromJson<SeasonLvReward>(freeReward);
        goldLvReward = JsonUtility.FromJson<SeasonLvReward>(goldReward);
        return this;
    }
}

[Serializable]
public class SeasonLvReward
{
    public string icon;
    public List<SeasonLvRewardItem> rewardList;
}

[Serializable]
public class SeasonLvRewardItem
{
    public int type; // 1 -> 金币 2 -> 免费回退 3 -> 万能牌(鬼牌) 4 -> +5道具(局内手牌数+5) 5 -> 免费入场券
    public int amount;
}

[Serializable]
public class ActivitiesSwitchModel // 活动开关
{
    public int id;
    public string name;
    public string type;
    public string desc;
    public int unlockLevel;
    public int duration;
    public int ActivityNumberUpper;
    public int subActivityType = 0;
    public string naturalOpenTime;
    public bool inOpenTime;
    public int openInterval;
    public string RewardTitle;
    public int needUserOpen;
    public string olderOpenTime;
    public List<List<int>> OlderOpenTime { private set; get; }
    public List<List<int>> NaturalTimeList { private set; get; }
    public string param;
    public int isOpen; // 0:关闭 1:开启
    public ActivityType acType { private set; get; }
    public List<int> weekList { set; get; }

    public ActivitiesSwitchModel Parse()
    {
        acType = ActivityType.none;
        if (Enum.TryParse(type, out ActivityType _type))
        {
            acType = _type;
        }
        OlderOpenTime = ParseNormalTimeFormat(olderOpenTime);
        NaturalTimeList = ParseNaturalTimeFormat(naturalOpenTime);
        return this;
    }

    public List<List<int>> ParseNaturalTimeFormat(string str)
    {
        List<List<int>> result = new List<List<int>>();
        if (string.IsNullOrEmpty(str) || string.IsNullOrWhiteSpace(str)) return result;
        string[] tempStr = str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);

        for (int i = 0; i < tempStr.Length; i++)
        {
            string[] parts = tempStr[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
            List<int> list = new List<int>();
            for (int j = 0; j < parts.Length; j++)
            {
                if (j == 0 || j == 1)
                {
                    list.Add(int.Parse(parts[j]));
                }
                else
                {
                    string date = parts[j].Replace("\"", string.Empty);
                    if (DateTime.TryParseExact(date, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dateTime))
                    {
                        list.Add(TimeUtils.DateTimeToLong(dateTime));
                    }
                    else
                    {
                        throw new FormatException($"Invalid date format: {date}--------2024-8-21 00:00:00");
                    }
                }
            }
            result.Add(list);
        }
        return result;
    }

    public List<List<int>> ParseNormalTimeFormat(string str)
    {
        List<List<int>> result = new List<List<int>>();
        string[] parts = str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        foreach (var part in parts)
        {
            string[] nums = part.Split(GameUtils.FirstSeparator);
            List<int> values = new List<int>();
            foreach (var num in nums)
            {
                string trimmedNum = num.Trim();
                values.Add(int.Parse(trimmedNum));
            }
            result.Add(values);
        }
        return result;
    }

    public List<int> GetWeekActivitieTime(int _serverTime, List<int> list)
    {
        DateTime nowDate = TimeUtils.IntToDateTime(_serverTime);
        int nowDayOfWeek = TimeUtils.GetDayOfWeek(nowDate);
        List<int> result = new List<int>
        {
            TimeUtils.DateTimeToLong(new DateTime(nowDate.Year, nowDate.Month, nowDate.Day, 0, 0, 0, DateTimeKind.Local).AddDays(list[1] - nowDayOfWeek)),
            TimeUtils.DateTimeToLong(new DateTime(nowDate.Year, nowDate.Month, nowDate.Day, 23, 59, 59, DateTimeKind.Local).AddDays(list[2] - nowDayOfWeek))
        };
        return result;
    }

    public List<int> GetBeginnerActivitieTime(List<int> list)
    {
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        DateTime registerDate = TimeUtils.IntToDateTime(dataService.RegisterTime);
        List<int> result = new List<int>
        {
            TimeUtils.DateTimeToLong(new DateTime(registerDate.Year, registerDate.Month, registerDate.Day, 0, 0, 0, DateTimeKind.Local).AddDays(list[1])),
            TimeUtils.DateTimeToLong(new DateTime(registerDate.Year, registerDate.Month, registerDate.Day, 23, 59, 59, DateTimeKind.Local).AddDays(list[2] - 1))
        };
        return result;
    }
}

[Serializable]
public class SeasonExpModel
{
    public int id;
    public int exp;
    public int IAPPush;
}

[Serializable]
public class CollectLoveCardModel
{
    public int id;
    public int layer;
    public int collectType;
    public int progress;
    public string reward;

    public Dictionary<int, int> Reward
    {
        get { return GameUtils.AnalysisPropString(reward); }
    }
}

[Serializable]
public class CollectMusicModel
{
    public int id;
    public int layer;
    public int progress;
    public string reward;
    public Dictionary<int, int> Reward
    {
        get { return GameUtils.AnalysisPropString(reward); }
    }
}

[Serializable]
public class DigTreasureRewardModel
{
    public int id;
    public int layer;
    public int mapId;
    public string reward;
}

[Serializable]
public class LevelPassModel
{
    public int id;
    public int node;
    public int levelFloor;
    public int levelCeil;
    public string reward;
}

[Serializable]
public class SeasonPassModel
{
    public int id;
    public int layer;
    public int type;
    public int progress;
    public string reward;
    public int activityid;
}

[Serializable]
public class LavaPassModel
{
    public int id;
    public int winStreak;
    public int reduceFloor;
    public int reduceCeil;
    public string reward;
}

[Serializable]
public class WheelRewardModel
{
    public int id;
    public int type;
    public string reward;
    public int weight;
    public int grid;
}

[Serializable]
public class PopupPriorityModel
{
    public string id;
    public int priority;
}

[Serializable]
public class FarmingModel
{
    public int id;
    public int mapId;
    public int themeId;
    public int landId;
    public string reward;
    public string consume;
    public int collectCount;
    public string homeBg;
    public string battleBg;
    public string mapTittle;
    public string mapSprite;
}

[Serializable]
public class UnlockModel
{
    public int id;
    public string type;
    public int unlockLevel;
    public int previewLevel;
}

[Serializable]
public class MysteriousSeedModel
{
    public int id;
    public int layer;
    public int progress;
    public string reward;
}

[Serializable]
public class CookMealModel
{
    public int id;
    public int Layer;
    public int MealType;
    public string Suit;
    public int CoinProgress;
    public string reward;
    public int GoldNum;
    public int CoinProgressNum;
    public int Weight2;
    public int Weight3;
    public string MealName;
    public Dictionary<int, List<int>> _suitInfo;
    public Dictionary<int, List<int>> SuitInfo
    {
        get
        {
            if (_suitInfo == null)
            {
                _suitInfo = new Dictionary<int, List<int>>();
                string[] strs = Suit.Split(GameUtils.SecondSeparator);

                foreach (var str in strs)
                {
                    string[] temp = str.Split(GameUtils.FirstSeparator);
                    int mat = int.Parse(temp[0]);
                    int progress = int.Parse(temp[1]);
                    int weight = int.Parse(temp[2]);
                    _suitInfo.Add(mat, new List<int>() { progress, weight });
                }
            }
            return _suitInfo;
        }
    }

    public object Clone()
    {
        var clone = (CookMealModel)MemberwiseClone();
        if (this._suitInfo != null)
        {
            clone._suitInfo = new Dictionary<int, List<int>>();
            foreach (var kvp in this._suitInfo)
            {
                clone._suitInfo[kvp.Key] = new List<int>(kvp.Value);
            }
        }
        return clone;
    }
}

[Serializable]
public class MagicNectarModel
{
    public int id;
    public int Stage;
    public int progress;
    public string reward;
}

[Serializable]
public class RainbowDropsModel
{
    public int id;
    public int Stage;
    public int progress;
    public string reward;
}

[Serializable]
public class AdRewardModel
{
    public int id;
    public int layer;
    public int progress;
    public string reward;
}


[Serializable]
public class PassRankRobotModel
{
    public int id;
    public string node;
    public string range;
    public int amount;
}

[Serializable]
public class PassRankRobotRuleModel
{
    public int id;
    public int node;
    public int amount;
    public int robotType;
    public List<int> range = new List<int>();
}

[Serializable]
public class CarRankRobotModel
{
    public int id;
    public string node;
    public string range;
    public int amount;
}

[Serializable]
public class CarRankRobotRuleModel
{
    public int id;
    public int node;
    public int amount;
    public int robotType;
    public List<int> range = new List<int>();
}

[Serializable]
public class WeightRewardModel
{
    public int PropEnum;
    public int Count;
    public int Weight;
}

[Serializable]
public class PushGiftInfo
{
    public PushGiftModel model;
    public bool CanPush = false;
    public FlagType Flag;
    public PushGiftInfo(PushGiftModel _model)
    {
        model = _model;
    }
}

[Serializable]
public class GradientModel
{
    public int id;
    public int Price;
    public int IsFree;
    public string reward;
    public string product_id;
    public int collectLayer;
    public int collectProgress;
    public string collectReward;
}

[Serializable]
public class PassRankRewardModel
{
    public int id;
    public string Reward;
    public int UpperRank;
    public int LowerRank;
}

[Serializable]
public class CarRankRewardModel
{
    public int id;
    public string Reward;
    public int UpperRank;
    public int LowerRank;
}

[Serializable]
public class EndlessLevelRewardModel
{
    public int id;
    public string enterTime;
    public int Rank;
    public string Reward;
}

[Serializable]
public class LimitPkModel
{
    public int id;
    public int node;
    public string range;
    public string range1;
    public string reward;

    public int[] Range()
    {
        string[] param = range.Split(GameUtils.FirstSeparator);
        int[] temp = new int[param.Length];
        temp[0] = int.Parse(param[0]);
        temp[1] = int.Parse(param[1]);
        return temp;
    }

    public int[] Range1()
    {
        string[] param = range1.Split(GameUtils.FirstSeparator);
        int[] temp = new int[param.Length];
        temp[0] = int.Parse(param[0]);
        temp[1] = int.Parse(param[1]);
        return temp;
    }
}

[Serializable]
public class PushGiftModel
{
    public int id;
    public string Para;
    public int Limit;
    public int Number;
    public int Second;
    public string Flag;
}

[Serializable]
public class SoundModel
{
    public string id;
    public string assetPath;
    public int instantRelease;
}

[Serializable]
public class CardDescModel
{
    public int id;
    public string cardType;
    public string modifierType;
    public string mainTitle;
    public string viceTitle;
    public string desc;

    public CardType CardType
    {
        get
        {
            var t = CardType.Value;
            try
            {
                t = (CardType)Enum.Parse(typeof(CardType), cardType);
            }
            catch (System.Exception)
            {
            }
            return t;
        }
    }

    public ModifierType ModType
    {
        get
        {
            var t = ModifierType.None;
            try
            {
                t = (ModifierType)Enum.Parse(typeof(ModifierType), modifierType);
            }
            catch (System.Exception)
            {
            }
            return t;
        }
    }
}


// [Serializable]
// public class ExperienceConfigModel
// {
//     public int id;
//     public int param;
//     public int win_ManyStack;
//     public int win_ZeroStack;
//     public int end_OneDesktop;
//     public int end_TwoDesktop;
//     public int end_ManyDesktop;
// }

// [Serializable]
// public class LevelResultConfigModel
// {
//     public int id;
//     public int result;
//     public int consumeItem;
//     public int paramChange;
// }

[Serializable]
public class TimingMessageConfigModel
{
    public int id;
    public int push_type;
    public int priority;
    public int order;
    public string time;
    public string act_condition;
    public int act_interval;
    public int lv_condition;
    public int noactive_condition;
    public string title;
    public string text;

    public ActivityType acType
    {
        get
        {
            var t = ActivityType.none;
            if (Enum.TryParse(act_condition, out ActivityType _type))
            {
                t = _type;
            }
            return t;
        }
    }

    public string[] pushTime
    {
        get
        {
            return time.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
        }
    }
}

[Serializable]
public class LevelConfigBase
{
    public int level;
    public string group;
    public string failResult;
}

[Serializable]
public class HandleLevelConfig : LevelConfigBase
{ }

[Serializable]
public class HandleEndlessLevelConfig : LevelConfigBase
{ }

[Serializable]
public class HandleResultConfig
{
    public int id;
    public int remainHand;
    public int remainDesktop;
    public int comboLimit;
    public string connectWeight;
    public string manyHandLinkRate;
}

[Serializable]
public class HandleLabelConfig
{
    public int id;
    public string result;
}

[Serializable]
public class HandleConsumConfig
{
    public int bet;
    public int consumRatio;
}

[Serializable]
public class HandlePaidConfig
{
    public int id;
    public int type;
    public int label;
    public int method;
    public int value;
    public int exparam;
    public int priority;
}

[Serializable]
public class DigGridRewardModel
{
    [SerializeField] private int id;
    [SerializeField] private int width;
    [SerializeField] private int height;
    [SerializeField] private int propId;
    [SerializeField] private int propCount;
    private Vector2Int pos;

    public int Id => id;
    public int Width => width;
    public int Height => height;
    public int PropId => propId;
    public int PropCount => propCount;
    public Vector2Int Pos // 如果需要，提供公共的 getter 和 setter
    {
        get => pos;
        set => pos = value;
    }
    public DigGridRewardModel(int id, int propId, int propCount, int width, int height)
    {
        this.id = id;
        this.propId = propId;
        this.width = width;
        this.height = height;
        this.propCount = propCount;
    }
}


[Serializable]
public class PosModel
{
    public int X { get; private set; }
    public int Y { get; private set; }
    public PosModel(int x, int y)
    {
        X = x;
        Y = y;
    }
}

[Serializable]
public class MergeItemConfig
{
    public int id;
    public string name;
    public int mergeItem = -1;
    public int nextItemId = -1;
    public int itemType;
    public int shape;
    public int exp;
    public int rarity;
    public int price;
    public string exparams;
    public string unlock_reward;
    public string grid;
    public string sale;
}



[Serializable]
public class MergeMapConfig
{
    public int id;
    public int cloud_id;
    public int unlock_exp;
    public int item_id;
}

[Serializable]
public class MergeRegionRewardsConfig
{
    public int id;
    public int level;
    public int exp;
    public int limit;
    public string rewards;
    public int cloud_id;
    public int build_lv;
}

[Serializable]
public class MergeOrderListConfig
{
    public int id;
    public string group;
    public int weight;
    public string item_weight;
    public string rewards;
}

[Serializable]
public class MergeBubbleModel
{
    public int id;
    public float x;
    public float y;
    public int[] items;

    public MergeBubbleModel(int id, List<int> items)
    {
        this.id = id;
        this.items = items.ToArray();
        Vector3 screenCenter = new Vector3(Screen.width / 2, Screen.height / 2, 0);
        Vector3 worldPosition = Camera.main.ScreenToWorldPoint(screenCenter);
        this.x = worldPosition.x;
        this.y = worldPosition.y;
    }
}

[Serializable]
public class MergeOrderDegreeConfig
{
    public int id;
    public int npc_id;
    public int limit;
    public int index;
    public int level;
    public string weight;
}

[Serializable]
public class MergeBuildConfig
{
    public int id;
    public int build_lv;
    public string res_list;
}

[Serializable]
public class MergeLevelBoxConfig
{
    public int id;
    public int region_id;
    public int level;
    public int number;
    public string rewards;
    public int order;
}

[Serializable]
public class MergeShopConfig
{
    public int region_id;
    public int level;
    public string normal_items;
    public string normal_weight;
    public string normal_info;
    public string normal_off;
    public string sp1_items;
    public string sp2_items;
    public string sp3_items;
    public string sp_group_weight;
    public string sp1_info;
    public string sp2_info;
    public string sp3_info;
    public string sp1_off;
    public string sp2_off;
    public string sp3_off;
    public int count;
}

[Serializable]
public class MergeShopConfigEx
{
    public int region_id;
    public int level;
    public List<Tuple<int, int>> normal_items;//初级物品id，权重
    public List<Tuple<int, int, int, List<float>>> normal_info;//等级, 限购次数，权重，折扣

    public Dictionary<int, List<Tuple<int, int>>> special_items;
    public Dictionary<int, List<Tuple<int, int, int, List<float>>>> special_info;

    public List<int> sp_group_weight;
    public int count;

    public MergeShopConfigEx(MergeShopConfig cfg)
    {
        this.region_id = cfg.region_id;
        this.level = cfg.level;

        this.normal_items = new List<Tuple<int, int>>();
        int[] norItems = Array.ConvertAll(cfg.normal_items.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
        int[] norWeights = Array.ConvertAll(cfg.normal_items.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
        for (int i = 0; i < norItems.Length; i++)
        {
            this.normal_items.Add(new Tuple<int, int>(norItems[i], norWeights[i]));
        }

        this.normal_info = new List<Tuple<int, int, int, List<float>>>();
        string[] norInfoStr = cfg.normal_info.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        string[] norOffStr = cfg.normal_off.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < norInfoStr.Length; i++)
        {
            int[] param = Array.ConvertAll(norInfoStr[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
            float[] off = Array.ConvertAll(norOffStr[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), float.Parse);
            this.normal_info.Add(new Tuple<int, int, int, List<float>>(param[0], param[1], param[2], off.ToList()));
        }

        special_items = new Dictionary<int, List<Tuple<int, int>>>();

        var sp_items = new List<Tuple<int, int>>();
        int[] spItems;
        if(!string.IsNullOrEmpty(cfg.sp1_items))
        {
            spItems = Array.ConvertAll(cfg.sp1_items.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
            for (int i = 0; i < spItems.Length; i++)
            {
                sp_items.Add(new Tuple<int, int>(spItems[i], 1));
            }
        }
        special_items.Add(0, sp_items);

        sp_items = new List<Tuple<int, int>>();
        if(!string.IsNullOrEmpty(cfg.sp2_items))
        {
            spItems = Array.ConvertAll(cfg.sp2_items.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
            for (int i = 0; i < spItems.Length; i++)
            {
                sp_items.Add(new Tuple<int, int>(spItems[i], 1));
            }
        }
        special_items.Add(1, sp_items);

        sp_items = new List<Tuple<int, int>>();
        
        if(!string.IsNullOrEmpty(cfg.sp3_items))
        {
            spItems = Array.ConvertAll(cfg.sp3_items.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
            for (int i = 0; i < spItems.Length; i++)
            {
                sp_items.Add(new Tuple<int, int>(spItems[i], 1));
            }
        }
        special_items.Add(2, sp_items);

        special_info = new Dictionary<int, List<Tuple<int, int, int, List<float>>>>();

        var sp_info = new List<Tuple<int, int, int, List<float>>>();
        string[] spInfoStr = cfg.sp1_info.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        string[] spOffStr = cfg.sp1_off.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < spInfoStr.Length; i++)
        {
            int[] param = Array.ConvertAll(spInfoStr[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
            float[] off = Array.ConvertAll(spOffStr[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), float.Parse);
            sp_info.Add(new Tuple<int, int, int, List<float>>(param[0], param[1], param[2], off.ToList()));
        }
        special_info.Add(0, sp_info);

        sp_info = new List<Tuple<int, int, int, List<float>>>();
        spInfoStr = cfg.sp2_info.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        spOffStr = cfg.sp2_off.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < spInfoStr.Length; i++)
        {
            int[] param = Array.ConvertAll(spInfoStr[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
            float[] off = Array.ConvertAll(spOffStr[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), float.Parse);
            sp_info.Add(new Tuple<int, int, int, List<float>>(param[0], param[1], param[2], off.ToList()));
        }
        special_info.Add(1, sp_info);

        sp_info = new List<Tuple<int, int, int, List<float>>>();
        spInfoStr = cfg.sp3_info.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        spOffStr = cfg.sp3_off.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < spInfoStr.Length; i++)
        {
            int[] param = Array.ConvertAll(spInfoStr[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse);
            float[] off = Array.ConvertAll(spOffStr[i].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), float.Parse);
            sp_info.Add(new Tuple<int, int, int, List<float>>(param[0], param[1], param[2], off.ToList()));
        }
        special_info.Add(2, sp_info);

        this.sp_group_weight = Array.ConvertAll(cfg.sp_group_weight.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries), int.Parse).ToList();
        this.count = cfg.count;
    }

    public Tuple<int, int, float> GetNormalItem(List<int> exItems) //物品id，限购次数，折扣
    {
        int totalWeight = 0;
        var _normal_items = new List<Tuple<int, int>>();
        foreach (var item in normal_items)
        {
            if (!exItems.Contains(item.Item1))
                _normal_items.Add(item);
        }
        if (_normal_items.Count == 0)
            return null;

        foreach (var item in _normal_items)
        {
            totalWeight += item.Item2;
        }
        float randomValue = GameUtils.RandomRange(0f, totalWeight);
        var targetItemId = _normal_items[0].Item1;
        int cumulativeWeight = 0;
        for (int i = 0; i < _normal_items.Count; i++)
        {
            cumulativeWeight += _normal_items[i].Item2;
            if (randomValue < cumulativeWeight)
            {
                targetItemId = _normal_items[i].Item1;
                break;
            }
        }

        totalWeight = 0;
        foreach (var item in normal_info)
        {
            totalWeight += item.Item3;
        }
        randomValue = GameUtils.RandomRange(0f, totalWeight);
        var targetInfo = normal_info[0];
        cumulativeWeight = 0;
        for (int i = 0; i < normal_info.Count; i++)
        {
            cumulativeWeight += normal_info[i].Item3;
            if (randomValue < cumulativeWeight)
            {
                targetInfo = normal_info[i];
                break;
            }
        }

        targetItemId = targetItemId + targetInfo.Item1 - 1;
        int randomIndex = UnityEngine.Random.Range(0, targetInfo.Item4.Count);
        float off = targetInfo.Item4[randomIndex];

        return new Tuple<int, int, float>(targetItemId, targetInfo.Item2, off);
    }

    public Tuple<int, int, float> GetSpecialItem(List<int> exItems) //物品id，限购次数，折扣
    {
        int randomGroupIndex = UnityEngine.Random.Range(0, 3);

        int totalWeight = 0;
        var _sp_items = new List<Tuple<int, int>>();
        foreach (var item in special_items[randomGroupIndex])
        {
            if (!exItems.Contains(item.Item1))
                _sp_items.Add(item);
        }
        if (_sp_items.Count == 0)
            return null;

        foreach (var item in _sp_items)
        {
            totalWeight += item.Item2;
        }
        float randomValue = GameUtils.RandomRange(0f, totalWeight);
        var targetItemId = _sp_items[0].Item1;
        int cumulativeWeight = 0;
        for (int i = 0; i < _sp_items.Count; i++)
        {
            cumulativeWeight += _sp_items[i].Item2;
            if (randomValue < cumulativeWeight)
            {
                targetItemId = _sp_items[i].Item1;
                break;
            }
        }

        totalWeight = 0;
        foreach (var item in special_info[randomGroupIndex])
        {
            totalWeight += item.Item3;
        }
        randomValue = GameUtils.RandomRange(0f, totalWeight);
        var targetInfo = special_info[randomGroupIndex][0];
        cumulativeWeight = 0;
        for (int i = 0; i < special_info[randomGroupIndex].Count; i++)
        {
            cumulativeWeight += special_info[randomGroupIndex][i].Item3;
            if (randomValue < cumulativeWeight)
            {
                targetInfo = special_info[randomGroupIndex][i];
                break;
            }
        }

        targetItemId = targetItemId + targetInfo.Item1 - 1;
        int randomIndex = UnityEngine.Random.Range(0, targetInfo.Item4.Count);
        float off = targetInfo.Item4[randomIndex];

        return new Tuple<int, int, float>(targetItemId, targetInfo.Item2, off);
    }

    public List<Tuple<int, int, float>> CreateShopInfo()
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        List<Tuple<int, int, float>> shopInfo = new List<Tuple<int, int, float>>(); //物品id，限购次数，折扣
        bool[] qualitys = { false, false, false, true, false, true, false, true, false, true };//true 稀有, false 普通
        for (int i = 0; i < count; i++)
        {
            bool quality = false;
            if (i < qualitys.Length)
            {
                quality = qualitys[i];
            }
            List<int> exItems = new List<int>();
            foreach (var item in shopInfo)
            {
                int oriItemId = item.Item1;
                while (configService.MergeItemConfig.ContainsKey(oriItemId) && configService.MergeItemConfig[oriItemId].mergeItem != -1)
                {
                    oriItemId = configService.MergeItemConfig[oriItemId].mergeItem;
                }
                exItems.Add(oriItemId);
            }
            if (!quality)
            {
                var info = GetNormalItem(exItems);
                if (info != null)
                    shopInfo.Add(info);
            }
            else
            {
                var info = GetSpecialItem(exItems);
                if (info != null)
                    shopInfo.Add(info);
            }
        }
        return shopInfo;
    }
}

[Serializable]
public class MergeIllustratedConfig
{
    public int id;
    public string name;
    public int tab_index;
}

[Serializable]
public class MergeOrderInfoModel
{
    public int id;
    public int npc_id;
    public int index;
    public int[] items;
    public int[] count;
    public int[] process;
    public bool over;
    public MergeOrderInfoModel(int npc_id, int order_id, int index)
    {
        this.id = order_id;
        this.npc_id = npc_id;
        this.index = index;
    }
}

[Serializable]
public class MergeRegionModel
{
    public int id;
    public int level;
    public int exp;
    public int addExp;
    public int[] rewardLv;

    public MergeRegionModel()
    {
    }

    public MergeRegionModel(MergeRegionModel old)
    {
        this.id = old.id;
        this.level = old.level;
        this.exp = old.exp;
        this.addExp = old.addExp;
        this.rewardLv = old.rewardLv;
    }
}


[Serializable]
public class MergeShopInfoModel
{
    public int date;
    public int[] items;
    public float[] offs;
    public int[] limits;
    public int[] boughts;
    public string[] products;

    public int[] storage;

    public MergeShopInfoModel()
    {

    }
}

[Serializable]
public class MergeHotAirBallModel
{
    public int id;
    public int cfgId;
    public int time;
    public float x;
    public float y;

    public MergeHotAirBallModel(int id, int cfgId, int time)
    {
        this.id = id;
        this.cfgId = cfgId;
        this.time = time;
        
        Vector3 screenCenter = new Vector3(Screen.width / 2, Screen.height / 2, 0);
        Vector3 worldPosition = Camera.main.ScreenToWorldPoint(screenCenter);
        this.x = worldPosition.x;
        this.y = worldPosition.y;
    }
}

[Serializable]
public class MergeHotAirBallConfig
{
    public int id;
    public int item_id;
    public int purchase_type;
    public string reward;
    public int off;
    public int price;
    public int time;
    public string product_id;
}

[Serializable]
public class MergeItemNpcConfig
{
    public int id;
    public int npc_id;
    public int region_id;
    public int order;
    public string rewards;
}