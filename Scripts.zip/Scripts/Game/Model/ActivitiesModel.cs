using Activities;
using System;
using System.Collections.Generic;
using System.Text;
using QFramework;
using UnityEngine;
using SoliUtils;

namespace Model
{
    #region 活动相关记录数据类统一管理(此 model 包含具体类型的活动的配置数据和本地存储数据)
    public class ActivityDataModel
    {
        public int id;
        public string name;
        public ActivityType type;
        public string desc;
        public string RewardTitle;
        public List<int> openTime; // 当 loopType == onlyOnce 时使用,时间区间, 单位：s
        public List<List<int>> openCycle; // 当 loopType == weekdayDuration 时使用,开始时间与结束时间, 单位：s
        public string param; // 附加参数
        public int unlockStage; // 解锁关卡
        public int isOpen; // 是否开启活动
        public int needUserOpen;
        public int subActivityType;
        public ActivityState state; // 活动状态
        public object localData; // 本地存储的数据，类型自定义，已对现有活动类型进行定义，直接根据需要填充字段就行
        public int ActivityNumberUpper;
        public int OpenInterval;
        public int ActivityBigEndTime;
        public List<List<int>> olderOpenTime;
        public List<List<int>> naturalTimeList;
        public void Init(int _id = 0, string _name = "", ActivityType _type = ActivityType.none, string _desc = "",
            string _param = "", int _unlockStage = 0, int _isOpen = 0,List<List<int>> _olderOpenTime = null,List<List<int>> _naturalTimeList = null,
            int _needUserOpen = 0,int _subActivityType = 0,string _rewardTitle = "",int _openInterval = 0)
        {
            id = _id;
            name = _name;
            type = _type;
            desc = _desc;
            param = _param;
            unlockStage = _unlockStage;
            isOpen = _isOpen;
            state = ActivityState.waitOpen;
            olderOpenTime = _olderOpenTime;
            needUserOpen = _needUserOpen;
            subActivityType = _subActivityType;
            RewardTitle = _rewardTitle;
            OpenInterval = _openInterval;
            naturalTimeList = _naturalTimeList;
        }
    }

    #endregion
    
    public class BaseActivityData
    {
        public bool IsFirstShow = true;
        public int ActivityBeginTime; //赛季时间内活动开启时间
        public int ActivityEndTime; //赛季时间内活动关闭时间
        public bool FinishGetReward;
        public bool WaitEntryFlag;
        public bool FinishFlag;
        public bool IsCheckingFinish;//检测活动结束
        public bool UserActivative;
        public bool PopBtn = true;
        public bool StartPopView = false;
        public bool FinishPopView = false;
        public int SubActivityType = 0;
        public int OpenActivityCount = 0;
        public int ResultAddCount = 0;
        public int RewardFlag = 0;//上报本次活动奖励标志，0没有奖励，1有奖励
    }
    
    #region 农场种植数据
    [Serializable]
    public class FarmingProgress
    {
        public int curMapId = 1;
        public int maxMapId = 1;
        public int lastMapId = 1;
        public int curThemeId = 1;
        public int maxThemeId = 1;
        public int lastMaxThemeId = 1;
        public int collectTimer = -1;
        public bool directCollect = false;
        public bool resetFlag = false;
        public int unlockCoin = 0;
        public Dictionary<int,Dictionary<int,ThemeData>> MapInfo = new Dictionary<int, Dictionary<int, ThemeData>>();
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();

        public void InitInfo()
        {
            if (MapInfo.Count == 0)
            {
                UnlockMap(1);
            }
        }

        //解锁地图
        public void UnlockMap(int mapId)
        {
            maxMapId = mapId;
            Dictionary<int, ThemeData> themeInfo = new Dictionary<int, ThemeData>();
            themeInfo.Add(1,new ThemeData());
            themeInfo.Add(2,new ThemeData());
            themeInfo.Add(3,new ThemeData());
            MapInfo.Add(mapId,themeInfo);
            UnlockTheme(1);
        }

        public void UnlockNextTheme()
        {
            if (maxThemeId + 1 <= MapInfo[curMapId].Count)
            {
                //解锁主题
                maxThemeId++;
                UnlockTheme(maxThemeId);
            }
            else
            {
                //解锁地图
                if(maxMapId + 1 > 3) return;
                maxMapId++;
                UnlockMap(maxMapId);
            }
        }
        
        //解锁主题
        public void UnlockTheme(int themeId)
        {
            maxThemeId = themeId;
            MapInfo[maxMapId][themeId].UnlockTheme();
        }

        public void CompleteTheme(int themeId)
        {
            MapInfo[curMapId][themeId].Finish = true;
        }
        
        //解锁土地
        public void UnlockLand(int landId,Action cb = null)
        {
            if (dataService.BuildCoin >= GetUnlockConsume())
            {
                dataService.ConsumeBuildCoin(GetUnlockConsume(), PropChangeWay.UnlockFarmingLand);
                MapInfo[curMapId][curThemeId].UnlockLand(landId);
                directCollect = true;
                cb?.Invoke();
            }
            TypeEventSystem.Send<UpdateFarmingPanelEvent>();
        }

        //获取下一个解锁的土地消耗建造币
        public int GetUnlockConsume()
        {
            FarmingModel model = ActivityManager.Instance.FarmingActivity.GetWaitUnlockLand();
            if (model != null)
            {
                Dictionary<int, int> consume = GameUtils.AnalysisPropString(model.consume);
                foreach (var material in consume)
                {
                    if (material.Key == (int)PropEnum.BuildCoin && dataService.BuildCoin >= dataService.GetPropNum(material.Key))
                    {
                        return material.Value;
                        break;
                    }
                }
            }
            return 0;
        }
    }
    
    //主题数据
    public class ThemeData
    {
        public bool Unlock = false;
        public bool Finish = false;
        public Dictionary<int, LandData> LandInfo = new Dictionary<int, LandData>();//土地信息
        public void UnlockTheme()
        {
            Unlock = true;
            for (int i = 1; i <= 9; i++)
            {
                LandInfo.Add(i,new LandData(i));
            }
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            ActivityManager.Instance.SaveActivityData();
        }

        public int GetUnlockLandCount()
        {
            int index = 0;
            foreach (var info in LandInfo)
            {
                if (info.Value.Unlock) index++;
            }
            return index;
        }
        public void UnlockLand(int id)
        {
            LandInfo[id].EnableLand();
            if (id >= LandInfo.Count)
            {
                IDataService dataService = MainContainer.Container.Resolve<IDataService>();
                dataService.FarmingProgress.UnlockNextTheme();
            }
        }
    }

    //土地数据
    [Serializable]
    public class LandData
    {
        public int landId;
        public bool Unlock = false;
        public bool PickFlag = false;
        public LandData(int _landId)
        {
            landId = _landId;
        }
        public int State => PickFlag ? 1 : 0;

        public int GetCollectCoin()
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            FarmingModel model = configService.GetFarmingModel(dataService.FarmingProgress.curMapId,dataService.FarmingProgress.curThemeId,landId);
            
            Dictionary<int, int> reward = GameUtils.AnalysisPropString(model.reward);
            foreach (var material in reward)
            {
                if (material.Key == (int)PropEnum.Coin)
                {
                    return material.Value;
                }
            }
            return 0;
        }
        
        public void EnableLand()
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            Unlock = true;
            PickFlag = true;
            dataService.FarmingProgress.unlockCoin += GetCollectCoin();
        }
        public void SendPlayHarvestAnim()
        {
            PickFlag = false;
            TypeEventSystem.Send<HarvestPlant>(new HarvestPlant(landId));
        }
    }
    
    #endregion
    
    #region 熔岩连胜

    [Serializable]
    public class LavaPassProgress:BaseActivityData
    {
        public int winCount = 0;
        public int lastWinCount = 0;
        public int robotCount = 99;
        public int lastRobotCount = 99;
        public int totalCount = 100;
        public int isFailState = -1;
    }

    #endregion
    
    #region 季节通行证

    [Serializable]
    public class SeasonPassProgress:BaseActivityData
    {
        public int totalProgress;
        public int getRewardCount = 0;
        public int curLayer = 1;
        public int lastLayer = 1;
        public int lastViewLayer = 1;
        public Dictionary<int, int> chargeLayerRewardFlag = new Dictionary<int, int>();//0未解锁，1解锁待领取，2已领取
        public Dictionary<int, int> freeLayerRewardFlag = new Dictionary<int, int>();//0未解锁，1解锁待领取，2已领取
        public int boxRewardIndex = 0;
        public bool IsPaid = false;
        public SeasonPassProgress()
        {
            if(chargeLayerRewardFlag.Count != 0) return;
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            foreach (var VARIABLE in configService.SeasonPassConfig)
            {
                if (VARIABLE.Value.type == 1)
                {
                    freeLayerRewardFlag.TryAdd(VARIABLE.Value.layer, VARIABLE.Value.layer == 1 ? 1 : 0);
                }
                else
                {
                    chargeLayerRewardFlag.TryAdd(VARIABLE.Value.layer, VARIABLE.Value.layer == 1 ? 1 : 0);
                }
            }
        }
        
        public void SetRewardState(SeasonPassModel model)
        {
            if (model.type == 1)
            {
                freeLayerRewardFlag[model.layer] = 2;
            }
            else
            {
                chargeLayerRewardFlag[model.layer] = 2;
            }
            TypeEventSystem.Send<SendUpdateSeasonRemid>();
            ActivityManager.Instance.SaveActivityData();
        }

        public int GetBoxRewardCount()
        {
            if (boxRewardIndex == 0) boxRewardIndex = ActivityManager.Instance.SeasonPassActivity.GetMaxLayer();
            return Math.Max(curLayer - boxRewardIndex,0);
        }
        
        public void UpdateBoxRewardIndex()
        {
            boxRewardIndex++;
            ActivityManager.Instance.SaveActivityData();
        }
    }

    #endregion

    #region 巅峰梯度礼包
    [Serializable]
    public class GradientGiftProgress : BaseActivityData
    {
        public int CurRewardIndex;
    }

    [Serializable]
    public class GiftGradientDigProgress : BaseActivityData
    {
        public int CurRewardIndex;
        public int CollectLayer = 1;
        public int CollecProgress;
    }
    
    [Serializable]
    public class GiftGradientCookProgress : BaseActivityData
    {
        public int CurRewardIndex;
        public int CollectLayer = 1;
        public int CollecProgress;
    }
    #endregion
    
    #region 每日广告奖励

    [Serializable]
    public class AdRewardProgress : BaseActivityData
    {
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        public int totalProgress;
        public int curLayer;
        public int ballonBornTime;
        public int ballonBornCount;
        public int pushAdCount;

        public void UpdateLayer()
        {
            curLayer++;
            dataService.AdRewardProgress.UpdateProgress();
        }
        
        public void UpdateProgress(int count = 1)
        {
            totalProgress += count;
            ActivityManager.Instance.SaveActivityData();
        }
    }

    #endregion


    #region 兔子礼盒
    public class RabitGiftProgress : BaseActivityData
    {
        public int curWinCount = 0;
        public int lastWinCount = 0;
    }
    #endregion

    #region 转盘
    public class WheelProgress
    {
        public int curIndex = 0;
        public int curLevel = 0;
        public bool isPay = false;
    }
    #endregion
    
    #region 收集水滴
    public class CollectWaterProgress : BaseActivityData
    {
        public int progress = 0;
        public int curLayer = 0;
    }
    #endregion

    #region 神秘种子
    public class MysteriousSeedProgress : BaseActivityData
    {
        public int curLayer = 0;
        public int curProgress = 0;
        public int lastLayer = 0;
        public int lastProgress = 0;
        public int rewardLayer = 0;
        public int failCount = 0;
        public bool canGetReward = false;
    }
    #endregion
    
    #region 收集蜂蜜
    public class CollectHoneyProgress : BaseActivityData
    {
        public int progress = 0;
        public int curLayer = 0;
    }
    #endregion
    
    #region 收集乐谱
    public class CollectMusicProgress : BaseActivityData
    {
        public int collectCount = 0;
        public int curLayer = 0;
        public int curLevelOpenCount = 1;//当前关卡打开次数
        
        public int getRewardLayer = 0;//已领取的奖励层数
        public int getRewardCount = 0;//获取奖励次数
        public Dictionary<int, int> readyGetRewardDic = new Dictionary<int, int>();//准备领取的奖励
        
        public void SetCurLayer(int layer)
        {
            curLayer = layer;
            getRewardLayer = layer;
        }
    }
    #endregion
    
    #region 挖宝活动
    public class DigTreasureProgress : BaseActivityData
    {
        public int curMap = 1;
        public int curLayer = 1;
        public int digCount = 0;
        public List<int> OccupyGridList = new List<int>();
        public List<int> GetRewardList = new List<int>();
        public Dictionary<int,PosModel> RewardGridDic = new Dictionary<int,PosModel>();
    }
    #endregion
    
    #region 做饭活动
    public class CookMealProgress : BaseActivityData
    {
        public int lastLayer = 1;
        public int curLayer = 1;
        public int cookCount = 0;
        public Dictionary<int, int> MaterialProgress = new Dictionary<int, int>();
        public int CoinProgress = 0;
        public int lastCoinProgress = 0;
    }
    #endregion
    
    #region 无尽关卡
    [Serializable]
    public class EndlessLevelProgress : BaseActivityData
    {
        public EndlessLevelData MyData;
        public int ViewMaxLayer = 1;
        public int UnlockLevel = 0;
        public bool InitInfo = false;
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        public void InitRankInfo()
        {
            if (InitInfo) return;
            MyData = new EndlessLevelData();
            InitInfo = true;
            ActivityManager.Instance.SaveActivityData();
        }
        
        //获取排行榜数据
        public List<EndlessLevelData> GetRankData()
        {
            InitRankInfo();
            int tempPos = -1;
            List<EndlessLevelData> RobotData = ActivityManager.Instance.EndlessLevelActivity.GetRobotData();
            if (RobotData.Count > 0)
            {
                RobotData.Sort((a, b) => b.integration.CompareTo(a.integration));
                tempPos = RobotData.FindIndex(data => data.integration < MyData.integration);
            }
            
            if (tempPos == -1) tempPos = RobotData.Count; // 如果没有找到合适的位置，就插入到末尾
            List<EndlessLevelData> tempList = new List<EndlessLevelData>(RobotData);
            tempList.Insert(tempPos, MyData);

            for (int i = 0; i < tempList.Count; i++)
            {
                tempList[i].curRank = i;
                if (tempList[i] == MyData && MyData.lastRank == -1)
                {
                    MyData.lastRank = tempList[i].curRank;
                }
            }
            return tempList;
        }
        
        public EndlessLevelData GetMyData()
        {
            GetRankData();
            return MyData;
        }
    }

    [Serializable]
    public class EndlessLevelData
    {
        public int integration = 0;
        public int level = 1;
        public int curRank;
        public int lastRank = -1;
        public int headIconIndex = -1;
        public int robotIndex = -1;
        public string avatar = "";
        public string name = "";
    }
    #endregion
    
    #region 熔岩活动

    [Serializable]
    public class LevelPassProgress:BaseActivityData
    {
        public int CurNodeId = 0;
        public LevelPassData MyData;
        public List<LevelPassData> RobotData = new List<LevelPassData>();
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        public bool InitInfo = false;
        public bool InitRobotIcon = false;
        public void InitRankInfo()
        {
            if(InitInfo) return;
            RobotData = new List<LevelPassData>();
            MyData = new LevelPassData
            {
                name = dataService.UserName,
                lastRank = 4
            };

            var list = new List<int>();
            for (int i = 1; i <= 4; i++)
            {
                LevelPassData levelPassData = new LevelPassData();
                var id = GameUtils.GetRandomRobotID();
                levelPassData.name = GameUtils.GetRobotInfo(id).name;
                levelPassData.headIconIndex = GameUtils.GetRandomRobotIcon(ref list);
                RobotData.Add(levelPassData);
            }
            
            InitInfo = true;
            InitRobotIcon = true;
            ActivityManager.Instance.SaveActivityData();
        }
        
        public LevelPassData GetMyData()
        {
            GetRankData();
            return MyData;
        }
        
        public List<LevelPassData> GetRobotData()
        {
            GetRankData();
            return RobotData;
        }

        //初始化机器人每个时间阶段添加的鲜花数
        public int GetRobotStepAddCount(LevelPassData robotData, int curId)
        {
            if (curId == 0) return 0;
            int nodeCount = 0;
            int tempValue = 0;
            foreach (var model in configService.CollectFlowerConfig)
            {
                nodeCount++;
            }

            if (robotData.stepAddList.Count == 0)
            {
                for (int i = 0; i < nodeCount; i++)
                {
                    int index = i + 1;
                    var result = GetRobotAddLimit(index);
                    int ceilCount = result.Item1;
                    int floorCount = result.Item2;
                    int value = GameUtils.RandomRange(floorCount,ceilCount + 1);
                    robotData.stepAddList.Add(value);
                }
            }

            for (int i = 0; i < curId; i++)
            {
                if(i >= robotData.stepAddList.Count) break;
                tempValue += robotData.stepAddList[i];
            }
            Mathf.Min(tempValue, 10);
            return tempValue;
        }
        
        public Tuple<int, int> GetRobotAddLimit(int nodeId)
        {
            return Tuple.Create(configService.LevelPassConfig[nodeId].levelCeil, configService.LevelPassConfig[nodeId].levelFloor);
        }
        
        public void SortRobotData()
        {
            ReviseRobotIcon();
            RobotData.Sort((a, b) => b.successVictory.CompareTo(a.successVictory));
        }

        private void ReviseRobotIcon()
        {
            if (!InitRobotIcon)
            {
                var list = new List<int>();
                foreach (var data in RobotData)
                {
                    data.headIconIndex = GameUtils.GetRandomRobotIcon(ref list);
                }
                InitRobotIcon = true;
                ActivityManager.Instance.SaveActivityData();
            }
        }
        
        //获取排行榜数据
        public List<LevelPassData> GetRankData()
        {
            InitRankInfo();
            SortRobotData();
            int tempPos = RobotData.FindIndex(data => data.successVictory < MyData.successVictory);
            if (tempPos == -1) tempPos = RobotData.Count; // 如果没有找到合适的位置，就插入到末尾
            List<LevelPassData> tempList = new List<LevelPassData>(RobotData);
            tempList.Insert(tempPos, MyData);

            for (int i = 0; i < tempList.Count; i++)
            {
                tempList[i].curRank = i;
                if (tempList[i].successVictory >= 10) tempList[i].finish = 1;
                if (tempList[i].name == MyData.name && MyData.lastRank == -1)
                {
                    MyData.lastRank = tempList[i].curRank;
                }
            }
            return tempList;
        }
    }
    
    [Serializable]
    public class LevelPassData
    {
        public string name;
        public int lastSuccessVictory = 0;
        public int successVictory = 0;
        public int curRank = -1; //排行等级
        public int lastRank = -1;
        public int finish = 0;
        public int headIconIndex = -1;
        public List<int> stepAddList = new List<int>();
    }
    #endregion

    #region 连胜活动数据

    [Serializable]
    public class WinStreakData:BaseActivityData
    {
        public int LastWinCount; //记录上一次的连胜次数
        public int WinCount; //连胜次数
    }

    #endregion

    #region 爱心方块牌收集活动（爬塔活动连续通关）数据

    [Serializable]
    public class CollectLoveCardProgress:BaseActivityData
    {
        public int collectCount = 0; //收集的方块和爱心牌
        public int curLayer = 0; //当前层数
        public int getRewardLayer = 0;//已领取的奖励层数
        public int getRewardCount = 0;//获取奖励次数
        public List<int> cardList = new List<int>(); //每局游戏里正确消除的卡牌集合
        public Dictionary<int, int> readyGetRewardDic = new Dictionary<int, int>();//准备领取的奖励
        
        public void SetCurLayer(int layer)
        {
            curLayer = layer;
            getRewardLayer = layer;
        }
    }
    #endregion

    #region 鲜花赶集活动（关卡内收集活动）数据
    [Serializable]
    public class CollectFlowerProgress:BaseActivityData
    {
        public int CurNodeId = 0;
        public CollectFlowerData MyData;
        public List<CollectFlowerData> RobotData = new List<CollectFlowerData>();
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        public bool InitInfo = false;
        public bool InitRobotIcon = false;
        public CollectFlowerData GetMyData()
        {
            GetRankData();
            return MyData;
        }

        public List<CollectFlowerData> GetRobotData()
        {
            GetRankData();
            return RobotData;
        }

        public void InitRankInfo()
        {
            if(InitInfo) return;
            RobotData = new List<CollectFlowerData>();
            MyData = new CollectFlowerData
            {
                name = dataService.UserName,
                lastRank = 4
            };

            var list = new List<int>();
            for (int i = 1; i <= 4; i++)
            {
                CollectFlowerData collectFlowerData = new CollectFlowerData();
                var id = GameUtils.GetRandomRobotID();
                collectFlowerData.name = GameUtils.GetRobotInfo(id).name;
                collectFlowerData.flowerCount = 0;
                collectFlowerData.headIconIndex = GameUtils.GetRandomRobotIcon(ref list);
                RobotData.Add(collectFlowerData);
            }
            
            InitInfo = true;
            InitRobotIcon = true;
            ActivityManager.Instance.SaveActivityData();
        }
  
        public Tuple<int, int> GetRobotAddLimit()
        {
            int id = 0;
            foreach (var model in configService.CollectFlowerConfig)
            {
                if (model.Value.level > dataService.MaxLevel)
                {
                    id++;
                    break;
                }
            }
            return Tuple.Create(configService.CollectFlowerConfig[id].robotFlowerCeil, configService.CollectFlowerConfig[id].robotFlowerFloor);
        }

        //初始化机器人每个时间阶段添加的鲜花数
        public int GetRobotStepAddCount(CollectFlowerData robotData, int curId)
        {
            if (curId == 0) return 0;
            int nodeCount = 0;
            int tempValue = 0;
            foreach (var model in configService.CollectFlowerConfig)
            {
                nodeCount++;
            }

            var result = GetRobotAddLimit();
            int ceilCount = result.Item1;
            int floorCount = result.Item2;
            if (robotData.stepAddList.Count == 0)
            {
                int average = Mathf.RoundToInt(ceilCount / 5 / nodeCount); // 最小值为5的倍数的1倍
                System.Random random = new System.Random();
                for (int i = 0; i < nodeCount; i++)
                {
                    int value = GameUtils.RandomRange(average - 20, average + 21) * 5;
                    robotData.stepAddList.Add(value);
                }
            }
            for (int i = 0; i < curId; i++)
            {
                tempValue += robotData.stepAddList[i];
            }
            return curId == nodeCount ? Mathf.Clamp(tempValue, floorCount, ceilCount) : tempValue;
        }

        public void ResetLastRank()
        {
            MyData.lastRank = GetMyData().curRank;
        }

        //排序机器人数据
        public void SortRobotData()
        {
            ReviseRobotIcon();
            RobotData.Sort((a, b) => b.flowerCount.CompareTo(a.flowerCount));
        }

        private void ReviseRobotIcon()
        {
            if (!InitRobotIcon)
            {
                var list = new List<int>();
                foreach (var data in RobotData)
                {
                    data.headIconIndex = GameUtils.GetRandomRobotIcon(ref list);
                }
                InitRobotIcon = true;
                ActivityManager.Instance.SaveActivityData();
            }
        }
        
        //获取排行榜数据
        public List<CollectFlowerData> GetRankData()
        {
            InitRankInfo();
            SortRobotData();
            int tempPos = RobotData.FindIndex(data => data.flowerCount < MyData.flowerCount);
            if (tempPos == -1) tempPos = RobotData.Count; // 如果没有找到合适的位置，就插入到末尾
            List<CollectFlowerData> tempList = new List<CollectFlowerData>(RobotData);
            tempList.Insert(tempPos, MyData);

            for (int i = 0; i < tempList.Count; i++)
            {
                tempList[i].curRank = i;
                if (tempList[i].name == MyData.name && MyData.lastRank == -1)
                {
                    MyData.lastRank = tempList[i].curRank;
                }
            }
            return tempList;
        }
    }

    [Serializable]
    public class CollectFlowerData
    {
        public string name = ""; //排行等级
        public int flowerCount = 0; //收集的鲜花数
        public int lastRank = -1;
        public int curRank = -1;
        public int headIconIndex = -1;
        public List<int> stepAddList = new List<int>();
    }

    #endregion

    #region 奖杯锦标赛（通关排行）数据

    [Serializable]
    public class PassRankProgress:BaseActivityData
    {
        public int CurNodeId = 0;
        public PassRankData myData;
        public List<PassRankData> roboData = new List<PassRankData>();
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        public bool InitRobotIcon = false;
        public bool InitInfo = false;

        public void InitRankInfo()
        {
            if(InitInfo) return;
            roboData = new List<PassRankData>();
            myData = new PassRankData
            {
                robotType = -1,
                name = dataService.UserName,
                lastRank = 19
            };
            var list = new List<int>();
            for (int i = 1; i <= 19; i++)
            {
                PassRankData passRankData = new PassRankData();
                var id = GameUtils.GetRandomRobotID();
                passRankData.name = GameUtils.GetRobotInfo(id).name;
                passRankData.cupCount = GameUtils.RandomRange(1, 11);
                passRankData.headIconIndex = GameUtils.GetRandomRobotIcon(ref list);
                int type = 1;
                int totalAmount = 0;
                foreach (var model in configService.PassRankRobotConfig)
                {
                    totalAmount += model.Value.amount;
                    if (totalAmount < i)
                    {
                        type++;
                    }
                    else
                    {
                        break;
                    }
                }
                passRankData.robotType = type;
                roboData.Add(passRankData);
            }

            InitInfo = true;
            InitRobotIcon = true;
            ActivityManager.Instance.SaveActivityData();
        }

        //排序机器人数据
        public void SortRobotData()
        {
            ReviseRobotIcon();
            roboData.Sort((a, b) => { return b.cupCount.CompareTo(a.cupCount); });
        }

        private void ReviseRobotIcon()
        {
            if (!InitRobotIcon)
            {
                var list = new List<int>();
                foreach (var data in roboData)
                {
                    data.headIconIndex = GameUtils.GetRandomRobotIcon(ref list);
                }
                InitRobotIcon = true;
                ActivityManager.Instance.SaveActivityData();
            }
        }

        //获取排行榜数据
        public List<PassRankData> GetRankData()
        {
            InitRankInfo();
            SortRobotData();
            int tempPos = roboData.FindIndex(data => data.cupCount < myData.cupCount);
            if (tempPos == -1) tempPos = roboData.Count; // 如果没有找到合适的位置，就插入到末尾
            List<PassRankData> tempList = new List<PassRankData>(roboData);
            tempList.Insert(tempPos, myData);

            for (int i = 0; i < tempList.Count; i++)
            {
                tempList[i].rank = i;
                if (tempList[i].rank == myData.rank && myData.lastRank == -1)
                {
                    myData.lastRank = tempList[i].rank;
                }
            }
            return tempList;
        }

        public PassRankData GetMyData()
        {
            GetRankData();
            return myData;
        }

        public List<PassRankData> GetRobotData()
        {
            GetRankData();
            return roboData;
        }

        public void ResetLastRank()
        {
            myData.lastRank = GetMyData().rank;
        }
    }

    [Serializable]
    public class PassRankData
    {
        public string name;
        public int rank = 0; //排行等级
        public int headIconIndex = -1;
        public int cupCount = 0; //奖杯数
        public int lastRank = -1;
        public int robotType = -1;//-1表示自己，其它为机器人类型
    }

    #endregion

       #region 赛车锦标赛（通关排行）数据

    [Serializable]
    public class CarRankProgress:BaseActivityData
    {
        public int CurNodeId = 0;
        public CarRankData myData;
        public List<CarRankData> roboData = new List<CarRankData>();
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        public bool InitRobotIcon = false;
        public bool InitInfo = false;

        public void InitRankInfo()
        {
            if(InitInfo) return;
            roboData = new List<CarRankData>();
            myData = new CarRankData
            {
                robotType = -1,
                name = dataService.UserName,
                lastRank = 19
            };
            var list = new List<int>();
            for (int i = 1; i <= 19; i++)
            {
                CarRankData carRankData = new CarRankData();
                var id = GameUtils.GetRandomRobotID();
                carRankData.name = GameUtils.GetRobotInfo(id).name;
                carRankData.cupCount = GameUtils.RandomRange(1, 11);
                carRankData.headIconIndex = GameUtils.GetRandomRobotIcon(ref list);
                int type = 1;
                int totalAmount = 0;
                foreach (var model in configService.CarRankRobotConfig)
                {
                    totalAmount += model.Value.amount;
                    if (totalAmount < i)
                    {
                        type++;
                    }
                    else
                    {
                        break;
                    }
                }
                carRankData.robotType = type;
                roboData.Add(carRankData);
            }

            InitInfo = true;
            InitRobotIcon = true;
            ActivityManager.Instance.SaveActivityData();
        }

        //排序机器人数据
        public void SortRobotData()
        {
            ReviseRobotIcon();
            roboData.Sort((a, b) => { return b.cupCount.CompareTo(a.cupCount); });
        }

        private void ReviseRobotIcon()
        {
            if (!InitRobotIcon)
            {
                var list = new List<int>();
                foreach (var data in roboData)
                {
                    data.headIconIndex = GameUtils.GetRandomRobotIcon(ref list);
                }
                InitRobotIcon = true;
                ActivityManager.Instance.SaveActivityData();
            }
        }

        //获取排行榜数据
        public List<CarRankData> GetRankData()
        {
            InitRankInfo();
            SortRobotData();
            int tempPos = roboData.FindIndex(data => data.cupCount < myData.cupCount);
            if (tempPos == -1) tempPos = roboData.Count; // 如果没有找到合适的位置，就插入到末尾
            List<CarRankData> tempList = new List<CarRankData>(roboData);
            tempList.Insert(tempPos, myData);

            for (int i = 0; i < tempList.Count; i++)
            {
                tempList[i].rank = i;
                if (tempList[i].rank == myData.rank && myData.lastRank == -1)
                {
                    myData.lastRank = tempList[i].rank;
                }
            }
            return tempList;
        }

        public CarRankData GetMyData()
        {
            GetRankData();
            return myData;
        }

        public List<CarRankData> GetRobotData()
        {
            GetRankData();
            return roboData;
        }

        public void ResetLastRank()
        {
            myData.lastRank = GetMyData().rank;
        }
    }

    [Serializable]
    public class CarRankData
    {
        public string name;
        public int rank = 0; //排行等级
        public int headIconIndex = -1;
        public int cupCount = 0; //奖杯数
        public int lastRank = -1;
        public int robotType = -1;//-1表示自己，其它为机器人类型
    }

    #endregion
    
    #region 拳击比赛(限时1v1)
    [Serializable]
    public class LimitPkData:BaseActivityData
    {
        public bool PopUI;
        public int CurNodeId = 0;
        public int MyIntegral = 0;
        public int LastMyIntegral = 0;
        public int RobotIntegral = 0;
        public string RobotName = "";
        public int RobotHeadIconIndex = -1;
        public int LastRobotIntegral = 0; 
        public bool MatchFlag;
        public List<int> cardList = new List<int>();
        public bool IsWin()
        {
            return MyIntegral > RobotIntegral;
        }

        public int GetMyRank()
        {
            return MyIntegral > RobotIntegral ? 1 : 2;
        }
    }
    #endregion
    
    #region 存钱罐数据
    [Serializable]
    public class PiggyData:BaseActivityData
    {
        public int piggyCoin = 0;
        public int tempAddCoin = 0;

        public void AddPiggyCoin(int addNum, bool needUpdate = false)
        {
            if (ActivityManager.Instance.GetActivityByType(ActivityType.piggy).state != ActivityState.underWay || FinishGetReward) return;
            tempAddCoin = addNum;
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            if (piggyCoin == 0) piggyCoin = configService.SaverInitial;
            if (needUpdate) UpdatePiggyCoin();
        }

        public void UpdatePiggyCoin()
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            int max = configService.SaverBankMax;
            if (tempAddCoin != 0)
            {
                ShopModel model = configService.ShopConfig[Constants.ProductId.PiggyBank];
                float beishu = float.Parse(configService.ValueConfig["SaverRawardConstant"]);
                //计算金币
                int newGold = Mathf.RoundToInt(tempAddCoin * beishu) + piggyCoin;
                piggyCoin = Mathf.Min(newGold,max);
                ActivityManager.Instance.SaveActivityData();
                var msg = new Dictionary<string, object>
                {
                    {AnalyticsKey.PiggyAdd, newGold - piggyCoin},
                    {AnalyticsKey.PiggyTotal, piggyCoin},
                    {AnalyticsKey.PiggyIsfull, piggyCoin == max ? 1 : 0},
                };
                AnalyticUtils.ReportEvent(AnalyticsKey.SoliPiggyFill, msg);
            }
            tempAddCoin = 0;
        }
    }
    #endregion


    #region 图鉴数据
    public class MergeIllustratedData
    {
        public MergeIllustratedConfig config;
        public MergeItemConfig targetConfig;//终极目标配置
        public List<MergeItemConfig> pieceConfigs;//碎片链配置
    }
    #endregion

    #region 礼包

    //1+1
    [Serializable]
    public class GiftPlusOneData : BaseActivityData
    {
        public int curIndex = 1;
    }
    
    //1+4
    [Serializable]
    public class GiftPlusFourData : BaseActivityData
    {
        public int curIndex = 1;
    }
    
    //1+4
    [Serializable]
    public class GiftDiscountData : BaseActivityData
    {
        public int curIndex = 1;
    }
    
    //1拖1
    [Serializable]
    public class GiftDragOneData : BaseActivityData
    {
        public int curIndex = 1;
    }

    //1拖2
    [Serializable]
    public class GiftDragTwoData : BaseActivityData
    {
        public int curIndex = 1;
    }
    
    //1拖6
    [Serializable]
    public class GiftDragSixData : BaseActivityData
    {
        public int curIndex = 1;
    }
    #endregion

    #region 所有活动的本地记录都可存在这边，自行扩展就好

    [Serializable]
    public class ActivitySaveData // TODO 过期的活动数据可能需要清理一下
    {
        public PiggyData piggy; // 存钱罐数据
        public CollectFlowerProgress flowerProgress; //收集鲜花数据
        public DigTreasureProgress digTreasureProgress; //挖宝数据
        public CookMealProgress cookMealProgress;//做饭数据
        public CollectLoveCardProgress loveCardProgress; //收集爱心方块卡牌数据
        public CollectWaterProgress waterProgress;
        public GiftPlusOneData giftPlusOneData;
        public GiftPlusFourData giftPlusFourData;
        public GiftDiscountData giftDiscountData;
        public GiftDragOneData giftDragOneData;
        public GiftDragTwoData giftDragTwoData;
        public GiftDragSixData giftDragSixData;
        public CollectHoneyProgress honeyProgress;
        public CollectMusicProgress musicProgress;
        public PassRankProgress passRankProgress; //奖杯锦标赛数据
        public CarRankProgress carRankProgress; //奖杯锦标赛数据
        public LevelPassProgress levelPassProgress;//10关PK数据
        public SeasonPassProgress seasonPassProgress;//赛季通行证
        public MysteriousSeedProgress mysteriousSeedProgress;
        public LavaPassProgress lavaPassProgress;//熔岩连胜数据
        public WinStreakData winStreak; //连胜活动数据
        public LimitPkData limitPkData;
        public GradientGiftProgress gradientGiftProgress;
        public GiftGradientCookProgress giftGradientCookProgress;
        public GiftGradientDigProgress giftGradientDigProgress;
        public AdRewardProgress adRewardProgress;
        public EndlessLevelProgress endlessLevelProgress;
        public RabitGiftProgress rabitGiftProgress;
        public WheelProgress wheelProgress;
        public ActivitySaveData()
        {
            piggy = new PiggyData();
            flowerProgress = new CollectFlowerProgress();
            digTreasureProgress = new DigTreasureProgress();
            cookMealProgress = new CookMealProgress();
            loveCardProgress = new CollectLoveCardProgress();
            waterProgress = new CollectWaterProgress();
            giftPlusOneData = new GiftPlusOneData();
            giftPlusFourData = new GiftPlusFourData();
            giftDiscountData = new GiftDiscountData();
            giftDragOneData = new GiftDragOneData();
            giftDragTwoData = new GiftDragTwoData();
            giftDragSixData = new GiftDragSixData();
            honeyProgress = new CollectHoneyProgress();
            musicProgress = new CollectMusicProgress();
            passRankProgress = new PassRankProgress();
            carRankProgress = new CarRankProgress();
            levelPassProgress = new LevelPassProgress();
            seasonPassProgress = new SeasonPassProgress();
            mysteriousSeedProgress = new MysteriousSeedProgress();
            lavaPassProgress = new LavaPassProgress();
            winStreak = new WinStreakData();
            limitPkData = new LimitPkData();
            gradientGiftProgress = new GradientGiftProgress();
            giftGradientCookProgress = new GiftGradientCookProgress();
            giftGradientDigProgress = new GiftGradientDigProgress();
            adRewardProgress = new AdRewardProgress();
            endlessLevelProgress = new EndlessLevelProgress();
            rabitGiftProgress = new RabitGiftProgress();
            wheelProgress = new WheelProgress();
        }

        public void ClearData(ActivityType type)
        {
            switch (type)
            {
                case ActivityType.piggy:
                    piggy = new PiggyData();
                    break;
                case ActivityType.collectFlower:
                    flowerProgress = new CollectFlowerProgress();
                    break;
                case ActivityType.digTreasure:
                    digTreasureProgress = new DigTreasureProgress();
                    break;
                case ActivityType.cookMeal:
                    cookMealProgress = new CookMealProgress();
                    break;
                case ActivityType.collectHoney:
                    honeyProgress = new CollectHoneyProgress();
                    break;
                case ActivityType.collectMusic:
                    musicProgress = new CollectMusicProgress();
                    break;
                case ActivityType.collectWater:
                    waterProgress = new CollectWaterProgress();
                    break;
                case ActivityType.giftPlusOne:
                    giftPlusOneData = new GiftPlusOneData();
                    break;
                case ActivityType.giftPlusFour:
                    giftPlusFourData = new GiftPlusFourData();
                    break;
                case ActivityType.giftDiscount:
                    giftDiscountData = new GiftDiscountData();
                    break;
                case ActivityType.giftDragOne:
                    giftDragOneData = new GiftDragOneData();
                    break;
                case ActivityType.giftDragTwo:
                    giftDragTwoData = new GiftDragTwoData();
                    break;
                case ActivityType.giftDragSix:
                    giftDragSixData = new GiftDragSixData();
                    break;
                case ActivityType.collectLoveCard:
                    loveCardProgress = new CollectLoveCardProgress();
                    break;
                case ActivityType.passRank:
                    passRankProgress = new PassRankProgress();
                    break;
                case ActivityType.carRank:
                    carRankProgress = new CarRankProgress();
                    break;
                case ActivityType.winStreak:
                    winStreak = new WinStreakData();
                    break;
                case ActivityType.limitPk:
                    limitPkData = new LimitPkData();
                    break;
                case ActivityType.gradientGift:
                    gradientGiftProgress = new GradientGiftProgress();
                    break;
                case ActivityType.giftGradientCook:
                    giftGradientCookProgress = new GiftGradientCookProgress();
                    break;
                case ActivityType.giftGradientDig:
                    giftGradientDigProgress = new GiftGradientDigProgress();
                    break;
                case ActivityType.adReward:
                    adRewardProgress = new AdRewardProgress();
                    break;
                case ActivityType.endlessLevel:
                    endlessLevelProgress = new EndlessLevelProgress();
                    break;
                case ActivityType.rabbitGift:
                    rabitGiftProgress = new RabitGiftProgress();
                    break;
                case ActivityType.wheel:
                    wheelProgress = new WheelProgress();
                    break;
                case ActivityType.levelPass:
                    levelPassProgress = new LevelPassProgress();
                    break;
                case ActivityType.seasonPass:
                    seasonPassProgress = new SeasonPassProgress();
                    break;
                case ActivityType.mysteriousSeed:
                    mysteriousSeedProgress = new MysteriousSeedProgress();
                    break;
                case ActivityType.lavaPass:
                    lavaPassProgress = NewActivityData(lavaPassProgress, new LavaPassProgress()) as LavaPassProgress;
                    break;
            }
        }

        public BaseActivityData NewActivityData(BaseActivityData oldData,BaseActivityData newData)
        {
            if (oldData != null)
            {
                newData.OpenActivityCount = oldData.OpenActivityCount;
            }
            return newData;
        }

        public void ClearAll()
        {
            piggy = new PiggyData();
            flowerProgress = new CollectFlowerProgress();
            digTreasureProgress = new DigTreasureProgress();
            cookMealProgress = new CookMealProgress();
            loveCardProgress = new CollectLoveCardProgress();
            waterProgress = new CollectWaterProgress();
            giftPlusOneData = new GiftPlusOneData();
            giftPlusFourData = new GiftPlusFourData();
            giftDiscountData = new GiftDiscountData();
            giftDragOneData = new GiftDragOneData();
            giftDragTwoData = new GiftDragTwoData();
            giftDragSixData = new GiftDragSixData();
            honeyProgress = new CollectHoneyProgress();
            musicProgress = new CollectMusicProgress();
            passRankProgress = new PassRankProgress();
            carRankProgress = new CarRankProgress();
            levelPassProgress = new LevelPassProgress();
            seasonPassProgress = new SeasonPassProgress();
            mysteriousSeedProgress = new MysteriousSeedProgress();
            lavaPassProgress = new LavaPassProgress();
            winStreak = new WinStreakData();
            limitPkData = new LimitPkData();
            gradientGiftProgress = new GradientGiftProgress();
            giftGradientCookProgress = new GiftGradientCookProgress();
            giftGradientDigProgress = new GiftGradientDigProgress();
            adRewardProgress = new AdRewardProgress();
            endlessLevelProgress = new EndlessLevelProgress();
            rabitGiftProgress = new RabitGiftProgress();
            wheelProgress = new WheelProgress();
        }
    }

    #endregion
}