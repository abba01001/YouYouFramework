﻿using System;
using System.Collections;
using UnityEngine;

public class EnergyModel
{

    
}

[Serializable]
public class EnergyConfig
{
    public int id;
    public int max_value;
    public int auto_recover_value;
    public int auto_recover_time;
    public int price;
    public int ad_count;
    public int ad_cd;

}

[Serializable]
public class EnergySaveData
{
    public bool inited;
    public int lastRecoverTime;//上次自动回复时间
    public int lastADTime;//上次看广告获得体力时间
    public int dayADCount;//当天看广告获得体力次数

}