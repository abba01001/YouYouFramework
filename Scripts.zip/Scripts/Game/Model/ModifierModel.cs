using System.Runtime.Serialization;
using UnityEngine;

[System.Serializable]
public class ModifierModel
{
    [SerializeField] public string type = "";
    public ModifierType modType {
        get {
            if(Constants.String2ModTypeDic.TryGetValue(type, out var mt))
                return mt;
            return ModifierType.None;
        }
        set {
            if(Constants.ModType2StringDic.TryGetValue(value, out var s))
                type = s;
        }
    }
    [SerializeField] public PropertieModel properties;

    public ModifierModel DeepCopy()
    {
        ModifierModel mm = new ModifierModel();
        mm.type = this.type;
        mm.properties = this.properties.DeepCopy();
        return mm;
    }

}
