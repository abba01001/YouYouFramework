using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Runtime.Serialization;

[System.Serializable]
public class CardModel
{
    [SerializeField] public int id;
    [SerializeField] private string type;
    [SerializeField] public bool random = true;
    [SerializeField] private int value = -1;
    [SerializeField] private int value2 = -1;
    [SerializeField] public int suit = -1;
    [SerializeField] public bool faceUp;
    [SerializeField] public int x;
    [SerializeField] public int y;
    [SerializeField] public int angle;
    [SerializeField] public int depth;

    [SerializeField] public ModifierModel[] modifiers = new ModifierModel[] { };

    public CardModel()
    {
        this.id = 0;
        this.cardType = CardType.Value;
        this.random = true;
        this.value = -1;
        this.faceUp = false;
        this.x = 0;
        this.y = 0;
        this.depth = 0;
        this.angle = 0;
    }

    public CardModel(int id)
    {
        this.id = id;
        this.cardType = CardType.Value;
        this.random = true;
        this.value = -1;
        this.faceUp = false;
        this.x = 0;
        this.y = 0;
        this.depth = 0;
        this.angle = 0;
    }

    public CardModel(int id, CardType cardType, bool random = true, int value = -1, bool faceUp = false, int x = 0, int y = 0, int depth = 0, int angle = 0)
    {
        this.id = id;
        this.cardType = cardType;
        this.random = random;
        this.value = value;
        this.faceUp = faceUp;
        this.x = x;
        this.y = y;
        this.depth = depth;
        this.angle = angle;
    }

    public int GetValue()
    {
        return value;
    }

    public void SetValue(int value)
    {
        this.value = value;
    }

    public int GetValue2()
    {
        return value2;
    }

    public void SetValue2(int value)
    {
        this.value2 = value;
    }


    public CardType cardType
    {
        get
        {
            if (Constants.String2CardTypeDic.TryGetValue(type, out var ct))
                return ct;
            random = true;
            value = -1;
            return CardType.Value;
        }
        set
        {
            if (Constants.CardType2StringDic.TryGetValue(value, out var s))
                type = s;
            else
                type = Constants.CardTypeValue;
        }
    }

    public void PrintInfo()
    {
        Debug.Log($"<color=cyan>id={id}, x={x}, y={y}, angle={angle}, depth={depth}" +
                  $" type={cardType}, random={random}, faceUp={faceUp}, value={value}, suit={suit}, value2={value2}</color>");

        if (modifiers != null && modifiers.Length > 0)
        {
            var str = "modifiers:{";
            foreach (var mod in modifiers)
            {
                str += $"type:{mod.modType}";
                if (mod.properties != null)
                {
                    str += $",plays:{mod.properties.plays},timer:{mod.properties.timer},interval:{mod.properties.interval},param1:{mod.properties.param1},param2:{mod.properties.param2}";
                }
                str += " ";
            }
            str += "}";
            Debug.Log($"<color=cyan>{str}</color>");
        }
    }

    public void Fix()
    {
        if (!Constants.String2CardTypeDic.ContainsKey(type))
        {
            random = true;
            value = -1;
            type = Constants.CardTypeValue;
        }
    }

    public bool HasBomb()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.Bomb))
                return true;
        }
        return false;
    }

    public bool HasBigBomb()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.BigBomb))
                return true;
        }
        return false;
    }

    public int LightningTimer
    {
        get
        {
            if (modifiers != null && modifiers.Length > 0)
            {
                foreach (var mod in modifiers)
                {
                    if (mod.modType == ModifierType.Lightning)
                    {
                        return mod.properties.timer;
                    }
                }
            }
            return 0;
        }

        set
        {
            modifiers = new ModifierModel[1] { new ModifierModel() };
            modifiers[0].modType = ModifierType.Lightning;
            modifiers[0].properties = new PropertieModel();
            modifiers[0].properties.timer = value;
            modifiers[0].properties.interval = value;
        }
    }

    public int LightningInterval
    {
        get
        {
            if (modifiers != null && modifiers.Length > 0)
            {
                foreach (var mod in modifiers)
                {
                    if (mod.modType == ModifierType.Lightning)
                    {
                        return mod.properties.interval;
                    }
                }
            }
            return 0;
        }
    }

    public int BigBombTimer
    {
        get
        {
            if (modifiers != null && modifiers.Length > 0)
            {
                foreach (var mod in modifiers)
                {
                    if (mod.modType == ModifierType.BigBomb)
                    {
                        return mod.properties.timer;
                    }
                }
            }
            return 0;
        }
        set
        {
            modifiers = new ModifierModel[1] { new ModifierModel() };
            modifiers[0].modType = ModifierType.BigBomb;
            modifiers[0].properties = new PropertieModel();
            modifiers[0].properties.timer = value;
        }
    }

    public int BombTimer
    {
        get
        {
            if (modifiers != null && modifiers.Length > 0)
            {
                foreach (var mod in modifiers)
                {
                    if (mod.modType == ModifierType.Bomb)
                    {
                        return mod.properties.timer;
                    }
                }
            }
            return 0;
        }
        set
        {
            modifiers = new ModifierModel[1] { new ModifierModel() };
            modifiers[0].modType = ModifierType.Bomb;
            modifiers[0].properties = new PropertieModel();
            modifiers[0].properties.timer = value;
        }
    }

    public bool HasRising()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.Rising))
                return true;
        }
        return false;
    }

    public void UpdateRising()
    {
        if (modifiers != null && modifiers.Length > 0)
        {
            foreach (var mod in modifiers)
            {
                if (mod.modType == ModifierType.Rising)
                {
                    value = (value + 1) % Constants.ValueCardCount52;
                }
            }
        }
    }
    public void UndoRising()
    {
        if (modifiers != null && modifiers.Length > 0)
        {
            foreach (var mod in modifiers)
            {
                if (mod.modType == ModifierType.Rising)
                {
                    value = ((value - 1) + Constants.ValueCardCount52) % Constants.ValueCardCount52;
                }
            }
        }
    }

    public bool HasLowering()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.Lowering))
                return true;
        }
        return false;
    }
    public void UpdateLowering()
    {
        if (modifiers != null && modifiers.Length > 0)
        {
            foreach (var mod in modifiers)
            {
                if (mod.modType == ModifierType.Lowering)
                {
                    value = ((value - 1) + Constants.ValueCardCount52) % Constants.ValueCardCount52;
                }
            }
        }
    }
    public void UndoLowering()
    {
        if (modifiers != null && modifiers.Length > 0)
        {
            foreach (var mod in modifiers)
            {
                if (mod.modType == ModifierType.Lowering)
                {
                    value = (value + 1) % Constants.ValueCardCount52;
                }
            }
        }
    }

    public bool HasWater()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.Water))
                return true;
        }
        return false;
    }

    public bool HasIce()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.Ice))
                return true;
        }
        return false;
    }

    public bool HasLightning()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.Lightning))
                return true;
        }
        return false;
    }

    public int GetLightningTimer(bool init)
    {
        int timer = 0;
        if (modifiers != null && modifiers.Length > 0)
        {
            foreach (var mod in modifiers)
            {
                if (mod.modType == ModifierType.Lightning)
                {
                    timer = init ? mod.properties.timer : mod.properties.interval;
                }
            }
        }

        return timer;
    }


    public bool HasGreenLeaf()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.GreenLeaf))
                return true;
        }
        return false;
    }

    public bool HasCloth()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.Cloth))
                return true;
        }
        return false;
    }

    public bool HasMagicCloth()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.MagicCloth))
                return true;
        }
        return false;
    }

    public int GetClothTimer(ModifierType type)
    {
        if (modifiers != null && modifiers.Length > 0)
        {
            foreach (var mod in modifiers)
            {
                if (mod.modType == type)
                {
                    return mod.properties.timer;
                }
            }
        }
        return 0;
    }

    public void SetModifier(ModifierType type)
    {
        modifiers = new ModifierModel[1] { new ModifierModel() };
        modifiers[0].modType = type;
        modifiers[0].properties = new PropertieModel();
    }

    public void SetClothTimer(ModifierType type, int timer)
    {
        modifiers = new ModifierModel[1] { new ModifierModel() };
        modifiers[0].modType = type;
        modifiers[0].properties = new PropertieModel();
        modifiers[0].properties.timer = timer;
        modifiers[0].properties.param1 = 0;
    }

    public bool GetClothOpen(ModifierType type)
    {
        if (modifiers != null && modifiers.Length > 0)
        {
            foreach (var mod in modifiers)
            {
                if (mod.modType == type)
                {
                    return mod.properties.param1 == 1;
                }
            }
        }
        return false;
    }

    public bool HasSuitRope()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.SuitRope))
                return true;
        }
        return false;
    }

    public bool HasLinkRope()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.LinkRope))
                return true;
        }
        return false;
    }

    public int LinkRopeCardId
    {
        get
        {
            if (modifiers != null && modifiers.Length > 0)
            {
                foreach (var mod in modifiers)
                {
                    if (mod.modType == ModifierType.LinkRope)
                    {
                        return mod.properties.param1;
                    }
                }
            }
            return 0;
        }
    }

    public bool HasLizard()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.Lizard))
                return true;
        }
        return false;
    }

    public bool HasTask()
    {
        if (cardType != CardType.Value)
            return false;
        if (modifiers != null && modifiers.Length > 0)
        {
            if (modifiers.Any(x => x.modType == ModifierType.Task))
                return true;
        }
        return false;
    }

    public Vector3Int Position
    {
        get
        {
            return new Vector3Int(x, y, depth);
        }
        set
        {
            x = value.x;
            y = value.y;
            depth = value.z;
        }
    }

    public CardModel DeepCopy()
    {
        // BinaryFormatter bFormatter = new BinaryFormatter();
        // MemoryStream stream = new MemoryStream();
        // bFormatter.Serialize(stream, this);
        // stream.Seek(0, SeekOrigin.Begin);
        // return (CardModel)bFormatter.Deserialize(stream);
        CardModel cm = new CardModel();
        cm.id = this.id;
        cm.type = this.type;
        cm.random = this.random;
        cm.value = this.value;
        cm.value2 = this.value2;
        cm.suit = this.suit;
        cm.faceUp = this.faceUp;
        cm.x = this.x;
        cm.y = this.y;
        cm.angle = this.angle;
        cm.depth = this.depth;
        var ms = new List<ModifierModel>();
        if (this.modifiers != null)
        {
            for (int i = 0; i < this.modifiers.Length; i++)
            {
                ms.Add(this.modifiers[i].DeepCopy());
            }
            cm.modifiers = ms.ToArray();
        }
        return cm;
    }

    public List<int> GetSuitRopeSuits()
    {
        if (modifiers == null || modifiers.Length == 0 || modifiers[0].properties.params3 == null)
            return new List<int>();
        return modifiers[0].properties.params3.ToList();
    }
}