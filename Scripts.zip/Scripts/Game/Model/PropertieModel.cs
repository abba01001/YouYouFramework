using System.Collections.Generic;
using System.Runtime.Serialization;

[System.Serializable]
public class PropertieModel
{
    public int plays;
    public int timer;
    public int interval;
    public int param1;
    public int param2;
    public int[] params3 = new int[]{};

    public PropertieModel DeepCopy()
    {
        PropertieModel pm = new PropertieModel();
        pm.plays = this.plays;
        pm.timer = this.timer;
        pm.interval = this.interval;
        pm.param1 = this.param1;
        pm.param2 = this.param2;
        pm.params3 = new List<int>(this.params3).ToArray();
        return pm;
    }
}
