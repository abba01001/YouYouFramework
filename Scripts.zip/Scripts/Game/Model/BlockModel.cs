[System.Serializable]
public class BlockModel
{
    public bool random;
    public string type;
    public int value;
}
