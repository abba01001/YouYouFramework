using System.Collections.Generic;

[System.Serializable]
public class SettingsModel
{
    public int[] cards_in_stack = new int[]{};
    public bool moving_scene;
    public SettingsModel DeepCopy()
    {
        SettingsModel sm = new SettingsModel();
        sm.moving_scene = this.moving_scene;
        sm.cards_in_stack = new List<int>(this.cards_in_stack).ToArray();

        return sm;
    }
}