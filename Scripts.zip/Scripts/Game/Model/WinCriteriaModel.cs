[System.Serializable]
public class WinCriteriaModel
{
    public string type;
}