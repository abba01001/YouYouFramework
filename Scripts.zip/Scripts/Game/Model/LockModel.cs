
[System.Serializable]
public class LockModel
{
    public int id;
    public float x;
    public float y;
    public float[] rect;
    public BlockModel[] blocks;
}
