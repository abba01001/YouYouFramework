[System.Serializable]
public class HandlePaidModel
{
    public int id;
    public int number;
    public int paidTime;
    public int priority;
}