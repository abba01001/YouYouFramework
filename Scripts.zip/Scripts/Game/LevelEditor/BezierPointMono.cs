using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BezierPointMono : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private Vector3 mouseDownPos;
	void OnMouseDown()
	{
		Vector3 pos = Camera.main.WorldToScreenPoint(transform .position);
		mouseDownPos = pos - Input.mousePosition;
	}
    void OnMouseDrag()
	{
		Vector3 pos = Camera.main.WorldToScreenPoint(transform .position);
		Vector3 mousePos = new Vector3(Input.mousePosition.x+mouseDownPos.x, Input.mousePosition.y+mouseDownPos.y, pos.z);
		transform.position = Camera.main.ScreenToWorldPoint(mousePos);
	}
}
