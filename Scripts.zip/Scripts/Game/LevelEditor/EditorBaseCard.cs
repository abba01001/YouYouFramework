using QFramework;
using UnityEngine;

#if UNITY_EDITOR

public partial class CardObjMono : MonoBehaviour
{
    private Vector3 mouseDownPos;
    void OnMouseDrag()
	{
		//TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent(){card = transform});
		
		// Vector3 pos = Camera.main.WorldToScreenPoint(transform .position);
		// Vector3 mousePos = new Vector3(Input.mousePosition.x+mouseDownPos.x, Input.mousePosition.y+mouseDownPos.y, pos.z);
		// transform.position = Camera.main.ScreenToWorldPoint(mousePos);
	}
}

public partial class BaseCard : MonoBehaviour
{
    [HideInInspector]
    public bool IsSel;

    public void OnEditorMouseDownEvent()
    {
		if(EditorMono.Instance.IsCardLine)
			return;
        SetSelectState();
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent(){card = transform});
    }

    public void SetSelectState()
    {
        IsSel = !IsSel;
        ShowSelectedColor(IsSel);
    }

	public void SetSelectState(bool sel)
    {
        IsSel = sel;
        ShowSelectedColor(IsSel);
    }

    public void ShowSelectedColor(bool sel)
	{
		MaterialPropertyBlock block = new MaterialPropertyBlock();
	    var renderer = GetComponentInChildren<SpriteRenderer>();
	    renderer.GetPropertyBlock(block);
		if (!sel)
		{
	        block.SetColor("_BlendColor", new Color32(255, 255, 255,255));
		}
		else
		{
	        block.SetColor("_BlendColor", new Color32(80, 255, 0, 255));
		}
		renderer.SetPropertyBlock(block);
	}
}

#endif