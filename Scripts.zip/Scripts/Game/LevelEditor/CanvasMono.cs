#if UNITY_EDITOR
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class CanvasMono : MonoBehaviour
{
    public Scrollbar scrollBar;

    private void Start()
    {
        GlobalRes.LoadOtherRes();
        TypeEventSystem.Register<EditorMoveSceneEvent>(OnEditorMoveSceneEvent);
    }

    private void OnDestroy()
    {
        TypeEventSystem.UnRegister<EditorMoveSceneEvent>(OnEditorMoveSceneEvent);
    }

    void OnEditorMoveSceneEvent(EditorMoveSceneEvent e)
    {
        scrollBar.gameObject.SetActive(e.show);
        scrollBar.value = 0;
    }

    public void GetValue(float f)
    {
        var width = 1334*3;
        EditorMono.Instance.MoveScene(-width*f);
    }
}
#endif