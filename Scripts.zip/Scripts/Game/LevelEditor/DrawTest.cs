using System;
using System.Collections;
using System.Collections.Generic;
using OBBUtils;
using QFramework;
using UnityEngine;
 
 
public class DrawTest : MonoBehaviour {
    public Material mat;
    private Vector2 FirstMousePosition;
    private Vector2 SecondMousePosition;
    private bool StartRectRender = false;
    private bool StartGridRender = false;

    
    void LateUpdate()
    {
        if (Input.GetKey(KeyCode.LeftShift))
        {
            StartGridRender = true;
        }
        else
        {
            StartGridRender = false;
        }
        if(Input.GetKey(KeyCode.LeftAlt))
        {
            if(Input.GetMouseButtonDown(0))
            {
                StartRectRender = true;
                FirstMousePosition = Input.mousePosition;
            }
            if (Input.GetMouseButtonUp(0))
            {
                if (StartRectRender)
                {
                    SelectGameObject();
                    ChangeTwoPoint();
                }
                StartRectRender = false;
                FirstMousePosition = SecondMousePosition = Vector2.zero;
                // EditorCommon.BeginRect = false;
            }
            if(StartRectRender)
                PickGameObject();
        }
        // else
        // {
        //     StartRectRender = false;
        //     FirstMousePosition = SecondMousePosition = Vector2.zero;
        // }
        SecondMousePosition = Input.mousePosition;
    }
 
    private void OnPostRender()
    {
        if (StartRectRender)
        {
            mat.SetPass(0);
            GL.LoadOrtho();
            GL.Begin(GL.QUADS);
            GL.Color(new Color(0,1,1,0.3f));
            DrawLine(FirstMousePosition.x, FirstMousePosition.y, SecondMousePosition.x, SecondMousePosition.y);
            GL.End(); 
        }

        if (StartGridRender)
        {
             DrawGrid();
        }
    }
    
    private void DrawLine(float x1, float y1, float x2, float y2)
    {
        GL.Vertex(new Vector3(x1 / Screen.width, y1 / Screen.height, 0));
        GL.Vertex(new Vector3(x2 / Screen.width, y1 / Screen.height, 0));
        GL.Vertex(new Vector3(x2 / Screen.width, y1 / Screen.height, 0));
        GL.Vertex(new Vector3(x2 / Screen.width, y2 / Screen.height, 0));
        GL.Vertex(new Vector3(x2 / Screen.width, y2 / Screen.height, 0));
        GL.Vertex(new Vector3(x1 / Screen.width, y2 / Screen.height, 0));
        GL.Vertex(new Vector3(x1 / Screen.width, y2 / Screen.height, 0));
        GL.Vertex(new Vector3(x1 / Screen.width, y1 / Screen.height, 0));
    }
    
    private void ChangeTwoPoint()
    {
        if (FirstMousePosition.x > SecondMousePosition.x)
        {
            float position1 = FirstMousePosition.x;
            FirstMousePosition.x = SecondMousePosition.x;
            SecondMousePosition.x = position1;
        }
        if (FirstMousePosition.y > SecondMousePosition.y)
        {
            float position2 = FirstMousePosition.y;
            FirstMousePosition.y = SecondMousePosition.y;
            SecondMousePosition.y = position2;
        }
    }
    
    private void PickGameObject()
    {
        var x1 = FirstMousePosition.x - Screen.width / 2f;
        var y1 = FirstMousePosition.y - Screen.height / 2f;
        var x2 = SecondMousePosition.x - Screen.width / 2f;
        var y2 = SecondMousePosition.y - Screen.height / 2f;

        if(Vector2.Distance(FirstMousePosition, SecondMousePosition) < 20)
            return;

        OBB obb = new OBB();
        obb.Pos = new Vec3((x2-x1)/2+x1, (y2-y1)/2+y1, 0);
        obb.Half_size = new Vec3(Math.Abs(x2-x1)/2, Math.Abs(y2-y1)/2, 0);
        obb.AxisX = new Vec3(1, 0, 0);
        obb.AxisY = new Vec3(0, 1, 0);
        obb.AxisZ = new Vec3(0, 0, 1);
        TypeEventSystem.Send<EditorRectCardsEvent>(new EditorRectCardsEvent(obb));
    }

    private void SelectGameObject()
    {
        var x1 = FirstMousePosition.x - Screen.width / 2f;
        var y1 = FirstMousePosition.y - Screen.height / 2f;
        var x2 = SecondMousePosition.x - Screen.width / 2f;
        var y2 = SecondMousePosition.y - Screen.height / 2f;
        OBB obb = new OBB();
        obb.Pos = new Vec3((x2-x1)/2+x1, (y2-y1)/2+y1, 0);
        obb.Half_size = new Vec3(Math.Abs(x2-x1)/2, Math.Abs(y2-y1)/2, 0);
        obb.AxisX = new Vec3(1, 0, 0);
        obb.AxisY = new Vec3(0, 1, 0);
        obb.AxisZ = new Vec3(0, 0, 1);
        // TypeEventSystem.Send<SelecteCardsEvent>(new SelecteCardsEvent(obb));
    }
    
    
    void DrawGrid()
    {
        mat.SetPass(0);
        GL.LoadOrtho();
        GL.Begin(GL.LINES);
        GL.Color(Color.yellow);
        var gap = 10;
        for (int i = 0; i <= Screen.width/gap; i++)
        {
            var posA = new Vector2(i * gap, 0);
            var posB = new Vector2(i*gap, Screen.height);
            GL.Vertex3(posA.x/ Screen.width, posA.y/ Screen.height, 0);
            GL.Vertex3(posB.x/ Screen.width, posB.y/ Screen.height, 0);
        }
        for (int i = 0; i <= Screen.height/gap; i++)
        {
            var posA = new Vector2(0, i * gap);
            var posB = new Vector2(Screen.width, i * gap);
            GL.Vertex3(posA.x/ Screen.width, posA.y/ Screen.height, 0);
            GL.Vertex3(posB.x/ Screen.width, posB.y/ Screen.height, 0);
        }
        GL.End();
 
    }

}