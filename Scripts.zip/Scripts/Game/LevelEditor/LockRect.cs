

using UnityEngine;

public class LockRect : MonoBehaviour
{
    public Transform[] controlPoints;
    public LineRenderer lineRenderer;

    private void Update()
    {
        Vector3 pos1 = controlPoints[0].transform.position; 
        Vector3 pos2 = controlPoints[1].transform.position; 
        Vector3 pos3 = controlPoints[2].transform.position; 
        Vector3 pos4 = controlPoints[3].transform.position; 
        lineRenderer.positionCount = 4;
        lineRenderer.SetPosition(0, pos1);
        lineRenderer.SetPosition(1, pos2);
        lineRenderer.SetPosition(2, pos3);
        lineRenderer.SetPosition(3, pos4);
    }
}