using QFramework;
using UnityEngine;

public partial class LockItem : MonoBehaviour
{
    public bool isSelected;
    
#if UNITY_EDITOR
    public void OnEditorMouseDownEvent()
    {
        if (EditorMono.Instance.IsCardLine)
            return;
        isSelected = !isSelected;
        TypeEventSystem.Send<EditorSelectedLockItemEvent>(new EditorSelectedLockItemEvent(isSelected));
        SetSelectState();
    }
#endif

    private void SetSelectState()
    {
        var children = GetComponentsInChildren<SpriteRenderer>();
        foreach (var item in children)
        {
            item.color = isSelected ? Color.green : Color.white;
        }
    }

}