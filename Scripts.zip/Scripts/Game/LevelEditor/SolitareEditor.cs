#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using DG.Tweening;
using OBBUtils;
using QFramework;
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using UniRx;
using UnityEditor;
using UnityEditor.Playables;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.Internal;
using SoliUtils;
using Random = UnityEngine.Random;

public enum EditorCardTypeEnum
{
    [LabelText("数值牌(value)")] Value = CardType.Value,
    [LabelText("双点牌(two_value)")] TwoValue = CardType.TwoValue,
    [LabelText("万能牌(joker)")] Joker = CardType.Joker,
    [LabelText("丰收牌(plus_three)")] Three = CardType.Three,
    [LabelText("单花色牌(gold)")] Gold = CardType.Gold,
    [LabelText("双花色牌(monochrome)")] Monochrome = CardType.Monochrome,
    [LabelText("仙人掌牌(boom)")] Boom = CardType.Boom,
    [LabelText("剪刀牌(zap)")] Zap = CardType.Zap,
    [LabelText("锁头牌(lock)")] Lock = CardType.Lock,
    [LabelText("钥匙牌(key)")] Key = CardType.Key,
    [LabelText("石头牌(anchor)")] Anchor = CardType.Anchor,
    [LabelText("复制牌(copy)")] Copy = CardType.Copy,
    [LabelText("风车牌(windmill)")] Windmill = CardType.Windmill,
    [LabelText("蝴蝶牌(banana)")] Banana = CardType.Banana,
    [LabelText("花朵牌(monkey)")] Monkey = CardType.Monkey,
    [LabelText("问号牌(question)")] Question = CardType.Question,
    [LabelText("船舵牌(rudder)")] Rudder = CardType.Rudder,
    // [LabelText("炮台牌(cannon)")] Cannon = CardType.Cannon,
}

public enum ModifierTypeEnum
{
    [LabelText("无")] None = 0,
    [LabelText("定时炮仗(bomb)")] Bomb = ModifierType.Bomb,
    [LabelText("大爆炸(new_bomb)")] BigBomb = ModifierType.BigBomb,
    [LabelText("上升牌(rising)")] Rising = ModifierType.Rising,
    [LabelText("下降牌(lowering)")] Lowering = ModifierType.Lowering,
    [LabelText("铁锹牌(water)")] Water = ModifierType.Water,
    [LabelText("冰冻牌(ice)")] Ice = ModifierType.Ice,
    [LabelText("闪电牌(lightning)")] Lightning = ModifierType.Lightning,
    [LabelText("绿叶牌(green_leaf)")] GreenLeaf = ModifierType.GreenLeaf,
    [LabelText("布帘牌(cloth)")] Cloth = ModifierType.Cloth,
    [LabelText("魔术布牌(magic_cloth)")] MagicCloth = ModifierType.MagicCloth,
    [LabelText("花色绳子牌(rope)")] Rope = ModifierType.SuitRope,
    [LabelText("拉绳牌(link_rope)")] LinkRope = ModifierType.LinkRope,
    [LabelText("蜥蜴牌(lizard)")] Lizard = ModifierType.Lizard,
    [LabelText("任务牌(task)")] Task = ModifierType.Task
}

public enum ValueCardEnum
{
    [LabelText("随机")] Random = -1,
    [LabelText("♣️A")] MeiHua1 = 0,
    [LabelText("♣️2")] MeiHua2 = 1,
    [LabelText("♣️3")] MeiHua3 = 2,
    [LabelText("♣️4")] MeiHua4 = 3,
    [LabelText("♣️5")] MeiHua5 = 4,
    [LabelText("♣️6")] MeiHua6 = 5,
    [LabelText("♣️7")] MeiHua7 = 6,
    [LabelText("♣️8")] MeiHua8 = 7,
    [LabelText("♣️9")] MeiHua9 = 8,
    [LabelText("♣️10")] MeiHua10 = 9,
    [LabelText("♣️J")] MeiHua11 = 10,
    [LabelText("♣️Q")] MeiHua12 = 11,
    [LabelText("♣️K")] MeiHua13 = 12,

    [LabelText("♥️A")] TaoXin1 = 13,
    [LabelText("♥️2")] TaoXin2 = 14,
    [LabelText("♥️3")] TaoXin3 = 15,
    [LabelText("♥️4")] TaoXin4 = 16,
    [LabelText("♥️5")] TaoXin5 = 17,
    [LabelText("♥️6")] TaoXin6 = 18,
    [LabelText("♥️7")] TaoXin7 = 19,
    [LabelText("♥️8")] TaoXin8 = 20,
    [LabelText("♥️9")] TaoXin9 = 21,
    [LabelText("♥️10")] TaoXin10 = 22,
    [LabelText("♥️J")] TaoXin11 = 23,
    [LabelText("♥️Q")] TaoXin12 = 24,
    [LabelText("♥️K")] TaoXin13 = 25,

    [LabelText("♠️A")] HeiTao1 = 26,
    [LabelText("♠️2")] HeiTao2 = 27,
    [LabelText("♠️3")] HeiTao3 = 28,
    [LabelText("♠️4")] HeiTao4 = 29,
    [LabelText("♠️5")] HeiTao5 = 30,
    [LabelText("♠️6")] HeiTao6 = 31,
    [LabelText("♠️7")] HeiTao7 = 32,
    [LabelText("♠️8")] HeiTao8 = 33,
    [LabelText("♠️9")] HeiTao9 = 34,
    [LabelText("♠️10")] HeiTao10 = 35,
    [LabelText("♠️J")] HeiTao11 = 36,
    [LabelText("♠️Q")] HeiTao12 = 37,
    [LabelText("♠️K")] HeiTao13 = 38,

    [LabelText("♦️A")] FangKuai1 = 39,
    [LabelText("♦️2")] FangKuai2 = 40,
    [LabelText("♦️3")] FangKuai3 = 41,
    [LabelText("♦️4")] FangKuai4 = 42,
    [LabelText("♦️5")] FangKuai5 = 43,
    [LabelText("♦️6")] FangKuai6 = 44,
    [LabelText("♦️7")] FangKuai7 = 45,
    [LabelText("♦️8")] FangKuai8 = 46,
    [LabelText("♦️9")] FangKuai9 = 47,
    [LabelText("♦️10")] FangKuai10 = 48,
    [LabelText("♦️J")] FangKuai11 = 49,
    [LabelText("♦️Q")] FangKuai12 = 50,
    [LabelText("♦️K")] FangKuai13 = 51,
}

public enum SuitTypeEnum
{
    [LabelText("随机")] Random = -1,
    [LabelText("♣️(0)")] MeiHua,
    [LabelText("♥️(1)")] HongTao,
    [LabelText("♠️(2)")] HeiTao,
    [LabelText("♦️(3)")] FangKuai,
}

public enum ColorTypeEnum
{
    [LabelText("随机")] Random = -1,
    [LabelText("♣️♠️(0|2)")] HeiSe,
    [LabelText("♥️♦️(1|3)")] HongSe,
}

public enum LockDirectionEnum
{
    [LabelText("左")] Left = -1,
    [LabelText("右")] Right,
}

public enum LockItemTypeEnum
{
    [LabelText("随机")] Random = 0,
    [LabelText("A")] Number1,
    [LabelText("2")] Number2,
    [LabelText("3")] Number3,
    [LabelText("4")] Number4,
    [LabelText("5")] Number5,
    [LabelText("6")] Number6,
    [LabelText("7")] Number7,
    [LabelText("8")] Number8,
    [LabelText("9")] Number9,
    [LabelText("10")] Number10,
    [LabelText("J")] Number11,
    [LabelText("Q")] Number12,
    [LabelText("K")] Number13,
    [LabelText("♣️")] Suit1,
    [LabelText("♥️")] Suit2,
    [LabelText("♠️")] Suit3,
    [LabelText("♦️")] Suit4,
    [LabelText("黑色")] ColorBlack,
    [LabelText("红色")] ColorRed,
}


public class SolitaireEditor : OdinEditorWindow
{
    public static LevelModel levelModel;
    public static bool IsHoldControl = false;
    public static int CardAutoId = 0;


    [MenuItem("关卡编辑器/Open")]
    private static void OpenWindow()
    {
        GetWindow<SolitaireEditor>().Show();
    }

    private void OnEnable()
    {
        GameCommon.IsEditorMode = true;
        GameCommon.IsAiMode = true;
        TypeEventSystem.Register<EditorShowCardInfoEvent>(OnEditorShowCardInfoEvent);
        TypeEventSystem.Register<AIEditorLevelResultEvent>(OnAIEditorLevelResultEvent);
        TypeEventSystem.Register<EditorMoveCardEvent>(OnEditorMoveCardEvent);
        TypeEventSystem.Register<EditorShowLockInfoEvent>(OnEditorShowLockInfoEvent);
    }

    private static bool isRunning = false;

    [OnInspectorGUI]
    [PropertyOrder(-10)] //, HorizontalGroup("Split", 80)]
    private void OnInspectorGUI()
    {
        isRunning = Application.isPlaying;
        GUILayout.Label(AssetDatabase.LoadAssetAtPath<Texture>("Assets/LevelEditor/editor.png"));
        if (!isRunning)
        {
            levelLoaded1 = true;
            levelLoaded2 = false;
            LevelInfo1 = "请先运行编辑器";
        }
        else
        {
            if (string.IsNullOrEmpty(FileName) || levelModel == null)
            {
                levelLoaded1 = false;
                levelLoaded2 = true;
                LevelInfo2 = "请输入有效关卡文件名并点击生成按钮";
            }
            else if (Stack.Length == 0)
            {
                levelLoaded1 = false;
                levelLoaded2 = true;
                LevelInfo2 = "牌堆不能为空";
            }
            else
            {
                if (levelModel != null)
                {
                    LevelInfo1 = $"关卡文件「{FileName}」读取成功";
                    levelLoaded1 = true;
                    levelLoaded2 = false;
                }
                else
                {
                    LevelInfo2 = $"关卡文件「{FileName}」读取失败";
                    levelLoaded1 = false;
                    levelLoaded2 = true;
                }
            }
        }
    }


    private string LevelInfo1;
    private string LevelInfo2;
    private bool levelLoaded1;
    private bool levelLoaded2;

    [InfoBox("$LevelInfo1", InfoMessageType.Info, "levelLoaded1")]
    [InfoBox("$LevelInfo2", InfoMessageType.Error, "levelLoaded2")]
    [PropertyOrder(1), ShowInInspector, LabelText("Json文件名")]
    public static string FileName = "";

    private void ShowCardNumInfo()
    {
        int d = EditorMono.Instance.GetCardNumber();
        int s = Stack?.Length ?? 0;
        LevelInfo3 = $"桌面牌数：{d}，手牌数：{s}";
        Repaint();
    }
    private string LevelInfo3;
    [InfoBox("$LevelInfo3", InfoMessageType.Info)]
    [PropertyOrder(1), ShowInInspector, LabelText("手牌堆"), OnValueChanged("ChangeStack", true)]
    public static ValueCardEnum[] Stack = { };

    private int stackCount;

    void ChangeStack()
    {
        if (stackCount != Stack.Length)
        {
            Stack[Stack.Length - 1] = ValueCardEnum.Random;
            stackCount = Stack.Length;
        }

        int[] intStack = new int[stackCount];
        for (int i = 0; i < stackCount; i++)
        {
            intStack[i] = (int)Stack[i];
        }

        EditorMono.Instance.ChangeHandCard(intStack);
        ShowCardNumInfo();
    }

    [Button("加载关卡"), PropertyOrder(2), PropertySpace(SpaceAfter = 20)]
    private void GenCards()
    {
        if (!LevelUtils.GetLevelModel(FileName, out levelModel))
            return;
        CleanShowLayer();
        EditorMono.Instance.CleanCards();
        CardAutoId = 0;
        int maxId = 0;
        foreach (var cm in levelModel.cards)
        {
            if (cm.id > maxId)
                maxId = cm.id;
        }
        CardAutoId = maxId;

        var lm = levelModel.DeepCopy();
        EditorMono.Instance.ReadLevelData(lm);
        EditorMono.Instance.ReView(lm);

        stackCount = levelModel.settings.cards_in_stack.Length;
        Stack = new ValueCardEnum[stackCount];
        for (int i = 0; i < stackCount; i++)
        {
            Stack[i] = (ValueCardEnum)(levelModel.settings.cards_in_stack[i]);
        }

        IsMovingScene = levelModel.settings.moving_scene;
        TypeEventSystem.Send<EditorMoveSceneEvent>(new EditorMoveSceneEvent(IsMovingScene));

        if (levelModel.locks != null && levelModel.locks.Length > 0)
        {
            EditorMono.Instance.CreateLockItem(levelModel.locks[0]);
        }

        ShowCardNumInfo();
    }

    [PropertyOrder(2), OnValueChanged("OnMovingScene"), ShowInInspector]
    [LabelText("是否滚动关卡")]
    public static bool IsMovingScene;

    void OnMovingScene()
    {
        if (!Input.GetMouseButton(0))
        {
            EditorMono.Instance.ChangeMoveSceneState(IsMovingScene);
            TypeEventSystem.Send<EditorMoveSceneEvent>(new EditorMoveSceneEvent(IsMovingScene));
        }
    }

    public bool IsSelectedOneCard
    {
        get
        {
            return Application.isPlaying && EditorMono.Instance.SelectedCardModel != null &&
                   EditorMono.Instance.GetSelectedCards().Count == 1;
        }
    }

    public bool IsSelectedMoreCards
    {
        get
        {
            return Application.isPlaying &&
                   EditorMono.Instance.GetSelectedCards().Count > 1;
        }
    }    

    

    [Button("一键数值牌"), PropertyOrder(2)]
    private void OneKeyValueCard()
    {
        EditorMono.Instance.OneKeyValueCard();
    }
    [Button("一键正面"), PropertyOrder(2)]
    private void OneKeyFaceup()
    {
        EditorMono.Instance.OneKeyFaceup(true);
    }
    [Button("一键反面"), PropertyOrder(2), PropertySpace(0, 20)]
    private void OneKeyFacedown()
    {
        EditorMono.Instance.OneKeyFaceup(false);
    }


    [ShowIfGroup("IsSelectedOneCard")]
    [BoxGroup("IsSelectedOneCard/卡牌信息", centerLabel: true), PropertyOrder(3), ReadOnly, ShowInInspector]
    [LabelText("卡牌ID")]
    public static int CardId;

    [ShowIfGroup("IsSelectedOneCard")]
    [BoxGroup("IsSelectedOneCard/卡牌信息", centerLabel: true), PropertyOrder(3), OnValueChanged("ChangeCardPos"),
     ShowInInspector]
    [LabelText("位置")]
    public static Vector3Int Position;

    void ChangeCardPos()
    {
        if (!Input.GetMouseButton(0))
        {
            var cardMono = EditorMono.Instance.SelectedCardMono;
            if (cardMono == null)
                return;
            var cardModel = EditorMono.Instance.SelectedCardModel;

            cardMono.transform.localPosition = Position;
            cardModel.Position = Position;
            EditorMono.Instance.SelectedCardModel = cardModel;
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), PropertyOrder(3), OnValueChanged("ChangeCardAngle"), ShowInInspector]
    [LabelText("角度")]
    public static int Angle;

    void ChangeCardAngle()
    {
        if (!Input.GetMouseButton(0))
        {
            var cardMono = EditorMono.Instance.SelectedCardMono;
            if (cardMono == null)
                return;

            var cardModel = EditorMono.Instance.SelectedCardModel;

            cardMono.CardAngle = Angle;
            cardModel.angle = Angle;
            EditorMono.Instance.SelectedCardModel = cardModel;
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), PropertyOrder(3), OnValueChanged("ChangeCardFaceup"), ShowInInspector]
    [LabelText("朝向")]
    public static bool Faceup;

    void ChangeCardFaceup()
    {
        if (!Input.GetMouseButton(0))
        {
            var cardMono = EditorMono.Instance.SelectedCardMono;
            if (cardMono == null)
                return;
            var cardModel = EditorMono.Instance.SelectedCardModel;

            cardMono.IsFaceUp = Faceup;
            cardModel.faceUp = Faceup;
            EditorMono.Instance.SelectedCardModel = cardModel;
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), PropertyOrder(3), OnValueChanged("ChangeCardType"), ShowInInspector]
    [LabelText("卡牌类型")]
    public static EditorCardTypeEnum TheCardType;

    void ChangeCardType()
    {
        Debug.Log("ChangeCardType");
        if (!Input.GetMouseButton(0))
        {
            EditorMono.Instance.ChangeSelectedCardsType(TheCardType);
            if (TheCardType == EditorCardTypeEnum.Value)
            {
                ChangeCardValue();
            }
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheCardType==EditorCardTypeEnum.Value"), PropertyOrder(3),
     OnValueChanged("ChangeCardValue"), ShowInInspector]
    [LabelText("面值")]
    public static ValueCardEnum Value;

    void ChangeCardValue()
    {
        if (!Input.GetMouseButton(0))
        {
            var cardMono = EditorMono.Instance.SelectedCardMono;
            if (cardMono == null)
                return;
            var cardModel = EditorMono.Instance.SelectedCardModel;
            cardModel.random = Value == ValueCardEnum.Random;
            cardModel.SetValue((int)Value);
            EditorMono.Instance.SelectedCardModel = cardModel;
            (cardMono as ValueCard)?.SetValue();
            ChangeModifierType();
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheCardType==EditorCardTypeEnum.TwoValue"), PropertyOrder(3),
     OnValueChanged("ChangeCardValue1"), ShowInInspector]
    [LabelText("面值1")]
    public static ValueCardEnum Value1;

    void ChangeCardValue1()
    {
        if (!Input.GetMouseButton(0))
        {
            var cardMono = EditorMono.Instance.SelectedCardMono;
            if (cardMono == null)
                return;
            var cardModel = EditorMono.Instance.SelectedCardModel;
            cardModel.random = Value1 == ValueCardEnum.Random;
            cardModel.SetValue((int)Value1);
            cardMono.CardData.Value = (int)Value1;
            EditorMono.Instance.SelectedCardModel = cardModel;
            (cardMono as TwoValueCard)?.SetValue();
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheCardType==EditorCardTypeEnum.TwoValue"), PropertyOrder(3),
     OnValueChanged("ChangeCardValue2"), ShowInInspector]
    [LabelText("面值2")]
    public static ValueCardEnum Value2;

    void ChangeCardValue2()
    {
        if (!Input.GetMouseButton(0))
        {
            var cardMono = EditorMono.Instance.SelectedCardMono;
            if (cardMono == null)
                return;
            var cardModel = EditorMono.Instance.SelectedCardModel;
            cardModel.random = Value2 == ValueCardEnum.Random;
            cardModel.SetValue2((int)Value2);
            cardMono.CardData.Value2 = (int)Value2;
            EditorMono.Instance.SelectedCardModel = cardModel;
            (cardMono as TwoValueCard)?.SetValue();
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheCardType==EditorCardTypeEnum.Value"), PropertyOrder(3),
     OnValueChanged("ChangeModifierType"), ShowInInspector]
    [LabelText("数值牌子类型")]
    public static ModifierTypeEnum TheModifierType;

    void ChangeModifierType()
    {
        if (TheCardType != EditorCardTypeEnum.Value)
            return;
        if (!Input.GetMouseButton(0))
        {
            EditorMono.Instance.ChangeSelectedCardModifier((ModifierType)TheModifierType);
            // Ropes.Clear();
            // if (TheModifierType == ModifierTypeEnum.Rope)
            // {
            //     Ropes.Add(SuitTypeEnum.MeiHua);
            //     ColorNum = 1;
            // }
            // EditorMono.Instance.RefreshCardRopes(Ropes);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheCardType==EditorCardTypeEnum.Three"), PropertyOrder(3),
     OnValueChanged("ChangeThreeCardValue"), ShowInInspector]
    [LabelText("丰收牌数量")]
    public static int ThreeCardValue = 1;

    void ChangeThreeCardValue()
    {
        if (!Input.GetMouseButton(0))
        {
            if (ThreeCardValue <= 0)
                ThreeCardValue = 1;
            if (ThreeCardValue >= 5)
                ThreeCardValue = 5;
            EditorMono.Instance.ChangeSelectedThreeCardValue(ThreeCardValue);
        }
    }


    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheModifierType==ModifierTypeEnum.BigBomb"), PropertyOrder(3),
     OnValueChanged("ChangeBigBombTimer"), ShowInInspector]
    [LabelText("大爆炸定时计数")]
    public static int BigBombTimer;

    void ChangeBigBombTimer()
    {
        if (TheModifierType != ModifierTypeEnum.BigBomb)
            return;
        if (!Input.GetMouseButton(0))
        {
            if (BigBombTimer <= 0)
                BigBombTimer = 1;
            EditorMono.Instance.ChangeSelectedCardBigBombTimer(BigBombTimer);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheModifierType==ModifierTypeEnum.Bomb"), PropertyOrder(3),
     OnValueChanged("ChangeBombTimer"), ShowInInspector]
    [LabelText("定时炮仗计数")]
    public static int BombTimer;

    void ChangeBombTimer()
    {
        if (TheModifierType != ModifierTypeEnum.Bomb)
            return;
        if (!Input.GetMouseButton(0))
        {
            if (BombTimer <= 0)
                BombTimer = 1;
            EditorMono.Instance.ChangeSelectedCardBombTimer(BombTimer);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheCardType==EditorCardTypeEnum.Gold"), PropertyOrder(3),
     OnValueChanged("ChangeCardSuit"), ShowInInspector]
    [LabelText("花色")]
    public static SuitTypeEnum Suit;

    void ChangeCardSuit()
    {
        if (!Input.GetMouseButton(0))
        {
            EditorMono.Instance.ChangeSelectedCardSuit((int)Suit);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheCardType==EditorCardTypeEnum.Monochrome||TheCardType==EditorCardTypeEnum.Rudder"), PropertyOrder(3),
     OnValueChanged("ChangeCardColor"), ShowInInspector]
    [LabelText("颜色")]
    public static ColorTypeEnum Color;

    void ChangeCardColor()
    {
        if (!Input.GetMouseButton(0))
        {
            var suit = -1;
            if (Color == ColorTypeEnum.HeiSe)
                suit = 0;
            else if (Color == ColorTypeEnum.HongSe)
                suit = 1;
            EditorMono.Instance.ChangeSelectedCardSuit((int)suit);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheModifierType==ModifierTypeEnum.Lightning"), PropertyOrder(3),
     OnValueChanged("ChangeLightningInitTimer"), ShowInInspector]
    [LabelText("初始计数")]
    public static int LightningInitTimer;

    void ChangeLightningInitTimer()
    {
        if (TheModifierType != ModifierTypeEnum.Lightning)
            return;
        if (!Input.GetMouseButton(0))
        {
            if (LightningInitTimer <= 0)
                LightningInitTimer = 1;
            EditorMono.Instance.ChangeSelectedCardLightningTimer(LightningInitTimer);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheModifierType==ModifierTypeEnum.Lightning"), PropertyOrder(3),
     OnValueChanged("ChangeLightningIntervalTimer"), ShowInInspector]
    [LabelText("间隔计数")]
    public static int LightningIntervalTimer;

    void ChangeLightningIntervalTimer()
    {
        if (TheModifierType != ModifierTypeEnum.Lightning)
            return;
        if (!Input.GetMouseButton(0))
        {
            if (LightningIntervalTimer <= 0)
                LightningIntervalTimer = 1;
            EditorMono.Instance.ChangeSelectedCardLightningTimer(LightningIntervalTimer, false);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"),
     ShowIf("@TheModifierType==ModifierTypeEnum.Cloth||TheModifierType==ModifierTypeEnum.MagicCloth"), PropertyOrder(3),
     OnValueChanged("ChangeClothIsOpen"), ShowInInspector]
    [LabelText("拉开")]
    public static bool ClothIsOpen;

    void ChangeClothIsOpen()
    {
        if (TheModifierType != ModifierTypeEnum.Cloth && TheModifierType != ModifierTypeEnum.MagicCloth)
            return;
        if (!Input.GetMouseButton(0))
        {
            bool isMagic = TheModifierType == ModifierTypeEnum.MagicCloth;
            EditorMono.Instance.ChangeSelectedCardClothIsOpen(ClothIsOpen, isMagic);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"),
     ShowIf("@TheModifierType==ModifierTypeEnum.Cloth||TheModifierType==ModifierTypeEnum.MagicCloth"), PropertyOrder(3),
     OnValueChanged("ChangeStateSwitchRound"), ShowInInspector]
    [LabelText("开合切换回合数(不能小于1)")]
    public static int StateSwitchRound = 1;

    void ChangeStateSwitchRound()
    {
        if (TheModifierType != ModifierTypeEnum.Cloth && TheModifierType != ModifierTypeEnum.MagicCloth)
            return;
        if (StateSwitchRound < 1) StateSwitchRound = 1;
        if (!Input.GetMouseButton(0))
        {
            bool isMagic = TheModifierType == ModifierTypeEnum.MagicCloth;
            EditorMono.Instance.ChangeSelectedCardClothStateSwitchRound(StateSwitchRound, isMagic);
        }
    }

    public readonly static List<SuitTypeEnum> Ropes = new List<SuitTypeEnum>();
    public static int ColorNum = 1;

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheModifierType==ModifierTypeEnum.Rope"), PropertyOrder(3),
     OnValueChanged("AddColor"), ShowInInspector]
    [Button("新增花色")]
    void AddColor()
    {
        if (!Input.GetMouseButton(0))
        {
            if (ColorNum >= 4) return;
            ColorNum++;
            Ropes.Add(SuitTypeEnum.MeiHua);
            EditorMono.Instance.RefreshCardRopes(Ropes);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheModifierType==ModifierTypeEnum.Rope"), PropertyOrder(3),
     OnValueChanged("RemoveColor"), ShowInInspector]
    [Button("移除花色")]
    void RemoveColor()
    {
        if (TheModifierType != ModifierTypeEnum.Rope)
            return;
        if (!Input.GetMouseButton(0))
        {
            if (ColorNum == 1) return; // 最少要有一种花色
            Ropes.RemoveAt(Ropes.Count - 1);
            ColorNum--;
            EditorMono.Instance.RefreshCardRopes(Ropes);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息/花色列表", centerLabel: true),
     ShowIf("@TheModifierType==ModifierTypeEnum.Rope&&ColorNum>=1"), PropertyOrder(3), OnValueChanged("RopeSelect1"),
     ShowInInspector]
    [LabelText("花色1")]
    public static SuitTypeEnum RopeSuit1 = SuitTypeEnum.MeiHua;

    void RopeSelect1()
    {
        if (TheModifierType != ModifierTypeEnum.Rope)
            return;
        if (!Input.GetMouseButton(0))
        {
            Ropes[0] = RopeSuit1;
            EditorMono.Instance.RefreshCardRopes(Ropes);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息/花色列表"), ShowIf("@TheModifierType==ModifierTypeEnum.Rope&&ColorNum>=2"),
     PropertyOrder(3), OnValueChanged("RopeSelect2"), ShowInInspector]
    [LabelText("花色2")]
    public static SuitTypeEnum RopeSuit2 = SuitTypeEnum.MeiHua;

    void RopeSelect2()
    {
        if (TheModifierType != ModifierTypeEnum.Rope)
            return;
        if (!Input.GetMouseButton(0))
        {
            Ropes[1] = RopeSuit2;
            EditorMono.Instance.RefreshCardRopes(Ropes);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息/花色列表"), ShowIf("@TheModifierType==ModifierTypeEnum.Rope&&ColorNum>=3"),
     PropertyOrder(3), OnValueChanged("RopeSelect3"), ShowInInspector]
    [LabelText("花色3")]
    public static SuitTypeEnum RopeSuit3 = SuitTypeEnum.MeiHua;

    void RopeSelect3()
    {
        if (TheModifierType != ModifierTypeEnum.Rope)
            return;
        if (!Input.GetMouseButton(0))
        {
            Ropes[2] = RopeSuit3;
            EditorMono.Instance.RefreshCardRopes(Ropes);
        }
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息/花色列表"), ShowIf("@TheModifierType==ModifierTypeEnum.Rope&&ColorNum==4"),
     PropertyOrder(3), OnValueChanged("RopeSelect4"), ShowInInspector]
    [LabelText("花色4")]
    public static SuitTypeEnum RopeSuit4 = SuitTypeEnum.MeiHua;

    void RopeSelect4()
    {
        if (TheModifierType != ModifierTypeEnum.Rope)
            return;
        if (!Input.GetMouseButton(0))
        {
            Ropes[3] = RopeSuit4;
            EditorMono.Instance.RefreshCardRopes(Ropes);
        }
    }

    private void SetRopeSuits(List<int> list)
    {
        Ropes.Clear();
        ColorNum = list.Count;
        int idx = 1;
        foreach (var item in list)
        {
            Ropes.Add((SuitTypeEnum)item);
            if (idx == 1)
                RopeSuit1 = (SuitTypeEnum)item;
            else if (idx == 2)
                RopeSuit2 = (SuitTypeEnum)item;
            else if (idx == 3)
                RopeSuit3 = (SuitTypeEnum)item;
            else if (idx == 4)
                RopeSuit4 = (SuitTypeEnum)item;
            idx++;
        }
        EditorMono.Instance.RefreshCardRopes(Ropes);
    }

    [BoxGroup("IsSelectedOneCard/卡牌信息"), ShowIf("@TheModifierType==ModifierTypeEnum.LinkRope"),
     PropertyOrder(3), OnValueChanged("ChangeLinkRopeCardId"), ShowInInspector]
    [LabelText("对应拉绳牌ID")]
    public static int LinkRopeCardId;

    void ChangeLinkRopeCardId()
    {
        if (!Input.GetMouseButton(0))
        {
            EditorMono.Instance.RefreshLinkRope(LinkRopeCardId);
        }
    }




    [BoxGroup("卡牌层级显示控制"),PropertyOrder(4),LabelText("开始层级"),ShowInInspector,OnValueChanged("SetShowLayerCard")]
    public static int ShowStartLayer = -999;
    [BoxGroup("卡牌层级显示控制"),PropertyOrder(4),LabelText("结束层级"),ShowInInspector,OnValueChanged("SetShowLayerCard")]
    public static int ShowEndLayer = 999;
    private void SetShowLayerCard()
    {
        if(EditorMono.Instance.GetDeskCard().Count <= 0) return;
        foreach (var VARIABLE in EditorMono.Instance.GetDeskCard())
        {
            if (VARIABLE.Value != null)
            {
                Vector3 pos = VARIABLE.Value.transform.position;
                float depth = pos.z;
                VARIABLE.Value.SetActive(depth >= ShowStartLayer && depth <= ShowEndLayer);
            }
        }
    }

    private void CleanShowLayer()
    {
        ShowStartLayer = -999;
        ShowEndLayer = 999;
        SetShowLayerCard();
    }


    [Button("新增卡牌"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@!IsSelectedOneCard&&!IsSelectedMoreCards&&!isCardLine&&!isAddLock")]
    private void AddCard()
    {
        var cm = new CardModel(++CardAutoId, CardType.Value, faceUp: true,
            x: -Constants.ResolutionWidth / 2 + 60,
            y: -Constants.ResolutionHeight / 2 + 80,
            depth: 0,
            angle: 0
        );
        cm.modifiers = new ModifierModel[] { };
        EditorMono.Instance.NewCard(cm);
        ShowCardNumInfo();
    }

    [Button("复制卡牌"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@IsSelectedOneCard&&!IsSelectedMoreCards&&!isCardLine")]
    private void CopyCard()
    {
        EditorMono.Instance.CopyCard(ref CardAutoId);
        Repaint();
        ShowCardNumInfo();
    }

    [Button("删除卡牌"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@IsSelectedOneCard")]
    private void DeleteCard()
    {
        EditorMono.Instance.DeleteCard();
        Repaint();
        ShowCardNumInfo();
    }

    private static bool isCardLine;

    [Button("新增卡牌组"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@!IsSelectedOneCard&&!IsSelectedMoreCards&&!isCardLine&&!isAddLock")]
    private void AddLineCard()
    {
        LineCardNum = 3;
        LineCardDepth = 0;
        LineCardDepthInterval = -1;
        EditorMono.Instance.CreateCardLine(LineCardNum, LineCardFaceup);
        isCardLine = true;
        ShowCardNumInfo();
    }

    [ShowIfGroup("isCardLine")]
    [BoxGroup("isCardLine/卡牌组信息", centerLabel: true), ShowInInspector]
    [PropertyOrder(3), OnValueChanged("ChangeLineCardNum")]
    [LabelText("卡牌数量")]
    public static int LineCardNum;

    void ChangeLineCardNum()
    {
        EditorMono.Instance.RenumCardLine(LineCardNum, LineCardFaceup);
    }

    [BoxGroup("isCardLine/卡牌组信息"), ShowInInspector, PropertyOrder(3), OnValueChanged("ChangeLineCardDepth")]
    [LabelText("初始Z轴")]
    public static int LineCardDepth;

    void ChangeLineCardDepth()
    {
        EditorMono.Instance.RedepthCardLine(LineCardDepth);
    }

    [BoxGroup("isCardLine/卡牌组信息"), ShowInInspector, PropertyOrder(3), OnValueChanged("ChangeLineCardDepthInterval")]
    [LabelText("Z轴间隔")]
    public static int LineCardDepthInterval;

    void ChangeLineCardDepthInterval()
    {
        EditorMono.Instance.ReintervalCardLine(LineCardDepthInterval);
    }

    [BoxGroup("isCardLine/卡牌组信息"), ShowInInspector, PropertyOrder(3), OnValueChanged("ChangeLineCardFaceup")]
    [LabelText("朝向")]
    public static bool LineCardFaceup = true;

    void ChangeLineCardFaceup()
    {
        EditorMono.Instance.RefaceupCardLine(LineCardFaceup);
    }

    [BoxGroup("isCardLine/卡牌组信息"), ShowInInspector, PropertyOrder(3)]
    [Button("确定卡牌组")]
    private void ConfirmLineCard()
    {
        isCardLine = false;
        EditorMono.Instance.ConfirmLineCard(ref CardAutoId);
        ShowCardNumInfo();
    }

    [BoxGroup("isCardLine/卡牌组信息"), ShowInInspector, PropertyOrder(3)]
    [Button("放弃卡牌组")]
    private void DeleteLineCard()
    {
        isCardLine = false;
        EditorMono.Instance.DeleteLineCard();
    }

    private void SelectedLockItem()
    {
        var lockModel = EditorMono.Instance.GetLockModel();
        var lockItemsList = new List<LockItemTypeEnum>();
        lockItems = new LockItemTypeEnum[] { };
        if (lockModel != null && lockModel.blocks != null && lockModel.blocks.Length > 0)
        {
            foreach (var item in lockModel.blocks)
            {
                if (item.random)
                {
                    lockItemsList.Add(LockItemTypeEnum.Random);
                }
                else if (item.type == "value")
                {
                    lockItemsList.Add((LockItemTypeEnum)item.value);
                }
                else if (item.type == "suit")
                {
                    lockItemsList.Add(LockItemTypeEnum.Suit1 + item.value);
                }
                else if (item.type == "color")
                {
                    lockItemsList.Add(LockItemTypeEnum.ColorBlack + item.value);
                }
            }
        }
    }

    [Button("加锁"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@!IsSelectedOneCard&&!IsSelectedMoreCards&&!isCardLine&&!isAddLock")]
    private void AddLockItem()
    {
        var levelModel = EditorMono.Instance.LevelDataStack.Peek();
        if (levelModel.locks == null || levelModel.locks.Length == 0)
        {
            EditorMono.Instance.CreateLockItem();
            isAddLock = true;
        }

        SelectedLockItem();
    }

    private static bool isAddLock;

    [ShowIfGroup("isAddLock")]
    [BoxGroup("isAddLock/锁头信息", centerLabel: true), ShowInInspector]

    // [BoxGroup("isAddLock/锁头信息"), PropertyOrder(3), OnValueChanged("ChangeLockDirectionEnum")]
    // [LabelText("锁定方位")]
    // public static LockDirectionEnum lockDirectionEnum = LockDirectionEnum.Right;
    // void ChangeLockDirectionEnum()
    // {

    // }
    [BoxGroup("isAddLock/锁头信息"), PropertyOrder(3), OnValueChanged("ChangeLockItemTypeEnum", true)]
    [LabelText("锁头类型")]
    private static LockItemTypeEnum[] lockItems = { };

    private static LockItemTypeEnum[] lastLockItems = { };

    void ChangeLockItemTypeEnum()
    {
        // if(lastLockItems.Length < lockItems.Length)
        // {
        // }
        // lastLockItems = lockItems;
        EditorMono.Instance.ChangeLockItems(lockItems);
    }

    [BoxGroup("isAddLock/锁头信息"), PropertyOrder(4), PropertySpace(5)]
    [Button("删除锁头")]
    private void DeleteLock()
    {
        EditorMono.Instance.DeleteLockItem();
        isAddLock = false;
        Repaint();
    }

    [BoxGroup("isAddLock/锁头信息"), PropertyOrder(4), PropertySpace(5)]
    [Button("完成")]
    private void SaveLock()
    {
        EditorMono.Instance.DeleteLockItem();
        isAddLock = false;
        Repaint();
    }

    private void OnEditorShowLockInfoEvent(EditorShowLockInfoEvent e)
    {
        isAddLock = e.sel;
        if (e.sel)
        {
            SelectedLockItem();
        }

        Repaint();
    }


    private void OnEditorShowCardInfoEvent(EditorShowCardInfoEvent e)
    {
        var cardMono = EditorMono.Instance.SelectedCardMono;
        var cardModel = EditorMono.Instance.SelectedCardModel;
        EditorMono.Instance.CheckSelected(cardMono.transform, IsHoldControl);

        CardId = cardModel.id;
        Position = ToVector3Int(cardMono.transform.localPosition);
        Angle = cardMono.CardAngle;
        Faceup = cardMono.IsFaceUp;
        Value = (ValueCardEnum)cardModel.GetValue();
        Value1 = Value;
        Value2 = (ValueCardEnum)cardModel.GetValue2();

        TheCardType = (EditorCardTypeEnum)cardModel.cardType;
        ThreeCardValue = cardModel.GetValue();
        if (cardModel.HasBomb())
        {
            TheModifierType = ModifierTypeEnum.Bomb;
            BombTimer = cardModel.BombTimer;
            if (BombTimer == 0)
            {
                BombTimer = 1;
                EditorMono.Instance.ChangeSelectedCardBombTimer(BombTimer);
            }
        }
        else if (cardModel.HasBigBomb())
        {
            TheModifierType = ModifierTypeEnum.BigBomb;
            BigBombTimer = cardModel.BigBombTimer;
            if (BigBombTimer == 0)
            {
                BigBombTimer = 1;
                EditorMono.Instance.ChangeSelectedCardBigBombTimer(BigBombTimer);
            }
        }
        else if (cardModel.HasIce())
            TheModifierType = ModifierTypeEnum.Ice;
        else if (cardModel.HasLowering())
            TheModifierType = ModifierTypeEnum.Lowering;
        else if (cardModel.HasRising())
            TheModifierType = ModifierTypeEnum.Rising;
        else if (cardModel.HasWater())
            TheModifierType = ModifierTypeEnum.Water;
        else if (cardModel.HasLightning())
        {
            TheModifierType = ModifierTypeEnum.Lightning;
            LightningInitTimer = cardModel.GetLightningTimer(true);
            LightningIntervalTimer = cardModel.GetLightningTimer(false);
            if (LightningInitTimer == 0)
            {
                LightningInitTimer = 1;
                EditorMono.Instance.ChangeSelectedCardLightningTimer(LightningInitTimer, true);
            }
            if (LightningIntervalTimer == 0)
            {
                LightningIntervalTimer = 1;
                EditorMono.Instance.ChangeSelectedCardLightningTimer(LightningIntervalTimer, false);
            }
        }
        else if (cardModel.HasGreenLeaf())
            TheModifierType = ModifierTypeEnum.GreenLeaf;
        else if (cardModel.HasCloth())
        {
            TheModifierType = ModifierTypeEnum.Cloth;
            ClothIsOpen = cardModel.GetClothOpen(ModifierType.Cloth);
            StateSwitchRound = cardModel.GetClothTimer(ModifierType.Cloth);
            if (StateSwitchRound == 0)
            {
                StateSwitchRound = 1;
                EditorMono.Instance.ChangeSelectedCardClothStateSwitchRound(StateSwitchRound, false);
            }
        }
        else if (cardModel.HasMagicCloth())
        {
            TheModifierType = ModifierTypeEnum.MagicCloth;
            ClothIsOpen = cardModel.GetClothOpen(ModifierType.MagicCloth);
            StateSwitchRound = cardModel.GetClothTimer(ModifierType.MagicCloth);
            if (StateSwitchRound == 0)
            {
                StateSwitchRound = 1;
                EditorMono.Instance.ChangeSelectedCardClothStateSwitchRound(StateSwitchRound, true);
            }
        }
        else if (cardModel.HasSuitRope())
        {
            TheModifierType = ModifierTypeEnum.Rope;
            SetRopeSuits(cardModel.GetSuitRopeSuits());
        }
        else if (cardModel.HasLinkRope())
        {
            TheModifierType = ModifierTypeEnum.LinkRope;
            LinkRopeCardId = cardModel.LinkRopeCardId;
        }
        else if (cardModel.HasLizard())
            TheModifierType = ModifierTypeEnum.Lizard;
        else if (cardModel.HasTask())
            TheModifierType = ModifierTypeEnum.Task;
        else
        {
            TheModifierType = ModifierTypeEnum.None;
            BombTimer = 0;
            BigBombTimer = 0;
            LinkRopeCardId = 0;
        }

        Suit = (SuitTypeEnum)cardModel.suit;
        Color = cardModel.suit == -1
            ? ColorTypeEnum.Random
            : (cardModel.suit == 0 || cardModel.suit == 2 ? ColorTypeEnum.HeiSe : ColorTypeEnum.HongSe);
        Repaint();
    }

    [Button("批量翻牌"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@IsSelectedMoreCards")]
    private void FlopGroup()
    {
        EditorMono.Instance.FlopGroup();
    }

    [Button("批量复制"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@IsSelectedMoreCards")]
    private void CopyGroup()
    {
        EditorMono.Instance.CopyGroup(ref CardAutoId);
    }

    [Button("批量删除"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@IsSelectedMoreCards")]
    private void DeleteGroup()
    {
        EditorMono.Instance.DeleteGroup();
    }

    [Button("Y轴对称"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@IsSelectedMoreCards")]
    private void FlipYGroup()
    {
        EditorMono.Instance.FlipYGroup(ref CardAutoId);
    }

    [Button("X轴对称"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@IsSelectedMoreCards")]
    private void FlipXGroup()
    {
        EditorMono.Instance.FlipXGroup(ref CardAutoId);
    }

    [Button("中心对称"), PropertyOrder(4), PropertySpace(5)]
    [ShowIf("@IsSelectedMoreCards")]
    private void FlipCenterGroup()
    {
        EditorMono.Instance.FlipCenterGroup(ref CardAutoId);
    }


    private void OnGUI()
    {
        base.OnImGUI();
        IsHoldControl = Event.current.control;

        wantsMouseMove = true;
        wantsMouseEnterLeaveWindow = true;
        if (Event.current.type == EventType.MouseEnterWindow)
        {
            if (mouseOverWindow != null)
                mouseOverWindow.Focus();
        }
        else if (Event.current.type == EventType.MouseLeaveWindow)
        {
            if (mouseOverWindow != null)
                mouseOverWindow.Focus();
        }
    }

    private void DoRepaint()
    {
        var lm = EditorMono.Instance.LevelDataStack.Peek();
        var stackCount = lm.settings.cards_in_stack.Length;
        Stack = new ValueCardEnum[stackCount];
        for (int i = 0; i < stackCount; i++)
        {
            Stack[i] = (ValueCardEnum)lm.settings.cards_in_stack[i];
        }

        Repaint();
    }

    [Button("取消选中"), GUIColor(1f, 0f, 0f, 1f), PropertyOrder(4), PropertySpace(20, 20)]
    [ShowIf("@IsSelectedOneCard||IsSelectedMoreCards&&!isCardLine")]
    private void CancelSelected()
    {
        EditorMono.Instance.CancelSelected();
    }


    private static string SaveInfo;
    private static bool ShowSaveInfo;

    [InfoBox("$SaveInfo", InfoMessageType.Error, "ShowSaveInfo")]
    [Button("保存(明文以及加密)"), PropertyOrder(4), PropertySpace(20, 20)]
    private void Save()
    {
        int[] intStack = new int[stackCount];
        for (int i = 0; i < stackCount; i++)
        {
            intStack[i] = (int)Stack[i];
        }

        EditorMono.Instance.ChangeHandCard(intStack);
        var lm = EditorMono.Instance.LevelDataStack.Peek();

        string info = "";
        foreach (var item1 in lm.cards)
        {
            if (item1.cardType == CardType.Value)
            {
                if (item1.GetValue() == (int)ValueCardEnum.Random)
                {
                    item1.random = true;
                }
                
                if(item1.modifiers != null)
                {
                    foreach (var mod in item1.modifiers)
                    {
                        if(mod.type == "bomb" && mod.properties.timer == 0)
                        {
                            mod.properties.timer = 1;
                        }
                        else if(mod.type == "new_bomb" && mod.properties.timer == 0)
                        {
                            mod.properties.timer = 1;
                        }
                        else if(mod.type == "lightning" && mod.properties.timer == 0)
                        {
                            mod.properties.timer = 1;
                            mod.properties.interval = 1;
                        }
                        else if(mod.type == "cloth" && mod.properties.timer == 0)
                        {
                            mod.properties.timer = 1;
                            mod.properties.interval = 1;
                        }
                        else if(mod.type == "magicCloth" && mod.properties.timer == 0)
                        {
                            mod.properties.timer = 1;
                            mod.properties.interval = 1;
                        }
                    }
                }
            }
            else if (item1.cardType == CardType.Gold)
            {
                if (item1.suit == (int)ValueCardEnum.Random)
                {
                    item1.random = true;
                }
            }
            else if (item1.cardType == CardType.Monochrome)
            {
                if (item1.suit == (int)ValueCardEnum.Random)
                {
                    item1.random = true;
                }
            }
            var cardWidth = Constants.CardSize.x * Constants.CardSizeScale.x;
            var cardHeight = Constants.CardSize.y * Constants.CardSizeScale.y;
            if (item1.cardType == CardType.TwoValue)
            {
                cardWidth = cardWidth * Constants.TwoValueCardSizeScale.x;
                cardHeight = cardHeight * Constants.TwoValueCardSizeScale.y;
            }
            var obb1 = CardData.CreateObb(item1, cardWidth, cardHeight);
            foreach (var item2 in lm.cards)
            {
                if (item1.id != item2.id)
                {
                    var cardWidth2 = Constants.CardSize.x * Constants.CardSizeScale.x;
                    var cardHeight2 = Constants.CardSize.y * Constants.CardSizeScale.y;
                    if (item2.cardType == CardType.TwoValue)
                    {
                        cardWidth2 = cardWidth2 * Constants.TwoValueCardSizeScale.x;
                        cardHeight2 = cardHeight2 * Constants.TwoValueCardSizeScale.y;
                    }
                    var obb2 = CardData.CreateObb(item2, cardWidth2, cardHeight2);
                    if (item1.depth == item2.depth && OBBCollision.GetCollision(obb1, obb2))
                    {
                        var str = $"存在相交且层级一样的卡牌:【{item1.id}:({item1.x},{item1.y})】 【{item2.id}:({item2.x},{item2.y})】\n";
                        info += str;
                        Debug.LogWarning(str);
                        // return;
                    }
                }
            }
        }


        foreach (var item1 in lm.cards)
        {
            if (item1.HasLinkRope())
            {
                bool vaild = false;
                foreach (var item2 in lm.cards)
                {
                    if (item2.id == item1.LinkRopeCardId && item2.HasLinkRope())
                    {
                        vaild = true;
                        break;
                    }
                }
                if (!vaild)
                {
                    var str = $"存在不成对的拉绳牌【{item1.id}:({item1.x},{item1.y})】\n";
                    info += str;
                }
            }
        }

        foreach (var item in lm.cards)
        {
            if (item.x < -1624 / 2 || (!lm.settings.moving_scene && item.x > 1624 / 2) || item.y < -750 / 2 ||
                item.y > 750 / 2)
            {
                var str = $"存在不在合法区域内的卡牌【{item.id}:({item.x},{item.y})】\n";
                info += str;
                Debug.LogWarning(str);
            }
        }

        ShowSaveInfo = false;
        if (!string.IsNullOrEmpty(info))
        {
            ShowSaveInfo = true;
            SaveInfo = info;
        }

        var json = JsonUtility.ToJson(lm);
        LevelUtils.SaveLevelModel(FileName, json);
        Debug.Log("保存成功");
    }

    public static Vector3Int ToVector3Int(Vector3 vec)
    {
        return new Vector3Int((int)vec.x, (int)vec.y, (int)vec.z);
    }


    private static bool AITest = true;


    // [BoxGroup("AITest/难度模拟器", centerLabel: true), PropertyOrder(5), ShowInInspector]
    // [BoxGroup("AITest/难度模拟器"), OnValueChanged("ChangeLevel")]
    // [LabelText("Level")]
    // public static int Level = 1;

    private void ChangeLevel()
    {
        // var configService = MainContainer.Container.Resolve<IConfigService>();
        // configService.HandleLevelConfig.TryGetValue(Level, out var hLevelCfg);
        // if (hLevelCfg == null)
        // {
        //     hLevelCfg = configService.HandleLevelConfig.Last().Value;
        // }
        // int label = GameUtils.RandomValueFromFormatString(hLevelCfg.group);
        // configService.HandleLabelConfig.TryGetValue(label, out var hLabelCfg);
        // if (hLabelCfg == null)
        // {
        //     hLabelCfg = configService.HandleLabelConfig.Last().Value;
        // }
        // int result = GameUtils.RandomValueFromFormatString(hLabelCfg.result);
        // configService.HandleResultConfig.TryGetValue(result, out var hResultCfg);
        // if (hResultCfg == null)
        // {
        //     hResultCfg = configService.HandleResultConfig.Last().Value;
        // }

        // LinkRate = hResultCfg.linkRate;
        // ComboRate = hResultCfg.comboRate;
    }


    [ShowIfGroup("AITest")]
    [InfoBox("模拟之前需要先保存", InfoMessageType.Info)]

    [BoxGroup("AITest/难度模拟器"), PropertyOrder(5), LabelText("纯随机"), OnValueChanged("ChangeRandomRate"), ShowInInspector]
    public static bool RandomRate = true;
    private void ChangeRandomRate()
    {
        if (RandomRate)
        {
            FixedResult = false;
            FixedLevel = false;
        }
        else
        {
            FixedResult = true;
            FixedLevel = false;
        }
    }

    [BoxGroup("AITest/难度模拟器"), PropertyOrder(5), LabelText("固定结果"), OnValueChanged("ChangeFixedRate"), ShowInInspector]
    public static bool FixedResult = false;
    private void ChangeFixedRate()
    {
        if (FixedResult)
        {
            RandomRate = false;
            FixedLevel = false;
        }
        else
        {
            RandomRate = true;
            FixedLevel = false;
        }
    }
    [BoxGroup("AITest/难度模拟器"), PropertyOrder(5), LabelText("result"), ShowIf("@FixedResult==true"), ShowInInspector]
    public static int result = 1;

    [BoxGroup("AITest/难度模拟器"), PropertyOrder(5), LabelText("模拟关卡"), OnValueChanged("ChangeFixedLevel"), ShowInInspector]
    public static bool FixedLevel = false;
    private void ChangeFixedLevel()
    {
        if (FixedLevel)
        {
            RandomRate = false;
            FixedResult = false;
        }
        else
        {
            RandomRate = true;
            FixedResult = false;
        }
    }
    [BoxGroup("AITest/难度模拟器"), PropertyOrder(5), LabelText("level"), ShowIf("@FixedLevel==true"), ShowInInspector]
    public static int level = 1;



    [BoxGroup("AITest/难度模拟器"), PropertyOrder(5), LabelText("道具次数"), ShowInInspector]
    public static int ToolNum = 0;

    [BoxGroup("AITest/难度模拟器"), PropertyOrder(5), LabelText("模拟次数"), ShowInInspector]
    public static int AITimes = 30;

    [BoxGroup("AITest/难度模拟器"), PropertyOrder(5), LabelText("胜率"), ReadOnly, GUIColor(0f, 1f, 0f, 1f), ShowInInspector]
    public static string WinRate = "null";

    [BoxGroup("AITest/难度模拟器"), Button("开始模拟"), PropertyOrder(5), ShowInInspector]
    private void DoAI()
    {
        WinRate = "模拟计算中";
        UniRx.Observable.NextFrame().Subscribe(a =>
        {
            var levelModel = EditorMono.Instance.LevelDataStack.Peek();
            TypeEventSystem.Send(new AIEditorStartLevelEvent(
                levelModel.DeepCopy(),
                ToolNum,
                AITimes,
                RandomRate,
                FixedResult,
                FixedLevel,
                result,
                level));
        });
    }

    void OnAIEditorLevelResultEvent(AIEditorLevelResultEvent e)
    {
        WinRate = $"{e.winRate * 100}%";
        InternalEditorUtility.RepaintAllViews();
    }

    void OnEditorMoveCardEvent(EditorMoveCardEvent e)
    {
        Position = ToVector3Int(e.card.transform.localPosition);
        Repaint();
    }
}

#endif