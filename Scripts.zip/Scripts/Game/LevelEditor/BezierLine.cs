using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEditor;
using UnityEngine;

public class BezierLine : MonoBehaviour
{
    public int CardNumber = 3;
    public int FirstDepth = 0;
    public int DepthInterval = -1;
    private bool _faceup;
    public bool Faceup
    {
        get => _faceup;
        set
        {
            _faceup = value;
            foreach (var card in cardList)
            {
                card.GetComponent<BaseCard>().IsFaceUp = value;
            }
        }
    }

    public List<GameObject> cardList = new List<GameObject>();

    private void Start()
    {
    }

    public void CreateCards(int num, bool faceup = true)
    {
        CardNumber = num;
        foreach (var card in cardList)
        {
            Destroy(card);
        }
        cardList.Clear();
        for (int i = 0; i < CardNumber; i++)
        {
            var cm = new CardModel(i, CardType.Value, true, -1, faceup);
            cardList.Add(CreateCard(i, cm));
        }
        Faceup = faceup;
    }

    GameObject CreateCard(int cardId, CardModel cardModel)
    {
        var gameObjType = Constants.CardType2ObjDic[cardModel.cardType];
        var card = GameObjManager.Instance.PopGameObject(gameObjType);
        card.transform.parent = Camera.main.transform.parent;
        card.SetActive(true);
        var cardMono = card.GetComponent<BaseCard>();
        cardMono.CardId = cardId;
        CardData cardData = new CardData(cardId, cardModel);
        cardMono.SetData(cardData, 0);
        return cardMono.gameObject;
    }

    public void Update()
    {
        var line = GetComponent<LineRenderer>();
        var count = line.positionCount;
        if (count < CardNumber)
            return;
        if (cardList.Count < CardNumber)
            return;
        for (int i = 0; i < CardNumber; i++)
        {
            Vector3 pos1, pos2;
            if (i == 0)
            {
                pos1 = line.GetPosition(0);
                pos2 = line.GetPosition(1);
            }
            else
            {
                var idx = (int)((count / (float)(CardNumber-1)) * i - 1);
                pos1 = line.GetPosition(idx-1);
                pos2 = line.GetPosition(idx);
            }

            var card = cardList[i];
            var pos = pos1 + (pos2 - pos1);
            pos.z = FirstDepth + i * DepthInterval;
            card.transform.position = pos;
            var dir = pos2 - pos1;
            double angle = Vector3.Angle(dir, new Vector3(1, 0, 0));// * (360/Math.PI);
            if (dir.y < 0)
                angle = -angle;
            card.transform.eulerAngles = Vector3.zero;
            card.transform.Rotate(new Vector3(0,0,(float)angle));
        }
        
    }
}
