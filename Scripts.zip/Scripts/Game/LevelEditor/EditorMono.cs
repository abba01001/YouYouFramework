using System;
using System.Collections.Generic;
using System.Linq;
using OBBUtils;
using QFramework;
using UnityEngine;
using SoliUtils;

#if UNITY_EDITOR
public class EditorMono : MonoBehaviour, ISingleton
{
    public Stack<LevelModel> LevelDataStack = new Stack<LevelModel>();
    public Stack<LevelModel> LevelDataRedoStack = new Stack<LevelModel>();
    public Dictionary<int, GameObject> DeskCards = new Dictionary<int, GameObject>();
    public BaseCard SelectedCardMono;
    public bool IsCardLine;
    public Vector2 pivot = new Vector2(0, 63);

    private CardModel _selectedCardModel;
    public CardModel SelectedCardModel
    {
        get
        {
            return _selectedCardModel;
        }
        set
        {
            _selectedCardModel = value.DeepCopy();
            SelectedCardMono.CardData.cm = value.DeepCopy();
            var levelData = LevelDataStack.Peek().DeepCopy();
            for (int i = 0; i < levelData.cards.Length; i++)
            {
                var cm = levelData.cards[i];
                if (cm.id == _selectedCardModel.id)
                {
                    var temp = levelData.cards;
                    temp[i] = _selectedCardModel.DeepCopy();
                    levelData.cards = temp;
                    break;
                }
            }
            LevelDataStack.Push(levelData.DeepCopy());
            LevelDataRedoStack.Clear();
        }
    }

    public void OnSingletonInit()
    {
    }
    public static EditorMono Instance
    {
        get { return MonoSingletonProperty<EditorMono>.Instance; }
    }


    private bool isHoldCtrl;
    private Vector2 mouseStart;
    private bool mouseDown;
    private bool undoFlag;
    private bool redoFlag;
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.LeftControl))
            isHoldCtrl = true;
        if (Input.GetKeyUp(KeyCode.LeftControl))
            isHoldCtrl = false;
        if (isHoldCtrl)
        {
            if (Input.GetKeyDown(KeyCode.Z))
            {
                if (!Input.GetKeyDown(KeyCode.LeftAlt))
                {
                    if (!undoFlag)
                    {
                        undoFlag = true;
                        EditorMono.Instance.Undo();
                    }
                }
                else
                {
                    if (!redoFlag)
                    {
                        redoFlag = true;
                        EditorMono.Instance.Redo();
                    }
                }
                return;
            }

            if (Input.GetMouseButtonDown(1))
            {
                mouseStart = Input.mousePosition;
                mouseDown = true;
            }
            if (Input.GetMouseButtonUp(1))
            {
                if (mouseDown)
                {
                    var cards = GetSelectedCards();
                    if (cards.Count == 1)
                    {
                        TypeEventSystem.Send<EditorMoveCardEvent>(new EditorMoveCardEvent(SelectedCardMono.transform));

                        SelectedCardMono.CardData.cm.Position = ToVector3Int(SelectedCardMono.transform.localPosition);
                        _selectedCardModel = SelectedCardMono.CardData.cm;
                        ChangeCardData(SelectedCardModel);
                    }
                    else
                    {
                        PushPositions();
                    }
                }
                mouseDown = false;
            }

            if (mouseDown)
            {
                var touch = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
                var cards = EditorMono.Instance.GetSelectedCards();
                if (Input.GetKey(KeyCode.LeftShift))
                {
                    if (Vector2.Distance(touch, mouseStart) > 5 && cards.Count >= 1)
                    {
                        var move = touch - mouseStart;
                        var firstCard = cards[0];
                        var pos = firstCard.transform.localPosition;
                        move.x = (int)((pos.x + move.x) / 5) * 5 - pos.x;
                        move.y = (int)((pos.y + move.y) / 5) * 5 - pos.y;
                        foreach (var card in cards)
                        {
                            pos = card.transform.localPosition;
                            pos.x += move.x;
                            pos.y += move.y;
                            card.transform.localPosition = pos;
                        }
                        mouseStart = touch;
                    }
                }
                else
                {
                    var move = touch - mouseStart;
                    foreach (var card in cards)
                    {
                        var pos = card.transform.localPosition;
                        pos.x += move.x;
                        pos.y += move.y;
                        card.transform.localPosition = pos;
                    }
                    mouseStart = touch;
                }
            }
        }
        undoFlag = false;
        redoFlag = false;
    }

    private void Start()
    {
        TypeEventSystem.Register<EditorSelectedCardEvent>(OnEditorSelectedCardEvent);
        TypeEventSystem.Register<EditorRectCardsEvent>(OnEditorRectCardsEvent);
        TypeEventSystem.Register<EditorSelectedLockItemEvent>(OnEditorSelectedLockItemEvent);
    }

    private void Destroy()
    {
        TypeEventSystem.UnRegister<EditorSelectedCardEvent>(OnEditorSelectedCardEvent);
        TypeEventSystem.UnRegister<EditorRectCardsEvent>(OnEditorRectCardsEvent);
        TypeEventSystem.UnRegister<EditorSelectedLockItemEvent>(OnEditorSelectedLockItemEvent);
    }

    public void OnEditorSelectedCardEvent(EditorSelectedCardEvent e)
    {
        SelectedCardMono = e.card.GetComponent<BaseCard>();
        _selectedCardModel = SelectedCardMono.CardData.cm;
        TypeEventSystem.Send<EditorShowCardInfoEvent>();
    }

    public void OnEditorRectCardsEvent(EditorRectCardsEvent e)
    {
        float cardWidth = Constants.CardSize.x * Constants.CardSizeScale.x;
        float cardHeight = Constants.CardSize.y * Constants.CardSizeScale.y;
        var grandFa = transform.GetComponentsInChildren<Transform>();
        foreach (Transform child in grandFa)
        {
            if (child.GetComponent<BaseCard>() != null)
            {
                var obb = new OBB();
                obb.Pos = new Vec3(child.position.x, child.position.y, 0);
                obb.Half_size = new Vec3(cardWidth / 2, cardHeight / 2, 0);
                obb.AxisX = new Vec3(1, 0, 0);
                obb.AxisY = new Vec3(0, 1, 0);
                obb.AxisZ = new Vec3(0, 0, 1);

                var arcAngle = child.eulerAngles.z * 3.14f / 180.0f;
                obb.AxisX = new Vec3(obb.AxisX.X * Mathf.Cos(arcAngle) - obb.AxisX.Y * Mathf.Sin(arcAngle),
                            obb.AxisX.X * Mathf.Sin(arcAngle) + obb.AxisX.Y * Mathf.Cos(arcAngle),
                            0);
                obb.AxisY = new Vec3(obb.AxisY.X * Mathf.Cos(arcAngle) - obb.AxisY.Y * Mathf.Sin(arcAngle),
                            obb.AxisY.X * Mathf.Sin(arcAngle) + obb.AxisY.Y * Mathf.Cos(arcAngle),
                            0);

                var sel = OBBCollision.GetCollision(e.obb, obb);
                child.GetComponent<BaseCard>().SetSelectState(sel);
            }
        }
    }

    public void OnEditorSelectedLockItemEvent(EditorSelectedLockItemEvent e)
    {
        TypeEventSystem.Send<EditorShowLockInfoEvent>(new EditorShowLockInfoEvent(e.sel));
    }

    public void CleanCards()
    {
        var grandFa = transform.GetComponentsInChildren<BaseCard>();
        var removeList = new List<Transform>();
        foreach (var card in grandFa)
        {
            removeList.Add(card.transform);
        }
        for (int i = 0; i < removeList.Count; i++)
        {
            Destroy(removeList[i].gameObject);
        }
        LevelDataStack.Clear();
        LevelDataRedoStack.Clear();
        SelectedCardMono = null;
        _selectedCardModel = null;
        MoveScene(0);
        foreach (var item in LinkRopeDic)
        {
            Destroy(item.Value.gameObject);
        }
        LinkRopeDic.Clear();
    }

    public void ReView(LevelModel lm)
    {
        foreach (var item in LinkRopeDic)
        {
            Destroy(item.Value.gameObject);
        }
        LinkRopeDic.Clear();
        var cards = new List<GameObject>();
        var grandFa = transform.GetComponentsInChildren<BaseCard>();
        var removeList = new List<Transform>();
        foreach (var card in grandFa)
        {
            removeList.Add(card.transform);
        }
        for (int i = 0; i < removeList.Count; i++)
        {
            Destroy(removeList[i].gameObject);
        }

        foreach (var cm in lm.cards)
        {
            CreateCard(cm);
        }

        if (lm.locks != null && lm.locks.Length > 0)
        {
            var lockItem = UnityEngine.Object.Instantiate(
                GlobalRes.Load<GameObject>("Assets/Res/Prefabs/Item/LockItem.prefab"), transform);
            foreach (var item in lm.locks)
            {
                lockItem.GetComponent<LockItem>().Show(item);
            }
        }

        foreach (var cm in lm.cards)
        {
            if (cm.HasLinkRope())
            {
                CreateLinkRope(cm.id, cm.LinkRopeCardId);
            }
        }

    }

    public void ReadLevelData(LevelModel lm)
    {
        LevelDataStack.Push(lm);
    }

    public GameObject CreateCard(CardModel cm)
    {
        var cmType = cm.cardType;
        var gameObjType = Constants.CardType2ObjDic[cmType];
        var card = GameObjManager.Instance.PopGameObject(gameObjType);
        card.transform.parent = transform;
        card.SetActive(true);
        var cardMono = card.GetComponent<BaseCard>();
        CardData cardData = new CardData(cm.id, cm);
        cardMono.SetData(cardData, 1);
        var pos = card.transform.localPosition;
        pos.x = cm.x;// + transform.position.x;
        pos.y = cm.y;// + transform.position.y;
        card.transform.localPosition = pos;

        if (cmType == CardType.Value)
        {
            cardMono.ShowModifier(true);
        }

        if (DeskCards.ContainsKey(cm.id))
            DeskCards.Remove(cm.id);
        DeskCards.Add(cm.id, card);

        return card;
    }

    public Dictionary<int, GameObject> GetDeskCard()
    {
        return DeskCards;
    }

    public List<GameObject> GetSelectedCards()
    {
        var cards = new List<GameObject>();
        var grandFa = transform.GetComponentsInChildren<Transform>();
        foreach (Transform card in grandFa)
        {
            var mono = card.GetComponent<BaseCard>();
            if (mono != null && mono.IsSel)
            {
                cards.Add(card.gameObject);
            }
        }
        return cards;
    }

    public void CheckSelected(Transform tarCard, bool isHoldControl)
    {
        if (!isHoldControl)
        {
            var grandFa = transform.GetComponentsInChildren<Transform>();
            foreach (Transform card in grandFa)
            {
                var mono = card.GetComponent<BaseCard>();
                if (mono != null && mono.IsSel && tarCard != card)
                {
                    mono.SetSelectState();
                }
            }
        }
    }

    public void Undo()
    {
        if (LevelDataStack.Count <= 1)
            return;
        var ld = LevelDataStack.Pop();
        LevelDataRedoStack.Push(ld.DeepCopy());

        var lm = LevelDataStack.Peek().DeepCopy();
        ReView(lm);

        _selectedCardModel = null;
        SelectedCardMono = null;
    }

    public void Redo()
    {
        if (LevelDataRedoStack.Count == 0)
            return;
        var lm = LevelDataRedoStack.Pop();
        LevelDataStack.Push(lm.DeepCopy());
        ReView(lm.DeepCopy());

        _selectedCardModel = null;
        SelectedCardMono = null;
    }

    public void PushPositions()
    {
        var grandFa = transform.GetComponentsInChildren<Transform>();
        var levelData = LevelDataStack.Peek().DeepCopy();
        foreach (Transform card in grandFa)
        {
            var mono = card.GetComponent<BaseCard>();
            if (mono != null && mono.IsSel)
            {
                for (int i = 0; i < levelData.cards.Length; i++)
                {
                    var cm = levelData.cards[i];
                    if (cm.id == mono.CardData.cm.id)
                    {
                        mono.CardData.cm.Position = SolitaireEditor.ToVector3Int(mono.transform.localPosition);
                        var temp = levelData.cards;
                        temp[i] = mono.CardData.cm.DeepCopy();
                        levelData.cards = temp;
                        break;
                    }
                }
            }
        }
        LevelDataStack.Push(levelData.DeepCopy());
        LevelDataRedoStack.Clear();
    }

    public void ChangeHandCard(int[] stack)
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        levelData.settings.cards_in_stack = stack;
        LevelDataStack.Push(levelData.DeepCopy());
        LevelDataRedoStack.Clear();
    }

    private void ChangeCardData(CardModel tarCm)
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        for (int i = 0; i < levelData.cards.Length; i++)
        {
            var cm = levelData.cards[i];
            if (cm.id == tarCm.id)
            {
                var temp = levelData.cards;
                temp[i] = tarCm.DeepCopy();
                levelData.cards = temp;
                break;
            }
        }
        LevelDataStack.Push(levelData.DeepCopy());
    }

    public int GetCardNumber()
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        return levelData.cards.Length;
    }

    public void ChangeSelectedCardsType(EditorCardTypeEnum tarType)
    {
        if (_selectedCardModel == null)
            return;
        var cm = _selectedCardModel.DeepCopy();
        cm.cardType = (CardType)tarType;
        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(_selectedCardModel);
    }

    public void ChangeSelectedCardModifier(ModifierType modType)
    {
        if (_selectedCardModel == null)
            return;
        var cm = _selectedCardModel.DeepCopy();

        if (cm.HasLinkRope() && modType != ModifierType.LinkRope)
        {
            cm.modifiers = null;

            GameObject linkRopeObj = null;
            LinkRopeDic.TryGetValue(cm.id, out linkRopeObj);
            if (linkRopeObj != null)
            {
                Destroy(linkRopeObj);
                LinkRopeDic.Remove(cm.id);
            }
            LinkRopeDic.TryGetValue(cm.LinkRopeCardId, out linkRopeObj);
            if (linkRopeObj != null)
            {
                Destroy(linkRopeObj);
                LinkRopeDic.Remove(cm.LinkRopeCardId);
            }
        }

        if (modType == ModifierType.None)
        {
            cm.modifiers = null;
        }
        else
        {
            var mod = new ModifierModel();
            mod.modType = modType;
            mod.properties = new PropertieModel();
            cm.modifiers = new ModifierModel[] { mod };
        }
        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        // (newCardMono as ValueCard)?.SetData(newCardMono.CardData, 0, 0);
        newCardMono.ShowModifier(modType != ModifierType.None);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(_selectedCardModel);
    }

    public void ChangeSelectedCardBombTimer(int value)
    {
        if (_selectedCardModel == null)
            return;
        var cm = _selectedCardModel.DeepCopy();
        cm.modifiers[0].properties.timer = value;
        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        newCardMono.ShowModifier(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(_selectedCardModel);
    }

    public void ChangeSelectedCardBigBombTimer(int value)
    {
        if (_selectedCardModel == null)
            return;
        var cm = _selectedCardModel.DeepCopy();
        cm.modifiers[0].properties.timer = value;
        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        newCardMono.ShowModifier(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(_selectedCardModel);
    }

    public void ChangeSelectedThreeCardValue(int value)
    {
        if (_selectedCardModel == null)
            return;
        var cm = _selectedCardModel.DeepCopy();
        cm.SetValue(value);
        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(_selectedCardModel);
    }

    public void ChangeSelectedCardSuit(int suit)
    {
        if (_selectedCardModel == null)
            return;
        var cm = _selectedCardModel.DeepCopy();
        cm.suit = suit;
        cm.random = suit == -1;
        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(_selectedCardModel);
    }

    public void ChangeSelectedCardLightningTimer(int value, bool isInit = true)
    {
        if (_selectedCardModel == null)
            return;
        var cm = _selectedCardModel.DeepCopy();
        if (isInit)
        {
            cm.modifiers[0].properties.timer = value;
            cm.modifiers[0].properties.param1 = value;
        }
        else
        {
            cm.modifiers[0].properties.interval = value;
            cm.modifiers[0].properties.param2 = value;
        }

        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(_selectedCardModel);

        if (isInit) (SelectedCardMono as ValueCard).SetLightningTimer(value);
    }

    public void ChangeSelectedCardClothIsOpen(bool isOpen, bool isMagic)
    {
        if (_selectedCardModel == null)
            return;
        var cm = _selectedCardModel.DeepCopy();
        cm.modifiers[0].properties.param1 = isOpen ? 1 : 0;

        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(_selectedCardModel);

        if (isMagic)
            (SelectedCardMono as ValueCard).SetMagicClothOpen(isOpen);
        else
            (SelectedCardMono as ValueCard).SetClothOpen(isOpen);
    }

    public void ChangeSelectedCardClothStateSwitchRound(int round, bool isMagic)
    {
        if (_selectedCardModel == null)
            return;
        var cm = _selectedCardModel.DeepCopy();
        cm.modifiers[0].properties.interval = round;
        cm.modifiers[0].properties.timer = round;

        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(_selectedCardModel);
    }

    private readonly List<int> _ropesList = new List<int>();
    public void RefreshCardRopes(List<SuitTypeEnum> ropes)
    {
        _ropesList.Clear();
        foreach (var value in ropes)
        {
            _ropesList.Add((int)value);
            if (_ropesList.Count == 4)
                break;
        }

        if (SelectedCardModel == null)
            return;

        var data = SelectedCardModel.DeepCopy();
        data.modifiers[0].properties.params3 = _ropesList.ToArray();
        SelectedCardMono.CardData.cm = data.DeepCopy();

        SelectedCardMono.CardData.ResetSuitRope();
        (SelectedCardMono as ValueCard)?.CreateModifier(data.modifiers);
        (SelectedCardMono as ValueCard)?.ShowModifier(true);
        // (SelectedCardMono as ValueCard)?.SetRopeSuits(SelectedCardMono.CardData);

        ChangeCardData(data);
    }

    public void NewCard(CardModel tarCm)
    {
        tarCm.x -= Convert.ToInt32(transform.position.x);
        var card = CreateCard(tarCm);
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cardList = levelData.cards.ToList();
        cardList.Add(tarCm);
        levelData.cards = cardList.ToArray();
        LevelDataStack.Push(levelData.DeepCopy());

        var newCardMono = card.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = card.transform });
    }

    public void DeleteCard()
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cardList = levelData.cards.ToList();
        for (int i = 0; i < cardList.Count; i++)
        {
            var cm = cardList[i];
            if (cm.id == SelectedCardMono.CardData.cm.id)
            {
                cardList.Remove(cm);
                break;
            }
        }
        levelData.cards = cardList.ToArray();
        LevelDataStack.Push(levelData.DeepCopy());
        Destroy(SelectedCardMono.gameObject);
        _selectedCardModel = null;
    }

    public void FlopGroup()
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cards = GetSelectedCards();
        foreach (var card in cards)
        {
            var cardMono = card.GetComponent<BaseCard>();
            cardMono.IsFaceUp = !cardMono.IsFaceUp;
            for (int i = 0; i < levelData.cards.Length; i++)
            {
                var cm = levelData.cards[i];
                if (cm.id == cardMono.CardData.cm.id)
                {
                    var temp = levelData.cards;
                    temp[i] = cardMono.CardData.cm.DeepCopy();
                    temp[i].faceUp = cardMono.IsFaceUp;
                    levelData.cards = temp;
                    break;
                }
            }
        }
        LevelDataStack.Push(levelData.DeepCopy());
    }

    public void CopyGroup(ref int CardAutoId)
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cards = GetSelectedCards();
        foreach (var card in cards)
        {
            var cardMono = card.GetComponent<BaseCard>();
            cardMono.SetSelectState();

            var cm = cardMono.CardData.cm.DeepCopy();
            cm.id = ++CardAutoId;
            cm.x += 10;
            cm.y -= 10;
            cm.depth -= 1;
            var newCard = CreateCard(cm);
            newCard.GetComponent<BaseCard>().SetSelectState();

            var cardList = levelData.cards.ToList();
            cardList.Add(cm);
            levelData.cards = cardList.ToArray();
        }
        LevelDataStack.Push(levelData.DeepCopy());
    }

    public void DeleteGroup()
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cards = GetSelectedCards();
        foreach (var card in cards)
        {
            var cardMono = card.GetComponent<BaseCard>();
            var cardList = levelData.cards.ToList();
            for (int i = 0; i < cardList.Count; i++)
            {
                var cm = cardList[i];
                if (cm.id == cardMono.CardData.cm.id)
                {
                    cardList.Remove(cm);
                    break;
                }
            }
            levelData.cards = cardList.ToArray();
            Destroy(card);
        }
        LevelDataStack.Push(levelData.DeepCopy());
    }

    public void FlipYGroup(ref int CardAutoId)
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cards = GetSelectedCards();
        var _pivot = pivot;
        _pivot.x -= transform.position.x;
        foreach (var card in cards)
        {
            var cardMono = card.GetComponent<BaseCard>();
            cardMono.SetSelectState();

            var cm = cardMono.CardData.cm.DeepCopy();
            cm.id = ++CardAutoId;
            cm.x = (int)(2 * _pivot.x - cm.x);
            cm.angle = -cm.angle;
            var newCard = CreateCard(cm);
            newCard.GetComponent<BaseCard>().SetSelectState();

            var cardList = levelData.cards.ToList();
            cardList.Add(cm);
            levelData.cards = cardList.ToArray();
        }
        LevelDataStack.Push(levelData.DeepCopy());
    }

    public void FlipXGroup(ref int CardAutoId)
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cards = GetSelectedCards();
        var _pivot = pivot;
        _pivot.x -= transform.position.x;
        foreach (var card in cards)
        {
            var cardMono = card.GetComponent<BaseCard>();
            cardMono.SetSelectState();

            var cm = cardMono.CardData.cm.DeepCopy();
            cm.id = ++CardAutoId;
            cm.y = (int)(2 * _pivot.y - cm.y);
            cm.angle = -cm.angle;
            var newCard = CreateCard(cm);
            newCard.GetComponent<BaseCard>().SetSelectState();

            var cardList = levelData.cards.ToList();
            cardList.Add(cm);
            levelData.cards = cardList.ToArray();
        }
        LevelDataStack.Push(levelData.DeepCopy());
    }

    public void FlipCenterGroup(ref int CardAutoId)
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cards = GetSelectedCards();
        var _pivot = pivot;
        _pivot.x -= transform.position.x;
        foreach (var card in cards)
        {
            var cardMono = card.GetComponent<BaseCard>();
            cardMono.SetSelectState();

            var cm = cardMono.CardData.cm.DeepCopy();
            cm.id = ++CardAutoId;
            cm.x = (int)(2 * _pivot.x - cm.x);
            cm.y = (int)(2 * _pivot.y - cm.y);
            var newCard = CreateCard(cm);
            newCard.GetComponent<BaseCard>().SetSelectState();

            var cardList = levelData.cards.ToList();
            cardList.Add(cm);
            levelData.cards = cardList.ToArray();
        }
        LevelDataStack.Push(levelData.DeepCopy());
    }

    public void CreateCardLine(int num, bool faceup)
    {
        IsCardLine = true;
        CancelSelected();
        var res = "Assets/Editor/Res/CardLine.prefab";
        var cardRes = UnityEditor.AssetDatabase.LoadAssetAtPath<GameObject>(res);
        var cardGroup = Instantiate(cardRes, transform);
        cardGroup.name = "CardLine";
        cardGroup.transform.position = new Vector3(-1334 / 2 + 60, -750 / 2 + 80, -300);
        var mono = cardGroup.GetComponent<BezierLine>();
        mono.CreateCards(num, faceup);
    }

    public void RenumCardLine(int num, bool faceup)
    {
        var cardline = transform.Find("CardLine");
        var mono = cardline.GetComponent<BezierLine>();
        mono.CreateCards(num, faceup);
    }

    public void RedepthCardLine(int depth)
    {
        var cardline = transform.Find("CardLine");
        var mono = cardline.GetComponent<BezierLine>();
        mono.FirstDepth = depth;
    }

    public void ReintervalCardLine(int inter)
    {
        var cardline = transform.Find("CardLine");
        var mono = cardline.GetComponent<BezierLine>();
        mono.DepthInterval = inter;
    }

    public void RefaceupCardLine(bool faceup)
    {
        var cardline = transform.Find("CardLine");
        var mono = cardline.GetComponent<BezierLine>();
        mono.Faceup = faceup;
    }

    public void ConfirmLineCard(ref int CardAutoId)
    {
        IsCardLine = false;
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cardline = transform.Find("CardLine");
        var mono = cardline.GetComponent<BezierLine>();
        for (int i = 0; i < mono.cardList.Count; i++)
        {
            var card = mono.cardList[i];
            var cm = new CardModel(++CardAutoId, CardType.Value);
            cm.x = (int)Math.Ceiling(card.transform.position.x - transform.position.x);
            cm.y = (int)Math.Ceiling(card.transform.position.y - transform.position.y);
            cm.depth = (int)Math.Ceiling(card.transform.position.z);
            cm.angle = (int)Math.Ceiling(card.transform.eulerAngles.z);
            cm.faceUp = mono.Faceup;
            CreateCard(cm);
            Destroy(card.gameObject);

            var cardList = levelData.cards.ToList();
            cardList.Add(cm);
            levelData.cards = cardList.ToArray();
        }
        LevelDataStack.Push(levelData.DeepCopy());
        Destroy(cardline.gameObject);
    }

    public void DeleteLineCard()
    {
        IsCardLine = false;
        var cardline = transform.Find("CardLine");
        var mono = cardline.GetComponent<BezierLine>();
        for (int i = 0; i < mono.cardList.Count; i++)
        {
            var card = mono.cardList[i];
            Destroy(card.gameObject);
        }
        Destroy(cardline.gameObject);
    }


    public void CopyCard(ref int CardAutoId)
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cardMono = SelectedCardMono;
        cardMono.SetSelectState();
        var cm = cardMono.CardData.cm.DeepCopy();
        cm.id = ++CardAutoId;
        cm.x += 10;
        cm.y -= 10;
        cm.depth -= 1;
        var newCard = CreateCard(cm);
        var cardList = levelData.cards.ToList();
        cardList.Add(cm);
        levelData.cards = cardList.ToArray();

        LevelDataStack.Push(levelData.DeepCopy());

        newCard.GetComponent<BaseCard>().SetSelectState();
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newCard.transform });
    }

    public void CancelSelected()
    {
        var grandFa = transform.GetComponentsInChildren<Transform>();
        foreach (Transform card in grandFa)
        {
            var mono = card.GetComponent<BaseCard>();
            if (mono != null)
                mono.SetSelectState(false);
        }
    }

    public static Vector3Int ToVector3Int(Vector3 vec)
    {
        return new Vector3Int((int)vec.x, (int)vec.y, (int)vec.z);
    }

    public void MoveScene(float x)
    {
        var pos = transform.position;
        pos.x = x;
        transform.position = pos;
    }

    public void ChangeMoveSceneState(bool flag)
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        levelData.settings.moving_scene = flag;
        LevelDataStack.Push(levelData.DeepCopy());
    }

    private GameObject LockItemObj;

    public void CreateLockItem(LockModel data = null)
    {
        var scene = Camera.main.transform.parent;
        var lockItem = UnityEngine.Object.Instantiate(GlobalRes.Load<GameObject>("Assets/Res/Prefabs/Item/LockItem.prefab"), scene);
        if (data == null)
            data = new LockModel();
        lockItem.GetComponent<LockItem>().Show(data);
        LockItemObj = lockItem.gameObject;

        var levelData = LevelDataStack.Peek().DeepCopy();
        levelData.locks = data == null ? new LockModel[] { } : new LockModel[]{
            data,
        };
        LevelDataStack.Push(levelData.DeepCopy());
    }

    public void DeleteLockItem()
    {
        Destroy(LockItemObj);
        LockItemObj = null;

        var levelData = LevelDataStack.Peek().DeepCopy();
        levelData.locks = null;
        LevelDataStack.Push(levelData.DeepCopy());
    }

    public LockModel GetLockModel()
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        return levelData.locks.Length > 0 ? levelData.locks[0] : null;
    }

    public void ChangeLockItems(LockItemTypeEnum[] lockItems)
    {
        var blocks = new List<BlockModel>();
        foreach (var item in lockItems)
        {
            if (item == LockItemTypeEnum.Random)
            {
                blocks.Add(
                    new BlockModel
                    {
                        random = true,
                    }
                );
            }
            else if (item >= LockItemTypeEnum.Number1 && item <= LockItemTypeEnum.Number13)
            {
                blocks.Add(
                    new BlockModel
                    {
                        type = "value",
                        value = (int)item
                    }
                );
            }
            else if (item >= LockItemTypeEnum.Suit1 && item <= LockItemTypeEnum.Suit4)
            {
                blocks.Add(
                    new BlockModel
                    {
                        type = "suit",
                        value = item - LockItemTypeEnum.Suit1
                    }
                );
            }
            else if (item >= LockItemTypeEnum.ColorBlack && item <= LockItemTypeEnum.ColorRed)
            {
                blocks.Add(
                    new BlockModel
                    {
                        type = "color",
                        value = item - LockItemTypeEnum.ColorBlack
                    }
                );
            }
        }
        var levelData = LevelDataStack.Peek().DeepCopy();
        levelData.locks[0].blocks = blocks.ToArray();
        LevelDataStack.Push(levelData.DeepCopy());
        LockItemObj.GetComponent<LockItem>().ReViewItem(levelData.locks[0]);
    }

    public void RefreshLinkRope(int linkRoleCardId)
    {
        if (SelectedCardModel == null)
            return;

        var cm = SelectedCardModel.DeepCopy();
        cm.modifiers[0].properties.param1 = linkRoleCardId;

        var newObj = CreateCard(cm);
        Destroy(SelectedCardMono.gameObject);
        var newCardMono = newObj.GetComponent<BaseCard>();
        newCardMono.IsSel = true;
        newCardMono.ShowSelectedColor(true);
        _selectedCardModel = newCardMono.CardData.cm;
        TypeEventSystem.Send<EditorSelectedCardEvent>(new EditorSelectedCardEvent() { card = newObj.transform });

        ChangeCardData(cm);
        CreateLinkRope(cm.id, linkRoleCardId);
    }

    Dictionary<int, GameObject> LinkRopeDic = new Dictionary<int, GameObject>();
    void CreateLinkRope(int cardId1, int cardId2)
    {
        if (!DeskCards.ContainsKey(cardId1) || !DeskCards.ContainsKey(cardId2))
            return;

        var vaild = true;
        var levelData = LevelDataStack.Peek().DeepCopy();
        for (int i = 0; i < levelData.cards.Length; i++)
        {
            var cm = levelData.cards[i];
            if (cm.id == cardId1)
            {
                vaild = cm.HasLinkRope() && cm.LinkRopeCardId == cardId2;
            }
            if (cm.id == cardId2)
            {
                vaild = cm.HasLinkRope() && cm.LinkRopeCardId == cardId1;
            }
            if (!vaild)
                return;
        }

        GameObject linkRopeObj;
        LinkRopeDic.TryGetValue(cardId1, out linkRopeObj);
        if (linkRopeObj != null)
        {
            Destroy(linkRopeObj);
            LinkRopeDic.Remove(cardId1);
        }
        LinkRopeDic.TryGetValue(cardId2, out linkRopeObj);
        if (linkRopeObj != null)
        {
            Destroy(linkRopeObj);
            LinkRopeDic.Remove(cardId2);
        }

        var scene = Camera.main.transform.parent;
        var linkRopeItem = UnityEngine.Object.Instantiate(GlobalRes.Load<GameObject>("Assets/Res/Cards/Prefabs/LinkRopeItem.prefab"), scene);

        Vector3 p1 = DeskCards[cardId1].transform.position - new Vector3(0, Constants.CardSize.y * Constants.CardSizeScale.y / 2, 0);
        Vector3 p3 = DeskCards[cardId2].transform.position - new Vector3(0, Constants.CardSize.y * Constants.CardSizeScale.y / 2, 0);
        Vector3 p2 = (p1 + p3) / 2 + new Vector3(0, -100, 0);
        List<Vector3> nodes = new List<Vector3>();
        nodes.Add(p1);
        nodes.Add(p2);
        nodes.Add(p3);

        var ropeItem = linkRopeItem.GetComponent<LinkRopeItem>();
        ropeItem.ConnectEnds(DeskCards[cardId1].transform.GetChild(0).GetChild(0), DeskCards[cardId2].transform.GetChild(0).GetChild(0));
        LinkRopeDic.Add(cardId1, linkRopeItem);
    }

    

    public void OneKeyFaceup(bool faceup)
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cards = new List<GameObject>();
        var grandFa = transform.GetComponentsInChildren<Transform>();
        foreach (Transform card in grandFa)
        {
            var mono = card.GetComponent<BaseCard>();
            if (mono != null)
            {
                cards.Add(card.gameObject);
            }
        }
        foreach (var card in cards)
        {
            var cardMono = card.GetComponent<BaseCard>();
            cardMono.IsFaceUp = faceup;
            for (int i = 0; i < levelData.cards.Length; i++)
            {
                var cm = levelData.cards[i];
                if (cm.id == cardMono.CardData.cm.id)
                {
                    var temp = levelData.cards;
                    temp[i] = cardMono.CardData.cm.DeepCopy();
                    temp[i].faceUp = cardMono.IsFaceUp;
                    levelData.cards = temp;
                    break;
                }
            }
        }
        LevelDataStack.Push(levelData.DeepCopy());
        var lm = LevelDataStack.Peek().DeepCopy();
        ReView(lm);
    }
    
    public void OneKeyValueCard()
    {
        var levelData = LevelDataStack.Peek().DeepCopy();
        var cards = new List<GameObject>();
        var grandFa = transform.GetComponentsInChildren<Transform>();
        foreach (Transform card in grandFa)
        {
            var mono = card.GetComponent<BaseCard>();
            if (mono != null)
            {
                cards.Add(card.gameObject);
            }
        }
        foreach (var card in cards)
        {
            var cardMono = card.GetComponent<BaseCard>();
            for (int i = 0; i < levelData.cards.Length; i++)
            {
                var cm = levelData.cards[i];
                if (cm.id == cardMono.CardData.cm.id)
                {
                    var temp = levelData.cards;
                    temp[i] = cardMono.CardData.cm.DeepCopy();
                    temp[i].cardType = CardType.Value;
                    temp[i].modifiers = null;
                    levelData.cards = temp;
                    break;
                }
            }
        }
        LevelDataStack.Push(levelData.DeepCopy());
        var lm = LevelDataStack.Peek().DeepCopy();
        ReView(lm);
    }
}

#endif