
using Activities;
using Doozy.Engine;
using UniRx;
using UnityEngine;
using SoliUtils;
using System.Collections;

public class SceneMono : MonoBehaviour
{
    [SerializeField] private AudioSource[] BgmAudioSource;
    [SerializeField] private AudioSource[] SoundAudioSource;
    void Awake()
    {
        Debug.Log($">>> SceneMono >> Awake ...");

        GlobalRes.PreLoadHomeRes();
        GameObjTransInfo.DefaultScene = transform.parent;
        BackdropMono.Instance.SwitchBackdrop();
        
        ActivityManager.Instance.Init();
        BattleCenter.Instance.Init();
        MergeGameController.Instance.Init();
    }


    private void OnDestroy()
    {
        ActivityManager.Instance.Dispose();
    }

    void Start()
    {
        SoundPlayer.Instance.Init(BgmAudioSource, SoundAudioSource);
        // SoundPlayer.Instance.ChangeBgm();
        // FxMaskView.Instance.SetAlpha(0);
    }

    private void Update()
    {
        BattleCenter.Instance.Update();

        if (Input.GetKey(KeyCode.F2))
        {
            var dataService = MainContainer.Container.Resolve<IDataService>();
            var configService = MainContainer.Container.Resolve<IConfigService>();
            foreach (var item in configService.RookieConfig)
            {
                dataService.MarkRookieTipFlag(item.Key);
            }
            dataService.PrintRookieTipFlag();
        }
    }
}
