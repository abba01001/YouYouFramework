using Doozy.Engine;
using QFramework;
using UnityEngine;

public class SceneMgr : MonoBehaviour
{
    private static SceneMgr _instance;

    public static SceneMgr Instance
    {
        get
        {
            if (_instance != null) return _instance;
            var go = GameObject.Find("SceneMgr");
            if (go != null) return _instance;
            go = new GameObject("SceneMgr");
            _instance = go.AddComponent<SceneMgr>();
            DontDestroyOnLoad(go);

            return _instance;
        }
    }

    #region 场景切换

    private const string LauncherName = "LauncherScene";
    private const string MainName = "MainScene";
    private const string TestName = "TestScene";

    public void LoadLauncherScene()
    {
        Debug.Log($">>> SceneMgr >> LoadLauncherScene .");
        TypeEventSystem.Send<ViewRefreshEvent>();
        GameEventMessage.SendEvent("ReloadSave");
        // GameEventMessage.SendEvent(Constants.DoozyEvent.ConfigInitFinish);
//            SceneManager.LoadScene(LauncherName);
    }

    #endregion

}