
using System.Threading.Tasks;
using UnityEngine;

public class AISceneMono : MonoBehaviour
{
    async void Awake()
    {
        Application.targetFrameRate = 30;
        Application.runInBackground = true;
        await LoadConfigAsync();
        InitData();
        BattleCenter.Instance.Init();
        var canvas = GameObject.Find("Canvas");
        canvas.transform.Find("InitView")?.gameObject.SetActive(false);
        canvas.transform.Find("AIPanel")?.gameObject.SetActive(true);
    }

    async Task LoadConfigAsync()
    {
        IAssetService assetService = MainContainer.Container.Resolve<IAssetService>();
        await assetService.LoadCollectFlowerConfig();
        await assetService.LoadRobotConfig();
        await assetService.LoadValueConfig();
        await assetService.LoadLocalStageConfig();
        await assetService.LoadEndlessLevelRewardConfig();
        await assetService.LoadWheelRewardConfig();
        await assetService.LoadEndlessStageOneConfig();
        await assetService.LoadEndlessStageTwoConfig();
        await assetService.LoadCardRemainConfig();
        await assetService.LoadComboRewardConfig();
        await assetService.LoadSignInConfig();
        // await assetService.LoadWheelConfig();
        await assetService.LoadShopConfig();
        await assetService.LoadRookieConfig();
        await assetService.LoadRookieClickConfig();
        await assetService.LoadRookieDialogueConfig();
        await assetService.LoadRookieDragConfig();
        await assetService.LoadRookieAnimConfig();
        await assetService.LoadBetConfig();
        await assetService.LoadItemConfig();
        await assetService.LoadPowerItemConfig();
        await assetService.LoadActivitiesConfig();
        await assetService.LoadSeasonRewardConfig();
        await assetService.LoadActivitiesSwitchConfig();
        await assetService.LoadCollectLoveCardConfig();
        await assetService.LoadCollectMusicConfig();
        await assetService.LoadDigTreasureRewardConfig();
        await assetService.LoadLevelPassConfig();
        await assetService.LoadLavaPassConfig();
        // await assetService.LoadFarmingConfig();
        await assetService.LoadCookMealConfig();
        await assetService.LoadMysteriousSeedConfig();
        await assetService.LoadUnlockConfig();
        await assetService.LoadMagicNectarConfig();
        await assetService.LoadRainbowDropsConfig();
        await assetService.LoadPopupPriorityConfig();
        await assetService.LoadAdRewardConfig();
        await assetService.LoadPassRankRobotConfig();
        await assetService.LoadCarRankRobotConfig();
        await assetService.LoadGradientConfig();
        await assetService.LoadGiftGradientCookConfig();
        await assetService.LoadGiftGradientDigConfig();
        await assetService.LoadPassRankRewardConfig();
        await assetService.LoadCarRankRewardConfig();
        await assetService.LoadLimitPkConfig();
        await assetService.LoadPushGiftConfig();
        await assetService.LoadSoundConfig();
        await assetService.LoadCardDescConfig();
        await assetService.LoadSeasonPassConfig();
        await assetService.LoadNewUserSeasonPassConfig();
        await assetService.LoadSeasonExpConfig();
        await assetService.LoadHandleLevelConfig();
        await assetService.LoadHandleEndlessLevelConfig();
        await assetService.LoadHandleResultConfig();
        await assetService.LoadHandleLabelConfig();
        await assetService.LoadHandleConsumConfig();
        await assetService.LoadHandlePaidConfig();
        await assetService.LoadMergeItemConfig();
        await assetService.LoadMergeMapConfig();
    }

    void InitData()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        dataService.ReadLocalData();
    }

    void Start()
    {
        GameCommon.IsAiMode = true;
    }

    private void Update()
    {
        BattleCenter.Instance.Update();
    }

}
