﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using Model;
using UnityEngine;
using SoliUtils;
using UniRx;

public interface IGiftGradientDigActivity
{
    void CheckFinishActivity();
    int GetStartIndex();
    void CheckTriggerPopup();
    void UpdateProgress(int value);
    int GetMaxProgress();
    GradientModel GetCurLayerCollectModel();
}

//梯度礼包活动
public class GiftGradientDigActivity : IGiftGradientDigActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public GiftGradientDigActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.GradientDigGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.GradientDigGuide);
        if (CheckCurGiftCanGet())
            list.Add(rootNode);
        return list;
    }

    public bool CheckCurGiftCanGet()
    {
        if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.giftGradientCook)) return false;
        int index = GetStartIndex();
        if (configService.GiftGradientDigConfig.TryGetValue(index, out GradientModel model))
        {
            return model.IsFree == 1;
        }

        return false;
    }


    public void CheckTriggerPopup()
    {
        if (dataService.GiftGradientDigProgress.PopBtn &&
            ActivityManager.Instance.GetActivityByType(ActivityType.giftGradientDig).state == ActivityState.underWay)
        {
            if (!GameCommon.IsShieldPurchase)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.GiftGradientDigPopup,
                    BoxBuilder.ShowGiftGradientDig);
                dataService.GiftGradientDigProgress.PopBtn = false;
            }
        }
    }

    public void UpdateProgress(int value)
    {
        foreach (var model in configService.GiftGradientDigConfig)
        {
            if (model.Value.collectLayer == dataService.GiftGradientDigProgress.CollectLayer)
            {
                dataService.GiftGradientDigProgress.CollecProgress += value;
                int max = model.Value.collectProgress;
                if (dataService.GiftGradientDigProgress.CollecProgress >= max)
                {
                    dataService.GiftGradientDigProgress.CollectLayer++;
                    int left = dataService.GiftGradientDigProgress.CollecProgress - max;
                    dataService.GiftGradientDigProgress.CollecProgress = left;
                    Observable.Timer(TimeSpan.FromSeconds(0.1f)).Subscribe(_ =>
                    {
                        GetCollectReward(model.Value);
                    });
                }

                dataService.SaveData(true);
                break;
            }
        }

        TypeEventSystem.Send<UpdateGiftDigProgress>();
    }

    public GradientModel GetCurLayerCollectModel()
    {
        foreach (var model in configService.GiftGradientDigConfig)
        {
            if (model.Value.collectLayer == dataService.GiftGradientDigProgress.CollectLayer)
            {
                return model.Value;
            }
        }

        return null;
    }

    private void GetCollectReward(GradientModel model)
    {
        BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(model.collectReward),
            PropChangeWay.GiftGradientCollectReward, endCall: () => { }, true,
            activityType: ActivityType.giftGradientDig);
    }

    public int GetMaxProgress()
    {
        int value = 0;
        foreach (var model in configService.GiftGradientDigConfig)
        {
            if (model.Key == dataService.GiftGradientDigProgress.CollectLayer)
            {
                value = model.Value.collectProgress;
                break;
            }
        }

        if (value == 0) value = 1;
        return value;
    }

    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.giftGradientDig,false);
    }

    public int GetStartIndex()
    {
        int startIndex = -1;
        foreach (var pair in configService.GiftGradientDigConfig)
        {
            if (pair.Key > dataService.GiftGradientDigProgress.CurRewardIndex)
            {
                startIndex = pair.Key;
                break;
            }
        }

        if (startIndex == -1) startIndex = configService.GiftGradientDigConfig.Count + 1;
        return startIndex;
    }
}