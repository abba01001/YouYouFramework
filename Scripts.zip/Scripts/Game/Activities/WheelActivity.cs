﻿using QFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface IWheelActivity
{
    void CheckTriggerPopup();
    void ResetProgress();
    List<WheelRewardModel> GetShowReward(bool isPay);
    WheelRewardModel GetRandomReward(bool isPay);
    void CheckGetReward(Dictionary<int, int> reward, int type,Action startAction,Action endAction);
    bool HasWheelCount();
    void CheckOpenActivity();
    void GMAddCount(int input);
    void SetPayState(bool isPay);
}

public class WheelActivity: IWheelActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();
    private List<WheelRewardModel> _wheelReward = null;
    public void CheckTriggerPopup()
    {
        if (GameUtils.CheckFuncIsUnlock("luckyWheel") && (HasWheelCount() || dataService.WheelProgress.isPay))
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.WheelPopup,BoxBuilder.ShowWheelPopup);
        }
    }

    public void GMAddCount(int input)
    {
        if(!CanShowBtn()) return;
        dataService.WheelProgress.curLevel += input;
    }

    public void SetPayState(bool isPay)
    {
        dataService.WheelProgress.isPay = isPay;
        dataService.SaveData(true);
    }
    
    public void CheckOpenActivity()
    {
        if(!CanShowBtn()) return;
        dataService.WheelProgress.curLevel++;
    }
    
    private bool CanShowBtn()
    {
        return GameUtils.CheckFuncIsUnlock("luckyWheel");
    }

    public void ResetProgress()
    {
        dataService.WheelProgress.curLevel = 0;
        dataService.WheelProgress.curIndex++;
        dataService.SaveData(true);
    }

    public bool HasWheelCount()
    {
        int curIndex = dataService.WheelProgress.curIndex;
        if (curIndex >= configService.WheelOpenInterval.Length) curIndex = configService.WheelOpenInterval.Length - 1;
        return dataService.WheelProgress.curLevel >= configService.WheelOpenInterval[curIndex];
    }

    public void CheckGetReward(Dictionary<int,int> reward,int type,Action startAction,Action endAction)
    {
        PropChangeWay changeWay = type == 1 ? PropChangeWay.FreeWheel : PropChangeWay.PayWheel;
        if (type == 1)
        {
            BoxBuilder.ShowRewardPop(reward, changeWay, endCall: endAction,activityType: ActivityType.wheel);
            startAction?.Invoke();
        }
        else
        {
            BoxBuilder.ShowRewardPop(reward, changeWay,endAction,activityType: ActivityType.wheel);
            startAction?.Invoke();
        }
    }
    
    public List<WheelRewardModel> GetShowReward(bool isPay)
    {
        int _type = isPay ? 2 : 1;
        List<WheelRewardModel> reward = new List<WheelRewardModel>();
        foreach (var model in configService.WheelRewardConfig)
        {
            if (model.Value.type == _type)
            {
                reward.Add(model.Value);
            }
        }
        return reward;
    }
    
    public WheelRewardModel GetRandomReward(bool isPay)
    {
        int _type = isPay ? 2 : 1;
        int totalWeight = 0;
        foreach (var model in configService.WheelRewardConfig)
        {
            if (model.Value.type == _type)
            {
                totalWeight += model.Value.weight;
            }
        }

        float value = GameUtils.RandomRange(0f, 1f);
        float tempTotal = 0;

        WheelRewardModel rewardModel = new WheelRewardModel();
        foreach (var model in configService.WheelRewardConfig)
        {
            if (model.Value.type == _type)
            {
                tempTotal += model.Value.weight;
                if (tempTotal > value * totalWeight)
                {
                    rewardModel = model.Value;
                    break;
                }
            }

        }
        return rewardModel;
    }


}