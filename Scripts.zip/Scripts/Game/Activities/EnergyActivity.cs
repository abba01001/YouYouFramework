﻿using Activities;
using QFramework;
using SoliUtils;
using System.Collections.Generic;
using UnityEngine;


public interface IEnergyActivity
{
    void Update();
    EnergyConfig GetConfig();
    int GetCurrentEnergy();
    int GetMaxEnergy();
    bool UseEnergy(int value);
    int GetDayADCount();
    int GetCD();
    int GetAutoRecoverCountDown();
    void OnWatchADComplete();
    int GetBuyEnergyCost();
    bool BuyEnergy();
    void HandleResultEnergy();
    int GetInfiniteSecond();

}

public class EnergyActivity : IEnergyActivity
{
    private IConfigService _configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService _dataService = MainContainer.Container.Resolve<IDataService>();
    private EnergyConfig _energyConfig;
    private EnergySaveData _energySaveData;
    private int[] _infiniteEnergyPropIds = { (int)PropEnum.EnergyInfinite };

    public void HandleResultEnergy()
    {
        if (!_dataService.IsOverRookie()) return;
        AddEnergy(1, PropChangeWay.WinGame);
    }
    
    public EnergyActivity()
    {
        Init();
    }

    private void Init()
    {
        _energyConfig = _configService.EnergyConfig[1];
        _energySaveData = _dataService.EnergySaveData;
        if (!_energySaveData.inited && GetCurrentEnergy() == 0)//未初始化过体力数据
        {
            _energySaveData.inited = true;
            AddEnergy(_energyConfig.max_value, PropChangeWay.EnergyInit);
        }
        TypeEventSystem.Register<SeasonPassPaidEvent>(OnSeasonPassPaidEvent);
    }

    private void OnSeasonPassPaidEvent(SeasonPassPaidEvent evt)
    {
        Debug.Log("OnSeasonPassPaidEvent........."+evt.active);
        if (evt.active)
        {
            ActivityManager.Instance.SeasonPassActivity.UpdateFirstReward();
            int addValue = GetMaxEnergy() - GetCurrentEnergy();
            AddEnergy(addValue, PropChangeWay.EnergyRecover);
            _energySaveData.lastRecoverTime = 0;
        }
        else
        {
            int reduceValue = GetCurrentEnergy() - GetMaxEnergy();//超过上限的体力减掉
            if (reduceValue > 0)
            {
                //UseEnergy(reduceValue);
                _dataService.UseProp((int)PropEnum.Energy, PropChangeWay.EnergyConsume, reduceValue);
            }
        }
    }

    public void Update()//每秒一次
    {
        CheckResetDayADCount();
        CheckAutoRecoverEnergy();
    }

    private void CheckResetDayADCount()
    {
        if (_energySaveData.dayADCount >= _energyConfig.ad_count)
        {
            int serverTime = ActivityManager.Instance.GetActivitySeverTime();
            if (_energySaveData.lastADTime + _energyConfig.ad_cd < serverTime)
            {
                Debug.Log("重置观看广告次数");
                _energySaveData.dayADCount = 0;
            }
        }
    }

    public void OnWatchADComplete()
    {
        _dataService.AdRewardProgress.UpdateProgress();
        _energySaveData.lastADTime = ActivityManager.Instance.GetActivitySeverTime();
        _energySaveData.dayADCount++;
        AddEnergy(1, PropChangeWay.EnergyAd);
        _dataService.SaveData(true);
    }



    private void CheckAutoRecoverEnergy()
    {
        if (_energySaveData.lastRecoverTime > 0)
        {
            int serverTime = ActivityManager.Instance.GetActivitySeverTime();
            int seconds = serverTime - _energySaveData.lastRecoverTime;
            if (seconds >= _energyConfig.auto_recover_time)
            {
                int recoverCount = seconds / _energyConfig.auto_recover_time;
                int remainderSeconds = seconds % _energyConfig.auto_recover_time;
                int recoverEnergy = recoverCount * _energyConfig.auto_recover_value;
                AddEnergy(recoverEnergy, PropChangeWay.EnergyRecover);
                if (GetCurrentEnergy() < GetMaxEnergy())
                {
                    _energySaveData.lastRecoverTime = serverTime - remainderSeconds;
                }
                else
                {
                    _energySaveData.lastRecoverTime = 0;
                }
                _dataService.SaveData(true);
            }
        }
    }

    public EnergyConfig GetConfig()
    {
        return _energyConfig;
    }

    public int GetCurrentEnergy()
    {
        if (GetInfiniteSecond() > 0)//无限体力
        {
            return GetMaxEnergy();
        }
        return (int)_dataService.GetPropNum((int)PropEnum.Energy);
    }

    public int GetMaxEnergy()
    {
        if (ActivityManager.Instance.SeasonPassActivity.IsPaid())//购买了通行证
        {
            return _energyConfig.max_value + 3;
        }
        return _energyConfig.max_value;
    }

    public int GetDayADCount()
    {
        return _energySaveData.dayADCount;
    }

    public int GetCD()
    {
        if (_energySaveData.lastADTime > 0)
        {
            int cd = _energySaveData.lastADTime + _energyConfig.ad_cd - ActivityManager.Instance.GetActivitySeverTime();
            if (cd > 0)
            {
                return cd;
            }
        }
        return 0;
    }

    private void AddEnergy(int value, PropChangeWay changeWay)
    {
        int oldValue = GetCurrentEnergy();
        int newValue = Mathf.Min(GetMaxEnergy(), oldValue + value);
        //Debug.Log("AddEnergy.....oldValue=" + oldValue+ " newValue=" + newValue);
        if (newValue >= GetMaxEnergy())//达到最大值重置自动恢复时间
        {
            _energySaveData.lastRecoverTime = 0;
        }
        if (newValue > oldValue)
        {
            _dataService.AddProp((int)PropEnum.Energy, newValue - oldValue, changeWay, null);
            
        }
    }


    
    public bool UseEnergy(int value)
    {
        if (GameUtils.IsSpecialLevel()) return true;
        if (GetInfiniteSecond() > 0)//无限体力
        {
            return true;
        }
        if (GetCurrentEnergy() < value)
        {
            return false;
        }
        //使用完后，开启回复倒计时
        if (_energySaveData.lastRecoverTime == 0)
        {
            _energySaveData.lastRecoverTime = ActivityManager.Instance.GetActivitySeverTime();
        }
        _dataService.UseProp((int)PropEnum.Energy, PropChangeWay.EnergyConsume, value);
        return true;
    }

    public int GetAutoRecoverCountDown()
    {
        if (_energySaveData.lastRecoverTime > 0)
        {
            int recoverTime = _energySaveData.lastRecoverTime + _energyConfig.auto_recover_time;
            int countDown = recoverTime - ActivityManager.Instance.GetActivitySeverTime();
            return countDown;
        }
        return 0;
    }

    public int GetBuyEnergyCost()
    {
        int cost = GetBuyEnergyValue() * _energyConfig.price;
        return cost;
    }

    private int GetBuyEnergyValue()
    {
        int buyEnergyValue = GetMaxEnergy() - GetCurrentEnergy();
        return buyEnergyValue;
    }

    public bool BuyEnergy()
    {
        int cost = GetBuyEnergyCost();
        if (_dataService.ConsumeCoin(cost, PropChangeWay.EnergyBuy))
        {
            AddEnergy(GetBuyEnergyValue(),PropChangeWay.EnergyBuy);
            
            _dataService.SaveData(true);
            return true;
        }
        return false;
    }

    //无限体力时长
    public int GetInfiniteSecond()
    {
        int second = 0;
        int nowTime = TimeUtils.UtcNow();
        for (int i=0;i< _infiniteEnergyPropIds.Length; i++)
        {
            int propId = _infiniteEnergyPropIds[i];
            long propNum = _dataService.GetPropNum(propId);
            if (propNum > nowTime)
            {
                second = Mathf.Max(second, (int)(propNum - nowTime));
            }
        }
        return second;
    }
}
