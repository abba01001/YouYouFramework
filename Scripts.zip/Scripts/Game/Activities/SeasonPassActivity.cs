﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using Model;
using UnityEngine;
using SoliUtils;

// 赛季通行证活动接口
public interface ISeasonPassActivity
{
    void CheckTriggerPopup();
    void CheckOpenActivity();
    void OperateMyProgress(int inputCount = 0);
    void CheckGetReward(SeasonPassModel model, Action cb);
    void CheckGetBoxReward(Action cb);
    void CheckFinishActivity();
    int GetPoint();
    SeasonPassModel GetLayerModel(int type, int layer);
    float GetRatio();
    bool CurIsMaxLayer();
    void GMAddIntegral(int count);
    int GetAddCount();
    int GetCurLayerCollectCount();
    int GetNextLayerCollectCount();
    int GetMaxIntegral();
    int GetMaxLayer();
    int GetCanGetRewardCount();
    Dictionary<int, SeasonPassModel> GetConfig();
    bool IsPaid();
    void CheckFirstLayer();
    void UpdateFirstReward();
}

//赛季通行证
public class SeasonPassActivity : ISeasonPassActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public bool IsPaid()
    {
        if (!IsOpenActivity()) return false;
        return dataService.SeasonPassProgress.IsPaid;
    }
    
    public int GetAddCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass).state != ActivityState.underWay)
        {
            dataService.SeasonPassProgress.ResultAddCount = 0;
            return 0;
        }

        return dataService.SeasonPassProgress.ResultAddCount;
    }

    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass).state ==
               ActivityState.underWay;
    }

    public void GMAddIntegral(int count)
    {
        OperateMyProgress(count);
        ActivityManager.Instance.SaveActivityData();
    }

    public void CheckFirstLayer()
    {
        if (dataService.SeasonPassProgress.curLayer == 0)
        {
            //OperateMyProgress(1);
        }
    }

    void UpdateRewardFlags(int layer)
    {
        if (dataService.SeasonPassProgress.freeLayerRewardFlag[layer] == 0)
        {
            dataService.SeasonPassProgress.freeLayerRewardFlag[layer] = 1;
        }
        if (dataService.SeasonPassProgress.chargeLayerRewardFlag[layer] == 0)
        {
            dataService.SeasonPassProgress.chargeLayerRewardFlag[layer] = 1;
        }
    }

    public void OperateMyProgress(int inputCount = 0)
    {
        dataService.SeasonPassProgress.totalProgress += inputCount == 0 ? GetPoint() : inputCount;
        dataService.SeasonPassProgress.ResultAddCount = inputCount == 0 ? GetPoint() : inputCount;
        int lastLayer = dataService.SeasonPassProgress.lastLayer;
        if (!CurIsMaxLayer())
        {
            foreach (var VARIABLE in GetConfig())
            {
                bool isFirstLayer = VARIABLE.Value.layer == 1 && dataService.SeasonPassProgress.curLayer == 0;
                bool isProgressValid = VARIABLE.Value.progress <= dataService.SeasonPassProgress.totalProgress;

                if (isFirstLayer || isProgressValid)
                {
                    UpdateRewardFlags(VARIABLE.Value.layer);
                    dataService.SeasonPassProgress.curLayer = VARIABLE.Value.layer;
                }
            }
        }
        else
        {
            if (dataService.SeasonPassProgress.totalProgress > GetMaxIntegral())
            {
                int left = dataService.SeasonPassProgress.totalProgress - GetMaxIntegral();
                int count = left / int.Parse(configService.ValueConfig["SeasonPassBoxProgress"]);
                dataService.SeasonPassProgress.curLayer = GetMaxLayer() + count;
            }
        }

        dataService.SeasonPassProgress.getRewardCount =
            Mathf.Max(dataService.SeasonPassProgress.curLayer - lastLayer, 0);
        if (dataService.SeasonPassProgress.getRewardCount > 0)
        {
            var msg = new Dictionary<string, object>
            {
                {"layer", dataService.SeasonPassProgress.curLayer}
            };
            AnalyticUtils.ReportEvent(AnalyticsKey.SeasonPass_Progress, msg);
        }

        dataService.SeasonPassProgress.lastLayer = dataService.SeasonPassProgress.curLayer;
        if (dataService.SeasonPassProgress.lastViewLayer == 0)
        {
            dataService.SeasonPassProgress.lastViewLayer = Mathf.Min(dataService.SeasonPassProgress.curLayer - 1, 0);
        }
    }

    public int GetCanGetRewardCount()
    {
        int count = 0;

        foreach (var pair in dataService.SeasonPassProgress.freeLayerRewardFlag)
        {
            if (pair.Value == 1) count++;
        }

        if (dataService.SeasonPassProgress.IsPaid)
        {
            foreach (var pair in dataService.SeasonPassProgress.chargeLayerRewardFlag)
            {
                if (pair.Value == 1) count++;
            }
        }

        return count;
    }

    public void CheckTriggerPopup()
    {
        if (dataService.SeasonPassProgress.PopBtn &&
            ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass).state == ActivityState.underWay)
        {
            if (!GameCommon.IsShieldPurchase)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartSeassPassPopup,
                    () => BoxBuilder.ShowStartSeasonPassPopup("start"));
                dataService.SeasonPassProgress.PopBtn = false;
            }
        }
    }

    public void CheckOpenActivity()
    {
        if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.seasonPass)) return;
        CheckFirstLayer();
        OperateMyProgress();
    }

    public int GetCurLayerCollectCount()
    {
        if (dataService.SeasonPassProgress.curLayer == 1)
        {
            return Mathf.Max(dataService.SeasonPassProgress.totalProgress, 0);
        }
        else
        {
            if (!CurIsMaxLayer())
            {
                var curModel = GetLayerModel(1, dataService.SeasonPassProgress.curLayer);
                return Mathf.Max(dataService.SeasonPassProgress.totalProgress - curModel.progress, 0);
            }
            else
            {
                int left = dataService.SeasonPassProgress.totalProgress - GetMaxIntegral();
                return Mathf.Max(left % int.Parse(configService.ValueConfig["SeasonPassBoxProgress"]), 0);
            }
        }
    }

    public int GetMaxIntegral()
    {
        int maxLayer = GetMaxLayer();
        foreach (var VARIABLE in GetConfig())
        {
            if (VARIABLE.Value.type == 1 && VARIABLE.Value.layer == maxLayer)
            {
                return VARIABLE.Value.progress;
            }
        }

        return 0;
    }

    public Dictionary<int, SeasonPassModel> GetConfig()
    {
        Dictionary<int, SeasonPassModel> models = new Dictionary<int, SeasonPassModel>();
        int subType = 1;
        if (ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.seasonPass))  subType = dataService.SeasonPassProgress.SubActivityType;
        foreach (var pair in configService.SeasonPassConfig)
        {
            if (pair.Value.activityid == subType)
            {
                models.Add(pair.Value.id,pair.Value);
            }
        }
        return models;
    }

    public int GetNextLayerCollectCount()
    {
        if (CurIsMaxLayer())
        {
            return int.Parse(configService.ValueConfig["SeasonPassBoxProgress"]);
        }

        SeasonPassModel nextModel = GetLayerModel(1, dataService.SeasonPassProgress.curLayer + 1);
        if (dataService.SeasonPassProgress.curLayer == 1)
        {
            return nextModel.progress;
        }
        else
        {
            var curModel = GetLayerModel(1, dataService.SeasonPassProgress.curLayer);
            return nextModel.progress - curModel.progress;
        }
    }

    public int GetMaxLayer()
    {
        int maxLayer = 0;
        foreach (var VARIABLE in GetConfig())
        {
            if (VARIABLE.Value.type == 1)
            {
                maxLayer++;
            }
        }

        return maxLayer;
    }

    public bool CurIsMaxLayer()
    {
        if (dataService.SeasonPassProgress.curLayer >= GetMaxLayer())
        {
            return true;
        }

        return false;
    }

    public float GetRatio()
    {
        return (float) GetCurLayerCollectCount() / GetNextLayerCollectCount();
    }

    public void UpdateFirstReward()
    {
        dataService.SeasonPassProgress.chargeLayerRewardFlag[1] = 2;
    }
    
    public SeasonPassModel GetLayerModel(int type, int layer)
    {
        SeasonPassModel nextModel = null;
        int maxLayer = 0;
        foreach (var VARIABLE in GetConfig())
        {
            if (VARIABLE.Value.type == type)
            {
                maxLayer++;
            }
        }

        layer = Mathf.Min(layer, maxLayer);
        foreach (var VARIABLE in GetConfig())
        {
            if (VARIABLE.Value.layer == layer && VARIABLE.Value.type == type)
            {
                nextModel = VARIABLE.Value;
                break;
            }
        }

        return nextModel;
    }

    public void CheckGetBoxReward(Action cb)
    {
        int count = dataService.SeasonPassProgress.GetBoxRewardCount();
        if (count > 0)
        {
            BoxBuilder.ShowRewardPop(configService.GetSeasonBoxReward, PropChangeWay.SeasonReward, endCall: () =>
            {
                dataService.SeasonPassProgress.UpdateBoxRewardIndex();
                cb?.Invoke();
            });
        }
    }

    public void CheckGetReward(SeasonPassModel model, Action cb)
    {
        Dictionary<int, int> rewardDic = GameUtils.AnalysisPropString(model.reward);
        BoxBuilder.ShowRewardPop(rewardDic, PropChangeWay.SeasonReward, endCall: () =>
        {
            dataService.SeasonPassProgress.SetRewardState(model);
            cb?.Invoke();
        });
    }

    //结束自动领取奖励
    public void CheckFinishActivity()
    {
        string reward = "";
        Dictionary<int, int> dic = new Dictionary<int, int>();
        foreach (var pair in dataService.SeasonPassProgress.freeLayerRewardFlag)
        {
            if (pair.Value == 1)
            {
                SeasonPassModel model = GetLayerModel(1, pair.Key);
                reward += model.reward + ";";
            }
        }

        if (dataService.SeasonPassProgress.IsPaid)
        {
            foreach (var pair in dataService.SeasonPassProgress.chargeLayerRewardFlag)
            {
                if (pair.Value == 1)
                {
                    SeasonPassModel model = GetLayerModel(2, pair.Key);
                    reward += model.reward + ";";
                }
            }
        }

        if (reward != "")
        {
            dic = GameUtils.AnalysisPropString(reward);
        }

        int count = dataService.SeasonPassProgress.GetBoxRewardCount();
        if (count > 0)
        {
            for (int i = 0; i < count; i++)
            {
                foreach (var pair in configService.GetSeasonBoxReward)
                {
                    if (dic.ContainsKey(pair.Key))
                    {
                        dic[pair.Key] += pair.Value;
                    }
                    else
                    {
                        dic[pair.Key] = pair.Value;
                    }
                }
            }
        }

        if (dic.Count > 0)
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.RewardPopup, () =>
            {
                BoxBuilder.ShowRewardPop(dic, PropChangeWay.SeasonReward, activityType: ActivityType.seasonPass);
            }, true,1);
        }
        ActivityManager.Instance.FinishGetReward(ActivityType.seasonPass);

        dataService.SeasonPassProgress.IsPaid = false;
        TypeEventSystem.Send(new SeasonPassPaidEvent(false));
    }

    public int GetPoint()
    {
        int point = 0;
        configService.GetSeasonPassRation.TryGetValue(dataService.NowBet, out point);
        return point * dataService.GetCollectBet();
    }
}

