using System;
using System.Collections.Generic;
using Doozy.Engine;
using Doozy.Engine.UI;
using Model;
using QFramework;
using UniRx;
using UnityEngine;
using UnityEngine.Events;
using SoliUtils;

namespace Activities
{
    public class ActivityManager
    {
        private static ActivityManager _instance;
        public static ActivityManager Instance => _instance ?? (_instance = new ActivityManager());

        #region 具体活动逻辑类
        public ISeasonPassActivity SeasonPassActivity;
        public ICollectLoveCardActivity CollectLoveCardActivity;
        public ICollectMusicActivity CollectMusicActivity;
        public ICollectFlowerActivity CollectFlowerActivity;
        public IPassRankActivity PassRankActivity;
        public ICarRankActivity CarRankActivity;
        public ILevelPassActivity LevelPassActivity;
        public ILavaPassActivity LavaPassActivity;
        public ILimitPkActivity LimitPkActivity;
        public IGradientGiftActivity GradientGiftActivity;
        public IGiftGradientCookActivity GiftGradientCookActivity;
        public IGiftGradientDigActivity GiftGradientDigActivity;
        public IAdRewardActivity AdRewardActivity;
        public IFarmingActivity FarmingActivity;
        public IWheelActivity WheelActivity;
        public IEndlessLevelActivity EndlessLevelActivity;
        public IRabbitGiftActivity RabbitGiftActivity;
        public ICollectWaterActivity CollectWaterActivity;
        public ICollectHoneyActivity CollectHoneyActivity;
        public IDigTreasureActivity DigTreasureActivity;
        public ICookMealActivity CookMealActivity;
        public IMysteriousSeedActivity MysteriousSeedActivity;
        public IIllustratedGuideActivity IllustratedGuideActivity;
        public IEnergyActivity EnergyActivity;
        public IGiftActivity GiftActivity;
        #endregion

        private IConfigService _configService;
        private IDataService _dataService;
        private Dictionary<int, ActivitiesSwitchModel> _activitiesSwitchDict;
        private Dictionary<int, ActivityModel> _activityDict;
        private Dictionary<int, SeasonRewardModel> _seasonRewardDict;
        private readonly List<ActivityModel> _allActivitiesConfig = new List<ActivityModel>(); // 所有开启的活动的开关数据
        private readonly List<ActivityDataModel> _allActivities = new List<ActivityDataModel>(); // 所有活动具体数据
        private readonly Dictionary<ActivityType,ActivitiesSwitchModel> _activitiesSwitchModels = new Dictionary<ActivityType,ActivitiesSwitchModel>(); // 所有活动具体数据
        private readonly List<SeasonRewardModel> _seasonRewardList = new List<SeasonRewardModel>(); // 所有赛季奖励
        private readonly Dictionary<int, PushGiftInfo> _pushGiftInfoList = new Dictionary<int, PushGiftInfo>();//礼包推送规则
        private IDisposable _backgroundTimer; // 后台定时器
        private int _serverTime; // 服务器时间
        private DateTime _serverDate = DateTime.MaxValue;
        private bool _isServerTime; // 是否是服务器时间了
        private bool _isInit; // 是否初始化过了
        private Dictionary<ActivityType, bool> sendRefreshTimerList = new Dictionary<ActivityType, bool>();
        private Dictionary<ActivityType, bool> needRefreshActivity = new Dictionary<ActivityType, bool>();//上一秒活动结束再刷新一次活动
        private bool sendTriggerPopup = false;
        #region Init

        private void ConfigInitFinishEvent(GameEventMessage message)
        {
            // if (message?.EventName == Constants.DoozyEvent.ConfigInitFinish)
            // {
            //     OnBackgroundTimerUpdate(true);
            //     Message.RemoveListener<GameEventMessage>(ConfigInitFinishEvent);
            // }
        }
        
        public void Init()
        {
            if (_isInit) return;
            _isInit = true;
            _configService = MainContainer.Container.Resolve<IConfigService>();
            _dataService = MainContainer.Container.Resolve<IDataService>();
            if (_dataService.ActivitySaveData == null) _dataService.InitActivitySaveData();
            SeasonPassActivity = new SeasonPassActivity();
            CollectLoveCardActivity = new CollectLoveCardActivity();
            CollectMusicActivity = new CollectMusicActivity();
            CollectFlowerActivity = new CollectFlowerActivity();
            PassRankActivity = new PassRankActivity();
            CarRankActivity = new CarRankActivity();
            LevelPassActivity = new LevelPassActivity();
            EndlessLevelActivity = new EndlessLevelActivity();
            RabbitGiftActivity = new RabbitGiftActivity();
            CollectWaterActivity = new CollectWaterActivity();
            CollectHoneyActivity = new CollectHoneyActivity();
            DigTreasureActivity = new DigTreasureActivity();
            CookMealActivity = new CookMealActivity();
            MysteriousSeedActivity = new MysteriousSeedActivity();
            LavaPassActivity = new LavaPassActivity();
            LimitPkActivity = new LimitPkActivity();
            GradientGiftActivity = new GradientGiftActivity();
            GiftGradientCookActivity = new GiftGradientCookActivity();
            GiftGradientDigActivity = new GiftGradientDigActivity();
            AdRewardActivity = new AdRewardActivity();
            FarmingActivity = new FarmingActivity();
            WheelActivity = new WheelActivity();
            IllustratedGuideActivity = new IllustratedGuideActivity();
            EnergyActivity = new EnergyActivity();
            GiftActivity = new GiftActivity();
            RefreshConfig();
//            InitAllActivities();
            InitBackgroundTimer();
            RefreshPushGiftRule();

            OnBackgroundTimerUpdate(true);

            // Message.AddListener<GameEventMessage>(ConfigInitFinishEvent);
        }

        //刷新礼包推送规则
        private void RefreshPushGiftRule()
        {
            if (_pushGiftInfoList.Count == 0)
            {
                foreach (var pair in _configService.PushGiftConfig)
                {
                    PushGiftInfo info = new PushGiftInfo(pair.Value);
                    InitPushGiftInfo(ref info);
                    _pushGiftInfoList.Add(pair.Value.id,info);
                }
            }
            else
            {
                foreach (var pair in _pushGiftInfoList)
                {
                    PushGiftInfo info = pair.Value;
                    InitPushGiftInfo(ref info);
                }
            }
        }
        
        private void InitPushGiftInfo(ref PushGiftInfo info)
        {
            bool tempPush = false;
            int remainCardCount = 0;
            int buyUndoPrice = 0;
            int buyCardsPrice = 0;
            int jokerCardPrice = 0;
            if (GameController.Instance.IsPlaying)
            {
                remainCardCount = BattleDataMgr.Instance.GetDeskCardsNum();
                buyUndoPrice = GameController.Instance.BattleCtrl.gameData.GetNowUndoCost();
                buyCardsPrice = GameController.Instance.BattleCtrl.gameData.GetNowBuyCardCost();
                jokerCardPrice = GameController.Instance.BattleCtrl.gameData.GetNowBuyJokerCost();
            }
            info.CanPush = tempPush;
            if (info.model.id == 1 || info.model.id == 11)
            {
                if(!GameController.Instance.IsPlaying) return;
                tempPush = _dataService.Coin < buyCardsPrice;
            }
            else if (info.model.id == 2 || info.model.id == 12)
            {
                tempPush = _dataService.Coin < jokerCardPrice;
            }
            else if (info.model.id == 3 || info.model.id == 13)
            {
                tempPush = _dataService.Coin < buyUndoPrice;
            }
            else if (info.model.id == 4 || info.model.id == 14)
            {
                tempPush = EnergyActivity.GetCurrentEnergy() <= 0;
            }
            else if (info.model.id is >= 5 and <= 7)
            {
                if (!GameController.Instance.IsPlaying) return;
                int[] Para = Array.ConvertAll(info.model.Para.Split(GameUtils.FirstSeparator), int.Parse);
                tempPush = remainCardCount == Para[0];
            }
            else if (info.model.id == 8)
            {
                int[] Para = Array.ConvertAll(info.model.Para.Split(GameUtils.FirstSeparator), int.Parse);
                tempPush = remainCardCount > Para[0] && remainCardCount <= Para[1] ;
            }
            else if (info.model.id == 9)
            {
                int[] Para = Array.ConvertAll(info.model.Para.Split(GameUtils.FirstSeparator), int.Parse);
                tempPush = remainCardCount > Para[0] && remainCardCount <= Para[1] ;
            }
            else if (info.model.id == 10)
            {
                int[] Para = Array.ConvertAll(info.model.Para.Split(GameUtils.FirstSeparator), int.Parse);
                tempPush = remainCardCount > Para[0];
            }
            info.CanPush = tempPush;
            info.Flag = (FlagType)Enum.Parse(typeof(FlagType), info.model.Flag);
        }

        //检测是否推送破产礼包
        public bool CheckPushGift(string ProductId,GiftType GiftType)
        {
            RefreshPushGiftRule();
            _configService.ShopConfig.TryGetValue(ProductId, out ShopModel model);
            if (model != null && model.PushConditionDict != null)
            {
                int[] tempPushConditionDict = model.PushConditionDict;
                if (model.pre_product != "")
                {
                    if (Constants.BankruptcyFlagId.TryGetValue(model.pre_product, out FlagType flagType))
                    {
                        _configService.ShopConfig.TryGetValue(model.pre_product, out ShopModel preModel);
                        if (preModel != null && preModel.PushConditionDict != null)
                        {
                            if (!_dataService.CheckDailyFlag(flagType))
                            {
                                tempPushConditionDict = preModel.PushConditionDict;
                                ProductId = preModel.product_id;
                            }
                        }
                    }
                }
                
                foreach (var pushId in tempPushConditionDict)
                {
                    _pushGiftInfoList.TryGetValue(pushId, out PushGiftInfo info);
                    if (info != null && info.CanPush)
                    {
                        if (!_dataService.CheckDailyFlag(info.Flag))
                        {
                            TypeEventSystem.Send<PopPushGift>(new PopPushGift(ProductId,GiftType));
                            _dataService.AddDailyFlag(info.Flag);
                            return true;
                            //进行推送
                        }
                        if (pushId is >= 1 and <= 4 or >= 11 and <= 14)
                        {
                            BoxBuilder.ShowShopPop();
                        }
                        return false;
                    }
                }
            }
            return false;
        }
        
        private void ActivitiesStateRefresh()
        {
            InitAllOpenActivities();
            if (needRefreshActivity.Count > 0)
            {
                foreach (var value in needRefreshActivity)
                {
                    UpdateCurActivity(value.Key,true);
                }
                needRefreshActivity.Clear();
            }
            //InitPerActivityCurrent();

            if (sendTriggerPopup)
            {
                TypeEventSystem.Send<TriggrePopupEvent>();
                sendTriggerPopup = false;
                SaveActivityData();
            }
            
            if (sendRefreshTimerList.Count > 0)
            {
                foreach (var info in sendRefreshTimerList)
                {
                    SendRefreshActivityTimer(info.Key);
                }
                sendRefreshTimerList.Clear();
            }
        }

        private void InitAllActivitiesConfig()
        {
            _allActivitiesConfig.Clear();
            foreach (var model in _activityDict)
            {
                _allActivitiesConfig.Add(model.Value);
            }
        }

        private void InitDataModel(ActivitiesSwitchModel activity,ActivityModel config,ref ActivityDataModel dataModel)
        {
            dataModel.Init(
                _id: activity.id,
                _name: activity.name,
                _type: activity.acType,
                _desc: activity.desc,
                _olderOpenTime: activity.OlderOpenTime,
                _naturalTimeList : activity.NaturalTimeList,
                _param: activity.param,
                _unlockStage: activity.unlockLevel,
                _isOpen: activity.isOpen,
                _needUserOpen :activity.needUserOpen,
                _subActivityType: activity.subActivityType,
                _rewardTitle: activity.RewardTitle,
                _openInterval : activity.openInterval
                );
            switch (activity.acType)
                {
                    case ActivityType.piggy:
                        dataModel.localData = _dataService.ActivitySaveData.piggy;
                        break;
                    case ActivityType.collectFlower:
                        dataModel.localData = _dataService.ActivitySaveData.flowerProgress;
                        break;
                    case ActivityType.digTreasure:
                        dataModel.localData = _dataService.ActivitySaveData.digTreasureProgress;
                        break;
                    case ActivityType.cookMeal:
                        dataModel.localData = _dataService.ActivitySaveData.cookMealProgress;
                        break;
                    case ActivityType.collectLoveCard:
                        dataModel.localData = _dataService.ActivitySaveData.loveCardProgress;
                        break;
                    case ActivityType.passRank:
                        dataModel.localData = _dataService.ActivitySaveData.passRankProgress;
                        break;
                    case ActivityType.carRank:
                        dataModel.localData = _dataService.ActivitySaveData.carRankProgress;
                        break;
                    case ActivityType.winStreak:
                        dataModel.localData = _dataService.ActivitySaveData.winStreak;
                        break;
                    case ActivityType.levelPass:
                        dataModel.localData = _dataService.ActivitySaveData.levelPassProgress;
                        break;
                    case ActivityType.seasonPass:
                        dataModel.localData = _dataService.ActivitySaveData.seasonPassProgress;
                        break;
                    case ActivityType.lavaPass:
                        dataModel.localData = _dataService.ActivitySaveData.lavaPassProgress;
                        break;
                    case ActivityType.limitPk:
                        dataModel.localData = _dataService.ActivitySaveData.limitPkData;
                        break;
                    case ActivityType.gradientGift:
                        dataModel.localData = _dataService.ActivitySaveData.gradientGiftProgress;
                        break;
                    case ActivityType.giftGradientCook:
                        dataModel.localData = _dataService.ActivitySaveData.giftGradientCookProgress;
                        break;
                    case ActivityType.giftGradientDig:
                        dataModel.localData = _dataService.ActivitySaveData.giftGradientDigProgress;
                        break;
                    case ActivityType.rabbitGift:
                        dataModel.localData = _dataService.ActivitySaveData.rabitGiftProgress;
                        break;
                    case ActivityType.adReward:
                        dataModel.localData = _dataService.ActivitySaveData.adRewardProgress;
                        break;
                    case ActivityType.endlessLevel:
                        dataModel.localData = _dataService.ActivitySaveData.endlessLevelProgress;
                        break;
                    case ActivityType.collectMusic:
                        dataModel.localData = _dataService.ActivitySaveData.musicProgress;
                        break;
                    case ActivityType.collectHoney:
                        dataModel.localData = _dataService.ActivitySaveData.honeyProgress;
                        break;
                    case ActivityType.collectWater:
                        dataModel.localData = _dataService.ActivitySaveData.waterProgress;
                        break;
                    case ActivityType.giftPlusOne:
                        dataModel.localData = _dataService.ActivitySaveData.giftPlusOneData;
                        break;
                    case ActivityType.giftDiscount:
                        dataModel.localData = _dataService.ActivitySaveData.giftDiscountData;
                        break;
                    case ActivityType.giftPlusFour:
                        dataModel.localData = _dataService.ActivitySaveData.giftPlusFourData;
                        break;
                    case ActivityType.giftDragOne:
                        dataModel.localData = _dataService.ActivitySaveData.giftDragOneData;
                        break;
                    case ActivityType.giftDragTwo:
                        dataModel.localData = _dataService.ActivitySaveData.giftDragTwoData;
                        break;
                    case ActivityType.giftDragSix:
                        dataModel.localData = _dataService.ActivitySaveData.giftDragSixData;
                        break;
                    case ActivityType.mysteriousSeed:
                        dataModel.localData = _dataService.ActivitySaveData.mysteriousSeedProgress;
                        break;
                }
        }

        
        private void InitAllOpenActivities()
        {
            var beforeList = _allActivities.CopyList();
            foreach (var model in _allActivities)
            {
                GameObjManager.Instance.PushClass(model);
            }
            _allActivities.Clear();
                
            foreach (var activityDict in _activitiesSwitchDict)
            {
                var activity = activityDict.Value;
                if (activity == null) continue;
                if (activity.isOpen != 1) continue;
                if (activity.acType == ActivityType.none) continue;
                UpdateCurActivity(activity.acType);
            }
        }

        private void UpdateServerTimer()
        {
            if ((_serverTime == 0 || TimeUtils.NetTimeUtil.GetNetTime) && _isServerTime == false)
            {
                _serverTime = TimeUtils.GetServerTimeUtc();
                _isServerTime = TimeUtils.NetTimeUtil.GetNetTime;
            }
            if (_serverTime > 0)
            {
                _serverTime++; // 服务器时间   
                _serverDate = TimeUtils.IntToDateTime(_serverTime);
            }
        }


        
        void ReportStartEvent(ActivityType activityType,BaseActivityData data)
        {
            string key = "";
            switch (activityType)
            {
                case ActivityType.limitPk:
                    key = AnalyticsKey.LimitPk_Start;
                    break;
                case ActivityType.passRank:
                    key = AnalyticsKey.PassRank_Start;
                    break;
                case ActivityType.carRank:
                    key = AnalyticsKey.CarRank_Start;
                    break;
                case ActivityType.levelPass:
                    key = AnalyticsKey.LevelPass_Start;
                    break;
                case ActivityType.collectFlower:
                    key = AnalyticsKey.CollectFlower_Start;
                    break;
                case ActivityType.lavaPass:
                    key = AnalyticsKey.Lava_Start;
                    break;
                case ActivityType.endlessLevel:
                    key = AnalyticsKey.Endless_Start;
                    break;
                default:
                    break;
            }
            if (key != "")
            {
                var level_type = 1;
                if (EndlessLevelActivity.IsOpenActivity())
                {
                    level_type = 2;
                }
                var msg = new Dictionary<string, object>
                {
                    { AnalyticsKey.StageType, level_type },
                    {"stage_id", _dataService.NowMaxLevel},
                    {"start_time", data.ActivityBeginTime},
                };
                AnalyticUtils.ReportEvent(key, msg);
            }
        }

        void ReportEndEvent(ActivityType activityType,BaseActivityData data)
        {
            var level_type = 1;
            if (EndlessLevelActivity.IsOpenActivity())
            {
                level_type = 2;
            }
            string key = "";
            var msg = new Dictionary<string, object>();

            if (activityType == ActivityType.levelPass)
            {
                key = AnalyticsKey.LevelPass_End;
                msg = new Dictionary<string, object>
                {
                    {"stage_id", _dataService.NowMaxLevel},
                    { AnalyticsKey.StageType, level_type },
                    {"rank", _dataService.LevelPassProgress.GetMyData().curRank + 1},
                    {"score", _dataService.LevelPassProgress.GetMyData().successVictory},
                    {"rewardFlag",data.RewardFlag},
                };
            }
            else if (activityType == ActivityType.collectFlower)
            {
                key = AnalyticsKey.CollectFlower_End;
                msg = new Dictionary<string, object>
                {
                    {"stage_id", _dataService.NowMaxLevel},
                    { AnalyticsKey.StageType, level_type },
                    {"rank", _dataService.CollectFlowerProgress.GetMyData().curRank + 1},
                    {"score", _dataService.CollectFlowerProgress.GetMyData().flowerCount},
                    {"rewardFlag",data.RewardFlag},
                };
            }
            else if (activityType == ActivityType.limitPk)
            {
                key = AnalyticsKey.limitPk_End;
                msg = new Dictionary<string, object>
                {
                    {"stage_id", _dataService.NowMaxLevel},
                    { AnalyticsKey.StageType, level_type },
                    {"rank", _dataService.LimitPkData.MyIntegral > _dataService.LimitPkData.RobotIntegral ? 1 : 2},
                    {"score", _dataService.LimitPkData.RobotIntegral},
                    {"rewardFlag",data.RewardFlag},
                };
            }
            else if (activityType == ActivityType.passRank)
            {
                key = AnalyticsKey.PassRank_End;
                msg = new Dictionary<string, object>
                {
                    {"stage_id", _dataService.NowMaxLevel},
                    { AnalyticsKey.StageType, level_type },
                    {"rank", _dataService.PassRankProgress.GetMyData().rank + 1},
                    {"score", _dataService.PassRankProgress.myData.cupCount},
                    {"rewardFlag",data.RewardFlag},
                };
            }
            else if (activityType == ActivityType.carRank)
            {
                key = AnalyticsKey.CarRank_End;
                msg = new Dictionary<string, object>
                {
                    {"stage_id", _dataService.NowMaxLevel},
                    { AnalyticsKey.StageType, level_type },
                    {"rank", _dataService.CarRankProgress.GetMyData().rank + 1},
                    {"score", _dataService.CarRankProgress.myData.cupCount},
                    {"rewardFlag",data.RewardFlag},
                };
            }
            else if (activityType == ActivityType.lavaPass)
            {
                key = AnalyticsKey.Lava_End;
                msg = new Dictionary<string, object>
                {
                    {"stage_id", _dataService.NowMaxLevel},
                    { AnalyticsKey.StageType, level_type },
                    {"pass_level", _dataService.LavaPassProgress.winCount},
                    {"result",_dataService.LavaPassProgress.isFailState == 1 ? 2 : 1},
                };
            }
            else if (activityType == ActivityType.endlessLevel)
            {
                key = AnalyticsKey.Endless_End;
                msg = new Dictionary<string, object>
                {
                    {"stage_id", _dataService.NowMaxLevel},
                    { AnalyticsKey.StageType, level_type },
                    {"score", _dataService.EndlessLevelProgress.MyData.integration},
                    {"rank", _dataService.EndlessLevelProgress.GetMyData().curRank},
                };
            }

            if (key != "")
            {
                AnalyticUtils.ReportEvent(key, msg);
            }
        }

        private void CheckStartGetGift(ActivityType activityType)
        {
            if (activityType == ActivityType.cookMeal)
            {
                if (_dataService.CookMealProgress == null) return;
                if (_configService.ValueConfig.TryGetValue("CookMealnitialProps",out string value))
                {
                    int num = int.Parse(value.Split(GameUtils.FirstSeparator)[1]);
                    _dataService.CookMealProgress.cookCount += num;
                }
            }
            if (activityType == ActivityType.digTreasure)
            {
                if (_dataService.DigTreasureProgress == null) return;
                if (_configService.ValueConfig.TryGetValue("DigTreasureInitialProps",out string value))
                {
                    int num = int.Parse(value.Split(GameUtils.FirstSeparator)[1]);
                    _dataService.DigTreasureProgress.digCount += num;
                }
            }
        }
        
        void CheckActivityState(ActivitiesSwitchModel activity,ref ActivityDataModel dataModel,ref Dictionary<ActivityType,bool> needSendRefreshTimer)
        {
            BaseActivityData data = (BaseActivityData) dataModel.localData;
            bool waitActivative = activity.needUserOpen == 1;
            int curTime = GetActivitySeverTime();
            if (waitActivative && !data.UserActivative && !data.StartPopView)
            {
                sendTriggerPopup = true;
                data.StartPopView = true;
            }

            if (activity.ActivityNumberUpper != 0 && data.OpenActivityCount >= activity.ActivityNumberUpper)
            {
                dataModel.state = ActivityState.waitOpen;
                return;
            }
            
            if (!waitActivative || (waitActivative && data.UserActivative))
            {
                if (data.ActivityBeginTime == 0)
                {
                    CheckStartGetGift(activity.acType);
                    ReviseUnlockLevel(data, activity);
                    ReportStartEvent(activity.acType,data);
                    data.SubActivityType = activity.subActivityType;
                    dataModel.state = ActivityState.underWay;
                    int startTime = activity.weekList[0];
                    int endTime = activity.weekList[1];
                    data.IsFirstShow = true;
                    data.ActivityBeginTime = curTime;
                    if (activity.duration != 0)
                    {
                        data.ActivityEndTime = curTime + activity.duration;
                    }
                    else
                    {
                        data.ActivityEndTime = endTime;
                    }
                    sendTriggerPopup = true;
                    needSendRefreshTimer.TryAdd(activity.acType, true);
                }
                else
                {
                    if (data.ActivityEndTime != 0) dataModel.state = ActivityState.underWay;
                    if (data.ActivityEndTime != 0 && curTime > data.ActivityEndTime)
                    {
                        UpdateActivityRobotData();
                        dataModel.state = ActivityState.waitFinished;
                        if (!data.FinishPopView)
                        {
                            data.FinishPopView = true;
                            needSendRefreshTimer.TryAdd(activity.acType, true);
                            sendTriggerPopup = true;
                        }
                        if (data.FinishGetReward)
                        {
                            dataModel.state = ActivityState.finished;
                            if (!data.FinishFlag)
                            {
                                data.FinishFlag = true;
                                needSendRefreshTimer.TryAdd(activity.acType, true);
                            }
                            bool exceedInterval = curTime >= data.ActivityEndTime + activity.openInterval;
                            if (exceedInterval)
                            {
                                _dataService.ActivitySaveData.ClearData(activity.acType);
                                needSendRefreshTimer.TryAdd(activity.acType, true);
                                needRefreshActivity.TryAdd(activity.acType, true);
                            }
                        }
                    }
                }
            }
            else
            {
                dataModel.state = ActivityState.waitEntry;
                if (!data.WaitEntryFlag)
                {
                    data.WaitEntryFlag = true;
                    needSendRefreshTimer.TryAdd(activity.acType, true);
                }
            }
        }

        public void UpdateCurActivity(ActivityType activityType,bool specifyUpdate = false)
        {
            ActivitiesSwitchModel activity = null;
            foreach (var activityDict in _activitiesSwitchDict)
            {
                var model = activityDict.Value;
                if (model == null) continue;
                if (model.acType == activityType)
                {
                    activity = model;
                    break;
                }
            }

            if (activity != null)
            {
                var config = _allActivitiesConfig.Find(item => item.activityId == activity.id);
                ActivityDataModel oldDataModel = GetActivityByType(activityType);
                if (oldDataModel != null)
                {
                    GameObjManager.Instance.PushClass(oldDataModel);
                    _allActivities.Remove(oldDataModel);
                }

                ActivityDataModel dataModel = GameObjManager.Instance.PopClass<ActivityDataModel>();
                if (activity.isOpen != 1) return;

                InitDataModel(activity, config, ref dataModel);
                BaseActivityData data = (dataModel.localData) as BaseActivityData;

                activity.subActivityType = 0;
                activity.inOpenTime = false;
                if (activity.acType == ActivityType.endlessLevel)
                {
                    InitEndlessActivityTime(ref dataModel,ref activity);
                }
                else if (activity.acType == ActivityType.seasonPass)
                {
                    InitSeasonActivityTime(ref dataModel,ref activity);
                    InitUnlockLevel(ref dataModel,ref activity);
                }
                else
                {
                    InitCommonActivityTime(ref dataModel,ref activity);
                    InitUnlockLevel(ref dataModel,ref activity);
                }
                bool isUnlcokLevel = _dataService.MaxLevel >= activity.unlockLevel;
                bool isSpecailLevel = GameUtils.IsSpecialLevel();
                if (!isUnlcokLevel || isSpecailLevel || (!activity.inOpenTime && data.ActivityBeginTime == 0))
                {
                    dataModel.state = ActivityState.waitOpen;
                }
                else
                {
                    CheckActivityState(activity, ref dataModel, ref sendRefreshTimerList);
                }
                var findIndex = _allActivities.FindIndex(item => item.id == dataModel.id);
                if (findIndex == -1) _allActivities.Add(dataModel); // 只添加首次激活的活动
            }

            if (_activitiesSwitchModels.TryGetValue(activityType,out ActivitiesSwitchModel switchModel))
            {
                _activitiesSwitchModels[activityType] = activity;
            }
            else
            {
                _activitiesSwitchModels.TryAdd(activityType, activity);
            }
        }

        public ActivitiesSwitchModel GetActivitySwitchModel(ActivityType activityType)
        {
            return _activitiesSwitchModels.TryGetValue(activityType,out ActivitiesSwitchModel switchModel) ? switchModel : null;
        }
        
        void InitUnlockLevel(ref ActivityDataModel dataModel,ref ActivitiesSwitchModel activity)
        {
            if (activity.acType != ActivityType.none)
            {
                foreach (var pair in _configService.UnlockConfig)
                {
                    if (pair.Value.type == activity.type)
                    {
                        activity.unlockLevel = pair.Value.unlockLevel;
                        break;
                    }
                }
            }
        }

        //赛季通行证
        void InitSeasonActivityTime(ref ActivityDataModel dataModel, ref ActivitiesSwitchModel activity)
        {
            int now = GetActivitySeverTime();
            foreach (var list in dataModel.naturalTimeList)
            {
                if (list.Count > 3)
                {
                    if (list[2] <= now && now <= list[3])
                    {
                        activity.subActivityType = list[0];
                        activity.weekList = new List<int>{list[2],list[3]};
                        activity.inOpenTime = true;
                        dataModel.ActivityBigEndTime = list[3];
                        break;
                    }
                }
            }
        }
        
        //无尽关卡
        void InitEndlessActivityTime(ref ActivityDataModel dataModel,ref ActivitiesSwitchModel activity)
        {
            int now = GetActivitySeverTime();
            activity.unlockLevel = _dataService.MaxLevel + 1;
            foreach (var list in dataModel.naturalTimeList)
            {
                if (list.Count > 3)
                {
                    if (list[2] <= now && now <= list[3])
                    {
                        activity.subActivityType = list[0];
                        activity.unlockLevel = list[1];
                        activity.weekList = new List<int>{list[2],list[3]};
                        activity.inOpenTime = true;
                        dataModel.ActivityBigEndTime = list[3];
                        break;
                    }
                }
            }
            if (_dataService.EndlessLevelProgress != null && _dataService.EndlessLevelProgress.UnlockLevel != 0)
            {
                activity.unlockLevel = _dataService.EndlessLevelProgress.UnlockLevel;
            }
        }

        void InitCommonActivityTime(ref ActivityDataModel dataModel,ref ActivitiesSwitchModel activity)
        {
            DateTime currentDate = GetActivityNowDateTime();
            int dayOfWeekOneToSeven = ((int) currentDate.DayOfWeek + 6) % 7 + 1;
            foreach (var pair in dataModel.olderOpenTime)
            {
                if (pair[1] <= dayOfWeekOneToSeven && dayOfWeekOneToSeven <= pair[2])
                {
                    activity.subActivityType = pair[0];
                    activity.weekList = activity.GetWeekActivitieTime(GetActivitySeverTime(), pair);
                    activity.inOpenTime = true;
                    dataModel.ActivityBigEndTime = activity.weekList[1];
                    break;
                }
            }
        }

        private void ReviseUnlockLevel( BaseActivityData data, ActivitiesSwitchModel activity)
        {
            if(activity.acType != ActivityType.endlessLevel) return;
            (data as EndlessLevelProgress).UnlockLevel = activity.unlockLevel;
        }
        
        public void ClearPopFlag(bool _clearActivityUpper = false)
        {
            foreach (var dataModel in _allActivities)
            {
                if (dataModel.isOpen != 1) continue;
                BaseActivityData data = (BaseActivityData) dataModel.localData;
                bool waitActivative = dataModel.needUserOpen == 1;
                bool waitFinished = dataModel.state == ActivityState.waitFinished;
                
                //if (waitActivative && !data.UserActivative) data.PopBtn = true;
                if (waitFinished && !data.FinishPopView) data.FinishPopView = true;
                if (_clearActivityUpper) data.OpenActivityCount = 0;

                data.IsCheckingFinish = false;

                ReviseOpenActivityCount(dataModel.type == ActivityType.lavaPass,ref data);
            }
        }

        //修正活动开启次数
        private void ReviseOpenActivityCount(bool needRevise,ref BaseActivityData data)
        {
            if(!needRevise) return;
            if(data.OpenActivityCount == 0) return;
            if(!TimeUtils.IsSameDay(_dataService.LavaPassProgress.ActivityBeginTime,GetActivitySeverTime()))
            {
                data.OpenActivityCount = 0;
            }
        }
        
        /// <summary>
        /// 初始化一个后台定时器,每秒刷新，需要定时器执行的事件都可以在这边操作
        /// </summary>
        private void InitBackgroundTimer()
        {
            _backgroundTimer = Observable.Timer(TimeSpan.FromSeconds(1)).Repeat()
                .Subscribe(_ => OnBackgroundTimerUpdate());
        }

        public void SendRefreshActivityTimer(ActivityType acType,float delayTime = 0)
        {
            if (delayTime != 0)
            {
                Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe(_ =>
                {
                    RefreshActivityTimer t = GameObjManager.Instance.PopClass<RefreshActivityTimer>(true);
                    t.Init(acType);
                    TypeEventSystem.Send<RefreshActivityTimer>(t);
                });
            }
            else
            {
                RefreshActivityTimer t = GameObjManager.Instance.PopClass<RefreshActivityTimer>(true);
                t.Init(acType);
                TypeEventSystem.Send<RefreshActivityTimer>(t);
            }
        }
        
        private void OnBackgroundTimerUpdate(bool init = false)
        {
            UpdateServerTimer();
            if (GameUtils.IsInHomeView() || init)
            {
                CheckDayChange();
                ActivitiesStateRefresh();
                UpdateActiveActivitiesTimer();
                CheckFinishActivity();
                CheckOpenHeartBeatGift();
                UpdateActivityRobotData();
                TypeEventSystem.Send(GameObjManager.Instance.PopClass<GlobalTimerRefreshEvent>(true));
            }
        }

        void UpdateActivityRobotData()
        {
            LimitPkActivity.Update();
            PassRankActivity.Update();
            CarRankActivity.Update();
            CollectFlowerActivity.Update();
            LevelPassActivity.Update();
            EnergyActivity.Update();
            GiftActivity.Update();
        }

        void CheckFinishActivity()
        {
            if(GameCommon.IsExitGame) return;
            if (GetActivityByType(ActivityType.seasonPass).state == ActivityState.waitFinished)
            {
                if (!_dataService.SeasonPassProgress.IsCheckingFinish)
                {
                    _dataService.SeasonPassProgress.IsCheckingFinish = true;
                    SeasonPassActivity.CheckFinishActivity();
                }
            }

            if (GetActivityByType(ActivityType.piggy).state == ActivityState.waitFinished)
            {
                if (!_dataService.PiggyData.IsCheckingFinish)
                {
                    _dataService.PiggyData.IsCheckingFinish = true;
                    FinishGetReward(ActivityType.piggy);
                }
            }

            if (GetActivityByType(ActivityType.passRank).state == ActivityState.waitFinished)
            {
                if (!_dataService.PassRankProgress.IsCheckingFinish)
                {
                    _dataService.PassRankProgress.IsCheckingFinish = true;
                    PassRankActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.carRank).state == ActivityState.waitFinished)
            {
                if (!_dataService.CarRankProgress.IsCheckingFinish)
                {
                    _dataService.CarRankProgress.IsCheckingFinish = true;
                    CarRankActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.adReward).state == ActivityState.waitFinished)
            {
                if (!_dataService.AdRewardProgress.IsCheckingFinish)
                {
                    _dataService.AdRewardProgress.IsCheckingFinish = true;
                    AdRewardActivity.CheckFinishActivity();
                }
            }

            if (GetActivityByType(ActivityType.gradientGift).state == ActivityState.waitFinished)
            {
                if (!_dataService.GradientGiftProgress.IsCheckingFinish)
                {
                    _dataService.GradientGiftProgress.IsCheckingFinish = true;
                    GradientGiftActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.giftGradientCook).state == ActivityState.waitFinished)
            {
                if (!_dataService.GiftGradientCookProgress.IsCheckingFinish)
                {
                    _dataService.GiftGradientCookProgress.IsCheckingFinish = true;
                    GiftGradientCookActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.giftGradientDig).state == ActivityState.waitFinished)
            {
                if (!_dataService.GiftGradientDigProgress.IsCheckingFinish)
                {
                    _dataService.GiftGradientDigProgress.IsCheckingFinish = true;
                    GiftGradientDigActivity.CheckFinishActivity();
                }
            }

            if (GetActivityByType(ActivityType.collectLoveCard).state == ActivityState.waitFinished)
            {
                if (!_dataService.CollectLoveCardProgress.IsCheckingFinish)
                {
                    _dataService.CollectLoveCardProgress.IsCheckingFinish = true;
                    CollectLoveCardActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.collectMusic).state == ActivityState.waitFinished)
            {
                if (!_dataService.CollectMusicProgress.IsCheckingFinish)
                {
                    _dataService.CollectMusicProgress.IsCheckingFinish = true;
                    CollectMusicActivity.CheckFinishActivity();
                }
            }

            if (GetActivityByType(ActivityType.rabbitGift).state == ActivityState.waitFinished)
            {
                if (!_dataService.RabitGiftProgress.IsCheckingFinish)
                {
                    _dataService.RabitGiftProgress.IsCheckingFinish = true;
                    RabbitGiftActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.digTreasure).state == ActivityState.waitFinished)
            {
                if (!_dataService.DigTreasureProgress.IsCheckingFinish)
                {
                    _dataService.DigTreasureProgress.IsCheckingFinish = true;
                    DigTreasureActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.mysteriousSeed).state == ActivityState.waitFinished)
            {
                if (!_dataService.MysteriousSeedProgress.IsCheckingFinish)
                {
                    _dataService.MysteriousSeedProgress.IsCheckingFinish = true;
                    MysteriousSeedActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.endlessLevel).state == ActivityState.waitFinished)
            {
                if (!_dataService.EndlessLevelProgress.IsCheckingFinish)
                {
                    _dataService.EndlessLevelProgress.IsCheckingFinish = true;
                    EndlessLevelActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.cookMeal).state == ActivityState.waitFinished)
            {
                if (!_dataService.CookMealProgress.IsCheckingFinish)
                {
                    _dataService.CookMealProgress.IsCheckingFinish = true;
                    CookMealActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.collectHoney).state == ActivityState.waitFinished)
            {
                if (!_dataService.CollectHoneyProgress.IsCheckingFinish)
                {
                    _dataService.CollectHoneyProgress.IsCheckingFinish = true;
                    CollectHoneyActivity.CheckFinishActivity();
                }
            }
            
            if (GetActivityByType(ActivityType.collectWater).state == ActivityState.waitFinished)
            {
                if (!_dataService.CollectWaterProgress.IsCheckingFinish)
                {
                    _dataService.CollectWaterProgress.IsCheckingFinish = true;
                    CollectWaterActivity.CheckFinishActivity();
                }
            }

            if (_dataService.FarmingProgress.collectTimer != -1)
            {
                if (GetActivitySeverTime() >= _dataService.FarmingProgress.collectTimer &&
                    !_dataService.FarmingProgress.resetFlag)
                {
                    FarmingActivity.ResetPickUp(true);
                    _dataService.FarmingProgress.resetFlag = true;
                    TypeEventSystem.Send<UpdateFarmingPanelEvent>();
                }
            }
            
            GiftActivity.CheckFinishActivity();
        }

        public void CheckActivityPopup()
        {
            ActivityManager.Instance.SeasonPassActivity.CheckTriggerPopup();
            ActivityManager.Instance.GradientGiftActivity.CheckTriggerPopup();
            ActivityManager.Instance.GiftGradientCookActivity.CheckTriggerPopup();
            ActivityManager.Instance.GiftGradientDigActivity.CheckTriggerPopup();
            ActivityManager.Instance.CollectLoveCardActivity.CheckTriggerPopup();
            ActivityManager.Instance.CollectMusicActivity.CheckTriggerPopup();
            ActivityManager.Instance.CollectFlowerActivity.CheckTriggerPopup();
            ActivityManager.Instance.PassRankActivity.CheckTriggerPopup();
            ActivityManager.Instance.CarRankActivity.CheckTriggerPopup();
            ActivityManager.Instance.LimitPkActivity.CheckTriggerPopup();
            ActivityManager.Instance.LevelPassActivity.CheckTriggerPopup();
            ActivityManager.Instance.LavaPassActivity.CheckTriggerPopup();
            ActivityManager.Instance.EndlessLevelActivity.CheckTriggerPopup();
            ActivityManager.Instance.RabbitGiftActivity.CheckTriggerPopup();
            ActivityManager.Instance.WheelActivity.CheckTriggerPopup();
            ActivityManager.Instance.CollectWaterActivity.CheckTriggerPopup();
            ActivityManager.Instance.CollectHoneyActivity.CheckTriggerPopup();
            ActivityManager.Instance.MysteriousSeedActivity.CheckTriggerPopup();
            ActivityManager.Instance.GiftActivity.CheckTriggerPopup();
        }

        public void CheckDailyPopup()
        {
            if (GameUtils.CheckFuncIsUnlock("piggy") && _dataService.PiggyData.PopBtn)
            {
                if (!GameCommon.IsShieldPurchase)
                {
                    PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.SaverPopup,BoxBuilder.ShowSaverPopup);
                    _dataService.PiggyData.PopBtn = false;
                }
            }
            //签到
            if (GameUtils.CheckFuncIsUnlock("dailyIn") && !_dataService.CheckDailyFlag(FlagType.SignIn))
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.CheckInPopup, () =>
                {
                    _dataService.LastSignTime = ActivityManager.Instance.GetActivitySeverTime();
                    BoxBuilder.ShowCheckIn();
                });
            }

            //首充
            if (GameUtils.CheckFuncIsUnlock("giftFirst"))
            {
                if (!GameCommon.IsShieldPurchase && !_dataService.IsBuyBeginner)
                {
                    if (!_dataService.IsSmallBuyBeginner)
                    {
                        if (!_dataService.CheckDailyFlag(FlagType.SmallFirstCharge))
                        {
                            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.FirstChargePopup,
                                () => BoxBuilder.ShowFirstCharge(null));
                        }
                    }
                    else
                    {
                        if (!_dataService.CheckDailyFlag(FlagType.FirstCharge))
                        {
                            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.FirstChargePopup,
                                () => BoxBuilder.ShowFirstCharge(null));
                        }
                    }
                }
            }

            //心动礼包
            if (GameUtils.CheckFuncIsUnlock("giftTimeOne"))
            {
                if (!GameCommon.IsShieldPurchase && !_dataService.IsBuyHeartBeatGift &&
                    _dataService.CheckTimeFlag(FlagType.ShowHeartBeatGift) && !GameCommon.IsShowHeartBeat)
                {
                    PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.HeartBeatGift,
                        BoxBuilder.ShowHeartBeatGift);
                    TypeEventSystem.Send<RefreshHeartBeatGift>();
                }
            }

            //周卡月卡
            if (GameUtils.CheckFuncIsUnlock("subscribe") && !_dataService.CheckFirstPopup(Constants.DoozyView.SubscribeChargePopup))
            {
                if (!GameCommon.IsShieldPurchase)
                {
                    PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.SubscribeChargePopup, BoxBuilder.ShowSubscribeCharge);
                }
            }
        }
        
        private void CheckDayChange()
        {
            int now = GetActivitySeverTime();
            bool isSameDay = TimeUtils.IsSameDay(_dataService.LastRefreshTime, now);
            _dataService.LastRefreshTime = now;
            if (isSameDay == false)
            {
                // 新的一天，清空一些数据
                _dataService.TodayLevelPassTimes = 0;
                _dataService.TodayLaunchTimes = 0;
                _dataService.ClearDailyFlag();
                ClearPopFlag(true);
                TypeEventSystem.Send(new NewDayChangeEvent());
                TypeEventSystem.Send<TriggrePopupEvent>();
                _dataService.SaveData(true);
                Debug.Log($">>> CheckDayChange >> is new day ...");
            }
        }

        /// <summary>
        /// 启动已激活的活动的定时器
        /// </summary>
        private void UpdateActiveActivitiesTimer()
        {
            foreach (var activity in _allActivities)
            {
                if (activity.state != ActivityState.finished)
                {
                    // 已激活的活动
                    OnTimerUpdate(activity);
                }
            }
        }

        private void OnTimerUpdate(ActivityDataModel activity)
        {
            int less = 0;
            ActivityTimerRefresh t = GameObjManager.Instance.PopClass<ActivityTimerRefresh>(true);
            t.Init(activity.type, less);
            TypeEventSystem.Send(t);
        }

        /// <summary>
        /// 远程配置更新了
        /// </summary>
        public void RefreshConfig()
        {
            if (!_isInit)
            {
                _configService = MainContainer.Container.Resolve<IConfigService>();
                _dataService = MainContainer.Container.Resolve<IDataService>();
            }
            _activitiesSwitchDict = _configService.ActivitiesSwitchConfig;
            _activityDict = _configService.ActivitiesConfig;
            _seasonRewardDict = _configService.SeasonRewardConfig;
            InitAllActivitiesConfig();
        }

        #endregion

        /// <summary>
        /// 获取指定类型的已激活活动(即活动已开启并且处于活动时间段内，但开启等级或其他条件不一定满足)
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public List<ActivityDataModel> GetActiveActivityByType(ActivityType type)
        {
            // 通常情况下，只有单笔充值这一类型有可能会有多个活动同时满足开启条件
            List<ActivityDataModel> activeList = new List<ActivityDataModel>(3);
            foreach (var activity in _allActivities)
            {
                if (activity.type == type && activity.state != ActivityState.finished) activeList.Add(activity);
            }
            return activeList;
        }

        public void FinishGetReward(ActivityType activityType,bool _resetEndTime = true)
        {
            BaseActivityData data = GetActivityByType(activityType).localData as BaseActivityData;
            data.FinishGetReward = true;
            if (_resetEndTime)
            {
                data.ActivityEndTime = GetActivitySeverTime() - 1;
                data.OpenActivityCount++;
            }
            ReportEndEvent(activityType,data);
            UpdateCurActivity(activityType,true);
            _dataService.SaveData(true);
        }
        
        public ActivityDataModel GetActivityById(int acId)
        {
            return _allActivities.Find(item => item.id == acId);
        }

        public ActivityDataModel GetActivityByType(ActivityType activityType)
        {
            return _allActivities.Find(item => item.type == activityType);
        }

        public bool CanShowActivityBtn(ActivityType activityType)
        {
            if (GetActivityByType(activityType) == null) return false;
            return GetActivityByType(activityType).state != ActivityState.waitOpen;
        }

        public void CheckOpenActivity(bool isWin)
        {
            if (isWin)
            {
                PassRankActivity.CheckOpenActivity();
                CarRankActivity.CheckOpenActivity();
                CollectFlowerActivity.CheckOpenActivity();
                CollectLoveCardActivity.CheckOpenActivity();
                SeasonPassActivity.CheckOpenActivity();
                LevelPassActivity.CheckOpenActivity();
                LimitPkActivity.CheckOpenActivity();
                EndlessLevelActivity.CheckOpenActivity();
                WheelActivity.CheckOpenActivity();
                CollectWaterActivity.CheckOpenActivity();
                CollectHoneyActivity.CheckOpenActivity();
            }
            DigTreasureActivity.CheckOpenActivity(isWin);
            CookMealActivity.CheckOpenActivity(isWin);
            MysteriousSeedActivity.CheckOpenActivity(isWin);
            CollectMusicActivity.CheckOpenActivity(isWin);
            LavaPassActivity.CheckOpenActivity(isWin);
            RabbitGiftActivity.CheckOpenActivity(isWin);
        }

        private void CheckOpenHeartBeatGift()
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            if (GameUtils.CheckFuncIsUnlock("giftTimeOne") && !_dataService.GetTimeFlagDic().ContainsKey(FlagType.ShowHeartBeatGift))
            {
                _dataService.AddTimeFlag(FlagType.ShowHeartBeatGift);
                TypeEventSystem.Send<TriggrePopupEvent>();
            }
        }
        
        public List<ActivityDataModel> GetShowActivityItem()
        {
            List<ActivityDataModel> temp = new List<ActivityDataModel>();
            foreach (var pair in _allActivities)
            {
                if(pair.type == ActivityType.endlessLevel) continue;
                if (pair.isOpen == 1 && pair.needUserOpen == 1 && _dataService.MaxLevel >= pair.unlockStage && pair.state != ActivityState.waitOpen)
                {
                    temp.Add(pair);
                }
            }
            return temp;
        }

        public void InitResultAddCount()
        {
            ClearResultAddCount();
            foreach (var model in _allActivities)
            {
                BaseActivityData data = model.localData as BaseActivityData;
                if (model.type == ActivityType.seasonPass && model.state == ActivityState.underWay)
                {
                    data.ResultAddCount = SeasonPassActivity.GetPoint();
                }
                else if (model.type == ActivityType.passRank && model.state == ActivityState.underWay)
                {
                    data.ResultAddCount = PassRankActivity.GetPoint();
                }
                else if (model.type == ActivityType.cookMeal && model.state == ActivityState.underWay)
                {
                    data.ResultAddCount = CookMealActivity.GetPoint();
                }
                else if (model.type == ActivityType.digTreasure && model.state == ActivityState.underWay)
                {
                    data.ResultAddCount = DigTreasureActivity.GetPoint();
                }
                else if (model.type == ActivityType.carRank && model.state == ActivityState.underWay)
                {
                    data.ResultAddCount = CarRankActivity.GetPoint();
                }
                else if (model.type == ActivityType.endlessLevel && model.state == ActivityState.underWay)
                {
                    data.ResultAddCount = EndlessLevelActivity.GetPoint();
                }
                else if (model.type == ActivityType.collectMusic && model.state == ActivityState.underWay)
                {
                    data.ResultAddCount = CollectMusicActivity.GetPoint();
                }
                //GameUtils.LogError($"---{model.type},==={data.ResultAddCount}");
            }
        }
        
        public void ClearResultAddCount()
        {
            bool needSave = false;
            foreach (var model in _allActivities)
            {
                BaseActivityData data = model.localData as BaseActivityData;
                data.ResultAddCount = 0;
            }

            LimitPkActivity?.InitData();
            CollectLoveCardActivity?.InitData();
            SaveActivityData();
        }
        
        public void CheckActivityCard(BaseCard card = null, Action action = null)
        {
            CardData cardData = card.CardData;
            CollectLoveCardActivity.CheckActivityCard(cardData, () => {
                FlowAddEvent t = GameObjManager.Instance.PopClass<FlowAddEvent>(true);
                t.Init(CollectLoveCardActivity.GetPoint(), 1, card.transform.position - new Vector3(0, 100, 0), PropEnum.CollectCard, 0, true);
                TypeEventSystem.Send<FlowAddEvent>(t);
            });
            LimitPkActivity.CheckActivityCard(cardData, () =>
            {
                FlowAddEvent t = GameObjManager.Instance.PopClass<FlowAddEvent>(true);
                t.Init(LimitPkActivity.GetPoint(), 1, card.transform.position - new Vector3(0, -100, 0), PropEnum.CollectRiot, 0, true);
                TypeEventSystem.Send<FlowAddEvent>(t);
            });
        }

        public void ClearActivityCard(BaseCard card = null, Action action = null)
        {
            CardData cardData = card.CardData;
            CollectLoveCardActivity.ClearActivityCard(cardData);
            LimitPkActivity.ClearActivityCard(cardData);
        }

        public void SaveActivityData()
        {
            _dataService.UpdateActivitySaveData();
        }

        public void Dispose()
        {
            _backgroundTimer.Dispose();
        }

        public int GetActivitySeverTime()
        {
            if (_serverTime > 0)
            {
                return _serverTime;
            }
            else
            {
                return TimeUtils.DateTimeToLong(DateTime.Now);
            }
        }

        public DateTime GetActivityNowDateTime()
        {
            if (_serverTime > 0 && _serverDate != DateTime.MaxValue)
            {
                return _serverDate;
            }
            else
            {
                return DateTime.Now;
            }
        }

        public void OpereateServerTime(int input = -1)
        {
            if (input != -1)
            {
                _serverTime = input;
            }
            else
            {
                _serverTime += (29 * 24 * 3600 + 3600 * 12 + 60 * 18);
            }
        }
        
        public bool CheckActivityIsUnderWay(ActivityType activityType)
        {
            return GetActivityByType(activityType) != null && GetActivityByType(activityType).state == ActivityState.underWay;
        }

        public void HandleActivityItem(ref Dictionary<int, int> rewards)
        {
            if (rewards.Count <= 0) return;

            // 记录需要移除的键
            List<int> keysToRemove = new List<int>();

            foreach (var pair in rewards)
            {
                if (pair.Key == (int)PropEnum.ItemDig)
                {
                    DigTreasureActivity.AddMyDigCount(pair.Value);
                    keysToRemove.Add(pair.Key);
                }
                else if (pair.Key == (int)PropEnum.ItemCook)
                {
                    CookMealActivity.AddMyCookCount(pair.Value);
                    keysToRemove.Add(pair.Key);
                }
                else if (pair.Key == (int)PropEnum.ItemWater)
                {
                    CollectWaterActivity.AddMyWaterCount(pair.Value);
                    keysToRemove.Add(pair.Key);
                }
                else if (pair.Key == (int)PropEnum.ItemHoney)
                {
                    CollectHoneyActivity.AddMyHoneyCount(pair.Value);
                    keysToRemove.Add(pair.Key);
                }
                else if (pair.Key == (int) PropEnum.GradientCook)
                {
                    GiftGradientCookActivity.UpdateProgress(pair.Value);
                    keysToRemove.Add(pair.Key);
                }
                else if (pair.Key == (int) PropEnum.GradientDig)
                {
                    GiftGradientDigActivity.UpdateProgress(pair.Value);
                    keysToRemove.Add(pair.Key);
                }
            }

            // foreach (var key in keysToRemove)
            // {
            //     rewards.Remove(key);
            // }
        }

        public List<ActivityDataModel> GetCollectActivity()
        {
            List<ActivityDataModel> lists = new List<ActivityDataModel>();
            foreach (var pair in _allActivities)
            {
                if (pair.type == ActivityType.collectLoveCard || pair.type == ActivityType.collectMusic
                    || pair.type == ActivityType.passRank || pair.type == ActivityType.limitPk
                     || pair.type == ActivityType.collectFlower || pair.type == ActivityType.digTreasure || pair.type == ActivityType.seasonPass
                       || pair.type == ActivityType.carRank || pair.type == ActivityType.cookMeal || pair.type == ActivityType.endlessLevel)
                {
                    BaseActivityData data = pair.localData as BaseActivityData;
                    if (pair.state == ActivityState.underWay && pair.isOpen == 1)
                    {
                        if (pair.needUserOpen == 1)
                        {
                            if (data.UserActivative)
                            {
                                lists.Add(pair);
                            }
                        }
                        else
                        {
                            lists.Add(pair);
                        }
                    }
                }
            }
            return lists;
        }

        public void AddCombo(int comboNum, bool sameColor)
        {
            CollectFlowerActivity?.AddCombo(comboNum, sameColor);
        }

        public void SubCombo(int comboNum, bool sameColor)
        {
            CollectFlowerActivity?.SubCombo(comboNum, sameColor);
        }
        
    }
}