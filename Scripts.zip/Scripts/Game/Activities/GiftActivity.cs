﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface IGiftActivity
{
    void CheckTriggerPopup();
    void CheckFinishActivity();
    void Update();
    void UpdateGiftDragData(ShopModel model);
    void UpdateGiftPlusData(ShopModel model);
    Dictionary<int, int> GetBuyDragOneReward(ShopModel model);
}

public class GiftActivity: IGiftActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();


    public GiftActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.SubscribeGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.SubscribeGuide);
        
        int seconds = (int)dataService.GetPropNum((int)PropEnum.MonthCard)  - TimeUtils.UtcNow();
        bool isBuyMonth = seconds > 0;
        bool canGetMonth = isBuyMonth && !dataService.CheckDailyFlag(FlagType.Month);
        
        seconds = (int)dataService.GetPropNum((int)PropEnum.WeekCard)  - TimeUtils.UtcNow();
        bool isBuyWeek = seconds > 0;
        bool canGetWeek = isBuyWeek && !dataService.CheckDailyFlag(FlagType.Week);

        if (canGetMonth || canGetWeek)
        {
            list.Add(rootNode);
        }
        return list;
    }

    
    public void Update()
    {
        
    }
    
    public void CheckFinishActivity()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.giftDragOne).state == ActivityState.waitFinished)
        {
            if (!dataService.GiftDragOneData.IsCheckingFinish)
            {
                dataService.GiftDragOneData.IsCheckingFinish = true;
                ActivityManager.Instance.FinishGetReward(ActivityType.giftDragOne);
            }
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.giftDragTwo).state == ActivityState.waitFinished)
        {
            if (!dataService.GiftDragTwoData.IsCheckingFinish)
            {
                dataService.GiftDragTwoData.IsCheckingFinish = true;
                ActivityManager.Instance.FinishGetReward(ActivityType.giftDragTwo);
            }
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.giftDragSix).state == ActivityState.waitFinished)
        {
            if (!dataService.GiftDragSixData.IsCheckingFinish)
            {
                dataService.GiftDragSixData.IsCheckingFinish = true;
                ActivityManager.Instance.FinishGetReward(ActivityType.giftDragSix);
            }
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.giftPlusOne).state == ActivityState.waitFinished)
        {
            if (!dataService.GiftPlusOneData.IsCheckingFinish)
            {
                dataService.GiftPlusOneData.IsCheckingFinish = true;
                ActivityManager.Instance.FinishGetReward(ActivityType.giftPlusOne);
            }
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.giftPlusFour).state == ActivityState.waitFinished)
        {
            if (!dataService.GiftPlusFourData.IsCheckingFinish)
            {
                dataService.GiftPlusFourData.IsCheckingFinish = true;
                ActivityManager.Instance.FinishGetReward(ActivityType.giftPlusFour);
            }
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.giftDiscount).state == ActivityState.waitFinished)
        {
            if (!dataService.GiftDiscountData.IsCheckingFinish)
            {
                dataService.GiftDiscountData.IsCheckingFinish = true;
                ActivityManager.Instance.FinishGetReward(ActivityType.giftDiscount);
            }
        }
    }

    public Dictionary<int, int> GetBuyDragOneReward(ShopModel model)
    {
        Dictionary<int, int> reward = new Dictionary<int, int>();
        Dictionary<int, int> reward1 = GameUtils.AnalysisPropString(model.reward);
        Dictionary<int, int> reward2 = GameUtils.AnalysisPropString(model.rewardFree);
        
        foreach (var pair in reward1)
        {
            reward.Add(pair.Key,pair.Value);
        }
        foreach (var pair in reward2)
        {
            if (reward.ContainsKey(pair.Key))
            {
                reward[pair.Key] += pair.Value;
            }
            else
            {
                reward.Add(pair.Key,pair.Value);
            }
        }
        return reward;
    }

    public void UpdateGiftDragData(ShopModel model)
    {
        if (model.product_id.Contains("GiftDragOne"))
        {
            dataService.GiftDragOneData.curIndex++;
            if (dataService.GiftDragOneData.curIndex > 3) dataService.GiftDragOneData.curIndex = 1;
        }
        else if (model.product_id.Contains("GiftDragTwo"))
        {
            dataService.GiftDragTwoData.curIndex++;
            if (dataService.GiftDragTwoData.curIndex > 3) dataService.GiftDragTwoData.curIndex = 1;
        }
        else if (model.product_id.Contains("GiftDragSix"))
        {
            dataService.GiftDragSixData.curIndex++;
            if (dataService.GiftDragSixData.curIndex > 3) dataService.GiftDragSixData.curIndex = 1;
        }
        TypeEventSystem.Send<HideGiftDragPopup>();
    }
    
    public void UpdateGiftPlusData(ShopModel model)
    {
        if (model.product_id.Contains("GiftPlusOne"))
        {
            dataService.GiftPlusOneData.curIndex++;
            if (dataService.GiftPlusOneData.curIndex > 3) dataService.GiftPlusOneData.curIndex = 1;
        }
        else if (model.product_id.Contains("GiftPlusFour"))
        {
            dataService.GiftPlusFourData.curIndex++;
            if (dataService.GiftPlusFourData .curIndex > 3) dataService.GiftPlusFourData.curIndex = 1;
        }
        TypeEventSystem.Send<HideGiftPlusPopup>();
    }

    public void CheckTriggerPopup()
    {
        if (dataService.GiftDragOneData.PopBtn && ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.giftDragOne))
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.GiftDragOnePopup, () =>
            {
                BoxBuilder.ShowGiftDragOnePopup();
                dataService.GiftDragOneData.PopBtn = false;
            });
        }

        if (dataService.GiftDragTwoData.PopBtn && ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.giftDragTwo))
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.GiftDragTwoPopup, () =>
            {
                BoxBuilder.ShowGiftDragTwoPopup();
                dataService.GiftDragTwoData.PopBtn = false;
            });
        }
        
        if (dataService.GiftDragSixData.PopBtn && ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.giftDragSix))
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.GiftDragSixPopup, () =>
            {
                BoxBuilder.ShowGiftDragSixPopup();
                dataService.GiftDragSixData.PopBtn = false;
            });
        }
        
        if (dataService.GiftPlusOneData.PopBtn && ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.giftPlusOne))
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.GiftPlusOnePopup, () =>
            {
                BoxBuilder.ShowGiftPlusOnePopup();
                dataService.GiftPlusOneData.PopBtn = false;
            });
        }
        
        if (dataService.GiftPlusFourData.PopBtn && ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.giftPlusFour))
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.GiftPlusFourPopup, () =>
            {
                BoxBuilder.ShowGiftPlusFourPopup();
                dataService.GiftPlusFourData.PopBtn = false;
            });
        }
                
        if (dataService.GiftDiscountData.PopBtn && ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.giftDiscount))
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.GiftDiscountPopup, () =>
            {
                BoxBuilder.ShowGiftDiscountPopup();
                dataService.GiftDiscountData.PopBtn = false;
            });
        }
    }
}