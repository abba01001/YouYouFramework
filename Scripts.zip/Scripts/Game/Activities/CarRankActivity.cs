using Activities;
using QFramework;
using System;
using System.Collections.Generic;
using System.Text;
using Model;
using SoliUtils;

public interface ICarRankActivity
{
    void CheckOpenActivity();
    int GetAddCount();
    void Update();
    void CheckFinishActivity();
    Dictionary<int, int> GetRewardConfig(int rankLevel);
    void GMAddCupCount(int count);
    void OperateRobotCupCount(CarRankRobotRuleModel model);
    void CheckRefreshRobot();
    int GetPoint(int inputBet = -1);
    void CheckTriggerPopup();
}

public class CarRankActivity : ICarRankActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();
    //机器人刷新时间节点
    private DateTime _curTimeNode = DateTime.MinValue;

    private DateTime CurTimeNode
    {
        get => _curTimeNode;
        set
        {
            bool finish = true;
            int node = 0;
            dataService.CarRankProgress.CurNodeId = 0;
            CarRankRobotRuleModel ruleModel = null;
            DateTime startTime = TimeUtils.IntToDateTime(dataService.CarRankProgress.ActivityBeginTime);
            foreach (var model in configService.CarRankRobotRule)
            {
                node += model.Key;
                if (ActivityManager.Instance.GetActivityNowDateTime() <= startTime.AddMinutes(node))
                {
                    _curTimeNode = startTime.AddMinutes(node);
                    ruleModel = model.Value;
                    finish = false;
                    break;
                }
                dataService.CarRankProgress.CurNodeId++;
            }
            if (finish) _curTimeNode = DateTime.MaxValue;
            OperateRobotCupCount(ruleModel);
        }
    }

    public void Update()
    {
        if (dataService.CarRankProgress is {ActivityBeginTime: > 0})
        {
            CheckRefreshRobot();
        }
    }
    
    public void CheckRefreshRobot()
    {
        if (CurTimeNode == DateTime.MaxValue)
        {
            return;
        }
        if (CurTimeNode == DateTime.MinValue)
        {
            CurTimeNode = ActivityManager.Instance.GetActivityNowDateTime();
        }
        if (ActivityManager.Instance.GetActivityNowDateTime() >= CurTimeNode)
        {
            CurTimeNode = ActivityManager.Instance.GetActivityNowDateTime();
        }
    }
    
    public void OperateRobotCupCount(CarRankRobotRuleModel model)
    {
        if(model == null) return;
        dataService.CarRankProgress.InitRankInfo();
        foreach (var data in dataService.CarRankProgress.GetRobotData())
        {
            if (data.robotType == model.robotType)
            {
                int count = GameUtils.RandomRange(model.range[0], model.range[1]);
                data.cupCount += count;
            }
        }
    }

    public void GMAddCupCount(int count)
    {
        OperateMyCupCount(count);
    }

    public void CheckOpenActivity()
    {
        if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.carRank)) return;
        dataService.CarRankProgress.GetRankData();
        OperateMyCupCount();
        TypeEventSystem.Send<RefreshActivityRank>();
    }

    public int GetAddCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.carRank).state != ActivityState.underWay)
        {
            dataService.CarRankProgress.ResultAddCount = 0;
            return 0;
        }
        return dataService.CarRankProgress.ResultAddCount;
    }

    private void OperateMyCupCount(int inputCount = 0)
    {
        int addCount = inputCount == 0 ? GetPoint() : inputCount;
        
        var msg = new Dictionary<string, object>
        {
            {"score_before", dataService.CarRankProgress.myData.cupCount},
            {"score_add", addCount},
            {"start_time", dataService.CarRankProgress.ActivityBeginTime},
        };
        AnalyticUtils.ReportEvent(AnalyticsKey.CarRank_Score, msg);
        
        dataService.CarRankProgress.myData.cupCount += addCount;
        dataService.CarRankProgress.ResultAddCount = addCount;
    }

    public int GetPoint(int inputBet = -1)
    {
        if (inputBet != -1)
        {
            return 1 * dataService.GetCollectBet();
        }
        return 1 * dataService.GetCollectBet();
    }

    public void CheckTriggerPopup()
    {
        if (dataService.CarRankProgress.PopBtn && ActivityManager.Instance.GetActivityByType(ActivityType.carRank).state == ActivityState.underWay)
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartCarRankPopup,() =>
            {
                BoxBuilder.ShowStartCarRankPopup();
            });
            dataService.CarRankProgress.PopBtn = false;
        }
    }
    #region 活动结束，发放游戏奖励

    public void CheckFinishActivity()
    {
        int rank = dataService.CarRankProgress.GetMyData().rank + 1;
        Dictionary<int, int> reward = GetRewardConfig(rank);
        if (reward == null)
        {
            ActivityManager.Instance.FinishGetReward(ActivityType.carRank);
        }
        else
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.RewardPopup, () =>
            {
                BoxBuilder.ShowRewardPop(reward, PropChangeWay.CarRankReward,
                    activityType: ActivityType.carRank, param: new object[] {rank,ActivityManager.Instance.GetActivityByType(ActivityType.carRank).RewardTitle},
                    startCall: () =>
                    {
                        ActivityManager.Instance.FinishGetReward(ActivityType.carRank);
                    });
            },true,1);
        }
    }

    public Dictionary<int, int> GetRewardConfig(int rankLevel)
    {
        configService.CarRankRewardConfig.TryGetValue(rankLevel, out CarRankRewardModel model);
        if (model != null)
        {
            return GameUtils.AnalysisPropString(model.Reward);
        }
        return null;
    }

    #endregion
}