using QFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Activities;
using Model;
using SoliUtils;
using System.Diagnostics;
using UniRx;

public interface ICollectFlowerActivity
{
    int GetAddCount();
    void InitRankInfo();
    void Update();
    void CheckOpenActivity();
    int GetReadyAddCount();
    void GMAddFlower(int count);
    void CheckFinishActivity();
    Dictionary<int, int> GetReward();
    void CheckTriggerPopup();
    void AddCombo(int comboNum, bool sameColor);
    void SubCombo(int comboNum, bool sameColor);
    bool IsOpenActivity();
}

public class CollectFlowerActivity : ICollectFlowerActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public CollectFlowerActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.FlowerGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.FlowerGuide);
        if (dataService.CollectFlowerProgress.IsFirstShow) list.Add(rootNode);
        if (dataService.CollectFlowerProgress.ActivityEndTime != 0 && ActivityManager.Instance.GetActivitySeverTime() >
            dataService.CollectFlowerProgress.ActivityEndTime - 300)
            list.Add(rootNode.GetChildNode(1));
        return list;
    }

    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state ==
               ActivityState.underWay;
    }

    //机器人刷新时间节点
    private DateTime _curTimeNode = DateTime.MinValue;

    private DateTime CurTimeNode
    {
        get => _curTimeNode;
        set
        {
            bool finish = true;
            int node = 0;
            dataService.CollectFlowerProgress.CurNodeId = 0;
            DateTime startTime = TimeUtils.IntToDateTime(dataService.CollectFlowerProgress.ActivityBeginTime);
            foreach (var model in configService.CollectFlowerConfig)
            {
                node += model.Value.node;
                if (ActivityManager.Instance.GetActivityNowDateTime() <= startTime.AddMinutes(node))
                {
                    _curTimeNode = startTime.AddMinutes(node);
                    finish = false;
                    break;
                }

                dataService.CollectFlowerProgress.CurNodeId++;
            }

            if (finish) _curTimeNode = DateTime.MaxValue;
            OperateRobotFlowerCount();
        }
    }

    public int GetAddCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state != ActivityState.underWay)
        {
            dataService.CollectFlowerProgress.ResultAddCount = 0;
            return 0;
        }

        return dataService.CollectFlowerProgress.ResultAddCount;
    }

    public void InitRankInfo()
    {
        dataService.CollectFlowerProgress.InitRankInfo();
    }

    public void Update()
    {
        if (dataService.CollectFlowerProgress is {ActivityBeginTime: > 0})
        {
            CheckRefreshRobot();
        }
    }

    private void CheckRefreshRobot()
    {
        if (CurTimeNode == DateTime.MaxValue)
        {
            return;
        }

        if (CurTimeNode == DateTime.MinValue)
        {
            CurTimeNode = ActivityManager.Instance.GetActivityNowDateTime();
        }

        if (ActivityManager.Instance.GetActivityNowDateTime() >= CurTimeNode)
        {
            CurTimeNode = ActivityManager.Instance.GetActivityNowDateTime();
        }
    }

    public void CheckOpenActivity()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state !=
            ActivityState.underWay) return;
        InitRankInfo();
        OperateMyFlowerCount();
        TypeEventSystem.Send<UpdateCollectFlowerInfoEvent>();
    }

    //获取待添加的鲜花数
    public int GetReadyAddCount()
    {
        return dataService.CollectFlowerProgress.ResultAddCount;
    }

    public void AddCombo(int comboNum, bool sameColor)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state !=
            ActivityState.underWay) return;
        int count = 0;
        foreach (var model in configService.CollectFlowerConfig)
        {
            if (model.Value.comboCount == comboNum)
            {
                count += model.Value.flowerCount * GetFlowerBet() * dataService.GetCollectBet();
                break;
            }
        }

        count *= GetOneColorComboBet(sameColor);
        dataService.CollectFlowerProgress.ResultAddCount += count;
        TypeEventSystem.Send<AddFlowerEvent>(new AddFlowerEvent(count));
    }

    public void SubCombo(int comboNum, bool sameColor)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state !=
            ActivityState.underWay) return;
        int count = 0;
        foreach (var model in configService.CollectFlowerConfig)
        {
            if (model.Value.comboCount == comboNum)
            {
                count += model.Value.flowerCount * GetFlowerBet() * dataService.GetCollectBet();
                break;
            }
        }

        dataService.CollectFlowerProgress.ResultAddCount -= count;
        TypeEventSystem.Send<AddFlowerEvent>(new AddFlowerEvent(-count));
    }

    public void GMAddFlower(int count)
    {
        dataService.CollectFlowerProgress.ResultAddCount = count;
        OperateMyFlowerCount(count);
    }

    //combo同色倍数X2
    private int GetOneColorComboBet(bool sameColor)
    {
        return sameColor ? 2 : 1;
    }

    //获取鲜花倍数
    private int GetFlowerBet()
    {
        int bet = 1;
        foreach (var model in configService.CollectFlowerConfig)
        {
            if (model.Value.entryBet == dataService.NowBet)
            {
                bet = model.Value.flowerBet;
                break;
            }
        }

        return bet;
    }

    //设置玩家鲜花数
    private void OperateMyFlowerCount(int inputCount = 0)
    {
        int addCount = inputCount == 0 ? dataService.CollectFlowerProgress.ResultAddCount : inputCount;
        var msg = new Dictionary<string, object>
        {
            {"score_before", dataService.CollectFlowerProgress.GetMyData().flowerCount},
            {"score_add", addCount},
            {"start_time", dataService.CollectFlowerProgress.ActivityBeginTime},
        };
        AnalyticUtils.ReportEvent(AnalyticsKey.CollectFlower_Score, msg);

        dataService.CollectFlowerProgress.GetMyData().flowerCount += addCount;
    }

    //设置机器人鲜花数
    private void OperateRobotFlowerCount()
    {
        foreach (var robotData in dataService.CollectFlowerProgress.GetRobotData())
        {
            robotData.flowerCount =
                dataService.CollectFlowerProgress.GetRobotStepAddCount(robotData,
                    dataService.CollectFlowerProgress.CurNodeId);
        }

        ActivityManager.Instance.SaveActivityData();
        TypeEventSystem.Send<RefreshActivityRank>();
    }

    #region 活动结束，发放游戏奖励

    public void CheckFinishActivity()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state !=
            ActivityState.waitFinished) return;
        int rank = dataService.CollectFlowerProgress.GetMyData().curRank + 1;
        if (dataService.CollectFlowerProgress.GetMyData().curRank == 0)
        {
            dataService.CollectFlowerProgress.RewardFlag = 1;
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.RewardPopup, () =>
            {
                BoxBuilder.ShowRewardPop(GetReward(), PropChangeWay.CollectFlowerReward,
                    activityType: ActivityType.collectFlower,
                    param: new object[]
                        {rank, ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).RewardTitle},
                    startCall: () => { ActivityManager.Instance.FinishGetReward(ActivityType.collectFlower); });
            }, true, 1);
        }
        else
        {
            ActivityManager.Instance.FinishGetReward(ActivityType.collectFlower);
        }

        Observable.TimerFrame(6).Subscribe(_ => { BoxBuilder.HideCollectFlowerPopup(); });
    }

    public Dictionary<int, int> GetReward()
    {
        string reward = "";
        foreach (var VARIABLE in configService.CollectFlowerConfig)
        {
            if (VARIABLE.Value.reward != "")
            {
                reward = VARIABLE.Value.reward;
                break;
            }
        }

        Dictionary<int, int> rewardDic = GameUtils.AnalysisPropString(reward);
        return rewardDic;
    }

    public void CheckTriggerPopup()
    {
        if (dataService.CollectFlowerProgress.PopBtn &&
            ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state == ActivityState.waitEntry ||
            dataService.CollectFlowerProgress.FinishPopView)
        {
            if (dataService.CollectFlowerProgress.FinishPopView)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.CollectFlowerPopup, () =>
                {
                    dataService.CollectFlowerProgress.FinishPopView = false;
                    BoxBuilder.ShowCollectFlowerPopup();
                });
            }
            else
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartCollectFlowerPopup,
                    BoxBuilder.ShowStartCollectFlowerPopup);
                dataService.CollectFlowerProgress.PopBtn = false;
            }
        }
    }

    #endregion
}