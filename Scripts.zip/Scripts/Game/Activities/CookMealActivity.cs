﻿using QFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface ICookMealActivity
{
    void CheckOpenActivity(bool isWin);
    int GetAddCount();
    void CheckGetReward();
    void GMAddCount(int count);
    void CheckFinishActivity();
    void InitData();
    void CheckTriggerPopup();
    bool IsOpenActivity();
    void SaveMaterialProgress(List<int> matList);
    int GetCookCount();
    bool CheckIsMaxLayer();
    List<int> GetFinalMaterial();
    CookMealModel GetCurLayerMealSuit();
    int GetMaterialProgress(int matType);
    bool CheckJumpNextLayer();
    void RefreshLastLayer();
    void AddMyCookCount(int count);
    void Dice(Action success, Action fail);
    List<RedDotNode> GetRedDotNodes();
    int GetPoint();
}

public class CookMealActivity : ICookMealActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();
    private Dictionary<PropEnum, int> rewardDic = new Dictionary<PropEnum, int>();
    private Dictionary<MealType, List<MealMaterialType>> MealInfo = new Dictionary<MealType, List<MealMaterialType>>();

    public CookMealActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.CookGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.CookGuide);
        if (dataService.CookMealProgress.IsFirstShow)
            list.Add(rootNode);
        if (dataService.CookMealProgress.ActivityEndTime != 0 && ActivityManager.Instance.GetActivitySeverTime() >
            dataService.CookMealProgress.ActivityEndTime - 300)
            list.Add(rootNode);
        return list;
    }

    public void Dice(Action success, Action fail)
    {
        int consumeCount = 20;
        if (dataService.CookMealProgress.cookCount >= consumeCount)
        {
            dataService.CookMealProgress.cookCount -= consumeCount;
            success?.Invoke();
        }
        else
        {
            fail?.Invoke();
        }
    }

    public void GMAddCount(int count)
    {
        dataService.CookMealProgress.ResultAddCount = count;
        dataService.CookMealProgress.cookCount += dataService.CookMealProgress.ResultAddCount;
    }

    public void AddMyCookCount(int count)
    {
        if (!IsOpenActivity()) return;
        dataService.CookMealProgress.cookCount += count;
    }

    public void RefreshLastLayer()
    {
        dataService.CookMealProgress.lastLayer = dataService.CookMealProgress.curLayer;
        ActivityManager.Instance.SaveActivityData();
    }

    public void InitData()
    {
    }

    //设置玩家收集的方块爱心卡牌数
    private void OperateMyCookCount(bool isWin)
    {
        if (isWin)
        {
            dataService.CookMealProgress.cookCount += dataService.CookMealProgress.ResultAddCount;
        }
    }

    public int GetPoint()
    {
        return 20;
    }

    public void CheckOpenActivity(bool isWin)
    {
        if (!IsOpenActivity()) return;
        OperateMyCookCount(isWin);
    }

    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.cookMeal) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.cookMeal).state ==
               ActivityState.underWay;
    }


    public int GetAddCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.cookMeal).state != ActivityState.underWay)
        {
            dataService.CookMealProgress.ResultAddCount = 0;
            return 0;
        }

        return dataService.CookMealProgress.ResultAddCount;
    }


    //检测跳转到下一层
    public bool CheckJumpNextLayer()
    {
        CookMealModel model = GetCurLayerMealSuit();
        bool canJump = CheckAllMaterialFull(model);
        if (canJump)
        {
            TypeEventSystem.Send<UpdateCookFinishEvent>();
            if (!CheckMaxLayer())
            {
                JumpNextLayer();
                dataService.SaveRewardData(GameUtils.AnalysisPropString(model.reward), PropChangeWay.DigTreasureReward);
                dataService.RecordBubbleItem = null;
                return true;
            }
            return false;
        }
        return false;
    }

    private void JumpNextLayer()
    {
        dataService.CookMealProgress.curLayer++;
        dataService.CookMealProgress.MaterialProgress.Clear();
    }

    private bool CheckMaxLayer()
    {
        return dataService.CookMealProgress.curLayer > 5;
    }

    public int GetCookCount()
    {
        return dataService.CookMealProgress.cookCount;
    }

    public int GetMaterialProgress(int matType)
    {
        dataService.CookMealProgress.MaterialProgress.TryGetValue(matType, out int value);
        return value;
    }

    public void SaveMaterialProgress(List<int> matList)
    {
        bool tripple = matList[0] == matList[1] && matList[0] == matList[2];
        CookMealModel model = GetCurLayerMealSuit();
        if (tripple)
        {
            int addCount = 9;
            int matType = matList[0];
            CheckCurMaterialFull(matList[0], ref addCount);
            if ((MealMaterialType) matList[0] == MealMaterialType.Coin)
            {
                //加金币
                dataService.AddCoin(model.GoldNum * 9, PropChangeWay.CookMealCoin, Vector3.zero, false);
            }
            else if ((MealMaterialType) matList[0] == MealMaterialType.Pine)
            {
                //加积攒金币
                dataService.CookMealProgress.CoinProgress += addCount;
            }
            else
            {
                if (dataService.CookMealProgress.MaterialProgress.TryGetValue(matType, out int count))
                {
                    dataService.CookMealProgress.MaterialProgress[matType] = count + addCount;
                }
                else
                {
                    dataService.CookMealProgress.MaterialProgress[matType] = addCount;
                }
            }
        }
        else
        {
            foreach (var matType in matList)
            {
                int addCount = 1;
                CheckCurMaterialFull(matType, ref addCount);
                if ((MealMaterialType) matType == MealMaterialType.Coin)
                {
                    //加金币
                }
                else if ((MealMaterialType) matType == MealMaterialType.Pine)
                {
                    //加积攒金币
                    dataService.CookMealProgress.CoinProgress += addCount;
                }
                else
                {
                    if (dataService.CookMealProgress.MaterialProgress.TryGetValue(matType, out int count))
                    {
                        dataService.CookMealProgress.MaterialProgress[matType] = count + addCount;
                    }
                    else
                    {
                        dataService.CookMealProgress.MaterialProgress[matType] = addCount;
                    }
                }
            }
        }

        ActivityManager.Instance.SaveActivityData();
    }

    private bool CheckAllMaterialFull(CookMealModel model)
    {
        bool canJump = true;
        foreach (var pair in model.SuitInfo)
        {
            bool isFull = CheckCurMaterialFull(pair.Key);
            if (!isFull)
            {
                canJump = false;
                break;
            }
        }

        if (CheckCurMaterialFull((int) MealMaterialType.Pine))
        {
            //加积攒金币
            TypeEventSystem.Send<CookGetProgressCoin>();
            dataService.AddCoin(model.CoinProgressNum, PropChangeWay.CookMealProgressCoin, Vector3.zero, false);
            dataService.CookMealProgress.CoinProgress = 0;
            ActivityManager.Instance.SaveActivityData();
        }

        return canJump;
    }

    private bool CheckCurMaterialFull(int matType)
    {
        CookMealModel model = GetCurLayerMealSuit();
        dataService.CookMealProgress.MaterialProgress.TryGetValue(matType, out int count);
        int max = 0;

        if ((MealMaterialType) matType == MealMaterialType.Coin)
        {
            max = 0;
        }
        else if ((MealMaterialType) matType == MealMaterialType.Pine)
        {
            count = dataService.CookMealProgress.CoinProgress;
            max = model.CoinProgress;
        }
        else
        {
            model.SuitInfo.TryGetValue(matType, out List<int> list);
            max = list[0];
        }

        return count >= max;
    }

    private bool CheckCurMaterialFull(int matType, ref int addCount)
    {
        bool isFull = CheckCurMaterialFull(matType);
        if (isFull) addCount = 0;
        return isFull;
    }

    public void CheckTriggerPopup()
    {
        if (!IsOpenActivity()) return;
        if (dataService.CookMealProgress.PopBtn)
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.CollectMusicPopup,
                BoxBuilder.ShowCollectMusicPopup);
            dataService.CookMealProgress.PopBtn = false;
        }
    }

    public bool CheckIsMaxLayer()
    {
        int maxLayer = configService.CookMealConfig.Count;
        return dataService.CookMealProgress.curLayer > maxLayer;
    }

    //掷骰子得到的最终食材
    public List<int> GetFinalMaterial()
    {
        CookMealModel model = GetCurLayerMealSuit();
        model.SuitInfo.Add((int) MealMaterialType.Coin, new List<int>() {0, model.Weight2});
        model.SuitInfo.Add((int) MealMaterialType.Pine, new List<int>() {model.CoinProgress, model.Weight3});

        int total = 0;
        foreach (var pair in model.SuitInfo)
        {
            total += pair.Value[1];
        }

        List<int> list = new List<int>();
        for (int i = 0; i < 3; i++)
        {
            int randomValue = GameUtils.RandomRange(0, total);
            int finalMat = 0;
            int tempValue = 0;
            foreach (var pair in model.SuitInfo)
            {
                finalMat = pair.Key;
                tempValue += pair.Value[1];
                if (tempValue > randomValue) break;
            }

            list.Add(finalMat);
        }
        // list.Clear();
        // list.Add((int)MealMaterialType.Coin);
        // list.Add((int)MealMaterialType.Coin);
        // list.Add((int)MealMaterialType.Coin);
        SaveMaterialProgress(list);
        return list;
    }

    //获取当前层菜品套装
    public CookMealModel GetCurLayerMealSuit()
    {
        configService.CookMealConfig.TryGetValue(dataService.CookMealProgress.curLayer, out CookMealModel model);
        return (CookMealModel) model?.Clone();
    }

    #region 活动结束，发放游戏奖励

    public void CheckGetReward()
    {
    }

    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.cookMeal);
    }

    #endregion
}