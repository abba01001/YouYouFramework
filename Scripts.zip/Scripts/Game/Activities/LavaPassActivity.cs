﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using Model;
using UnityEngine;
using SoliUtils;

public interface ILavaPassActivity
{
    void CheckOpenActivity(bool isWin);
    void CheckRefreshRobot(bool isWin);
    void OperateMyWinCount(bool isWin);
    bool CheckGetReward(Action successAction, Action failAction);
    void CheckTriggerPopup();
    void CheckFinishActivity();
    void GMAddWinCount(int count);
    void ResetActivity();
    bool CheckShowLavaPopup(Action cb);
    void EnableActivity();
    bool IsOpenActivity();
    int GetActivityRewardCoin();
}

//熔岩连胜活动
public class LavaPassActivity : ILavaPassActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public LavaPassActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.LavaPassGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.LavaPassGuide);
        if (dataService.LavaPassProgress.IsFirstShow)
            list.Add(rootNode);
        if (dataService.LavaPassProgress.ActivityEndTime != 0 && ActivityManager.Instance.GetActivitySeverTime() >
            dataService.LavaPassProgress.ActivityEndTime - 300)
            list.Add(rootNode);
        return list;
    }

    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state ==
               ActivityState.underWay;
    }

    public bool CheckShowLavaPopup(Action cb)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state == ActivityState.underWay)
        {
            BoxBuilder.ShowLavaPassPopup(cb);
            return true;
        }

        return false;
    }

    public void GMAddWinCount(int count)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state != ActivityState.underWay) return;
        for (int i = 0; i < count; i++)
        {
            CheckOpenActivity(true);
        }
    }

    public void CheckOpenActivity(bool isWin)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state != ActivityState.underWay) return;
        OperateMyWinCount(isWin);
        CheckRefreshRobot(isWin);
        if (!isWin)
        {
            dataService.LavaPassProgress.ActivityEndTime = ActivityManager.Instance.GetActivitySeverTime() - 1;
            dataService.LavaPassProgress.isFailState = 1;
        }
    }

    public void CheckRefreshRobot(bool isWin)
    {
        if (!isWin) return;
        int finalFloor = configService.LavaPassConfig[configService.LavaPassConfig.Count].reduceFloor;
        int finalCeil = configService.LavaPassConfig[configService.LavaPassConfig.Count].reduceCeil;

        int curWinCount = dataService.LavaPassProgress.winCount;
        if (curWinCount >= configService.LavaPassConfig.Count)
        {
            if (dataService.LavaPassProgress.robotCount < finalFloor &&
                dataService.LavaPassProgress.robotCount > finalCeil)
            {
                dataService.LavaPassProgress.robotCount = GameUtils.RandomRange(finalFloor, finalCeil + 1);
                dataService.LavaPassProgress.totalCount = dataService.LavaPassProgress.robotCount + 1;
            }

            return;
        }

        if (finalFloor <= dataService.LavaPassProgress.robotCount &&
            dataService.LavaPassProgress.robotCount < finalCeil) return;


        var model = configService.LavaPassConfig[Mathf.Clamp(curWinCount, 1, configService.LavaPassConfig.Count - 1)];
        int reduceFloor = model.reduceFloor;
        int reduceCeil = model.reduceCeil;
        int reduceNum = GameUtils.RandomRange(reduceFloor, reduceCeil + 1);


        int tempRobotCount = dataService.LavaPassProgress.robotCount - reduceNum;
        if (tempRobotCount < finalFloor)
        {
            tempRobotCount = GameUtils.RandomRange(finalFloor, finalCeil + 1);
        }

        dataService.LavaPassProgress.robotCount = tempRobotCount;
        dataService.LavaPassProgress.totalCount = dataService.LavaPassProgress.robotCount + 1;
    }

    public int GetActivityRewardCoin()
    {
        int coin = 0;
        Dictionary<int, int> reward = configService.GetLavaReward();
        if (reward.ContainsKey((int) PropEnum.Coin))
        {
            coin = reward[(int) PropEnum.Coin];
        }

        return coin;
    }

    public void OperateMyWinCount(bool isWin)
    {
        if (isWin) dataService.LavaPassProgress.winCount++;
    }

    public bool CheckGetReward(Action successAction, Action failAction)
    {
        if (dataService.LavaPassProgress.isFailState == 1)
        {
            ActivityManager.Instance.UpdateCurActivity(ActivityType.lavaPass, true);
            CheckTriggerPopup();
            failAction?.Invoke();
            return false;
        }

        int curWinCount = dataService.LavaPassProgress.winCount;
        if (curWinCount < configService.LavaPassConfig.Count ||
            ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state == ActivityState.finished)
        {
            // dataService.LavaPassProgress.RewardFlag = 0;
            // ActivityManager.Instance.FinishGetReward(ActivityType.lavaPass);
            return false;
        }

        dataService.LavaPassProgress.RewardFlag = 1;
        ActivityManager.Instance.FinishGetReward(ActivityType.lavaPass, true);

        Dictionary<int, int> reward = configService.GetLavaReward();
        if (reward.ContainsKey((int) PropEnum.Coin))
        {
            reward[(int) PropEnum.Coin] /= (dataService.LavaPassProgress.robotCount + 1);
        }

        ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.LavaPassRewardPopup,
            () => BoxBuilder.ShowLavaPassRewardPopup(reward, PropChangeWay.LavaPassReward,
                () => { successAction?.Invoke(); }), true);
        return true;
    }

    public void CheckFinishActivity()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state == ActivityState.waitFinished)
        {
            ActivityManager.Instance.FinishGetReward(ActivityType.lavaPass, false);
        }
    }

    public void CheckTriggerPopup()
    {
        if (dataService.LavaPassProgress.PopBtn &&
            ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state == ActivityState.waitEntry)
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartLavaPass,
                () => { BoxBuilder.ShowStartLavaPassPopup(0); });
            dataService.LavaPassProgress.PopBtn = false;
        }

        if (ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state == ActivityState.waitFinished)
        {
            if (!dataService.LavaPassProgress.IsCheckingFinish)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartLavaPass, () =>
                {
                    CheckFinishActivity();
                    dataService.LavaPassProgress.IsCheckingFinish = true;
                    BoxBuilder.ShowStartLavaPassPopup(2);
                });
            }
        }
    }

    public void EnableActivity()
    {
        dataService.LavaPassProgress.UserActivative = true;
    }

    public void ResetActivity()
    {
        dataService.LavaPassProgress.ActivityBeginTime = 0;
        dataService.LavaPassProgress.winCount = 0;
        dataService.LavaPassProgress.lastWinCount = 0;
        dataService.LavaPassProgress.robotCount = 99;
        dataService.LavaPassProgress.lastRobotCount = 99;
        dataService.LavaPassProgress.totalCount = 100;
    }
}