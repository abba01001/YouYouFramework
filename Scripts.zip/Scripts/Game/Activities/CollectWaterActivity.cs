﻿using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface ICollectWaterActivity
{
    void CheckOpenActivity();
    bool IsOpenActivity();
    void CheckTriggerPopup();
    void GMAddCount(int input);
    int GetTotalProgress();
    int GetCurMaxProgress();
    int GetCurProgress();
    float GetCurLayerRatio();
    Dictionary<int, int> GetBottleReward(int layer);
    RainbowDropsModel GetLayerModel(int layer);
    void CheckGetReward();
    void CheckFinishActivity();
    void AddMyWaterCount(int count);
    bool IsMaxLevel();
}

public class CollectWaterActivity: ICollectWaterActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();
    
    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.collectWater);
    }

    public bool IsMaxLevel()
    {
        return dataService.CollectWaterProgress.curLayer >= configService.RainbowDropsConfig.Count;
    }

    public void AddMyWaterCount(int count)
    {
        if (!IsOpenActivity()) return;
        dataService.CollectWaterProgress.progress += count;
        Observable.Timer(TimeSpan.FromSeconds(0.1f)).Subscribe(_ =>
        {
            StaticCoroutine.StartCoroutine(CheckReward());
        });
    }
    
    public Dictionary<int, int> GetBottleReward(int layer)
    {
        configService.RainbowDropsConfig.TryGetValue(layer, out RainbowDropsModel model);
        return GameUtils.AnalysisPropString(model.reward);
    }
    public int GetTotalProgress()
    {
        return configService.RainbowDropsConfig[configService.RainbowDropsConfig.Count].progress;
    }

    public int GetCurMaxProgress()
    {
        int curLayer = dataService.CollectWaterProgress.curLayer + 1;
        if (curLayer == 1)
        {
            configService.RainbowDropsConfig.TryGetValue(1, out RainbowDropsModel model);
            return model.progress;
        }
        else
        {
            configService.RainbowDropsConfig.TryGetValue(curLayer - 1, out RainbowDropsModel model1);
            configService.RainbowDropsConfig.TryGetValue(curLayer, out RainbowDropsModel model2);
            return model2.progress - model1.progress;
        }
    }
    
    public int GetCurProgress()
    {
        int curLayer = dataService.CollectWaterProgress.curLayer + 1;
        if (curLayer == 1)
        {
            return dataService.CollectWaterProgress.progress;
        }
        else
        {
            configService.RainbowDropsConfig.TryGetValue(curLayer - 1, out RainbowDropsModel model);
            return dataService.CollectWaterProgress.progress - model.progress;
        }
    }

    public float GetCurLayerRatio()
    {
        return (float) GetCurProgress() / GetCurMaxProgress();
    }

    public RainbowDropsModel GetLayerModel(int layer)
    {
        configService.RainbowDropsConfig.TryGetValue(layer, out RainbowDropsModel model);
        return model;
    }
    
    public void GMAddCount(int input)
    {
        if (!IsOpenActivity()) return;
        dataService.CollectWaterProgress.progress += input;
        Observable.Timer(TimeSpan.FromSeconds(0.1f)).Subscribe(_ =>
        {
            StaticCoroutine.StartCoroutine(CheckReward());
        });
    }

    public void CheckGetReward()
    {
        int layer = 0;
        int progress = dataService.CollectWaterProgress.progress;
        foreach (var model in configService.RainbowDropsConfig)
        {
            if(model.Value.progress > progress) break;
            layer++;
        }

        if (dataService.CollectWaterProgress.curLayer != layer)
        {
            string rewardStr = "";
            for (int i = dataService.CollectWaterProgress.curLayer + 1; i <= layer; i++)
            {
                if (rewardStr != "") rewardStr += $";{GetLayerModel(i).reward}";
                else rewardStr = GetLayerModel(i).reward;
            }
            dataService.CollectWaterProgress.curLayer = layer;
            Dictionary<int, int> rewards = GameUtils.AnalysisPropString(rewardStr);
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.PopCollectRewardPopup, () =>
            {
                BoxBuilder.ShowPopCollectRewardPopup(ActivityType.collectWater, rewards, null, null);
            });
            dataService.SaveRewardData(rewards,PropChangeWay.CollectWaterReward);
        }
    }
    
    
    private IEnumerator CheckReward()
    {
        yield return new WaitUntil(() => GameCommon.VisiblePopupCount == 0);
        CheckGetReward();
    }

    public void CheckOpenActivity()
    {
        if (!IsOpenActivity()) return;
        // dataService.RabitGiftProgress.curWinCount = 0;
    }
    
    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.collectWater) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.collectWater).state ==
               ActivityState.underWay;
    }

    public void CheckTriggerPopup()
    {
        if (dataService.CollectWaterProgress.PopBtn && IsOpenActivity())
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.CollectWaterPopup, () =>
            {
                BoxBuilder.ShowCollectWaterPopup();
                dataService.CollectWaterProgress.PopBtn = false;
            });
        }
        
        if (IsOpenActivity() && ActivityManager.Instance.CollectWaterActivity.IsMaxLevel())
        {
            dataService.CollectWaterProgress.FinishGetReward = true;
        }
    }
    
}