﻿using QFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using Activities;
using Model;
using UnityEngine;
using SoliUtils;
using UniRx;

public interface IEndlessLevelActivity
{
    void CheckFinishActivity();
    void GMAddCount(int input);
    void CheckTriggerPopup();
    void CheckOpenActivity();
    EndlessLevelData GetMyData();
    int GetActivityEndTime();
    List<EndlessLevelData> GetRankData();
    void ResetLastRank();
    void EnableActivity();
    void LevelUp();
    void HandleRankInfo(string json);
    EndlessLevelRewardModel GetRankReward(int rank);
    void CheckGetReward();
    bool CanGetReward();
    int GetAddCount();
    List<EndlessLevelData> GetRobotData();
    int GetMyIntegral();
    bool IsOpenActivity();
    void InitData();
    int GetPoint();
}

//无尽关卡活动
public class EndlessLevelActivity : IEndlessLevelActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();
    private List<EndlessLevelRewardModel> rewardList = new List<EndlessLevelRewardModel>();
    public List<EndlessLevelData> RobotData = new List<EndlessLevelData>();

    public void InitData()
    {
        //dataService.EndlessLevelProgress.ResultAddCount = 1 * dataService.GetCollectBet() * dataService.NowBet;
    }

    public int GetPoint()
    {
        return 1 * dataService.GetCollectBet() * dataService.NowBet;
    }
    
    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state ==
               ActivityState.underWay;
    }
    
    public bool CanGetReward()
    {
        if (GetRankReward(GetMyData().curRank + 1) != null) return true;
        return false;
    }
    public void CheckGetReward()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.waitFinished)
        {
            EndlessLevelRewardModel model = GetRankReward(GetMyData().curRank + 1);
            if (model != null)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.RewardPopup, () =>
                {
                    BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(model.Reward),PropChangeWay.EndlessLevelReward, activityType: ActivityType.endlessLevel,startCall:
                        () =>
                        {
                            ActivityManager.Instance.FinishGetReward(ActivityType.endlessLevel);
                        });
                    TypeEventSystem.Send<RefreshEndlessLevel>();
                }, true,1);
                Observable.TimerFrame(6).Subscribe(_ =>
                {
                    BoxBuilder.HideEndlessLevelRankPopup();
                });
            }
        }
    }
    
    public void GMAddCount(int input)
    {
        GetMyData().integration += input;
        dataService.EndlessLevelProgress.ResultAddCount += input;
    }
    
    public void CheckFinishActivity()
    {
        PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.EndlessLevelRankPopup,() =>
        {
            BoxBuilder.ShowEndlessLevelRankPopup();
        });
    }

    //开启活动
    public void EnableActivity()
    {
        dataService.EndlessLevelProgress.UserActivative = true;
        ActivityManager.Instance.UpdateCurActivity(ActivityType.endlessLevel,true);
        TypeEventSystem.Send<RefreshEndlessLevel>();
        dataService.SaveData(true);
    }

    public List<EndlessLevelData> GetRankData()
    {
        return dataService.EndlessLevelProgress.GetRankData();
    }

    public List<EndlessLevelData> GetRobotData()
    {
        return RobotData;
    }

    public EndlessLevelData GetMyData()
    {
        return dataService.EndlessLevelProgress.GetMyData();
    }
    
    public int GetActivityEndTime()
    {
        return dataService.EndlessLevelProgress.ActivityEndTime;
    }

    public void ResetLastRank()
    {
        dataService.EndlessLevelProgress.GetMyData().lastRank = dataService.EndlessLevelProgress.GetMyData().curRank;
    }

    public int GetMyIntegral()
    {
        int integral = 0;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel) != null &&
            ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
        {
            integral = GetMyData().integration;
        }
        return integral;
    }
    
    public void CheckTriggerPopup()
    {
        if (dataService.EndlessLevelProgress.PopBtn && ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.waitEntry || dataService.EndlessLevelProgress.FinishPopView)
        {
            if (dataService.EndlessLevelProgress.FinishPopView)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.EndlessLevelRankPopup,() =>
                {
                    dataService.EndlessLevelProgress.FinishPopView = false;
                    BoxBuilder.ShowEndlessLevelRankPopup();
                });
            }
            else
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartEndlessLevelPopup,BoxBuilder.ShowStartEndlessLevelPopup);
                dataService.EndlessLevelProgress.PopBtn = false;
            }
        }
    }

    public void CheckOpenActivity()
    {
        
    }

    public int GetAddCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state != ActivityState.underWay)
        {
            dataService.EndlessLevelProgress.ResultAddCount = 0;
            return 0;
        }
        return dataService.EndlessLevelProgress.ResultAddCount;
    }
    
    public void LevelUp()
    {
        Dictionary<int, StageModel> tempStageConfig = new Dictionary<int, StageModel>();
        if (dataService.EndlessLevelProgress.SubActivityType == 1)
        {
            tempStageConfig = configService.EndlessStageOneConfig;
        }
        else
        {
            tempStageConfig = configService.EndlessStageTwoConfig;
        }

        int newLevel = dataService.EndlessLevelProgress.MyData.level + 1;
        if (newLevel > tempStageConfig.Last().Value.id) newLevel = 1;
        GetMyData().integration += 1 * dataService.GetCollectBet() * dataService.NowBet;
        dataService.EndlessLevelProgress.ResultAddCount = 1 * dataService.GetCollectBet() * dataService.NowBet;
        GetMyData().level = newLevel;
        dataService.EndlessLevelProgress.ViewMaxLayer++;
    }

    public EndlessLevelRewardModel GetRankReward(int rank)
    {
        if (rewardList.Count == 0)
        {
            DateTime startTime = TimeUtils.IntToDateTime(dataService.EndlessLevelProgress.ActivityBeginTime);
            DateTime endTime = TimeUtils.IntToDateTime(dataService.EndlessLevelProgress.ActivityEndTime);

            DateTime time1 = new DateTime(startTime.Year, startTime.Month, startTime.Day, 0, 0, 0, DateTimeKind.Local);
            DateTime time2 = new DateTime(endTime.Year, endTime.Month, endTime.Day, 23, 59, 59, DateTimeKind.Local);
            int interval = (time2 - time1).Days;

            foreach (var info in configService.EndlessLevelRewardConfig)
            {
                string[] str = info.Value.enterTime.Split(GameUtils.FirstSeparator);
                int start = int.Parse(str[0]);
                int end = int.Parse(str[1]);
                if (start <= interval && interval <= end)
                {
                    rewardList.Add(info.Value);
                }
            }
            rewardList.Sort((a, b) => b.Rank.CompareTo(a.Rank));
        }
        EndlessLevelRewardModel model = rewardList.Find(t => t.Rank == rank);
        return model;
    }

    public void HandleRankInfo(string json)
    {
        var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
        if (dic.TryGetValue("leaderboard", out var list) && list != null)//获取列表
        {
            List<EndlessLevelData> tempList = new List<EndlessLevelData>();
            List<object> info = list as List<object>;
            foreach (var pair in info)
            {
                EndlessLevelData model = new EndlessLevelData();
                Dictionary<string, object> data = pair as Dictionary<string, object>;
                if(data.TryGetValue("user_id",out object userId) && userId != null && Convert.ToString(userId) == dataService.UserId) continue;
                
                
                if(data.TryGetValue("avatar",out object value1)) model.avatar = Convert.ToString(value1);
                if(data.TryGetValue("endless_score",out object value2)) model.integration = Convert.ToInt32(value2);
                if(data.TryGetValue("name",out object value3)) model.name = Convert.ToString(value3);
                
                tempList.Add(model);
            }
            tempList.Sort((a, b) => b.integration.CompareTo(a.integration));

            RobotData.Clear();
            foreach (var data in tempList)
            {
                
                EndlessLevelData endLessLevelData = new EndlessLevelData();
                endLessLevelData.avatar = data.avatar;
                endLessLevelData.integration = data.integration;
                endLessLevelData.name = data.name;
                RobotData.Add(endLessLevelData);
            }
            TypeEventSystem.Send<UpdateEndlessRankInfoEvent>();
        }
    }
}