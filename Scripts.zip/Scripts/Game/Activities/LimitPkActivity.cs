﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using UnityEngine;
using SoliUtils;

public interface ILimitPkActivity
{
    void OperateRobotWinCount();
    void CheckGetReward(Action cb);
    void Update();
    void CheckRefreshRobot();
    void CheckActivityCard(CardData cardData, Action action = null);
    void ClearActivityCard(CardData cardData, Action action = null);
    void GMAddCount(int count);
    int GetAddCount();
    void SetMatchFlag(bool flag);
    void RecordLastIntegral();
    int GetPoint();
    void CheckOpenActivity();
    void InitData();
    void CheckTriggerPopup();
}

//拳击赛
public class LimitPkActivity : ILimitPkActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public LimitPkActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.LimitPkGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.LimitPkGuide);
        if (dataService.LimitPkData.IsFirstShow) list.Add(rootNode);
        if (dataService.LimitPkData.ActivityEndTime != 0 && ActivityManager.Instance.GetActivitySeverTime() >
            dataService.LimitPkData.ActivityEndTime - 300) list.Add(rootNode);
        return list;
    }

    //机器人刷新时间节点
    private DateTime _curTimeNode = DateTime.MinValue;

    private DateTime CurTimeNode
    {
        get => _curTimeNode;
        set
        {
            bool finish = true;
            int node = 0;
            dataService.LimitPkData.CurNodeId = 0;
            DateTime startTime = TimeUtils.IntToDateTime(dataService.LimitPkData.ActivityBeginTime);
            foreach (var model in configService.LimitPkConfig)
            {
                node += model.Value.node;
                if (ActivityManager.Instance.GetActivityNowDateTime() <= startTime.AddMinutes(node))
                {
                    _curTimeNode = startTime.AddMinutes(node);
                    finish = false;
                    break;
                }

                dataService.LimitPkData.CurNodeId++;
            }

            if (finish) _curTimeNode = DateTime.MaxValue;
            OperateRobotWinCount();
        }
    }

    public void InitData()
    {
        if (dataService.LimitPkData.cardList != null)
        {
            dataService.LimitPkData.cardList.Clear();
        }
    }

    //设置机器人积分数
    public void OperateRobotWinCount()
    {
        if (dataService.LimitPkData.CurNodeId == 0) return;
        configService.LimitPkConfig.TryGetValue(dataService.LimitPkData.CurNodeId, out LimitPkModel model);
        if (model != null)
        {
            int random = 0;
            if (dataService.LimitPkData.MyIntegral == 0)
            {
                int[] Range1 = model.Range1();
                random = GameUtils.RandomRange(Range1[0], Range1[1]);
            }
            else
            {
                int[] Range = model.Range();
                int[] Range1 = model.Range1();
                int temp = GameUtils.RandomRange(Range[0], Range[1]);
                int temp1 = GameUtils.RandomRange(Range1[0], Range1[1]);
                random = Mathf.Max(temp, temp1);
            }

            float beishu = (1 + (float) random / 10000);
            if (beishu >= 1)
            {
                dataService.LimitPkData.RobotIntegral = Mathf.RoundToInt(dataService.LimitPkData.MyIntegral * beishu);
            }
        }

        ActivityManager.Instance.SaveActivityData();
        TypeEventSystem.Send<RefreshActivityRank>();
    }

    public void CheckGetReward(Action cb)
    {
        if (!dataService.LimitPkData.IsWin())
        {
            cb?.Invoke();
            ActivityManager.Instance.FinishGetReward(ActivityType.limitPk);
            return;
        }

        Dictionary<int, int> rewardDic = new Dictionary<int, int>();
        foreach (var pair in configService.LimitPkConfig)
        {
            if (pair.Value.reward != null)
            {
                rewardDic = GameUtils.AnalysisPropString(pair.Value.reward);
                break;
            }
        }

        dataService.LimitPkData.RewardFlag = 1;
        ActivityManager.Instance.FinishGetReward(ActivityType.limitPk);

        PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.RewardPopup,
            () =>
            {
                BoxBuilder.ShowRewardPop(rewardDic, PropChangeWay.LimitPkReward, null,
                    activityType: ActivityType.limitPk);
            }, true, 1);
        cb?.Invoke();
    }

    public void Update()
    {
        if (dataService.LimitPkData is {ActivityBeginTime: > 0})
        {
            CheckRefreshRobot();
        }
    }

    public void CheckRefreshRobot()
    {
        if (CurTimeNode == DateTime.MaxValue)
        {
            return;
        }

        if (CurTimeNode == DateTime.MinValue)
        {
            CurTimeNode = ActivityManager.Instance.GetActivityNowDateTime();
        }

        if (ActivityManager.Instance.GetActivityNowDateTime() >= CurTimeNode)
        {
            CurTimeNode = ActivityManager.Instance.GetActivityNowDateTime();
        }
    }

    //计算积分
    public void CheckActivityCard(CardData cardData, Action action = null)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).state != ActivityState.underWay) return;
        if (cardData.CardType == CardType.Value ||
            cardData.CardType == CardType.TwoValue ||
            cardData.CardType == CardType.Gold ||
            cardData.CardType == CardType.Monochrome)
        {
            if (CardIsAdd(cardData)) return;
            dataService.LimitPkData.ResultAddCount += GetPoint();
            dataService.LimitPkData.cardList.Add(cardData.id);
            action?.Invoke();
        }
    }

    public void ClearActivityCard(CardData cardData, Action action = null)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).state != ActivityState.underWay) return;
        if (cardData.cm.cardType != CardType.Value) return;
        if (CardIsAdd(cardData))
        {
            dataService.LimitPkData.ResultAddCount -= GetPoint();
            dataService.LimitPkData.cardList.Remove(cardData.id);
            action?.Invoke();
        }
    }

    //处理一下卡牌，避免撤回重复添加
    private bool CardIsAdd(CardData cardData)
    {
        if (dataService.LimitPkData.cardList.Contains(cardData.id)) return true;
        return false;
    }

    public int GetPoint()
    {
        return 1 * dataService.NowBet * dataService.GetCollectBet();
    }

    public int GetAddCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).state != ActivityState.underWay)
        {
            dataService.LimitPkData.ResultAddCount = 0;
            return 0;
        }

        return dataService.LimitPkData.ResultAddCount;
    }

    public void SetMatchFlag(bool flag)
    {
        dataService.LimitPkData.MatchFlag = flag;
        ActivityManager.Instance.SaveActivityData();
    }

    public void RecordLastIntegral()
    {
        dataService.LimitPkData.LastMyIntegral = dataService.LimitPkData.MyIntegral;
        dataService.LimitPkData.LastRobotIntegral = dataService.LimitPkData.RobotIntegral;
    }

    public void GMAddCount(int _count)
    {
        OperateMyIntegral(_count);
    }

    private void OperateMyIntegral(int addCount = 0)
    {
        if (addCount == 0) return;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).state != ActivityState.underWay) return;

        var msg = new Dictionary<string, object>
        {
            {"score_before", dataService.LimitPkData.MyIntegral},
            {"score_add", addCount},
            {"start_time", dataService.LimitPkData.ActivityBeginTime},
        };
        AnalyticUtils.ReportEvent(AnalyticsKey.LimitPk_Score, msg);
        dataService.LimitPkData.MyIntegral += addCount;
        dataService.LimitPkData.cardList.Clear();
    }

    public void CheckOpenActivity()
    {
        OperateMyIntegral(dataService.LimitPkData.ResultAddCount);
    }

    public void CheckTriggerPopup()
    {
        if (dataService.LimitPkData.PopBtn && ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).state ==
            ActivityState.waitEntry || dataService.LimitPkData.FinishPopView)
        {
            if (dataService.LimitPkData.FinishPopView)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartLimitPkPopup, () =>
                {
                    dataService.LimitPkData.FinishPopView = false;
                    BoxBuilder.ShowStartLimitPkPopup("result");
                });
            }
            else
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartLimitPkPopup,
                    () => BoxBuilder.ShowStartLimitPkPopup(dataService.LimitPkData.MatchFlag ? "match" : "start"));
                dataService.LimitPkData.PopBtn = false;
            }
        }
    }
}