﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface IDigTreasureActivity
{
    void CheckOpenActivity(bool isWin);
    int GetAddCount();
    void CheckGetReward();
    void GMAddCount(int count);
    void CheckFinishActivity();
    void InitData();
    void CheckTriggerPopup();
    bool IsOpenActivity();
    Dictionary<int, Vector2> LoadRewardGrid();
    void SaveRewardGrid(Dictionary<int, Vector2> dic);
    List<int> LoadOccupyGrid();
    void OccupyGridByIndex(int index, Action successCb, Action failCb);
    void CheckReward(Dictionary<int, List<int>> dic);
    int GetDigCount();
    (int, int, int) GetRowCollumn();
    void CheckJumpNextLayer(Dictionary<int, List<int>> dic);
    bool CheckMaxLayer();
    Dictionary<int, int> GetCurRewards();
    void AddMyDigCount(int count);
    int GetPoint();
}

public class DigTreasureActivity : IDigTreasureActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public DigTreasureActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.DigGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.DigGuide);
        if (dataService.DigTreasureProgress.IsFirstShow)
            list.Add(rootNode);
        if (dataService.DigTreasureProgress.ActivityEndTime != 0 && ActivityManager.Instance.GetActivitySeverTime() >
            dataService.DigTreasureProgress.ActivityEndTime - 300)
            list.Add(rootNode);
        return list;
    }

    public void GMAddCount(int count)
    {
        dataService.DigTreasureProgress.ResultAddCount = count;
        dataService.DigTreasureProgress.digCount += dataService.DigTreasureProgress.ResultAddCount;
    }

    public void InitData()
    {
    }

    //设置玩家收集的方块爱心卡牌数
    private void OperateMyDigCount(bool isWin)
    {
        if(isWin) dataService.DigTreasureProgress.digCount += dataService.DigTreasureProgress.ResultAddCount;
    }

    public int GetPoint()
    {
        return 1;
    }
    
    public void AddMyDigCount(int count)
    {
        if (!IsOpenActivity()) return;
        dataService.DigTreasureProgress.digCount += count; //dataService.DigTreasureProgress.ResultAddCount;
    }

    public void CheckOpenActivity(bool isWin)
    {
        if (!IsOpenActivity()) return;
        OperateMyDigCount(isWin);
        //TypeEventSystem.Send<UpdateCollectLoveCardViewEvent>();
    }

    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.digTreasure) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.digTreasure).state ==
               ActivityState.underWay;
    }


    public int GetAddCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.digTreasure).state != ActivityState.underWay)
        {
            dataService.DigTreasureProgress.ResultAddCount = 0;
            return 0;
        }

        return dataService.DigTreasureProgress.ResultAddCount;
    }

    //dic每个奖励占领的所有格子索引
    public void CheckReward(Dictionary<int, List<int>> dic)
    {
        foreach (var info in dic)
        {
            int rewardState = 0; //0不能领取    1可以领取    2已领取
            if (dataService.DigTreasureProgress.GetRewardList.Contains(info.Key))
            {
                rewardState = 2;
                continue;
            }
            else
            {
                foreach (var posIndex in info.Value)
                {
                    rewardState = dataService.DigTreasureProgress.OccupyGridList.Contains(posIndex) ? 1 : 0;
                    if (rewardState == 0) break;
                }

                if (rewardState == 1)
                {
                    dataService.DigTreasureProgress.GetRewardList.Add(info.Key);
                    TypeEventSystem.Send<PlayGetTreasure>(new PlayGetTreasure(info.Key, 1f));
                    ActivityManager.Instance.SaveActivityData();
                    break;
                }
            }
        }
    }

    public Dictionary<int, int> GetCurRewards()
    {
        Dictionary<int, int> rewards = new Dictionary<int, int>();
        foreach (var pair in configService.DigTreasureRewardConfig)
        {
            if (pair.Value.mapId == dataService.DigTreasureProgress.curMap &&
                pair.Value.layer == dataService.DigTreasureProgress.curLayer)
            {
                rewards = GameUtils.AnalysisPropString(pair.Value.reward);
                break;
            }
        }

        return rewards;
    }

    //检测跳转到下一层
    public void CheckJumpNextLayer(Dictionary<int, List<int>> dic)
    {
        bool canJump = true;
        foreach (var info in dic)
        {
            if (!dataService.DigTreasureProgress.GetRewardList.Contains(info.Key))
            {
                canJump = false;
                break;
            }
        }

        if (canJump)
        {
            if (!CheckMaxLayer())
            {
                Dictionary<int, int> reward = new Dictionary<int, int>();
                foreach (var pair in GetCurRewards())
                {
                    reward.Add(pair.Key, pair.Value);
                }

                JumpNextLayer();

                dataService.SaveRewardData(reward, PropChangeWay.DigTreasureReward);
                dataService.RecordBubbleItem = null;
                TypeEventSystem.Send<JumpNextTreasure>(new JumpNextTreasure(0.5f));
            }
        }
    }

    private void JumpNextLayer()
    {
        dataService.DigTreasureProgress.curLayer++;
        dataService.DigTreasureProgress.OccupyGridList.Clear();
        dataService.DigTreasureProgress.GetRewardList.Clear();
        dataService.DigTreasureProgress.RewardGridDic.Clear();
    }

    public bool CheckMaxLayer()
    {
        return dataService.DigTreasureProgress.curLayer > 5;
    }

    public List<int> LoadOccupyGrid()
    {
        return dataService.DigTreasureProgress.OccupyGridList;
    }

    public int GetDigCount()
    {
        return dataService.DigTreasureProgress.digCount;
    }

    public void OccupyGridByIndex(int index, Action successCb, Action failCb)
    {
        List<int> occupyList = LoadOccupyGrid();
        if (!occupyList.Contains(index) && dataService.DigTreasureProgress.digCount > 0)
        {
            dataService.DigTreasureProgress.OccupyGridList.Add(index);
            dataService.DigTreasureProgress.digCount--;
            dataService.DigTreasureProgress.digCount = Mathf.Max(dataService.DigTreasureProgress.digCount, 0);
            successCb?.Invoke();
            ActivityManager.Instance.SaveActivityData();
        }
        else
        {
            failCb?.Invoke();
        }
    }

    public void SaveRewardGrid(Dictionary<int, Vector2> dic)
    {
        Dictionary<int, PosModel> tempDic = new Dictionary<int, PosModel>();
        foreach (var pair in dic)
        {
            PosModel model = new PosModel((int) pair.Value.x, (int) pair.Value.y);
            tempDic.Add(pair.Key, model);
        }

        dataService.DigTreasureProgress.RewardGridDic = tempDic;
        ActivityManager.Instance.SaveActivityData();
    }

    public Dictionary<int, Vector2> LoadRewardGrid()
    {
        Dictionary<int, Vector2> dic = new Dictionary<int, Vector2>();
        foreach (var pair in dataService.DigTreasureProgress.RewardGridDic)
        {
            dic.Add(pair.Key, new Vector2(pair.Value.X, pair.Value.Y));
        }

        return dic;
    }

    public void CheckTriggerPopup()
    {
        if (!IsOpenActivity()) return;
        if (dataService.CollectMusicProgress.PopBtn)
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.CollectMusicPopup,
                BoxBuilder.ShowCollectMusicPopup);
            dataService.CollectMusicProgress.PopBtn = false;
        }
    }

    public (int, int, int) GetRowCollumn()
    {
        int XWidth = 5;
        int YWidth = 6;
        int CellSize = 80;
        switch (dataService.DigTreasureProgress.curLayer)
        {
            case 1:
                XWidth = 6;
                YWidth = 5;
                CellSize = 80;
                break;
            case 2:
                XWidth = 7;
                YWidth = 6;
                CellSize = 70;
                break;
            case 3:
                XWidth = 8;
                YWidth = 7;
                CellSize = 65;
                break;
            case 4:
                XWidth = 9;
                YWidth = 8;
                CellSize = 65;
                break;
            case 5:
                XWidth = 10;
                YWidth = 9;
                CellSize = 65;
                break;
            default:
                XWidth = 10;
                YWidth = 9;
                CellSize = 65;
                break;
        }

        return (XWidth, YWidth, CellSize);
    }

    #region 活动结束，发放游戏奖励

    public void CheckGetReward()
    {
    }

    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.digTreasure);
    }

    #endregion
}