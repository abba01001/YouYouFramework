﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using Model;
using UnityEngine;
using SoliUtils;

public interface IGradientGiftActivity
{
    void CheckFinishActivity();
    int GetStartIndex();
    void CheckTriggerPopup();
}

//梯度礼包活动
public class GradientGiftActivity : IGradientGiftActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public GradientGiftActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.GradientGiftGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.GradientGiftGuide);
        if (CheckCurGiftCanGet())
            list.Add(rootNode);
        return list;
    }

    public bool CheckCurGiftCanGet()
    {
        if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.gradientGift)) return false;
        int index = GetStartIndex();
        if (configService.GradientConfig.TryGetValue(index, out GradientModel model))
        {
            return model.IsFree == 1;
        }

        return false;
    }

    public void CheckTriggerPopup()
    {
        if (dataService.GradientGiftProgress.PopBtn &&
            ActivityManager.Instance.GetActivityByType(ActivityType.gradientGift).state == ActivityState.underWay)
        {
            if (!GameCommon.IsShieldPurchase)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.GradientGiftPopup,
                    BoxBuilder.ShowGradientGift);
                dataService.GradientGiftProgress.PopBtn = false;
            }
        }
    }

    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.gradientGift,false);
    }

    public int GetStartIndex()
    {
        int startIndex = -1;
        foreach (var pair in configService.GradientConfig)
        {
            if (pair.Key > dataService.GradientGiftProgress.CurRewardIndex)
            {
                startIndex = pair.Key;
                break;
            }
        }

        if (startIndex == -1) startIndex = configService.GradientConfig.Count + 1;
        return startIndex;
    }
}