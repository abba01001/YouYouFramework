﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface ICollectMusicActivity
{
    void CheckOpenActivity(bool isWin);
    int GetNextLayerCollectCount();
    int GetCurLayerCollectCount();
    Dictionary<int,int> GetNextReward();
    Dictionary<int, int> GetCurReward();
    float GetRatio();
    int GetAddCount();
    Dictionary<int, Dictionary<int,int>> GetRewardConfig();
    void CheckGetReward();
    void GMAddCount(int count);
    void CheckFinishActivity();
    int GetPoint();
    void SetCurLayer(int layer);
    bool CurIsMaxLayer();
    void CheckTriggerPopup();
    bool IsOpenActivity();
    bool CheckReadyFull();
}

public class CollectMusicActivity: ICollectMusicActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();
    private Dictionary<int, int> rewardDic = new Dictionary<int, int>();

    public bool CheckReadyFull()
    {
        if (!IsOpenActivity()) return false;
        if(CurIsMaxLayer()) return false;
        int curLayer = dataService.CollectMusicProgress.curLayer;
        int getRewardLayer = dataService.CollectMusicProgress.getRewardLayer;
        int myCollectCount = dataService.CollectMusicProgress.collectCount + dataService.CollectMusicProgress.ResultAddCount;
        int progress = 0;
        bool isMax = false;
        foreach (var VARIABLE in configService.CollectMusicConfig)
        {
            progress = VARIABLE.Value.progress;
            if (progress > myCollectCount)
            {
                curLayer = VARIABLE.Value.layer - 1;
                break;
            }
        }
        int getRewardCount = curLayer - getRewardLayer;
        return getRewardCount > 0;
    }

    
    public void GMAddCount(int count)
    {
        dataService.CollectMusicProgress.ResultAddCount = count;
        dataService.CollectMusicProgress.collectCount += dataService.CollectMusicProgress.ResultAddCount;
        CheckReward();
    }
    
    //设置玩家收集的方块爱心卡牌数
    private void OperateMyCollectCount(bool isWin)
    {
        if (isWin) dataService.CollectMusicProgress.curLevelOpenCount = 1;
        else dataService.CollectMusicProgress.curLevelOpenCount++;
        dataService.CollectMusicProgress.collectCount += dataService.CollectMusicProgress.ResultAddCount;
    }

    public void CheckOpenActivity(bool isWin)
    {
        if (!IsOpenActivity()) return;
        OperateMyCollectCount(isWin);
        CheckReward();
        //TypeEventSystem.Send<UpdateCollectLoveCardViewEvent>();
    }

    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.collectMusic) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.collectMusic).state ==
               ActivityState.underWay;
    }
    
    //获取下一层需要收集的数量
    public int GetNextLayerCollectCount()
    {
        if (CurIsMaxLayer()) return GetMaxLayerCollectCount();
        int lastLayerProgress = 0;
        int layerProgress = 0;
        foreach (var VARIABLE in configService.CollectMusicConfig)
        {
            layerProgress = VARIABLE.Value.progress;
            if (VARIABLE.Value.progress > dataService.CollectMusicProgress.collectCount)
            {
                break;
            }
            lastLayerProgress = VARIABLE.Value.progress;
        }
        return layerProgress - lastLayerProgress;
    }

    private int GetMaxLayerCollectCount()
    {
        int count = 0;
        foreach (var VARIABLE in configService.CollectMusicConfig)
        {
            count = VARIABLE.Value.progress;
        }
        return count;
    }
    
    public int GetCurLayerCollectCount()
    {
        if (CurIsMaxLayer()) return GetMaxLayerCollectCount();
        int progress = 0;
        foreach (var VARIABLE in configService.CollectMusicConfig)
        {
            progress = VARIABLE.Value.progress;
            if (VARIABLE.Value.layer >= dataService.CollectMusicProgress.curLayer)
            {
                break;
            }
        }
        if (dataService.CollectMusicProgress.curLayer == 0) progress = 0;
        return dataService.CollectMusicProgress.collectCount - progress;
    }

    public float GetRatio()
    {
        return (float)GetCurLayerCollectCount() / GetNextLayerCollectCount();
    }
    
    public Dictionary<int,int> GetNextReward()
    {
        int tempLayer = dataService.CollectMusicProgress.curLayer + 1;
        foreach (var VARIABLE in configService.CollectMusicConfig)
        {
            if (tempLayer == VARIABLE.Value.layer)
            {
                return VARIABLE.Value.Reward;
            }
        }
        return new Dictionary<int, int>();
    }
    
    public Dictionary<int,int> GetCurReward()
    {
        int tempLayer = dataService.CollectMusicProgress.curLayer;
        foreach (var VARIABLE in configService.CollectMusicConfig)
        {
            if (tempLayer == VARIABLE.Value.layer)
            {
                return VARIABLE.Value.Reward;
            }
        }
        return new Dictionary<int, int>();
    }

    public int GetAddCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectMusic).state != ActivityState.underWay)
        {
            dataService.CollectMusicProgress.ResultAddCount = 0;
            return 0;
        }
        return dataService.CollectMusicProgress.ResultAddCount;
    }

    public Dictionary<int, Dictionary<int,int>> GetRewardConfig()
    {
        Dictionary<int, Dictionary<int,int>> list = new Dictionary<int, Dictionary<int,int>>();
        foreach (var VARIABLE in configService.CollectMusicConfig)
        {
            list.Add(VARIABLE.Value.layer,VARIABLE.Value.Reward);
        }
        return list;
    }

    public bool CurIsMaxLayer()
    {
        if (dataService.CollectMusicProgress.curLayer >= GetRewardConfig().Count)
        {
            return true;
        }
        return false;
    }
    
    private void CheckReward()
    {
        if(CurIsMaxLayer()) return;
        int curLayer = dataService.CollectMusicProgress.curLayer;
        int getRewardLayer = dataService.CollectMusicProgress.getRewardLayer;
        int myCollectCount = dataService.CollectMusicProgress.collectCount;
        int progress = 0;
        bool isMax = false;
        foreach (var VARIABLE in configService.CollectMusicConfig)
        {
            progress = VARIABLE.Value.progress;
            if (progress > myCollectCount)
            {
                curLayer = VARIABLE.Value.layer - 1;
                break;
            }
            
            if (VARIABLE.Value.layer > getRewardLayer)
            {
                foreach (var item in VARIABLE.Value.Reward)
                {
                    dataService.CollectMusicProgress.readyGetRewardDic[item.Key] =
                        dataService.CollectMusicProgress.readyGetRewardDic.TryGetValue(item.Key,
                            out int existingValue)
                            ? existingValue + item.Value
                            : item.Value;
                }
            }
            if (VARIABLE.Value.layer == GetRewardConfig().Count)
            {
                isMax = true;
            }
        }
        dataService.CollectMusicProgress.getRewardCount = curLayer - getRewardLayer;
        if (isMax) curLayer = GetRewardConfig().Count + 1;
        SetCurLayer(curLayer);
        if (dataService.CollectMusicProgress.getRewardCount > 0)
        {
            var msg = new Dictionary<string, object>
            {
                {"layer", dataService.CollectMusicProgress.curLayer}
            };
            AnalyticUtils.ReportEvent(AnalyticsKey.CollectMusic_Progress, msg);
        }
    }
    
    public void SetCurLayer(int layer)
    {
        dataService.CollectMusicProgress.curLayer = layer;
        dataService.CollectMusicProgress.getRewardLayer = layer;
    }
    
    public int GetPoint()
    {
        if (dataService.CollectMusicProgress.curLevelOpenCount == 1)
        {
            return 10 * dataService.NowBet * dataService.GetCollectBet();
        }

        return 5 * dataService.NowBet * dataService.GetCollectBet();
    }

    public void CheckTriggerPopup()
    {
        if(!IsOpenActivity()) return;
        if (dataService.CollectMusicProgress.PopBtn)
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.CollectMusicPopup,BoxBuilder.ShowCollectMusicPopup);
            dataService.CollectMusicProgress.PopBtn = false;
        }
    }

    #region 活动结束，发放游戏奖励

    public void CheckGetReward()
    {
        if (dataService.CollectMusicProgress.readyGetRewardDic.Count > 0)
        {
            rewardDic = new Dictionary<int, int>(dataService.CollectMusicProgress.readyGetRewardDic);
            GameCommon.IsPlayingCollectAnim = true;
            if (rewardDic.Count > 1)
            {
                Observable.Timer(TimeSpan.FromSeconds(1.3f)).Subscribe(_ =>
                {
                    BoxBuilder.ShowRewardPop(rewardDic, PropChangeWay.CollectMuiscReward, endCall: () =>
                                            {
                                                dataService.CollectMusicProgress.getRewardCount = 0;
                                                TypeEventSystem.Send<TriggrePopupEvent>();
                                            });
                });
                TypeEventSystem.Send<PlayGetMusicReward>(new PlayGetMusicReward((int)PropEnum.Xishu,0,false));
            }
            else
            {
                int type = (int)PropEnum.Coin;
                int count = 0;
                foreach (var pair in rewardDic)
                {
                    type = pair.Key;
                    count = pair.Value;
                    dataService.AddProp(pair.Key,pair.Value,PropChangeWay.CollectMuiscReward,Vector3.zero,false);
                }
                TypeEventSystem.Send<PlayGetMusicReward>(new PlayGetMusicReward(type,count,true));
            }
            dataService.CollectMusicProgress.readyGetRewardDic.Clear();
            ActivityManager.Instance.SaveActivityData();
        }
    }
    
    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.collectMusic);
    }
    #endregion
}