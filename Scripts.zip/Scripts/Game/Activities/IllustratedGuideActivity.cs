using Model;
using SoliUtils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public interface IIllustratedGuideActivity
{
    List<MergeIllustratedData> GetDataListByTabIndex(int tabIndex);

    bool CheckCanReward(int tabIndex);
    void DoGetReward(MergeItemConfig config);
}
public class IllustratedGuideActivity : IIllustratedGuideActivity
{
    private IConfigService _configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService _dataService = MainContainer.Container.Resolve<IDataService>();
    private Dictionary<int,List<MergeIllustratedData>> _dataDict = new Dictionary<int, List<MergeIllustratedData>>();

    public IllustratedGuideActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.IllustratedGuide, GetRedDotNodes);
    }

    private List<RedDotNode> GetRedDotNodes()
    {
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.IllustratedGuide);
        List<RedDotNode> list = new List<RedDotNode>();
        for(int page = 1; page <= 6; page++)
        {
            if (CheckCanReward(page))
            {
                list.Add(rootNode.GetChildNode(page));
            }
        }
        return list;
    }


    public List<MergeIllustratedData> GetDataListByTabIndex(int tabIndex)
    {
        if (!_dataDict.ContainsKey(tabIndex))
        {
            List<MergeIllustratedData> dataList = new List<MergeIllustratedData>();
            _dataDict.Add(tabIndex, dataList);
            Dictionary<int, MergeItemConfig> mergeItemConfig = _configService.MergeItemConfig;
            List<MergeIllustratedConfig> configList = _configService.MergeIllustratedConfig.Values.Where(cfg => cfg.tab_index == tabIndex).ToList();
            for(int i=0;i< configList.Count; i++)
            {
                MergeIllustratedConfig config = configList[i];
                MergeIllustratedData data = new MergeIllustratedData();
                data.config = config;
                data.targetConfig = mergeItemConfig[config.id];
                data.pieceConfigs = new List<MergeItemConfig>();
                MergeItemConfig itemConfig = data.targetConfig;
                while(itemConfig.mergeItem > 0 && mergeItemConfig.ContainsKey(itemConfig.mergeItem))
                {
                    itemConfig = mergeItemConfig[itemConfig.mergeItem];
                    data.pieceConfigs.Add(itemConfig);
                }
                data.pieceConfigs.Reverse();
                if ((Constants.MergeItemType)data.targetConfig.itemType != Constants.MergeItemType.Npc)//��npc
                {
                    data.pieceConfigs.Add(data.targetConfig);
                }
                dataList.Add(data);
            }
        }
        return _dataDict[tabIndex];
    }

    public bool CheckCanReward(int tabIndex)
    {
        List<MergeIllustratedData> datas = GetDataListByTabIndex(tabIndex);
        for(int i = 0; i < datas.Count; i++)
        {
            MergeIllustratedData data = datas[i];
            //if (_dataService.CheckMergeItemFirstUnlock(data.config.id))
            //{
            //    return true;
            //}
            List<MergeItemConfig> pieceConfigs = data.pieceConfigs;
            for (int j=0;j< pieceConfigs.Count; j++)
            {
                if ((MergeItemState)_dataService.GetMergeItemState(pieceConfigs[j].id) == MergeItemState.CanReward)
                {
                    return true;
                }
            }
        }
        return false;
    }

    public void DoGetReward(MergeItemConfig config)
    {
        _dataService.SetMergeItemState(config.id, (int)MergeItemState.HasReward);
        AddRewardProp(config);
    }

    private void AddRewardProp(MergeItemConfig config)
    {
        string reward = config.unlock_reward;
        string[] items = reward.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
        foreach (var item in items)
        {
            string[] param = item.Split(GameUtils.FirstSeparator);
            int id = int.Parse(param[0]);
            int num = int.Parse(param[1]);
            _dataService.AddProp(id, num, PropChangeWay.UnlockMergeItem, new object[]{ false,false });
        }
    }

}