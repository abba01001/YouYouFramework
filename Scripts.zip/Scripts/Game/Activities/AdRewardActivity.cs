﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using Model;
using UnityEngine;
using SoliUtils;

public interface IAdRewardActivity
{
    void RefreshBallon(Action action);
    void RefreshPushAdCount();
    bool CheckBallonShow();
    bool CheckAdPush();
    void CheckFinishActivity();
    float GetRatio();
    int GetCurLayerCollectCount();
    int GetNextLayerCollectCount();
    void CheckGetReward(int index);
    void CheckFinalReward(Action sucessAction, Action failAction);
    int GetMaxProgress();
    void GMAddCount(int input);
    int GetMaxLayer();
}

//每日广告奖励活动
public class AdRewardActivity : IAdRewardActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public bool CheckAdPush()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.adReward).state != ActivityState.underWay) return false;
        if (dataService.AdRewardProgress.pushAdCount > int.Parse(configService.ValueConfig["FailPushAdLimit"])) return false;
        return true;
    }

    public void GMAddCount(int input)
    {
        dataService.AdRewardProgress.UpdateProgress(input);
    }

    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.adReward, false);
    }

    public bool CheckBallonShow()
    {
        if (dataService.AdRewardProgress.ballonBornCount > int.Parse(configService.ValueConfig["FreeItemAdLimit"])) return false;
        if (dataService.AdRewardProgress.ballonBornTime == 0) return true;
        int curTime = ActivityManager.Instance.GetActivitySeverTime();
        return false;
    }

    public void CheckGetReward(int index)
    {
        if (dataService.AdRewardProgress.curLayer + 1 == index)
        {

#if UNITY_EDITOR
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.RewardPopup,
                () => BoxBuilder.ShowRewardPop(GetReward(index), PropChangeWay.DailyReward, endCall: () =>
                {
                    dataService.AdRewardProgress.UpdateLayer();
                    ActivityManager.Instance.SaveActivityData();
                    TypeEventSystem.Send<UpdateAdRewardPanel>();
                }, activityType: ActivityType.adReward), true);
            return;
#endif
            AdPlayer.ShowFreeItemAd((() =>
            {
                ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.RewardPopup,
                    () => BoxBuilder.ShowRewardPop(GetReward(index), PropChangeWay.DailyReward, endCall: () =>
                    {
                        dataService.AdRewardProgress.UpdateLayer();
                        ActivityManager.Instance.SaveActivityData();
                        TypeEventSystem.Send<UpdateAdRewardPanel>();
                    }, activityType: ActivityType.adReward), true);
            }));
        }
    }

    public void CheckFinalReward(Action sucessAction, Action failAction)
    {
        if (dataService.AdRewardProgress.totalProgress < GetMaxProgress())
        {
            failAction?.Invoke();
            return;
        }
        if (!dataService.CheckDailyFlag(FlagType.FinalAdReward))
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.RewardPopup,
                () => BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(configService.ValueConfig["AdRewardProgressCumulative"]), PropChangeWay.DailyReward, endCall: () =>
                {
                    TypeEventSystem.Send<UpdateAdRewardPanel>();
                }, activityType: ActivityType.adReward), true);
            dataService.AddDailyFlag(FlagType.FinalAdReward);
        }
    }

    private Dictionary<int, int> GetReward(int index)
    {
        foreach (var pair in configService.AdRewardConfig)
        {
            if (pair.Value.layer == index)
            {
                return GameUtils.AnalysisPropString(pair.Value.reward);
            }
        }
        return null;
    }

    public void RefreshPushAdCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.adReward).state != ActivityState.underWay) return;
        dataService.AdRewardProgress.pushAdCount++;
    }

    public void RefreshBallon(Action action)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.adReward).state != ActivityState.underWay) return;
        dataService.AdRewardProgress.ballonBornCount++;
        dataService.AdRewardProgress.ballonBornTime = ActivityManager.Instance.GetActivitySeverTime();
        dataService.AdRewardProgress.UpdateProgress();
        action?.Invoke();
    }

    public int GetCurLayerCollectCount()
    {
        return Mathf.Min(dataService.AdRewardProgress.totalProgress, GetMaxProgress());
    }

    public AdRewardModel GetLayerModel(int layer)
    {
        AdRewardModel nextModel = null;
        layer = Mathf.Min(layer, GetMaxLayer());
        foreach (var VARIABLE in configService.AdRewardConfig)
        {
            if (VARIABLE.Value.layer == layer)
            {
                nextModel = VARIABLE.Value;
                break;
            }
        }
        return nextModel;
    }
    public int GetMaxLayer()
    {
        int maxLayer = 0;
        foreach (var VARIABLE in configService.AdRewardConfig)
        {
            maxLayer++;
        }
        return maxLayer;
    }

    public int GetMaxProgress()
    {
        return int.Parse(configService.ValueConfig["AdRewardProgress"]);
        // int maxLayer = GetMaxLayer();
        // foreach (var VARIABLE in configService.AdRewardConfig)
        // {
        //     if (VARIABLE.Value.layer == maxLayer)
        //     {
        //         return VARIABLE.Value.progress;
        //     }
        // }
        // return 0;
    }

    public int GetNextLayerCollectCount()
    {
        return int.Parse(configService.ValueConfig["AdRewardProgress"]);
    }

    public float GetRatio()
    {
        return (float)GetCurLayerCollectCount() / GetNextLayerCollectCount();
    }
}