﻿using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface ICollectHoneyActivity
{
    void CheckOpenActivity();
    bool IsOpenActivity();
    void CheckTriggerPopup();
    void GMAddCount(int input);
    int GetTotalProgress();
    int GetCurMaxProgress();
    int GetCurProgress();
    float GetCurLayerRatio();
    Dictionary<int, int> GetBottleReward(int layer);
    MagicNectarModel GetLayerModel(int layer);
    void CheckGetReward();
    void CheckFinishActivity();
    void AddMyHoneyCount(int count);
    bool IsMaxLevel();
}

public class CollectHoneyActivity: ICollectHoneyActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();
    
    public void AddMyHoneyCount(int count)
    {
        if (!IsOpenActivity()) return;
        dataService.CollectHoneyProgress.progress += count;
        Observable.Timer(TimeSpan.FromSeconds(0.1f)).Subscribe(_ =>
        {
            StaticCoroutine.StartCoroutine(CheckReward());
        });
    }

    public bool IsMaxLevel()
    {
        return dataService.CollectHoneyProgress.curLayer >= configService.MagicNectarConfig.Count;
    }
    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.collectHoney);
    }
    
    public Dictionary<int, int> GetBottleReward(int layer)
    {
        configService.MagicNectarConfig.TryGetValue(layer, out MagicNectarModel model);
        return GameUtils.AnalysisPropString(model.reward);
    }
    public int GetTotalProgress()
    {
        return configService.MagicNectarConfig[configService.MagicNectarConfig.Count].progress;
    }

    public int GetCurMaxProgress()
    {
        int curLayer = dataService.CollectHoneyProgress.curLayer + 1;
        if (curLayer == 1)
        {
            configService.MagicNectarConfig.TryGetValue(1, out MagicNectarModel model);
            return model.progress;
        }
        else
        {
            configService.MagicNectarConfig.TryGetValue(curLayer - 1, out MagicNectarModel model1);
            configService.MagicNectarConfig.TryGetValue(curLayer, out MagicNectarModel model2);
            return model2.progress - model1.progress;
        }
    }
    
    public int GetCurProgress()
    {
        int curLayer = dataService.CollectHoneyProgress.curLayer + 1;
        if (curLayer == 1)
        {
            return dataService.CollectHoneyProgress.progress;
        }
        else
        {
            configService.MagicNectarConfig.TryGetValue(curLayer - 1, out MagicNectarModel model);
            return dataService.CollectHoneyProgress.progress - model.progress;
        }
    }

    public float GetCurLayerRatio()
    {
        return (float) GetCurProgress() / GetCurMaxProgress();
    }

    public MagicNectarModel GetLayerModel(int layer)
    {
        configService.MagicNectarConfig.TryGetValue(layer, out MagicNectarModel model);
        return model;
    }
    
    public void GMAddCount(int input)
    {
        if (!IsOpenActivity()) return;
        dataService.CollectHoneyProgress.progress += input;
        Observable.Timer(TimeSpan.FromSeconds(0.1f)).Subscribe(_ =>
        {
            StaticCoroutine.StartCoroutine(CheckReward());
        });
    }

    public void CheckGetReward()
    {
        int layer = 0;
        int progress = dataService.CollectHoneyProgress.progress;
        foreach (var model in configService.MagicNectarConfig)
        {
            if(model.Value.progress > progress) break;
            layer++;
        }

        if (dataService.CollectHoneyProgress.curLayer != layer)
        {
            string rewardStr = "";
            for (int i = dataService.CollectHoneyProgress.curLayer + 1; i <= layer; i++)
            {
                if (rewardStr != "") rewardStr += $";{GetLayerModel(i).reward}";
                else rewardStr = GetLayerModel(i).reward;
            }
            dataService.CollectHoneyProgress.curLayer = layer;
            Dictionary<int, int> rewards = GameUtils.AnalysisPropString(rewardStr);
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.PopCollectRewardPopup, () =>
            {
                BoxBuilder.ShowPopCollectRewardPopup(ActivityType.collectHoney, GameUtils.AnalysisPropString(rewardStr) ,null,null);
            });
            dataService.SaveRewardData(rewards,PropChangeWay.CollectHoneyReward);
        }
    }

    private IEnumerator CheckReward()
    {
        yield return new WaitUntil(() => GameCommon.VisiblePopupCount == 0);
        CheckGetReward();
    }
    
    public void CheckOpenActivity()
    {
        if (!IsOpenActivity()) return;
        // dataService.RabitGiftProgress.curWinCount = 0;
    }
    
    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.collectHoney) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.collectHoney).state ==
               ActivityState.underWay;
    }

    public void CheckTriggerPopup()
    {
        if (dataService.CollectHoneyProgress.PopBtn && IsOpenActivity())
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.CollectHoneyPopup, () =>
            {
                BoxBuilder.ShowCollectHoneyPopup();
                dataService.CollectHoneyProgress.PopBtn = false;
            });
        }
        
        if (IsOpenActivity() && ActivityManager.Instance.CollectHoneyActivity.IsMaxLevel())
        {
            dataService.CollectHoneyProgress.FinishGetReward = true;
        }
    }
    
}