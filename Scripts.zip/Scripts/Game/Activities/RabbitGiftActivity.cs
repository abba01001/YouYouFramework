﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface IRabbitGiftActivity
{
    void CheckOpenActivity(bool isWin);
    bool IsOpenActivity();
    void CheckTriggerPopup();
    List<CardModel> GetCardList();
    void GMAddCount(int input);
    void ResetLastWinCount();
    void CheckFinishActivity();
    bool CheckLoseThreeWin();
}

public class RabbitGiftActivity: IRabbitGiftActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public bool CheckLoseThreeWin()
    {
        if (!IsOpenActivity()) return false;
        return dataService.RabitGiftProgress.curWinCount == 3;
    }
    
    public void GMAddCount(int input)
    {
        if (!IsOpenActivity()) return;
        dataService.RabitGiftProgress.curWinCount = Mathf.Min(input, 3);
    }

    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.rabbitGift);
    }
    
    public void CheckOpenActivity(bool isWin)
    {
        if (!IsOpenActivity()) return;
        dataService.RabitGiftProgress.curWinCount = isWin ? Mathf.Min(dataService.RabitGiftProgress.curWinCount + 1, 3) : 0;
    }
    
    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.rabbitGift) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.rabbitGift).state ==
               ActivityState.underWay;
    }

    public List<CardModel> GetCardList()
    {
        if (dataService.RabitGiftProgress.curWinCount > 0)
        {
            List<CardModel> tempList = new List<CardModel>();

            for (int i = 0; i < dataService.RabitGiftProgress.curWinCount; i++)
            {
                CardModel cm = null;
                if (i == 0 || i == 1)
                {
                    cm = new CardModel(99, CardType.Monochrome, faceUp: false);
                    cm.suit = i;
                    cm.random = false;
                    cm.faceUp = true;
                }
                else
                {
                    cm = new CardModel(99, CardType.Joker, faceUp: false);
                }
                tempList.Add(cm);
            }
            return tempList;
        }
        return null;
    }
    
    public void CheckTriggerPopup()
    {
        if (dataService.RabitGiftProgress.PopBtn && IsOpenActivity())
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.RabbitGiftPopup, () =>
            {
                BoxBuilder.ShowRabbitGiftPopup();
                dataService.RabitGiftProgress.PopBtn = false;
            });
        }
    }

    public void ResetLastWinCount()
    {
        dataService.RabitGiftProgress.lastWinCount = dataService.RabitGiftProgress.curWinCount;
    }
    
}