﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using Model;
using SoliUtils;

public interface ILevelPassActivity
{
    void OperateRobotWinCount();
    void InitRankInfo();
    Dictionary<int, int> GetReward(int index);
    void Update();
    void CheckRefreshRobot();
    void CheckOpenActivity();
    void GMAddWinCount(int count);
    bool CheckCanGetReward();
    void CheckGetReward(Action action);
    void CheckFinishActivity();
    void CheckTriggerPopup();
    bool IsOpenActivity();
}

//10关PK挑战
public class LevelPassActivity : ILevelPassActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public LevelPassActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.BoatGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.BoatGuide);
        if (dataService.LevelPassProgress.IsFirstShow)
            list.Add(rootNode);

        if (dataService.LevelPassProgress.ActivityEndTime != 0 && ActivityManager.Instance.GetActivitySeverTime() >
            dataService.LevelPassProgress.ActivityEndTime - 300)
            list.Add(rootNode);

        return list;
    }

    //机器人刷新时间节点
    private DateTime _curTimeNode = DateTime.MinValue;

    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.levelPass) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state ==
               ActivityState.underWay;
    }

    private DateTime CurTimeNode
    {
        get => _curTimeNode;
        set
        {
            bool finish = true;
            int node = 0;
            dataService.LevelPassProgress.CurNodeId = 0;
            DateTime startTime = TimeUtils.IntToDateTime(dataService.LevelPassProgress.ActivityBeginTime);
            foreach (var model in configService.LevelPassConfig)
            {
                node += model.Value.node;
                if (ActivityManager.Instance.GetActivityNowDateTime() <= startTime.AddMinutes(node))
                {
                    _curTimeNode = startTime.AddMinutes(node);
                    finish = false;
                    break;
                }

                dataService.LevelPassProgress.CurNodeId++;
            }

            if (finish) _curTimeNode = DateTime.MaxValue;
            OperateRobotWinCount();
        }
    }

    public void GMAddWinCount(int count)
    {
        OperateMyWinCount(count);
    }

    //设置机器人鲜花数
    public void OperateRobotWinCount()
    {
        if (CheckCanGetReward()) return;
        foreach (var robotData in dataService.LevelPassProgress.GetRobotData())
        {
            robotData.lastSuccessVictory = robotData.successVictory;
            robotData.successVictory =
                dataService.LevelPassProgress.GetRobotStepAddCount(robotData, dataService.LevelPassProgress.CurNodeId);
        }

        ActivityManager.Instance.SaveActivityData();
        TypeEventSystem.Send<RefreshActivityRank>();
    }

    public void InitRankInfo()
    {
        dataService.LevelPassProgress.InitRankInfo();
    }

    public Dictionary<int, int> GetReward(int index)
    {
        configService.LevelPassConfig.TryGetValue(index, out LevelPassModel model);
        Dictionary<int, int> reward = new Dictionary<int, int>();
        if (model != null)
        {
            reward = GameUtils.AnalysisPropString(model.reward);
        }

        return reward;
    }

    public void Update()
    {
        if (dataService.LevelPassProgress is {ActivityBeginTime: > 0})
        {
            CheckRefreshRobot();
        }
    }

    public void CheckOpenActivity()
    {
        if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.levelPass)) return;
        InitRankInfo();
        OperateMyWinCount();
        CheckRefreshRobot();
    }

    public void CheckFinishActivity()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state == ActivityState.waitFinished)
        {
            ActivityManager.Instance.FinishGetReward(ActivityType.levelPass);
        }
    }

    public void OperateMyWinCount(int inputCount = 0)
    {
        int addCount = inputCount == 0 ? 1 : inputCount;
        var msg = new Dictionary<string, object>
        {
            {"score_before", dataService.LevelPassProgress.GetMyData().successVictory},
            {"score_add", addCount},
            {"start_time", dataService.LevelPassProgress.ActivityBeginTime},
        };
        AnalyticUtils.ReportEvent(AnalyticsKey.LevelPass_Score, msg);
        dataService.LevelPassProgress.GetMyData().successVictory += addCount;

        //已经获取奖励的机器人，保持排名
        foreach (var data in dataService.LevelPassProgress.GetRankData())
        {
            if (data.finish == 1 && data != dataService.LevelPassProgress.GetMyData()) data.successVictory++;
        }

        ActivityManager.Instance.SaveActivityData();
    }

    public bool CheckCanGetReward()
    {
        LevelPassData data = dataService.LevelPassProgress.GetMyData();
        if (data.curRank <= 2 && data.successVictory >= 10) return true;
        return false;
    }

    public void CheckGetReward(Action cb)
    {
        if (!CheckCanGetReward()) return;

        dataService.CollectFlowerProgress.RewardFlag = 1;

        LevelPassData data = dataService.LevelPassProgress.GetMyData();
        BoxBuilder.ShowRewardPop(GetReward(data.curRank + 1), PropChangeWay.LevelPassReward, null,
            activityType: ActivityType.levelPass);
        cb?.Invoke();
        ActivityManager.Instance.FinishGetReward(ActivityType.levelPass);
    }

    public void CheckRefreshRobot()
    {
        if (CurTimeNode == DateTime.MaxValue)
        {
            return;
        }

        if (CurTimeNode == DateTime.MinValue)
        {
            CurTimeNode = ActivityManager.Instance.GetActivityNowDateTime();
        }

        if (ActivityManager.Instance.GetActivityNowDateTime() >= CurTimeNode)
        {
            CurTimeNode = ActivityManager.Instance.GetActivityNowDateTime();
        }
    }

    public void CheckTriggerPopup()
    {
        if (dataService.LevelPassProgress.PopBtn &&
            ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state == ActivityState.waitEntry ||
            dataService.LevelPassProgress.FinishPopView)
        {
            if (dataService.LevelPassProgress.FinishPopView)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.LevelPassPopup, () =>
                {
                    dataService.LevelPassProgress.FinishPopView = false;
                    BoxBuilder.ShowLevelPassPopup(false);
                });
            }
            else
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartLevelPassPopup,
                    BoxBuilder.ShowStartLevelPassPopup);
                dataService.LevelPassProgress.PopBtn = false;
            }
        }

        if (ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state == ActivityState.underWay &&
            ActivityManager.Instance.LevelPassActivity.CheckCanGetReward())
        {
            if (!dataService.LevelPassProgress.IsCheckingFinish)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.LevelPassPopup, () =>
                {
                    dataService.LevelPassProgress.IsCheckingFinish = true;
                    BoxBuilder.ShowLevelPassPopup(false);
                });
            }
        }

        if (ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state == ActivityState.waitFinished)
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.LevelPassPopup,
                () => { BoxBuilder.ShowLevelPassPopup(false); });
        }
    }
}