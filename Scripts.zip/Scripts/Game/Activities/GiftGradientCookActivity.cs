﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using Model;
using UnityEngine;
using SoliUtils;
using UniRx;

public interface IGiftGradientCookActivity
{
    void CheckFinishActivity();
    int GetStartIndex();
    void CheckTriggerPopup();
    void UpdateProgress(int value);
    int GetMaxProgress();
    GradientModel GetCurLayerCollectModel();
}

//梯度礼包活动
public class GiftGradientCookActivity : IGiftGradientCookActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public GiftGradientCookActivity()
    {
        RedDotMgr.Instance.Register(RedDotId.GradientCookGuide, GetRedDotNodes);
    }

    public List<RedDotNode> GetRedDotNodes()
    {
        List<RedDotNode> list = new List<RedDotNode>();
        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.GradientCookGuide);
        if (CheckCurGiftCanGet())
            list.Add(rootNode);
        return list;
    }

    public bool CheckCurGiftCanGet()
    {
        if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.giftGradientCook)) return false;
        int index = GetStartIndex();
        if (configService.GiftGradientCookConfig.TryGetValue(index, out GradientModel model))
        {
            return model.IsFree == 1;
        }

        return false;
    }


    public void CheckTriggerPopup()
    {
        if (dataService.GiftGradientCookProgress.PopBtn &&
            ActivityManager.Instance.GetActivityByType(ActivityType.giftGradientCook).state == ActivityState.underWay)
        {
            if (!GameCommon.IsShieldPurchase)
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.GiftGradientCookPopup,
                    BoxBuilder.ShowGiftGradientCook);
                dataService.GiftGradientCookProgress.PopBtn = false;
            }
        }
    }

    public GradientModel GetCurLayerCollectModel()
    {
        foreach (var model in configService.GiftGradientCookConfig)
        {
            if (model.Value.collectLayer == dataService.GiftGradientCookProgress.CollectLayer)
            {
                return model.Value;
            }
        }

        return null;
    }

    public void UpdateProgress(int value)
    {
        foreach (var model in configService.GiftGradientCookConfig)
        {
            if (model.Key == dataService.GiftGradientCookProgress.CollectLayer)
            {
                dataService.GiftGradientCookProgress.CollecProgress += value;
                int max = model.Value.collectProgress;
                if (dataService.GiftGradientCookProgress.CollecProgress >= max)
                {
                    dataService.GiftGradientCookProgress.CollectLayer++;
                    int left = dataService.GiftGradientCookProgress.CollecProgress - max;
                    dataService.GiftGradientCookProgress.CollecProgress = left;
                    Observable.Timer(TimeSpan.FromSeconds(0.1f)).Subscribe(_ =>
                    {
                        GetCollectReward(model.Value);
                    });
                }

                dataService.SaveData(true);
                break;
            }
        }

        TypeEventSystem.Send<UpdateGiftCookProgress>();
    }

    private void GetCollectReward(GradientModel model)
    {
        BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(model.collectReward),
            PropChangeWay.GiftGradientCollectReward, endCall: () => { }, true,
            activityType: ActivityType.giftGradientCook);
    }

    public int GetMaxProgress()
    {
        int value = 0;
        foreach (var model in configService.GiftGradientCookConfig)
        {
            if (model.Key == dataService.GiftGradientCookProgress.CollectLayer)
            {
                value = model.Value.collectProgress;
                break;
            }
        }

        if (value == 0) value = 1;
        return value;
    }

    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.giftGradientCook,false);
    }

    public int GetStartIndex()
    {
        int startIndex = -1;
        foreach (var pair in configService.GiftGradientCookConfig)
        {
            if (pair.Key > dataService.GiftGradientCookProgress.CurRewardIndex)
            {
                startIndex = pair.Key;
                break;
            }
        }

        if (startIndex == -1) startIndex = configService.GiftGradientCookConfig.Count + 1;
        return startIndex;
    }
}