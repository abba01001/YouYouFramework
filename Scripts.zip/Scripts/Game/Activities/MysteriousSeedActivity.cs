﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface IMysteriousSeedActivity
{
    void CheckOpenActivity(bool isWin);
    bool IsOpenActivity();
    void CheckTriggerPopup();
    void GMAddCount(int input);
    void CheckGetReward();
    void OperateProgress(bool isWin);
    void CheckFinishActivity();
    void RefreshLast();
    bool CheckIsMaxLevel();
    bool CheckFinalBallon();
}

public class MysteriousSeedActivity: IMysteriousSeedActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public bool CheckFinalBallon()
    {
        if (!IsOpenActivity()) return false;
        return dataService.MysteriousSeedProgress.failCount == 2;
    }
    
    public void RefreshLast()
    {
        dataService.MysteriousSeedProgress.lastLayer = dataService.MysteriousSeedProgress.curLayer;
        dataService.MysteriousSeedProgress.lastProgress = dataService.MysteriousSeedProgress.curProgress;
        ActivityManager.Instance.SaveActivityData();
    }

    public void GMAddCount(int input)
    {
        if (!IsOpenActivity()) return;
        bool state = input > 0 ? true : false;
        for (int i = 0; i < Mathf.Abs(input); i++)
        {
            OperateProgress(state);
        }
    }
    
    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.mysteriousSeed);
    }
    
    public void CheckOpenActivity(bool isWin)
    {
        if (!IsOpenActivity()) return;
        OperateProgress(isWin);
    }

    public bool CheckIsMaxLevel()
    {
        return dataService.MysteriousSeedProgress.rewardLayer == configService.MysteriousSeedConfig.Count;
    }

    public void ResetFailCount()
    {
        dataService.MysteriousSeedProgress.failCount = 0;
    }

    public void CheckGetReward()
    {
        if (dataService.MysteriousSeedProgress.canGetReward)
        {
            dataService.MysteriousSeedProgress.canGetReward = false;
            dataService.MysteriousSeedProgress.rewardLayer++;
            if (configService.MysteriousSeedConfig.TryGetValue(dataService.MysteriousSeedProgress.curLayer, out MysteriousSeedModel model))
            {
                PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.MysteriousSeedPopup, () =>
                {
                    BoxBuilder.ShowMysteriousSeedPopup();
                    BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(model.reward), PropChangeWay.MysteriousSeed,
                        endCall:
                        () =>
                        {
                            if (CheckIsMaxLevel())
                            {
                                dataService.MysteriousSeedProgress.FinishGetReward = true;
                                ActivityManager.Instance.SaveActivityData();
                                BoxBuilder.HideMysteriousPopup();
                            }
                        });
                }, true, 1);
            }
        }
    }
    
    public void OperateProgress(bool win)
    {
        int layer = dataService.MysteriousSeedProgress.curLayer + 1;
        if (configService.MysteriousSeedConfig.TryGetValue(layer, out MysteriousSeedModel model))
        {
            if (win)
            {
                dataService.MysteriousSeedProgress.curProgress++;
                if (dataService.MysteriousSeedProgress.curProgress >= model.progress)
                {
                    //跳到下一层
                    dataService.MysteriousSeedProgress.curLayer++;
                    dataService.MysteriousSeedProgress.curProgress = 0;
                    dataService.MysteriousSeedProgress.canGetReward = true;
                    dataService.MysteriousSeedProgress.failCount = 0;
                }
            }
            else
            {
                dataService.MysteriousSeedProgress.failCount++;
                if (dataService.MysteriousSeedProgress.failCount >= 3)
                {
                    dataService.MysteriousSeedProgress.curProgress = 0;
                    ResetFailCount();
                }
            }
        }
        ActivityManager.Instance.SaveActivityData();
    }
    
    
    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.mysteriousSeed) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.mysteriousSeed).state ==
               ActivityState.underWay;
    }

    public void CheckTriggerPopup()
    {
        if (dataService.MysteriousSeedProgress.PopBtn && IsOpenActivity())
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartMysteriousSeedPopup, BoxBuilder.ShowStartMysteriousSeedPopup);
            dataService.MysteriousSeedProgress.PopBtn = false;
        }
        CheckGetReward();
    }
    
}