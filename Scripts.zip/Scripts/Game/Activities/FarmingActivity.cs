﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using Model;
using UniRx;
using UnityEngine;
using SoliUtils;

public interface IFarmingActivity
{
    void ChangeMap(int mapId,int themeId,Action successCb,Action failCb);
    void CheckChangeBg();
    void ResetPickUp(bool canPick);
    void GetHarvestCoin(Action cb);
    ThemeData GetCurThemeData();
    int GetCurMapId();
    int GetCurThemeId();
    bool CanGetReward();
    FarmingModel GetWaitUnlockLand();
}

//农场
public class FarmingActivity : IFarmingActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();

    public void ChangeMap(int mapId,int themeId,Action successCb,Action failCb)
    {
        if(mapId == GetCurMapId() && themeId == GetCurThemeId()) return;
        if (dataService.FarmingProgress.maxMapId >= mapId && dataService.FarmingProgress.MapInfo[mapId][themeId].Unlock)
        {
            dataService.FarmingProgress.curMapId = mapId;
            dataService.FarmingProgress.curThemeId = themeId;
            TypeEventSystem.Send<UpdateFarmingPanelEvent>();
            successCb?.Invoke();
            return;
        }
        failCb?.Invoke();
    }
    
    public void GetHarvestCoin(Action cb)
    {
        int curTime = ActivityManager.Instance.GetActivitySeverTime();
        if (dataService.FarmingProgress.collectTimer != -1 && curTime >= dataService.FarmingProgress.collectTimer || dataService.FarmingProgress.directCollect)
        {
            int count = 0;
            foreach (var VARIABLE in GetCurThemeData().LandInfo)
            {
                if (VARIABLE.Value.PickFlag && VARIABLE.Value.Unlock)
                {
                    VARIABLE.Value.SendPlayHarvestAnim();
                    count++;
                }
            }
            if (!dataService.FarmingProgress.directCollect)
            {
                ResetPickUp(false);
            }


            int tempAdd = 0;
            SoundPlayer.Instance.PlayMainSound("Plants_Collect_All");
            bool playBeforeAnim = false;
            PropChangeWay changeWay = PropChangeWay.AfkCoin;
            if (dataService.FarmingProgress.directCollect)
            {
                tempAdd += dataService.FarmingProgress.unlockCoin;
                dataService.FarmingProgress.unlockCoin = 0;
                dataService.FarmingProgress.directCollect = false;
                changeWay = PropChangeWay.CollectFarmingCoin;
                if (dataService.FarmingProgress.collectTimer == -1)
                {
                    dataService.FarmingProgress.collectTimer = ActivityManager.Instance.GetActivitySeverTime() + 3600;
                }
            }
            else
            {
                playBeforeAnim = true;
                dataService.FarmingProgress.collectTimer = ActivityManager.Instance.GetActivitySeverTime() + 3600;
            }
            TypeEventSystem.Send<UpdateFarmingPanelEvent>();
            TypeEventSystem.Send<CollectFarmingCoin>(new CollectFarmingCoin(tempAdd,playBeforeAnim,changeWay));
            dataService.FarmingProgress.resetFlag = false;
            RefreshActivityTimer t = GameObjManager.Instance.PopClass<RefreshActivityTimer>(true);
            t.Init(ActivityType.farmingCollect);
            TypeEventSystem.Send<RefreshActivityTimer>(t);
            cb?.Invoke();
            return;
        }
    }

    public void CheckChangeBg()
    {
        if (dataService.FarmingProgress.lastMapId != dataService.FarmingProgress.maxMapId ||
            dataService.FarmingProgress.lastMaxThemeId != dataService.FarmingProgress.maxThemeId)
        {
            int maxMapId = dataService.FarmingProgress.maxMapId;
            int maxThemeId = dataService.FarmingProgress.maxThemeId;
            dataService.FarmingProgress.lastMapId = maxMapId;
            dataService.FarmingProgress.lastMaxThemeId = maxThemeId;
            // foreach (var dict in configService.GetHomeMapModel())
            // {
            //     foreach (var model in dict.Value)
            //     {
            //         if (model.Value.mapId == maxMapId && model.Value.themeId == maxThemeId)
            //         {
            //             Observable.Timer(TimeSpan.FromSeconds(1.7f)).Subscribe(_ =>
            //             {
            //                 GameUtils.ChangeMap(model.Value);
            //             });
            //             break;
            //         }
            //     }
            // }
            ActivityManager.Instance.SaveActivityData();
        }
    }
    public void ResetPickUp(bool canPick)
    {

        for (int i = 1; i <= dataService.FarmingProgress.MapInfo.Count; i++)
        {
            int index = 1;
            index = i == dataService.FarmingProgress.maxMapId ? dataService.FarmingProgress.maxThemeId : 3;
            for (int j = 1; j <= index; j++)
            {
                foreach (var VARIABLE in dataService.FarmingProgress.MapInfo[i][j].LandInfo)
                {
                    VARIABLE.Value.PickFlag = canPick;
                }
            }
        }
    }
    
    public ThemeData GetCurThemeData()
    {
        return dataService.FarmingProgress.MapInfo[GetCurMapId()][GetCurThemeId()];
    }

    public ThemeData GetMaxThemeData()
    {
        return dataService.FarmingProgress.MapInfo[dataService.FarmingProgress.maxMapId][dataService.FarmingProgress.maxThemeId];
    }

    public int GetCurMapId()
    {
        return dataService.FarmingProgress.curMapId;
    }

    public int GetCurThemeId()
    {
        return dataService.FarmingProgress.curThemeId;
    }
    
    public bool CanGetReward()
    {
        int curTime = ActivityManager.Instance.GetActivitySeverTime();
        if (dataService.FarmingProgress.collectTimer != -1 && curTime >= dataService.FarmingProgress.collectTimer || dataService.FarmingProgress.directCollect)
        {
            return true;
        }
        return false;
    }
            
    //获取下一个解锁的土地
    public FarmingModel GetWaitUnlockLand()
    {
        foreach (var VARIABLE in GetCurThemeData().LandInfo)
        {
            if (!VARIABLE.Value.Unlock)
            {
                FarmingModel model = configService.GetFarmingModel(GetCurMapId(),GetCurThemeId(),VARIABLE.Value.landId);
                return model;
            }
        }
        return null;
    }
}