﻿using QFramework;
using System;
using System.Collections.Generic;
using Activities;
using UniRx;
using SoliUtils;
using UnityEngine;

public interface ICollectLoveCardActivity
{
    void CheckOpenActivity();
    int GetNextLayerCollectCount();
    int GetCurLayerCollectCount();
    List<SeasonLvRewardItem> GetNextReward();
    List<SeasonLvRewardItem> GetCurReward();
    float GetRatio();
    float GetTotalRatio();
    int GetPerLayerWidth();
    int GetAddCount();
    Dictionary<int, List<SeasonLvRewardItem>> GetRewardConfig();
    void CheckActivityCard(CardData cardData, Action action = null);
    void ClearActivityCard(CardData cardData, Action action = null);
    void CheckGetReward();
    void GMAddCount(int count);
    void CheckFinishActivity();
    int GetPoint();
    void InitData();
    bool CurIsMaxLayer();
    void CheckTriggerPopup();
    bool CheckReadyFull();
}

public class CollectLoveCardActivity : ICollectLoveCardActivity
{
    private IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
    private IDataService dataService = MainContainer.Container.Resolve<IDataService>();
    private Dictionary<int, int> rewardDic = new Dictionary<int, int>();

    public bool CheckReadyFull()
    {
        if (!IsOpenActivity()) return false;
        if(CurIsMaxLayer()) return false;
        int curLayer = dataService.CollectLoveCardProgress.curLayer;
        int getRewardLayer = dataService.CollectLoveCardProgress.getRewardLayer;
        int myCollectCount = dataService.CollectLoveCardProgress.collectCount + dataService.CollectLoveCardProgress.ResultAddCount;
        int progress = 0;
        bool isMax = false;
        foreach (var VARIABLE in configService.CollectLoveCardConfig)
        {
            if(VARIABLE.Value.collectType != dataService.CollectLoveCardProgress.SubActivityType) continue;
            progress = VARIABLE.Value.progress;
            if (progress > myCollectCount)
            {
                curLayer = VARIABLE.Value.layer - 1;
                break;
            }
        }
        int getRewardCount = curLayer - getRewardLayer;
        return getRewardCount > 0;
    }
    
    public bool IsOpenActivity()
    {
        return ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard) != null &&
               ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).state ==
               ActivityState.underWay;
    }
    
    public void GMAddCount(int count)
    {
        dataService.CollectLoveCardProgress.ResultAddCount = count;
        dataService.CollectLoveCardProgress.collectCount += dataService.CollectLoveCardProgress.ResultAddCount;
        dataService.CollectLoveCardProgress.cardList.Clear();
        CheckReward();
    }

    public void InitData()
    {
        if (dataService.CollectLoveCardProgress.cardList != null)
        {
            dataService.CollectLoveCardProgress.cardList.Clear();
        }
    }
    
    //设置玩家收集的方块爱心卡牌数
    private void OperateMyCollectCount()
    {
        dataService.CollectLoveCardProgress.collectCount += dataService.CollectLoveCardProgress.ResultAddCount;
        dataService.CollectLoveCardProgress.cardList.Clear();
    }

    public void CheckOpenActivity()
    {
        if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.collectLoveCard)) return;
        OperateMyCollectCount();
        CheckReward();
        TypeEventSystem.Send<UpdateCollectLoveCardViewEvent>();
    }

    
    //获取下一层需要收集的数量
    public int GetNextLayerCollectCount()
    {
        if (CurIsMaxLayer()) return GetMaxLayerCollectCount();
        int lastLayerProgress = 0;
        int layerProgress = 0;
        foreach (var VARIABLE in configService.CollectLoveCardConfig)
        {
            if(VARIABLE.Value.collectType != dataService.CollectLoveCardProgress.SubActivityType) continue;
            layerProgress = VARIABLE.Value.progress;
            if (VARIABLE.Value.progress > dataService.CollectLoveCardProgress.collectCount)
            {
                break;
            }
            lastLayerProgress = VARIABLE.Value.progress;
        }
        return layerProgress - lastLayerProgress;
    }

    private int GetMaxLayerCollectCount()
    {
        int count = 0;
        foreach (var VARIABLE in configService.CollectLoveCardConfig)
        {
            if(VARIABLE.Value.collectType != dataService.CollectLoveCardProgress.SubActivityType) continue;
            count = VARIABLE.Value.progress;
        }
        return count;
    }
    
    public int GetCurLayerCollectCount()
    {
        if (CurIsMaxLayer()) return GetMaxLayerCollectCount();
        int progress = 0;
        foreach (var VARIABLE in configService.CollectLoveCardConfig)
        {
            if(VARIABLE.Value.collectType != dataService.CollectLoveCardProgress.SubActivityType) continue;
            progress = VARIABLE.Value.progress;
            if (VARIABLE.Value.layer >= dataService.CollectLoveCardProgress.curLayer)
            {
                break;
            }
        }
        if (dataService.CollectLoveCardProgress.curLayer == 0) progress = 0;
        return dataService.CollectLoveCardProgress.collectCount - progress;
    }

    public float GetTotalRatio()
    {
        return Mathf.Clamp((float) (dataService.CollectLoveCardProgress.curLayer - 1) / GetRewardConfig().Count, 0, 1);
    }

    public int GetPerLayerWidth()
    {
        return 217;
    }
    
    public float GetRatio()
    {
        return (float)GetCurLayerCollectCount() / GetNextLayerCollectCount();
    }
    
    public List<SeasonLvRewardItem> GetCurReward()
    {
        int tempLayer = dataService.CollectLoveCardProgress.curLayer;
        List<SeasonLvRewardItem> list = new List<SeasonLvRewardItem>();
        foreach (var VARIABLE in configService.CollectLoveCardConfig)
        {
            if(VARIABLE.Value.collectType != dataService.CollectLoveCardProgress.SubActivityType) continue;
            if (tempLayer == VARIABLE.Value.layer)
            {
                foreach (var item in VARIABLE.Value.Reward)
                {
                    list.Add(new SeasonLvRewardItem{type = Convert.ToInt32(item.Key),amount = item.Value});
                }
                break;
            }
        }
        return list;
    }
    
    public List<SeasonLvRewardItem> GetNextReward()
    {
        int tempLayer = dataService.CollectLoveCardProgress.curLayer + 1;
        List<SeasonLvRewardItem> list = new List<SeasonLvRewardItem>();
        foreach (var VARIABLE in configService.CollectLoveCardConfig)
        {
            if(VARIABLE.Value.collectType != dataService.CollectLoveCardProgress.SubActivityType) continue;
            if (tempLayer == VARIABLE.Value.layer)
            {
                foreach (var item in VARIABLE.Value.Reward)
                {
                    list.Add(new SeasonLvRewardItem{type = Convert.ToInt32(item.Key),amount = item.Value});
                }
                break;
            }
        }
        return list;
    }

    public int GetAddCount()
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).state != ActivityState.underWay)
        {
            dataService.CollectLoveCardProgress.ResultAddCount = 0;
            return 0;
        }
        return dataService.CollectLoveCardProgress.ResultAddCount;
    }

    public Dictionary<int, List<SeasonLvRewardItem>> GetRewardConfig()
    {
        Dictionary<int, List<SeasonLvRewardItem>> list = new Dictionary<int, List<SeasonLvRewardItem>>();
        foreach (var VARIABLE in configService.CollectLoveCardConfig)
        {
            if(VARIABLE.Value.collectType != dataService.CollectLoveCardProgress.SubActivityType) continue;
            List<SeasonLvRewardItem> rewardList = new List<SeasonLvRewardItem>();
            foreach (var item in VARIABLE.Value.Reward)
            {
                rewardList.Add(new SeasonLvRewardItem {type = Convert.ToInt32(item.Key), amount = item.Value});
            }
            list.Add(VARIABLE.Value.layer,rewardList);
        }
        return list;
    }

    public bool CurIsMaxLayer()
    {
        if (dataService.CollectLoveCardProgress.curLayer >= GetRewardConfig().Count)
        {
            return true;
        }
        return false;
    }
    
    private void CheckReward()
    {
        if(CurIsMaxLayer()) return;
        int curLayer = dataService.CollectLoveCardProgress.curLayer;
        int getRewardLayer = dataService.CollectLoveCardProgress.getRewardLayer;
        int myCollectCount = dataService.CollectLoveCardProgress.collectCount;
        int progress = 0;
        bool isMax = false;
        foreach (var VARIABLE in configService.CollectLoveCardConfig)
        {
            if(VARIABLE.Value.collectType != dataService.CollectLoveCardProgress.SubActivityType) continue;
            progress = VARIABLE.Value.progress;
            if (progress > myCollectCount)
            {
                curLayer = VARIABLE.Value.layer - 1;
                break;
            }
            
            if (VARIABLE.Value.layer > getRewardLayer)
            {
                foreach (var item in VARIABLE.Value.Reward)
                {
                    dataService.CollectLoveCardProgress.readyGetRewardDic[item.Key] =
                        dataService.CollectLoveCardProgress.readyGetRewardDic.TryGetValue(item.Key,
                            out int existingValue)
                            ? existingValue + item.Value
                            : item.Value;
                }
            }
            if (VARIABLE.Value.layer == GetRewardConfig().Count)
            {
                isMax = true;
            }
        }
        dataService.CollectLoveCardProgress.getRewardCount = curLayer - getRewardLayer;
        if (isMax) curLayer = GetRewardConfig().Count + 1;
        dataService.CollectLoveCardProgress.SetCurLayer(curLayer);
        if (dataService.CollectLoveCardProgress.getRewardCount > 0)
        {
            var msg = new Dictionary<string, object>
            {
                {"layer", dataService.CollectLoveCardProgress.curLayer}
            };
            AnalyticUtils.ReportEvent(AnalyticsKey.CollectLoveCard_Progress, msg);
        }
    }

    public void CheckActivityCard(CardData cardData = null, Action action = null)
    {
        if(CurIsMaxLayer()) return;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).state != ActivityState.underWay) return;
        if (CardIsAdd(cardData)) return;
        int cardType = cardData.Value / Constants.ValueCardCount13; //0梅花♣  1爱心❤  2黑桃♠  3方块♦
        int cardType2 = cardData.Value2 / Constants.ValueCardCount13;
        bool isRed = false;
        bool isRed1 = false;
        bool isBlack = false;
        bool isBlack1 = false;

        if (cardData.CardType == CardType.Value)
        {
            isRed = cardType == 1 || cardType == 3;
            isBlack = cardType == 0 || cardType == 2;
        }
        if (cardData.CardType == CardType.TwoValue)
        {
            isRed = cardType == 1 || cardType == 3;
            isBlack = cardType == 0 || cardType == 2;
            isRed1 = cardType2 == 1 || cardType2 == 3;
            isBlack1 =  cardType2 == 0 || cardType2 == 2;
        }
        else if (cardData.CardType == CardType.Gold)
        {
            isRed = cardData.cm.suit == 1 || cardData.cm.suit == 3;
            isBlack = cardData.cm.suit == 0 || cardData.cm.suit == 2;
        }
        else if (cardData.CardType == CardType.Monochrome)
        {
            isRed = cardData.cm.suit == 1;
            isBlack = cardData.cm.suit == 0;
        }
        else
        {
            //return;
        }
        if ((dataService.CollectLoveCardProgress.SubActivityType == 1 && (isRed || isRed1)) || (dataService.CollectLoveCardProgress.SubActivityType == 2 && (isBlack || isBlack1)))
        {
            dataService.CollectLoveCardProgress.cardList.Add(cardData.id);
            dataService.CollectLoveCardProgress.ResultAddCount += GetPoint();
            action?.Invoke();
        }
    }
    
    public void ClearActivityCard(CardData cardData, Action action = null)
    {
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).state != ActivityState.underWay) return;
        if (cardData.cm.cardType != CardType.Value) return;
        if (CardIsAdd(cardData))
        {
            dataService.CollectLoveCardProgress.ResultAddCount -= GetPoint();
            dataService.CollectLoveCardProgress.cardList.Remove(cardData.id);
            action?.Invoke();
        }
    }
    
    public int GetPoint()
    {
        return 1 * dataService.NowBet * dataService.GetCollectBet();
    }

    //处理一下卡牌，避免撤回重复添加
    private bool CardIsAdd(CardData cardData)
    {
        if (dataService.CollectLoveCardProgress.cardList.Contains(cardData.id)) return true;
        return false;
    }

    public void CheckTriggerPopup()
    {
        if (dataService.CollectLoveCardProgress.PopBtn && ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).state == ActivityState.underWay)
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartCollectLoveCardPopup,BoxBuilder.ShowStartCollectLoveCardPopup);
            dataService.CollectLoveCardProgress.PopBtn = false;
        }
    }

    #region 活动结束，发放游戏奖励

    public void CheckGetReward()
    {
        if (dataService.CollectLoveCardProgress.readyGetRewardDic.Count > 0)
        {
            rewardDic = new Dictionary<int, int>(dataService.CollectLoveCardProgress.readyGetRewardDic);
            GameCommon.IsPlayingCollectAnim = true;
            if (rewardDic.Count > 1)
            {
                Observable.Timer(TimeSpan.FromSeconds(1.3f)).Subscribe(_ =>
                {
                    BoxBuilder.ShowRewardPop(rewardDic, PropChangeWay.CollectLoveCardReward, endCall: () =>
                        {
                            dataService.CollectLoveCardProgress.getRewardCount = 0;
                            TypeEventSystem.Send<TriggrePopupEvent>();
                        }, activityType: ActivityType.collectLoveCard);
                });
                TypeEventSystem.Send<PlayGetLoveCardReward>(new PlayGetLoveCardReward((int)PropEnum.Xishu,0,false));
            }
            else
            {
                int type = (int)PropEnum.Coin;
                int count = 0;
                foreach (var pair in rewardDic)
                {
                    type = pair.Key;
                    count = pair.Value;
                    dataService.AddProp(pair.Key,pair.Value,PropChangeWay.CollectLoveCardReward,Vector3.zero,false);
                }
                TypeEventSystem.Send<PlayGetLoveCardReward>(new PlayGetLoveCardReward(type,count,true));
            }
            dataService.CollectLoveCardProgress.readyGetRewardDic.Clear();
            ActivityManager.Instance.SaveActivityData();
        }
    }
    
    public void CheckFinishActivity()
    {
        ActivityManager.Instance.FinishGetReward(ActivityType.collectLoveCard);
    }
    #endregion
}