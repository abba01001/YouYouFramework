﻿using QFramework;
using SoliUtils;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;

public class RookieAnimItem : MonoBehaviour
{
    private Button bgBtn;
    private SkeletonAnimation skeletonAnimation;
    private GameObject obj;
    private int rookieId;
    private RookieAnimModel animModel;
    private int loopCount;

    private void Awake()
    {
        if(bgBtn != null)
        {
            return;
        }
        bgBtn = transform.Get<Button>("BgBtn");
        bgBtn.onClick.AddListener(OnClickBg);
    }

    private void OnClickBg()
    {
        OnEnd();
    }

    public void Show(int rookieId, RookieAnimModel animModel)
    {
        this.rookieId = rookieId;
        this.animModel = animModel;
        if (animModel.prefab == "GemStoneAnimItem")
        {
            obj = GameObjManager.Instance.PopGameObject(GameObjType.GemStoneAnimItem);
        }
        obj.transform.SetParent(transform);
        obj.transform.localPosition = new Vector3(0, 0, 0);
        obj.transform.localScale = Vector3.one;
        obj.SetActive(true);

        loopCount = 0;
        skeletonAnimation = obj.GetComponentInChildren<SkeletonAnimation>();
        // 播放动画
        skeletonAnimation.state.SetAnimation(0, animModel.animation, true);
        // 获取动画状态
        var animationState = skeletonAnimation.state.GetCurrent(0);

        // 设置动画完成事件的回调函数
        animationState.Complete += AnimationFinished;
    }

    private void OnEnd()
    {
        if(obj == null)
        {
            return;
        }
        GameObjManager.Instance.PushGameObject(obj);
        obj = null;
        if (skeletonAnimation != null)
        {
            var animationState = skeletonAnimation.state.GetCurrent(0);
            animationState.Complete -= AnimationFinished;
        }
        gameObject.SetActive(false);
        RookieTriggerEndEvent t = GameObjManager.Instance.PopClass<RookieTriggerEndEvent>(true);
        t.Init4(rookieId);
        TypeEventSystem.Send<RookieTriggerEndEvent>(t);
    }

    private void AnimationFinished(TrackEntry trackEntry)
    {
        // 动画播放完成后的操作
        Debug.Log("动画播放完成");
        loopCount++;
        if (animModel.loop_count == loopCount)
        {
            OnEnd();
        }
    }
}