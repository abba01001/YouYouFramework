using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using UniRx;
using System;
using QFramework;
using Doozy.Engine.UI;

public class RookieTipItem : MonoBehaviour
{
    [SerializeField] private RawImage maskImg;
    [SerializeField] private RawImage arrowImg;
    [SerializeField] private Text tipText;
    [SerializeField] private EyuThroughBtn closeBtn;
    [SerializeField] private RawImage touchImg;

    private void Awake()
    {
        Material material = new Material(maskImg.materialForRendering);
        maskImg.material = material;
    }

    public void Hide()
    {
        arrowImg.transform.DOKill();
        maskImg.gameObject.SetActive(false);
        arrowImg.gameObject.SetActive(false);
        maskImg.materialForRendering.DOFloat(1200, "_Radius", 0);

        UniRx.Observable.Timer(TimeSpan.FromSeconds(0.02f)).Subscribe(_ =>
        {
            gameObject.SetActive(false);
        });
    }

    public void Show(int rookieId, Vector2 pos, Rect touchRect, Action callback, bool force, float touchMaskTime)
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var rookieModel = configService.RookieClickConfig[rookieId];
        string tipstr = rookieModel.tipTranslateKey;

        touchImg.raycastTarget = true;
        maskImg.gameObject.SetActive(true);
        arrowImg.gameObject.SetActive(true);
        closeBtn.TouchRect = touchRect;
        closeBtn.IsForce = force;
        // Debug.Log($"========= force = {force} ");
        Action touchCallback = () =>
        {
            Hide();
            Vector2 _pos = Vector2.one;
            var clickPos = Input.mousePosition;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(UICanvas.MasterCanvas.Canvas.transform as RectTransform,
                clickPos, Camera.main, out _pos);
            RookieTriggerEndEvent t = GameObjManager.Instance.PopClass<RookieTriggerEndEvent>(true);
            t.Init(rookieId, _pos);
            TypeEventSystem.Send<RookieTriggerEndEvent>(t);
            callback?.Invoke();
        };
        GameCommon.HideRookieTipItem = touchCallback;
        transform.GetComponent<BoxCollider2D>().enabled = true;
        if (touchMaskTime > 0)
        {
            closeBtn.TouchRect = new Rect(0, 0, 0, 0);
            UniRx.Observable.Timer(TimeSpan.FromSeconds(touchMaskTime)).Subscribe(_ =>
            {
                if(touchRect != null)
                    closeBtn.TouchRect = touchRect;
                closeBtn.Callback = touchCallback;
                touchImg.raycastTarget = false;
            });
        }
        else
        {
            closeBtn.Callback = touchCallback;
            touchImg.raycastTarget = false;
        }

        Vector2 matPos;
        var screenpos = Camera.main.WorldToScreenPoint(pos);
        RectTransformUtility.ScreenPointToLocalPointInRectangle(UICanvas.MasterCanvas.Canvas.transform as RectTransform,
         screenpos, Camera.main, out matPos);
        maskImg.materialForRendering.DOFloat(1200, "_Radius", 0);
        maskImg.materialForRendering.DOFloat(rookieModel.view_size, "_Radius", 0.5f);
        maskImg.materialForRendering.DOVector(new Vector4(matPos.x, matPos.y, 0, 0), "_Center", 0);
        tipText.gameObject.SetActive(true);
        if (string.IsNullOrEmpty(tipstr))
            tipText.gameObject.SetActive(false);
        else
            tipText.text = tipstr;

        RePos(matPos, rookieModel.arrow_pos, rookieModel.view_size);
    }

    void RePos(Vector3 pos, int arrow_pos, int view_size)
    {
        var space = 50;
        var arrowSize = new Vector2(110, 160);
        var screenRect = GetComponent<RectTransform>().rect;
        pos.x = pos.x + screenRect.width/2;
        pos.y = pos.y + screenRect.height/2;
        var isTop = pos.y > screenRect.height / 3 * 2;
        var isBottom = pos.y < screenRect.height / 3;
        var isLeft = pos.x < screenRect.width / 3;
        var isRight = pos.x > screenRect.width / 3 * 2;
        var boxImg = tipText.transform.Find("BgImg");
        var boxWidth = boxImg.GetComponent<RectTransform>().rect.width;
        var boxHeight = boxImg.GetComponent<RectTransform>().rect.height;
        var HeadWidth = tipText.transform.Find("Image").GetComponent<RectTransform>().rect.width + 10;
        pos.x = pos.x - screenRect.width/2;
        pos.y = pos.y - screenRect.height/2;
        if (arrow_pos != 0)
        {
            if (arrow_pos == 2)
            {
                isTop = true;
                isBottom = false;
                isLeft = false;
                isRight = false;
            }
            else if (arrow_pos == 1)
            {
                isTop = false;
                isBottom = true;
                isLeft = false;
                isRight = false;
            }
            else if (arrow_pos == 4)
            {
                isTop = false;
                isBottom = false;
                isLeft = true;
                isRight = false;
            }
            else if (arrow_pos == 3)
            {
                isTop = false;
                isBottom = false;
                isLeft = false;
                isRight = true;
            }
        }
        if (isTop)
        {
            arrowImg.transform.localEulerAngles = new Vector3(0, 0, 90);
            arrowImg.transform.localPosition = new Vector3(pos.x, pos.y - arrowSize.y - view_size / 2, 0);
            tipText.transform.localPosition = new Vector3(pos.x, pos.y - space - arrowSize.y - boxHeight / 2 - view_size / 2, 0);
            arrowImg.transform.DOLocalMoveY(25, 0.5f).SetLoops(-1, LoopType.Yoyo).SetRelative(true).SetEase(Ease.OutQuad);
        }
        else if (isBottom)
        {
            arrowImg.transform.localEulerAngles = new Vector3(0, 0, -90);
            arrowImg.transform.localPosition = new Vector3(pos.x, pos.y + arrowSize.y + view_size / 2, 0);
            tipText.transform.localPosition = new Vector3(pos.x, pos.y + space + arrowSize.y + boxHeight / 2 + view_size / 2, 0);
            arrowImg.transform.DOLocalMoveY(-25, 0.5f).SetLoops(-1, LoopType.Yoyo).SetRelative(true).SetEase(Ease.OutQuad);
        }
        else if (isLeft)
        {
            arrowImg.transform.localEulerAngles = new Vector3(0, 0, 180);
            arrowImg.transform.localPosition = new Vector3(pos.x + arrowSize.x + view_size / 2, pos.y, 0);
            tipText.transform.localPosition = new Vector3(pos.x + space + arrowSize.x + boxWidth / 2 + view_size / 2 + HeadWidth, pos.y, 0);
            arrowImg.transform.DOLocalMoveX(-25, 0.5f).SetLoops(-1, LoopType.Yoyo).SetRelative(true).SetEase(Ease.OutQuad);
        }
        else if (isRight)
        {
            arrowImg.transform.localEulerAngles = new Vector3(0, 0, 0);
            arrowImg.transform.localPosition = new Vector3(pos.x - arrowSize.x - view_size / 2, pos.y, 0);
            tipText.transform.localPosition = new Vector3(pos.x - space - arrowSize.x - boxWidth / 2 - view_size / 2, pos.y, 0);
            arrowImg.transform.DOLocalMoveX(25, 0.5f).SetLoops(-1, LoopType.Yoyo).SetRelative(true).SetEase(Ease.OutQuad);
        }
        else
        {
            if (pos.x < 0)
            {
                arrowImg.transform.localEulerAngles = new Vector3(0, 0, 180);
                arrowImg.transform.localPosition = new Vector3(pos.x + arrowSize.x + view_size / 2, pos.y, 0);
                tipText.transform.localPosition = new Vector3(pos.x + space + arrowSize.x + boxWidth / 2 + view_size / 2 + HeadWidth, pos.y, 0);
                arrowImg.transform.DOLocalMoveX(-25, 0.5f).SetLoops(-1, LoopType.Yoyo).SetRelative(true).SetEase(Ease.OutQuad);
            }
            else
            {
                arrowImg.transform.localEulerAngles = new Vector3(0, 0, 0);
                arrowImg.transform.localPosition = new Vector3(pos.x - arrowSize.x - view_size / 2, pos.y, 0);
                tipText.transform.localPosition = new Vector3(pos.x - space - arrowSize.x - boxWidth / 2 - view_size / 2, pos.y, 0);
                arrowImg.transform.DOLocalMoveX(25, 0.5f).SetLoops(-1, LoopType.Yoyo).SetRelative(true).SetEase(Ease.OutQuad);
            }
        }

        var textRect = tipText.GetComponent<RectTransform>().rect;
        var boxPos = tipText.transform.localPosition;
        var boxSize = tipText.rectTransform.sizeDelta;
        if (boxPos.x - boxWidth / 2 - HeadWidth < -screenRect.width / 2)
        {
            var v = -screenRect.width / 2 - (boxPos.x - boxWidth / 2 - HeadWidth);
            if (isTop || isBottom)
            {
                var tipTextPos = tipText.transform.localPosition;
                tipTextPos.x += v;
                tipText.transform.localPosition = tipTextPos;
            }
            else
                tipText.rectTransform.sizeDelta = new Vector2(boxSize.x - v, boxSize.y);
        }
        if (boxPos.x + boxWidth / 2 > screenRect.width / 2)
        {
            var v = boxPos.x + boxWidth / 2 - screenRect.width / 2;
            if (isTop || isBottom)
            {
                var tipTextPos = tipText.transform.localPosition;
                tipTextPos.x -= v;
                tipText.transform.localPosition = tipTextPos;
            }
            else
                tipText.rectTransform.sizeDelta = new Vector2(boxSize.x - v, boxSize.y);
        }
        if (boxPos.y - boxHeight / 2 < -screenRect.height / 2)
        {
            var v = -screenRect.height / 2 - (boxPos.y - boxHeight / 2);
            tipText.rectTransform.sizeDelta = new Vector2(boxSize.x, boxSize.y - v);
        }
        if (boxPos.y + boxHeight / 2 > screenRect.height / 2)
        {
            var v = boxPos.y + boxHeight / 2 - screenRect.height / 2;
            tipText.rectTransform.sizeDelta = new Vector2(boxSize.x, boxSize.y - v);
        }
    }

}
