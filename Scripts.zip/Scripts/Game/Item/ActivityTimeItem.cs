using System;
using System.Collections;
using Activities;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class CountTimeData
{
    public DateTime startTime;
    public DateTime endTime;
    public Action endAction;
    public string endText;
    public void Clear()
    {
        startTime = ActivityManager.Instance.GetActivityNowDateTime();
        endTime = ActivityManager.Instance.GetActivityNowDateTime();
        endAction = null;
        endText = null;
    }
}


public class ActivityTimeItem : MonoBehaviour
{
    private Text timeText;
    private Image bg;
    private CountTimeData timeData;
    private bool isAwakeCompleted;
    public WaitForSeconds waitOneSecond;
    private bool EnableTimer;

    [SerializeField] public string Time;
    private void Awake()
    {
        timeText = transform.Get<Text>("Text");
        bg = transform.Get<Image>("Bg");
        waitOneSecond = new WaitForSeconds(1);
        isAwakeCompleted = true;
    }

    private void OnDisable()
    {
        EnableTimer = false;
    }

    public void SetStyle(string atlasName,string keyName)
    {
        bg.SetSpriteByAtlas(atlasName, keyName);
    }

    public void SetTimeData(CountTimeData _timeData)
    {
        timeData = _timeData;
        EnableTimer = false;
    }

    void Update()
    {
        if (!gameObject.activeInHierarchy || !gameObject.activeSelf)
        {
            return;
        }
        if (isAwakeCompleted && !EnableTimer && timeData != null)
        {
            EnableTimer = true;
            StopAllCoroutines();
            StartCoroutine(StartTimer());
        }
    }

    IEnumerator StartTimer()
    {
        if (this == null) yield break;
        TimeSpan timeDifference = timeData.endTime - timeData.startTime;
        long nowDiffTime = (long)timeDifference.TotalSeconds;
        if (nowDiffTime <= 0)
        {
            SetEndState();
            yield break;
        }
        while (nowDiffTime > 0)
        {
            timeText.text = GetTime(nowDiffTime);
            Time = $"{nowDiffTime / 60}分{nowDiffTime % 60}秒";;
            yield return waitOneSecond;
            nowDiffTime--;
        }
        timeData.endAction?.Invoke();
        SetEndState();
    }

    private string GetTime(long nowDiffTime)
    {
        string timeFormat = "";
        if (nowDiffTime >= 86400)
            timeFormat = $"{nowDiffTime / 86400}天{nowDiffTime % 86400 / 3600}时";
        else if (nowDiffTime >= 3600)
            timeFormat = $"{nowDiffTime / 3600}时{nowDiffTime % 3600 / 60}分";
        else if (nowDiffTime >= 60)
            timeFormat = $"{nowDiffTime / 60}分{nowDiffTime % 60}秒";
        else
            timeFormat = $"{nowDiffTime}秒";
        return timeFormat;
    }
    
    private void SetEndState()
    {
        timeText.text = timeData.endText ?? "";
    }
}
