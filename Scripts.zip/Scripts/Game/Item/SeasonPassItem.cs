using System;
using System.Collections.Generic;
using Activities;
using Coffee.UIExtensions;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class SeasonPassItem : ScrollItem
{
    private Transform freeItem;
    private GameObject freeItemGet;
    private GameObject freeItemUnGet;
    private GameObject freeItemGetBtn;
    
    private Transform chargeItem;
    private GameObject chargeItemGet;
    private GameObject chargeItemUnGet;
    private GameObject chargeItemGetBtn;
    
    [SerializeField] private GameObject rope;
    [SerializeField] private GameObject ropeEf;
    
    private Text levelText;
    private Image levelImage;
    private RectTransform fillImage;
    private GameObject propItem;
    private GameObject bar;

    private int curLevel = -1;
    private Transform rewardList;
    private Dictionary<int, GameObject> itemList = new Dictionary<int, GameObject>();
    private bool isAwakeCompleted = false;
    private bool isShaking = false;
    private IDataService dataService;
    public void Awake()
    {
        freeItem = transform.Find("FreeItem");
        freeItemGet = transform.Find("FreeItem/Lock/Get").gameObject;
        freeItemUnGet = transform.Find("FreeItem/Lock/UnGet").gameObject;
        freeItemGetBtn = transform.Find("FreeItem/GetBtn").gameObject;
        freeItemGetBtn.GetComponent<Button>().SetButtonClick(() => { GetReward(1);});
        
        chargeItem = transform.Find("ChargeItem");
        chargeItemGet = transform.Find("ChargeItem/Lock/Get").gameObject;
        chargeItemUnGet = transform.Find("ChargeItem/Lock/UnGet").gameObject;
        chargeItemGetBtn = transform.Find("ChargeItem/GetBtn").gameObject;
        chargeItemGetBtn.GetComponent<Button>().SetButtonClick(() => { GetReward(2);});
        chargeItem.Find("Lock/UnGet").GetComponent<Button>().SetButtonClick(ShakeLock);
        
        levelText = transform.Find("Level/Text").GetComponent<Text>();
        levelImage = transform.Find("Level").GetComponent<Image>();
        fillImage = transform.Find("FillAmount/Value").GetComponent<RectTransform>();
        isAwakeCompleted = true;
        if (curLevel != -1)
        {
            SetData(curLevel);
        }
    }

    public override void OnDataUpdate(object data, int index)
    {
        base.OnDataUpdate(data, index);
        SeasonPassModel model = data as SeasonPassModel;
        SetData(model.layer);
        gameObject.name = "Scroll" + (index < 10 ? "0" + index : index.ToString());
    }
    
    private void ShakeLock()
    {
        if(isShaking) return;
        GameUtils.PlayShakeAnim(chargeItem.Find("Lock/UnGet"), () => isShaking = true, () => isShaking = false);
    }
    
    public void SetData(int level)
    {
        curLevel = level;
        if (!isAwakeCompleted)
        {
            return;
        }
        ropeEf.SetActive(false);
        dataService = MainContainer.Container.Resolve<IDataService>();
        int layer = Math.Max(dataService.SeasonPassProgress.curLayer, 1);
        if (dataService.SeasonPassProgress.curLayer == 0 && level == 1)
        {
            rope.GetComponent<RectTransform>().anchoredPosition = new Vector2(-95, 2);
        }
        else
        {
            rope.GetComponent<RectTransform>().anchoredPosition = new Vector2(82, 2);
        }
        rope.SetActive(layer == level);
        levelText.text = level.ToString();

        UpdatProgress(level);
        UpdateFreeItem(level);
        UpdateChargeItem(level);
        InitItem(transform.Find("FreeItem"),level);
        InitItem(transform.Find("ChargeItem"),GetChargeIndex(level));
    }

    private int GetChargeIndex(int index)
    {
        Dictionary<int, SeasonPassModel>  list = ActivityManager.Instance.SeasonPassActivity.GetConfig();
        int rewardCount = 0;
        foreach (var VARIABLE in list)
        {
            if (VARIABLE.Value.type == 1)
            {
                rewardCount++;
            }
        }
        return rewardCount + index;
    }
    
    private void InitItem(Transform itemTrans,int index)
    {
        ActivityManager.Instance.SeasonPassActivity.GetConfig().TryGetValue(index, out SeasonPassModel model);
        if(model == null) return;
        Dictionary<int, int> reward = GameUtils.AnalysisPropString(model.reward);
        foreach (var pair in reward)
        {
            var icon = itemTrans.Find("PropItem/PropImage").GetComponent<Image>();
            GameUtils.LoadPropSprite(icon,pair.Key);
            itemTrans.Get<Transform>("PropItem/PropImage").localScale = 1.5f * Vector3.one;
            itemTrans.Find("PropItem/NumText").GetComponent<Text>().text = "";
            itemTrans.Get<Text>($"PropItem/NumText").text = GameUtils.GetItemCountText(pair.Key, pair.Value);
            break;                
        }
    }

    public void ShowRopeCloseAnim(float delay)
    {
        fillImage.localScale = new Vector3(0, 1, 1);
        rope.gameObject.SetActive(false);
        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(delay);
        seq.Insert(delay, levelImage.transform.DOScale(Vector3.one * 1.2f, 0.2f));
        seq.Insert(delay + 0.1f, levelImage.transform.DOScale(Vector3.one, 0.2f));
        seq.AppendCallback(() =>
        {
            rope.gameObject.SetActive(true);
            GameUtils.PlayAnimation(rope.GetComponent<Animator>(), "ani_Rope_Close", 0);
            fillImage.DOScaleX(ActivityManager.Instance.SeasonPassActivity.GetRatio(), 0.5f);
        });
    }

    public void ShowRopeOpenAnim()
    {
        fillImage.localScale = new Vector3(0, 1, 1);
        fillImage.DOScaleX(1, 1f);
        rope.gameObject.SetActive(true);
        Observable.NextFrame().Subscribe(_ =>
        {
            GameUtils.PlayAnimation(rope.GetComponent<Animator>(), "ani_Rope_Open", 0, () =>
            {
                rope.gameObject.SetActive(false);
            });
        });
    }

    void UpdatProgress(int level)
    {
        bool smallLayer = level < dataService.SeasonPassProgress.curLayer;
        bool bigLayer = level > dataService.SeasonPassProgress.curLayer;
        bool curLayer = level == dataService.SeasonPassProgress.curLayer;
        if (smallLayer)
        {
            fillImage.localScale = Vector3.one;
        } 
        else if (bigLayer)
        {
            fillImage.localScale = new Vector3(0,1,1);
        }else if (curLayer)
        {
            fillImage.localScale = new Vector3(ActivityManager.Instance.SeasonPassActivity.GetRatio(), 1, 1);
        }
    }

    void UpdateFreeItem(int level)
    {
        //0未解锁，1解锁待领取，2已领取
        int status = dataService.SeasonPassProgress.freeLayerRewardFlag[level];
        freeItemUnGet.GetComponent<CanvasGroup>().alpha = 0;
        freeItemGet.GetComponent<CanvasGroup>().alpha = status == 2 ? 1 : 0;
        freeItemGetBtn.SetActive(status == 1);
        if (status == 0)
        {
            levelImage.SetSpriteByAtlas(Constants.AtlasNamePath.SeasonPassAtlas, "pass_12", false);
        }
        else if (status == 1)
        {
            levelImage.SetSpriteByAtlas(Constants.AtlasNamePath.SeasonPassAtlas, "pass_10", false);
        }
        else
        {
            levelImage.SetSpriteByAtlas(Constants.AtlasNamePath.SeasonPassAtlas, "pass_11", false);
            levelText.text = "";
        }
        SetGray(freeItem,status == 2);
    }

    void SetGray(Transform trans,bool isGray)
    {
        foreach (var pair in trans.GetComponentsInChildren<UIEffect>())
        {
            pair.effectFactor = isGray ? 1 : 0;
        }
    }
    
    void UpdateChargeItem(int level)
    {
        int status = dataService.SeasonPassProgress.chargeLayerRewardFlag[level];
        chargeItemUnGet.GetComponent<CanvasGroup>().alpha = !dataService.SeasonPassProgress.IsPaid ? 1 : 0;
        chargeItemGet.GetComponent<CanvasGroup>().alpha = status == 2 ? 1 : 0;
        chargeItemGetBtn.SetActive(status == 1);
        
        if (!dataService.SeasonPassProgress.IsPaid)
        {
            chargeItemGet.GetComponent<CanvasGroup>().alpha = 0;
            chargeItemGetBtn.SetActive(false);
        }
        SetGray(chargeItem,status == 2);
    }
    void GetReward(int type)
    {
        if(type == 2 && !dataService.SeasonPassProgress.IsPaid) return;
        SeasonPassModel model = ActivityManager.Instance.SeasonPassActivity.GetLayerModel(type,curLevel);
        if (model != null)
        {
            ActivityManager.Instance.SeasonPassActivity.CheckGetReward(model,() =>
            {
                if(type == 1) freeItemGetBtn.SetActive(false);
                if(type == 2) chargeItemGetBtn.SetActive(false);
                SetData(curLevel);
            });
        }
    }
}
