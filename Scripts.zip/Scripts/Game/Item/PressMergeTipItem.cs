﻿using DG.Tweening;
using SoliUtils;
using UnityEngine;
using UnityEngine.UI;

public class PressMergeTipItem : MonoBehaviour
{
    public enum Step
    {
        step1,
        step2
    }
    private PressBehaviour _pressBehaviour;
    private Transform _barContaniner;
    private Transform _btnContainer;
    private Image _barImage;
    private Image _bg;
    private Button _bgBtn;
    private Button _btn1;
    private Button _btn2;
    private Step _step = Step.step1;
    private Sequence _sequence;
    private MergeItem _item;
    private void Awake()
    {
        _bgBtn = transform.Get<Button>("BgBtn");
        _barContaniner = transform.Find("BarContainer");
        _btnContainer = transform.Find("BtnContainer");
        _barImage = _barContaniner.Get<Image>("Bar");

        Transform container = _btnContainer.Find("Container");
        _bg = container.Get<Image>("Bg");
        _btn1 = container.Get<Button>("Btn1");
        _btn2 = container.Get<Button>("Btn2");
        _btn1.onClick.AddListener(OnClickBtn1);
        _btn2.onClick.AddListener(OnClickBtn2);
        _bgBtn.onClick.AddListener(OnClickBgBtn);
    }

    private void OnClickBtn1()
    {
        Hidden();
        BoxBuilder.ShowDeleteMergeItemPopup(_item);
    }

    private void OnClickBtn2()
    {
        Hidden();
        BoxBuilder.ShowIllustratedGuidePopup();
    }

    private void OnClickBgBtn()
    {
        Hidden();
    }



    public void Show(MergeItem item)
    {
        _item = item;
        gameObject.SetActive(true);
        _bgBtn.gameObject.SetActive(false);
        _pressBehaviour = item.gameObject.GetComponent<PressBehaviour>();
        if (_pressBehaviour == null)
        {
            _pressBehaviour = item.gameObject.AddComponent<PressBehaviour>();
        }
        _pressBehaviour.Init(this);
        Vector3 itemPos = item.transform.position;
        _barContaniner.transform.position = new Vector2(itemPos.x, itemPos.y);
        _btnContainer.transform.position = new Vector2(itemPos.x, itemPos.y);

        _sequence = PlayStep1();
        _sequence.OnComplete(() =>
        {
            PlayStep2();
        });
        _sequence.Play();
    }

    public void Hidden()
    {
        gameObject.SetActive(false);
    }

    public void Release()
    {
        if (_step == Step.step1)
        {
            _sequence.Kill(false);
            Hidden();
        }
    }


    private Sequence PlayStep1()
    {
        _step = Step.step1;
        _barContaniner.gameObject.SetActive(false);
        _btnContainer.gameObject.SetActive(false);
        Sequence sequence = DOTween.Sequence();
        sequence.AppendInterval(0.2f);
        sequence.AppendCallback(() =>
        {
            _barContaniner.gameObject.SetActive(true);
            _barImage.fillAmount = 0;
        });
        Tween tween = DOTween.To(() => _barImage.fillAmount, value => _barImage.fillAmount = value, 1, 1.2f).SetEase(Ease.Linear);
        sequence.Append(tween);
        sequence.SetAutoKill(true);
        return sequence;
    }


    private void PlayStep2()
    {
        _step = Step.step2;
        _barContaniner.gameObject.SetActive(false);
        _btnContainer.gameObject.SetActive(true);
        _btn1.gameObject.SetActive(false);
        _btn2.gameObject.SetActive(false);
        _bg.fillAmount = 0;
        Tween tween = DOTween.To(() => _bg.fillAmount, value => _bg.fillAmount = value, 1, 0.3f).SetEase(Ease.Linear);
        tween.OnComplete(()=> 
        {
            _btn1.gameObject.SetActive(true);
            _btn2.gameObject.SetActive(true);
            _bgBtn.gameObject.SetActive(true);
        });
    }
    


    public class PressBehaviour : MonoBehaviour
    {
        private PressMergeTipItem tipItem;
        private Vector3 initPos;
        public void Init(PressMergeTipItem tipItem)
        {
            this.tipItem = tipItem;
            initPos = transform.position;
        }
        void OnMouseUp()
        {
            CheckRelease();
        }

        private void Update()
        {
            if (tipItem == null)
            {
                return;
            }
            if(transform.position != initPos)
            {
                CheckRelease();
            }

        }

        private void CheckRelease()
        {
            if (tipItem != null)
            {
                tipItem.Release();
                tipItem = null;

            }
        }





    }


}