using System;
using System.Collections.Generic;
using Activities;
using Coffee.UIExtensions;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class AdRewardItem : ViewBase
{

    Dictionary<int, GameObject> itemList = new Dictionary<int, GameObject>();
    private bool isAwakeCompleted = false;
    private int curIndex;
    protected override void OnAwake()
    {
        isAwakeCompleted = true;
        transform.Get<Button>("Btn").SetButtonClick(() =>
        {
            ActivityManager.Instance.AdRewardActivity.CheckGetReward(curIndex);
        });
        SetData(curIndex);
    }


    public void SetData(int index)
    {
        curIndex = index;
        if (!isAwakeCompleted) return;
        configService.AdRewardConfig.TryGetValue(index, out AdRewardModel model);
        if(model == null) return;
        foreach (var pair in GameUtils.AnalysisPropString(model.reward))
        {
            int propCount = pair.Value;
            Image propImage = transform.Get<Image>("PropItem/PropImage");
            Text timeText = transform.Get<Text>("PropItem/TimeText");
            Text numText = transform.Get<Text>("PropItem/NumText");
            numText.text = "";
            timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                long infiniteTime = propCount;
                timeText.text = infiniteTime / 60 + "m";
            }
            else
            {
                numText.text = pair.Key == (int)PropEnum.Coin ? propCount.ToString() : $"x{propCount}";
            }
            propImage.LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : pair.Key);
            break;
        }
        transform.Get<Transform>("Get").gameObject.SetActive(index <= dataService.AdRewardProgress.curLayer);
        transform.Get<Transform>("Btn").gameObject.SetActive(index > dataService.AdRewardProgress.curLayer);
        SetGray(curIndex > dataService.AdRewardProgress.curLayer + 1);
    }

    private void SetGray(bool isGray)
    {
        transform.Get<UIEffect>("Btn/Icon").effectFactor = isGray ? 1 : 0;
        transform.Get<UIEffect>("Btn").effectFactor = isGray ? 1 : 0;
        transform.Get<Image>("Progress/Value").fillAmount = curIndex > dataService.AdRewardProgress.curLayer ? 0 : 1;
        //transform.Get<Text>("Btn/Text").color = isGray ? Color.gray : Color.white;
    }

}
