using Activities;
using Coffee.UIExtensions;
using DG.Tweening;
using Doozy.Engine.UI;
using SoliUtils;
using System;
using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class IllustratedPieceItem : MonoBehaviour
{
    public List<Sprite> bgSprites;
    private Image _bg;
    private Image _icon;
    private Text _levText;
    private GameObject _arrowGO;
    private Image _signImage;
    private GameObject _rewardGO;
    private Animator _rewardAnimator;
    private GameObject _rewardEffect;
    private GameObject _rewardImage;
    private bool _inited;
    private IDataService _dataService;
    private MergeItemConfig _config;
    private bool _isLast;
    private bool _clickAble;
    private int _lev;

    private void Awake()
    {
        
    }

    private void Init()
    {
        if (_inited)
        {
            return;
        }
        _inited = true;
        _dataService = MainContainer.Container.Resolve<IDataService>();
        _bg = transform.Get<Image>("Bg");
        _icon = transform.Get<Image>("Icon");
        _levText = transform.Get<Text>("LevText");
        _arrowGO = transform.Find("Arrow").gameObject;
        _signImage = transform.Get <Image>("Sign");
        _rewardGO = transform.Find("Reward").gameObject;
        _rewardGO.GetComponent<SpriteRenderer>().sortingOrder = IllustratedGuideView.Instance.sortingOrder;
        _rewardGO.GetComponent<Button>().onClick.AddListener(OnClickReward);
        _rewardAnimator = _rewardGO.transform.Get<Animator>("bone_1");
        _rewardEffect = _rewardGO.transform.Find("bone_1/bone_baodian_01").gameObject;
        _rewardEffect.GetComponent<SortingGroup>().sortingOrder = IllustratedGuideView.Instance.sortingOrder+1;
        _rewardImage = _rewardGO.transform.Find("bone_1/Image").gameObject;

    }

    private void OnClickReward()
    {
        if (CanReward && _clickAble)
        {
            _clickAble = false;
            _rewardAnimator.Play("ani_Canvas_MyPopupCanvas_Reward02");
            _rewardEffect.SetActive(true);
            Sequence mySequence = DOTween.Sequence();
            mySequence.AppendInterval(0.45f);
            mySequence.AppendCallback(() =>
            {
                long oldCoin = _dataService.Coin;
                _rewardImage.SetActive(false);
                ActivityManager.Instance.IllustratedGuideActivity.DoGetReward(_config);
                long newCoin = _dataService.Coin;
                if (newCoin > oldCoin)
                {
                    IllustratedGuideView.Instance.PlayGoldAnim(_rewardGO.transform, oldCoin, newCoin);
                }
                UpdateItem();
            });
            mySequence.Play();
        }
    }


    public void SetConfig(MergeItemConfig config,int lev,bool isLast)
    {
        Init();
        _lev = lev;
        _config = config;
        _isLast = isLast;
        //_levText.text = config.name;
        _levText.text = lev + "��";
        LoadIcon(config.id);

        UpdateItem();
    }

    private void UpdateItem()
    {
        bool isNoneState = IsNoneState;
        _signImage.gameObject.SetActive(isNoneState);
        if (_isLast)
        {
            _bg.sprite = bgSprites[1];
            _arrowGO.SetActive(false);
            SetSignGray(false);
        }
        else
        {
            _bg.sprite = bgSprites[0];
            _arrowGO.SetActive(true);
            SetSignGray(isNoneState);
        }
        _bg.SetNativeSize();
        SetIconGray(isNoneState);
        _rewardGO.SetActive(CanReward);
        if (CanReward)
        {
            _clickAble = true;
            _rewardImage.SetActive(true);
            _rewardAnimator.Play("ani_Canvas_MyPopupCanvas_Reward01");
            _rewardEffect.SetActive(false);
        }
        _icon.gameObject.SetActive(!CanReward);
    }

    private bool CanReward
    {
        get
        {
            return (MergeItemState)_dataService.GetMergeItemState(_config.id) == MergeItemState.CanReward;
        }
    }

    private bool IsNoneState
    {
        get
        {
            return (MergeItemState)_dataService.GetMergeItemState(_config.id) == MergeItemState.None;
        }
    }


    private void LoadIcon(int itemId)
    {
        _icon.LoadPropSprite(itemId, true, () =>
        {
            float maxHeight = 130;
            float maxWidth = 130;
            if (_lev <= 3)
            {
                maxHeight = 100;
                maxWidth = 100;
            }
            float originalWidth = _icon.sprite.rect.width;
            float originalHeight = _icon.sprite.rect.height;
            float aspectRatio = originalWidth / originalHeight;
            float newWidth;
            float newHeight;
            float scaleHeight = maxHeight / originalHeight;
            float scaleWidth = maxWidth / originalWidth;
            float scale = Mathf.Min(scaleHeight, scaleWidth);

            scale = Mathf.Clamp(scale, 0, 1.3f);

            newHeight = originalHeight * scale;
            newWidth = originalWidth * scale;
            _icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
        });
    }



    private void SetIconGray(bool isGray)
    {
        _icon.GetComponent<UIEffect>().effectFactor = isGray ? 1 : 0;
        _arrowGO.GetComponent<UIEffect>().effectFactor = isGray ? 1 : 0;
    }

    private void SetSignGray(bool isGray)
    {
        if (isGray)
        {
            _signImage.color = new Color(253f / 255f, 248f / 255f, 244f / 255f);
        }
        else
        {
            _signImage.color = new Color(252f / 255f, 228f / 255f, 43f / 255f);
        }
        
    }

    
}
