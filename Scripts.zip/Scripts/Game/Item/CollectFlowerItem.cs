using System;
using System.Collections;
using System.Collections.Generic;
using Activities;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class CollectFlowerItem : MonoBehaviour
{
    private int cupCount;// 奖杯数
    private int coinCount;// 金币数
    private int rank;// 排名
    private string name;//名字

    private Image bg;
    private Image levelIcon;
    private RectTransform levelIconRect;
    private Image headIcon;
    private Text levelText;
    private Text nameText;
    private Text flowerText;
    private Transform reward;
    private Button getbtn;

    private Transform parent;
    private bool isAwakeCompleted = false;
    private void Awake()
    {
        if (!isAwakeCompleted)
            InitRes();
    }

    void InitRes(CollectFlowerData collectFlowerData = null)
    {
        getbtn = transform.Get<Button>("GetBtn");
        getbtn.gameObject.SetActive(false);
        getbtn.SetButtonClick(() =>
        {
            //领取奖励
            var dataService = MainContainer.Container.Resolve<IDataService>();
            if (ActivityManager.Instance.GetActivitySeverTime() >= dataService.CollectFlowerProgress.ActivityEndTime && !dataService.CollectFlowerProgress.FinishGetReward)
            {
                ActivityManager.Instance.CollectFlowerActivity.CheckFinishActivity();
            }
            getbtn.gameObject.SetActive(false);
        });
        bg = transform.Get<Image>("Bg");
        nameText = transform.Get<Text>("Name");
        levelIcon = transform.Get<Image>("LevelIcon");
        levelIconRect = levelIcon.GetComponent<RectTransform>();
        headIcon = transform.Get<Image>("HeadIcon/Image");
        levelText = transform.Get<Text>("LevelIcon/Text");
        flowerText = transform.Get<Text>("Flower/NumText");
        reward = transform.Get<Transform>("PropImage");
        reward.GetComponent<Button>().SetButtonClick(() =>
        {
            GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                .ShowItem(TextAnchor.LowerCenter, reward.GetComponent<Transform>(), Vector2.zero,ActivityManager.Instance.CollectFlowerActivity.GetReward());
        });
        isAwakeCompleted = true;
        if (collectFlowerData != null && parent != null) SetData(parent,collectFlowerData);
    }

    private void CheckShowGetBtn()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        if (ActivityManager.Instance.GetActivitySeverTime() >= dataService.CollectFlowerProgress.ActivityEndTime && !dataService.CollectFlowerProgress.FinishGetReward)
        {
            getbtn.gameObject.SetActive(dataService.CollectFlowerProgress.GetMyData().curRank == 0);
        }
    }
    
    public void SetData(Transform parentTrans,CollectFlowerData collectFlowerData)
    {
        parent = parentTrans;
        if (!isAwakeCompleted) InitRes(collectFlowerData);
        getbtn.gameObject.SetActive(false);
        var dataService = MainContainer.Container.Resolve<IDataService>();
        // nameText.text = GameUtils.GetRobotInfo(collectFlowerData.robotId).name;
        if (string.IsNullOrEmpty(collectFlowerData.name))
        {
            var id = GameUtils.GetRandomRobotID();
            collectFlowerData.name = GameUtils.GetRobotInfo(id).name;
        }
        nameText.text = collectFlowerData.name;
        flowerText.text = collectFlowerData.flowerCount.ToString();
        
        rank = collectFlowerData.curRank;
        if (rank <= 2)
        {
            levelIcon.enabled = true;
            levelText.text = "";
            levelIcon.SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectFlowerAtlas, "hd_pm_" + (rank + 1));
        }
        else
        {
            levelIcon.enabled = false;
            levelText.text = (rank + 1).ToString();
        }
        
        if (rank == dataService.CollectFlowerProgress.GetMyData().curRank)
        {
            headIcon.SetSpriteByAtlas(Constants.AtlasNamePath.TextureCommonAtlas, "defaultIcon", false);
            WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
            {
                if (ret)
                {
                    nameText.text = dataService.UserName;
                    var tex = SpriteUtils.ReadTexture(filePath);
                    if (tex != null)
                    {
                        headIcon.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                    }
                }
            });
        }
        else
        {
            SpriteUtils.SetRobotSpriteByIndex(headIcon,collectFlowerData.headIconIndex);
        }

        levelIconRect.anchoredPosition = rank == 0 ? new Vector2(18.2f, -7.8f) : new Vector2(28f, -7.8f);
        bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectFlowerAtlas,
    collectFlowerData.name == dataService.CollectFlowerProgress.GetMyData().name ? "hdlb_1" : "hdlb_2", false);
        reward.gameObject.SetActive(rank == 0);
        if (rank == 0 && dataService.CollectFlowerProgress.GetMyData().curRank == rank)
        {
            CheckShowGetBtn();
        }
    }
}
