using Doozy.Engine.UI;
using Model;
using SoliUtils;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class IllustratedGoodsItem:MonoBehaviour
{
    [SerializeField] private List<Sprite> _itemBgList;
    private bool _inited;
    private RectTransform _rectTransform;
    private RectTransform _bgRectTransform;
    private Text _nameText;
    private Transform _grid;
    private Transform _piecePrefab;
    private List<IllustratedPieceItem> _itemList = new List<IllustratedPieceItem>();
    public void Init()
    {
        if (_inited)
        {
            return;
        }
        _inited = true;
        _rectTransform = gameObject.GetComponent<RectTransform>();
        _bgRectTransform = transform.Get<RectTransform>("Bg");
        _nameText = transform.Get<Text>("NameBg/NameText");
        _grid = transform.Find("Grid");
        _piecePrefab = _grid.Find("PieceItem");
        IllustratedPieceItem pieceItem = _piecePrefab.gameObject.AddComponent<IllustratedPieceItem>();
        pieceItem.bgSprites = _itemBgList;
        _itemList.Add(pieceItem);
    }

    public void SetAnchoredPosition(Vector3 pos)
    {
        _rectTransform.anchoredPosition3D = pos;
    }

    

    public void SetData(MergeIllustratedData data)
    {
        _nameText.text = data.config.name;


        int lineCount = Mathf.CeilToInt(data.pieceConfigs.Count / 5f);
        int bgHeight = 250 + (lineCount - 1) * 200;
        Vector2 sizeDelta = _bgRectTransform.sizeDelta;
        sizeDelta.y = bgHeight;
        _bgRectTransform.sizeDelta = sizeDelta;
        ShowPieceCount(data.pieceConfigs.Count);
        for (int i = 0; i < data.pieceConfigs.Count; i++)
        {
            MergeItemConfig config = data.pieceConfigs[i];
            IllustratedPieceItem item = _itemList[i];
            item.SetConfig(config,i+1, i == data.pieceConfigs.Count - 1);
        }
    }



    private void ShowPieceCount(int count)
    {
        int createCount = count - _itemList.Count;
        if (createCount > 0)
        {
            for(int i=0;i< createCount; i++)
            {
                Transform itemTransform = Transform.Instantiate(_piecePrefab, _piecePrefab.parent);
                IllustratedPieceItem pieceItem = itemTransform.gameObject.GetComponent<IllustratedPieceItem>();
                _itemList.Add(pieceItem);
            }
        }
        for(int i=0;i< _itemList.Count; i++)
        {
            _itemList[i].gameObject.SetActive(i < count);
        }
    }
}
