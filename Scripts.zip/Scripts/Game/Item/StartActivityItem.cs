using System;
using System.Collections;
using System.Collections.Generic;
using Activities;
using DG.Tweening;
using Model;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class StartActivityItem : MonoBehaviour
{
    private List<Transform> itemList = new List<Transform>();
    private bool IsAwakeComplete = false;
    private Button EnterBtn;
    private Image BG1;
    private Image BG2;
    IDataService dataService;
    private ActivityType _activityType = ActivityType.none;
    private void Awake()
    {
        IsAwakeComplete = true;
        dataService = MainContainer.Container.Resolve<IDataService>();
        EnterBtn = transform.Get<Button>("EnterBtn");
        BG1 = transform.Get<Image>("BG1");
        BG2 = transform.Get<Image>("BG2");
    }

    private void OnEnable()
    {
        TypeEventSystem.Register<RefreshActivityTimer>(UpdateItem);
    }

    private void OnDisable()
    {
        TypeEventSystem.UnRegister<RefreshActivityTimer>(UpdateItem);
    }

    public void SetActivityType(ActivityType activityType)
    {
        _activityType = activityType;
    }
    
    public void UpdatePanel()
    {
        if(!IsAwakeComplete) return;
        UpdateItem();
    }

    public void PlayAnim()
    {
        if(!IsAwakeComplete) return;
        // foreach (var item in itemList)
        // {
        //     item.GetComponent<DOTweenAnimation>().DORestart();
        // }
    }
    
    private void UpdateItem(RefreshActivityTimer obj = null)
    {
        transform.Get<Text>("Title").text = "";
        
        var limitPk = transform.Get<Transform>("LimitPk");
        var lava = transform.Get<Transform>("Lava");
        var flower = transform.Get<Transform>("Flower");
        var levelPass = transform.Get<Transform>("LevelPass");
        
        limitPk.gameObject.MSetActive(_activityType == ActivityType.limitPk);
        lava.gameObject.MSetActive(_activityType == ActivityType.lavaPass);
        flower.gameObject.MSetActive(_activityType == ActivityType.collectFlower);
        levelPass.gameObject.MSetActive(_activityType == ActivityType.levelPass);

        string bg1 = "";
        string bg2 = "";
        string title = "";
        if (_activityType == ActivityType.collectFlower)
        {
            bg1 = "kstc_hdnew_3";
            bg2 = "kstc_hdnew_3_1";
            if (ActivityManager.Instance.CollectFlowerActivity.IsOpenActivity()) bg2 = "kstc_hdnew_3_2";
            title = "鲜花赛";
            InitCollectFlower(flower);
        }
        else if (_activityType == ActivityType.limitPk)
        {
            bg1 = "kstc_hdnew_1";
            bg2 = "kstc_hdnew_1_1";
            title = "拳击比赛";
            InitLimitPk(limitPk);
        }
        else if (_activityType == ActivityType.levelPass)
        {
            bg1 = "kstc_hdnew_4";
            bg2 = "kstc_hdnew_4_1";
            if (ActivityManager.Instance.LevelPassActivity.IsOpenActivity()) bg2 = "kstc_hdnew_4_2";
            title = "龙舟赛";
            InitLevelPass(levelPass);
        }
        else if (_activityType == ActivityType.lavaPass)
        {
            bg1 = "kstc_hdnew_2";
            bg2 = "kstc_hdnew_2_1";
            if (ActivityManager.Instance.LavaPassActivity.IsOpenActivity()) bg2 = "kstc_hdnew_2_2";
            title = "熔岩比赛";
            InitLavaPass(lava);
        }
        transform.Get<Text>("Title").text = title;
        BG1.SetSpriteByAtlas(Constants.AtlasNamePath.StartPageAtlas, bg1, true);
        BG2.SetSpriteByAtlas(Constants.AtlasNamePath.StartPageAtlas, bg2, true);
        RefreshTimer();
    }

    private void RefreshTimer()
    {
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(_activityType);
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>(true);
        timeData.Clear();
        timeData.endText = model.state is ActivityState.finished ? "结束" : model.state is ActivityState.waitFinished ? "结束" : null;
        if (model.state is ActivityState.waitEntry)
        {
            timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(_activityType).ActivityBigEndTime);
        }
        BaseActivityData data = model.localData as BaseActivityData;
        if (model.state is ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(data.ActivityEndTime);
        }
        transform.Get<ActivityTimeItem>("ActivityTimeItem").SetTimeData(timeData);
    }

    private void InitCollectFlower(Transform item)
    {
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower);
        var panel = item.Get<Transform>("Panel").gameObject;
        if (model.state == ActivityState.underWay || model.state == ActivityState.waitFinished)
        {
            EnterBtn.gameObject.SetActive(false);
            panel.gameObject.MSetActive(true);
            foreach (var data in dataService.CollectFlowerProgress.GetRankData())
            {
                var obj = panel.transform.GetChild(data.curRank);
                var headIcon = obj.Get<Image>("HeadIcon/Image");
                var levelIcon = obj.Get<Image>("LevelIcon");
                var levelText = levelIcon.transform.Get<Text>("Text");
                var numText = obj.Get<Text>("Text/NumText");
                var isMine = data.curRank == dataService.CollectFlowerProgress.GetMyData().curRank;
                numText.text = data.flowerCount.ToString();
                if (obj)
                {
                    obj.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.StartPageAtlas,isMine ? "kstc_hdnew_3_3" : "kstc_hdnew_3_4");
                }

                if (isMine)
                {
                    headIcon.SetSpriteByAtlas(Constants.AtlasNamePath.TextureCommonAtlas, "defaultIcon", false);
                    WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
                    {
                        if (ret)
                        {
                            var tex = SpriteUtils.ReadTexture(filePath);
                            if (tex != null)
                            {
                                headIcon.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                            }
                        }
                    });
                }
                else
                {
                    SpriteUtils.SetRobotSpriteByIndex(headIcon,data.headIconIndex);
                }
                if (data.curRank <= 2)
                {
                    levelIcon.enabled = true;
                    levelText.text = "";
                    levelIcon.SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectFlowerAtlas, "hd_pm_" + (data.curRank + 1));
                }
                else
                {
                    levelIcon.enabled = false;
                    levelText.text = (data.curRank + 1).ToString();
                }
            }
        }
        else
        {
            EnterBtn.gameObject.SetActive(true);
            panel.gameObject.MSetActive(false);
        }

        EnterBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowStartCollectFlowerPopup();
        });
        // item.GetComponent<Button>().SetButtonClick(() =>
        // {
        //     if (ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state == ActivityState.underWay)
        //     {
        //         BoxBuilder.ShowLevelPassPopup();
        //     }
        // });
    }

    private void InitLevelPass(Transform item)
    {
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.levelPass);
        var panel = item.Get<Transform>("Panel").gameObject;
        if (model.state == ActivityState.underWay || model.state == ActivityState.waitFinished)
        {
            EnterBtn.gameObject.SetActive(false);
            panel.gameObject.MSetActive(true);
            foreach (var data in dataService.LevelPassProgress.GetRankData())
            {
                var obj = panel.transform.GetChild(data.curRank);
                var headIcon = obj.Get<Image>("HeadIcon/Image");
                var levelIcon = obj.Get<Image>("LevelIcon");
                var levelText = levelIcon.transform.Get<Text>("Text");
                var numText = obj.Get<Text>("Text/NumText");
                var isMine = data.curRank == dataService.LevelPassProgress.GetMyData().curRank;
                numText.text = data.successVictory.ToString();
                if (obj)
                {
                    obj.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.StartPageAtlas,isMine ? "kstc_hdnew_3_3" : "kstc_hdnew_3_4");
                }

                if (isMine)
                {
                    headIcon.SetSpriteByAtlas(Constants.AtlasNamePath.TextureCommonAtlas, "defaultIcon", false);
                    WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
                    {
                        if (ret)
                        {
                            var tex = SpriteUtils.ReadTexture(filePath);
                            if (tex != null)
                            {
                                headIcon.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                            }
                        }
                    });
                }
                else
                {
                    SpriteUtils.SetRobotSpriteByIndex(headIcon,data.headIconIndex);
                }
                if (data.curRank <= 2)
                {
                    levelIcon.enabled = true;
                    levelText.text = "";
                    levelIcon.SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectFlowerAtlas, "hd_pm_" + (data.curRank + 1));
                }
                else
                {
                    levelIcon.enabled = false;
                    levelText.text = (data.curRank + 1).ToString();
                }
            }
        }
        else
        {
            EnterBtn.gameObject.SetActive(true);
            panel.gameObject.MSetActive(false);
        }

        EnterBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowStartLevelPassPopup();
        });
        // item.GetComponent<Button>().SetButtonClick(() =>
        // {
        //     if (ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state == ActivityState.underWay)
        //     {
        //         BoxBuilder.ShowLevelPassPopup();
        //     }
        // });
    }

    private void InitLavaPass(Transform item)
    {
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass);
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        var lvTotal = item.Get<Text>("LevelText/Total");
        var lvNum = item.Get<Text>("LevelText/Num");
        var playerTotal = item.Get<Text>("PlayerText/Total");
        var playerNum = item.Get<Text>("PlayerText/Num");
        var reward1Text = item.Get<Text>("Total1");
        var reward2Text = item.Get<Text>("Total2");
        if (model.state == ActivityState.underWay || model.state == ActivityState.waitFinished)
        {
            item.Get<Text>("PlayerText").gameObject.SetActive(true);
            item.Get<Text>("LevelText").gameObject.SetActive(true);
            lvTotal.text = $"{configService.LavaPassConfig.Count}";
            lvNum.text = dataService.LavaPassProgress.winCount.ToString();
            playerTotal.text = "100";
            playerNum.text = $"{dataService.LavaPassProgress.robotCount + 1}";
            EnterBtn.gameObject.SetActive(false);
            reward1Text.gameObject.SetActive(false);
            reward2Text.gameObject.SetActive(true);
        }
        else
        {
            item.Get<Text>("PlayerText").gameObject.SetActive(false);
            item.Get<Text>("LevelText").gameObject.SetActive(false);
            EnterBtn.gameObject.SetActive(true);
            reward1Text.gameObject.SetActive(true);
            reward2Text.gameObject.SetActive(false);
        }

        reward1Text.text = $"{ActivityManager.Instance.LavaPassActivity.GetActivityRewardCoin()}";
        reward2Text.text = $"{ActivityManager.Instance.LavaPassActivity.GetActivityRewardCoin()}";
        
        EnterBtn.SetButtonClick(BoxBuilder.ShowLava);
    }

    private void InitLimitPk(Transform item)
    {
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.limitPk);
        //var quest = item.transform.Get<Transform>("Bg2/Quest").gameObject;
        var bg1Icon = item.transform.Get<Image>("Bg1/Mask/Icon");
        var bg2Icon = item.transform.Get<Image>("Bg2/Mask/Icon");
        bg2Icon.enabled = false;
        item.transform.Get<Transform>("Bg1/Bar").gameObject.MSetActive(false);
        item.transform.Get<Transform>("Bg2/Bar").gameObject.MSetActive(false);
        if (model.state == ActivityState.underWay || model.state == ActivityState.waitFinished)
        {
            item.transform.Get<Transform>("Bg1/Bar").gameObject.MSetActive(true);
            item.transform.Get<Text>("Bg1/Bar/Name").text = "";
            item.transform.Get<Text>("Bg1/Bar/Progress/Text").text = dataService.LimitPkData.MyIntegral.ToString();

            WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
            {
                if (ret)
                {
                    var tex = SpriteUtils.ReadTexture(filePath);
                    if (tex != null)
                    {
                        bg1Icon.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                    }
                }
            });

            if (dataService.LimitPkData.RobotHeadIconIndex != -1)
            {
                SpriteUtils.SetRobotSpriteByIndex(bg2Icon, dataService.LimitPkData.RobotHeadIconIndex, () =>
                {
                    bg2Icon.enabled = true;
                });
                item.transform.Get<Transform>("Bg2/Bar").gameObject.MSetActive(true);
                item.transform.Get<Text>("Bg2/Bar/Name").text = "";
                item.Get<Text>("Bg2/Bar/Progress/Text").text = dataService.LimitPkData.RobotIntegral.ToString();
            }
            
            item.transform.Get<Image>("Bg1/WinFlag").gameObject.MSetActive(dataService.LimitPkData.MyIntegral > dataService.LimitPkData.RobotIntegral);
            item.transform.Get<Image>("Bg2/WinFlag").gameObject.MSetActive(dataService.LimitPkData.MyIntegral <= dataService.LimitPkData.RobotIntegral);
                        EnterBtn.gameObject.SetActive(false);
            // item.Get<Text>("LimitPk/Progress/Left").text = dataService.LimitPkData.MyIntegral.ToString();
            // item.Get<Text>("LimitPk/Progress/Right").text = dataService.LimitPkData.RobotIntegral.ToString();
        }
        else
        {
            EnterBtn.gameObject.SetActive(true);
        }

        EnterBtn.SetButtonClick(
            () =>
            {
                SoundPlayer.Instance.PlayButton();
                BoxBuilder.ShowStartLimitPkPopup("start");
            });
    }
}