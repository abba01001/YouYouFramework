using System;
using System.Collections;
using System.Collections.Generic;
using SoliUtils;
using UniRx;
using UnityEngine;
using UnityEngine.UI;

public class BubbleRewardItem : MonoBehaviour
{
    private int index;
    private List<int> spriteKeys;
    [SerializeField] private Animator _animator;

    public void EnableChangIcon(Dictionary<int, int> rewards)
    {
        if(!this.gameObject.activeSelf) return;
        if (rewards is {Count: > 0})
        {
            _animator.enabled = false;
            index = 0;
            spriteKeys = new List<int>(rewards.Keys);
            GameUtils.LoadPropSprite(transform.Get<Image>("Prop"),spriteKeys[index]);
            index = (index + 1) % spriteKeys.Count;
            _animator.enabled = true;
            _animator.Play("BubbleItem",0,0);
        }
    }

    private void UpdateIcon()
    {
        if (spriteKeys != null)
        {
            GameUtils.LoadPropSprite(transform.Get<Image>("Prop"),spriteKeys[index]);
            index = (index + 1) % spriteKeys.Count;
        }
    }
}
