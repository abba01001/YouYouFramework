﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class DialogueItem : MonoBehaviour
{
    RectTransform selfTrans;
    RectTransform dialogueArrow;
    RectTransform dialogueBG;
    HorizontalLayoutGroup dialogueLayout;
    Text dialogueText;

    Transform propItem;
    List<Transform> propList;

    Transform coinUpRoot;
    Text coinUpText;

    void Awake()
    {
        selfTrans = GetComponent<RectTransform>();
        dialogueArrow = transform.Get<RectTransform>("Arrow");
        dialogueBG = transform.Get<RectTransform>("DialogueBG");
        dialogueLayout = dialogueBG.GetComponent<HorizontalLayoutGroup>();
        transform.Get<Button>("CloseBtn").SetButtonClick(() => GameObjManager.Instance.PushGameObject(gameObject));
        dialogueText = transform.Get<Text>("DialogueBG/DialogueText");

        propItem = transform.Find("PropItem");
        propItem.gameObject.SetActive(false);
        propList = new List<Transform>();

        coinUpRoot = transform.Find("DialogueBG/CoinUpRoot");
        coinUpText = coinUpRoot.Get<Text>("CoinUpText");
    }

    private void SetAnchor(TextAnchor anchor, Transform parent, Vector2 position)
    {
        gameObject.SetActive(true);
        dialogueText.gameObject.SetActive(false);
        coinUpRoot.gameObject.SetActive(false);
        if (propList.Count > 0)
        {
            propList.ForEach(x => Destroy(x.gameObject));
            propList.Clear();
        }

        Vector2 pivot = Vector2.zero;
        Vector3Int selfScale = Vector3Int.one;
        switch (anchor)
        {
            case TextAnchor.UpperLeft:
                pivot = new Vector2(0.8f, 0);
                selfScale.y = -1;
                break;
            case TextAnchor.UpperCenter:
                pivot = new Vector2(0.5f, 0);
                selfScale.y = -1;
                break;
            case TextAnchor.UpperRight:
                pivot = new Vector2(0.2f, 0);
                selfScale.y = -1;
                break;
            case TextAnchor.LowerLeft:
            case TextAnchor.MiddleLeft:
                pivot = new Vector2(0.8f, 1);
                break;
            case TextAnchor.LowerCenter:
            case TextAnchor.MiddleCenter:
                pivot = new Vector2(0.5f, 1);
                break;
            case TextAnchor.LowerRight:
            case TextAnchor.MiddleRight:
                pivot = new Vector2(0.2f, 1);
                break;
        }

        transform.SetParent(parent, false);
        selfTrans.anchoredPosition3D = position;
        selfTrans.localScale = selfScale;

        dialogueArrow.pivot = new Vector2(0.5f, pivot.y);
        dialogueBG.pivot = pivot;
        dialogueBG.localScale = selfScale;
        dialogueArrow.anchoredPosition = Vector2.zero;
        dialogueBG.anchoredPosition = new Vector2(0, selfScale.y > 0 ? -16 : -7) * selfScale.y;
    }

    public void ShowText(TextAnchor anchor, Transform parent, Vector2 position, string content)
    {
        SetAnchor(anchor, parent, position);
        dialogueText.gameObject.SetActive(true);
        dialogueLayout.childControlHeight = true;
        dialogueText.text = content;
    }


    public void ShowItem(TextAnchor anchor, Transform parent, Vector2 position, Dictionary<int, int> itemDic)
    {
        SetAnchor(anchor, parent, position);
        dialogueLayout.childControlHeight = false;
        IStorageService storageService = MainContainer.Container.Resolve<IStorageService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        foreach (var pair in itemDic)
        {
            Transform newPropItem = Instantiate(propItem, dialogueBG);
            newPropItem.gameObject.SetActive(true);
            propList.Add(newPropItem);
            //ItemModel itemModel = configService.ItemConfig[item.Key];
            Text numText = newPropItem.Get<Text>("NumText");
            Text timeText = newPropItem.Get<Text>("TimeText");
            
            
            newPropItem.Get<Transform>("TimeText").gameObject.MSetActive(GameUtils.IsLimitTimeReward(pair.Key));
            newPropItem.Get<Text>("NumText").text = "";
            
            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                newPropItem.Get<Text>("TimeText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            }
            else
            {
                newPropItem.Get<Text>("NumText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            }
            var icon = newPropItem.Get<Image>("PropImage");
            GameUtils.LoadPropSprite(icon,pair.Key);
            if (newPropItem.Find("BubbleItem"))
            {
                newPropItem.Find("BubbleItem").localScale = Vector3.one * 0.8f;
            }
            icon.rectTransform.localScale = Vector3.one;
        }
    }

    public void ShowItem(TextAnchor anchor, Transform parent, Vector2 position, string itemStr)
    {
        ShowItem(anchor, parent, position, GameUtils.AnalysisPropString(itemStr));
    }

    public void ShowCoinUp(TextAnchor anchor, Transform parent, Vector2 position, int coinUpPre)
    {
        SetAnchor(anchor, parent, position);
        dialogueLayout.childControlHeight = false;
        coinUpRoot.gameObject.SetActive(true);
        coinUpText.text = "+" + coinUpPre;
    }
}
