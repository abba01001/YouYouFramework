using System.Collections.Generic;
using Activities;
using SoliUtils;
using UnityEngine;
using UnityEngine.UI;

public class BottleWaterItem : MonoBehaviour
{
    [SerializeField] private GameObject waterEf;
    [SerializeField] private GameObject content;
    [Header("水流移动速度(横向和纵向)")]
    [SerializeField] public float speed = 1.0f; 
    private float yOffset = 1.3f;

    private IConfigService configService;
    private IDataService dataService;
    
    private static readonly int MainTex = Shader.PropertyToID("_MainTex");
    private Vector2 offset;
    private Material mat;
    private int CurIndex = -1;
    private void Awake()
    {
        MeshRenderer meshRenderer = waterEf.transform.GetComponent<MeshRenderer>();
        if (meshRenderer != null)
        {
            mat = meshRenderer.materials.Length > 0 ? meshRenderer.materials[0] : null;
        }
        content.GetComponent<Button>().SetButtonClick(ShowBottleReward);
        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
    }

    private void ShowBottleReward()
    {
        if(CurIndex == configService.RainbowDropsConfig.Count - 1) return;
        GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
            .ShowItem(TextAnchor.UpperCenter, content.GetComponent<Transform>(),new Vector2(0,80),ActivityManager.Instance.CollectWaterActivity.GetBottleReward(CurIndex + 1));
    }

    private void UpdateOffsetY(float value)
    {
        float realOffsetY = 1.5f - value * 0.5f;
        yOffset = realOffsetY;
    }
    
    void Update()
    {
        PlayWaterFlow();
    }

    private void PlayWaterFlow()
    {
        if (mat != null)
        {
            float offsetX = Mathf.Repeat(Time.time * speed, 1.0f);
            Vector2 newOffset = new Vector2(offsetX, yOffset);
            mat.SetTextureOffset(MainTex, newOffset);
        }
    }

    public void UpdateIndex(int index)
    {
        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
        CurIndex = index;

        int layer = 0;
        float value = ActivityManager.Instance.CollectWaterActivity.GetCurLayerRatio();
        int progress = dataService.CollectWaterProgress.progress;
        foreach (var pair in configService.RainbowDropsConfig)
        {
            if(pair.Value.progress > progress) break;
            layer++;
        }
        if (CurIndex > layer)
        {
            //水流置为0
            UpdateOffsetY(0f);
        }
        else if (CurIndex == layer)
        {
            UpdateOffsetY(value);
        }
        else
        {
            UpdateOffsetY(1f);
            //置灰
        }

        ShowBarItem(layer);
        UpdateFinalReward(CurIndex == configService.RainbowDropsConfig.Count - 1);
    }

    private void ShowBarItem(int layer)
    {
        var bar = transform.Get<Transform>("Content/Bar");
        var tx = bar.Get<Text>("Text");
        bar.gameObject.MSetActive(CurIndex == layer || CurIndex == configService.RainbowDropsConfig.Count - 1);
        tx.text = $"{ActivityManager.Instance.CollectWaterActivity.GetCurProgress()}/{ActivityManager.Instance.CollectWaterActivity.GetCurMaxProgress()}";

        if (CurIndex == configService.RainbowDropsConfig.Count - 1)
        {
            var bar1 = transform.Get<Transform>("Content/Bar1");
            var tx1 = bar1.Get<Text>("Text");
            bar1.gameObject.SetActive(false);
            if (CurIndex == layer)
            {
                bar1.gameObject.SetActive(true);
                bar.gameObject.SetActive(false);
                tx1.text = $"{ActivityManager.Instance.CollectWaterActivity.GetCurProgress()}/{ActivityManager.Instance.CollectWaterActivity.GetCurMaxProgress()}";
            }
        }
    }
    
    private void UpdateFinalReward(bool set)
    {
        if(!set) return;
        List<GameObject> list = new List<GameObject>();
        for (int i = 0; i < 4; i++)
        {
            string path = i != 3 ? $"Content/Bar/PropItem{i + 1}" : $"Content/PropItem{i + 1}";
            list.Add(transform.Get<Transform>(path).gameObject);
            list[i].gameObject.SetActive(false);
        }
        RainbowDropsModel model = ActivityManager.Instance.CollectWaterActivity.GetLayerModel(CurIndex + 1);
        int id = 0;
        foreach (var pair in GameUtils.AnalysisPropString(model.reward))
        {
            list[id].gameObject.MSetActive(true);
            int propId = pair.Key;

            var icon = list[id].Get<Image>("PropImage");
            GameUtils.LoadPropSprite(icon,propId);
            if (list[id].transform.Find("BubbleItem"))
            {
                list[id].transform.Find("BubbleItem").localScale = Vector3.one * 0.7f;
            }
            list[id].Get<Transform>("TimeText").gameObject.MSetActive(GameUtils.IsLimitTimeReward(pair.Key));
            list[id].Get<Text>("NumText").text = "";

            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                list[id].Get<Text>("TimeText").text =  GameUtils.GetItemCountText(pair.Key,pair.Value);
            }
            else
            {
                list[id].Get<Text>("NumText").text =  GameUtils.GetItemCountText(pair.Key,pair.Value);
            }
            id++;
        }
    }
}
