﻿using System.Collections;
using UnityEngine;

public class RedDotItem : MonoBehaviour
{
    private RedDotNode _node;
    private Transform _child;

    // Use this for initialization
    void Awake()
    {
        Init();
    }

    private void Init()
    {
        if (_child != null)
        {
            return;
        }
        _child = transform.Find("Image");
    }

    void Update()
    {
        OnUpdate();
    }

    private void OnUpdate()
    {
        if (_node == null)
        {
            SetVisible(false);
            return;
        }
        SetVisible(_node.GetState());
    }

    private void SetVisible(bool visible)
    {
        if(_child.gameObject.activeSelf == visible)
        {
            return;
        }
        _child.gameObject.SetActive(visible);
    }

    public void SetNode(RedDotNode node)
    {
        if (_node == node)
        {
            return;
        }
        _node = node;
    }
}