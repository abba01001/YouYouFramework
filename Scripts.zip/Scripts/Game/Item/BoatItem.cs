using Activities;
using DG.Tweening;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
public class BoatItem : MonoBehaviour
{

    private Image headIcon;
    private Text levelText;
    private Text nameText;
    private Transform reward;
    // private Button getbtn;

    private RectTransform path;
    private int pathLength = 43;
    private int perLength = 430 / 10;
    private Vector2 orignPos = new Vector2(233, -72.5f);
    private Vector2 winPos = new Vector2(1000, -72.5f);
    private bool isAwakeCompleted = false;
    private Animator rewardAnimator;
    private GameObject tx_shui;
    private GameObject tx_shui_2;
    private GameObject tx_tuowei;
    private void Awake()
    {
        if (!isAwakeCompleted)
            InitRes();
    }

    void InitRes(LevelPassData levelPassData = null)
    {
        path = transform.Get<RectTransform>("Path");
        nameText = transform.Get<Text>("HeadIcon/Name");
        tx_shui = path.Find("BoatIcon/tx_shui").gameObject;
        tx_shui.SetActive(false);
        tx_shui_2 = path.Find("BoatIcon/tx_shui_2").gameObject;
        tx_shui_2.SetActive(false);
        tx_tuowei = path.Find("BoatIcon/tx_tuowei").gameObject;
        headIcon = transform.Get<Image>("HeadIcon/Icon");
        levelText = transform.Get<Text>("Path/BoatIcon/bg/Text");
        reward = transform.Get<Transform>("Reward/Icon");
        rewardAnimator = transform.Get<Animator>("Reward");
        rewardAnimator.enabled = false;
        reward.GetComponent<Button>().SetButtonClick(() =>
        {
            GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                .ShowItem(TextAnchor.LowerCenter, transform.Get<Transform>("Reward"), Vector2.zero,ActivityManager.Instance.LevelPassActivity.GetReward(levelPassData.curRank + 1));
        });
        isAwakeCompleted = true;
        if (levelPassData != null) SetData(levelPassData);
    }
    
    public void SetData(LevelPassData levelPassData)
    {
        if (!isAwakeCompleted)
        {
            InitRes(levelPassData);
            return;
        }
        var dataService = MainContainer.Container.Resolve<IDataService>();
        if (string.IsNullOrEmpty(levelPassData.name))
        {
            var id = GameUtils.GetRandomRobotID();
            levelPassData.name = GameUtils.GetRobotInfo(id).name;
        }
        nameText.text = levelPassData.name;
        levelText.text = Mathf.Min(levelPassData.successVictory,10).ToString();


        path.anchoredPosition = orignPos + new Vector2(perLength * Mathf.Min(levelPassData.lastSuccessVictory,10),0);
        
        if (levelPassData == dataService.LevelPassProgress.GetMyData())
        {
            transform.Get<Image>("Path/BoatIcon").SetSpriteByAtlas(Constants.AtlasNamePath.ViewLevelPassAtlas,"lzs_15");
            transform.Get<Image>("HeadIcon/bar").SetSpriteByAtlas(Constants.AtlasNamePath.ViewLevelPassAtlas,"lzs_7");
            WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
            {
                if (ret)
                {
                    nameText.text = dataService.UserName;
                    var tex = SpriteUtils.ReadTexture(filePath);
                    if (tex != null)
                    {
                        headIcon.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                    }
                }
            });
        }
        else
        {
            SpriteUtils.SetRobotSpriteByIndex(headIcon,levelPassData.headIconIndex);
            transform.Get<Image>("Path/BoatIcon").SetSpriteByAtlas(Constants.AtlasNamePath.ViewLevelPassAtlas,"lzs_16");
            transform.Get<Image>("HeadIcon/bar").SetSpriteByAtlas(Constants.AtlasNamePath.ViewLevelPassAtlas,"lzs_8");
        }
        PlayAnim(levelPassData);
    }

    public void PlayAnim(LevelPassData levelPassData)
    {
        transform.Get<Transform>("Path/BoatIcon").gameObject.SetActive(true);
        if (levelPassData.lastSuccessVictory >= 10)
        {
            transform.Get<Transform>("Path/BoatIcon").gameObject.SetActive(false);
            transform.Get<RectTransform>("Reward").sizeDelta = Vector2.zero;
            transform.Get<RectTransform>("Reward/Icon").sizeDelta = Vector2.zero;
            //transform.Get<RectTransform>("Reward/Icon_rank").sizeDelta = new Vector2(68, 66);
            transform.Get<Image>("Reward/Icon_rank").SetNativeSize();
            transform.Get<RectTransform>("Reward/Icon_rank").localScale = Vector3.one;
            
            return;
        }
        if(levelPassData.lastSuccessVictory == levelPassData.successVictory) return;

        Sequence seq = DOTween.Sequence();
        seq.SetTarget(this);
        int tempCount = 10 - levelPassData.lastSuccessVictory;
        tempCount = Mathf.Min(tempCount, levelPassData.successVictory - levelPassData.lastSuccessVictory);
        SoundPlayer.Instance.PlayMainSound("dragonboat_move1");
        seq.Append(path.DOAnchorPos(
                path.anchoredPosition +
                new Vector2(perLength * tempCount, 0), 1f)
            .SetEase(Ease.Linear));

        if (levelPassData.successVictory >= 10 && levelPassData.curRank <= 2)
        {
            seq.AppendInterval(0.2f);
            seq.AppendCallback(() =>
            {
                SoundPlayer.Instance.PlayMainSound("dragonboat_move2");
                tx_shui.SetActive(true);
                tx_shui_2.SetActive(true);
            });
            seq.Append(path.DOAnchorPos(winPos, 0.8f).SetEase(Ease.OutQuad));
            seq.InsertCallback(1.2f, () =>
            {
                SoundPlayer.Instance.PlayMainSound("dragonboat_ani_LevelPass_GetReward");
                rewardAnimator.enabled = true;
                rewardAnimator.Play("ani_LevelPass_GetReward",0,0);
            });
        }
        
        levelPassData.lastSuccessVictory = levelPassData.successVictory;
        ActivityManager.Instance.SaveActivityData();
    }

    public void Clear()
    {
        tx_shui.SetActive(false);
        tx_shui_2.SetActive(false);
        tx_tuowei.SetActive(false);
        DOTween.Kill(this);
    }
}
