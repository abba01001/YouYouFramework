using System;
using SoliUtils;
using UnityEngine;
using UnityEngine.UI;

public class EmailTagItem : ViewBase
{
    [SerializeField] private GameObject selectGo;
    [SerializeField] private GameObject remidGo;
    [SerializeField] private Text tittle;
    [SerializeField] private Text date;
    [SerializeField] private Text time;
    [SerializeField] private Image emailIcon;
    private EmailInfoModel Info;
    protected override void OnAwake()
    {

    }

    public void SetData(EmailInfoModel data)
    {
        Info = data;
        tittle.text = data.title;
        date.text = TimeUtils.GetDateFromTimestamp(int.Parse(data.time),"yyyy-MM-dd");
        time.text = TimeUtils.GetDateFromTimestamp(int.Parse(data.time),"hh:mm");//$"{t.Hour}:{t.Minute}";
        RefreshRemind();
    }

    public EmailInfoModel GetInfo()
    {
        return Info;
    }
    
    public void SetSelect(bool bo)
    {
        selectGo.SetActive(bo);
        if(!bo) return;
        if (Info != null && Info.read != 1)
        {
            GameUtils.RequestEmailInfo("2", Info.mid);
        }
    }

    public void RefreshRemind()
    {
        bool show = !string.IsNullOrEmpty(Info.rewards) && Info.receive == 0 || Info.read == 0;
        emailIcon.SetSpriteByAtlas(Constants.AtlasNamePath.ViewEmailAtlas,Info.read == 0 ?"email_8":"email_9",true);
        remidGo.gameObject.SetActive(show);
    }

}
