using System.Collections.Generic;
using Activities;
using DG.Tweening;
using Model;
using QFramework;
using UniRx;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class FarmingPrefab : ViewBase
{
    private GameObject UnlockTip;
    private CanvasGroup UnlockTipCanvas;
    private Text UnlockTipText;
    
    private GameObject Activation;
    private CanvasGroup ActivationCanvas;
    private Text ActivationText;
    private List<FarmingItem> itemList = new List<FarmingItem>();
    private ThemeData themeData;
    private GameObject unlockEf;
    private int lastUnlockModelId;
    private bool reported = false;

    protected override void OnAwake()
    {
        Activation = transform.Find("Activation").gameObject;
        Activation.GetComponent<Button>().SetButtonClick(UnlockLand);
        ActivationCanvas = Activation.GetComponent<CanvasGroup>();
        ActivationText = Activation.Get<Text>("Text");
        
        UnlockTip = transform.Find("UnlockTip").gameObject;
        UnlockTipCanvas = UnlockTip.GetComponent<CanvasGroup>();
        UnlockTipText = UnlockTip.Get<Text>("Text");
        
        themeData = ActivityManager.Instance.FarmingActivity.GetCurThemeData();
        for (int i = 0; i < themeData.LandInfo.Count; i++)
        {
            int index = i + 1;
            GameObject obj = transform.Find($"{index}").gameObject;
            FarmingItem t = obj.AddComponent<FarmingItem>();
            itemList.Add(t);
        }
    }

    public void UpdatePanel(RefreshUserInfoBuildCoin obj = null)
    {
        themeData = ActivityManager.Instance.FarmingActivity.GetCurThemeData();
        foreach (var VARIABLE in themeData.LandInfo)
        {
            int index = VARIABLE.Key - 1;
            itemList[index].UpdateLand(VARIABLE.Value);
        }
        CheckUnlockLand();
    }

    void CheckUnlockLand()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        FarmingItem item = null;
        bool showActivate = false;
        Vector2 pos = Vector2.zero;

        FarmingModel model = ActivityManager.Instance.FarmingActivity.GetWaitUnlockLand();
        if (model != null)
        {
            pos = itemList[model.landId - 1].GetComponent<RectTransform>().anchoredPosition + new Vector2(0, 100);
            showActivate = true;
        }

        int consume = dataService.FarmingProgress.GetUnlockConsume();
        ActivationCanvas.alpha = (showActivate && dataService.BuildCoin >= consume) ? 1 : 0;
        ActivationCanvas.interactable = showActivate && dataService.BuildCoin >= consume;
        if (showActivate && dataService.BuildCoin >= consume)
        {
            UniRx.Observable.NextFrame().Subscribe((x) =>
            { 
                Activation.transform.localScale = Vector3.zero;
                Activation.transform.DOScale(Vector3.one, 0.5f).SetEase(Ease.OutBack);
            });
        }
        ActivationText.text = dataService.FarmingProgress.GetUnlockConsume().ToString();
        Activation.GetComponent<RectTransform>().anchoredPosition = pos;

        UnlockTipCanvas.alpha = (showActivate && dataService.BuildCoin < consume) ? 1 : 0;
        if (showActivate && dataService.BuildCoin < consume)
        {
            UniRx.Observable.NextFrame().Subscribe((x) =>
            { 
                UnlockTip.transform.localScale = Vector3.zero;
                UnlockTip.transform.DOScale(Vector3.one, 0.5f).SetEase(Ease.OutBack);
            });
        }
        UnlockTipText.text = dataService.FarmingProgress.GetUnlockConsume().ToString();
        UnlockTip.GetComponent<RectTransform>().anchoredPosition = pos + new Vector2(0,20);
    }

    private void UnlockLand()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        FarmingModel model = ActivityManager.Instance.FarmingActivity.GetWaitUnlockLand();
        if (model != null)
        {
            dataService.FarmingProgress.UnlockLand(model.landId, () =>
            {
                SoundPlayer.Instance.PlayMainSound("Farming_jiesuo_tx");
                if (ActivityManager.Instance.FarmingActivity.GetWaitUnlockLand() == null)
                {
                    dataService.FarmingProgress.CompleteTheme(dataService.FarmingProgress.curThemeId);
                }
                if (unlockEf == null)
                {
                    GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/Farming_jiesuo_tx.prefab", (obj) =>
                    {
                        obj.transform.SetParent(itemList[model.landId - 1].transform); //.GetUnlockEfParent()
                        obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                        obj.transform.localScale = Vector3.one;
                        obj.SetActive(true);
                        unlockEf = obj;
                    });
                }
                else
                {
                    unlockEf.SetActive(false);
                    unlockEf.transform.SetParent(itemList[model.landId - 1].transform);
                    unlockEf.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                    unlockEf.SetActive(true);
                }
            });

            if (model.landId == 1 && !reported)
            {
                // WeChatMiniGame.ReportCreateRole();
                var msg = new Dictionary<string, object>{};
                AnalyticUtils.ReportFirstEvent(AnalyticsKey.SoliCreateRoleEx, msg);
                reported = true;
            }
        }
    }

    private void OnEnable()
    {
        TypeEventSystem.Register<RefreshUserInfoBuildCoin>(UpdatePanel);
    }

    private void OnDisable()
    {
        if (unlockEf)
        {
            GameObject.Destroy(unlockEf);
            unlockEf = null;
        }
        TypeEventSystem.UnRegister<RefreshUserInfoBuildCoin>(UpdatePanel);
    }
}