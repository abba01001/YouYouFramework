using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class LoveCardItem : ScrollItem
{
    GameObject get;
    GameObject unGet;
    Text levelText;
    GameObject propItem;
    GameObject bar;

    Transform rewardList;
    Dictionary<int, GameObject> itemList = new Dictionary<int, GameObject>();
    private bool isAwakeCompleted = false;
    private GameObject ef;
    private void Awake()
    {
        if (!isAwakeCompleted)
            InitRes();
    }

    void InitRes(int level = 0, List<SeasonLvRewardItem> list = null)
    {
        get = transform.Get<Transform>("Get").gameObject;
        bar = transform.Get<Transform>("bar").gameObject;
        unGet = transform.Get<Transform>("UnGet").gameObject;
        levelText = transform.Get<Text>("Level");
        propItem = transform.Get<Transform>("PropItem").gameObject;
        ef = transform.Get<Transform>("UnGet/CollectProgress_tx").gameObject;
        isAwakeCompleted = true;
        if (level != 0 && list != null)
        {
            SetData(level, list);
        }

    }

    public override void OnDataUpdate(object data, int index)
    {
        base.OnDataUpdate(data, index);
        List<SeasonLvRewardItem> list = data as List<SeasonLvRewardItem>;
        SetData(index + 1,list);
        gameObject.name = "Scroll" + (index < 10 ? "0" + index : index.ToString());
    }
    
    public void SetData(int layer = 0, List<SeasonLvRewardItem> list = null)
    {
        if (!isAwakeCompleted) InitRes(layer,list);
        var storageService = MainContainer.Container.Resolve<IStorageService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        foreach (var tempItem in list)
        {

            int prop_id = int.Parse(tempItem.type.ToString());
            int propCount = tempItem.amount;
            Image propImage = propItem.transform.Get<Image>("PropImage");
            Text timeText = propItem.transform.Get<Text>("TimeText");
            Text numText = propItem.transform.Get<Text>("NumText");
            numText.text = "";
            timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward(prop_id));
            if (GameUtils.IsLimitTimeReward(prop_id))
            {
                long infiniteTime = propCount;
                timeText.text = infiniteTime / 60 + "m";
            }
            else
            {
                numText.text = prop_id == (int)PropEnum.Coin ? propCount.ToString() : $"x{propCount}";
            }

            propImage.LoadPropSprite(prop_id == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : prop_id);
            break;
        }
        ef.MSetActive(layer == dataService.CollectLoveCardProgress.curLayer + 1);
        levelText.text = layer.ToString();
        bool finish = dataService.CollectLoveCardProgress.curLayer >= layer;
        unGet.gameObject.SetActive(!finish);
        if(list.Count == 0)
        {
            propItem.SetActive(false);
        }
        else
        {
            propItem.SetActive(!finish);
        }
        get.gameObject.SetActive(finish);
    }

    public void Clear()
    {
        get.SetActive(false);
        unGet.SetActive(false);
        levelText.text = "";
    }
}
