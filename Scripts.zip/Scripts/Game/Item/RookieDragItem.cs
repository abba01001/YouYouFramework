﻿using DG.Tweening;
using QFramework;
using SoliUtils;
using System;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class RookieDragItem : MonoBehaviour, IDragHandler, IBeginDragHandler, IEndDragHandler,IPointerUpHandler
{
    
    [SerializeField] private Text tipText;
    [SerializeField] private GameObject finger;
    [SerializeField] private Transform dragRoot;

    private GameObject headGO;
    private List<DragObj> dragObjs = new List<DragObj>();
    private DragObj targetObj;
    private DragObj selectedObj;
    private Vector3 offset;
    private GameObject cloneObj;
    private Sequence dragTween;
    private int rookieId;

    
    private void Awake()
    {
        headGO = tipText.transform.Find("Head").gameObject;
    }

    
    private void OnSelected(DragObj dargObj)
    {
        if (dargObj != dragObjs[0])
        {
            return;
        }
        selectedObj = dargObj;
        selectedObj.mergeItem.ShowSelected(true);
        targetObj = null;
    }


    public void OnPointerUp(PointerEventData eventData)
    {
        ReleaseDrag(eventData);
    }

    
    public void OnBeginDrag(PointerEventData eventData)
    {
        if (selectedObj == null)
        {
            return;
        }
        Vector3 worldPos = ConvertPointerToWorld(eventData, Camera.main);
        offset = selectedObj.go.transform.position - worldPos;
        DoDrag(eventData);
    }

    public void OnDrag(PointerEventData eventData)
    {
        DoDrag(eventData);
    }

    private void DoDrag(PointerEventData eventData)
    {
        Vector3 worldPos = ConvertPointerToWorld(eventData, Camera.main);
        if (selectedObj != null)
        {
            selectedObj.go.transform.position = worldPos + offset;
            SetDragTweenActive(false);
            UpdateState();
        }
    }

    private Vector3 ConvertPointerToWorld(PointerEventData pointerData,Camera worldCamera)
    {
        // 将屏幕坐标转换为世界坐标
        Vector2 screenPoint = pointerData.position;
        Vector3 worldPoint = worldCamera.ScreenToWorldPoint(new Vector3(screenPoint.x, screenPoint.y, worldCamera.nearClipPlane));
        return worldPoint;
    }

    
    
    

    public void OnEndDrag(PointerEventData eventData)
    {
        ReleaseDrag(eventData);
    }

    private void ReleaseDrag(PointerEventData eventData)
    {
        if (selectedObj == null)
        {
            return;
        }

        if (targetObj != null)
        {
            for (int i = 0; i < dragObjs.Count; i++)
            {
                dragObjs[i].Reset();
            }
            Debug.Log("引导合并成功。。。。。");
            OnRookieEnd();
            selectedObj = null;
        }
        else
        {
            selectedObj.transform.position = selectedObj.position;
            selectedObj.mergeItem.ShowSelected(false);
            UpdateState();
            selectedObj = null;
            SetDragTweenActive(true);
        }
    }

    private void UpdateState()
    {
        targetObj = null;
        for (int i = 0; i < dragObjs.Count; i++)
        {
            DragObj dragObj = dragObjs[i];
            if (dragObj == selectedObj)
            {
                continue;
            }
            float distance = Vector2.Distance(dragObj.transform.position, selectedObj.transform.position);
            //Debug.Log("distance=="+distance);
            if (distance < 80f)
            {
                dragObj.mergeItem.ShowSelected(true);
                targetObj = dragObj;
            }
            else
            {
                dragObj.mergeItem.ShowSelected(false);
            }
        }
    }


    private void OnRookieEnd()
    {
        dragTween.Kill();
        dragTween = null;
        if (cloneObj != null)
        {
            //GameObject.Destroy(cloneObj);
            cloneObj.SetActive(false);//销毁报tween的错
            cloneObj = null;
        }
        gameObject.SetActive(false);

        RookieMergeEndEvent mergeEndEvt = new RookieMergeEndEvent(selectedObj.mergeItem.GridId, targetObj.mergeItem.GridId);
        TypeEventSystem.Send<RookieMergeEndEvent>(mergeEndEvt);

        Observable.Timer(TimeSpan.FromSeconds(1f)).Subscribe(_ =>
        {
            RookieTriggerEndEvent t = GameObjManager.Instance.PopClass<RookieTriggerEndEvent>(true);
            t.Init3(rookieId);
            TypeEventSystem.Send<RookieTriggerEndEvent>(t);
        });
        
    }

    
    public void Show(int rookieId, RookieDragModel dragModel, List<GameObject> objs, Action callback)
    {
        this.rookieId = rookieId;
        dragObjs.Clear();
        selectedObj = null;
        int maxOrder = 0;
        DragObj dragObj;
        for (int i = 0; i < objs.Count; i++)
        {
            GameObject obj = objs[i];
            dragObj = new DragObj(obj,this);
            if (dragObj.order > maxOrder)
            {
                maxOrder = dragObj.order;
            }
            dragObjs.Add(dragObj);
            //DOTween.Kill(dragObj.go,true);
            dragObj.go.transform.SetParent(dragRoot);
            dragObj.go.transform.position = dragObj.go.transform.position;
        }

        dragObj = dragObjs[0];
        cloneObj = GameObject.Instantiate(dragObj.go);
        cloneObj.transform.SetParent(dragRoot);
        cloneObj.transform.localScale = dragObj.go.transform.localScale;
        cloneObj.SetActive(false);
        MergeItem mergeItem = cloneObj.GetComponent<MergeItem>();
        mergeItem.SetItemId(dragObj.mergeItem.GetItemId());
        mergeItem.ShowSelected(true);
        if (maxOrder > 0)
        {
            cloneObj.GetComponentInChildren<SpriteRenderer>().sortingOrder = maxOrder;
        }
        ShowDragTips(dragModel, dragObjs[0].go.transform.position, dragObjs[1].go.transform.position);
    }



    private Sequence CreateDragTween( Vector2 startPos, Vector2 endPos)
    {
        Sequence mySequence = DOTween.Sequence();
        mySequence.AppendCallback(() =>
        {
            finger.transform.position = startPos;
            if (cloneObj != null)
            {
                cloneObj.SetActive(false);
                //cloneObj.transform.position = startPos;
            }
        });
        mySequence.AppendInterval(0.5f);
        mySequence.AppendCallback(() =>
        {
            if (cloneObj != null)
            {
                cloneObj.SetActive(true);
                cloneObj.transform.position = startPos;
                cloneObj.transform.DOMove(endPos, 1);
            }
        });

        mySequence.Append(finger.transform.DOMove(endPos, 1));
        mySequence.AppendInterval(0.5f);
        mySequence.SetLoops(-1);
        //mySequence.Play();
        return mySequence;
    }

    private void SetDragTweenActive(bool active)
    {
        if (active)
        {
            dragTween.Play();
            finger.SetActive(true);
        }
        else
        {
            dragTween.Pause();
            finger.SetActive(false);
            cloneObj.SetActive(false);
        }
    }


    private void ShowDragTips(RookieDragModel dragModel, Vector2 startPos, Vector2 endPos)
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        //var rookieModel = configService.RookieDragConfig[dragModelId];
        string tipstr = dragModel.text;

        finger.SetActive(true);
        tipText.gameObject.SetActive(true);

        dragTween = CreateDragTween(startPos, endPos);

        SetDragTweenActive(true);


        if (string.IsNullOrEmpty(tipstr))
            tipText.gameObject.SetActive(false);
        else
            tipText.text = tipstr;
        // 强制UI重新布局
        LayoutRebuilder.ForceRebuildLayoutImmediate(tipText.rectTransform);
        //对话框位置
        bool isTop = false;
        if ((startPos.y + endPos.y) / 2 < 0)//
        {
            isTop = true;
        }
        int headImageWidth = 200;
        var screenRect = GetComponent<RectTransform>().rect;
        var boxImg = tipText.transform.Find("BgImg");
        var boxWidth = boxImg.GetComponent<RectTransform>().rect.width;
        var boxHeight = boxImg.GetComponent<RectTransform>().rect.height;
        float posY = 0;
        float posX = (startPos.x + endPos.x) / 2 + headImageWidth/2;
        float maxX = screenRect.width / 2 - boxWidth / 2;
        posX = Mathf.Clamp(posX, -maxX + headImageWidth/2, maxX);
        if (isTop)
        {
            posY = Mathf.Max(startPos.y, endPos.y) + boxHeight / 2 + 150;
        }
        else
        {
            posY = Mathf.Min(startPos.y, endPos.y) - boxHeight / 2 - 290;
        }
        tipText.transform.position = new Vector3(posX, posY, 0);

        ShowNpcHead(dragModel.item_id);
    }

    private void ShowNpcHead(int itemId)
    {
        if (itemId <= 0)
        {
            headGO.SetActive(false);
            return;
        }
        headGO.SetActive(true);
        
        //var configService = MainContainer.Container.Resolve<IConfigService>();
        //Dictionary<int, MergeItemConfig> mergeItemConfigDic = configService.MergeItemConfig;
        //if (itemId == 1)
        //{
        //    nameText.text = "爱丽";
        //    iconImg.sprite = iconDefaultSprite;
        //    ResetIconSize(iconImg);
        //}
        //else
        //{
        //    MergeItemConfig mergeItemConfig = mergeItemConfigDic[itemId];
        //    nameText.text = mergeItemConfig.name;
        //    LoadIcon(iconImg, itemId);
        //}
        
    }

    private void LoadIcon(Image icon, int itemId)
    {
        icon.LoadPropSprite(itemId, true, () =>
        {
            ResetIconSize(icon);
        });
    }

    private void ResetIconSize(Image icon)
    {
        float targetHeight = 335;
        float targetWidth = 296;
        float originalWidth = icon.sprite.rect.width;
        float originalHeight = icon.sprite.rect.height;
        float aspectRatio = originalWidth / originalHeight;
        float newWidth;
        float newHeight;
        if (originalHeight >= originalWidth)
        {
            newHeight = targetHeight;
            newWidth = targetHeight * aspectRatio;
        }
        else
        {
            newWidth = targetWidth;
            newHeight = targetWidth / aspectRatio;
        }
        icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
    }


    public class DragObj
    {
        public GameObject go;
        public Transform transform;
        public MergeItem mergeItem;
        //public GameObject cloneGO;
        public Vector3 position;
        public Transform parent;
        public DragObjBehaviour behaviour;
        public RookieDragItem rookieDragItem;
        public int order;
        public Animator animator;

        public DragObj(GameObject go, RookieDragItem rookieDragItem)
        {
            this.go = go;
            this.rookieDragItem = rookieDragItem;
            this.parent = go.transform.parent;
            animator = go.GetComponent<Animator>();
            if (animator != null)
            {
                animator.enabled = false;
            }
            transform = go.transform;
            mergeItem = go.GetComponent<MergeItem>();
            position = go.transform.position;
            behaviour = go.AddComponent<DragObjBehaviour>();
            behaviour.Init(this, rookieDragItem.OnSelected);
            SpriteRenderer spriteRenderer = go.GetComponentInChildren<SpriteRenderer>();
            if (spriteRenderer != null)
            {
                order = spriteRenderer.sortingOrder;
            }
        }

        public void Reset()
        {
            if (animator != null)
            {
                animator.enabled = true;
            }
            transform.SetParent(parent);
            transform.position = position;
            mergeItem.ShowSelected(false);
            Behaviour.Destroy(behaviour);
        }

    }

    public class DragObjBehaviour : MonoBehaviour
    {
        private Action<DragObj> selectCallBack;
        private DragObj dragObj;

        public void Init(DragObj dragObj, Action<DragObj> selectCallBack)
        {
            this.dragObj = dragObj;
            this.selectCallBack = selectCallBack;
        }
        void OnMouseDown()
        {
            selectCallBack(dragObj);
        }
    }
}