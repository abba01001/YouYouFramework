using System.Collections.Generic;
using Activities;
using Doozy.Engine.Utils.ColorModels;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class EndlessLevelRankItem : ScrollItem
{
    private int cupCount;
    private int coinCount;
    private string name;

    private Image bg;
    private Image levelIcon;
    private Image headIcon;
    private Text levelText;
    private Text nameText;
    private Text cupText;
    private bool isAwakeCompleted = false;
    private EndlessLevelData endlessLevelData;
    private IDataService dataService;
    private IConfigService configService;
    private void Awake()
    {
        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
        bg = transform.Get<Image>("Bg");
        nameText = transform.Get<Text>("Name");
        levelIcon = transform.Get<Image>("LevelIcon");
        headIcon = transform.Get<Image>("HeadIcon/Image");
        levelText = transform.Get<Text>("LevelIcon/Text");
        cupText = transform.Get<Text>("Cup/NumText");
        transform.Get<Button>("Reward").SetButtonClick(() =>
        {
            EndlessLevelRewardModel model = ActivityManager.Instance.EndlessLevelActivity.GetRankReward(Index + 1);
            GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                .ShowItem(TextAnchor.LowerCenter, transform.Get<Transform>("Reward"), Vector2.zero,
                    GameUtils.AnalysisPropString(model.Reward));
        });
        isAwakeCompleted = true;
        if (endlessLevelData != null) SetData(endlessLevelData);
    }

    public override void OnDataUpdate(object data, int index)
    {
        base.OnDataUpdate(data, index);
        SetData(data as EndlessLevelData);
        gameObject.name = "Scroll" + (index < 10 ? "0" + index : index.ToString());
    }
    
    public void SetData(EndlessLevelData data)
    {
        endlessLevelData = data;
        if (!isAwakeCompleted) return;

        nameText.text = data.name != "" ? data.name : GameUtils.GetRobotInfo(data.robotIndex).name;
        cupText.text = endlessLevelData.integration.ToString();

        if (Index <= 2)
        {
            levelIcon.enabled = true;
            levelText.text = "";
            levelIcon.SetSpriteByAtlas(Constants.AtlasNamePath.ViewPassRankAtlas, "hd_pm_" + (Index + 1));
        }
        else
        {
            levelIcon.enabled = false;
            levelText.text = (Index + 1).ToString();
        }

        if (data == ActivityManager.Instance.EndlessLevelActivity.GetMyData())
        {
            headIcon.SetSpriteByAtlas(Constants.AtlasNamePath.TextureCommonAtlas, "defaultIcon", false);
            WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
            {
                if (ret)
                {
                     nameText.text = dataService.UserName;
                     var tex = SpriteUtils.ReadTexture(filePath);
                     if (tex != null)
                     {
                         headIcon.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                     }
                }
            });
        }
        else
        {
            if (data.avatar != "")
            {
                GameUtils.GetAvatar(data.avatar, (ret, filePath) =>
                {
                    if (ret)
                    {
                        var tex = SpriteUtils.ReadTexture(filePath);
                        if (tex != null)
                        {
                            headIcon.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                        }
                    }
                });
            }
        }
        bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewPassRankAtlas,
            endlessLevelData == ActivityManager.Instance.EndlessLevelActivity.GetMyData() ? "hdlb_1" : "hdlb_2", false);
        SetReward();
    }

    void SetReward()
    {
        EndlessLevelRewardModel model = ActivityManager.Instance.EndlessLevelActivity.GetRankReward(Index + 1);
        transform.Get<Transform>("Reward").gameObject.SetActive(model != null);
        if (model != null)
        {
            string key = Index == 0 ? "hd_pm_box_4" : Index == 1 ? "hd_pm_box_3" : Index == 2 ? "hd_pm_box_2" : "hd_pm_box_1";
            transform.Get<Image>("Reward").SetSpriteByAtlas(Constants.AtlasNamePath.ViewPassRankAtlas, key);
        }
    }
}