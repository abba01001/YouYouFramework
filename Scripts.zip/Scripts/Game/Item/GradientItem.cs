using System;
using System.Collections.Generic;
using Activities;
using Model;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class GradientItem : MonoBehaviour
{
    private bool isAwakeCompleted;
    private int curIndex;
    private List<Transform> rewardList = new List<Transform>();
    private bool? lastCanGetReward;
    private Animator lockAnimator;
    private void Awake()
    {
        var itemParent = transform.Find("Reward");
        for (int i = 0; i < itemParent.childCount; i++)
        {
            rewardList.Add(itemParent.GetChild(i));
        }
        lockAnimator = transform.Get<Animator>("Btn/Lock");
        isAwakeCompleted = true;
        SetData(curIndex);
    }

    public void SetData(int _index)
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        transform.gameObject.SetActive(true);
        curIndex = _index;
        if (!isAwakeCompleted) return;
        if (curIndex > configService.GradientConfig.Count)
        {
            transform.gameObject.SetActive(false);
            return;
        }
        configService.GradientConfig.TryGetValue(curIndex, out GradientModel model);
        if(model == null) return;
        bool canGetReward = curIndex == ActivityManager.Instance.GradientGiftActivity.GetStartIndex();
        if (lastCanGetReward.HasValue && lastCanGetReward != canGetReward && canGetReward)
        {
            PlayUnlockAnim(1,() =>
            {
                lockAnimator.gameObject.SetActive(false);
                lockAnimator.GetComponent<RectTransform>().anchoredPosition = new Vector2(90, 23.8f);
            });
        }
        else
        {
            transform.Get<Transform>($"Btn/Lock").gameObject.SetActive(!canGetReward);
        }
        transform.Get<Button>("Btn").SetButtonClick(CheckGetReward);
        transform.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewGradientGiftAtlas,canGetReward ? "tdlb_2" : "tdlb_1",true);
        transform.Get<Text>("Btn/Price").text = $"{model.Price}";
        transform.Get<Text>("Btn/Price").gameObject.SetActive(model.IsFree != 1);
        transform.Get<Text>("Btn/Free").gameObject.SetActive(model.IsFree == 1);
        lastCanGetReward = canGetReward;
        UpdateReward(model);
    }

    public void ResetLockObj()
    {
        lockAnimator.transform.localRotation = Quaternion.identity;
        lockAnimator.gameObject.SetActive(true);
        lockAnimator.GetComponent<Image>().color = Color.white;
    }
    
    public void PlayUnlockAnim(int type,Action cb)
    {
        if (type == 0)
        {
            GameUtils.PlayShakeAnim(lockAnimator.transform,null,null);
        }
        else if (type == 1)
        {
            GameUtils.PlayAnimation(lockAnimator,"unlock_02",0,cb);
        }
    }
    
    private void UpdateReward(GradientModel model)
    {
        foreach (var item in rewardList)
        {
            item.gameObject.SetActive(false);
        }
        
        int index = 0;
        foreach (var pair in GameUtils.AnalysisPropString(model.reward))
        {
            Transform trans = rewardList[index];
            if(trans == null) break;
            trans.gameObject.SetActive(true);

            GameUtils.LoadPropSprite(trans.Get<Image>($"PropImage"),pair.Key);
            trans.Get<Text>($"NumText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            trans.Get<Image>($"PropImage").transform.localScale = pair.Key != (int) PropEnum.BubbleGift ? Vector3.one * 1.2f : Vector3.one;
            index++;
        }
    }

    private void CheckGetReward()
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        if (curIndex != ActivityManager.Instance.GradientGiftActivity.GetStartIndex())
        {
            PlayUnlockAnim(0,null);
            return;
        }
        configService.GradientConfig.TryGetValue(curIndex, out GradientModel model);
        if(model == null) return;
        if (model.IsFree == 1)
        {
            Dictionary<int, int> rewardDic = GameUtils.AnalysisPropString(model.reward);
            BoxBuilder.ShowRewardPop(rewardDic, PropChangeWay.GradientReward, endCall: () =>
            {
                dataService.GradientGiftProgress.CurRewardIndex++;
                ActivityManager.Instance.SaveActivityData();
                TypeEventSystem.Send<UpdateGradientGift>();
            }, true, activityType: ActivityType.gradientGift);
        }
        else
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(model.product_id);
        }
        ActivityManager.Instance.SaveActivityData();
    }
    
}
