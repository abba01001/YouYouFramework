using System;
using System.Collections.Generic;
using Activities;
using DG.Tweening;
using Doozy.Engine.UI;
using Model;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class ShopItem : MonoBehaviour
{
    private IConfigService configService;
    private IDataService dataService;
    private Transform productTrans;
    private Transform parentUI;

    public void SetShopInfo(ShopInfo shopInfo, Transform parent)
    {
        parentUI = parent;
        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
        productTrans = transform.Find("ProductContent");
        ShopModel model = configService.ShopConfig[shopInfo.productKey];

        productTrans.Get<Text>("BuyBtn/Price").text = model.money.ToString();
        productTrans.Get<Button>("BuyBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(model.product_id);
        });
        
        switch (model.Quality)
        {
            case 1:
                InitRewardItem(productTrans.Find("DailyGet/Reward"), GameUtils.AnalysisPropString(model.daily_reward));
                InitRewardItem(productTrans.Find("Reward"), GameUtils.AnalysisPropString(model.reward));
                InitWeek(model);
                break;
            case 2:
                InitRewardItem(productTrans.Find("DailyGet/Reward"), GameUtils.AnalysisPropString(model.daily_reward));
                InitRewardItem(productTrans.Find("Reward"), GameUtils.AnalysisPropString(model.reward));
                InitMonth(model);
                break;
            case 3:
                InitPurchaseLimit(model);
                break;
            case 4:
                InitPropsPack(model);
                break;
            case 5:
                InitCoinsPack(model);
                break;
            case 9:
                InitSeason(model);
                break;
            default:
                break;
        }
    }

    private void InitSeason(ShopModel model)
    {
        productTrans.Get<Button>("BuyBtn").SetButtonClick(() =>
        {
            if (dataService.SeasonPassProgress.IsPaid)
            {
                BoxBuilder.ShowSeasonPassPopup();
            }
            else
            {
                BoxBuilder.ShowStartSeasonPassPopup("detail");
            }
        });
        productTrans.Get<Text>("BuyBtn/Text").text = dataService.SeasonPassProgress.IsPaid ? "领取" : "购买"; 
        ActivityTimeItem timeItem = productTrans.Get<ActivityTimeItem>("ActivityTimeItem");
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeData.endTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.seasonPass))
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.SeasonPassProgress.ActivityEndTime);
        }

        timeItem.gameObject.SetActive(true);
        timeItem.SetTimeData(timeData);
    }

    private void InitMonth(ShopModel model)
    {
        productTrans.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas, "shop_4");
        productTrans.Get<Text>("BuyBtn/Price").text = model.money.ToString();
        productTrans.Get<Text>("BuyBtn/RenewPrice").text = model.money.ToString();

        int seconds = (int)dataService.GetPropNum((int)PropEnum.MonthCard)  - TimeUtils.UtcNow();
        bool isBuy = seconds > 0;
        productTrans.Get<Transform>("BuyBtn/Price").gameObject.SetActive(!isBuy);
        productTrans.Get<Transform>("BuyBtn/RenewPrice").gameObject.SetActive(isBuy);

        productTrans.Get<Image>("RewardImage").SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas, "shop_jl_1");
        productTrans.Get<Image>("Title").SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas, "shop_8");
        productTrans.Get<Text>("Title/Title1").text = model.Description;
        productTrans.Get<Text>("Title/Title2").text = "开通后免广告,立即获得";
        productTrans.Get<Text>("Title/Title4").text = "购买后立即生效，持续30天，可累积购买";
        if (seconds > 0)
        {
            int days = seconds / 86400;
            seconds %= 86400;
            
            int hours = seconds / 3600;
            seconds %= 3600;
            
            int minutes = seconds / 60;
            string text = days > 0 ? $"{days}天{hours}时" : $"{hours}时{minutes}分";
            productTrans.Get<Text>("Title/Title4").text = $"已激活 剩余:" + text;
        }
        
        bool canGet = isBuy && !dataService.CheckDailyFlag(FlagType.Month);
        productTrans.Get<Image>("DailyGet/Bg").SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas,canGet?"shop_12" :"shop_11");
        productTrans.Get<Transform>("DailyGet/Btn").gameObject.SetActive(canGet);
        productTrans.Get<Button>("DailyGet/Btn").SetButtonClick(() =>
        {
            if (!dataService.CheckDailyFlag(FlagType.Month))
            {
                BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(model.daily_reward), PropChangeWay.WeekReward, ()=>{
                    InitMonth(model);
                });
                dataService.AddDailyFlag(FlagType.Month);
            }
        });
    }

    private void InitWeek(ShopModel model)
    {
        productTrans.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas, "shop_3");
        productTrans.Get<Text>("BuyBtn/Price").text = model.money.ToString();
        productTrans.Get<Text>("BuyBtn/RenewPrice").text = model.money.ToString();

        int seconds = (int)dataService.GetPropNum((int)PropEnum.WeekCard) - TimeUtils.UtcNow();
        bool isBuy = seconds > 0;
        productTrans.Get<Transform>("BuyBtn/Price").gameObject.SetActive(!isBuy);
        productTrans.Get<Transform>("BuyBtn/RenewPrice").gameObject.SetActive(isBuy);

        productTrans.Get<Image>("RewardImage").SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas, "shop_jl_0");
        productTrans.Get<Image>("Title").SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas, "shop_7");
        productTrans.Get<Text>("Title/Title1").text = model.Description;
        productTrans.Get<Text>("Title/Title2").text = "开通后免广告,立即获得";
        productTrans.Get<Text>("Title/Title4").text = "购买后立即生效，持续7天，可累积购买";
        if (seconds > 0)
        {
            int days = seconds / 86400;
            seconds %= 86400;
            
            int hours = seconds / 3600;
            seconds %= 3600;
            
            int minutes = seconds / 60;
            string text = days > 0 ? $"{days}天{hours}时" : $"{hours}时{minutes}分";
            productTrans.Get<Text>("Title/Title4").text = $"已激活 剩余:" + text;
        }

        bool canGet = isBuy && !dataService.CheckDailyFlag(FlagType.Week);
        productTrans.Get<Image>("DailyGet/Bg").SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas,canGet?"shop_12" :"shop_11");
        productTrans.Get<Transform>("DailyGet/Btn").gameObject.SetActive(canGet);
        productTrans.Get<Button>("DailyGet/Btn").SetButtonClick(() =>
        {
            if (!dataService.CheckDailyFlag(FlagType.Week))
            {
                BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(model.daily_reward), PropChangeWay.WeekReward, ()=>{
                    InitWeek(model);
                });
                dataService.AddDailyFlag(FlagType.Week);
            }
        });
    }

    private void InitPropsPack(ShopModel model)
    {
        productTrans.Get<Text>("Title/Title1").text = model.Description;

        Dictionary<int, int> rewardDic = GameUtils.AnalysisPropString(model.reward);
        Transform normalItemParent = productTrans.Get<Transform>("Normal");
        for (int i = 0; i < normalItemParent.childCount; i++)
        {
            normalItemParent.GetChild(i).gameObject.SetActive(false);
        }

        int normalIndex = 0;
        foreach (var pair in rewardDic)
        {
            if (pair.Key == (int)PropEnum.Coin)
            {
                productTrans.Get<Text>("Coin").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            }
            else
            {
                Transform item = normalItemParent.GetChild(normalIndex);
                if (item)
                {
                    item.gameObject.SetActive(true);
                    GameUtils.LoadPropSprite(item.Get<Image>("PropImage"), pair.Key);
                    item.Get<Text>("NumText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
                    normalIndex++;
                }
            }
        }
    }

    private void InitPurchaseLimit(ShopModel model)
    {
        productTrans.Get<Text>("Title/Title1").text = model.Description;
        Dictionary<int, int> rewardDic = GameUtils.AnalysisPropString(model.reward);
        Transform limitItemParent = productTrans.Get<Transform>("Limit/Item");
        Text limitText = productTrans.Get<Text>("Limit/TimeText");
        limitText.gameObject.SetActive(false);
        Transform normalItemParent = productTrans.Get<Transform>("Normal");

        for (int i = 0; i < normalItemParent.childCount; i++)
        {
            normalItemParent.GetChild(i).gameObject.SetActive(false);
        }

        for (int i = 0; i < limitItemParent.childCount; i++)
        {
            limitItemParent.GetChild(i).gameObject.SetActive(false);
        }

        int limitIndex = 0;
        int normalIndex = 0;
        foreach (var pair in rewardDic)
        {
            if (pair.Key == (int)PropEnum.Coin)
            {
                productTrans.Get<Text>("Coin").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            }
            else if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                Transform item = limitItemParent.GetChild(limitIndex);
                if (item)
                {
                    item.gameObject.SetActive(true);
                    GameUtils.LoadPropSprite(item.GetComponent<Image>(), pair.Key);
                    limitText.gameObject.SetActive(true);
                    limitText.text = GameUtils.GetItemCountText(pair.Key,pair.Value);
                    limitIndex++;
                }
            }
            else
            {
                Transform item = normalItemParent.GetChild(normalIndex);
                if (item)
                {
                    item.gameObject.SetActive(true);
                    GameUtils.LoadPropSprite(item.Get<Image>("PropImage"), pair.Key);
                    item.Get<Text>("NumText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
                    normalIndex++;
                }
            }
        }
    }

    private void InitCoinsPack(ShopModel model)
    {
        Dictionary<int, int> rewardDic = GameUtils.AnalysisPropString(model.reward);
        Transform rewardParent = productTrans.Get<Transform>("Reward");

        for (int i = 0; i < rewardParent.childCount; i++)
        {
            rewardParent.GetChild(i).gameObject.SetActive(false);
        }

        int index = 1;
        foreach (var pair in rewardDic)
        {
            if (index > rewardParent.childCount) break;
            Transform trans = rewardParent.GetChild(index - 1);
            trans.gameObject.SetActive(true);
            trans.Get<Text>("Coin").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            index++;
        }
    }

    void InitRewardItem(Transform rewardParent, Dictionary<int, int> rewardDic)
    {
        
        for (int i = 0; i < rewardParent.childCount; i++)
        {
            rewardParent.Get<Transform>($"PropItem{i + 1}").gameObject.SetActive(false);
        }
        int index = 1;
        foreach (var pair in rewardDic)
        {
            if (index > rewardParent.childCount) break;
            var item = rewardParent.Get<Transform>($"PropItem{index}");
            item.gameObject.SetActive(true);
            GameUtils.LoadPropSprite(item.Get<Image>($"PropImage"), pair.Key);
            
            item.Get<Transform>($"TimeText").gameObject
                .SetActive(GameUtils.IsLimitTimeReward(pair.Key));
            item.Get<Text>($"NumText").text = "";

            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                item.Get<Text>($"TimeText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            }
            else
            {
                item.Get<Text>($"NumText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            }
            index++;
        }
    }

    public void SetPageShopItem(string productId)
    {
        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
        productTrans = transform.Find("ProductContent");
        configService.ShopConfig.TryGetValue(productId, out ShopModel model);
        if (productId == Constants.ProductId.SeasonPass)
        {
            InitSeason(model);
        }
        else if (productId == Constants.ProductId.SmallFirstPayment || productId == Constants.ProductId.FirstPayment)
        {
            InitPageItem(model);
        }
        else if (productId == "Turn")
        {
            productId = GetTurnProductId();
            configService.ShopConfig.TryGetValue(productId, out ShopModel model1);
            InitTurnItem(model1);
        }
    }

    public void InitTurnItem(ShopModel model)
    {
        Dictionary<int, int> rewards = GameUtils.AnalysisPropString(model.reward);
        var rewardImage = productTrans.Get<Image>("RewardImage");
        productTrans.Get<Text>("Title/Title1").text = model.Description;
        productTrans.Get<Text>("BuyBtn/Price").text = model.money.ToString();
        productTrans.Get<Button>("BuyBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(model.product_id);
        });
        if (rewards.ContainsKey((int) PropEnum.Coin))
        {
            productTrans.Get<Text>("Coin").text = rewards[(int) PropEnum.Coin].ToString();
            rewards.Remove((int) PropEnum.Coin);
        }
        InitRewardItem(productTrans.Get<Transform>("Reward"), rewards);
    }

    private string GetTurnProductId()
    {
        string productId = "";
        int time = dataService.FailSameLevelTimes;
        int id = time % 6;
        if (id == 1)
        {
            productId = Constants.ProductId.DiscountGift;
        }
        else if (id == 2)
        {
            productId = Constants.ProductId.NarrowDefeatPack_1;
        }
        else if (id == 3)
        {
            productId = Constants.ProductId.AssistancePack_1;
        }
        else if (id == 4)
        {
            productId = Constants.ProductId.DailyPurchaseLimit_1 ;
        }
        else if (id == 5)
        {
            productId = Constants.ProductId.WeeklyPurchaseLimit_1 ;
        }
        else
        {
            productId = Constants.ProductId.MonthlyPurchaseLimit_1;
        }
        return productId;
    }
    
    private void InitPageItem(ShopModel model)
    {
        Dictionary<int, int> rewards = GameUtils.AnalysisPropString(model.reward);
        var rewardImage = productTrans.Get<Image>("RewardImage");
        productTrans.Get<Text>("Title/Title1").text = "首充礼包";
        productTrans.Get<Text>("BuyBtn/Price").text = model.money.ToString();
        productTrans.Get<Button>("BuyBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(model.product_id);
        });
        if (rewards.ContainsKey((int) PropEnum.Coin))
        {
            productTrans.Get<Text>("Coin").text = rewards[(int) PropEnum.Coin].ToString();
            rewards.Remove((int) PropEnum.Coin);
        }
        InitRewardItem(productTrans.Get<Transform>("Reward"), rewards);
    }
}