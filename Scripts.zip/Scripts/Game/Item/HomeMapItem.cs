using Coffee.UIExtensions;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class HomeMapItem : MonoBehaviour
{
    private GameObject Lock;
    private GameObject Finish;
    private GameObject Bg;
    private GameObject Progress;
    private Image ProgressImage;
    private Text ProgressText;
    private Image Map;
    private Text Title;
    private bool isShaking = false;
    private void Awake()
    {
        Lock = transform.Find("Content/Lock").gameObject;
        Lock.GetComponent<Button>().SetButtonClick(ShakeLock);
        Finish = transform.Find("Content/Finish").gameObject;
        Progress = transform.Find("Content/Progress").gameObject;
        ProgressImage = transform.Find("Content/Progress/Value").GetComponent<Image>();
        ProgressText = transform.Find("Content/Progress/Text").GetComponent<Text>();
        Bg = transform.Find("Content").gameObject;
        Map = transform.Find("Content/Map").GetComponent<Image>();
        Title = transform.Find("Content/Title").GetComponent<Text>();
    }

    public void UpdateItem(ThemeData info,FarmingModel model)
    {
        Lock.SetActive(!info.Unlock);
        Finish.SetActive(info.Finish);
        SetGray(!info.Unlock);
        Progress.SetActive(info.Unlock && !info.Finish);
        if (info.Unlock)
        {
            int count = info.GetUnlockLandCount();
            ProgressText.text = $"{count}/{info.LandInfo.Count}";
            ProgressImage.fillAmount = (float) count / info.LandInfo.Count;
        }
        Map.SetSpriteByAtlas(Constants.AtlasNamePath.ViewHomeMapAtlas, model.mapSprite, true);
        Title.text = model.mapTittle;
    }
    
    public void ShakeLock()
    {
        if(isShaking) return;
        GameUtils.PlayShakeAnim(Lock.transform, () => isShaking = true, () => isShaking = false);
    }


    private void SetGray(bool isGray)
    {
        Bg.GetComponent<UIEffect>().effectFactor = isGray ? 1 : 0;
        Title.color = isGray ? Color.gray : new Color(0.6862745f,0.2901961f,0.08235294f,1);
        Map.GetComponent<UIEffect>().effectFactor = isGray ? 1 : 0;
    }
    
}
