﻿using DG.Tweening;
using SoliUtils;
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class UnlockMergeTipItem : MonoBehaviour
{
    [SerializeField]
    public Transform item;
    private Image icon;


    private void LoadIcon(int itemId,Action callBack)
    {
        if (icon == null)
        {
            icon = item.Get<Image>("Icon");
            icon.transform.localScale = Vector3.one * 0.74f;
            //icon.transform.localPosition = new Vector2(-2f,11f);
        }
        
        icon.LoadPropSprite(itemId, false, callBack);
    }

    public void Show(MergeItem mergeItem, Vector2 endPos, Action callBack)
    {
        LoadIcon(mergeItem.GetItemId(), () => {
            icon.GetComponent<RectTransform>().sizeDelta = new Vector2(icon.sprite.rect.width, icon.sprite.rect.height);
            PlayTween(mergeItem, endPos,callBack);
        });
    }
    public void PlayTween(MergeItem mergeItem,Vector2 endPos,Action callBack)
    {
        
        Transform child = mergeItem.transform.Find(mergeItem.GetItemId().ToString());
        Vector2 startPos = child.transform.position;



        item.position = startPos;
        item.localScale = Vector3.one;

        

        Sequence sequence = DOTween.Sequence();
        sequence.AppendInterval(0.5f);

        Vector3 pos2 = new Vector3((startPos.x + endPos.x) / 2f, (startPos.y + endPos.y)/2 + 50, 0);
        Vector3[] path = { startPos, pos2, endPos };
        float distance = Vector2.Distance(startPos, endPos);
        float duration = distance / 1200;

        Sequence seq1 = DOTween.Sequence();


        seq1.Join(item.DOPath(path, duration, PathType.CatmullRom).SetEase(Ease.InSine));
        seq1.Join(item.DOScale(0.8f, duration).SetEase(Ease.InSine));


        sequence.Append(seq1);
        sequence.OnComplete(() =>
        {
            callBack.Invoke();
        });
        sequence.SetAutoKill(true);
        sequence.Play();
    }
}