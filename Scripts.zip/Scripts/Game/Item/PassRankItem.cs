using System.Collections.Generic;
using Activities;
using Doozy.Engine.Utils.ColorModels;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class PassRankItem : ScrollItem
{
    private int cupCount;
    private int coinCount;
    private int rank;
    private string name;

    private Image bg;
    private Image levelIcon;
    private RectTransform levelIconRect;
    private Image headIcon;
    private Text levelText;
    private Text nameText;
    private Text cupText;
    private bool isAwakeCompleted = false;
    private PassRankData passRankData;
    private IDataService dataService;
    private IConfigService configService;
    private void Awake()
    {
        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
        bg = transform.Get<Image>("Bg");
        nameText = transform.Get<Text>("Name");
        levelIcon = transform.Get<Image>("LevelIcon");
        levelIconRect = levelIcon.GetComponent<RectTransform>();
        headIcon = transform.Get<Image>("HeadIcon/Image");
        levelText = transform.Get<Text>("LevelIcon/Text");
        cupText = transform.Get<Text>("Cup/NumText");
        transform.Get<Button>("Reward").SetButtonClick(() =>
        {
            GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                .ShowItem(TextAnchor.LowerCenter, transform.Get<Transform>("Reward"), Vector2.zero,
                    GameUtils.AnalysisPropString(configService.PassRankRewardConfig[rank + 1].Reward));
        });
        isAwakeCompleted = true;
        if (passRankData != null) SetData(passRankData);
    }

    public override void OnDataUpdate(object data, int index)
    {
        base.OnDataUpdate(data, index);
        SetData(data as PassRankData);
        gameObject.name = "Scroll" + (index < 10 ? "0" + index : index.ToString());
    }
    
    public void SetData(PassRankData data)
    {
        passRankData = data;
        if (!isAwakeCompleted) return;
        if (string.IsNullOrEmpty(passRankData.name))
        {
            var id = GameUtils.GetRandomRobotID();
            passRankData.name = GameUtils.GetRobotInfo(id).name;
        }

        nameText.text = passRankData.name;
        cupText.text = passRankData.cupCount.ToString();

        rank = data.rank;
        if (rank <= 2)
        {
            levelIcon.enabled = true;
            levelText.text = "";
            levelIcon.SetSpriteByAtlas(Constants.AtlasNamePath.ViewPassRankAtlas, "hd_pm_" + (rank + 1));
        }
        else
        {
            levelIcon.enabled = false;
            levelText.text = (rank + 1).ToString();
        }

        if (rank == dataService.PassRankProgress.GetMyData().rank)
        {
            headIcon.SetSpriteByAtlas(Constants.AtlasNamePath.TextureCommonAtlas, "defaultIcon", false);
            WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
            {
                if (ret)
                {
                     nameText.text = dataService.UserName;
                     var tex = SpriteUtils.ReadTexture(filePath);
                     if (tex != null)
                     {
                         headIcon.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                     }
                     else
                     {
                         headIcon.enabled = false;
                     }
                }
                else
                {
                    headIcon.enabled = true;
                }
            });
        }
        else
        {
            SpriteUtils.SetRobotSpriteByIndex(headIcon,data.headIconIndex,()=>headIcon.enabled = true);
        }
        //levelIconRect.anchoredPosition = rank == 0 ? new Vector2(18.2f, -7.8f) : new Vector2(28f, -7.8f);
        bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewPassRankAtlas,
            passRankData == dataService.PassRankProgress.myData ? "hdlb_1" : "hdlb_2", false);
        SetReward();
    }

    void SetReward()
    {
        if (rank >= configService.PassRankRewardConfig.Count)
        {
            transform.Get<Transform>("Reward").gameObject.SetActive(false);
            return;
        }

        //transform.Get<RectTransform>("Reward").anchoredPosition = rank == 0 ? new Vector2(608, -1.6f) : new Vector2(616, -1.6f);
        string key = rank == 0 ? "hd_pm_box_4" : rank == 1 ? "hd_pm_box_3" : rank == 2 ? "hd_pm_box_2" : "hd_pm_box_1";
        transform.Get<Image>("Reward").SetSpriteByAtlas(Constants.AtlasNamePath.ViewPassRankAtlas, key);
        transform.Get<Transform>("Reward").gameObject.SetActive(true);
    }
}