using System;
using System.Collections.Generic;
using Activities;
using Model;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class GradientDigItem : MonoBehaviour
{
    private bool isAwakeCompleted;
    private int curIndex;
    private List<Transform> rewardList = new List<Transform>();
    private bool? lastCanGetReward;
    private Animator lockAnimator;
    private void Awake()
    {
        for (int i = 1; i <= 3; i++)
        {
            rewardList.Add(transform.Find($"Reward/PropItem{i}"));
        }
        lockAnimator = transform.Get<Animator>("Btn/Lock");
        isAwakeCompleted = true;
        SetData(curIndex);
    }

    public void SetData(int _index)
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        transform.gameObject.SetActive(true);
        curIndex = _index;
        if (!isAwakeCompleted) return;
        if (curIndex > configService.GiftGradientDigConfig.Count)
        {
            transform.gameObject.SetActive(false);
            return;
        }
        configService.GiftGradientDigConfig.TryGetValue(curIndex, out GradientModel model);
        if(model == null) return;
        bool canGetReward = curIndex == ActivityManager.Instance.GiftGradientDigActivity.GetStartIndex();
        if (lastCanGetReward.HasValue && lastCanGetReward != canGetReward && canGetReward)
        {
            PlayUnlockAnim(1,() =>
            {
                lockAnimator.gameObject.SetActive(false);
                lockAnimator.GetComponent<RectTransform>().anchoredPosition = new Vector2(90, 23.8f);
            });
        }
        else
        {
            transform.Get<Transform>($"Btn/Lock").gameObject.SetActive(!canGetReward);
        }
        transform.Get<Button>("Btn").SetButtonClick(CheckGetReward);
        transform.Get<Image>("Bg").SetSpriteByAtlas(Constants.AtlasNamePath.ViewGiftDigtAtlas,canGetReward ? "wbsxtdlb_bj_1" : "wbsxtdlb_bj_2",true);
        transform.Get<Text>("Btn/Price").text = $"{model.Price}";
        transform.Get<Text>("Btn/Price").gameObject.SetActive(model.IsFree != 1);
        transform.Get<Text>("Btn/Free").gameObject.SetActive(model.IsFree == 1);
        lastCanGetReward = canGetReward;
        UpdateReward(model);
    }

    public void ResetLockObj()
    {
        lockAnimator.transform.localRotation = Quaternion.identity;
        lockAnimator.gameObject.SetActive(true);
        lockAnimator.GetComponent<Image>().color = Color.white;
    }
    
    public void PlayUnlockAnim(int type,Action cb)
    {
        if (type == 0)
        {
            GameUtils.PlayShakeAnim(lockAnimator.transform,null,null);
        }
        else if (type == 1)
        {
            GameUtils.PlayAnimation(lockAnimator,"unlock_02",0,cb);
        }
    }
    
    private void UpdateReward(GradientModel model)
    {
        foreach (var item in rewardList)
        {
            item.gameObject.SetActive(false);
        }
        
        int index = 0;
        foreach (var pair in GameUtils.AnalysisPropString(model.reward))
        {
            if(index >= rewardList.Count) break;
            Transform trans = rewardList[index];
            if(trans == null) break;
            trans.gameObject.SetActive(true);

            GameUtils.LoadPropSprite(trans.Get<Image>($"PropImage"),pair.Key);
            trans.Get<Transform>($"TimeText").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
            trans.Get<Text>($"TimeText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            trans.Get<Text>($"NumText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            trans.Get<Image>($"PropImage").transform.localScale = pair.Key == (int) PropEnum.ItemDig ? Vector3.one * 0.75f : Vector3.one;
            index++;
        }
    }

    private void CheckGetReward()
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        if (curIndex != ActivityManager.Instance.GiftGradientDigActivity.GetStartIndex())
        {
            PlayUnlockAnim(0,null);
            return;
        }
        configService.GiftGradientDigConfig.TryGetValue(curIndex, out GradientModel model);
        if(model == null) return;
        if (model.IsFree == 1)
        {
            Dictionary<int, int> rewardDic = GameUtils.AnalysisPropString(model.reward);
            BoxBuilder.ShowRewardPop(rewardDic, PropChangeWay.GiftGradientDigReward, endCall: () =>
            {
                dataService.GiftGradientDigProgress.CurRewardIndex++;
                ActivityManager.Instance.SaveActivityData();
                TypeEventSystem.Send<UpdateGiftDig>();
            }, true, activityType: ActivityType.giftGradientDig);
        }
        else
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(model.product_id);
        }
        ActivityManager.Instance.SaveActivityData();
    }
    
}
