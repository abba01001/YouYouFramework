using System;
using System.Collections;
using System.Collections.Generic;
using Activities;
using DG.Tweening;
using UniRx;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using Random = UnityEngine.Random;

public class BallonGiftItem : ViewBase
{
    private Animator animator;
    private bool isFlying = false;
    protected override void OnAwake()
    {
        animator = transform.GetComponent<Animator>();
        transform.Get<Button>("Btn").SetButtonClick(() =>
        {

        });
    }

    public void StartFly()
    {
        isFlying = true;

        int direction = GameUtils.RandomRange(0f, 1) > 0.5 ? -1 : 1;
        Sequence seq = DOTween.Sequence();
        Vector3 beginPos = new Vector3(direction * 900, 150,0);
        transform.localPosition = beginPos;
        Vector3 controlPos = beginPos + new Vector3(direction * -500, 150);
        Vector3 endPos = new Vector3(direction * 380, 150,0);
        Vector3[] bezierArray = BezierUtils.GetBeizerList(beginPos, controlPos, endPos, 2);
        seq.Join(transform.DOPath(bezierArray, 10f, PathType.CatmullRom).SetEase(Ease.Linear));
    }
}