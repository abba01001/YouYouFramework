﻿using System.Collections;
using UnityEngine;
using DG.Tweening;
using System;

public class RewardBoxItem : MonoBehaviour
{
    private Transform box;

    private void Awake()
    {
        
    }

    private Transform Box
    {
        get
        {
            if (box == null)
            {
                box = transform.Find("Box");
            }
            return box;
        }
    }

    public void SetSortingOrder(int value)
    {
        transform.GetComponent<Canvas>().sortingOrder = value;
    }

    public void StartPlay(Vector3 endPos,Action callBack)
    {
        Sequence sequence = DOTween.Sequence();
        sequence.AppendInterval(0.6f);
        Box.transform.localPosition = new Vector2(-4.2f,46.2f);
        Box.transform.localScale = Vector3.one;
        Vector3 startPos = Box.position;
        //Vector3 pos1 = new Vector3(startPos.x - 100, startPos.y, startPos.z);
        Vector3 pos2 = new Vector3((startPos.x + endPos.x)/2f, startPos.y+100, startPos.z);
        Vector3[] path = { startPos, pos2, endPos };


        Sequence seq1 = DOTween.Sequence();


        seq1.Join(Box.DOPath(path, 0.6f, PathType.CatmullRom).SetEase(Ease.InQuad));
        seq1.Join(Box.DOScale(0.4f,0.6f).SetEase(Ease.InQuad));


        sequence.Append(seq1);


        sequence.AppendCallback(()=> 
        {
            if(callBack != null)
            {
                callBack.Invoke();
            }
        });
        sequence.SetAutoKill(true);
        sequence.Play();
    }
}