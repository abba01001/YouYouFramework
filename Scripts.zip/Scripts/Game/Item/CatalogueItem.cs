using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class CatalogueItem : ViewBase
{
    [SerializeField] private Button email;
    [SerializeField] private Button setting;
    [SerializeField] private Button kefu;
    [SerializeField] private Text Name;
    [SerializeField] private Text ID;
    [SerializeField] private Image Icon;
    [SerializeField] private GameObject remind;
    protected override void OnAwake()
    {
        transform.GetComponent<Button>().SetButtonClick(() => { transform.gameObject.SetActive(false); });
        email.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowEmailPopup();
            transform.gameObject.SetActive(false);
        });
        setting.SetButtonClick(() =>
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.SettingPopup, () =>
            {
                BoxBuilder.ShowSettingPopup();
                SoundPlayer.Instance.PlayButton();
            });
            transform.gameObject.SetActive(false);
        });
        kefu.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            WeChatMiniGame.OpenCustomerService();
            transform.gameObject.SetActive(false);
        });
        UpdatePanel();
    }

    private void UpdatePanel()
    {
        Name.text = $"用户:{dataService.UserName}";
        ID.text = $"ID:{dataService.UserId}";
        WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
        {
            if (ret)
            {
                Name.text = dataService.UserName;
                var tex = SpriteUtils.ReadTexture(filePath);
                if (tex != null)
                {
                    Icon.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                }
            }
        });
        remind.SetActive(false);
        if (dataService.EmailList is { Count: > 0 })
        {
            foreach (var model in dataService.EmailList)
            {
                if (model.read == 0 || model.receive == 0)
                {
                    remind.SetActive(true);
                    break;
                }
            }
        }
    }
    
}