using Coffee.UIExtensions;
using Model;
using SoliUtils;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class IllustratedNPCItem : ScrollItem
{
    [SerializeField] private List<Sprite> _itemBgList;
    private bool _inited;
    private IDataService _dataService;
    private ScrollView _scrollView;
    private ScrollRect _scrollRect;
    private List<IllustratedPieceItem> _itemList = new List<IllustratedPieceItem>();
    private Transform _piecePrefab;
    private Image _icon;
    private Text _nameText;
    private HorizontalLayoutGroup _layoutGroup;
    private void Awake()
    {
        
    }

    private void Init()
    {
        if (_inited)
        {
            return;
        }
        _inited = true;
        _dataService = MainContainer.Container.Resolve<IDataService>();
        _scrollRect = transform.Get<ScrollRect>("Bg/ScrollView");
        _scrollView = _scrollRect.gameObject.AddComponent<ScrollView>();
        _layoutGroup = _scrollRect.content.GetComponent<HorizontalLayoutGroup>();
        _piecePrefab = _scrollRect.content.Find("PieceItem");
        IllustratedPieceItem pieceItem = _piecePrefab.gameObject.AddComponent<IllustratedPieceItem>();
        pieceItem.bgSprites = _itemBgList;
        _itemList.Add(pieceItem);

        _icon = transform.Get<Image>("Bg/IconBg/Icon");
        _nameText = transform.Get<Text>("Bg/IconBg/NameBg/NameText");
    }

    public void SetParentScrollRect(ScrollRect parentScrollRect)
    {
        _scrollView.SetParentScrollRect(parentScrollRect);
    }

    public override void OnDataUpdate(object data, int index)
    {
        base.OnDataUpdate(data, index);

        Init();
        MergeIllustratedData mergeIllustratedData = data as MergeIllustratedData;
        _scrollRect.movementType = mergeIllustratedData.pieceConfigs.Count < 4 ? ScrollRect.MovementType.Clamped : ScrollRect.MovementType.Elastic;
        ShowPieceCount(mergeIllustratedData.pieceConfigs.Count);
        for(int i=0;i< mergeIllustratedData.pieceConfigs.Count; i++)
        {
            MergeItemConfig config = mergeIllustratedData.pieceConfigs[i];
            IllustratedPieceItem item = _itemList[i];
            item.SetConfig(config,i+1, i == mergeIllustratedData.pieceConfigs.Count - 1);
        }

        _nameText.text = mergeIllustratedData.config.name;
        LoadIcon(mergeIllustratedData.config.id);
        SetGray((MergeItemState)_dataService.GetMergeItemState(mergeIllustratedData.config.id) == MergeItemState.None);
    }

    private void LoadIcon(int itemId)
    {
        _icon.LoadPropSprite(itemId, true, () =>
        {
            float targetHeight = 225;
            float targetWidth = 144;
            float originalWidth = _icon.sprite.rect.width;
            float originalHeight = _icon.sprite.rect.height;
            float aspectRatio = originalWidth / originalHeight;
            float newWidth;
            float newHeight;
            if (originalHeight >= originalWidth)
            {
                newHeight = targetHeight;
                newWidth = targetHeight * aspectRatio;
            }
            else
            {
                newWidth = targetWidth;
                newHeight = targetWidth / aspectRatio;
            }
            _icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
        });
    }

    private void SetGray(bool isGray)
    {
        _icon.GetComponent<UIEffect>().effectFactor = isGray ? 1 : 0;
        //Title.color = isGray ? Color.gray : new Color(0.6862745f, 0.2901961f, 0.08235294f, 1);
    }

    private void ShowPieceCount(int count)
    {
        int createCount = count - _itemList.Count;
        if (createCount > 0)
        {
            for (int i = 0; i < createCount; i++)
            {
                Transform itemTransform = Transform.Instantiate(_piecePrefab, _piecePrefab.parent);
                IllustratedPieceItem pieceItem = itemTransform.gameObject.GetComponent<IllustratedPieceItem>();
                _itemList.Add(pieceItem);
            }
        }
        for (int i = 0; i < _itemList.Count; i++)
        {
            _itemList[i].gameObject.SetActive(i < count);
        }

        int itemWidth = 166;
        Vector2 sizeDelta = _scrollRect.content.sizeDelta;
        sizeDelta.x = _layoutGroup.padding.left + (itemWidth + _layoutGroup.spacing) * count;
        _scrollRect.content.sizeDelta = sizeDelta;

        Vector2 anchoredPosition = _scrollRect.content.anchoredPosition;
        anchoredPosition.x = 0;
        _scrollRect.content.anchoredPosition = anchoredPosition;
    }


    public class ScrollView : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        private ScrollRect _parentScrollRect;
        public void SetParentScrollRect(ScrollRect parentScrollRect)
        {
            this._parentScrollRect = parentScrollRect;
        }
        public void OnBeginDrag(PointerEventData eventdata)
        {
            _parentScrollRect.OnBeginDrag(eventdata);
        }
        public void OnDrag(PointerEventData eventdata)
        {
            _parentScrollRect.OnDrag(eventdata);
        }
        public void OnEndDrag(PointerEventData eventdata)
        {
            _parentScrollRect.OnEndDrag(eventdata);
        }
    }


}
