using System;
using System.Collections;
using System.Collections.Generic;
using Activities;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using Random = UnityEngine.Random;

public class SeasonBuyItem : ViewBase
{
    [SerializeField] private GameObject Remind;
    [SerializeField] private GameObject BuyBtn;
    [SerializeField] private GameObject Lock;
    [SerializeField] private Text RemindText;
    [SerializeField] private Text BuyBtnText;
    [SerializeField] private Text TipText;
    [SerializeField] private Button RewardIcon;
    private bool isAwakeCompleted = false;

    protected override void OnAwake()
    {
        BuyBtn.GetComponent<Button>().SetButtonClick(CheckGetReward);
        RewardIcon.SetButtonClick(() =>
        {
            GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                .ShowItem(TextAnchor.LowerCenter, RewardIcon.transform, Vector2.zero,configService.GetSeasonBoxReward);
        });
        isAwakeCompleted = true;
        RefreshData();
    }

    private void CheckGetReward()
    {
        if (!dataService.SeasonPassProgress.IsPaid)
        {
            BoxBuilder.ShowStartSeasonPassPopup("detail");
        }
        else
        {
            ActivityManager.Instance.SeasonPassActivity.CheckGetBoxReward(RefreshData);
        }
    }

    public void RefreshData()
    {
        if (!isAwakeCompleted) return;
        int count = dataService.SeasonPassProgress.GetBoxRewardCount();
        int curLayer = dataService.SeasonPassProgress.curLayer;
        RemindText.text = $"{count}";
        Lock.gameObject.SetActive(!dataService.SeasonPassProgress.IsPaid);
        Remind.gameObject.SetActive(dataService.SeasonPassProgress.IsPaid && count > 0);

        if (!dataService.SeasonPassProgress.IsPaid)
        {
            BuyBtn.gameObject.SetActive(true);
            BuyBtnText.text = "购买";
            TipText.text = "购买通行证" + "\n" +
                           "完成所有等级后可获得";
        }
        else
        {
            BuyBtn.gameObject.SetActive(count > 0);
            BuyBtnText.text = "领取";
            TipText.text = "满级后每完成一次进度" + "\n" +
                           "均可获得保险箱";
        }
    }
}