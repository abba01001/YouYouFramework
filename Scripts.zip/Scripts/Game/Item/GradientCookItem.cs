using System;
using System.Collections.Generic;
using Activities;
using Model;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class GradientCookItem : MonoBehaviour
{
    private bool isAwakeCompleted;
    private int curIndex;
    private List<Transform> rewardList = new List<Transform>();
    private bool? lastCanGetReward;
    private Animator lockAnimator;
    private void Awake()
    {
        for (int i = 1; i <= 3; i++)
        {
            rewardList.Add(transform.Find($"Reward/PropItem{i}"));
        }
        lockAnimator = transform.Get<Animator>("Btn/Lock");
        isAwakeCompleted = true;
        SetData(curIndex);
    }

    public void SetData(int _index)
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        transform.gameObject.SetActive(true);
        curIndex = _index;
        if (!isAwakeCompleted) return;
        if (curIndex > configService.GiftGradientCookConfig.Count)
        {
            transform.gameObject.SetActive(false);
            return;
        }
        configService.GiftGradientCookConfig.TryGetValue(curIndex, out GradientModel model);
        if(model == null) return;
        bool canGetReward = curIndex == ActivityManager.Instance.GiftGradientCookActivity.GetStartIndex();
        if (lastCanGetReward.HasValue && lastCanGetReward != canGetReward && canGetReward)
        {
            PlayUnlockAnim(1,() =>
            {
                lockAnimator.gameObject.SetActive(false);
                lockAnimator.GetComponent<RectTransform>().anchoredPosition = new Vector2(90, 23.8f);
            });
        }
        else
        {
            transform.Get<Transform>($"Btn/Lock").gameObject.SetActive(!canGetReward);
        }
        transform.Get<Button>("Btn").SetButtonClick(CheckGetReward);
        transform.Get<Image>("Bg").SetSpriteByAtlas(Constants.AtlasNamePath.ViewGiftDigtAtlas,canGetReward ? "wbsxtdlb_bj_1" : "wbsxtdlb_bj_2",true);
        transform.Get<Text>("Btn/Price").text = $"{model.Price}";
        transform.Get<Text>("Btn/Price").gameObject.SetActive(model.IsFree != 1);
        transform.Get<Text>("Btn/Free").gameObject.SetActive(model.IsFree == 1);
        lastCanGetReward = canGetReward;
        UpdateReward(model);
    }

    public void ResetLockObj()
    {
        lockAnimator.transform.localRotation = Quaternion.identity;
        lockAnimator.gameObject.SetActive(true);
        lockAnimator.GetComponent<Image>().color = Color.white;
    }
    
    public void PlayUnlockAnim(int type,Action cb)
    {
        if (type == 0)
        {
            GameUtils.PlayShakeAnim(lockAnimator.transform,null,null);
        }
        else if (type == 1)
        {
            GameUtils.PlayAnimation(lockAnimator,"unlock_02",0,cb);
        }
    }
    
    private void UpdateReward(GradientModel model)
    {
        foreach (var item in rewardList)
        {
            item.gameObject.SetActive(false);
        }
        
        int index = 0;
        foreach (var pair in GameUtils.AnalysisPropString(model.reward))
        {
            if(index >= rewardList.Count) break;
            Transform trans = rewardList[index];
            if(trans == null) break;
            trans.gameObject.SetActive(true);

            var icon = trans.Get<Image>($"PropImage");
            GameUtils.LoadPropSprite(icon,pair.Key);
            icon.transform.localScale = Vector3.one;
            if(pair.Key == (int)PropEnum.ItemCook) icon.transform.localScale = Vector3.one * 0.8f;
            trans.Get<Transform>($"TimeText").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
            trans.Get<Text>($"NumText").text = "";

            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                trans.Get<Text>($"TimeText").text = $"{pair.Value / 60}m";
            }
            else
            {
                trans.Get<Text>($"NumText").text = pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
            }
            index++;
        }
    }

    private void CheckGetReward()
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        if (curIndex != ActivityManager.Instance.GiftGradientCookActivity.GetStartIndex())
        {
            PlayUnlockAnim(0,null);
            return;
        }
        configService.GiftGradientCookConfig.TryGetValue(curIndex, out GradientModel model);
        if(model == null) return;
        if (model.IsFree == 1)
        {
            Dictionary<int, int> rewardDic = GameUtils.AnalysisPropString(model.reward);
            BoxBuilder.ShowRewardPop(rewardDic, PropChangeWay.GiftGradientCookReward, endCall: () =>
            {
                dataService.GiftGradientCookProgress.CurRewardIndex++;
                ActivityManager.Instance.SaveActivityData();
                TypeEventSystem.Send<UpdateGiftCook>();
            }, true, activityType: ActivityType.giftGradientCook);
        }
        else
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(model.product_id);
        }
        ActivityManager.Instance.SaveActivityData();
    }
    
}
