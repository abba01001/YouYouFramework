using System;
using DG.Tweening;
using Doozy.Engine.UI;
using Model;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class FarmingItem : MonoBehaviour
{
    private GameObject Lock;
    private CanvasGroup LockCanvas;
    private GameObject Plant;
    private Image PlantImage;
    public LandData data;
    private GameObject plantEf;

    private void Awake()
    {
        Lock = transform.Find("Lock").gameObject;
        LockCanvas = Lock.GetComponent<CanvasGroup>();
        Plant = transform.Find("plant").gameObject;
        PlantImage = Plant.GetComponent<Image>();
    }

    private void PlayAnim(HarvestPlant obj)
    {
        if (obj.landId != data.landId) return;
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        FarmingModel model = configService.GetFarmingModel(dataService.FarmingProgress.maxMapId,
            dataService.FarmingProgress.maxThemeId, 1);
        bool playGoldEf = false;
        for (int i = 0; i < model.collectCount; i++)
        {
            Transform starTrans = GameObjManager.Instance.PopGameObject(GameObjType.FlyFarmingItem).transform;
            starTrans.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewFarmingAtlas,
                $"gs_{dataService.FarmingProgress.curMapId}_{dataService.FarmingProgress.curThemeId}", true);
            //starTrans.GetComponent<Canvas>().sortingOrder = 25 + i + 1;
            starTrans.SetParent(transform, false);
            starTrans.localScale = Vector3.one * 0.4f;
            starTrans.localPosition = Vector3.zero + 0.5f * GoldView.flyGoldPoints[i];
            Vector3 startPos = starTrans.position;
            Vector3 beginPos = startPos + new Vector3(100, 100);
            Vector3 controlPos = startPos + new Vector3(0, 300, 0);
            Vector3 endPos = UIView.GetViews(Doozy.Engine.UI.Base.NamesDatabase.GENERAL, Constants.DoozyView.Gold)[0]
                .GetComponent<GoldView>().GetGoldPos(); //new Vector3(-500,200);
            Vector3[] bezierArray = BezierUtils.GetBeizerList(beginPos, controlPos, endPos, 10);
            Sequence seq = DOTween.Sequence();
            seq.AppendInterval(0.02f);
            seq.AppendCallback(() => starTrans.gameObject.SetActive(true));
            seq.Append(starTrans.DOMove(beginPos, 0.3f).SetEase(Ease.OutQuad));
            seq.Join(starTrans.DOScale(Vector3.one, 0.3f));
            seq.AppendInterval(0.1f);
            seq.Append(starTrans.DOPath(bezierArray, 1f, PathType.CatmullRom).SetEase(Ease.InSine).OnComplete(
                () =>
                {
                    if (!playGoldEf)
                    {
                        playGoldEf = true;
                        GoldView.Instance.ShowGoldNumFx((int)PropEnum.Coin);
                    }
                    starTrans.gameObject.SetActive(false);
                    GameObjManager.Instance.PushGameObject(starTrans.gameObject);
                }
            ));
        }
    }

    private void OnEnable()
    {
        TypeEventSystem.Register<HarvestPlant>(PlayAnim);
    }

    private void OnDisable()
    {
        TypeEventSystem.UnRegister<HarvestPlant>(PlayAnim);
    }


    public void UpdateLand(LandData landData)
    {
        data = landData;
        var dataService = MainContainer.Container.Resolve<IDataService>();
        Lock.SetActive(!landData.Unlock);
        Plant.SetActive(landData.Unlock);
        LockCanvas.alpha = !landData.Unlock ? 1 : 0;
        PlantImage.SetSpriteByAtlas(Constants.AtlasNamePath.ViewFarmingAtlas,
            $"zw_{dataService.FarmingProgress.curMapId}_{dataService.FarmingProgress.curThemeId}_{landData.State}");
        if (landData.Unlock && landData.PickFlag)
        {
            if (plantEf == null)
            {
                GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/farming_tx_01.prefab", (obj) =>
                {
                    plantEf = obj;
                    obj.transform.SetParent(Plant.transform);
                    obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                    obj.transform.localScale = Vector3.one;
                    obj.SetActive(true);
                });
            }
            else
            {
                plantEf.SetActive(true);
            }
        }
        else
        {
            if (plantEf != null) plantEf.SetActive(false);
        }
    }
}