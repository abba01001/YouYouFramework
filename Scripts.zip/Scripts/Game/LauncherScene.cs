using Doozy.Engine.UI.Settings;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using QFramework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.U2D;
using UnityEngine.UI;
using SoliUtils;
using UnityEngine.Networking;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UniRx;
using Doozy.Engine;

public class LauncherScene : MonoBehaviour
{
    public Transform loadingPop;
    public Image ProgressImage;
    public Text ProgressText;
    public Button ServiceBtn;
    public Button CleanBtn;
    private float loadingProcess = 0f;
    private IAssetService assetService;
    private IDataService dataService;
    private bool bgLoaded = false;

    public void Awake()
    {
        // var msg1 = new Dictionary<string, object>();
        // AnalyticUtils.ReportFirstEvent(AnalyticsKey.SoliFirstOpen, msg1);
        var msg2 = new Dictionary<string, object>();
        AnalyticUtils.ReportEvent(AnalyticsKey.SoliLaunchGame, msg2);
        BaseInit();
    }

    public void BaseInit()
    {
        // InitFixCalendarError();
        DOTween.Init();
        DOTween.SetTweensCapacity(500, 150);
        ViewQueueManager.Instance.Init();
        AnalyticUtils.ReportUser_Add(AnalyticsKey.LoginTimes, 1);
        // UIPopupSettings.InitInstance();
        PaidManager.Instance.Init();

        GameCommon.IsAiMode = false;
        GameCommon.IsEditorMode = false;
        Application.runInBackground = true;

        assetService = MainContainer.Container.Resolve<IAssetService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
        ServiceBtn.gameObject.SetActive(false);
        Debug.Log($">>> SceneMgr === BaseInit Finish .");
    }

    private async void Start()
    {
        Debug.Log($">>> LauncherScene >> Start ... ");

        // await UIPopupSettings.UpdateDatabaseAsync();

        WeChatMiniGame.InitQySdk(); //调用登录

        ShowProcess(0.02f);
        await Doozy.Engine.Settings.DoozySettings.Init();
        ShowProcess(0.04f);
        await Doozy.Engine.Soundy.SoundySettings.Init();
        ShowProcess(0.06f);
        await Doozy.Engine.Nody.NodySettings.Init();
        ShowProcess(0.08f);
        await Doozy.Engine.Themes.ThemesSettings.Init();
        ShowProcess(0.10f);
        await Doozy.Engine.UI.Settings.UIPopupSettings.Init();
        ShowProcess(0.12f);
        await Doozy.Engine.UI.Settings.UIButtonSettings.Init();
        ShowProcess(0.14f);
        await Doozy.Engine.UI.Settings.UICanvasSettings.Init();
        ShowProcess(0.16f);
        await Doozy.Engine.UI.Settings.UIDrawerSettings.Init();
        ShowProcess(0.18f);
        await Doozy.Engine.UI.Settings.UIToggleSettings.Init();
        ShowProcess(0.22f);
        await Doozy.Engine.UI.Settings.UIViewSettings.Init();
        ShowProcess(0.26f);
        await Doozy.Engine.UI.Animation.UIAnimations.Init();
        ShowProcess(0.3f);
        loadingProcess = 0.3f;

        // await UIPopupSettings.UpdateDatabaseAsync();

        if (!GameCommon.IsOffMode)
        {
            await GetServerTime();
        }

        TypeEventSystem.Register<BackGroundLoadedEvent>(OnBackGroundLoadedEvent);

        // float scale = Math.Max(Screen.width / Constants.ResolutionWidth,
        //     Screen.height / Constants.ResolutionHeight);
        // loadingPop.transform.localScale = Vector3.one * scale;

        ServiceBtn.onClick.AddListener((() =>
        {
            WeChatMiniGame.OpenCustomerService();
        }));

        CleanBtn.onClick.AddListener((() =>
        {
            WeChatMiniGame.CleanAndRestart();
        }));

        await LoadRemoteConfigAsync(); //获取远端配置（审核版本）
        await LoadConfigAsync(); //先初始化配置

        DOTween.To(() => loadingProcess, x => ShowProcess(x), 0.9f, 10f);

        if (!GameCommon.IsOffMode)
        {
            await WaitRemoteUser(); //等待SDK登录成功
            await CheckUser(); //检查是否新用户
            await VerificateAuth(); //obs授权
            await SyncUserData(); //同步远端数据
        }
        else
        {
            dataService.ReadLocalData();
            GameCommon.IsRemoteData = true;
        }


        await LoadMergeSceneAsync(); //加载合成场景
        await LoadAssetsAsync(); //预加载资源

        await GlobalRes.PreLoadHomeRes();
        await GlobalRes.LoadOtherRes();

        StartCoroutine(LoadMainScene(MainSceneLoadingCall, loadingProcess));

    }

    private void OnDestroy()
    {
        TypeEventSystem.UnRegister<BackGroundLoadedEvent>(OnBackGroundLoadedEvent);
    }

    private void OnBackGroundLoadedEvent(GameEvent e)
    {
        bgLoaded = true;
    }

    private void MainSceneLoadingCall(float progress)
    {
        ShowProcess(progress);
    }

    private async Task GetServerTime()
    {
        Debug.Log("GetServerTime Start");
        while (!GameCommon.HasServerTime)
        {
            await UniTask.Delay(100);
            TimeUtils.NetTimeUtil.ReqNetDateTime();
        }

        Debug.Log("GetServerTime Done");
    }

    private async Task LoadMergeSceneAsync()
    {
        Debug.Log("LoadMergeSceneAsync Start");
        await MergeGameController.Instance.Load();
        TypeEventSystem.Send<BackGroundLoadedEvent>();
        MergeGameController.Instance.Show(false);

        Debug.Log("LoadMergeSceneAsync Done");
    }

    private async Task LoadAssetsAsync()
    {
        Debug.Log($"LoadAssetsAsync start {TimeUtils.UtcNow()}");
        float totalPercent = 0.6f;
        List<Task> loadTasks = new List<Task>();
        int totalAssets = Constants.PreLoadResList.Count;
        foreach (var res in Constants.PreLoadResList)
        {
            Task task = null;
            if (res.Item2 == typeof(GameObject))
            {
                task = GlobalRes.LoadAssetAsync<GameObject>(res.Item1);
            }
            else if (res.Item2 == typeof(Sprite))
            {
                task = GlobalRes.LoadAssetAsync<Sprite>(res.Item1);
            }
            else if (res.Item2 == typeof(SpriteAtlas))
            {
                task = GlobalRes.LoadAssetAsync<SpriteAtlas>(res.Item1);
            }
            else if (res.Item2 == typeof(Texture2D))
            {
                task = GlobalRes.LoadAssetAsync<Texture2D>(res.Item1);
            }

            if (task != null)
                loadTasks.Add(task);
            var completedCount = loadTasks.Count(t => t.IsCompleted);
            var pro = loadingProcess + (completedCount / (float)totalAssets) * totalPercent;
            ShowProcess(pro);

            if (task != null)
                await task;
            else
                await Task.Yield();
        }

        loadingProcess += totalPercent;
        Debug.Log($"LoadAssetsAsync end {TimeUtils.UtcNow()}");
    }

    private async Task WaitRemoteUser()
    {
        Debug.Log("WaitRemoteUser start");

        // #if UNITY_EDITOR
        //                 WeChatMiniGame.UserId = "28222416";
        //                 WeChatMiniGame.OpenId = "oXxOt67dQhZxCS0nPqrilUrx8_eM";
        //                 // WeChatMiniGame.UserId = "28249944";
        //                 // WeChatMiniGame.OpenId = "oXxOt60d88l3qDjFJcwDVoBqmra4";

        //                 GameCommon.IsRemoteUser = true;
        //                 Debug.LogError("篡改数据先清档！！！");
        //                 Debug.LogError("篡改数据先清档！！！");
        //                 Debug.LogError("篡改数据先清档！！！");
        //                 GameCommon.IsDataUpload = false;
        //                 return;
        // #endif

        while (!GameCommon.IsRemoteUser)
        {
            await UniTask.Delay(100);
#if UNITY_EDITOR
            Debug.LogError("登录失败，读取历史账号进入");
            dataService.ReadLocalData();
            WeChatMiniGame.UserId = dataService.UserId;
            WeChatMiniGame.OpenId = dataService.OpenId;
            break;
#endif
        }
        ServiceBtn.gameObject.SetActive(GameCommon.IsRemoteUser);

        Debug.Log("WaitRemoteUser Done");
    }

    private async Task CheckUser()
    {
        Debug.Log("CheckUser Start");
        while (!GameCommon.HasCheckUser)
        {
            await UniTask.Delay(1000);
            HuaweiCloudUtils.RequestLogin();
        }

        Debug.Log("CheckUser Done");
    }

    private async Task VerificateAuth()
    {
        Debug.Log("VerificateAuth Start");
        while (!HuaweiCloudUtils.IsVerificateAuth())
        {
            await UniTask.Delay(1000);
            HuaweiCloudUtils.RequestObsUrl(1);
        }

        Debug.Log("VerificateAuth Done");
    }

    private async Task SyncUserData()
    {
        dataService.UserId = WeChatMiniGame.UserId;
        dataService.OpenId = WeChatMiniGame.OpenId;

        if (!GameCommon.IsOldUser)
        {
            dataService.ReadLocalData();
            GameCommon.IsRemoteData = true;
            return;
        }

        dataService.SyncUserData(WeChatMiniGame.UserId);
        while (!GameCommon.IsRemoteData)
        {
            await UniTask.Delay(100);
        }
        Debug.Log("SyncUserData Done");
    }

    private async Task LoadRemoteConfigAsync()
    {
        Debug.Log($"LoadRemoteConfigAsync==========platform:{DeviceUtils.GetPlatform()} env:{DeviceUtils.GetEnvVersion()} ver:{DeviceUtils.GetVersionName()}");
        if (DeviceUtils.GetPlatform() != "ios")
        {
            GameCommon.IsShieldPurchase = false;
            return;
        }
        GameCommon.IsShieldPurchase = true;

        int tryTimes = 0;
        int maxTimes = 60;
        bool result = false;
        string url = Constants.ApiUrl + "/config";
        StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
        {
            if (ret)
            {
                result = true;
                // Debug.LogError($"LoadRemoteConfigAsync==========json {json}");
                var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
                dic.TryGetValue("review_able", out var review_able);
                if (review_able != null)
                {
                    int able = Convert.ToInt32(review_able);
                    if (able == 1)
                    {
                        dic.TryGetValue("review_ver", out var review_ver);
                        if (review_ver != null)
                        {
                            string ver = review_ver.ToString();
                            if (!string.IsNullOrEmpty(ver) && (DeviceUtils.GetVersionName() == ver || DeviceUtils.GetVersionName() == "0.0.1"))
                            {
                                //TODO 审核版
                                GameCommon.IsShieldPurchase = true;
                            }
                            else
                            {
                                GameCommon.IsShieldPurchase = false;
                            }
                        }
                    }
                    else
                    {
                        GameCommon.IsShieldPurchase = false;
                    }
                }
            }
            else
            {
            }
        }));

        while (!result)
        {
            await UniTask.Delay(100);
            tryTimes++;
            if (tryTimes >= maxTimes)
            {
                Debug.LogError("获取远端配置失败");
                break;
            }
            ServiceBtn.gameObject.SetActive(GameCommon.IsRemoteUser);
        }
    }

    private async Task LoadConfigAsync()
    {
        Debug.Log($"LoadConfigAsync start {TimeUtils.UtcNow()}");
        List<Action> loadTaskFuncList = new List<Action>();
        List<Task> loadTasks = new List<Task>();
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadValueConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadLocalStageConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadEndlessStageOneConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadEndlessLevelRewardConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadWheelRewardConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadEndlessStageTwoConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadCardRemainConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadComboRewardConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadSignInConfig()); });
        // loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadWheelConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadShopConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadRookieConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadRookieClickConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadRookieDialogueConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadRookieDragConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadRookieAnimConfig()); }); 
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadBetConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadItemConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadPowerItemConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadCollectFlowerConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadRobotConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadActivitiesConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadSeasonRewardConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadActivitiesSwitchConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadCollectLoveCardConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadCollectMusicConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadDigTreasureRewardConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadLevelPassConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadLavaPassConfig()); });
        // loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadFarmingConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadCookMealConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMysteriousSeedConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadUnlockConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMagicNectarConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadRainbowDropsConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadPopupPriorityConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadAdRewardConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadPassRankRobotConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadCarRankRobotConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadGradientConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadGiftGradientCookConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadGiftGradientDigConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadPassRankRewardConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadCarRankRewardConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadLimitPkConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadPushGiftConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadSoundConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadCardDescConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadSeasonPassConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadNewUserSeasonPassConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadSeasonExpConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadHandleLevelConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadHandleEndlessLevelConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadHandleResultConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadHandleLabelConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadHandleConsumConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadHandlePaidConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeItemConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeMapConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeRegionRewardsConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeOrderDegreeConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeOrderListConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeBuildConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeLevelBoxConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeShopConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeHotAirBallConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeItemNpcConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadMergeIllustratedConfig()); });
        loadTaskFuncList.Add(() => { loadTasks.Add(assetService.LoadEnergyConfig()); });


        float totalPercent = 0.5f;
        int totalAssets = loadTaskFuncList.Count;
        foreach (var func in loadTaskFuncList)
        {
            func?.Invoke();
            var completedCount = loadTasks.Count(t => t.IsCompleted);
            var pro = loadingProcess + (completedCount / (float)totalAssets) * totalPercent;
            ShowProcess(pro);
            var task = loadTasks.Find(t => !t.IsCompleted);
            if (task != null)
                await task;
            else
                await Task.Yield();
            ServiceBtn.gameObject.SetActive(GameCommon.IsRemoteUser);
        }

        loadingProcess += totalPercent;

        Debug.Log($"LoadConfigAsync end {TimeUtils.UtcNow()}");
    }

    private void ShowProcess(float pro)
    {
        if (pro >= ProgressImage.fillAmount)
        {
            // ProgressImage.fillAmount = pro;
            // ProgressText.text = $"{(pro * 100):0.0}";
            pro = Math.Min(1, pro);
            DOTween.To(() => ProgressImage.fillAmount, x => ProgressImage.fillAmount = x, pro, 0.1f);
            DOTween.To(() => ProgressImage.fillAmount, x =>
            {
                ProgressText.text = $"{(ProgressImage.fillAmount * 100):0.0}%";
            }, pro, 0.1f);
        }
    }

    private IEnumerator LoadMainScene(UnityAction<float> callback, float percent)
    {
        var lastScene = SceneManager.GetActiveScene();
        AsyncOperationHandle<SceneInstance> currLoadHandle =
            Addressables.LoadSceneAsync("Assets/Scenes/MainScene.unity", LoadSceneMode.Additive);
        while (currLoadHandle.Status == AsyncOperationStatus.None)
        {
            callback?.Invoke(percent + currLoadHandle.PercentComplete * (1 - percent));
            yield return null;
        }

        while (!bgLoaded)
        {
            yield return null;
        }

        if (currLoadHandle.Status == AsyncOperationStatus.Succeeded)
        {
            callback?.Invoke(1);
            yield return new WaitForSeconds(0.5f);
            WeChatMiniGame.ReportGameStart();
            dataService.SaveData(true);
            var msg = new Dictionary<string, object>();
            AnalyticUtils.ReportEvent(AnalyticsKey.SoliEnterGame, msg);
            PayUtils.CheckOrder();

            int uiLoaded = 0;
            GlobalRes.DynamicLoadView(Constants.DoozyView.Gold, () =>
            {
                GoldView.Instance.ResetCanvasPos();
                uiLoaded++;
            });
            GlobalRes.DynamicLoadView(Constants.DoozyView.FxMask, () =>
            {
                uiLoaded++;
            });
            while (uiLoaded < 2)
            {
                yield return null;
            }
            GameCommon.IsEnterGame = true;

            uiLoaded = 0;
            bool isRookie = dataService.IsRookieStatus();
            if (isRookie)
            {
                MergeGameController.Instance.Show(false);
                GlobalRes.DynamicLoadView(Constants.DoozyView.Rookie, () =>
                {
                    GameEventMessage.SendEvent(Constants.DoozyEvent.EnterRookie);
                    uiLoaded++;
                });
            }
            else
            {
                MergeGameController.Instance.Show(true);
                GlobalRes.DynamicLoadView(Constants.DoozyView.Home, () =>
                {
                    GameEventMessage.SendEvent(Constants.DoozyEvent.Loaded);
                    uiLoaded++;
                });
            }
            
            while (uiLoaded < 1)
            {
                yield return null;
            }

            SoundPlayer.Instance.ChangeBgm();
            SceneManager.UnloadSceneAsync(lastScene);
        }

        // yield return null;
    }

    private void CheckGuideLevel()
    {
        if (GameCommon.IsOffMode) return;
        if (dataService.MaxLevel == 1)
        {
            _ = GlobalRes.DynamicLoadView(Constants.DoozyView.Game, () =>
            {
                ViewQueueManager.Instance.ClearQueue();
                LevelUtils.LoadLevel(dataService.MaxLevel, model =>
                {
                    GameUtils.CosumeAndReportStartEvent(dataService.MaxLevel, model);
                });
            });
        }
    }


    IEnumerator GetRequest(string url, Action<bool, string> callback)
    {
        using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
        {
            yield return webRequest.SendWebRequest();

            if (webRequest.result == UnityWebRequest.Result.ConnectionError || webRequest.result == UnityWebRequest.Result.ProtocolError)
            {
                Debug.LogError("Error: " + webRequest.error);
                callback?.Invoke(false, "");
            }
            else
            {
                // Debug.Log("Response: " + webRequest.downloadHandler.text);
                callback?.Invoke(true, webRequest.downloadHandler.text);
            }
        }
    }
}