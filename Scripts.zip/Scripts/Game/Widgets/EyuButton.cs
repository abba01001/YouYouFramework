using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class EyuButton : Selectable, IPointerClickHandler
{
    [Serializable]
    /// <summary>
    /// Function definition for a button click event.
    /// </summary>
    public class ButtonClickedEvent : UnityEvent
    {
    }

    // Event delegates triggered on click.
    [FormerlySerializedAs("onTouchDown")]
    [SerializeField]
    private ButtonClickedEvent m_OnTouchDown = new ButtonClickedEvent();

    [FormerlySerializedAs("onTouchUp")]
    [SerializeField]
    private ButtonClickedEvent m_OnTouchUp = new ButtonClickedEvent();

    protected EyuButton()
    {
    }

    public ButtonClickedEvent onTouchDown
    {
        get { return m_OnTouchDown; }
        set { m_OnTouchDown = value; }
    }

    public ButtonClickedEvent onTouchUp
    {
        get { return m_OnTouchUp; }
        set { m_OnTouchUp = value; }
    }

    public override void OnPointerDown(PointerEventData eventData)
    {
        // 按下刷新當前時間
        base.OnPointerDown(eventData);
        m_OnTouchDown.Invoke();
    }

    public override void OnPointerUp(PointerEventData eventData)
    {
        // 指針擡起，結束開始長按
        base.OnPointerUp(eventData);
        m_OnTouchUp.Invoke();
    }

    public override void OnPointerExit(PointerEventData eventData)
    {
        // 指針移出，結束開始長按，計時長按標志
        base.OnPointerExit(eventData);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
    }
}