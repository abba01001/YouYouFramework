﻿using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class ButtonClickInterval : MonoBehaviour, IPointerClickHandler
{
    public float waitTime = 0f;
    private Button button;
    private Coroutine waitCoroutine;

    private void Awake()
    {
        button = GetComponent<Button>();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (waitTime > 0.0001f && gameObject.activeInHierarchy && waitCoroutine == null)
            waitCoroutine = StartCoroutine(RunClickInterval());
    }

    private void OnDisable()
    {
        if (waitCoroutine != null)
        {
            StopCoroutine(waitCoroutine);
            waitCoroutine = null;
        }
        button.interactable = true;
    }

    private void OnDestroy()
    {
        if (waitCoroutine != null)
        {
            StopCoroutine(waitCoroutine);
            waitCoroutine = null;
        }
    }

    IEnumerator RunClickInterval()
    {
        button.interactable = false;
        yield return new WaitForSecondsRealtime(waitTime);
        waitCoroutine = null;
        button.interactable = true;
    }
}