using QFramework;
using UnityEngine;
using SoliUtils;

public class LiuhaiAdaptor : MonoBehaviour
{
    void Awake()
    {
        TypeEventSystem.Register<ChangeDeviceOrientationEvent>(OnChangeDeviceOrientationEvent);
        DoAdaptor();
    }

    private void OnDestroy()
    {
        TypeEventSystem.UnRegister<ChangeDeviceOrientationEvent>(OnChangeDeviceOrientationEvent);
    }

    void DoAdaptor()
    {
        if (DeviceUtils.HasLiuhai())
        {
            if (Input.deviceOrientation == DeviceOrientation.LandscapeLeft ||
               Input.deviceOrientation == DeviceOrientation.Unknown ||
               Input.deviceOrientation == DeviceOrientation.FaceUp)
            {
                var offsetMin = GetComponent<RectTransform>().offsetMin;
                offsetMin.x = 75;
                GetComponent<RectTransform>().offsetMin = offsetMin;
                var offsetMax = GetComponent<RectTransform>().offsetMax;
                offsetMax.x = 0;
                GetComponent<RectTransform>().offsetMax = offsetMax;
            }
            else if (Input.deviceOrientation == DeviceOrientation.LandscapeRight)
            {
                var offsetMin = GetComponent<RectTransform>().offsetMin;
                offsetMin.x = 0;
                GetComponent<RectTransform>().offsetMin = offsetMin;
                var offsetMax = GetComponent<RectTransform>().offsetMax;
                offsetMax.x = -75;
                GetComponent<RectTransform>().offsetMax = offsetMax;
            }
        }
    }

    void OnChangeDeviceOrientationEvent(GameEvent e)
    {
        DoAdaptor();
    }
}