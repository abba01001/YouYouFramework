using UnityEngine;
using UnityEngine.Events;

public class ParticleSystemsStoppedCallback : MonoBehaviour
{
    private UnityEvent _callback = new UnityEvent();
    public UnityEvent Callback
    {
        get => _callback;
        set
        {
            var particles = GetComponentsInChildren<ParticleSystem>(true);
            _particleCnt = particles.Length;
            _callback = value;
        }
    }
    private int _particleCnt;

    void Start()
    {
        var particles = GetComponentsInChildren<ParticleSystem>(true);
        _particleCnt = particles.Length;

        foreach (var particle in particles)
        {
            var del = particle.gameObject.GetComponent<ParticleSystemStoppedCallback>();
            if (del == null)
            {
                del = particle.gameObject.AddComponent<ParticleSystemStoppedCallback>();
            }
            del.callback = new UnityEvent();
            del.callback.AddListener(OnParticleStopped);
        }
    }

    void OnParticleStopped()
    {
        _particleCnt--;
        if (_particleCnt == 0 && _callback != null)
        {
            _callback.Invoke();
            var particles = GetComponentsInChildren<ParticleSystem>(true);
            _particleCnt = particles.Length;
        }
    }
}