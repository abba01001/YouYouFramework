using System;
using System.Collections.Generic;
using UniRx;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class EyuThroughBtn : Image, IPointerClickHandler, IPointerDownHandler, IPointerUpHandler
{
    [SerializeField]
    private bool hasPassedEvent;
    [SerializeField]
    public Rect TouchRect = Rect.zero;
    public Action Callback;
    [SerializeField]
    public bool IsForce;
    private readonly string MergeTag = "Merge";

    public void OnPointerDown(PointerEventData eventData)
    {
        // Debug.Log("======= OnPointerDown 1");
        if (IsForce && !CheckVaildTouchRect(eventData))
            return;
        Callback?.Invoke();
        PassEvent(eventData, ExecuteEvents.pointerClickHandler);
        // Debug.Log("======= OnPointerDown 2");
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        // Debug.Log("======= OnPointerUp 1");
        if (IsForce && !CheckVaildTouchRect(eventData))
            return;
        // PassEvent(eventData, ExecuteEvents.pointerUpHandler);
        // Debug.Log("======= OnPointerUp 2");
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        // Debug.Log("======= OnPointerClick 1");
        if (!CheckVaildTouchRect(eventData))
            return;
        // PassEvent(eventData, ExecuteEvents.submitHandler);
        // PassEvent(eventData, ExecuteEvents.pointerClickHandler);
        // Debug.Log("======= OnPointerClick 2");
    }

    private bool CheckVaildTouchRect(PointerEventData eventData)
    {
        // Vector2 _pos = Vector2.one;
        // RectTransformUtility.ScreenPointToLocalPointInRectangle(canvas.transform as RectTransform,
        //     eventData.position, canvas.worldCamera, out _pos);

        Vector2 _pos = eventData.position;
        _pos.x -= Screen.width/2;
        _pos.y -= Screen.height/2;

        // Debug.LogError($"======= =============================");
        // Debug.LogError($"======= eventData  {eventData.position}");
        // Debug.LogError($"======= _pos  {_pos}");
        // Debug.LogError($"======= TouchRect  {TouchRect}");
        // Debug.LogError($"{TouchRect.x - TouchRect.width / 2}, {TouchRect.x + TouchRect.width / 2}, {TouchRect.y - TouchRect.height / 2}, {TouchRect.y + TouchRect.height / 2} ");
        // Debug.LogError($"======= check  {_pos.x > TouchRect.x - TouchRect.width / 2},{_pos.x < TouchRect.x + TouchRect.width / 2},{_pos.y > TouchRect.y - TouchRect.height / 2},{_pos.y < TouchRect.y + TouchRect.height / 2}");
        
        if (_pos.x > TouchRect.x - TouchRect.width / 2 && _pos.x < TouchRect.x + TouchRect.width / 2 &&
           _pos.y > TouchRect.y - TouchRect.height / 2 && _pos.y < TouchRect.y + TouchRect.height / 2)
        {
            return true;
        }
        return false;
    }

    public void PassEvent<T>(PointerEventData data, ExecuteEvents.EventFunction<T> function)
        where T : IEventSystemHandler
    {
        if (hasPassedEvent)
            return;

        hasPassedEvent = true;
        List<RaycastResult> results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(data, results);
        GameObject current = data.pointerCurrentRaycast.gameObject;
        GameObject target = null;
        var zIdx = float.MaxValue;
        for (int i = 0; i < results.Count; i++)
        {
            var castObj = results[i].gameObject;
            if (current != castObj && castObj.GetComponent<Button>() != null)
            {
                if (castObj.transform.position.z < zIdx)
                {
                    zIdx = castObj.transform.position.z;
                    target = castObj;
                }
            }
        }
        if (target != null)
        {
            ExecuteEvents.Execute(target, data, function);
        }

        Observable.TimerFrame(1).Subscribe((_) =>
        {
            Vector3 mousePosition = Input.mousePosition;
            Vector2 worldPosition = Camera.main.ScreenToWorldPoint(mousePosition);
            RaycastHit2D[] hits = Physics2D.RaycastAll(worldPosition, Vector2.zero);
            foreach (var hit in hits)
            {
                // Debug.LogError($"====== {hit.collider.gameObject.name}");
                bool isUGUIElement = hit.collider.gameObject.GetComponent<UnityEngine.UI.Graphic>() != null;
                if (!isUGUIElement && hit.collider.CompareTag(MergeTag))
                {
                    hit.collider.gameObject.SendMessage("OnMouseDown", SendMessageOptions.DontRequireReceiver);
                    hit.collider.gameObject.SendMessage("OnMouseUp", SendMessageOptions.DontRequireReceiver);
                    break;
                }
            }
        });

        hasPassedEvent = false;
    }
}
