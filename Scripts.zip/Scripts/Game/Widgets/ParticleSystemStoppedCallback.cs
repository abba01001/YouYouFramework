using UnityEngine;
using UnityEngine.Events;

public class ParticleSystemStoppedCallback : MonoBehaviour
{
    public UnityEvent callback;

    void Start()
    {
        var main = GetComponent<ParticleSystem>().main;
        main.stopAction = ParticleSystemStopAction.Callback;
    }

    public void OnParticleSystemStopped()
    {
        if (callback != null)
        {
            callback.Invoke();
        }
    }
}