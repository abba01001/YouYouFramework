﻿using DG.Tweening;
using System;
using System.Collections.Generic;
using UnityEngine;

public class SpreadViewHandler
{
    public enum Toward
    {
        Up,
        Bottom,
        Left,
        Right,
    }
    private List<SpreadItem> items = new List<SpreadItem>();
    private bool spread = false;
    private Sequence sequence;
    private Action<bool> callBack;
    public bool allVisible = true;//完全可见

    public void SetCallBack(Action<bool> callBack)
    {
        this.callBack = callBack;
    }
    public void AddItem(Transform transform, Toward toward)
    {
        SpreadItem item = new SpreadItem(transform, toward);
        items.Add(item);
    }

    public void ToggleSpread(bool value)
    {
        if (spread == value)
        {
            return;
        }
        allVisible = false;
        spread = value;
        if (sequence != null)
        {
            sequence.Kill(false);
        }
        sequence = DOTween.Sequence();
        if (spread == false)
        {
            sequence.AppendInterval(0.2f);
        }
        
        Sequence sequence1 = DOTween.Sequence();

        for (int i = 0; i < items.Count; i++)
        {
            SpreadItem item = items[i];
            Vector2 endPos = spread ? item.targetPosition : item.initPosition;
            float duration = Vector2.Distance(item.rtf.anchoredPosition, endPos) * 0.6f / item.spreadDistance;
            sequence1.Join(item.rtf.DOAnchorPos(endPos, duration));
        }

        sequence.Append(sequence1);
        sequence.AppendCallback(() => 
        {
            if(callBack != null)
            {
                callBack.Invoke(spread);
            }
            if (!spread)
            {
                allVisible = true;
            }
        });
        sequence.SetAutoKill(true);
    }


    public class SpreadItem
    {
        public RectTransform rtf;
        public Toward toward;
        public Vector2 initPosition;
        public Vector2 targetPosition;
        public float spreadDistance = 250f;
        public SpreadItem(Transform transform, Toward toward)
        {
            this.toward = toward;
            rtf = transform.GetComponent<RectTransform>();
            initPosition = rtf.anchoredPosition;
            targetPosition = GetTargetPos();
        }



        private Vector2 GetTargetPos()
        {
            if (toward == Toward.Up)
            {
                return initPosition + new Vector2(0, spreadDistance);
            }
            else if (toward == Toward.Bottom)
            {
                return initPosition + new Vector2(0, -spreadDistance);
            }
            else if (toward == Toward.Left)
            {
                return initPosition + new Vector2(-spreadDistance, 0);
            }
            else if (toward == Toward.Right)
            {
                return initPosition + new Vector2(spreadDistance, 0);
            }
            return Vector2.zero;
        }


    }

}