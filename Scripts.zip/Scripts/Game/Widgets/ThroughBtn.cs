using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ThroughButton : Button, IPointerDownHandler
{
    public Action EnterEvent;

    public override void OnPointerDown(PointerEventData eventData)
    {
        EnterEvent?.Invoke();
        // List<RaycastResult> results = new List<RaycastResult>();
        // EventSystem.current.RaycastAll(eventData, results);
    }

}
