
using UnityEngine;

public class MeshRenderSort : MonoBehaviour
{
    public int SortingOrder;
    private void Awake()
    {
        GetComponent<MeshRenderer>().sortingOrder = SortingOrder;
    }
}