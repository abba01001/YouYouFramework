using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public abstract class ListViewAdapter : MonoBehaviour
{
    [HideInInspector]
    public ListView listview;

    public virtual void Initialize()
    {

    }

    public abstract int GetCount();

    public abstract void FillItemData(ListViewCell item, int cellindex);

    public abstract int GetCellPrefabIndex(int index);

    public virtual int GetCellPrefabIndex(object data)
    {
        return 0;
    }

    public virtual bool IsTitleCell(int index)
    {
        return false;
    }

    public virtual bool IsTitleExpandInDefault(int index)
    {
        return true;
    }
}