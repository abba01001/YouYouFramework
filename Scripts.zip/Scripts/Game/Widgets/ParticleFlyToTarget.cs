using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Events;

[RequireComponent(typeof(ParticleSystem))]
public class ParticleFlyToTarget : MonoBehaviour
{
    public Transform target;
    public UnityEvent OnParticleFlyComplete = new UnityEvent();
    public UnityEvent OnParticleEnter = new UnityEvent();
    private ParticleSystem.Particle[] _particles;
    private ParticleSystem _particleSystem;
    private Vector3 targetPos;

    private void Awake()
    {
        _particleSystem = GetComponent<ParticleSystem>();
        _particles = new ParticleSystem.Particle[_particleSystem.main.maxParticles];
    }

    private void OnParticleSystemStopped()
    {
        Invoke("Remove", 1f);
    }

    private void Remove()
    {
        Destroy(gameObject);
    }

    private void Update()
    {
        if (_particleSystem != null)
        {
            int arrCount = _particleSystem.GetParticles(_particles); //获取到当前激活的粒子  

            if (arrCount > 0)
            {
                Vector3 pos = targetPos;

                for (int i = 0; i < arrCount; i++)
                {
                    ParticleSystem.Particle p = _particles[i];
                    _particles[i].position =
                        Vector3.MoveTowards(p.position, pos,
                            (p.startLifetime - p.remainingLifetime) / p.startLifetime);
                }

                _particleSystem.SetParticles(_particles, arrCount); //再把更新过的粒子数据设置回去  
            }
        }
    }

    void OnParticleTrigger()
    {
        // particles
        List<ParticleSystem.Particle> enter = new List<ParticleSystem.Particle>();

        // get
        int numEnter = _particleSystem.GetTriggerParticles(ParticleSystemTriggerEventType.Enter, enter);

        if (numEnter > 0) OnParticleEnter.Invoke();

        if (!_particleSystem.isEmitting && _particleSystem.particleCount == 0) OnParticleFlyComplete.Invoke();

        //            Debug.Log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ partilce count:" + ps.isEmitting + "," + ps.particleCount);
    }

    public void burst(int count, Vector3 startPos, Vector3 targetPos)
    {
        //Debug.Log("diamond to "+targetPos);
        transform.position = startPos;
        this.targetPos = targetPos;
        target.transform.position = targetPos;
        ParticleSystem.MainModule m = _particleSystem.main;
        //m.maxParticles = count;
        if (!_particleSystem.isPlaying)
        {
            m.duration = count / _particleSystem.emission.rateOverTime.constant;
        }

        _particleSystem.Play();
    }
}