using UnityEngine;
using SoliUtils;

public class EyuAudioSource : MonoBehaviour
{
    public AudioClip clip;
    private void OnEnable()
    {
        SoundPlayer.Instance.Play(clip);
    }
}