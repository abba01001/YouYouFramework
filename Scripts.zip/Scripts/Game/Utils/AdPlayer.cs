using System;
using System.Collections.Generic;
using UniRx;

namespace SoliUtils
{
    public class AdPlayer
    {
        public static string TestRewardAd = "test_reward_ad";
        public static string ShopRewardAd = "shop_reward_ad";
        public static string HarvestRewardAd = "harvest_reward_ad";
        public static string WheelRewardAd = "wheel_reward_ad";
        public static string BrokenRewardAd = "broken_reward_ad";
        public static string CoinRewardAd = "coin_reward_ad";
        public static string FreeCoinRewardAd = "free_coin_reward_ad";
        public static string FreeItemRewardAd = "free_item_reward_ad";
        public static string EnergyRewardAd = "energy_reward_ad";

        public static string InsetAd = "insert_ad";

        private static string RewardPlaceId;
        private static Action RewardCallback;

        private static void ShowRewardAd(string adPlaceId)
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            var msg = new Dictionary<string, object>
            {
                { AnalyticsKey.PurchaseScene, GameController.Instance.IsPlaying ? "game" : "home" },
                { AnalyticsKey.PurchaseCurrentStage, dataService.MaxLevel },
                { AnalyticsKey.PurchaseCurrentCoin, dataService.Coin },
                { AnalyticsKey.PurchaseCurrentWild, dataService.GetPropNum((int)PropEnum.FreeJoker) },
                { AnalyticsKey.PurchaseCurrentUndo, dataService.GetPropNum((int)PropEnum.FreeUndo) },
                { AnalyticsKey.PurchaseCurrentFill, dataService.GetPropNum((int)PropEnum.FreeBuyCard) },
                { AnalyticsKey.PurchaseCurrentPowerupDelthree, dataService.GetPropNum((int)PropEnum.ItemEliminate) },
                { AnalyticsKey.PurchaseCurrentPowerupWild, dataService.GetPropNum((int)PropEnum.ItemJoker) },
                { AnalyticsKey.PurchaseCurrentPowerupCactus, dataService.GetPropNum((int)PropEnum.ItemCactus) },
                { AnalyticsKey.PurchaseTime, dataService.CumulativeRechargeCount },
                { AnalyticsKey.AdPlaceId, adPlaceId },
            };
            AnalyticUtils.ReportEvent(AnalyticsKey.SoliAdClick, msg);
            
            WeChatMiniGame.ShowRewardAd(adPlaceId);
        }

        public static void ShowTestAd(Action callback)
        {
            RewardPlaceId = TestRewardAd;
            RewardCallback = callback;
            ShowRewardAd(RewardPlaceId);
        }
        
        public static void ShowWheelAd(Action callback)
        {
            RewardPlaceId = WheelRewardAd;
            RewardCallback = callback;
            ShowRewardAd(RewardPlaceId);
        }
        
        public static void ShowShopAd(Action callback)
        {
            RewardPlaceId = ShopRewardAd;
            RewardCallback = callback;
            ShowRewardAd(RewardPlaceId);
        }
        
        public static void ShowHarvestAd(Action callback)
        {
            RewardPlaceId = HarvestRewardAd;
            RewardCallback = callback;
            ShowRewardAd(RewardPlaceId);
        }
        
        public static void ShowCoinAd(Action callback)
        {
            RewardPlaceId = CoinRewardAd;
            RewardCallback = callback;
            ShowRewardAd(RewardPlaceId);
        }
        
        public static void ShowBrokenAd(Action callback)
        {
            RewardPlaceId = BrokenRewardAd;
            RewardCallback = callback;
            ShowRewardAd(RewardPlaceId);
        }
        
        public static void ShowFreeCoinAd(Action callback)
        {
            RewardPlaceId = FreeCoinRewardAd;
            RewardCallback = callback;
            ShowRewardAd(RewardPlaceId);
        }

        public static void ShowEnergyAd(Action callback)
        {
            RewardPlaceId = EnergyRewardAd;
            RewardCallback = callback;
            ShowRewardAd(RewardPlaceId);
        }

        public static void ShowFreeItemAd(Action callback)
        {
            FxMaskView.Instance.BlockOperation(true);
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            if (dataService.IsFreeAd())
            {
                callback?.Invoke();
                FxMaskView.Instance.BlockOperation(false);
                return;
            }
            Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe(_ =>
            {
                FxMaskView.Instance.BlockOperation(false);
            });
            RewardPlaceId = FreeItemRewardAd;
            RewardCallback = callback;
            ShowRewardAd(RewardPlaceId);
        }

        public static void ShowInterAd(string adPlaceId, Action<string> callback)
        {
            
        }

        public static void OnRewardAd(string place_id)
        {
            if (RewardPlaceId == place_id)
            {
                RewardCallback?.Invoke();
            }

            RewardPlaceId = "";
            RewardCallback = null;
            FxMaskView.Instance.BlockOperation(false);
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            var msg = new Dictionary<string, object>
            {
                { AnalyticsKey.PurchaseScene, GameController.Instance.IsPlaying ? "game" : "home" },
                { AnalyticsKey.PurchaseCurrentStage, dataService.MaxLevel },
                { AnalyticsKey.PurchaseCurrentCoin, dataService.Coin },
                { AnalyticsKey.PurchaseCurrentWild, dataService.GetPropNum((int)PropEnum.FreeJoker) },
                { AnalyticsKey.PurchaseCurrentUndo, dataService.GetPropNum((int)PropEnum.FreeUndo) },
                { AnalyticsKey.PurchaseCurrentFill, dataService.GetPropNum((int)PropEnum.FreeBuyCard) },
                { AnalyticsKey.PurchaseCurrentPowerupDelthree, dataService.GetPropNum((int)PropEnum.ItemEliminate) },
                { AnalyticsKey.PurchaseCurrentPowerupWild, dataService.GetPropNum((int)PropEnum.ItemJoker) },
                { AnalyticsKey.PurchaseCurrentPowerupCactus, dataService.GetPropNum((int)PropEnum.ItemCactus) },
                { AnalyticsKey.PurchaseTime, dataService.CumulativeRechargeCount },
                { AnalyticsKey.AdPlaceId, place_id },
            };
            AnalyticUtils.ReportEvent(AnalyticsKey.SoliAdShow, msg);
        }
    }
}
