using Doozy.Engine.UI;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.U2D;
using Object = UnityEngine.Object;
using YieldAwaitable = System.Runtime.CompilerServices.YieldAwaitable;

namespace SoliUtils
{
    /// <summary>
    /// 全局加载类，外面需要动态加载资源的地方统一调用这个
    /// 在这里面统一控制加载方式，方便统一管理
    /// </summary>
    public static class GlobalRes
    {
        private static Dictionary<string, GameObject> _resPrefabMap = new Dictionary<string, GameObject>();
        private static Dictionary<string, Sprite> _resSpriteMap = new Dictionary<string, Sprite>();
        private static Dictionary<string, SpriteAtlas> _resAtlasMap = new Dictionary<string, SpriteAtlas>();
        private static Dictionary<string, Texture2D> _resTex2dMap = new Dictionary<string, Texture2D>();

        public static void AddPreloadResPrefab<T>(string key, T res)
        {
            switch (res)
            {
                case GameObject gameObject:
                    _resPrefabMap.TryAdd(key, gameObject);
                    break;
                case Sprite sprite:
                    _resSpriteMap.TryAdd(key, sprite);
                    break;
                case SpriteAtlas atlas:
                    _resAtlasMap.TryAdd(key, atlas);
                    break;
                case Texture2D tex2d:
                    _resTex2dMap.TryAdd(key, tex2d);
                    break;
            }
        }


        public static T GetPreloadResPrefab<T>(string key) where T : Object
        {
            if (typeof(T).Name == "GameObject")
            {
                if (_resPrefabMap.TryGetValue(key, out GameObject value))
                {
                    return value as T;
                }
            }
            else if (typeof(T).Name == "Sprite")
            {
                if (_resSpriteMap.TryGetValue(key, out Sprite value))
                {
                    return value as T;
                }
            }
            else if (typeof(T).Name == "SpriteAtlas")
            {
                if (_resAtlasMap.TryGetValue(key, out SpriteAtlas value))
                {
                    return value as T;
                }
            }
            else if (typeof(T).Name == "Texture2D")
            {
                if (_resTex2dMap.TryGetValue(key, out Texture2D value))
                {
                    return value as T;
                }
            }
            return null;
        }

        private static Dictionary<string, GameObject> _resMap = new Dictionary<string, GameObject>();

        public static async Task<YieldAwaitable> PreLoad(List<string> keys)
        {
            foreach (var key in keys)
            {
                if (!_resMap.ContainsKey(key))
                {
                    var handle = Addressables.LoadAssetAsync<GameObject>(key);
                    await handle.Task;
                    if (handle.IsDone)
                    {
                        _resMap.TryAdd(key, handle.Result);
                        Debug.Log($"=========== PreLoad key = {key}");
                    }
                }
            }

            return Task.Yield();
        }

        public static void RemovePreLoad(List<string> keys)
        {
            // while (keys.Count > 0)
            // {
            //     var key = keys[0];
            //     if (_resMap.TryGetValue(key, out var value))
            //     {
            //         Addressables.Release(value);
            //     }
            //     _resMap.Remove(key);
            // }
        }

        public static GameObject InstantiatePre(string key, Transform trans = null)
        {
            // if (_resMap.TryGetValue(key, out GameObject value))
            // {
            //     return GameObject.Instantiate(value, trans);
            // }
            var obj = GetPreloadResPrefab<GameObject>(key);
            if (obj)
            {
                return GameObject.Instantiate(obj, trans);
            }

            Debug.LogError($"InstantiatePre failed key = {key}");
            return null;
        }

        public static async Task<AsyncOperationHandle<T>> LoadAssetAsync<T>(string key) where T : Object
        {
            var handle = Addressables.LoadAssetAsync<T>(key);
            // Debug.Log(key);
            await handle.Task;
            if (handle.IsDone)
            {
                AddPreloadResPrefab<T>(key, handle.Result);
            }
            return handle;
        }


        #region 全局通用加载方式


        public static T Load<T>(string path) where T : Object
        {
            var target = GetPreloadResPrefab<T>(path);
            if (target)
            {
                return target;
            }
            return AddressableUtils.Load<T>(path);
        }

        public static void LoadAsset<T>(string path, Action<T> callback) where T : Object
        {
            AddressableUtils.LoadAsset<T>(path, callback);
        }

        #endregion

        #region 局部加载方式

        /// <summary>
        /// 每次都可以单独设置加载方式，不影响全局方法，
        /// 这里是为了满足个别需要加载 Resources 下资源的情况
        /// </summary>
        public static T Load<T>(string path, bool loadByAddressable) where T : Object
        {
            return loadByAddressable ? AddressableUtils.Load<T>(path) : Resources.Load<T>(path);
        }

        public static Object Load(string path, bool loadByAddressable)
        {
            return loadByAddressable ? AddressableUtils.Load<Object>(path) : Resources.Load(path);
        }

        #endregion

        #region 实例化

        public static GameObject Instantiate(string path, Transform transform = null)
        {
            var target = GetPreloadResPrefab<GameObject>(path);
            if (target)
            {
                return GameObject.Instantiate(target, transform);
            }
            return AddressableUtils.Instantiate<GameObject>(path);
        }



        public static void Instantiate(string path, Action<GameObject> callback)
        {
            AddressableUtils.Instantiate(path, o => { callback?.Invoke(o); });
        }

        #endregion

        #region 预加载

        private const string label_cards = "cards";
        private const string label_preload_texture = "preload_texture";
        private const string label_preload_gameobject = "preload_gameobject";
        private const string label_preload_spriteatlas = "preload_spriteatlas";
        private const string label_preload_materials = "preload_materials";

        /// <summary>
        /// 预加载首页资源
        /// </summary>
        public static async Task PreLoadHomeRes()
        {
            Debug.Log($">>>>>>> PreLoadHomeRes --- Start .");
            await AddressableUtils.LoadByLabel<Texture2D>(label_preload_texture);
            await AddressableUtils.LoadByLabel<GameObject>(label_preload_gameobject);
            await AddressableUtils.LoadByLabel<SpriteAtlas>(label_preload_spriteatlas);
            await AddressableUtils.LoadByLabel<Material>(label_preload_materials);
            Debug.Log($">>>>>>> PreLoadHomeRes --- Finish .");
        }

        private static string DealViewName(string viewName)
        {
            int lastIndex = viewName.LastIndexOf('/');
            string name = lastIndex >= 0 ? viewName.Substring(lastIndex + 1) : viewName;
            return string.Format("Assets/Res/Prefabs/View/View - {0}.prefab", name);
        }

        /// <summary>
        /// 动态加载View
        /// View界面加载后不会销毁
        /// </summary>
        public static async Task DynamicLoadView(string viewName, Action action = null)
        {
            var view = UIView.GetViews(Doozy.Engine.UI.Base.NamesDatabase.GENERAL, viewName);
            if (view.Count != 0)
            {
                action?.Invoke();
            }
            else
            {
                var handle = await GlobalRes.LoadAssetAsync<GameObject>(DealViewName(viewName));
                if (handle.Status == AsyncOperationStatus.Succeeded)
                {
                    Transform parent = GameObject.Find("Canvas - MasterCanvas").transform;
                    GameObject gameObject = GameObject.Instantiate(handle.Result, Vector3.zero, Quaternion.identity, parent);
                    action?.Invoke();
                }
                else
                {
                    GameUtils.LogError($"资源加载失败{DealViewName(viewName)}");
                }
            }
        }

        public static async Task<GameObject> DynamicLoadPrefab(string assetPath, Action<GameObject> startAction = null, bool delayDestroy = false, float delayTime = 0f)
        {
            var obj = GetPreloadResPrefab<GameObject>(assetPath);
            if (obj != null)
            {
                GameObject temp = GameObject.Instantiate(obj, obj.transform.position, Quaternion.identity);
                startAction?.Invoke(temp);
                if (delayDestroy)
                {
                    GameObject.Destroy(temp, delayTime);
                }
                return temp;
            }
            else
            {
                var handle = await GlobalRes.LoadAssetAsync<GameObject>(assetPath);
                if (handle.Status == AsyncOperationStatus.Succeeded)
                {
                    GameObject temp = GameObject.Instantiate(handle.Result, Vector3.zero, Quaternion.identity);
                    startAction?.Invoke(temp);
                    if (delayDestroy)
                    {
                        GameObject.Destroy(temp, delayTime);
                    }
                    return temp;
                }
                else
                {
                    GameUtils.LogError($"资源加载失败{assetPath}");
                }
            }
            return null;
        }

        private static bool _otherResHasLoaded = false;

        /// <summary>
        /// 到首页后再加载其他资源
        /// </summary>
        public static async Task LoadOtherRes()
        {
            if (_otherResHasLoaded) return;
            _otherResHasLoaded = true;
            Debug.Log($">>> GlobalRes >> LoadOtherRes Start ...");
            await GameObjManager.Instance.PreLoad();
            GameObjManager.Instance.LoadCardsObj();
            await AddressableUtils.LoadByLabel<Texture2D>(label_cards);
            Debug.Log($">>> GlobalRes >> LoadOtherRes Finish ...");
        }

        public static async Task<RuntimeAnimatorController> DynamicLoadAnimator(string assetPath, Action<RuntimeAnimatorController> action = null)
        {
            var handle = await GlobalRes.LoadAssetAsync<RuntimeAnimatorController>(assetPath);
            if (handle.Status == AsyncOperationStatus.Succeeded)
            {
                action?.Invoke(handle.Result);
                return handle.Result;
            }
            return handle.Result;
        }

        #endregion

        #region 资源释放

        public static async void Release<T>(string path, float delayTime = 0f) where T : Object
        {
            await UniTask.Delay((int)(delayTime * 1000));
            AddressableUtils.Release<T>(path);
        }

        #endregion
    }
}