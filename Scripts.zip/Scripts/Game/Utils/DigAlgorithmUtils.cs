using System;
using UnityEngine;
using System.Collections.Generic;
using SoliUtils;

public class DigAlgorithmUtils
{
    private int XAxis { get; set; } // X轴单位长度
    private int YAxis { get; set; } // Y轴单位长度
    private int CellSize { get; set; } // 每个格子的大小
    private int[,] GridPanel { get; set; }//格子面板
    private Dictionary<DigGridRewardModel,Vector2> RecordItemPos { get; set; }//计算后得到的奖励坐标
    private List<DigGridRewardModel> RewardItemList { get; set; }//奖励表
    private int TryRandomMaxCount = 100;//尝试随机次数

    public void InitParams(int xAxis,int yAxis,int cellSize,List<DigGridRewardModel> rewards)
    {
        XAxis = xAxis;
        YAxis = yAxis;
        CellSize = cellSize;
        GridPanel = new int[XAxis, YAxis];
        RewardItemList = rewards;
        RecordItemPos = new Dictionary<DigGridRewardModel,Vector2>();
        TryRandomlyPlaceItems();
    }

    public Dictionary<int,Vector2> GetUnitPosList()
    {
        Dictionary<int,Vector2> posDic = new Dictionary<int,Vector2>();
        int index = 0;
        foreach (var pos in RecordItemPos)
        {
            posDic.Add(pos.Key.PropId,new Vector2(pos.Value.x,pos.Value.y));
            index++;
        }
        return posDic;
    }

    // 尝试随机放置物品
    private void TryRandomlyPlaceItems()
    {
        RecordItemPos.Clear();
        HashSet<Vector2> availablePositions = new HashSet<Vector2>();
        for (int x = 0; x < XAxis; x++)
        {
            for (int y = 0; y < YAxis; y++)
            {
                availablePositions.Add(new Vector2(x, y));
            }
        }

        bool allItemsPlaced = true;
        foreach (var item in RewardItemList)
        {
            bool placed = false;
            HashSet<Vector2> attempts = new HashSet<Vector2>(availablePositions);
            for (int attempt = 0; attempt < Mathf.Min(availablePositions.Count, TryRandomMaxCount); attempt++)
            {
                if (attempts.Count == 0) break;
                Vector2 pos = GetRandomPos(attempts);
                int x = (int) pos.x;
                int y = (int) pos.y;
                attempts.Remove(pos);
                if (CanPlace(item, x,y))
                {
                    PlaceItem(item, x, y);
                    RemoveOccupiedPositions(item,pos,ref availablePositions);
                    RecordItemPos.Add(item,new Vector2(pos.x,pos.y));
                    placed = true;
                    break;
                }
            }
            if (!placed)
            {
                allItemsPlaced = false;
                break;
            }
        }

        if (!allItemsPlaced)
        {
            RecordItemPos.Clear();
            ResetGridPanel();
            GameUtils.LogError("随机放置失败，尝试第二方案...");
            TryPlaceItems();
        }
    }
    
    //移除该奖励占领的坐标
    private void RemoveOccupiedPositions(DigGridRewardModel item,Vector2 startPos,ref HashSet<Vector2> availablePositions)
    {
        for (int i = 0; i < item.Width; i++)
        {
            for (int j = 0; j < item.Height; j++)
            {
                Vector2 pos = new Vector2(startPos.x + i, startPos.y + j);
                availablePositions.Remove(pos);
            }
        }
    }
    
    private void ResetGridPanel()
    {
        Array.Clear(GridPanel, 0, GridPanel.Length);
    }

    //如果这个方案都没走成功，只有可能是奖励配置放不进去格子里
    private void TryPlaceItems()
    {
        foreach (var item in RewardItemList)
        {
            bool placed = false;
            for (int x = 0; x < XAxis; x++)
            {
                for (int y = 0; y < YAxis; y++)
                {
                    if (CanPlace(item, x, y))
                    {
                        PlaceItem(item, x, y);
                        RecordItemPos.Add(item,new Vector2(x,y));
                        placed = true;
                        break;
                    }
                }
                if (placed) break;
            }
            if (!placed)
            {
                RecordItemPos.Clear();
                GameUtils.LogError($"奖励配置方案有问题");
                return;
            }
        }
    }

    // 能否放置
    private bool CanPlace(DigGridRewardModel digGridRewardModel, int x, int y)
    {
        //是否超出右边界 || 上边界
        if (x + digGridRewardModel.Width > XAxis || y + digGridRewardModel.Height > YAxis)
        {
            return false;
        }

        for (int i = x; i < x + digGridRewardModel.Width; i++)
        {
            for (int j = y; j < y + digGridRewardModel.Height; j++)
            {
                if (GridPanel[i, j] != 0)
                {
                    return false;
                }
            }
        }
        return true;
    }

    private void PlaceItem(DigGridRewardModel digGridRewardModel, int x, int y)
    {
        for (int i = x; i < x + digGridRewardModel.Width; i++)
        {
            for (int j = y; j < y + digGridRewardModel.Height; j++)
            {
                GridPanel[i, j] = digGridRewardModel.Id;
            }
        }
    }

    private Vector2 GetRandomPos(HashSet<Vector2> set)
    {
        int randomIndex = GameUtils.RandomRange(0, set.Count);
        foreach (var element in set)
        {
            if (randomIndex-- == 0) return element;
        }
        return default;
    }

    public void PrintGridPanel()
    {
        int index = 0;
        foreach (var pos in RecordItemPos)
        {
            GameUtils.LogError($"Item宽{RewardItemList[index].Width}高{RewardItemList[index].Height}",$",索引{pos.Value.x}--{pos.Value.y}",
                $"坐标{CellSize * pos.Value.x},{CellSize * pos.Value.y}");
            index++;
        }
    }
    
}