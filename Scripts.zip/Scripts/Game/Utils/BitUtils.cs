
namespace SoliUtils
{
    class BitUtils 
    {
        public static void Flag(ref long value, int bit)
        {
            value |= (1L << bit);
        }

        public static void UnFlag(ref long value, int bit)
        {
            value &= ~(1L << bit);
        }

        public static bool IsFlag(long value, int bit)
        {
            return (value >> bit & 1) == 1;
        }
    }
}
