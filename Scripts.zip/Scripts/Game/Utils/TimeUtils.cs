using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Activities;
using UnityEngine;
using UnityEngine.Networking;
using Debug = UnityEngine.Debug;

namespace SoliUtils
{
    public static class TimeUtils
    {
        private static DateTime severTime = DateTime.Now;
        private static DateTime GMT = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);//标准时间
        private static DateTime local_MT = GMT.ToLocalTime();

        public static int UtcNow()
        {
            return ActivityManager.Instance.GetActivitySeverTime();
            // return ConvertTimestamp(GetUtcNowDateTime());
        }

        public static long Timestamp()
        {
            long timestamp = System.DateTime.UtcNow.Ticks / System.TimeSpan.TicksPerMillisecond;
            return timestamp;
        }

        public static DateTime GetUtcNowDateTime()
        {
            return DateTimeOffset.UtcNow.DateTime;
            //return saverTime.AddSeconds(Time.realtimeSinceStartup);
        }

        public static int GetOffsetDays(int time1, int time2)
        {
            var dt1 = DateTimeOffset.FromUnixTimeSeconds(time1);
            var dt2 = DateTimeOffset.FromUnixTimeSeconds(time2);
            return Convert.ToInt32(Math.Floor(dt1.Subtract(dt2).TotalDays));
        }

        public static int GetDayEndTime(DateTime time)
        {
            time = time.ToLocalTime();
            DateTime endTime = new DateTime(time.Year, time.Month, time.Day, 23, 59, 59, DateTimeKind.Local);
            return ConvertTimestamp(endTime);
        }

        public static bool IsSameDay(int time1, int time2)
        {
            DateTime dt1 = IntToDateTime(time1);
            DateTime dt2 = IntToDateTime(time2);
            return dt1.Date == dt2.Date;
        }

        public static int OneDaySeconds()
        {
            return 86400;
        }

        public static int GetDayOfWeek(DateTime date)
        {
            int dayOfWeek = Convert.ToInt32(date.DayOfWeek);
            return dayOfWeek == 0 ? 7 : dayOfWeek;
        }

        public static int GetSecondsOfDay(DateTime date)
        {
            return Convert.ToInt32(date.TimeOfDay.TotalSeconds);
        }

        public static DateTime GetServerTime()
        {
            return severTime;
        }

        public static int GetServerTimeUtc()
        {
            TimeSpan timeSpan = severTime.ToUniversalTime() - GMT;
            // #if !UNITY_EDITOR
            //  timeSpan = timeSpan + TimeSpan.FromHours(8);
            // #endif
            return Convert.ToInt32(timeSpan.TotalSeconds);
        }

        public static TimeSpan GetNowDiffTime(int time)
        {
            DateTime dt = GMT.AddSeconds(time);
            return dt - DateTime.UtcNow;
        }

        public static string GetDateFromTimestamp(int timpStamp, string format)
        {
            DateTime startTime = TimeZoneInfo.ConvertTime(GMT, TimeZoneInfo.Local);
            DateTime dt = startTime.AddSeconds(timpStamp);
            return dt.ToString(format);
        }

        public static int StringDate2Second(string date, string format)
        {
            DateTime dt = DateTime.ParseExact(date, format, System.Globalization.CultureInfo.CurrentCulture);
            TimeSpan timeSpan = dt - TimeZone.CurrentTimeZone.ToLocalTime(GMT);
            return Convert.ToInt32(timeSpan.TotalSeconds);
        }

        public static int StringTimeToSeconds(string time)
        {
            // 将时间字符串按照":"分割
            string[] parts = time.Split(':');

            // 提取时、分、秒
            int hours = int.Parse(parts[0]);
            int minutes = int.Parse(parts[1]);
            int seconds = int.Parse(parts[2]);

            // 计算总秒数
            int totalSeconds = hours * 3600 + minutes * 60 + seconds;
            return totalSeconds;
        }

        public static DateTime IntToDateTime(int time) // time 单位 s
        {
            return local_MT.AddSeconds(time);
        }

        public static int DateTimeToLong(DateTime time) // 返回 单位 s
        {
            if (time.Kind == DateTimeKind.Utc)
                return (int)(time - GMT).TotalSeconds;
            else
                return (int)(time - local_MT).TotalSeconds;
        }

        public static string SecondFormatDdHhMmSs(int second)
        {
            StringBuilder sb = new StringBuilder();
            int day = second / 86400;
            int hour = second % 86400 / 3600;
            int min = second % 86400 % 3600 / 60;
            int sec = second % 60;
            if (day >= 1)
            {
                sb.Append(day).Append("d ");
            }

            if (hour < 10)
            {
                sb.Append($"0{hour}");
            }
            else
            {
                sb.Append(hour);
            }

            sb.Append(":");
            if (min < 10)
            {
                sb.Append($"0{min}");
            }
            else
            {
                sb.Append(min);
            }

            sb.Append(":");
            if (sec < 10)
            {
                sb.Append($"0{sec}");
            }
            else
            {
                sb.Append(sec);
            }

            return sb.ToString();
        }

        public static string SecondFormatDdHh(int second)
        {
            StringBuilder sb = new StringBuilder();
            int day = second / 86400;
            int hour = second % 86400 / 3600;
            int min = second % 86400 % 3600 / 60;
            int sec = second % 60;

            sb.Append(day).Append("d ");
            if (hour < 10)
            {
                sb.Append($"0{hour}");
            }
            else
            {
                sb.Append(hour);
            }

            sb.Append("h ");
            //        if (min < 10)
            //        {
            //            str += "0" + min.ToString();
            //        }
            //        else
            //        {
            //            str += min.ToString();
            //        }
            //
            //        str += " m";
            //        if (sec < 10)
            //        {
            //            str += "0" + sec.ToString();
            //        }
            //        else
            //        {
            //            str += sec.ToString();
            //        }

            //        str += "s";
            return sb.ToString();
        }

        public static string SmartSecondFormatString(int second)
        {
            int day = second / 86400;
            if (day >= 1)
            {
                // 多余 1 天
                return SecondFormatDdHh(second);
            }
            // 不足 1 天
            return SecondFormatDdHhMmSs(second);
        }

        public static int ConvertTimestamp(DateTime time)
        {
            if (time.Kind != DateTimeKind.Local)
                time = time.ToLocalTime();
            double intResult = (time - local_MT).TotalSeconds;
            return (int)Math.Round(intResult, 0);
        }

        public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            // Unix时间戳是秒数，需要转换为DateTime
            DateTime utcDateTime = DateTimeOffset.FromUnixTimeSeconds((long)unixTimeStamp).UtcDateTime;

            // 手动创建中国标准时间
            TimeZoneInfo cstZone = TimeZoneInfo.CreateCustomTimeZone("China Standard Time", TimeSpan.FromHours(8), "China Standard Time", "China Standard Time");

            // 将UTC时间转换为指定时区的时间
            DateTime targetDateTime = TimeZoneInfo.ConvertTimeFromUtc(utcDateTime, cstZone);

            return targetDateTime;
        }

        //获取注册天数
        public static int GetRegisterDay(int registerTime)
        {
            DateTime nowDate = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivitySeverTime());
            DateTime registerDate = TimeUtils.IntToDateTime(registerTime);
            int temp1 = TimeUtils.DateTimeToLong(new DateTime(registerDate.Year, registerDate.Month, registerDate.Day, 0, 0, 0, DateTimeKind.Local));
            int temp2 = TimeUtils.DateTimeToLong(new DateTime(nowDate.Year, nowDate.Month, nowDate.Day, 23, 59, 59, DateTimeKind.Local));
            return Mathf.CeilToInt((float)(temp2 - temp1) / (24 * 60 * 60));
        }

        public static class NetTimeUtil
        {
            public static readonly bool IS_OS = true;
            public static bool GetNetTime { private set; get; }

            private static List<string> TIME_URL_LIST = new List<string>
            {
                "https://qxjlapi.6666net.com/time",
            };

            static IEnumerator GetRequest(string url, Action<bool, string> callback)
            {
                using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
                {
                    yield return webRequest.SendWebRequest();

                    if (webRequest.result == UnityWebRequest.Result.ConnectionError || webRequest.result == UnityWebRequest.Result.ProtocolError)
                    {
                        Debug.LogError($"url:{url} Error: " + webRequest.error);
                        callback?.Invoke(false, "");
                    }
                    else
                    {
                        // Debug.Log("Response: " + webRequest.downloadHandler.text);
                        callback?.Invoke(true, webRequest.downloadHandler.text);
                    }
                }
            }

            public static void ReqNetDateTime(int ask_time = 10)
            {
                if (GameCommon.IsOffMode) return;

                if (ask_time <= 0)
                    return;
                ask_time--;

                var dataSrv = MainContainer.Container.Resolve<IDataService>();
                string uid = dataSrv.UserId;
                string url = Constants.ApiUrl + "/time";
                StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
                {
                    if (ret)
                    {
                        Debug.Log("网络时间: " + json);
                        DateTime dateTime = TimeUtils.UnixTimeStampToDateTime(Convert.ToInt32(json));
                        GameCommon.HasServerTime = true;
                        severTime = dateTime;
                        GetNetTime = true;
                    }
                    else
                    {
                        if (ask_time > 0)
                        {
                            ReqNetDateTime(ask_time);
                        }
                    }
                }));
            }

            public static void InitNetDateTime(MonoBehaviour sceneMono)
            {
                int index = 0;
                bool waitResult = false;
                List<string> urlList = TIME_URL_LIST;
                severTime = DateTime.Now; // 先默认给一个本地时间，再去请求网络时间，请求到之后再替换

                if (GameCommon.IsOffMode)
                    return;

                void Fun()
                {
                    Debug.Log($">>> InitNetDateTime >> Fun > index:{index}, listCount:{urlList.Count}");
                    if (index == urlList.Count)
                    {
                        severTime = DateTime.Now;
                        GetNetTime = true;
                        return;
                    }

                    if (waitResult == false)
                    {
                        waitResult = true;
                        string url = urlList[index];
                        index++;
                        Debug.Log($">>> Ready To Request >> Url:{url}");
                        GetNetDateTime(sceneMono, url, (state, dateTime) =>
                        {
                            Debug.Log($">>> InitNetDateTime >> GetNetDateTime > state:{state} dateTime:{dateTime}");
                            waitResult = false;
                            if (state)
                            {
                                severTime = dateTime;
                                GetNetTime = true;
                                Debug.Log($">>> InitNetDateTime >> serverTime:{severTime}");
                            }
                            else
                                Fun();
                        });
                    }
                }
#if !UNITY_EDITOR || true
                Fun();
#endif
            }

            private static void GetNetDateTime(MonoBehaviour sceneMono, string url, Action<bool, DateTime> action)
            {
                sceneMono.StartCoroutine(Get(url, action));
            }

            private static IEnumerator Get(string url, Action<bool, DateTime> action)
            {
                UnityWebRequest request = UnityWebRequest.Get(url);
                yield return request.SendWebRequest();
                if (request.result != UnityWebRequest.Result.Success)
                {
                    Debug.LogError("获取网络时间错误1");
                    action?.Invoke(false, DateTime.Now);
                }
                else
                {
                    Debug.Log("网络时间1: " + request.downloadHandler.text);
                    var dt = IntToDateTime(Convert.ToInt32(request.downloadHandler.text));
                    Debug.Log("网络时间2: " + dt);
                    action?.Invoke(true, dt);

                    // Dictionary<string, string> headerCollection = request.GetResponseHeaders();
                    // if (headerCollection.ContainsKey("Date"))
                    // {
                    //     string dateTime = headerCollection["Date"];
                    //     try
                    //     {
                    //         action?.Invoke(true, Convert.ToDateTime(dateTime));
                    //     }
                    //     catch (System.Exception)
                    //     {
                    //         action?.Invoke(false, DateTime.Now);
                    //     }

                    // }
                    // else
                    // {
                    //     action?.Invoke(false, DateTime.Now);
                    // }
                }
            }
        }
    }
}