using System;
using System.IO;
using System.IO.Compression;
using System.Text;

using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Paddings;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using UnityEngine;

namespace SoliUtils
{
    public class DESEncrypt
    {

        #region ========加密========
        public static byte[] Encrypt(string text, string key)
        {

            byte[] keyArray = UTF8Encoding.UTF8.GetBytes(text);
            return Encrypt(keyArray, key);
        }


        public static byte[] Encrypt(byte[] input, string key)
        {
            try
            {
                PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(new AesEngine(), new Pkcs7Padding());
                KeyParameter keyParam = new KeyParameter(Encoding.UTF8.GetBytes(key));
                cipher.Init(true, keyParam);

                byte[] output = new byte[cipher.GetOutputSize(input.Length)];
                int length = cipher.ProcessBytes(input, 0, input.Length, output, 0);
                cipher.DoFinal(output, length);

                return output;
            }
            catch (Exception e)
            {
                Debug.LogError($"Encryption failed: {e.Message}");
                return null;
            }
        }

        public static string Decrypt(string inputBase64, string key)
        {
            byte[] input = Convert.FromBase64String(inputBase64);
            return Decrypt(input, key);
        }

        public static string Decrypt(byte[] bytes, string key)
        {
            try
            {
                PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(new AesEngine(), new Pkcs7Padding());
                KeyParameter keyParam = new KeyParameter(Encoding.UTF8.GetBytes(key));
                cipher.Init(false, keyParam);

                byte[] output = new byte[cipher.GetOutputSize(bytes.Length)];
                int length = cipher.ProcessBytes(bytes, 0, bytes.Length, output, 0);
                cipher.DoFinal(output, length);

                return Encoding.UTF8.GetString(output).TrimEnd('\0');
            }
            catch (Exception e)
            {
                Debug.LogError($"Decryption failed: {e.Message}");
                return null;
            }
        }

        #endregion


        public static byte[] Compress(string content)
        {
            // string content = File.ReadAllText(inputFilePath);
            byte[] bytes = Encoding.UTF8.GetBytes(content);
            byte[] compressedBytes;
            using (MemoryStream compressedStream = new MemoryStream())
            {
                using (BrotliStream brotliStream = new BrotliStream(compressedStream, CompressionMode.Compress))
                {
                    brotliStream.Write(bytes, 0, bytes.Length);
                }
                compressedBytes = compressedStream.ToArray();
            }
            // File.WriteAllBytes(outputFilePath, compressedBytes);
            return compressedBytes;
        }

        public static string Decompress(byte[] bytes)
        {
            // byte[] compressedBytes = File.ReadAllBytes(inputFilePath);
            byte[] decompressedBytes;
            using (MemoryStream compressedStream = new MemoryStream(bytes))
            using (MemoryStream decompressedStream = new MemoryStream())
            {
                using (BrotliStream brotliStream = new BrotliStream(compressedStream, CompressionMode.Decompress))
                {
                    brotliStream.CopyTo(decompressedStream);
                }
                decompressedBytes = decompressedStream.ToArray();
            }

            string content = Encoding.UTF8.GetString(decompressedBytes);
            // File.WriteAllText(outputFilePath, text);
            return content;
        }


    }
}