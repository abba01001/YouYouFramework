using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using UniRx;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using Object = UnityEngine.Object;

namespace SoliUtils
{
    public static class AddressableUtils
    {
        private static readonly Dictionary<string, Object> _assetsDict = new Dictionary<string, Object>();

        private static readonly Dictionary<string, AsyncOperationHandle> _handleDict =
            new Dictionary<string, AsyncOperationHandle>();

        #region Load

        public static void LoadAsset<T>(string name, Action<T> callback) where T : Object
        {
            try
            {
                var task = LoadAssetAsync<T>(name);
                task.ToObservable().Subscribe(res => { callback?.Invoke(res); });
            }
            catch (Exception e)
            {
                Debug.LogError($"LoadAsset {e}");
            }
        }

        public static async UniTask<T> LoadAssetAsync<T>(string address) where T : Object
        {
            var handle = Addressables.LoadAssetAsync<T>(address);
            await handle.Task;
            return handle.Result;
        }

        public static void Instantiate(string name, Action<GameObject> callback)
        {
            var task = InstantiateAsync(name);
            task.ToObservable().Subscribe(res => { callback?.Invoke(res); });
        }

        public static async UniTask<GameObject> InstantiateAsync(string address)
        {
            var handle = Addressables.LoadAssetAsync<GameObject>(address);
            await handle.Task;
            return handle.Result;
        }

        public static T Load<T>(string name) where T : Object
        {
            string key = $"{name}_{typeof(T).Name}";
            if (_assetsDict.TryGetValue(key, out Object obj))
            {
                return (T)obj;
            }

            T asset;
            AsyncOperationHandle handle;

            handle = Addressables.LoadAssetAsync<T>(name);
            if (!GameCommon.IsAiMode && !GameCommon.IsEditorMode)
                Debug.LogError($"Dont use WaitForCompletion Load<{typeof(T).Name}> name= {name} ");

#if UNITY_EDITOR
            string filePath = "E://test.txt";
            Encoding encoder = Encoding.UTF8;
            byte[] bytes = encoder.GetBytes($"new(\"{name}\", typeof({typeof(T).Name}))," + "\n");
            FileStream fs = null;
            try
            {
                fs = File.OpenWrite(filePath);
                fs.Position = fs.Length;
                fs.Write(bytes, 0, bytes.Length);
                fs.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("文件打开失败{0}", ex.ToString());
            }
#endif
            asset = handle.WaitForCompletion() as T;

            if (asset == null)
            {
                Debug.LogError($"Asset key - {name} has no exist");
                return null;
            }

            if (_assetsDict.ContainsKey(key) == false) _assetsDict.Add(key, asset);
            if (_handleDict.ContainsKey(key) == false) _handleDict.Add(key, handle);

            return asset;
        }

        public static async Task<T> LoadAsync<T>(string name) where T : Object
        {
            string key = $"{name}_{typeof(T).Name}";
            //            Debug.Log($">>> AddressableUtils >> LoadAsync > key:{key}, Type:{typeof(T).Name}");
            var handle = Addressables.LoadAssetAsync<T>(name);
            T asset = await handle.Task;
            if (_assetsDict.ContainsKey(key) == false)
            {
                _assetsDict.Add(key, asset);
            }

            if (_handleDict.ContainsKey(key) == false) _handleDict.Add(key, handle);
            return asset;
        }

        public static async Task<List<T>> LoadByLabel<T>(string label) where T : Object
        {
            //            Debug.Log($">>> LoadByLabel >> label:{label}");
            List<T> assets = new List<T>(3);
            AsyncOperationHandle<IList<IResourceLocation>> locations = Addressables.LoadResourceLocationsAsync(label);
            foreach (var location in locations.Result)
            {
                var asset = await LoadAsync<T>(location.PrimaryKey);
                assets.Add(asset);
            }

            //            var handle = Addressables.LoadAssetsAsync<T>(label, obj =>
            //            {
            //                Debug.Log($">>> LoadByLabel >> load success > name:{obj.name}, type:{typeof(T).Name}");
            //                assets.Add(obj);
            //            });
            //            handle.WaitForCompletion();
            //            _handleList.Add(handle);
            return assets;
        }

        public static T Instantiate<T>(string name) where T : Object
        {
            var asset = Load<T>(name);
            var instantiate = GameObject.Instantiate(asset);
            return instantiate;
        }

        public static T Instantiate<T>(string name, Transform parent) where T : Object
        {
            string key = $"{name}_{typeof(T).Name}";
            var asset = Load<T>(name);
            var instantiate = GameObject.Instantiate(asset, parent);
            return instantiate;
        }

        public static T Instantiate<T>(string name, Transform parent, bool worldPositionStays) where T : Object
        {
            string key = $"{name}_{typeof(T).Name}";
            var asset = Load<T>(name);
            var instantiate = GameObject.Instantiate(asset, parent, worldPositionStays);
            return instantiate;
        }

        #endregion


        #region Release

        private static void Release(string key)
        {
            //            Debug.Log($">>> Release > key:{key}");
            if (_assetsDict.TryGetValue(key, out Object asset))
            {
                string type = key.Substring(key.LastIndexOf("_") + 1);
                //                Debug.Log($">>>> type:{type}, name:{asset.name}");
                if (type.Equals("Transform")) Release(((Transform)asset).gameObject);
                else Release(asset);
                _assetsDict.Remove(key);
            }

            if (_handleDict.TryGetValue(key, out AsyncOperationHandle handle))
            {
                //                Release(handle);
                _handleDict.Remove(key);
            }
        }

        public static void Release<T>(string name) where T : Object
        {
            string key = $"{name}_{typeof(T).Name}";
            //            Debug.Log($">>> AddressableUtils >> Release > key:{key}");
            Release(key);
        }

        public static void Release(Object obj)
        {
            Addressables.Release(obj);
        }

        /// <summary>
        /// 释放资源加载操作
        /// </summary>
        /// <param name="handle"></param>
        private static void Release(AsyncOperationHandle handle)
        {
            Addressables.Release(handle);
        }

        /// <summary>
        /// 释放实例
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static bool ReleaseInstance(GameObject obj)
        {
            return Addressables.ReleaseInstance(obj);
        }

        public static void ReleaseAll()
        {
            foreach (var asset in _assetsDict)
            {
                Debug.Log($">>> Release Asset >> assetName:{asset.Value.name}, type:{asset.GetType().Name}");
                Release(asset.Value);
            }

            _assetsDict.Clear();

            foreach (var handle in _handleDict)
            {
                if (handle.Value.IsValid())
                {
                    Debug.Log(
                        $">>> Release Handle >> status:{handle.Value.Status}, IsVaild:{handle.Value.IsValid()}, isDone:{handle.Value.IsDone}");
                    Release(handle.Value);
                }
            }

            _handleDict.Clear();
        }

        #endregion
    }
}