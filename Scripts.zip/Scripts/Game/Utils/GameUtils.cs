﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Activities;
using Coffee.UIExtensions;
using Cysharp.Threading.Tasks.Triggers;
using DG.Tweening;
using Doozy.Engine;
using Doozy.Engine.UI;
using Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using QFramework;
using UniRx;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object = System.Object;
using Random = UnityEngine.Random;
using UnityEngine.UI;

#if UNITY_WEBGL
using WeChatWASM;
#endif

namespace SoliUtils
{
    public class BeizerFlyAnimParam
    {
        private IList<GameObject> goList;

        public int goCount;
        public Vector3 beginPos;
        public Vector3[] controlPosArray;
        public Vector3 endPos;
        public float flyTime;

        public float endScale = 0;
        public Ease moveEase = Ease.OutQuad;
        public Transform parent;
        public float scale = 1f;
        public float startScale = 1f;
        public float stopTime = 0;
        public float intervalTime = 0.05f;
        public float splitTime = 0.3f;
        public Vector3 splitOffset = Vector3.zero;
        public Action firstArriveCall = null;
        public Action<int> everyArriveCall = null;
        public Action endCall = null;
        public bool IsBuildCoin = false;
        public BeizerFlyAnimParam(int _goCount, Vector3 _beginPos, Vector3[] _controlPosArray, Vector3 _endPos,
            float _flyTime)
        {
            goCount = _goCount;
            beginPos = _beginPos;
            controlPosArray = _controlPosArray;
            endPos = _endPos;
            flyTime = _flyTime;

            beginPos.z = 0;
            endPos.z = 0;
        }

        public BeizerFlyAnimParam(IList<GameObject> _goList, Vector3 _beginPos, Vector3[] _controlPosArray,
            Vector3 _endPos, float _flyTime)
        {
            goList = _goList;
            goCount = goList.Count;
            beginPos = _beginPos;
            controlPosArray = _controlPosArray;
            endPos = _endPos;
            flyTime = _flyTime;

            beginPos.z = 0;
            endPos.z = 0;
        }

        public IList<GameObject> GetGoList()
        {
            if (goList == null)
            {
                goList = new List<GameObject>(goCount);
                for (int i = 0; i < goCount; i++)
                {
                    var coin = GameObjManager.Instance.PopGameObject(GameObjType.CoinItem);
                    coin.SetActive(true);
                    coin.transform.SetParent(GoldView.Instance.transform, false);
                    coin.GetComponent<Renderer>().sortingOrder = GoldView.Instance.SortingOrder + 2;
                    Animator coinAnim = coin.GetComponent<Animator>();
                    coinAnim.Play("jinbi_zhuan_01_0", 0, Random.Range(0, 1f));
                    coinAnim.speed = Random.Range(1.5f, 3f);
                    coin.transform.localScale = Vector3.one * 0.4f;
                    coin.transform.localPosition = beginPos;
                    goList.Add(coin);
                }
            }

            return goList;
        }

        public IList<GameObject> GetBuildCoinList()
        {
            if (goList == null)
            {
                goList = new List<GameObject>(goCount);
                for (int i = 0; i < goCount; i++)
                {
                    var coin = GameObjManager.Instance.PopGameObject(GameObjType.BuildCoinItem);
                    coin.SetActive(true);
                    coin.transform.SetParent(GoldView.Instance.transform, false);
                    coin.GetComponent<Renderer>().sortingOrder = GoldView.Instance.SortingOrder + 2;
                    Animator coinAnim = coin.GetComponent<Animator>();
                    coinAnim.Play("jianzaobi_zhuan_01_0", 0, Random.Range(0, 1f));
                    coinAnim.speed = Random.Range(1.5f, 3f);
                    coin.transform.localScale = Vector3.one * 0.4f;
                    coin.transform.position = beginPos;
                    goList.Add(coin);
                }
            }

            return goList;
        }

        public Vector3[] GetBeizerList(Vector3 startPos)
        {
            if (controlPosArray.Length > 1)
                return BezierUtils.GetThreePowerBeizerList(startPos, controlPosArray[0], controlPosArray[1], endPos,
                    10);
            else
                return BezierUtils.GetBeizerList(startPos, controlPosArray[0], endPos, 10);
        }
    }

    public static class GameUtils
    {
        private static StringBuilder stringBuilder = new StringBuilder();
        public static readonly char[] FirstSeparator = ",".ToCharArray();
        public static readonly char[] SecondSeparator = ";".ToCharArray();
        public static readonly char[] ThirdSeparator = "#".ToCharArray();
        public static readonly bool EnableCoinShop = true; //是否屏蔽金币商城
        private static readonly System.Random _random = new System.Random();
        public static int GMmapId = 0;
        public static int GMthemeId = 0;
        public static Dictionary<int, Vector2> PropSizeDic = new Dictionary<int, Vector2>()
        {
            {(int)PropEnum.Coin, new Vector2(95, 95)},
            {(int)PropEnum.FreeBuyCard, new Vector2(240, 240)},
            {(int)PropEnum.FreeJoker, new Vector2(240, 240)},
            {(int)PropEnum.FreeTicket, new Vector2(240, 240)},
            {(int)PropEnum.FreeUndo, new Vector2(240, 240)},
            {(int)PropEnum.ItemEliminate, new Vector2(240, 240)},
            {(int)PropEnum.TimeItemEliminate, new Vector2(240, 240)},
            {(int)PropEnum.ItemJoker, new Vector2(240, 240)},
            {(int)PropEnum.TimeItemJoker, new Vector2(240, 240)},
            {(int)PropEnum.ItemCactus, new Vector2(240, 240)},
            {(int)PropEnum.TimeItemCactus, new Vector2(240, 240)},
            {(int)PropEnum.TimeItemDouble, new Vector2(240, 240)},
            {(int)PropEnum.MultiplyCoin, new Vector2(240, 240)},
            {(int)PropEnum.ItemWindmill, new Vector2(240, 240)},
            {(int)PropEnum.TimeItemWindmill, new Vector2(240, 240)},
        };

        public static List<Dictionary<int, int>> GetMultiplePropByString(string str)
        {
            List<Dictionary<int, int>> list = new List<Dictionary<int, int>>();
            // 去掉最外层的方括号
            str = str.Trim('[', ']');
            // 按照 "],[" 分割字符串，得到每个子字符串
            string[] result = str.Split(new[] { "],[" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var t in result)
            {
                Dictionary<int, int> reward = AnalysisPropString(t);
                list.Add(reward);
                
            }
            return list;
        }
        
        public static Dictionary<int, int> AnalysisMultiplePropString(string str)
        {
            // 去掉最外层的方括号
            str = str.Trim('[', ']');
            // 按照 "],[" 分割字符串，得到每个子字符串
            string[] result = str.Split(new[] { "],[" }, StringSplitOptions.RemoveEmptyEntries);
            Dictionary<int, int> rewards = new Dictionary<int, int>();
            foreach (var reward in GetMultiplePropByString(str))
            {
                foreach (var pair in reward)
                {
                    if (!rewards.ContainsKey(pair.Key))
                    {
                        rewards.Add(pair.Key,pair.Value);
                    }
                    else
                    {
                        rewards[pair.Key] += pair.Value;
                    }
                }
            }
            return rewards;
        }

        public static Vector3 GetRealPos(RectTransform t)
        {
            var obj = t;
            Vector2 originalAnchoredPosition = obj.anchoredPosition;
            Vector2 size = obj.rect.size;
            Vector2 currentPivot = obj.pivot;
            Vector2 newPivot = new Vector2(0.5f, 0.5f); // Middle Center
            Vector2 oldWorldPosition = obj.TransformPoint(originalAnchoredPosition);
            obj.pivot = newPivot;
            obj.anchorMin = newPivot;
            obj.anchorMax = newPivot;
            Vector2 newAnchoredPosition = obj.InverseTransformPoint(oldWorldPosition);
            Vector2 deltaPivot = newPivot - currentPivot;
            Vector3 deltaPosition = new Vector3(deltaPivot.x * size.x, deltaPivot.y * size.y);
            if (currentPivot != newPivot)
            {
                newAnchoredPosition += (Vector2)deltaPosition;
            }
            return newAnchoredPosition;
        }
        
        public static Dictionary<int, int> AnalysisPropString(string str)
        {
            Dictionary<int, int> result = new Dictionary<int, int>();
            var configService = MainContainer.Container.Resolve<IConfigService>();
            string[] propArray = str.Split(SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            bool hasSpecialItem = false;
            foreach (var propInfo in propArray)
            {
                string[] rewardParam = propInfo.Split(FirstSeparator);
                if (rewardParam.Length < 2)
                {
                    GameUtils.LogError("配置奖励错误");
                    continue;
                }
                int prop_id = int.Parse(rewardParam[0]);
                int propNum = int.Parse(rewardParam[1]);
                if (result.ContainsKey(prop_id))
                    result[prop_id] += propNum;
                else
                {
                    result.Add(prop_id, propNum);
                }

                if (configService.ItemConfig.TryGetValue(prop_id,out ItemModel model) && model.special == 1)
                {
                    hasSpecialItem = true;
                }
            }

            if (hasSpecialItem)
            {
                CaculateCoinFactor(ref result);
            }

            return result;
        }

        public static Dictionary<int, int> AnalysisBubblePropString(string str)
        {
            int tempIndex = 0;
            List<WeightRewardModel> modelList = new List<WeightRewardModel>();
            string[] propArray = str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            int totalWeigh = 0;
            foreach (var propInfo in propArray)
            {
                string[] rewardParam = propInfo.Split(GameUtils.FirstSeparator);
                WeightRewardModel model = GameObjManager.Instance.PopClass<WeightRewardModel>(true);
                model.PropEnum = int.Parse(rewardParam[0]);
                model.Count = 1;
                model.Weight = int.Parse(rewardParam[1]);
                totalWeigh += model.Weight;
                modelList.Add(model);
            }
            string reward = "";
            float randomValue = GameUtils.RandomRange(0, 1f);
            int tempWeight = 0;
            foreach (var model in modelList)
            {
                tempWeight += model.Weight;
                float weight = (float)tempWeight / totalWeigh;
                if (weight > randomValue)
                {
                    reward = $"{model.PropEnum},{model.Count}";
                    break;
                }
                tempIndex++;
            }
            return AnalysisPropString(reward);
        }
        
        public static (int index,Dictionary<int, int>) AnalysisWeightPropString(string str)
        {
            int tempIndex = 0;
            List<WeightRewardModel> modelList = new List<WeightRewardModel>();
            string[] propArray = str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            int totalWeigh = 0;
            foreach (var propInfo in propArray)
            {
                string[] rewardParam = propInfo.Split(GameUtils.FirstSeparator);
                WeightRewardModel model = GameObjManager.Instance.PopClass<WeightRewardModel>(true);
                model.PropEnum = int.Parse(rewardParam[0]);
                model.Count = int.Parse(rewardParam[1]);
                model.Weight = int.Parse(rewardParam[2]);
                totalWeigh += model.Weight;
                modelList.Add(model);
            }
            string reward = "";
            float randomValue = GameUtils.RandomRange(0, 1f);
            int tempWeight = 0;
            foreach (var model in modelList)
            {
                tempWeight += model.Weight;
                float weight = (float)tempWeight / totalWeigh;
                if (weight > randomValue)
                {
                    reward = $"{model.PropEnum},{model.Count}";
                    break;
                }
                tempIndex++;
            }

            return (tempIndex, AnalysisPropString(reward));
        }

        public static KeyValuePair<int, T> GetRandomWithWight<T>(ICollection<KeyValuePair<int, T>> dic)
            where T : IRandomWight
        {
            if (dic.Count <= 0) return default;
            if (dic.Count == 1) return dic.First();
            int allWight = 0;
            foreach (var item in dic)
                allWight += item.Value.GetWight();
            int value = UnityEngine.Random.Range(0, allWight + 1);
            foreach (var item in dic)
            {
                value -= item.Value.GetWight();
                if (value <= 0) return item;
            }

            return dic.Last();
        }

        public static Tween PlayGoldAnim(Transform root,int oldCoin,int newCoin,Transform startTrans,Action action = null,bool needResetGold = true)
        {
            GameObjectData goldRootData = GoldView.Instance.goldRootData;
            int goldSortingOrder = GoldView.Instance.SortingOrder;
            if (goldRootData.transform.parent != root)
            {
                goldRootData.transform.SetParent(root);
                if (!GameUtils.IsInHomeView() || GameCommon.VisiblePopupCount > 0)
                {
                    goldRootData.rectTransform.anchoredPosition = new Vector2(48f, -25f);
                }
                GoldView.Instance.SortingOrder = root.GetComponent<Canvas>().sortingOrder + 1;
            }

            GoldView.Instance.ThreePowerBeizerFlyCoin((int) PropEnum.Coin, oldCoin, newCoin, startTrans);

            Sequence mySequence = DOTween.Sequence();
            mySequence.SetAutoKill(true);
            mySequence.AppendInterval(2f);
            mySequence.AppendCallback(() =>
            {
                GoldView.Instance.SortingOrder = goldSortingOrder;
                if(needResetGold) goldRootData.Reset();
                mySequence = null;
                action?.Invoke();
            });
            return mySequence;
        }
        
        public static string GetItemCountText(int propId, int count)
        {
            string text = "";
            if (IsLimitTimeReward(propId))
            {
                text = $"{count / 60}m";
            }
            else if (propId == (int) PropEnum.BubbleGift || propId == (int) PropEnum.EnergyPlus8)
            {
                text = "";
            }
            else if (propId == (int) PropEnum.BuildCoin || propId == (int) PropEnum.Coin)
            {
                text = count.ToString();
            }
            else
            {
                text = $"x{count}";
            }
            return text;
        }

        public static int GetLevelHard()
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            return configService.GetStageHard(dataService.NowMaxLevel);
        }
        
        public static bool CheckDirectExitGame(int solatium)
        {
            List<ActivityType> list = new List<ActivityType>()
            {
                ActivityType.collectFlower,
                ActivityType.passRank,
                ActivityType.collectLoveCard,
                ActivityType.seasonPass,
                ActivityType.limitPk
            };
            foreach (var activityType in list)
            {
                if (ActivityManager.Instance.GetActivityByType(activityType).state == ActivityState.underWay)
                {
                    BaseActivityData data =
                        ActivityManager.Instance.GetActivityByType(activityType).localData as BaseActivityData;
                    if (data.ResultAddCount != 0)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        public static RobotConfigModel GetRobotInfo(int id)
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();

            if (id == -1)
            {
                RobotConfigModel model = new RobotConfigModel();
                model.name = dataService.UserName;
                model.id = "-1";
                return model;
            }

            Dictionary<int, RobotConfigModel> list = configService.RobotList;
            return list[id];
        }

        public static int GetRandomRobotID()
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            Dictionary<int, RobotConfigModel> list = configService.RobotList;
            return UnityEngine.Random.Range(1, list.Count);
        }

        public static void HandlePairCard(CardType cardType, ref Dictionary<string, bool> specialCardDic)
        {
            if (cardType == CardType.Lock || cardType == CardType.Key)
            {
                specialCardDic.TryAdd(Constants.CardType2StringDic[CardType.Lock], true);
                specialCardDic.TryAdd(Constants.CardType2StringDic[CardType.Key], true);
            }
            else if (cardType == CardType.Banana || cardType == CardType.Monkey)
            {
                specialCardDic.TryAdd(Constants.CardType2StringDic[CardType.Banana], true);
                specialCardDic.TryAdd(Constants.CardType2StringDic[CardType.Monkey], true);
            }
            else if (cardType == CardType.Anchor)
            {
                specialCardDic.TryAdd(Constants.CardType2StringDic[CardType.Anchor], true);
                specialCardDic.TryAdd(Constants.ModType2StringDic[ModifierType.Water], true);
            }
        }

        public static void HandlePairCard(ModifierType modifierType, ref Dictionary<string, bool> specialCardDic)
        {
            if (modifierType == ModifierType.Rising || modifierType == ModifierType.Lowering)
            {
                specialCardDic.TryAdd(Constants.ModType2StringDic[ModifierType.Rising], true);
                specialCardDic.TryAdd(Constants.ModType2StringDic[ModifierType.Lowering], true);
            }
            else if (modifierType == ModifierType.Water)
            {
                specialCardDic.TryAdd(Constants.CardType2StringDic[CardType.Anchor], true);
                specialCardDic.TryAdd(Constants.ModType2StringDic[ModifierType.Water], true);
            }
        }

        public static void ClearPreAddItem(bool clearAll, int prop_id)
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            if (clearAll)
            {
                dataService.PreAddItem.Clear();
            }
            else
            {
                if (dataService.PreAddItem.Contains(prop_id)) dataService.PreAddItem.Remove(prop_id);
            }
        }

        public static long GetBetStageCost(int toLevel, int betNum)
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            int nowStageCost = configService.GetStageCost(toLevel) * betNum;
            return Math.Max(nowStageCost, int.Parse(configService.ValueConfig["MinGold"]));
        }

        public static void PlayShakeAnim(Transform trans, Action startAction, Action endAction)
        {
            if (trans == null) return;
            startAction?.Invoke();
            Sequence seq = DOTween.Sequence();
            seq.Insert(0f, trans.DOLocalRotate(new Vector3(0f, 0f, 25f), 9f / 60));
            seq.Insert(9f / 60, trans.DOLocalRotate(new Vector3(0f, 0f, -15f), 9f / 60));
            seq.Insert(18f / 60, trans.DOLocalRotate(new Vector3(0f, 0f, 10f), 8f / 60));
            seq.Insert(26f / 60, trans.DOLocalRotate(new Vector3(0f, 0f, -7.5f), 9f / 60));
            seq.Insert(35f / 60, trans.DOLocalRotate(new Vector3(0f, 0f, 5.5f), 9f / 60));
            seq.Insert(44f / 60, trans.DOLocalRotate(new Vector3(0f, 0f, -3f), 9f / 60));
            seq.Insert(53f / 60, trans.DOLocalRotate(new Vector3(0f, 0f, 1f), 8f / 60));
            seq.Insert(61f / 60, trans.DOLocalRotate(new Vector3(0f, 0f, 0f), 9f / 60));
            SoundPlayer.Instance.PlayMainSound("map_unget");
            seq.InsertCallback(70f / 60, () => { endAction?.Invoke(); });
        }

        public static long GetStageCost(int toLevel)
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            int nowStageCost = configService.GetStageCost(toLevel);
            return Math.Max(nowStageCost, int.Parse(configService.ValueConfig["MinGold"]));
        }

        public static int GetRandomRobotIcon(ref List<int> list)
        {
            int index = GameUtils.RandomRange(1, 151);
            if (!list.Contains(index))
            {
                list.Add(index);
                return index;
            }
            else
            {
                for (int i = 0; i < 151; i++)
                {
                    int value = GameUtils.RandomRange(1, 151);
                    if (list.Contains(value)) continue;
                    list.Add(index);
                    return index;
                }
            }
            return -1;
        }

        public static bool CheckCanShowFirstCharge()
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            if (!CheckFuncIsUnlock("giftFirst") || dataService.IsBuyBeginner)
            {
                return false;
            }
            return true;
        }

        public static bool HavePowerItemInfinite(int prop_id)
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            if (configService.ItemConfig[prop_id].type != 3) return false;
            PowerItemModel powerItemModel = configService.PowerItemConfig[prop_id];
            int relateItem = powerItemModel.relateItem;
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            return dataService.GetPropNum(relateItem) >= TimeUtils.UtcNow();
        }

        public static int? CosumePowerItem(int prop)
        {
            int prop_id = (int)prop;
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            if (configService.ItemConfig[prop_id].type != 3) return null;
            PowerItemModel powerItemModel = configService.PowerItemConfig[prop_id];
            int relateItem = powerItemModel.relateItem;

            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            if (dataService.GetPropNum(relateItem) >= TimeUtils.UtcNow()) return (int)relateItem;
            if (!dataService.UseProp(prop_id, PropChangeWay.EnterGame, 1)) return null;
            return prop;
        }

        public static int? HasTimerPowerItem(int prop)
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            if (dataService.GetPropNum((int)prop) >= TimeUtils.UtcNow())
                return prop;
            return null;
        }


        public static void Shuffle<T>(IList<T> original)
        {
            T temp;
            for (int i = 0; i < original.Count; i++)
            {
                int index = RandomRange(0, original.Count - 1);
                if (index != i)
                {
                    temp = original[i];
                    original[i] = original[index];
                    original[index] = temp;
                }
            }
        }

        public static Tween BeizerFlyCoin(BeizerFlyAnimParam animParam)
        {
            Sequence rootSeq = DOTween.Sequence();
            IList<GameObject> coinList = null;
            coinList = animParam.IsBuildCoin ? animParam.GetBuildCoinList() : animParam.GetGoList();
            for (var i = 0; i < animParam.goCount; i++)
            {
                int index = i;
                Vector3 offset = index < GoldView.flyGoldPoints.Length
                    ? GoldView.flyGoldPoints[index]
                    : (new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f)) * 100);
                Vector3 startPos = animParam.beginPos + (offset * animParam.scale) + animParam.splitOffset;
                
                Transform coinTrans = coinList[i].transform;
                coinTrans.localPosition = startPos;
                coinTrans.localScale = Vector3.one * animParam.startScale;
                Sequence seq = DOTween.Sequence();
                seq.Append(coinTrans.transform.DOLocalMove(startPos, animParam.splitTime).SetEase(Ease.OutQuad));
                
                seq.Join(coinTrans.transform.DOScale(Vector3.one * animParam.scale, animParam.splitTime));
                seq.AppendInterval(animParam.intervalTime * index + animParam.stopTime);
                
                seq.Append(coinTrans.transform.DOLocalPath(animParam.GetBeizerList(startPos), animParam.flyTime,
                    PathType.CatmullRom, gizmoColor: Color.red).SetEase(animParam.moveEase));
                seq.Join(coinTrans.transform.DOScale(Vector3.one * animParam.endScale, animParam.flyTime)
                    .SetEase(Ease.InQuart));
                if (index == 0)
                {
                    SoundPlayer.Instance.PlayGoldFly(2);
                    seq.AppendCallback(() => animParam.firstArriveCall?.Invoke());
                }

                seq.AppendCallback(() =>
                {
                    GameObjManager.Instance.PushGameObject(coinTrans.gameObject);
                    coinList.Remove(coinTrans.gameObject);
                    animParam.everyArriveCall?.Invoke(index);
                });
                rootSeq.Join(seq);
            }

            rootSeq.AppendCallback(() => animParam.endCall?.Invoke());
            rootSeq.onKill += () =>
            {
                foreach (var item in coinList)
                {
                    if (item != null)
                        GameObjManager.Instance.PushGameObject(item);
                }
            };
            return rootSeq;
        }

        public static Sequence BeizerFly(BeizerFlyAnimParam animParam)
        {
            Sequence rootSeq = DOTween.Sequence();
            IList<GameObject> goList = animParam.GetGoList();
            for (var i = 0; i < goList.Count; i++)
            {
                int index = i;
                GameObject go = goList[index];
                Vector3 offset = index < GoldView.flyGoldPoints.Length
                    ? GoldView.flyGoldPoints[index]
                    : (new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f)) * 100);
                Vector3 startPos = animParam.beginPos + (offset * animParam.scale) + animParam.splitOffset;
                string fxKeyStr = go.GetInstanceID().ToString();
                FxMaskView.Instance.AddFx(fxKeyStr, go);
                go.transform.localScale = Vector3.one * animParam.startScale;
                go.transform.position = animParam.beginPos;
                go.gameObject.SetActive(false);

                Vector3[] pathPosArray = animParam.GetBeizerList(startPos);
                Sequence seq = DOTween.Sequence();
                seq.AppendCallback(() => go.SetActive(true));
                seq.Append(go.transform.DOMove(startPos, animParam.splitTime).SetEase(Ease.OutQuad));
                seq.Join(go.transform.DOScale(Vector3.one * animParam.scale, animParam.splitTime));
                seq.AppendInterval(animParam.intervalTime * index + animParam.stopTime);
                seq.Append(go.transform
                    .DOLocalPath(pathPosArray, animParam.flyTime, PathType.CatmullRom, gizmoColor: Color.red)
                    .SetEase(animParam.moveEase));
                seq.Join(go.transform.DOScale(Vector3.one * animParam.endScale, animParam.flyTime));
                seq.AppendCallback(() =>
                {
                    FxMaskView.Instance.RemoveFx(fxKeyStr, null);
                    GameObjManager.Instance.PushGameObject(go);
                    goList.Remove(go);
                });
                if (index == 0)
                    seq.AppendCallback(() => animParam.firstArriveCall?.Invoke());
                seq.AppendCallback(() => animParam.everyArriveCall?.Invoke(index));
                rootSeq.Join(seq);
            }

            rootSeq.AppendCallback(() => animParam.endCall?.Invoke());
            rootSeq.onKill += () =>
            {
                foreach (var item in goList)
                {
                    if (item != null)
                        GameObjManager.Instance.PushGameObject(item);
                }
            };
            return rootSeq;
        }

        #region 触发礼包逻辑
        public static void CheckFailGift()
        {
            if (ActivityManager.Instance.CheckPushGift(Constants.ProductId.AssistancePack_1, GiftType.FailGift)) return;
            if (ActivityManager.Instance.CheckPushGift(Constants.ProductId.NarrowDefeatPack_1, GiftType.FailGift)) return;
            if (ActivityManager.Instance.CheckPushGift(Constants.ProductId.NarrowDefeatPack_2, GiftType.FailGift)) return;
            if (ActivityManager.Instance.CheckPushGift(Constants.ProductId.NarrowDefeatPack_3, GiftType.FailGift)) return;
        }

        #endregion

        /// <summary>
        /// 网络是否可用
        /// </summary>
        /// <returns></returns>
        public static bool IsNetAvailable()
        {
            return Application.internetReachability != NetworkReachability.NotReachable;
        }

        public static bool IsVector3Illegal(this Vector3 v3)
        {
            return v3.x == 99999f && v3.y == 99999f && v3.z == 99999f;
        }

        public static bool ListEqualsByCondition<T>(this List<T> list1, List<T> list2, Func<T, T, bool> condition)
        {
            //数量相等，且一样
            if (list1.Count == list2.Count)
            {
                foreach (T item in list1)
                {
                    T find = list2.Find(it => condition(it, item));
                    if (find == null) return false;
                }
            }
            else
            {
                return false;
            }

            return true;
        }

        public static List<T> CopyList<T>(this List<T> list)
        {
            if (list == null) return new List<T>();
            return new List<T>(list.ToArray());
        }

        private static int seedIdx = 0;

        public static int RandomRange(int minInclusive, int maxExclusive)
        {
            // int seed = (int)System.DateTime.Now.Ticks + seedIdx++;
            // Random.InitState(seed);
            // return Random.Range(minInclusive, maxExclusive);
            return _random.Next(minInclusive, maxExclusive);
        }

        public static bool IsLimitTimeReward(int prop_id)
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            if (configService.ItemConfig.TryGetValue(prop_id, out ItemModel model))
            {
                ItemModel itemModel = configService.ItemConfig[prop_id];
                return itemModel.type == (int)Constants.ItemType.TimeForceItem;
            }
            return false;
        }

        public static void SpawnIconEffect(Transform parent,GameObjType objType,GameObject efObj)
        {
            GameObject newStarFx = GameObjManager.Instance.PopGameObject(objType, efObj);
            newStarFx.transform.SetParent(parent.transform);
            newStarFx.transform.localScale = Vector3.one;
            newStarFx.transform.position = Vector3.zero;
            newStarFx.transform.localPosition = Vector3.zero;
            newStarFx.SetActive(true);
            GameObjManager.Instance.PushGameObject(newStarFx.gameObject, 2);
        }
        
        public static void ExitResultView()
        {
            BoxBuilder.ShowSceneChangePop(() =>
            {
                GameEventMessage.SendEvent(Constants.DoozyEvent.GameEnd);
            }, BoxBuilder.HideSceneChangePop);
        }
        
        //计算金币系数
        public static void CaculateCoinFactor(ref Dictionary<int, int> result)
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();

            long enterCoin = GetStageCost(dataService.MaxLevel);
            int addCoin = 0;
            Dictionary<int, int> tempResult = new Dictionary<int, int>();
            foreach (var propInfo in result)
            {
                if (configService.ItemConfig[propInfo.Key].special == 1)
                {
                    int temp = (int)(enterCoin * configService.ItemConfig[propInfo.Key].beishu * propInfo.Value);
                    int roundedIntegerResult = (int)Math.Ceiling(temp / 10.0f) * 10;

                    addCoin += roundedIntegerResult;
                }
                else
                {
                    tempResult.TryAdd(propInfo.Key, propInfo.Value);
                }
            }

            if (result.ContainsKey((int)PropEnum.Coin))
            {
                tempResult[(int)PropEnum.Coin] += addCoin;
            }
            else
            {
                if (addCoin != 0)
                {
                    tempResult.TryAdd((int)PropEnum.Coin, addCoin);
                }
            }

            result = tempResult;
        }

        public static float RandomRange(float minInclusive, float maxExclusive)
        {
            // int seed = (int)System.DateTime.Now.Ticks + seedIdx++;
            // Random.InitState(seed);
            // return Random.Range(minInclusive, maxExclusive);
            int precision = 10000;
            System.Random random = new System.Random();
            float number = (float)random.NextDouble() * (maxExclusive - minInclusive) + minInclusive;
            number = Mathf.Round(number * precision) / precision;
            return number;
        }

        public static void LogError(params object[] messages)
        {
            string combinedMessage = JointString(messages);
            Debug.LogError(combinedMessage);
        }
        
        //调整中心点
        public static void AdjustPivot(RectTransform rectTransform, Vector2 newPivot)
        {
            // 保存当前视觉位置
            Vector2 originalSize = rectTransform.rect.size;
            Vector2 originalPivot = rectTransform.pivot;
            Vector2 originalPosition = rectTransform.anchoredPosition;

            // 更新 pivot
            rectTransform.pivot = newPivot;

            // 计算新的 anchoredPosition
            Vector2 pivotDelta = newPivot - originalPivot;
            Vector2 sizeDelta = originalSize * pivotDelta;

            rectTransform.anchoredPosition = originalPosition + sizeDelta;
        }

        // 测试代码块的执行时间
        public static void TestTime(string tag, System.Action action = null)
        {
            System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
            stopwatch.Start();
            action?.Invoke();
            stopwatch.Stop();
            float seconds = stopwatch.ElapsedTicks / (float)System.Diagnostics.Stopwatch.Frequency;
            LogError($"{tag} --- 消耗时间: {seconds:F3} 秒");
        }


        //拼接字符串
        public static string JointString(params object[] values)
        {
            stringBuilder.Clear();
            foreach (object value in values)
            {
                stringBuilder.Append(value);
            }
            return stringBuilder.ToString();
        }

        public static System.Collections.IEnumerator CheckKeys(params Action[] actions)
        {
            while (true)
            {
                for (int i = 0; i < Mathf.Min(actions.Length, 12); i++)
                {
                    if (Input.GetKeyDown(KeyCode.F1 + i))
                    {
                        actions[i]?.Invoke();
                    }
                }

                yield return null;
            }
        }

        public static void ChangeMap(FarmingModel model, Action successCb = null, Action failCb = null)
        {
            ActivityManager.Instance.FarmingActivity.ChangeMap(model.mapId, model.themeId, () =>
            {
                successCb?.Invoke();
                BackdropMono.Instance.SwitchBackdrop();
                SoundPlayer.Instance.ChangeBgm();
                SoundPlayer.Instance.PlayMainSound("Land_Show");
                PlayMasterCanavsAnim("ani_Home_MapChange");

            }, failCb);
        }

        public static void PlayMasterCanavsAnim(string stateName, Action startCb = null, Action finishCb = null)
        {
            startCb?.Invoke();
            Animator animator = UICanvas.GetMasterCanvas().GetComponent<Animator>();
            animator.enabled = false;
            RuntimeAnimatorController originalController = animator.runtimeAnimatorController;
            animator.runtimeAnimatorController = null;
            animator.runtimeAnimatorController = originalController;
            animator.enabled = true;
            animator.Play(stateName, 0, 0);

            FxMaskView.Instance.BlockOperation(true);
            UniRx.Observable.NextFrame().Subscribe(_ =>
            {
                Observable.Timer(TimeSpan.FromSeconds(animator.GetCurrentAnimatorStateInfo(0).length)).Subscribe(
                    _ =>
                    {
                        animator.enabled = false;
                        FxMaskView.Instance.BlockOperation(false);
                        finishCb?.Invoke();
                    });
            });
        }

        public static void CosumeAndReportStartEvent(int toLevel, LevelModel levelModel)
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            
            var startCoin = dataService.Coin;
            int consumeCoin = (int)dataService.GetPreAddItemConsume();
            dataService.UseProp((int)PropEnum.Coin, PropChangeWay.GameBeforeUseProp, consumeCoin);
            ActivityManager.Instance.EnergyActivity.UseEnergy(1);

            List<int> realUseList = new List<int>();
            int? eliminateUse = GameUtils.HasTimerPowerItem((int)PropEnum.TimeItemEliminate);
            int? jokerUse = GameUtils.HasTimerPowerItem((int)PropEnum.TimeItemJoker);
            int? windmillUse = GameUtils.HasTimerPowerItem((int)PropEnum.TimeItemWindmill);
            int? cactusUse = GameUtils.HasTimerPowerItem((int)PropEnum.TimeItemCactus);
            if (eliminateUse.HasValue) realUseList.Add((int)eliminateUse.Value);
            if (jokerUse.HasValue) realUseList.Add((int)jokerUse.Value);
            if (cactusUse.HasValue) realUseList.Add((int)cactusUse.Value);
            if (windmillUse.HasValue) realUseList.Add((int)windmillUse.Value);

            string propType = "Energy";
            AnalyticUtils.ReportUser_Add(AnalyticsKey.BattleTimes, 1);
            int defaultCost = configService.GetStageCost(toLevel);
            configService.GetWinStreakIdx(dataService.SuccessiveVictory, out var stepIdx);
            string[] winStreakCards = null;
            var level_type = 1;
            var level = dataService.MaxLevel;
            if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel) != null &&
                ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
            {
                level = dataService.EndlessLevelProgress.ViewMaxLayer;
                level_type = 2;
            }
            var msg = new Dictionary<string, object>
            {
                { AnalyticsKey.StageType, level_type},
                { AnalyticsKey.StageId, level},
                { AnalyticsKey.WinstreakLevel, stepIdx},
                { AnalyticsKey.StageStartCostType, propType},
                { AnalyticsKey.StageStartCostValue, 0},
                { AnalyticsKey.StageStartCostTicketValue, 0},
                { AnalyticsKey.StageStartDefaultCost, defaultCost},
                { AnalyticsKey.MultiplyFactor, dataService.NowBet},
                { AnalyticsKey.StagePowerupDelthreeUse, eliminateUse == (int)PropEnum.ItemEliminate ? 1 : 0 },
                { AnalyticsKey.StagePowerupWildUse, jokerUse == (int)PropEnum.ItemJoker ? 1 : 0 },
                { AnalyticsKey.StagePowerupCactusUse, cactusUse == (int)PropEnum.ItemCactus ? 1 : 0 },
                { AnalyticsKey.StagePowerupDelthreeLimitless, eliminateUse == (int)PropEnum.TimeItemEliminate ? 1 : 0 },
                { AnalyticsKey.StagePowerupWildLimitless, jokerUse == (int)PropEnum.TimeItemJoker ? 1 : 0 },
                { AnalyticsKey.StagePowerupCactusLimitless, cactusUse == (int)PropEnum.TimeItemCactus ? 1 : 0 },
                { AnalyticsKey.Coin, startCoin}
            };
            AnalyticUtils.ReportEvent(AnalyticsKey.SoliBattleStart, msg);
            TypeEventSystem.Send(new StartGameEvent(toLevel, levelModel, 0, 0, winStreakCards,
                realUseList));
            GameEventMessage.SendEvent(Constants.DoozyEvent.StartGame);
        }

        public static void SetTimeScale(float scale)
        {
            Time.timeScale = scale;
        }

        public static string GetAvatarUrlFilePath(string url)
        {
            string md5Str = EncryptUtils.MD5Encrypt(url).Replace("\\", "")
                .Replace("/", "")
                .Replace("=", "");
            var storageService = MainContainer.Container.Resolve<IStorageService>();
            string dataPath = storageService.GetUserDataPath();
            var folder = Path.Combine(dataPath, "avatars");
            if (!storageService.FolderExists(folder))
            {
                storageService.MkFolder(folder);
            }
            var dst = Path.Combine(folder, md5Str + ".jpg");
            return dst;
        }

        public static void GetAvatar(string url, Action<bool, string> callback)
        {
            if (GameCommon.IsOffMode) return;
            if (string.IsNullOrEmpty(url))
            {
                Debug.LogError($"GameUtils.DownloadAvatar, url is null");
                return;
            }

            var dst = GetAvatarUrlFilePath(url);
            var storageService = MainContainer.Container.Resolve<IStorageService>();
            if (storageService.FileExists(dst))
            {
                callback?.Invoke(true, dst);
                return;
            }

            StaticCoroutine.StartCoroutine(DownloadJpg(url, dst, callback));
        }

        public static bool IsFullyEnterGame()
        {
            return SceneManager.GetActiveScene() != null && SceneManager.GetActiveScene().name == "MainScene";
        }

        public static bool CheckSpecialCard(CardData CardData)
        {
            if (CardData.HasBomb())
            {
                return false;
            }
            if (CardData.CardType == CardType.Monochrome)
            {
                return false;
            }
            if (CardData.HasBigBomb())
            {
                return false;
            }
            if (CardData.HasLightning())
            {
                return false;
            }
            if (CardData.CardType == CardType.Joker)
            {
                return false;
            }
            if (CardData.HasCloth())
            {
                return false;
            }
            return true;
        }

        public static void PlayAnimation(Animator animator, string animName, int layer, Action endCall = null, bool disableAnimator = true)
        {
            animator.enabled = true;
            animator.Play(animName, layer, 0);
            Observable.NextFrame().Subscribe(_ =>
            {
                Observable.Timer(TimeSpan.FromSeconds(animator.GetCurrentAnimatorStateInfo(0).length)).Subscribe(
                    _ =>
                    {
                        if (disableAnimator)
                        {
                            animator.enabled = false;
                        }
                        endCall?.Invoke();
                    });
            });
        }

        public static StageModel GetCurStageModel()
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            StageModel stageModel = new StageModel();
            if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
            {
                stageModel = configService.GetStageConfig[dataService.EndlessLevelProgress.MyData.level];
            }
            else
            {
                stageModel = configService.StageConfig[dataService.MaxLevel];
            }

            return stageModel;
        }

        //请求排行榜信息
        public static void RequestRankInfo(string type,string rankid)
        {
            if (GameCommon.IsOffMode) return;
            GameCommon.IsRequestingRank = true;
            Observable.Timer(TimeSpan.FromSeconds(1f)).Subscribe(_ => GameCommon.IsRequestingRank = false);
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            string uid = dataService.UserId;
            var time = TimeUtils.UtcNow();
            string flag = EncryptUtils.MD5Encrypt(uid + time + Constants.ServerKey);
            string url = Constants.ApiUrl + "/rank";
            url = $"{url}?uid={uid}&time={time}&flag={flag.ToLower()}&type={type}&rankid={rankid}";
            StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
            {
                GameCommon.IsRequestingRank = false;
                if (ret)
                {
                    if (type == "3")
                    {
                        ActivityManager.Instance.EndlessLevelActivity.HandleRankInfo(json);
                    }
                }
            }));
        }


        //请求邮件信息
        public static void RequestEmailInfo(string type, string emailID = "-1", Action action = null)
        {
            if (GameCommon.IsOffMode) return;
            if (GameCommon.IsRequestingEmail) return;
            GameCommon.IsRequestingEmail = true;
            Observable.Timer(TimeSpan.FromSeconds(3f)).Subscribe(_ => GameCommon.IsRequestingEmail = false);
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            string uid = dataService.UserId;
            var time = TimeUtils.UtcNow();
            string flag = EncryptUtils.MD5Encrypt(uid + time + Constants.ServerKey);
            string url = Constants.ApiUrl + "/mail";
            if (emailID == "-1")
            {
                url = $"{url}?uid={uid}&time={time}&flag={flag.ToLower()}&opt={type}";
            }
            else
            {
                url = $"{url}?uid={uid}&time={time}&flag={flag.ToLower()}&opt={type}&mid={emailID}";//&mid={emailID}
            }
            StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
            {
                GameCommon.IsRequestingEmail = false;
                if (ret)
                {
                    // var dicData = JsonConvert.DeserializeObject<Dictionary<string, List<EmailInfoModel>>>(json);
                    var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
                    List<EmailInfoModel> tempList = new List<EmailInfoModel>();
                    if (type == "1" && dic.TryGetValue("mail_list", out var list) && list != null)//获取列表
                    {
                        List<object> info = list as List<object>;
                        foreach (var pair in info)
                        {
                            EmailInfoModel model = new EmailInfoModel();

                            Dictionary<string, object> data = pair as Dictionary<string, object>;
                            model.mid = Convert.ToString(data["mid"]);
                            model.time = Convert.ToString(data["time"]);
                            model.title = Convert.ToString(data["title"]);
                            model.content = Convert.ToString(data["content"]);
                            model.rewards = Convert.ToString(data["rewards"]);
                            model.read = Convert.ToInt32(data["read"]);
                            model.receive = Convert.ToInt32(data["receive"]);
                            tempList.Add(model);
                        }
                        dataService.EmailList = tempList;
                        TypeEventSystem.Send<UpdateEmailInfoEvent>();
                    }
                    else if (type == "2" && dic.TryGetValue("read", out var readFlag) && readFlag != null)//读邮件
                    {
                        if (dataService.EmailList is { Count: > 0 })
                        {
                            foreach (var model in dataService.EmailList)
                            {
                                if (model.mid == emailID)
                                {
                                    model.read = Convert.ToInt32(readFlag);
                                    break;
                                }
                            }
                        }
                        TypeEventSystem.Send<UpdateEmailInfoEvent>();
                    }
                    else if (type == "3" && dic.TryGetValue("receive", out var receiveFlag) && receiveFlag != null)//领取奖励
                    {
                        if (dataService.EmailList is { Count: > 0 })
                        {
                            foreach (var model in dataService.EmailList)
                            {
                                if (model.mid == emailID)
                                {
                                    model.receive = Convert.ToInt32(receiveFlag);
                                    if (model.receive == 1) action?.Invoke();
                                    break;
                                }
                            }
                        }
                        TypeEventSystem.Send<UpdateEmailInfoEvent>();
                    }
                    else if (type == "4" && dic.TryGetValue("states", out var states) && states != null) //删除
                    {
                        dic.TryGetValue("msg", out var msg);
                        if (Convert.ToString(states) == "1")
                        {
                            List<EmailInfoModel> list1 = new List<EmailInfoModel>();
                            if (dataService.EmailList is { Count: > 0 })
                            {
                                foreach (var model in dataService.EmailList)
                                {
                                    if (model.mid != emailID)
                                    {
                                        list1.Add(model);
                                    }
                                }
                                dataService.EmailList = list1;
                                TypeEventSystem.Send<UpdateEmailInfoEvent>();
                            }
                            else
                            {
                                if (msg != null)
                                {
                                    string str = Convert.ToString(msg);
                                    if (str == "unread")
                                    {

                                    }
                                    else if (str == "unreceive")
                                    {

                                    }
                                }
                            }
                        }
                    }
                    else if (type == "5" && dic.TryGetValue("states", out var states1) && states1 != null)//全部删除
                    {
                        if (Convert.ToString(states1) == "1")
                        {
                            dataService.EmailList = null;
                            TypeEventSystem.Send<UpdateEmailInfoEvent>();
                        }
                    }
                    else if (type == "6" && dic.TryGetValue("states", out var states2) && states2 != null)//全部领取
                    {
                        if (Convert.ToString(states2) == "1")
                        {
                            action?.Invoke();
                        }
                    }
                }
            }));
        }

        public static bool CamGetSubscribeReward()
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            int seconds = (int)dataService.GetPropNum((int)PropEnum.MonthCard) - TimeUtils.UtcNow();
            if (seconds > 0)
            {
                if (!dataService.CheckDailyFlag(FlagType.Month))
                {
                    return true;
                }
            }
            seconds = (int)dataService.GetPropNum((int)PropEnum.WeekCard) - TimeUtils.UtcNow();
            if (seconds > 0)
            {
                if (!dataService.CheckDailyFlag(FlagType.Week))
                {
                    return true;
                }
            }
            return false;
        }

        static IEnumerator GetRequest(string url, Action<bool, string> callback)
        {
            using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
            {
                yield return webRequest.SendWebRequest();

                if (webRequest.result == UnityWebRequest.Result.ConnectionError || webRequest.result == UnityWebRequest.Result.ProtocolError)
                {
                    Debug.LogError("Error: " + webRequest.error);
                    callback?.Invoke(false, "");
                }
                else
                {
                    Debug.Log($"{url}, Response=> {webRequest.downloadHandler.text}");
                    callback?.Invoke(true, webRequest.downloadHandler.text);
                }
            }
        }

        public static IEnumerator DownloadJpg2(string url, string dst, Action<string> callback)
        {
            WWW www = new WWW(url);
            yield return www;
            if (www.error != null)
            {
                Debug.LogError(www.error);
                yield return null;
            }

            if (www.error != null)
            {
                byte[] bytes = www.texture.EncodeToJPG();
#if UNITY_WEBGL && !UNITY_EDITOR
                WXFileSystemManager fs = WX.GetFileSystemManager();
                fs.WriteFileSync(dst, bytes);
#else
                File.WriteAllBytes(dst, bytes);
#endif
                callback?.Invoke(dst);
            }
            else
            {
                callback?.Invoke("");
            }
        }

        public static IEnumerator DownloadJpg(string url, string dst, Action<bool, string> callback)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            WxDownloadJpg(url, dst, callback);
            yield return null;
#else
            string imageUrl = url;
            UnityWebRequest request = UnityWebRequestTexture.GetTexture(imageUrl);
            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError($"Image:{url} download failed: " + request.error);
                callback?.Invoke(false, "");
            }
            else
            {
                // Debug.LogError($"==========图片下载成功 {dst}");
                Texture2D tex = DownloadHandlerTexture.GetContent(request);
                byte[] bytes = tex.EncodeToJPG();
                File.WriteAllBytes(dst, bytes);
                callback?.Invoke(true, dst);
            }
#endif
        }

        public static void WxDownloadJpg(string downloadUrl, string dst, Action<bool, string> callback)
        {
            WX.DownloadFile(new DownloadFileOption()
            {
                url = downloadUrl,
                success = (res) =>
                {
                    if (res.statusCode == 200)
                    {
                        // Debug.Log("下载成功, 临时路径1: " + res.tempFilePath);
                        var dst = GetAvatarUrlFilePath(downloadUrl);
                        WXFileSystemManager fs = WX.GetFileSystemManager();
                        byte[] fileData = fs.ReadFileSync(res.tempFilePath);
                        fs.WriteFileSync(dst, fileData, "utf-8");
                        callback?.Invoke(true, dst);
                    }
                    else
                    {
                        Debug.LogError("下载失败, 状态码: " + res.statusCode);
                        callback?.Invoke(false, "");
                    }
                },
                fail = (err) =>
                {
                    Debug.LogError("下载失败: " + err.errMsg);
                    callback?.Invoke(false, "");
                }
            });
        }

        public static void WxUploadImage(string uploadUrl, string filePath, string name, Dictionary<string, string> formData, Action<bool> callback)
        {
            WX.UploadFile(new UploadFileOption()
            {
                url = uploadUrl,
                filePath = filePath,
                name = name,
                formData = formData,
                success = (res) =>
                {
                    Debug.Log("上传成功, 返回数据: " + res.data);
                    callback?.Invoke(true);
                },
                fail = (err) =>
                {
                    Debug.LogError("上传失败: " + err.errMsg);
                    callback?.Invoke(false);
                }
            });
        }


        //[[1,0.01],[2,0.1],[2,0.899]]
        public static int RandomIntFromFormatString(string str)
        {
            var groupStr = str.Replace(" ", "").Replace("[", "").Replace("]", "");
            var group = Array.ConvertAll(groupStr.Split(","), (str) => float.Parse(str));
            var total = 0f;
            for (int i = 0; i < group.Length / 2; i++)
            {
                total += group[i * 2 + 1];
            }

            var rv = UnityEngine.Random.value * total;
            var acc = 0f;
            int value = 1;
            for (int i = 0; i < group.Length / 2; i++)
            {
                acc += group[i * 2 + 1];
                if (rv <= acc)
                {
                    value = (int)group[i * 2];
                    break;
                }
            }

            return value;
        }

        public static bool IsInHomeView()
        {
            return UIView.IsViewVisible(Doozy.Engine.UI.Base.NamesDatabase.GENERAL, Constants.ViewName_Home);
        }

        public static float RandomFloatFromFormatString(string str)
        {
            var groupStr = str.Replace(" ", "").Replace("[", "").Replace("]", "");
            var group = Array.ConvertAll(groupStr.Split(","), (str) => float.Parse(str));
            var total = 0f;
            for (int i = 0; i < group.Length / 2; i++)
            {
                total += group[i * 2 + 1];
            }

            var rv = UnityEngine.Random.value * total;
            var acc = 0f;
            float value = 1;
            for (int i = 0; i < group.Length / 2; i++)
            {
                acc += group[i * 2 + 1];
                if (rv <= acc)
                {
                    value = group[i * 2];
                    break;
                }
            }

            return value;
        }

        public static T GetRandomValue<T>(List<T> list)
        {
            if (list.Count == 0)
                return default;
            System.Random random = new System.Random();
            int randomIndex = random.Next(list.Count);
            return list[randomIndex];
        }

        public static List<CardData> CloneCardDataList(List<CardData> cards)
        {
            List<CardData> cardList = new List<CardData>();
            if (cards == null)
                return cardList;
            foreach (var item in cards)
            {
                cardList.Add(item.Copy());
            }
            return cardList;
        }

        public static string GenerateRandomName()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            System.Random random = new System.Random();
            string name = "";
            for (int i = 0; i < 8; i++)
            {
                name += chars[random.Next(chars.Length)];
            }

            return name;
        }

        public static void SetTextWithEllipsis(Text txt, string value)
        {
            value = ReplaceSpace(value);
            var textComponent = txt.GetComponent<Text>();
            var generator = new TextGenerator();
            var rectTransform = textComponent.GetComponent<RectTransform>();
            var settings = textComponent.GetGenerationSettings(rectTransform.rect.size);
            generator.Populate(value, settings);
            var characterCountVisible = generator.characterCountVisible;
            var updatedText = value;
            if (value.Length > characterCountVisible)
            {
                updatedText = value.Substring(0, characterCountVisible - 3);
                updatedText += "…";
            }

            updatedText = ReplaceSpaceBack(updatedText);
            textComponent.text = updatedText;
        }

        public static void HandleUIEffect(GameObject obj,Canvas rootCanvas)
        {
            if (rootCanvas != null)
            {
                var efScale = Camera.main.orthographicSize / 400;
                var ps = obj.GetComponentsInChildren<ParticleSystem>(true);
                foreach (var p in ps)
                {
                    ParticleSystemRenderer r = p.GetComponent<ParticleSystemRenderer>();
                    r.sortingLayerName = "UI";
                    r.sortingOrder = rootCanvas.sortingOrder + r.sortingOrder;

                    var mainModule = p.main;
                    if (mainModule.scalingMode != ParticleSystemScalingMode.Hierarchy)
                    {
                        Vector3 initScale = r.transform.localScale;
                        Debug.LogError($"{r.transform.name}---{initScale}---{initScale * efScale}");
                        r.transform.localScale = initScale * efScale;
                    }
                }

                var sg = obj.GetComponentsInChildren<SortingGroup>(true);
                foreach (var t in sg)
                {
                    t.sortingLayerName = "UI";
                    t.sortingOrder = rootCanvas.sortingOrder + t.sortingOrder;
                }
            }
        }

        public static string GetCollectIcon(ActivityType activityType)
        {
            string icon = "";
            if (activityType == ActivityType.collectFlower)
            {
                icon = "rose";
            }
            else if(activityType == ActivityType.passRank)
            {
                icon = "hdjb_ts_1";
            }
            else if(activityType == ActivityType.carRank)
            {
                icon = "lt";
            }
            else if(activityType == ActivityType.endlessLevel)
            {
                icon = "hg";
            }
            else if(activityType == ActivityType.seasonPass)
            {
                icon = "syrk_1_4";
            }
            else if(activityType == ActivityType.collectMusic)
            {
                icon = "xzyf_yf";
            }
            else if(activityType == ActivityType.collectLoveCard)
            {
                icon = "axfk_11";
            }
            else if(activityType == ActivityType.limitPk)
            {
                icon = "qjbs_13";
            }
            else if(activityType == ActivityType.digTreasure)
            {
                icon = "dig";
            }
            else if(activityType == ActivityType.cookMeal)
            {
                icon = "cook";
            }
            return icon;
        }

        public static bool CheckDirectShowRestart()
        {
            if (BattleDataMgr.Instance.GetHandCardsNum() > 0)
            {
                if (!GameUtils.IsSpecialLevel() && ActivityManager.Instance.EnergyActivity.GetInfiniteSecond() <= 0)
                {
                    return false;
                }
                if (ActivityManager.Instance.CollectLoveCardActivity.CheckReadyFull())
                {
                    return false;
                }
                else if (ActivityManager.Instance.MysteriousSeedActivity.CheckFinalBallon())
                {
                    return false;
                }
                else if (ActivityManager.Instance.RabbitGiftActivity.CheckLoseThreeWin())
                {
                    return false;
                }
                if (ActivityManager.Instance.GetCollectActivity().Count > 0)
                {
                    return false;
                }
                ShowRestartGamePopup();
                return true;
            }
            return false;
        }

        public static void ShowRestartGamePopup()
        {
            BoxBuilder.ShowRestartPopup();
            TypeEventSystem.Send(new BattleCommandEvent() {command = BattleCommand.LoseGame});
            GameController.Instance.ExitBattle();
            MoveGameViewBottom t = GameObjManager.Instance.PopClass<MoveGameViewBottom>(true);
            TypeEventSystem.Send<MoveGameViewBottom>(t);
            if (ActivityManager.Instance.LavaPassActivity.CheckShowLavaPopup(BoxBuilder.ShowRestartPopup)) return;
        }
        
        public static void SetPreUnlock(bool set,GameObject obj)
        {
            if(obj == null) return;
            if (set)
            {
                obj.MSetActive(set);

            }
            foreach (var image in obj.GetComponentsInChildren<Image>(true))
            {
                if (image.color == Color.white || image.color == Color.gray)
                {
                    image.color = set ? Color.gray : Color.white;
                }
            }
            foreach (var text in obj.GetComponentsInChildren<Text>(true))
            {
                if (text.color == Color.white || text.color == Color.gray)
                {
                    text.color = set ? Color.gray : Color.white;
                }
            }
        }

        public static bool CheckFuncIsUnlock(string acType,bool popTip = false)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var dataService = MainContainer.Container.Resolve<IDataService>();
            bool unlock = true;
            int unlockLv = 0;
            foreach (var model in configService.UnlockConfig)
            {
                unlockLv = model.Value.unlockLevel;
                if (acType == model.Value.type)
                {
                    unlock = dataService.MaxLevel >= unlockLv;
                    break;
                }
            }
            if (acType != "passbox" && GameUtils.IsSpecialLevel()) return false;
            if (popTip && !unlock) BoxBuilder.ShowToast($"关卡达到第{unlockLv}关开启活动~");
            return unlock;
        }

        public static void SetBubbleItem(Transform bubbleItem,Image icon,int propId)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var dataService = MainContainer.Container.Resolve<IDataService>();
            
            bubbleItem.transform.SetAsFirstSibling();
            bubbleItem.transform.localPosition = icon.transform.localPosition;
            bubbleItem.gameObject.MSetActive(true);
            foreach (var pair in bubbleItem.GetComponentsInChildren<UIEffect>(true))
            {
                pair.effectFactor = 0;
            }
            int level = dataService.GetRegionLevel();
            int id = dataService.GetRegionId();
            if (level == 0) level = 1;
            foreach (var pair in configService.MergeLevelBoxConfig)
            {
                if (pair.Value.level == level && pair.Value.region_id == id)
                {
                    Dictionary<int, int> rewards = AnalysisPropString(pair.Value.rewards);
                    bubbleItem.GetComponent<BubbleRewardItem>().EnableChangIcon(rewards);
                    break;
                }
            }
        }

        public static void LoadPropSprite(Image icon,int prop)
        {
            var propId = prop == (int) PropEnum.Coin ? (int) PropEnum.MultiplyCoin : prop;
            var bubbleItem = icon.transform.parent.Find("BubbleItem");
            if (propId == (int) PropEnum.BubbleGift)
            {
                icon.gameObject.MSetActive(false);
                if (bubbleItem != null)
                {
                    SetBubbleItem(bubbleItem,icon,prop);
                }
                else
                {
                    bubbleItem = GameObjManager.Instance.PopGameObject(GameObjType.BubbleItem).transform;
                    bubbleItem.name = "BubbleItem";
                    bubbleItem.SetParent(icon.transform.parent);
                    bubbleItem.transform.localScale = Vector3.one;
                    SetBubbleItem(bubbleItem,icon,prop);
                }
                return;
            }
            
            if(bubbleItem != null) bubbleItem.gameObject.MSetActive(false);
            icon.gameObject.MSetActive(true);
            icon.LoadPropSprite(propId, true, () =>
            {
                float targetHeight = 100;
                float targetWidth = 80;
                float originalWidth = icon.sprite.rect.width;
                float originalHeight = icon.sprite.rect.height;
                float aspectRatio = originalWidth / originalHeight;
                float newWidth;
                float newHeight;
                if (originalHeight >= originalWidth)
                {
                    newHeight = targetHeight;
                    newWidth = targetHeight * aspectRatio;
                }
                else
                {
                    newWidth = targetWidth;
                    newHeight = targetWidth / aspectRatio;
                }

                icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
            });
        }

        public static bool IsSpecialLevel()
        {
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            if (!dataService.IsOverRookie()) return true;
            if (!dataService.IsHasFirstNpc()) return true;
            if (!dataService.IsRookieShowed(21)) return true;
            return false;
        }

        public static Vector3 GetLocalPosition(Transform parent,Transform targetObj,Vector3 offset)
        {
            Vector3 localPosition = parent.InverseTransformPoint(targetObj.position);
            return localPosition + offset;
        }
        
        public static string ReplaceSpace(string sourceStr)
        {
            return sourceStr.Replace(" ", "^");
        }

        public static string ReplaceSpaceBack(string sourceStr)
        {
            return sourceStr.Replace("^", " ");
        }
    }
}