﻿using System;
using System.Collections.Generic;
using MiniJSON;
using UnityEngine;
using WeChatWASM;

namespace SoliUtils
{
    public static class WeChatMiniGame
    {
        public static void OnShow(Action<OnShowListenerResult> result)
        {
            if(GameCommon.IsOffMode) return;
            WX.OnShow(result);
        }

        public static void OnHide(Action<GeneralCallbackResult> res)
        {
            if(GameCommon.IsOffMode) return;
            WX.OnHide(res);
        }

        public static void InitQySdk()
        {
            if(GameCommon.IsOffMode) return;
            ExternFunc.QYSDK_create(120, true);
            ExternFunc.QYSDK_login();
            ExternFunc.WXCloud_init();
        }

        public static void OpenCustomerService()
        {
            if(GameCommon.IsOffMode) return;
            ExternFunc.QYSDK_openCustomerService();
        }

        public static void CleanAndRestart()
        {
            if(GameCommon.IsOffMode) return;
            ExternFunc.CleanAndRestart();
        }

        public static void Restart()
        {
            if(GameCommon.IsOffMode) return;
            ExternFunc.Restart();
        }

        public static string UserId;
        public static string UserName = "";
        public static string OpenId;

        private static void ReportData(int data_type, string server_id, string server_name,
            string role_id, string role_name, int role_level, int money_num, int vip)
        {
            if(GameCommon.IsOffMode) return;
            ExternFunc.QYSDK_submitData(data_type, server_id, server_name, role_id, role_name, role_level, money_num, vip);
        }

        public static void ReportCreateRole()
        {
            if(GameCommon.IsOffMode) return;
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            ReportData(2, "1", "mini", UserId, UserName, dataService.MaxLevel, (int)dataService.Coin, 0);
        }

        public static void ReportEnterGame()
        {
            if(GameCommon.IsOffMode) return;
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            ReportData(3, "1", "mini", UserId, UserName, dataService.MaxLevel, (int)dataService.Coin, 0);
        }

        public static void ReportLevelUp()
        {
            if(GameCommon.IsOffMode) return;
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            ReportData(4, "1", "mini", UserId, UserName, dataService.MaxLevel, (int)dataService.Coin, 0);
        }

        public static void ReportLeaveGame()
        {
            if(GameCommon.IsOffMode) return;
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            ReportData(5, "1", "mini", UserId, UserName, dataService.MaxLevel, (int)dataService.Coin, 0);
        }

        public static void ShowRewardAd(string place_id)
        {
            if(GameCommon.IsOffMode) return;
            ExternFunc.QYSDK_showRewardAd("adunit-bee6c9e6f29f0242", place_id);
        }

        public static void Pay(string product_id, int money, int game_gold, string product_name, string product_desc, string order_id)
        {
            if(GameCommon.IsOffMode) return;
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            var user_name = dataService.UserName;
            if(string.IsNullOrEmpty(user_name))
                user_name = WeChatMiniGame.UserName;
            if(string.IsNullOrEmpty(user_name))
                user_name = GameUtils.GenerateRandomName();
            ExternFunc.QYSDK_pay(dataService.UserId, user_name, dataService.MaxLevel, money, game_gold, product_id, product_name, product_desc, order_id);
        }

        public static void ReportPay(string svr_order, string game_order, int money, string product_id, string item_desc)
        {
            if(GameCommon.IsOffMode) return;
            ExternFunc.QXReportSDK_pay(svr_order, game_order, money, product_id, item_desc, 0);
        }

        public static void ReadUserData()
        {
            if(GameCommon.IsOffMode) return;
            Debug.Log($"WeChatMiniGame.ReadUserData UserId:{UserId}");
            if (string.IsNullOrEmpty(UserId))
                return;
            ExternFunc.WXCloud_readUserData(UserId);
        }

        public static bool LockWriteOpt = false;


        public static void WriteUserData(string data_json)
        {
            if(GameCommon.IsOffMode) return;
            Debug.Log(
                $"WeChatMiniGame.WriteUserData UserId:{UserId} data_json:{data_json} LockWriteOpt:{LockWriteOpt}");
            if (string.IsNullOrEmpty(UserId) || string.IsNullOrEmpty(data_json) || LockWriteOpt)
                return;
            LockWriteOpt = true;
            ExternFunc.WXCloud_writeUserData(UserId, data_json);
        }

        public static void UploadFile(string cloudPath, string filePath)
        {
            if(GameCommon.IsOffMode) return;
            var storageService = MainContainer.Container.Resolve<IStorageService>();
            if (!storageService.FileExists(filePath))
            {
                return;
            }
            ExternFunc.WXCloud_uploadFile(cloudPath, filePath);
        }

        public static void CheckWxAuthInfo(Action<bool, string> callback)
        {
            if(GameCommon.IsOffMode) return;
            var dataService = MainContainer.Container.Resolve<IDataService>();
            var storageService = MainContainer.Container.Resolve<IStorageService>();
            GetSettingOption setTingOp = new GetSettingOption();
            setTingOp.success = (e) =>
            {
                if (!e.authSetting.ContainsKey("scope.userInfo") || !e.authSetting["scope.userInfo"])
                {
                    //用户没有允许获取个人信息，调用请求获取用户个人信息接口   
                    WXUserInfoButton btn = WX.CreateUserInfoButton(0, 0, Screen.width, Screen.height, "zh_CN", false);
                    btn.OnTap((data) =>
                    {
                        if (data.errCode == 0)
                        {
                            Loom.QueueOnMainThread(() =>
                            {
                                Debug.Log($"个人信息1:{data.userInfo.nickName},{data.userInfo.country},{data.userInfo.province},{data.userInfo.city},{data.userInfo.gender},{data.userInfo.avatarUrl}。 ");
                                //用户已允许获取个人信息，返回的data即为用户信息
                                dataService.UserName = data.userInfo.nickName;
                                if(string.IsNullOrEmpty(dataService.UserName))
                                    dataService.UserName = GameUtils.GenerateRandomName();
                                var dst = GameUtils.GetAvatarUrlFilePath(data.userInfo.avatarUrl);
                                if (dataService.UserAvatar != data.userInfo.avatarUrl || !storageService.FileExists(dst))
                                {
                                    Debug.LogError($"开始下载头像 downloadDst:{dst}");
                                    StaticCoroutine.StartCoroutine(GameUtils.DownloadJpg(data.userInfo.avatarUrl,
                                        dst, (ret, path) =>
                                        {
                                            // Debug.LogError($"下载头像完成1 ret:{ret}");
                                            callback?.Invoke(ret, path);
                                            if (ret)
                                            {
                                                dataService.UserAvatar = data.userInfo.avatarUrl;
                                                dataService.SaveData(true);
                                            }
                                        }));
                                }
                                else
                                {
                                    callback?.Invoke(true, dst);
                                }
                            });
                        }
                        else
                        {
                            //用户未允许获取个人信息
                            Debug.LogError($"WeChatMiniGame.CheckAuthSetting failed");
                        }

                        btn.Destroy();
                    });
                }
                else
                {
                    //用户已经允许获取个人信息，直接获取用户个人信息
                    GetUserInfoOption userInfo = new GetUserInfoOption()
                    {
                        withCredentials = true,
                        lang = "zh_CN",
                        success = (data) =>
                        {
                            Loom.QueueOnMainThread(() =>
                            {
                                Debug.Log($"个人信息2:{data.userInfo.nickName},{data.userInfo.country},{data.userInfo.province},{data.userInfo.city},{data.userInfo.gender},{data.userInfo.avatarUrl}。 ");
                                dataService.UserName = data.userInfo.nickName;
                                if(string.IsNullOrEmpty(dataService.UserName))
                                    dataService.UserName = GameUtils.GenerateRandomName();

                                var dst = GameUtils.GetAvatarUrlFilePath(data.userInfo.avatarUrl);
                                if (dataService.UserAvatar != data.userInfo.avatarUrl || !storageService.FileExists(dst))
                                {
                                    Debug.LogError($"开始下载头像 downloadDst:{dst}");
                                    StaticCoroutine.StartCoroutine(GameUtils.DownloadJpg(data.userInfo.avatarUrl,
                                        dst, (ret, path) =>
                                        {
                                            // Debug.LogError($"下载头像完成1 ret:{ret}");
                                            callback?.Invoke(ret, path);
                                            if (ret)
                                            {
                                                dataService.UserAvatar = data.userInfo.avatarUrl;
                                                dataService.SaveData(true);
                                            }
                                        }));
                                }
                                else
                                {
                                    callback?.Invoke(true, dst);
                                }
                            });
                        }
                    };
                    WX.GetUserInfo(userInfo);
                }
            };
            WX.GetSetting(setTingOp);
        }

        public static void ReportLevelRanking()
        {
            if(GameCommon.IsOffMode) return;
            IDataService dataService = MainContainer.Container.Resolve<IDataService>();
            SetUserCloudStorageOption opt = new SetUserCloudStorageOption();
            KVData data = new KVData();
            data.key = "user_level";
            Dictionary<string, int> data1 = new Dictionary<string, int>();
            data1.Add("score",  dataService.MaxLevel);
            data1.Add("update_time",  TimeUtils.UtcNow());
            Dictionary<string, object> data2 = new Dictionary<string, object>();
            data2.Add("wxgame", data1);
            var msg = Json.Serialize(data2);
            Debug.Log($"WeChatMiniGame.ReportLevelRanking msg, {msg}");
            data.value = msg;
            opt.KVDataList = new[] { data };
            opt.complete = result =>
            {
                Debug.Log($"WeChatMiniGame.ReportLevelRanking complete, {result.errMsg}");
            };
            opt.success = result =>
            {
                Debug.Log($"WeChatMiniGame.ReportLevelRanking success, {result.errMsg}");
            };
            opt.fail = result =>
            {
                Debug.Log($"WeChatMiniGame.ReportLevelRanking fail, {result.errMsg}");
            };
            WX.SetUserCloudStorage(opt);
        }

        public static void GetRankingData()
        {
            if(GameCommon.IsOffMode) return;
            ExternFunc.WXCloud_getRanking();
        }

        public static void WXShare()
        {
            if(GameCommon.IsOffMode) return;
            ExternFunc.WXShare();
        }

        public static void ReportGameStart()
        {
            if(GameCommon.IsOffMode) return;
            WX.ReportGameStart();
        }

        public static void ReportGameSceneError(int sceneId, int errorType = 0, string errStr = "", string extJsonStr = "")
        {
            if(GameCommon.IsOffMode) return;
            WX.ReportGameSceneError(sceneId, errorType, errStr, extJsonStr);
        }

        public static void GetSystemInfo(ref string platform, ref float width, ref float height)
        {
            if(GameCommon.IsOffMode) return;
            float w = 0f;
            float h = 0f;
            string pf = "";
            GetSystemInfoOption opt = new GetSystemInfoOption();
            opt.success = info =>
            {
                w = (float)info.screenWidth;
                h = (float)info.screenHeight;
                pf = info.platform;
            };
            WX.GetSystemInfo(opt);
            width = w;
            height = h;
            platform = pf;
        }

        public static void HideOpenData()
        {
            if(GameCommon.IsOffMode) return;
            WX.HideOpenData();
        }

        public static void ShowOpenData(Texture texture, int x, int y, int width, int height)
        {
            if(GameCommon.IsOffMode) return;
            WX.ShowOpenData(texture, x, y, width, height);
        }

        public static void OpenDataPostMessage(string msg)
        {
            if(GameCommon.IsOffMode) return;
            WX.GetOpenDataContext().PostMessage(msg);
        }

    }
}