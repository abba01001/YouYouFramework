using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

#if UNITY_WEBGL
using WeChatWASM;
#endif

namespace SoliUtils
{
    public class AnalyticUtils
    {

        public static void ReportEvent(string eventName, Dictionary<string, object> msg)
        {
            if (GameCommon.IsOffMode) return;
 #if !UNITY_EDITOR
            var info = WX.GetAccountInfoSync();
            var envVersion = info.miniProgram.envVersion;
            var version = info.miniProgram.version;
            msg.TryAdd("env_version", envVersion);
            msg.TryAdd("app_version", version);
            msg.TryAdd("soli_device_id", DeviceUtils.GetDeviceId());
            string json = MiniJSON.Json.Serialize(msg);
            ExternFunc.TA_track(eventName, json);
#endif
        }

        public static void ReportFirstEvent(string eventName, Dictionary<string, object> msg)
        {
            if (GameCommon.IsOffMode) return;
            ReportEvent(eventName, msg);
//  #if !UNITY_EDITOR
//             var info = WX.GetAccountInfoSync();
//             var envVersion = info.miniProgram.envVersion;
//             var version = info.miniProgram.version;
//             msg.TryAdd("env_version", envVersion);
//             msg.TryAdd("app_version", version);
//             msg.TryAdd("soli_device_id", DeviceUtils.GetDeviceId());
//             string json = MiniJSON.Json.Serialize(msg);
//             ExternFunc.TA_trackFirst(eventName, json);
// #endif
        }

        public void ReportSuperProperties(string jsonStr)
        {
            if (GameCommon.IsOffMode) return;
        }

        public static void ReportUser_Set(string key, object value)
        {
            if (GameCommon.IsOffMode) return;
            Dictionary<string, object> msg = new Dictionary<string, object>();
            msg.Add(key, value);
            string json = MiniJSON.Json.Serialize(msg);
            ExternFunc.TA_userSet(json);
        }

        public static void ReportUser_SetOnce(string key, object value)
        {
            if (GameCommon.IsOffMode) return;
            Dictionary<string, object> msg = new Dictionary<string, object>();
            msg.Add(key, value);
            string json = MiniJSON.Json.Serialize(msg);
            ExternFunc.TA_userSetOnce(json);
        }

        public static void ReportUser_Add(string key, float value)
        {
            if (GameCommon.IsOffMode) return;
            Dictionary<string, object> msg = new Dictionary<string, object>();
            msg.Add(key, value);
            string json = MiniJSON.Json.Serialize(msg);
            ExternFunc.TA_userAdd(json);
        }

        public static void ReportUser_Append(string key, object value)
        {
        }

        public static void ReportUser_Unset(string[] key)
        {
        }

        public static void ReportUser_Delete()
        {
        }

        public static void AddAccountId(string aId)
        {
        }

        public static void RemoveAccountId()
        {
        }
    }
}
