using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UniRx;
using UnityEngine;
using UnityEngine.Networking;
using WeChatWASM;

namespace SoliUtils
{
    public static class HuaweiCloudUtils
    {
        private static int write_userdata_time = 0;
        private static readonly int WRITE_UESRDATA_INTERVAL = 5;
        private static string ObsGetUrl = "";
        private static Dictionary<string, object> ObsGetHeader = new Dictionary<string, object>();
        private static string ObsPutUrl = "";
        private static Dictionary<string, object> ObsPutHeader = new Dictionary<string, object>();
        private static string ObsAvatarUrl = "";
        private static Dictionary<string, object> ObsAvatarHeader = new Dictionary<string, object>();


        static IEnumerator GetRequest(string url, Action<bool, string> callback)
        {
            using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
            {
                yield return webRequest.SendWebRequest();

                if (webRequest.result == UnityWebRequest.Result.ConnectionError || webRequest.result == UnityWebRequest.Result.ProtocolError)
                {
                    Debug.LogError($"url:{url} Error: " + webRequest.error);
                    callback?.Invoke(false, "");
                }
                else
                {
                    // Debug.Log("Response: " + webRequest.downloadHandler.text);
                    callback?.Invoke(true, webRequest.downloadHandler.text);
                }
            }
        }

        public static void RequestLogin()
        {
            if (GameCommon.IsOffMode) return;
            string uid = WeChatMiniGame.UserId;
            string openid = WeChatMiniGame.OpenId;
            string deviceid = DeviceUtils.GetDeviceId();
            var time = TimeUtils.UtcNow();
            string flag = EncryptUtils.MD5Encrypt(uid + time + openid + Constants.ServerKey);
            string url = Constants.ApiUrl + "/login";
            url = $"{url}?uid={uid}&time={time}&flag={flag.ToLower()}&openid={openid}&deviceid={deviceid}";
            // Debug.LogError("==== {url}"+url);
            StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
            {
                if (ret)
                {
                    var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
                    if (dic != null)
                    {
                        dic.TryGetValue("status", out var status);
                        if (status != null)
                        {
                            int st = Convert.ToInt32(status);
                            GameCommon.IsOldUser = st == 1;
                            GameCommon.HasCheckUser = true;
                            if (!GameCommon.IsOldUser)
                            {
                                if(PlayerPrefs.HasKey(Constants.StorageKey.GameData))
                                {
                                    PlayerPrefs.DeleteKey(Constants.StorageKey.GameData);
                                }
                            }
                        }
                    }
                }
            }));
        }

        public static bool IsVerificateAuth()
        {
            return !string.IsNullOrEmpty(ObsGetUrl) && !string.IsNullOrEmpty(ObsPutUrl);
        }

        public static void RequestObsUrl(int ask_time = 10)
        {
            if (GameCommon.IsOffMode) return;
            if (ask_time <= 0)
                return;
            ask_time--;

            Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe(_ =>
            {
                string uid = WeChatMiniGame.UserId;
                string openid = WeChatMiniGame.OpenId;
                string deviceid = DeviceUtils.GetDeviceId();
                var time = TimeUtils.UtcNow();
                string flag = EncryptUtils.MD5Encrypt(uid + time + Constants.ServerKey);
                string url = Constants.ApiUrl + "/create_obs_url";
                url = $"{url}?uid={uid}&time={time}&flag={flag.ToLower()}&openid={openid}&deviceid={deviceid}";
                StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
                {
                    if (ret)
                    {
                        var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
                        if (dic != null)
                        {
                            dic.TryGetValue("status", out var status);
                            if (Convert.ToInt32(status) == 1) //在其他设备登录
                            {
                                if (GameCommon.IsEnterGame)
                                {
                                    BoxBuilder.ShowUpdateTipPopup(showBtnType: 1, jumpCb: () =>
                                    {
                                        WeChatMiniGame.Restart();
                                    },
                                    closeCb: null, content: "其他设备登录了你的账号，请重新登录", jumpText: "确定");
                                }
                            }
                            else
                            {
                                dic.TryGetValue("get_url", out var get_url);
                                ObsGetUrl = get_url.ToString();
                                dic.TryGetValue("get_header", out var get_header);
                                ObsGetHeader = get_header as Dictionary<string, object>;
                                dic.TryGetValue("put_url", out var put_url);
                                ObsPutUrl = put_url.ToString();
                                dic.TryGetValue("put_header", out var put_header);
                                ObsPutHeader = put_header as Dictionary<string, object>;
                                dic.TryGetValue("avatar_url", out var avatar_url);
                                ObsAvatarUrl = avatar_url.ToString();
                                dic.TryGetValue("avatar_header", out var avatar_header);
                                ObsAvatarHeader = avatar_header as Dictionary<string, object>;
                            }
                        }
                    }
                    else
                    {
                        if (ask_time > 0)
                        {
                            RequestObsUrl(ask_time);
                        }
                    }
                }));
            });
        }

        private static IEnumerator PutFileObject(string filePath, Action<bool> callback = null)
        {
            UnityWebRequest request = new UnityWebRequest(ObsPutUrl, "PUT");
            byte[] fileData = File.ReadAllBytes(filePath);
            request.uploadHandler = new UploadHandlerRaw(fileData);
            foreach (var item in ObsPutHeader)
            {
                request.SetRequestHeader(item.Key, item.Value.ToString());
            }

            yield return request.SendWebRequest();

            try
            {
                if (request.result != UnityWebRequest.Result.Success)
                {
                    Debug.LogError($"Error: {request.error}");
                    callback?.Invoke(false);
                }
                else
                {
                    Debug.Log("File uploaded successfully.");
                    callback?.Invoke(true);
                }
            }
            finally
            {
                request.Dispose();
            }
        }

        private static IEnumerator PutByteObject(byte[] value, Action<bool> callback = null)
        {
            UnityWebRequest request = new UnityWebRequest(ObsPutUrl, "PUT");
            request.uploadHandler = new UploadHandlerRaw(value);
            foreach (var item in ObsPutHeader)
            {
                request.SetRequestHeader(item.Key, item.Value.ToString());
            }

            yield return request.SendWebRequest();

            try
            {
                if (request.result != UnityWebRequest.Result.Success)
                {
                    if (request.responseCode == 403)
                        RequestObsUrl();
                    else
                        Debug.LogError($"Error: {request.error}");
                    callback?.Invoke(false);
                }
                else
                {
                    Debug.Log("File uploaded successfully.");
                    callback?.Invoke(true);
                }
            }
            finally
            {
                request.Dispose();
            }
        }

        private static IEnumerator PutStringObject(string value, Action<bool> callback = null)
        {
            UnityWebRequest request = new UnityWebRequest(ObsPutUrl, "PUT");
            request.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(value));
            foreach (var item in ObsPutHeader)
            {
                request.SetRequestHeader(item.Key, item.Value.ToString());
            }

            yield return request.SendWebRequest();

            try
            {
                if (request.result != UnityWebRequest.Result.Success)
                {
                    Debug.LogError($"Error: {request.error}");
                    callback?.Invoke(false);
                }
                else
                {
                    Debug.Log("File uploaded successfully.");
                    callback?.Invoke(true);
                }
            }
            finally
            {
                request.Dispose();
            }
        }

        private static IEnumerator PutAvatarByteObject(byte[] value, Action<bool> callback = null)
        {
            UnityWebRequest request = new UnityWebRequest(ObsAvatarUrl, "PUT");
            request.uploadHandler = new UploadHandlerRaw(value);
            foreach (var item in ObsAvatarHeader)
            {
                request.SetRequestHeader(item.Key, item.Value.ToString());
            }

            yield return request.SendWebRequest();

            try
            {
                if (request.result != UnityWebRequest.Result.Success)
                {
                    Debug.LogError($"Error: {request.error}");
                    callback?.Invoke(false);
                }
                else
                {
                    Debug.Log("File uploaded successfully.");
                    callback?.Invoke(true);
                }
            }
            finally
            {
                request.Dispose();
            }
        }

        private static IEnumerator PutAvatarFileObject(string filePath, Action<bool> callback = null)
        {
            // Debug.LogError($"开始上传头像 1 filePath:{filePath}");
            // #if UNITY_WEBGL && !UNITY_EDITOR
            //             Dictionary<string, string> headers = new Dictionary<string, string>();
            //             foreach (var item in ObsAvatarHeader)
            //             {
            //                 headers.Add(item.Key, item.Value.ToString());
            //             }
            //             GameUtils.WxUploadImage(ObsAvatarUrl, filePath, "test", headers, callback);
            //             yield return null;
            // #else
            UnityWebRequest request = new UnityWebRequest(ObsAvatarUrl, "PUT");
            // byte[] fileData = File.ReadAllBytes(filePath);

            WXFileSystemManager fs = WX.GetFileSystemManager();
            byte[] fileData = fs.ReadFileSync(filePath);
            request.uploadHandler = new UploadHandlerRaw(fileData);
            foreach (var item in ObsAvatarHeader)
            {
                request.SetRequestHeader(item.Key, item.Value.ToString());
            }

            // Debug.LogError("开始上传头像 2");
            yield return request.SendWebRequest();

            try
            {
                if (request.result != UnityWebRequest.Result.Success)
                {
                    if (request.responseCode == 403)
                        RequestObsUrl();
                    else
                        Debug.LogError($"PutAvatarFileObject Error: {request.error}");
                    callback?.Invoke(false);
                }
                else
                {
                    Debug.Log("PutAvatarFileObject successfully.");
                    callback?.Invoke(true);
                }
            }
            finally
            {
                request.Dispose();
            }
            // #endif
        }

        private static IEnumerator GetFileObject(string filePath, Action<bool> callback = null)
        {
            UnityWebRequest request = new UnityWebRequest(ObsGetUrl, "Get");
            request.downloadHandler = new DownloadHandlerBuffer();
            foreach (var item in ObsGetHeader)
            {
                request.SetRequestHeader(item.Key, item.Value.ToString());
            }

            yield return request.SendWebRequest();

            try
            {
                if (request.result != UnityWebRequest.Result.Success)
                {
                    Debug.LogError($"Error: {request.error}");
                    if (request.downloadHandler != null)
                    {
                        Debug.LogError("Error Response: " + request.downloadHandler.text);
                    }
                    callback?.Invoke(false);
                }
                else
                {
                    System.IO.File.WriteAllBytes(filePath, request.downloadHandler.data);
                    var content = Encoding.UTF8.GetString(request.downloadHandler.data);
                    callback?.Invoke(true);
                    Debug.Log($"File downloaded successfully to: {content}");
                }
            }
            finally
            {
                request.Dispose();
            }
        }

        private static IEnumerator GetStringObject(Action<bool, string> callback = null)
        {
            UnityWebRequest request = new UnityWebRequest(ObsGetUrl, "Get");
            request.downloadHandler = new DownloadHandlerBuffer();
            foreach (var item in ObsGetHeader)
            {
                request.SetRequestHeader(item.Key, item.Value.ToString());
            }
            yield return request.SendWebRequest();

            try
            {
                if (request.result != UnityWebRequest.Result.Success)
                {
                    // Debug.LogError($"GetStringObject responseCode: {request.responseCode}");
                    if (request.responseCode == 404 || request.downloadHandler.text.Contains("NoSuchKey"))
                        callback?.Invoke(true, "");
                    else
                    {
                        if (request.downloadHandler != null)
                        {
                            Debug.LogError("Error Response: " + request.downloadHandler.text);
                        }
                        callback?.Invoke(false, "");
                    }
                }
                else
                {
                    var content = Encoding.UTF8.GetString(request.downloadHandler.data);
                    // Debug.Log($"File downloaded successfully to: {content}");
                    callback?.Invoke(true, content);
                }
            }
            finally
            {
                request.Dispose();
            }
        }

        private static IEnumerator GetByteObject(Action<bool, byte[]> callback = null)
        {
            UnityWebRequest request = new UnityWebRequest(ObsGetUrl, "Get");
            request.downloadHandler = new DownloadHandlerBuffer();
            foreach (var item in ObsGetHeader)
            {
                request.SetRequestHeader(item.Key, item.Value.ToString());
            }
            yield return request.SendWebRequest();

            try
            {
                if (request.result != UnityWebRequest.Result.Success)
                {
                    if (request.responseCode == 403)
                        RequestObsUrl();
                    else
                        Debug.LogError($"Error Res: {request.error}");
                    callback?.Invoke(false, null);
                }
                else
                {
                    // var content = Encoding.UTF8.GetString(request.downloadHandler.data);
                    // Debug.Log($"File downloaded successfully to: {content}");
                    callback?.Invoke(true, request.downloadHandler.data);
                }
            }
            finally
            {
                request.Dispose();
            }
        }

        public static void UploadUserAvatar(string filePath, Action<bool> callback)
        {
            // PutFileObject($"avatars/{user_id}.jpg", filePath);
            StaticCoroutine.StartCoroutine(PutAvatarFileObject(filePath, callback));
        }


        public static void ForceWriteUserData(string user_id, string data_json)
        {
            if (GameCommon.IsOffMode) return;
            if (!GameCommon.IsDataUpload) return;
            Debug.Log($"HuaweiCloudUtils.WriteUserData UserId:{user_id} data_json:{data_json}");
            write_userdata_time = TimeUtils.UtcNow();
            var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(data_json);
            if (dic.TryGetValue(Constants.StorageKey.UserInfoData, out var data))
            {
                var userInfoData = (Dictionary<string, object>)data;
                var content = MiniJSON.Json.Serialize(userInfoData);
                var bytes = DESEncrypt.Encrypt(content, Constants.DesKey);
                // var compressBytes = DESEncrypt.Compress(content);
                StaticCoroutine.StartCoroutine(PutByteObject(bytes));
            }
        }

        public static void WriteUserData(string user_id, string data_json)
        {
            if (GameCommon.IsOffMode) return;
            if (!GameCommon.IsDataUpload) return;
            Debug.Log($"HuaweiCloudUtils.WriteUserData start");
            int now = TimeUtils.UtcNow();
            if (now < write_userdata_time + WRITE_UESRDATA_INTERVAL)
                return;
            write_userdata_time = now;
            Debug.Log($"HuaweiCloudUtils.WriteUserData UserId:{user_id} data_json:{data_json}");
            var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(data_json);
            if (dic.TryGetValue(Constants.StorageKey.UserInfoData, out var data))
            {
                var userInfoData = (Dictionary<string, object>)data;
                var content = MiniJSON.Json.Serialize(userInfoData);
                var bytes = DESEncrypt.Encrypt(content, Constants.DesKey);
                // var compressBytes = DESEncrypt.Compress(content);
                StaticCoroutine.StartCoroutine(PutByteObject(bytes));
            }
        }

        public static void ReadUserData(string user_id, Action<bool, string> callback)
        {
            Debug.Log($"HuaweiCloudUtils.ReadUserData UserId:{user_id}");
            System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
            stopwatch.Start();
            StaticCoroutine.StartCoroutine(GetByteObject(
                (b, ret) =>
                {
                    stopwatch.Stop();
                    Debug.Log("HuaweiCloudUtils.ReadUserData Time: " + stopwatch.ElapsedMilliseconds + " ms");
                    var content = "";
                    if (ret != null)
                    {
                        // content = DESEncrypt.Decompress(ret);
                        // Debug.LogError("userdata================= test");
                        content = DESEncrypt.Decrypt(ret, Constants.DesKey);
                        Debug.Log("userdata================= " + content);
                    }
                    callback?.Invoke(b, content);
                }
            ));
        }

    }
}