﻿using System;
using Widgets;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Core.PathCore;
using DG.Tweening.Plugins.Options;

namespace SoliUtils
{
    public static class ExtendFunction
    {
        public static T Get<T>(this GameObject go, string path) where T : Component => go.transform.Get<T>(path);
        public static T Get<T>(this Transform ts, string path) where T : Component
        {
            Transform result = ts.Find(path);
            if (result == null)
            {
                GameUtils.LogError($"该路径未找到对应的组件{path}");
                return null;
            }
            return result.GetComponent<T>();
        }

        public static Transform FindOrNull(this Transform ts, string path)
        {
            if (string.IsNullOrEmpty(path)) return null;
            return ts.Find(path);
        }

        public static void SetButtonClick(this Button btn, UnityEngine.Events.UnityAction action, bool isClear = true)
        {
            if (isClear) btn.onClick.RemoveAllListeners();
            btn.onClick.AddListener(() =>
            {
                var clickTime = btn.GetComponent<BtnClickTimeMono>() ?? btn.gameObject.AddComponent<BtnClickTimeMono>();
                if (clickTime.CanClick(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()))
                    action?.Invoke();
            });
        }

        public static void MSetActive(this GameObject go, bool State)
        {
            if (go)
            {
                if (go.activeSelf != State)
                {
                    go.SetActive(State);
                }
            }
        }

        public static void DestroyAllChildren(this Transform trans)
        {
            if (trans == null) return;
            int count = trans.childCount;
            for (int i = count - 1; i >= 0; i--)
                GameObjManager.Instance.PushGameObject(trans.GetChild(i).gameObject);
        }

        public static void ShowRemind(this GameObject button, bool show)
        {
            Transform redDot = button.transform.Find("Remind");
            if (redDot != null)
            {
                redDot.gameObject.MSetActive(show);
            }
        }

        public static TweenerCore<Vector3, Path, PathOptions> DOCurMove(this Transform transform, Vector3 endPos, float duration)
        {
            Vector3 startPos = transform.position;
            Vector3 direction = (endPos - startPos).normalized;
            Vector3 verticalDir = Vector3.Cross(direction, Vector3.back).normalized;
            float distance = Vector3.Distance(startPos, endPos);
            float arcHeight = distance / 8f;
            Vector3 controlPoint = (startPos + endPos) / 2 + verticalDir * arcHeight;
            Vector3[] path = new Vector3[]
            {
                startPos,
                controlPoint,
                endPos
            };
            return transform.DOPath(path, duration, PathType.CatmullRom);
        }
    }
}
