#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.U2D;
using UnityEngine;
using UnityEngine.U2D;
using Object = UnityEngine.Object;

namespace SoliUtils
{
    public static class DevTools
    {
        private static string AtlasDefaultName =>
            $"atlas_{DateTime.Now.Hour}_{DateTime.Now.Minute}_{DateTime.Now.Second}.asset";

        [MenuItem("Assets/工具/Atlas/CreateAtlas")]
        public static void CreateAtlas()
        {
            object[] asset = Selection.GetFiltered<object>(SelectionMode.DeepAssets);
            SpriteAtlas atlas = new SpriteAtlas();
            foreach (object o in asset)
            {
                Texture2D sprite = o as Texture2D;
                if (sprite == null) continue;
                atlas.Add(new Object[] {sprite});
            }
            DoRealCreateAtlas(atlas);
        }

        [MenuItem("Assets/工具/Atlas/AtlasCombine")]
        public static void AtlasCombine()
        {
            object[] asset = Selection.GetFiltered<object>(SelectionMode.DeepAssets);
            SpriteAtlas atlas = new SpriteAtlas();
            foreach (object o in asset)
            {
                SpriteAtlas spriteAtlas = o as SpriteAtlas;
                if (spriteAtlas == null) continue;
                atlas.Add(spriteAtlas.GetPackables());
            }

            DoRealCreateAtlas(atlas);
        }

        [MenuItem("Assets/工具/Atlas/AtlasDeWeight")]
        private static void AtlasDeWeight()
        {
            object[] assets = Selection.GetFiltered<object>(SelectionMode.DeepAssets);
            foreach (object asset in assets)
            {
                SpriteAtlas atlas = asset as SpriteAtlas;
                DoRealAtlasDeWeight(atlas);
            }
        }

        private static void DoRealAtlasDeWeight(SpriteAtlas atlas)
        {
            if (atlas == null) return;
            Object[] objs = atlas.GetPackables();
            List<Object> newObjs = new List<Object>();
            foreach (Object obj in objs)
            {
                if (newObjs.Contains(obj)) continue;
                newObjs.Add(obj);
            }

            atlas.Remove(objs);
            atlas.Add(newObjs.ToArray());
        }

        private static void DoRealCreateAtlas(SpriteAtlas atlas, string assetName = "")
        {
            if (string.IsNullOrEmpty(assetName)) assetName = AtlasDefaultName;
            string path = Path.Combine("Res/Atlas", assetName);

            string fullPath = Path.Combine(Application.dataPath, path);
            if (!Directory.Exists(fullPath)) Directory.CreateDirectory(fullPath);

            string assetPath = Path.Combine("Assets", path);
            AssetDatabase.DeleteAsset(assetPath);
            AssetDatabase.CreateAsset(atlas, assetPath);
            DoRealAtlasDeWeight(atlas);
        }
    }
}
#endif