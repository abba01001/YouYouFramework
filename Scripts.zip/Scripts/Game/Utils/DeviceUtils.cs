using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
#if UNITY_WEBGL
using WeChatWASM;
#endif

namespace SoliUtils
{
    public class DeviceUtils
    {
        public static bool HasLiuhai()
        {
            return hasLiuhai();
        }

        public static float GetScreenScale()
        {
            return getScreenScale();
        }

        public static string GetPlatform()
        {
            return getPlatform();
        }
        
        public static string GetVersionName()
        {
            return getVersionName();
        }

        public static string GetEnvVersion()
        {
            return getEnvVersion();
        }

        public static string GetRegionCode()
        {
            return getRegionCode();
        }

        public static int GetVersionNum()
        {
            var nums = getVersionName().Split('.');
            var version = Convert.ToInt32(nums[0]) * 10000 + Convert.ToInt32(nums[1]) * 100 + Convert.ToInt32(nums[2]);
            return version;
        }

        public static int VersionNameToNum(string versionName)
        {
            var nums = versionName.Split('.');
            var version = Convert.ToInt32(nums[0]) * 10000 + Convert.ToInt32(nums[1]) * 100 + Convert.ToInt32(nums[2]);
            return version;
        }
        
        private static float getScreenScale()
        {
            float width = Screen.width;
            float height = Screen.height;
            string platform = "";
            
            WeChatMiniGame.GetSystemInfo(ref platform, ref width, ref height);
               
            float scale = Math.Max(width / Constants.ResolutionWidth,
                height / Constants.ResolutionHeight);
            
            return scale;
        }

        static string deviceid = "";
        public static string GetDeviceId()
        {
            if(!string.IsNullOrEmpty(deviceid))
            {
                return deviceid;
            }
            string key = "SOLI_DEVICE_ID";
            if (PlayerPrefs.HasKey(key))
            {
                deviceid = PlayerPrefs.GetString(key);
                return deviceid;
            }
            deviceid = Guid.NewGuid().ToString("N");
            PlayerPrefs.SetString(key, deviceid);
            return deviceid;
        }

        private static string getPlatform()
        {
            float width = Screen.width;
            float height = Screen.height;
            string platform = "";
            
            WeChatMiniGame.GetSystemInfo(ref platform, ref width, ref height);

            return platform;
        }


        private static bool hasLiuhai()
        {
            bool has = false;
            GetSystemInfoOption opt = new GetSystemInfoOption();
            opt.success = info =>
            {
                if (info.safeArea != null && (info.safeArea.top > 0 || info.safeArea.left > 0))
                {
                    has = true;
                }
            };
            WX.GetSystemInfo(opt);
                
            return has;
        }
        

        private static string getVersionName()
        {
            if (GameCommon.IsOffMode) return "0.0.1";
#if UNITY_WEBGL && !UNITY_EDITOR
            var info = WX.GetAccountInfoSync();
            var version = info.miniProgram.version;
            if(string.IsNullOrEmpty(version))
                version = "0.0.1";
            return version;
#endif
            return "0.0.1";
        }

        private static string getEnvVersion()
        {
            if (GameCommon.IsOffMode) return "gm";
#if UNITY_WEBGL && !UNITY_EDITOR
            var info = WX.GetAccountInfoSync();
            var envVersion = info.miniProgram.envVersion;
            return envVersion;
#endif
            return "unity";
        }

        private static string getRegionCode()
        {
            return "CN-S";
        }

        public static IEnumerator LocationInfoCoroutine(Action<string> callback)
        {
            var publicIpReq = new UnityWebRequest(Constants.ProvinceUrl, UnityWebRequest.kHttpVerbGET);
            publicIpReq.downloadHandler = new DownloadHandlerBuffer();

            yield return publicIpReq.SendWebRequest();
            if (!string.IsNullOrEmpty(publicIpReq.error))
            {
                Debug.Log($"获取省份信息失败：{publicIpReq.error}");
                yield break;
            }
            var res = publicIpReq.downloadHandler.text;
            Debug.Log($"DeviceUtils.GetLocationInfo res={res}");
            var jsonData = (Dictionary<string, object>)MiniJSON.Json.Deserialize(res);
            if (jsonData.TryGetValue("data", out var data))
            {
                var info = (Dictionary<string, object>)data;
                if (info.TryGetValue("province", out var province))
                {
                    // Debug.Log($"获取省份：{province}");
                    callback?.Invoke((string)province);
                }
            }
        }

        public static void GetLocationInfo(Action<string> callback)
        {
            if (!PlayerPrefs.HasKey("province"))
            {
                StaticCoroutine.StartCoroutine(LocationInfoCoroutine(province =>
                {
                    if (!string.IsNullOrEmpty(province))
                    {
                        PlayerPrefs.SetString("province", province);
                        callback.Invoke(province);
                    }
                }));
            }
            else
            {
                callback(PlayerPrefs.GetString("province"));
            }
        }
        
    }
}