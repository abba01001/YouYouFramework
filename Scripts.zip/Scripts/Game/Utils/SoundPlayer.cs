using System;
using System.Collections.Generic;
using Activities;
using DG.Tweening;
using QFramework;
using UniRx;
using UnityEngine;
using Random = UnityEngine.Random;

namespace SoliUtils
{
    public class SoundPlayer : ISingleton
    {
        private AudioSource mainAudioSource;
        private AudioSource environmentAudioSource;

        private AudioSource mainSoundSource;
        private AudioSource viceSoundSource;

        private string lastMainBgm = "";
        private string lastEnvironmentBgm = "";
        private string lastViceBgm = "";
        private List<string> playSoundFlag = new List<string>();
        private string MainBgm
        {
            get
            {
                var configService = MainContainer.Container.Resolve<IConfigService>();
                configService.SoundConfig.TryGetValue("Merge_Main_BGM_Mono", out SoundModel model);
                return model != null ? model.assetPath : "Assets/Res/Bgm/Merge_Main_BGM_Mono.ogg";
            }
        }

        private string EnvironmentSound
        {
            get
            {
                return "";
            }
        }

        private string ViceBgm
        {
            get
            {
                var dataService = MainContainer.Container.Resolve<IDataService>();
                var configService = MainContainer.Container.Resolve<IConfigService>();
                int mapId = dataService.FarmingProgress?.curMapId ?? 1;
                int themeId = dataService.FarmingProgress?.curThemeId ?? 1;
                configService.SoundConfig.TryGetValue($"map_battle_{mapId}", out SoundModel model);
                return model != null ? model.assetPath : "Assets/Res/Bgm/CN_BGM_P2.ogg";
            }
        }

        private string[] noteSounds = new string[21];
        private string[] btnSounds = new string[7];
        private string[] guideSounds = new string[3];
        private string[] boomSounds = new string[2];
        private string[] keySounds = new string[2];
        private string[] lockSounds = new string[2];
        private string[] zapSounds = new string[1];
        private string[] threeoutSounds = new string[1];
        private string[] threeinSounds = new string[1];
        private string[] anchorSounds = new string[2];
        private string[] bombSounds = new string[2];
        private string[] iceflySounds = new string[2];
        private string[] icebreakSounds = new string[2];
        private string[] comboPointSounds = new string[3];
        private string[] comboFlycardSounds = new string[1];
        private string[] remaincardSounds = new string[3]; //added 2
        private string[] resultStarsSounds = new string[3];
        private string[] fireworkSounds = new string[2];
        private string[] fapaiSounds = new string[1];
        private string[] handCardFlopSounds = new string[1];
        private string[] wheelSounds = new string[1];
        private string[] wheelEndSounds = new string[1];
        private string[] handCardSounds = new string[1];
        private string[] jokerFlySounds = new string[1]; //added jokerfly
        private string[] leftFlipCardSounds = new string[1]; //added flipcard-leftward
        private string[] friendSounds = new string[1]; //added skill-friend
        private string[] firstBonuStreakSounds = new string[1]; //added first bonus streak
        private string[] secondBonuStreakSounds = new string[1]; //added second bonus streak
        private string[] goldFlySounds = new string[3];
        private string[] starFlySounds = new string[1];
        private string[] starHitSounds = new string[1];
        private string[] openBoxSounds = new string[1];
        private string[] wheelPop = new string[2]; //1 is normal, 2 is paid

        private string[] getAnchorSounds = new string[1];

        //new sounds
        private string[] showUtilSounds = new string[1];
        private string[] scissorsFlySounds = new string[1];
        private string[] updownCardSounds = new string[1];
        private string[] iceCardBounceSounds = new string[1];
        private string[] invalidMoveSounds = new string[1];
        private string[] flipCardSounds = new string[1];
        private string[] comboFinishSounds = new string[1];
        private string[] showrewardSounds = new string[3];
        private string[] magicSkillsSounds = new string[2];
        private string[] betChangeSounds = new string[2];
        private string winStreakFlyCardSound;
        private string winStreakBoxOutSound;
        private string failGameSound;

        private long lastAudioClipTime;

        //小精灵
        private string[] xjlFei01Sounds = new string[2];
        private string[] xjlFei02Sounds = new string[2];
        private string[] xjlZan01Sounds = new string[2];
        private string[] xjlZan02Sounds = new string[3];
        private string[] xjlZan03Sounds = new string[3];
        private string[] xjlZan04Sounds = new string[2];
        private string[] xjlZuo01Sounds = new string[2];


        private bool musicMute
        {
            get
            {
                // if (GameCommon.IsEditorMode)
                //     return true;
                var dataSvr = MainContainer.Container.Resolve<IDataService>();
                return dataSvr.MusicMute;
            }
        }

        private bool soundMute
        {
            get
            {
                // if (GameCommon.IsEditorMode)
                //     return true;
                var dataSvr = MainContainer.Container.Resolve<IDataService>();
                return dataSvr.SoundMute;
            }
        }

        private SoundPlayer()
        {
        }

        public void Init(AudioSource[] aus1, AudioSource[] aus2)
        {
            mainAudioSource = aus1[0];
            environmentAudioSource = aus1[1];
            mainSoundSource = aus2[0];
            viceSoundSource = aus2[1];
        }

        public static SoundPlayer Instance
        {
            get
            {
                return SingletonProperty<SoundPlayer>.Instance;
            }
        }

        public void OnSingletonInit()
        {
            for (int i = 0; i < btnSounds.Length; i++)
            {
                btnSounds[i] = $"Assets/Res/Audio/button/{i + 1}.mp3";
            }

            for (int i = 0; i < noteSounds.Length; i++)
            {
                noteSounds[i] = $"Assets/Res/Audio/note/{i + 1}.mp3";
            }

            for (int i = 0; i < guideSounds.Length; i++)
            {
                guideSounds[i] = $"Assets/Res/Audio/guide/{i + 1}.mp3";
            }

            for (int i = 0; i < boomSounds.Length; i++)
            {
                boomSounds[i] = $"Assets/Res/Audio/cards/boom{i + 1}.mp3";
            }

            for (int i = 0; i < keySounds.Length; i++)
            {
                keySounds[i] = $"Assets/Res/Audio/cards/key{i + 1}.mp3";
            }

            for (int i = 0; i < lockSounds.Length; i++)
            {
                lockSounds[i] = $"Assets/Res/Audio/cards/lock{i + 1}.mp3";
            }

            for (int i = 0; i < zapSounds.Length; i++)
            {
                zapSounds[i] = $"Assets/Res/Audio/cards/zap{i + 1}.mp3";
            }

            for (int i = 0; i < threeoutSounds.Length; i++)
            {
                threeoutSounds[i] = $"Assets/Res/Audio/cards/threeout{i + 1}.mp3";
            }

            for (int i = 0; i < threeinSounds.Length; i++)
            {
                threeinSounds[i] = $"Assets/Res/Audio/cards/threein{i + 1}.mp3";
            }

            for (int i = 0; i < anchorSounds.Length; i++)
            {
                anchorSounds[i] = $"Assets/Res/Audio/cards/anchor{i + 1}.mp3";
            }

            for (int i = 0; i < bombSounds.Length; i++)
            {
                bombSounds[i] = $"Assets/Res/Audio/cards/bomb{i + 1}.mp3";
            }

            for (int i = 0; i < iceflySounds.Length; i++)
            {
                iceflySounds[i] = $"Assets/Res/Audio/cards/icefly{i + 1}.mp3";
            }

            for (int i = 0; i < icebreakSounds.Length; i++)
            {
                icebreakSounds[i] = $"Assets/Res/Audio/cards/icebreak{i + 1}.mp3";
            }

            for (int i = 0; i < comboPointSounds.Length; i++)
            {
                comboPointSounds[i] = $"Assets/Res/Audio/combo/point{i + 1}.mp3";
            }

            for (int i = 0; i < comboFlycardSounds.Length; i++)
            {
                comboFlycardSounds[i] = $"Assets/Res/Audio/combo/flycard{i + 1}.mp3";
            }

            for (int i = 0; i < remaincardSounds.Length; i++)
            {
                remaincardSounds[i] = $"Assets/Res/Audio/remaincard/{i + 1}.mp3"; //edited from 1 to 3
            }

            for (int i = 0; i < resultStarsSounds.Length; i++)
            {
                resultStarsSounds[i] = $"Assets/Res/Audio/resultstars/{i + 1}.mp3";
            }

            for (int i = 0; i < fireworkSounds.Length; i++)
            {
                fireworkSounds[i] = $"Assets/Res/Audio/firework/{i + 1}.mp3";
            }

            for (int i = 0; i < handCardFlopSounds.Length; i++)
            {
                handCardFlopSounds[i] = $"Assets/Res/Audio/flopcard/{i + 1}.mp3";
            }

            for (int i = 0; i < fapaiSounds.Length; i++)
            {
                fapaiSounds[i] = $"Assets/Res/Audio/fapai/{i + 1}.mp3";
            }

            for (int i = 0; i < handCardSounds.Length; i++)
            {
                handCardSounds[i] = $"Assets/Res/Audio/stack/{i + 1}.mp3";
            }

            for (int i = 0; i < jokerFlySounds.Length; i++)
            {
                jokerFlySounds[i] = $"Assets/Res/Audio/skill/jokerfly2.mp3";
            }

            for (int i = 0; i < leftFlipCardSounds.Length; i++)
            {
                leftFlipCardSounds[i] = $"Assets/Res/Audio/flipcard/leftward4.mp3";
            }

            for (int i = 0; i < friendSounds.Length; i++)
            {
                friendSounds[i] = $"Assets/Res/Audio/skill/friend.mp3";
            }

            for (int i = 0; i < firstBonuStreakSounds.Length; i++)
            {
                firstBonuStreakSounds[i] = $"Assets/Res/Audio/skill/firstbonustreak{i + 1}.mp3";
            }

            for (int i = 0; i < secondBonuStreakSounds.Length; i++)
            {
                secondBonuStreakSounds[i] = $"Assets/Res/Audio/skill/secondbonustreak{i + 1}.mp3";
            }

            for (int i = 0; i < goldFlySounds.Length; i++)
            {
                goldFlySounds[i] = $"Assets/Res/Audio/gold/goldFly{i + 1}.mp3";
            }

            for (int i = 0; i < starFlySounds.Length; i++)
            {
                starFlySounds[i] = $"Assets/Res/Audio/star/starFly.mp3";
            }

            for (int i = 0; i < starHitSounds.Length; i++)
            {
                starHitSounds[i] = $"Assets/Res/Audio/star/starHit.mp3";
            }

            for (int i = 0; i < openBoxSounds.Length; i++)
            {
                openBoxSounds[i] = $"Assets/Res/Audio/openbox/{i + 1}.mp3";
            }

            for (int i = 0; i < getAnchorSounds.Length; i++)
            {
                getAnchorSounds[i] = $"Assets/Res/Audio/cards/getanchor.mp3";
            }

            //new contents
            for (int i = 0; i < showUtilSounds.Length; i++)
            {
                showUtilSounds[i] = $"Assets/Res/Audio/cards/utilshow.mp3";
            }

            for (int i = 0; i < scissorsFlySounds.Length; i++)
            {
                scissorsFlySounds[i] = $"Assets/Res/Audio/cards/scissorsfly.mp3";
            }

            for (int i = 0; i < updownCardSounds.Length; i++)
            {
                updownCardSounds[i] = $"Assets/Res/Audio/cards/updown.mp3";
            }

            for (int i = 0; i < iceCardBounceSounds.Length; i++)
            {
                iceCardBounceSounds[i] = $"Assets/Res/Audio/cards/icebounce.mp3";
            }

            for (int i = 0; i < invalidMoveSounds.Length; i++)
            {
                invalidMoveSounds[i] = $"Assets/Res/Audio/invalid/{i + 1}.mp3";
            }

            for (int i = 0; i < flipCardSounds.Length; i++)
            {
                flipCardSounds[i] = $"Assets/Res/Audio/flipcard/leftward4.mp3";
            }

            for (int i = 0; i < comboFinishSounds.Length; i++)
            {
                comboFinishSounds[i] = $"Assets/Res/Audio/combo/finish.mp3";
            }

            for (int i = 0; i < showrewardSounds.Length; i++)
            {
                showrewardSounds[i] = $"Assets/Res/Audio/showreward/{i + 1}.mp3";
            }

            for (int i = 0; i < magicSkillsSounds.Length; i++)
            {
                magicSkillsSounds[i] = $"Assets/Res/Audio/skill/magic{i + 1}.mp3";
            }

            for (int i = 0; i < betChangeSounds.Length; i++)
                betChangeSounds[i] = $"Assets/Res/Audio/betChange/bet{i + 1}.mp3";

            for (int i = 0; i < wheelSounds.Length; i++)
            {
                wheelSounds[i] = $"Assets/Res/Audio/wheel/{i + 1}.mp3";
            }

            for (int i = 0; i < wheelEndSounds.Length; i++)
            {
                wheelEndSounds[i] = $"Assets/Res/Audio/wheel/wheelEnd.mp3";
            }

            for (int i = 0; i < wheelPop.Length; i++)
            {
                wheelPop[i] = $"Assets/Res/Audio/wheel/wheelpop{i + 1}.mp3";
            }

            winStreakFlyCardSound = $"Assets/Res/Audio/winstreak/flycard.mp3";
            winStreakBoxOutSound = $"Assets/Res/Audio/winstreak/boxout.mp3";
            failGameSound = $"Assets/Res/Audio/failGame/1.mp3";

            for (int i = 0; i < xjlFei01Sounds.Length; i++)
            {
                xjlFei01Sounds[i] = $"Assets/Res/Audio/xiaojingling/xjl_fei_01_0{i +1 }.ogg";
            }
            for (int i = 0; i < xjlFei02Sounds.Length; i++)
            {
                xjlFei02Sounds[i] = $"Assets/Res/Audio/xiaojingling/xjl_fei_02_0{i + 1 }.ogg";
            }
            for (int i = 0; i < xjlZan01Sounds.Length; i++)
            {
                xjlZan01Sounds[i] = $"Assets/Res/Audio/xiaojingling/xjl_zan_01_0{i + 1 }.ogg";
            }
            for (int i = 0; i < xjlZan02Sounds.Length; i++)
            {
                xjlZan02Sounds[i] = $"Assets/Res/Audio/xiaojingling/xjl_zan_02_0{i + 1 }.ogg";
            }
            for (int i = 0; i < xjlZan03Sounds.Length; i++)
            {
                xjlZan03Sounds[i] = $"Assets/Res/Audio/xiaojingling/xjl_zan_03_0{i + 1 }.ogg";
            }
            for (int i = 0; i < xjlZan04Sounds.Length; i++)
            {
                xjlZan04Sounds[i] = $"Assets/Res/Audio/xiaojingling/xjl_zan_04_0{i + 1 }.ogg";
            }
            for (int i = 0; i < xjlZuo01Sounds.Length; i++)
            {
                xjlZuo01Sounds[i] = $"Assets/Res/Audio/xiaojingling/xjl_zuo_01_0{i + 1 }.ogg";
            }
        }

        private void LoadClip(string path, Action<AudioClip> callback)
        {
            // var clip = GlobalRes.Load<AudioClip>(path);
            // callback(clip);
            GlobalRes.LoadAsset<AudioClip>(path, callback);
        }

        private void ReleaseClip(string path)
        {
            GlobalRes.Release<AudioClip>(path, 5); // 延迟5s确保较长的音效也能播放完全再释放
        }


        private void PlayOneShot(AudioClip clip, float volumeScale = 1,bool needInteval = true)
        {
            if (soundMute) return;
            var now = TimeUtils.Timestamp();
            if (needInteval && now < lastAudioClipTime + 5) return;
            lastAudioClipTime = now;
            mainSoundSource.PlayOneShot(clip, volumeScale);
        }

        public void ChangeBgm()
        {
            if (lastMainBgm != MainBgm) PlayMainBgm();
            if (lastEnvironmentBgm != EnvironmentSound) PlayEnvironmentSound();
        }

        public void UnPauseBgm()
        {
            mainAudioSource.UnPause();
            // environmentAudioSource.UnPause();
        }

        public void PauseBgm()
        {
            mainAudioSource.Pause();
            // environmentAudioSource.Pause();
        }


        private Dictionary<ActivityType, string> _activityBgmDic = new Dictionary<ActivityType, string>()
        {
            {ActivityType.lavaPass,"LavaPass_BGM_Mono"},
            {ActivityType.cookMeal,"Cook_BGM_Mono"},
            {ActivityType.digTreasure,"MysteriousSeed_p1_BGM_Mono"},
            {ActivityType.mysteriousSeed,"MysteriousSeed_p1_BGM_Mono"},
        };
        public void CheckActivityBgm(bool check,ActivityType activityType)
        {
            if (!check)
            {
                environmentAudioSource.volume = 1f;
                PlayMainBgm();
                return;
            }

            if (ActivityManager.Instance.CheckActivityIsUnderWay(activityType))
            {
                var configService = MainContainer.Container.Resolve<IConfigService>();
                _activityBgmDic.TryGetValue(activityType, out string BgmName);
                configService.SoundConfig.TryGetValue(BgmName, out SoundModel model);
                if (model != null && lastMainBgm != model.assetPath)
                {
                    DOTween.To(() => mainAudioSource.volume, x => mainAudioSource.volume = x, 0, 0.5f).OnComplete(
                        () => PlayMainBgm(model.assetPath));
                    environmentAudioSource.volume = 0f;
                }
            }
        }
        
        public void PlayWheelBgm(bool play)
        {
            if (play)
            {
                var configService = MainContainer.Container.Resolve<IConfigService>();
                configService.SoundConfig.TryGetValue("Wheel_Standby_BGM_Mono", out SoundModel model);
                if (model != null && lastMainBgm != model.assetPath)
                {
                    DOTween.To(() => mainAudioSource.volume, x => mainAudioSource.volume = x, 0, 0.5f).OnComplete(
                        () => { PlayMainBgm(model.assetPath); });
                    environmentAudioSource.volume = 0f;
                }
                else
                {
                    DOTween.To(() => mainAudioSource.volume, x => mainAudioSource.volume = x, 1, 0.5f);
                }
            }
            else
            {
                mainAudioSource.volume = 0f;
                environmentAudioSource.volume = 0f;
            }
        }
        
        public void PlayMainBgm(string specifyBgm = "")
        {
            Clear(1);
            Clear(3);
            Debug.Log($"sound.PlayBgm musicMute={musicMute}");
            if (musicMute) return;
            var mainBgm = MainBgm;
            if (specifyBgm != "") mainBgm = specifyBgm;
            if (lastMainBgm == mainBgm)
            {
                DOTween.To(() => mainAudioSource.volume, x => mainAudioSource.volume = x, 1, 0.5f);
                return;
            }
            LoadClip(mainBgm, clip =>
            {
                lastMainBgm = mainBgm;
                mainAudioSource.clip = clip;
                mainAudioSource.loop = true;
                mainAudioSource.volume = 1f;
                mainAudioSource.Play();
            });
        }

        public void PlayEnvironmentSound(string specifySound = "")
        {
            Clear(2);
            if (soundMute) return;

            string tempSound = EnvironmentSound;
            if (specifySound != "")
            {
                DOTween.To(() => environmentAudioSource.volume, x => environmentAudioSource.volume = x, 0, 1f);
                tempSound = specifySound;
            }
            if (lastEnvironmentBgm == tempSound)
            {
                environmentAudioSource.Play();
                DOTween.To(() => environmentAudioSource.volume, x => environmentAudioSource.volume = x, 1, 1f);
                return;
            }
            LoadClip(tempSound, clip =>
            {
                lastEnvironmentBgm = tempSound;
                environmentAudioSource.clip = clip;
                environmentAudioSource.loop = true;
                DOTween.To(() => environmentAudioSource.volume, x => environmentAudioSource.volume = x, 1, 1f);
                environmentAudioSource.Play();
            });
        }

        public void Clear(int type)
        {
            if (type == 1)
            {
                if (lastMainBgm != "" && lastMainBgm != MainBgm)
                {
                    mainAudioSource.clip = null;
                    ReleaseClip(lastMainBgm);
                    lastMainBgm = "";
                }
            }
            else if (type == 2)
            {
                if (lastEnvironmentBgm != "" && lastEnvironmentBgm != EnvironmentSound)
                {
                    environmentAudioSource.clip = null;
                    ReleaseClip(lastMainBgm);
                    lastEnvironmentBgm = "";
                }
            }
        }

        public void Play(AudioClip clip)
        {
            if (soundMute) return;
            PlayOneShot(clip);
        }

        public void PlayNote(int idx, bool needInterval)
        {
            if (soundMute) return;

            if(idx == 0)
                return;

            idx = (idx - 1) % noteSounds.Length;
            LoadClip(noteSounds[idx], clip =>
            {
                PlayOneShot(clip,1f,needInterval);
            });
        }

        void PlaySound(AudioSource audioSource, string key, float delayPlay = 0f, bool loop = false, Action cb = null)
        {
            if (audioSource == null) return;
            if (soundMute) return;
            var configService = MainContainer.Container.Resolve<IConfigService>();
            if (!configService.SoundConfig.TryGetValue(key, out SoundModel model))
            {
                GameUtils.LogError($"配置表没有找到该音效{key}");
                return;
            };
            void Play()
            {
                LoadClip(model.assetPath, clip =>
                {
                    if (clip == null)
                        return;
                    if (loop)
                    {
                        audioSource.clip = clip;
                        audioSource.loop = true;
                        audioSource.Play();
                        cb?.Invoke();
                    }
                    else
                    {
                        audioSource.PlayOneShot(clip);
                        if (model.instantRelease == 1)
                        {
                            ReleaseClip(model.assetPath);
                        }
                        Observable.NextFrame().Subscribe(_ => playSoundFlag.Remove(key));
                    }
                });
            }

            if (delayPlay > 0)
            {
                Observable.Timer(TimeSpan.FromSeconds(delayPlay)).Subscribe(_ => Play());
            }
            else
            {
                Play();
            }
        }

        void ReleaseSound(AudioSource audioSource, string key)
        {
            if (audioSource == null) return;
            if (soundMute) return;
            var configService = MainContainer.Container.Resolve<IConfigService>();
            if (!configService.SoundConfig.TryGetValue(key, out SoundModel model))
            {
                GameUtils.LogError($"配置表没有找到该音效{key}");
                return;
            };
            audioSource.clip = null;
            audioSource.loop = false;
            ReleaseClip(model.assetPath);
        }

        public void ForceCleanSound()
        {
            mainSoundSource.clip = null;
            mainSoundSource.loop = false;
            viceSoundSource.clip = null;
            viceSoundSource.loop = false;
        }

        public void PlayMainSound(string key, float delayPlay = 0f, bool loop = false)
        {
            if(GameCommon.IsShowCarding) return;
            if (mainAudioSource == null) return;
            if (!loop)
            {
                if (playSoundFlag.Contains(key))
                {
                    return;
                }
                else
                {
                    playSoundFlag.Add(key);
                }
            }
            if (mainSoundSource.clip && mainSoundSource.clip.name == key) return;
            PlaySound(mainSoundSource, key, delayPlay, loop);
        }

        public void PlayLoopSound(string key, float delayPlay = 0f, bool loop = false)
        {
            if (viceSoundSource == null) return;
            if (viceSoundSource.clip && viceSoundSource.clip.name == key) return;
            PlaySound(viceSoundSource, key, delayPlay, loop);
        }

        public void StopLoopSound()
        {
            if (viceSoundSource == null) return;
            viceSoundSource.clip = null;
            viceSoundSource.loop = false;
        }

        public void PlayNoteRemain(int idx)
        {
            if (soundMute) return;

            idx = (idx - 1) % noteSounds.Length;
            LoadClip(noteSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayButton(int idx = -1)
        {
            if (soundMute) return;

            //if (idx > boomSounds.Length || idx < 1)
            //    idx = Random.Range(0, boomSounds.Length);
            idx = 1;
            LoadClip(btnSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        //handling sound effect requirments on btn actions
        public void PlayCertainButton(int idx)
        {
            if (soundMute) return;

            LoadClip(btnSounds[idx - 1], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayFlopcard()
        {
            if (soundMute) return;

            var idx = Random.Range(0, handCardFlopSounds.Length);
            LoadClip(handCardFlopSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayGuide()
        {
            if (soundMute) return;

            var idx = 1; //Random.Range(0, guideSounds.Length);
            //soundSource.PlayOneShot(guideSounds[idx]);
        }

        public void PlayBoom()
        {
            if (soundMute) return;

            var idx = 0; //Random.Range(0, boomSounds.Length);
            LoadClip(boomSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(boomSounds[idx]);
            });
        }

        public void PlayKey()
        {
            if (soundMute) return;

            var idx = 0; // Random.Range(0, keySounds.Length);
            LoadClip(keySounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(keySounds[idx]);
            });
        }

        public void PlayLock()
        {
            if (soundMute) return;

            var idx = 1; // Random.Range(0, lockSounds.Length);
            LoadClip(lockSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(lockSounds[idx]);
            });
        }

        public void PlayZap()
        {
            if (soundMute) return;

            var idx = 0;
            LoadClip(zapSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(zapSounds[idx]);
            });
        }

        public void PlayThreeOut()
        {
            if (soundMute) return;

            var idx = 0;
            LoadClip(threeoutSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(threeoutSounds[idx]);
            });
        }

        public void PlayThreeIn()
        {
            if (soundMute) return;

            var idx = 0;
            LoadClip(threeinSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(threeinSounds[idx]);
            });
        }

        public void PlayAnchor()
        {
            if (soundMute) return;

            var idx = Random.Range(0, anchorSounds.Length);
            LoadClip(anchorSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(anchorSounds[idx]);
            });
        }

        public void PlayBomb()
        {
            if (soundMute) return;

            var idx = Random.Range(0, bombSounds.Length);
            LoadClip(bombSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(bombSounds[idx]);
            });
        }

        public void PlayIceFly()
        {
            if (soundMute) return;

            var idx = Random.Range(0, iceflySounds.Length);
            LoadClip(iceflySounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(iceflySounds[idx]);
            });
        }

        public void PlayIceBreak()
        {
            if (soundMute) return;

            var idx = Random.Range(0, icebreakSounds.Length);
            LoadClip(icebreakSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(icebreakSounds[idx]);
            });
        }

        public void PlayComboPoint()
        {
            if (soundMute) return;

            var idx = Random.Range(0, comboPointSounds.Length);
            LoadClip(comboPointSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(comboPointSounds[idx]);
            });
        }

        //added
        public void PlayCertainComboPoint(int idx)
        {
            if (soundMute) return;
            LoadClip(comboPointSounds[idx - 1], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(comboPointSounds[idx - 1]);
            });
        }

        public void PlayComboFlycard()
        {
            if (soundMute) return;

            var idx = Random.Range(0, comboFlycardSounds.Length);
            LoadClip(comboFlycardSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayRemaincard(int idx)
        {
            if (soundMute) return;

            LoadClip(remaincardSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(remaincardSounds[idx]);
            });
        }

        public void PlayResultStar(int idx)
        {
            if (soundMute) return;

            if (idx < 0 || idx >= resultStarsSounds.Length)
                return;
            LoadClip(resultStarsSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(resultStarsSounds[idx]);
            });
        }

        public void PlayFirework()
        {
            if (soundMute) return;

            var idx = Random.Range(0, fireworkSounds.Length);
            LoadClip(fireworkSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayWheel()
        {
            if (soundMute) return;

            var idx = Random.Range(0, wheelSounds.Length);
            LoadClip(wheelSounds[idx], clip =>
            {
                PlayOneShot(clip, 0.2f);
                ReleaseClip(wheelSounds[idx]);
            });
        }

        public void PlayWheelEnd()
        {
            if (soundMute) return;
            var idx = Random.Range(0, wheelEndSounds.Length);
            LoadClip(wheelEndSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(wheelEndSounds[idx]);
            });
        }

        public void PlayFapai()
        {
            if (soundMute) return;

            var idx = Random.Range(0, fapaiSounds.Length);
            LoadClip(fapaiSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayHandCard()
        {
            if (soundMute) return;

            var idx = Random.Range(0, handCardSounds.Length);
            LoadClip(handCardSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(handCardSounds[idx]);
            });
        }

        //added
        public void PlayJokerFly()
        {
            if (soundMute) return;

            var idx = Random.Range(0, jokerFlySounds.Length);
            LoadClip(jokerFlySounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(jokerFlySounds[idx]);
            });
        }

        private int leftFlipCardNum = 0;

        public void PlayLeftFlipCard()
        {
            if (soundMute) return;

            if (leftFlipCardNum % 3 == 0)
            {
                var idx = Random.Range(0, leftFlipCardSounds.Length);
                LoadClip(leftFlipCardSounds[idx], clip =>
                {
                    PlayOneShot(clip);
                    ReleaseClip(leftFlipCardSounds[idx]);
                });
            }

            leftFlipCardNum++;
        }

        public void PlayFriendSkill()
        {
            if (soundMute) return;

            var idx = Random.Range(0, friendSounds.Length);
            LoadClip(friendSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayFirstBonusStreak()
        {
            if (soundMute) return;

            var idx = Random.Range(0, firstBonuStreakSounds.Length);
            LoadClip(firstBonuStreakSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(firstBonuStreakSounds[idx]);
            });
        }

        public void PlaySecondBonusStreak()
        {
            if (soundMute) return;

            var idx = Random.Range(0, secondBonuStreakSounds.Length);
            LoadClip(secondBonuStreakSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(secondBonuStreakSounds[idx]);
            });
        }

        public void PlayBoxOpen()
        {
            if (soundMute) return;

            var idx = Random.Range(0, openBoxSounds.Length);
            LoadClip(openBoxSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(openBoxSounds[idx]);
            });
        }

        public void PlayWheelPop(int idx)
        {
            if (soundMute) return;
            LoadClip(wheelPop[idx - 1], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(wheelPop[idx - 1]);
            });
        }

        //0���ɽ��  1��ҵ���
        public void PlayGoldFly(int idx, float volume = 1f)
        {
            if (soundMute) return;
            if (playSoundFlag.Contains(goldFlySounds[idx]))
            {
                return;
            }
            else
            {
                playSoundFlag.Add(goldFlySounds[idx]);
            }
            LoadClip(goldFlySounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
            Observable.Timer(TimeSpan.FromSeconds(0.5f)).Subscribe(_ =>
            {
                playSoundFlag.Remove(goldFlySounds[idx]);
            });
        }

        public void PlayStarFly()
        {
            if (soundMute) return;
            var idx = Random.Range(0, starFlySounds.Length);
            LoadClip(starFlySounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(starFlySounds[idx]);
            });
        }

        public void PlayStarHit()
        {
            if (soundMute) return;
            var idx = Random.Range(0, starHitSounds.Length);
            LoadClip(starHitSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlaygetAnchor()
        {
            if (soundMute) return;
            var idx = Random.Range(0, getAnchorSounds.Length);
            LoadClip(getAnchorSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(getAnchorSounds[idx]);
            });
        }

        //additional
        public void PlayUtilShow()
        {
            if (soundMute) return;
            var idx = Random.Range(0, showUtilSounds.Length);
            LoadClip(showUtilSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(showUtilSounds[idx]);
            });
        }

        public void PlayScissorsFly()
        {
            if (soundMute) return;
            var idx = Random.Range(0, scissorsFlySounds.Length);
            LoadClip(scissorsFlySounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(scissorsFlySounds[idx]);
            });
        }

        public void PlayUpdownChange()
        {
            if (soundMute) return;
            var idx = Random.Range(0, updownCardSounds.Length);
            LoadClip(updownCardSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(updownCardSounds[idx]);
            });
        }

        public void PlayIceBounce()
        {
            if (soundMute) return;
            var idx = Random.Range(0, iceCardBounceSounds.Length);
            LoadClip(iceCardBounceSounds[idx], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(iceCardBounceSounds[idx]);
            });
        }

        public void PlayInvalidMove()
        {
            if (soundMute) return;
            var idx = Random.Range(0, invalidMoveSounds.Length);
            LoadClip(invalidMoveSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayNormalFlip()
        {
            if (soundMute) return;
            var idx = Random.Range(0, flipCardSounds.Length);
            LoadClip(flipCardSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayComboFinish()
        {
            if (soundMute) return;
            var idx = Random.Range(0, comboFinishSounds.Length);
            LoadClip(comboFinishSounds[idx], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayShowReward(int idx)
        {
            if (soundMute) return;
            //var idx = Random.Range(0, getAnchorSounds.Length);
            LoadClip(showrewardSounds[idx - 1], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(showrewardSounds[idx - 1]);
            });
        }

        public void PlayMagicSkill()
        {
            if (soundMute) return;
            LoadClip(magicSkillsSounds[0], clip =>
            {
                PlayOneShot(clip, 0.8f);
                ReleaseClip(magicSkillsSounds[0]);
            });
        }

        public void PlayUndo()
        {
            if (soundMute) return;
            LoadClip(magicSkillsSounds[1], clip =>
            {
                PlayOneShot(clip);
            });
        }

        public void PlayBetChange(int idx)
        {
            if (soundMute) return;
            idx = idx > 2 ? 2 : idx;
            LoadClip(betChangeSounds[idx - 1], clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(betChangeSounds[idx - 1]);
            });
        }

        public void PlayFailGame()
        {
            if (soundMute) return;
            LoadClip(failGameSound, clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(failGameSound);
            });
        }

        public void PlayWinStreakFlyCard()
        {
            if (soundMute) return;
            LoadClip(winStreakFlyCardSound, clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(winStreakFlyCardSound);
            });
        }

        public void PlayWinStreakBoxOut()
        {
            if (soundMute) return;
            LoadClip(winStreakBoxOutSound, clip =>
            {
                PlayOneShot(clip);
                ReleaseClip(winStreakBoxOutSound);
            });
        }
        public void PlayRandomSound(string[] sounds)
        {
            if (soundMute) return;
            if (sounds.Length == 0) return;
            int index = Random.Range(0, sounds.Length);
            LoadClip(sounds[index], clip =>
            {
                PlayOneShot(clip);
            });
        }
        public void PlayXJLFei01()
        {
            PlayRandomSound(xjlFei01Sounds);
        }
        public void PlayXJLFei02()
        {
            PlayRandomSound(xjlFei02Sounds);
        }
        public void PlayXJLZan01()
        {
            PlayRandomSound(xjlZan01Sounds);
        }
        public void PlayXJLZan02()
        {
            PlayRandomSound(xjlZan02Sounds);
        }
        public void PlayXJLZan03()
        {
            PlayRandomSound(xjlZan03Sounds);
        }
        public void PlayXJLZan04()
        {
            PlayRandomSound(xjlZan04Sounds);
        }
        public void PlayXJLZuo01()
        {
            PlayRandomSound(xjlZuo01Sounds);
        }

    }
}