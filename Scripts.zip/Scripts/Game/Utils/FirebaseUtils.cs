using System;
using System.Collections.Generic;
using System.Threading.Tasks;
// using Firebase.Auth;
// using Firebase.Extensions;
// using Firebase.Firestore;
// using Firebase.RemoteConfig;
using UniRx;
#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;
using UnityEngine.Events;

namespace SoliUtils
{
    public class FirebaseUtils
    {
        private static FirebaseUtils _instance;
        
        public static FirebaseUtils Instance => _instance ?? (_instance = new FirebaseUtils());

        public const string USERDATA_KEY = "userData";

        private MonoBehaviour _mono;
        private IDataService _dataService;
        private IStorageService _storageService;
        // private FirebaseAuth _auth;
        // private FirebaseUser _curUser;
        private bool _curUserInitComplete;
        private string _androidVersion;
        private string _iOSVersion;

        public void Init(MonoBehaviour mono)
        {
            _mono = mono;
            _dataService = MainContainer.Container.Resolve<IDataService>();
            _storageService = MainContainer.Container.Resolve<IStorageService>();
            if (_dataService.UserType == 0) return; // 绑定了 Facebook 的用户才需要定时上传数据
            StartTimer();
        }

        private void StartTimer()
        {
            Observable.Timer(TimeSpan.FromSeconds(3)).Repeat()
                .Subscribe(_ =>
                {
                    // 每 3s 上传一次数据
                    // FirestoreUpdateUser();
                })
                .AddTo(_mono);
        }
        
//         public async Task CheckAndFixDependencies(UnityAction completedCall = null)
//         {
//             Debug.Log($">>> Firebase Start Init ...");
//             bool dependenceComplete = false; // 用户初始化完成
//             
//             await Firebase.FirebaseApp.CheckAndFixDependenciesAsync().ContinueWith(async task =>
//             {
//                 var dependencyStatus = task.Result;
//                 if (dependencyStatus == Firebase.DependencyStatus.Available)
//                 {
//                     // Create and hold a reference to your FirebaseApp,
//                     // where app is a Firebase.FirebaseApp property of your application class.
//                     // Crashlytics will use the DefaultInstance, as well;
//                     // this ensures that Crashlytics is initialized.
//                     Debug.Log($">>> Firebase Init Success ... 1");
//                     _auth = FirebaseAuth.DefaultInstance;
//                     _auth.StateChanged += AuthStateChanged;
// //                    AuthStateChanged(this, null);
//                     Debug.Log($">>> Firebase Init Success ... UserType:{_dataService.UserType}");
//                     _curUserInitComplete = true;
//                     if (_dataService.UserType == 0)
//                     {
//                         if (_auth.CurrentUser == null) await FirebaseSignInAnonymously(); // 默认都使用匿名登录，未关联之前
//                     }
//                     else if (_dataService.UserType == 1)
//                     {
//                         await FirebaseSignInFacebookAccount(_dataService.FbAccount); // 登录Fb账号，关联之后
//                     }
//                     FirebaseFetchRemoteConfigData();
//                     dependenceComplete = true;
//                     // Set a flag here for indicating that your project is ready to use Firebase.
//                 }
//                 else
//                 {
//                     dependenceComplete = true;
//                     Debug.LogError(System.String.Format("Could not resolve all Firebase dependencies: {0}", dependencyStatus));
//                     // Firebase Unity SDK is not safe to use here.
//                 }
//                 
//                 completedCall?.Invoke();
//             });
//         }
//
//         #region SignIn
//
//         /// <summary>
//         /// 匿名登录(每次登录默认是匿名登录)
//         /// </summary>
//         /// <returns></returns>
//         private async Task FirebaseSignInAnonymously()
//         {
//             await _auth.SignInAnonymouslyAsync().ContinueWith(task =>
//             {
//                 if (task.IsCanceled) {
//                     Debug.LogError("SignInAnonymouslyAsync was canceled.");
//                     return;
//                 }
//                 if (task.IsFaulted) {
//                     Debug.LogError("SignInAnonymouslyAsync encountered an error: " + task.Exception);
//                     return;
//                 }
//                 
//                 FirebaseUser user = task.Result;
//                 if (string.IsNullOrEmpty(_dataService.InstallUid)) _dataService.InstallUid = user.UserId;
//                 
//                 Debug.Log($">>> FirebaseSignInAnonymously >> CurUser:{_auth.CurrentUser.UserId}");
//             });
//         }
//
//         private async Task FirebaseSignInFacebookAccount(string fbUid, UnityAction resultCall = null)
//         {
//             string account = fbUid;
//             string password = "123456";
//             Debug.Log($">>> FirebaseSignInFacebookAccount >> fbAccount:{account}");
//             await _auth.SignInWithEmailAndPasswordAsync(account, password).ContinueWith(async task => {
//                 if (task.IsCanceled) {
//                     Debug.LogError("SignInWithEmailAndPasswordAsync was canceled.");
//                     return;
//                 }
//                 if (task.IsFaulted) {
//                     Debug.LogError("SignInWithEmailAndPasswordAsync encountered an error: " + task.Exception);
//                     return;
//                 }
//                 
//                 FirebaseUser newUser = task.Result;
//                 await FirestoreGetUser();
//                 if (resultCall != null)
//                 {
//                     // 需要回调说明是关联过来的
//                     _linkAccount = account;
//                     resultCall.Invoke();
//                 }
//                 Debug.Log($">>> FirebaseSignInFacebookAccount >> Fb Login Success ... ");
//             });
//         }
//
//         #endregion
//
//         #region Link
//
//         /// <summary>
//         /// 由于真实的 facebook 绑定有问题，只能先用假绑定
//         /// 第一个绑定的匿名账号是Facebook相关的数据，后面再有其他匿名账号绑定只是去修改这一份数据而已
//         /// </summary>
//         /// <param name="fbUid"></param>
//         /// <param name="resultCall"></param>
//         public void FirebaseLinkWithFacebookAccount(string fbUid, UnityAction resultCall)
//         {
//             string account = $"fb_{fbUid}@eyu.com";
//             string password = "123456";
//             _fbUid = fbUid;
//             Debug.Log($">>> FirebaseLinkWithFacebookAccount >> account:{account}");
//             Debug.Log($">>> FirebaseLinkWithFacebookAccount >> curUserId:{_auth.CurrentUser.UserId}");
//             Credential credential = EmailAuthProvider.GetCredential(account, password);
//             _auth.CurrentUser.LinkWithCredentialAsync(credential).ContinueWith(async task => {
//                 if (task.IsCanceled) {
//                     Debug.LogError("LinkWithCredentialAsync was canceled.");
//                     resultCall?.Invoke();
//                     return;
//                 }
//                 if (task.IsFaulted) {
//                     // 这一步说明已经绑定过账号，那就直接改变状态拿数据就行
//                     Debug.LogError("LinkWithCredentialAsync encountered an error: " + task.Exception);
//                     await FirebaseSignInFacebookAccount(account, resultCall);
//                     return;
//                 }
//
//                 _linkAccount = account;
//                 FirebaseUser newUser = task.Result;
//                 await FirestoreCreateUser();
//                 string userData = await FirestoreGetUser();
//                 Debug.LogFormat("Credentials successfully linked to Firebase user: {0} ({1})", newUser.DisplayName, newUser.UserId);
//                 Debug.Log($">>> FirebaseLinkWithFacebook >> CurUser:{_auth.CurrentUser.UserId}");
//                 Debug.Log($">>> FirebaseLinkWithFacebookAccount >> userData:{userData}");
//                 resultCall?.Invoke();
//             });
//         }
//         
//         private string _linkAccount;
//         private string _fbUid;
//         public async void FirebaseLinkWithFacebookSuccess()
//         {
//             // 关联 Facebook 成功
//             _dataService.UserType = 1;
//             _dataService.FbAccount = _linkAccount;
//             AnalyticeUtils.AddAccountId(_fbUid);
//             StartTimer(); // 重新关联后应该重新开启定时器，定期存储刷剧
//             await UpdateCurrentLink(_dataService.InstallUid);
//         }
//
//         /// <summary>
//         /// 假解绑
//         /// </summary>
//         public async void FirebaseUnlinkWithFacebookAccount(UnityAction resultCall = null)
//         {
//             Debug.Log($">>> FirebaseUnlinkWithFacebookAccount >> Unlink Success ...");
//             _dataService.UserType = 0;
//             _dataService.FbAccount = "";
//             if (resultCall != null)
//             {
//                 // 手动取消关联
//                 AnalyticeUtils.RemoveAccountId();
//                 await UpdateCurrentLink();
//                 resultCall.Invoke();   
//             }
//         }
//
//         #endregion
//
//         /// <summary>
//         /// 退出登录
//         /// </summary>
//         /// <returns></returns>
//         private async Task FirebaseUserSignOut()
//         {
//             _auth.SignOut();
//         }
//         
//         /// <summary>
//         /// 用户登录状态改变
//         /// </summary>
//         /// <param name="sender"></param>
//         /// <param name="eventArgs"></param>
//         private void AuthStateChanged(object sender, System.EventArgs eventArgs) {
//             Debug.Log($">>> AuthStateChanged >> curUser:{_auth.CurrentUser == null}");
//             if (_auth.CurrentUser != _curUser) 
//             {
//                 bool signedIn = _curUser != _auth.CurrentUser && _auth.CurrentUser != null;
//                 if (!signedIn && _curUser != null) {
//                     // 登出成功
//                     Debug.Log($">>> Signed out >> user:{_curUser.UserId}");
//                 }
//                 
//                 if (signedIn) {
//                     // 登录成功
//                     _curUser = _auth.CurrentUser;
//                     Debug.Log(">>> AuthStateChanged >> Signed in " + _curUser.UserId);
//                     string displayName = _curUser.DisplayName ?? "";
//                     string emailAddress = _curUser.Email ?? "";
// //                Uri photoUrl = _curUser.PhotoUrl ?? new Uri("");
//                     Debug.Log($">>> AuthStateChanged >> SignIn > displayName:{displayName}, emailAddress:{emailAddress}");
//                 }
//             }
//         }
//
//         #region UserData
//
//         /// <summary>
//         /// 用户首次登录
//         /// </summary>
//         private async Task FirestoreCreateUser()
//         {
//             bool userExist = await IsUserExist();
//             if (userExist) return;  // 已经创建过的用户不要重新创建
//             Debug.Log($">>> FirestoreCreateUser >> 即将创建一个新的用户 ...");
//             DocumentReference document = FirebaseFirestore.DefaultInstance.Collection("users")
//                 .Document(_curUser.UserId).Collection("masters").Document("device");
//             Dictionary<string, object> device = new Dictionary<string, object>
//             {
//                 { "cur_device", _curUser.UserId }
//             };
//             await document.SetAsync(device);
//         }
//
//         private async Task<bool> IsUserExist()
//         {
//             if (_curUser == null) return false;
//             DocumentSnapshot snapshot = await FirebaseFirestore.DefaultInstance.Collection("users")
//                 .Document(_curUser.UserId).Collection("masters").Document("device").GetSnapshotAsync();
//             Debug.Log($">>> IsUserExist >> 用户:{_curUser.UserId},是否存在:{snapshot.Exists}");
//             return snapshot.Exists;
//         }
//
//         private async Task UpdateCurrentLink(string linkUid = "")
//         {
//             Debug.Log($">>> UpdateCurrentLink >> 更新 Facebook 关联信息 ... linkUid:{linkUid}");
//             DocumentReference document = FirebaseFirestore.DefaultInstance.Collection("users")
//                 .Document(_curUser.UserId).Collection("masters").Document("link");
//             Dictionary<string, object> link = new Dictionary<string, object>
//             {
//                 { "cur_link", linkUid }
//             };
//             await document.SetAsync(link);
//         }
//
//         private async Task<string> GetCurrentLink()
//         {
//             string curLink = "";
//             DocumentSnapshot snapshot = await FirebaseFirestore.DefaultInstance.Collection("users")
//                 .Document(_curUser.UserId).Collection("masters").Document("link").GetSnapshotAsync();
//             if (snapshot.TryGetValue("cur_link", out string userData))
//             {
//                 curLink = userData;
//             }
//             Debug.Log($">>> GetCurrentLink >> curLink:{curLink}");
//             return curLink;
//         }
//
//         /// <summary>
//         /// 更新用户信息(未关联 Facebook 前不上传 Firebase)
//         /// </summary>
//         /// <param name="userData"></param>
//         public async void FirestoreUpdateUser()
//         {
//             if (_curUserInitComplete == false || _dataService.UserType == 0) return; // 匿名用户不上传数据
//             var userData = (string)MainContainer.Container.Resolve<IStorageService>().Load<object>(Constants.StorageKey.GameData, "");
//             string curLink = await GetCurrentLink();
//             if (curLink.Equals(_dataService.InstallUid) == false)
//             {
//                 // 这种情况说明被强制踢掉(有人在另一台设备关联了 FB)
//                 FirebaseUnlinkWithFacebookAccount();
//                 return;
//             }
//             Debug.Log($">>> FirestoreUpdateUser >> userData:{userData}");
//             DocumentReference document = FirebaseFirestore.DefaultInstance.Collection("users")
//                 .Document(_curUser.UserId).Collection("branches").Document(_curUser.UserId);
//             Dictionary<string, object> userDict = new Dictionary<string, object>
//             {
//                 { USERDATA_KEY, userData }
//             };
//             await document.SetAsync(userDict);
//         }
//         
//         /// <summary>
//         /// 获取用户数据
//         /// </summary>
//         /// <returns></returns>
//         public async Task<string> FirestoreGetUser()
//         {
//             Debug.Log($">>> FirestoreGetUser ... _curUserInitComplete:{_curUserInitComplete}");
//             string json = "";
//             if (_curUserInitComplete == false || _curUser == null) return json;
//             DocumentSnapshot snapshot = await FirebaseFirestore.DefaultInstance.Collection("users")
//                 .Document(_curUser.UserId).Collection("masters").Document("master").GetSnapshotAsync();
//             if (snapshot.TryGetValue(USERDATA_KEY, out string userData))
//             {
//                 json = userData;
//             }
//             Debug.Log($">>> FirestoreGetUser >> UserId:{_curUser.UserId}, userData:{json}");
//             return json;
//         }
//
//         #endregion

        /// <summary>
        /// 获取版本
        /// </summary>
        /// <returns></returns>
        public string FirebaseGetAppVersion()
        {
#if UNITY_ANDROID
            return _androidVersion;
#elif UNITY_IOS
            return _iOSVersion;
#endif
            return _androidVersion;
        }
        
        // private async void FirebaseFetchRemoteConfigData()
        // {
        //     
        //     
        //     Debug.Log($">>> FirebaseFetchRemoteConfigData >> ...");
        //     await FirebaseRemoteConfig.DefaultInstance.FetchAndActivateAsync().ContinueWithOnMainThread(task =>
        //     {
        //         if (task.IsFaulted)
        //         {
        //             Debug.Log($">>> Fetch Failed  >> ErrorMsg:{task.Exception}");
        //             return;
        //         }
        //
        //         _androidVersion = FirebaseRemoteConfig.DefaultInstance.GetValue("android_version").StringValue;
        //         _iOSVersion = FirebaseRemoteConfig.DefaultInstance.GetValue("ios_version").StringValue;
        //         Debug.Log($">>> Fetch Success ... Completed:{task.IsCompleted}, androidVersion:{_androidVersion}, iOSVersion:{_iOSVersion}");
        //     });
        //     
        //
        // }
        
    }
}