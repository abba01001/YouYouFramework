using System;
using System.Collections.Generic;
using Doozy.Engine.UI;
using UnityEngine;
using UnityEngine.Rendering;

namespace SoliUtils
{
    public class EffectLayer : MonoBehaviour
    {
        public int controllerLayer;
        private Canvas _canvas;
        private void Awake()
        {
            _canvas = GetTopmostCanvasWithUIPopup(gameObject);
        }

        private void OnEnable()
        {
            RefreshLayer();
        }

        private void RefreshLayer()
        {
            if (_canvas != null)
            {
                int newLayer =  _canvas.sortingOrder + controllerLayer;
                SortingGroup[] SortingGroups = transform.GetComponentsInChildren<SortingGroup>();
                foreach (var go in SortingGroups)
                {
                    go.sortingOrder = newLayer;
                }
                
                ParticleSystem[] particleSystems = transform.GetComponentsInChildren<ParticleSystem>();
                foreach (var go in particleSystems)
                {
                    ParticleSystemRenderer renderer = go.GetComponent<ParticleSystemRenderer>();
                    if (renderer != null)
                    {
                        int oldLayer = renderer.sortingOrder;
                        renderer.sortingOrder = oldLayer + newLayer;
                    }
                }
                
                Canvas[] canvasArray = transform.GetComponentsInChildren<Canvas>();
                foreach (var go in canvasArray)
                {
                    go.sortingOrder = newLayer;
                }
            }
        }

        public static Canvas GetTopmostCanvasWithUIPopup(GameObject uiElement)
        {
            if (uiElement == null) return null;

            HashSet<Transform> visitedTransforms = new HashSet<Transform>();
            Transform currentTransform = uiElement.transform;

            while (currentTransform != null)
            {
                if (visitedTransforms.Contains(currentTransform))
                {
                    return null;
                }
                visitedTransforms.Add(currentTransform);

                if (currentTransform.parent == null)
                {
                    return null;
                }

                if (currentTransform.name.Contains("Pop") || currentTransform.name.Contains("View"))
                {
                    Canvas canvas = currentTransform.GetComponent<Canvas>();
                    if (canvas != null)
                    {
                        return canvas;
                    }
                }
                currentTransform = currentTransform.parent;
            }
            return null;
        }
    }

}