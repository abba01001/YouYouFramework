using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Activities;
using UnityEngine;
using UnityEngine.AddressableAssets;

namespace SoliUtils
{
    public class LevelUtils
    {
        public static LevelModel CreateLevelData(string levelJson)
        {
            Debug.Log($"CreateLevelData , levelJson = {levelJson}");

            // var storageService = MainContainer.Container.Resolve<IStorageService>();
            // var assetConfigModel =
            //     storageService.LoadJsonResource($"levels/{lv}", typeof(LevelModel)) as
            //         LevelModel;
            // Debug.Log(assetConfigModel.id);

            // string str = "";
            // for (int i = 887; i < 889; i++)
            // {
            //     var t = Resources.Load<TextAsset>($"Levels/{i+1}");
            //     var mm = JsonUtility.FromJson<LevelModel>(t.text);
            //     str += $"\n======================= Lv.{i + 1} ==\n";
            //     foreach (var c in mm.cards)
            //     {
            //         if (c.type != "value")
            //         {
            //             str += c.type + ",";
            //         }
            //
            //         if (c.modifiers != null && c.modifiers.Length > 0)
            //         {
            //             foreach (var mod in c.modifiers)
            //             {
            //                 str += mod.type + ",";
            //             }
            //         }
            //     }
            // }
            // Debug.Log(str);

            StreamReader sr = null;
            IStorageService storageService = MainContainer.Container.Resolve<IStorageService>();
            try
            {
                sr = new StreamReader(storageService.LevelJsonDownloadPath(levelJson));
                string txt = sr.ReadToEnd();
                var str = DESEncrypt.Decrypt(txt, Constants.DesKey);
                var m = JsonUtility.FromJson<LevelModel>(str);
                FixLevelModel(m);
                return m;
            }
            catch
            {
                var task = Addressables.LoadAssetAsync<TextAsset>($"Assets/Res/Levels/{levelJson}.json");
                task.WaitForCompletion();
                var str = DESEncrypt.Decrypt(task.Result.text, Constants.DesKey);
                var m = JsonUtility.FromJson<LevelModel>(str);
                FixLevelModel(m);
                return m;
            }
            finally
            {
                sr?.Close();
            }

            return null;


            // foreach (var c in m.cards)
            // {
            //     c.y = -c.y;
            //     c.depth = -c.depth;
            //     c.angle = -c.angle;
            // }

            // for (int lv = 1; lv <= 1; lv++)
            // {
            //     
            //     var filename = $"Levels/{lv}";
            //     var targetFile = Resources.Load<TextAsset>(filename);
            //     
            //     
            //     filename = Path.Combine(Application.dataPath, "Resources", "Levels", $"{lv}.json");
            //     if (File.Exists(filename))
            //     {
            //         File.Delete(filename);
            //     }
            //     var json = JsonUtility.ToJson(m);
            //     //WriteFile(filename, json);
            // }
            //
            // return null;
        }

        public static void FixLevelModel(LevelModel lm)
        {
            for (int i = 0; i < lm.cards.Length; i++)
            {
                lm.cards[i].Fix();
            }
        }

        //加载无尽活动关卡
        public static void LoadEndlessLevel(Action<LevelModel> callback)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            var dataService = MainContainer.Container.Resolve<IDataService>();
            Dictionary<int, StageModel> tempStageConfig = new Dictionary<int, StageModel>();
            int level = ActivityManager.Instance.EndlessLevelActivity.GetMyData().level;
            
            if (dataService.EndlessLevelProgress.SubActivityType == 1)
            {
                tempStageConfig = configService.EndlessStageOneConfig;
            }
            else
            {
                tempStageConfig = configService.EndlessStageTwoConfig;
            }

            if (tempStageConfig.TryGetValue(level, out StageModel stage))
            {
                GlobalRes.LoadAsset<TextAsset>($"Assets/Res/Levels/{stage.json}.json", (asset =>
                {
                    var str = DESEncrypt.Decrypt(asset.text, Constants.DesKey);
                    var m = JsonUtility.FromJson<LevelModel>(str);
                    FixLevelModel(m);
                    callback?.Invoke(m);
                }));
            }
        }
        
        //加载正常关卡
        public static void LoadNormalLevel(int level, Action<LevelModel> callback)
        {
            var configService = MainContainer.Container.Resolve<IConfigService>();
            if (configService.StageConfig.TryGetValue(level, out StageModel stage))
            {
                GlobalRes.LoadAsset<TextAsset>($"Assets/Res/Levels/{stage.json}.json", (asset =>
                {
                    var str = DESEncrypt.Decrypt(asset.text, Constants.DesKey);
                    var m = JsonUtility.FromJson<LevelModel>(str);
                    FixLevelModel(m);
                    callback?.Invoke(m);
                }));
            }
        }

        //加载新手关卡
        public static void LoadRookieLevel(int level, Action<LevelModel> callback)
        {
            string[] jsons = {"100001", "100002", "100003"};
            GlobalRes.LoadAsset<TextAsset>($"Assets/Res/Levels/{jsons[level-1]}.json", (asset =>
                {
                    var str = DESEncrypt.Decrypt(asset.text, Constants.DesKey);
                    var m = JsonUtility.FromJson<LevelModel>(str);
                    FixLevelModel(m);
                    callback?.Invoke(m);
                }));
        }
        
        public static void LoadLevel(int level, Action<LevelModel> callback)
        {
            if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
            {
                LoadEndlessLevel(callback);
            }
            else
            {
                LoadNormalLevel(level, callback);
            }
        }

        public static bool CheckVaild(int level, out LevelModel lm)
        {
            bool result = true;
            lm = null;
            var configService = MainContainer.Container.Resolve<IConfigService>();
            if (!configService.GetStageConfig.TryGetValue(level, out StageModel stage))
            {
                Debug.LogError("not exist level config   level=>" + level);
                result = false;
            }
            else
            {
                // #if TestMode && UNITY_EDITOR
                //     GetLevelModel(stage.json, out lm);
                // #else
                var levelModel = LevelUtils.CreateLevelData(stage.json);
                if (levelModel == null)
                {
                    Debug.LogError($"cant load level Data  level:{level} json:{stage.json}");
                    result = false;
                }

                lm = levelModel;
                // #endif
            }

            if (result == false)
            {
                BoxBuilder.ShowTip("网络错误");
                return false;
            }

            return true;
        }

        public static bool GetLevelModel(string levelJson, out LevelModel m)
        {
            m = null;
            //var targetFile = Resources.Load<TextAsset>($"LevelJsons/{levelJson}");
            string filepath = Path.Combine(Application.dataPath, "LevelEditor/LevelJsons");
            string filename = $"{filepath}/{levelJson}.json";
            string targetFile = File.ReadAllText(filename, Encoding.UTF8);
            if (targetFile == null)
            {
                Debug.LogError($"读文件失败 - {levelJson}.json");
                return false;
            }

            // var str = DESEncrypt.Decrypt(targetFile.text, Constants.DesKey);
            m = JsonUtility.FromJson<LevelModel>(targetFile);
            FixLevelModel(m);


            return true;
        }


#if UNITY_EDITOR

        public static void SaveLevelModel(string levelJson, string content)
        {
            string filepath = Path.Combine(Application.dataPath, "LevelEditor/LevelJsons");
            string filename = $"{filepath}/{levelJson}.json";
            if (File.Exists(filename))
            {
                File.Delete(filename);
            }

            WriteFile(filename, content);

            string filepath2 = Path.Combine(Application.dataPath, "Res/Levels");
            string filename2 = $"{filepath2}/{levelJson}.json";
            if (File.Exists(filename2))
            {
                File.Delete(filename2);
            }

            var content2 = Encrypt(content, Constants.DesKey);
            WriteFile(filename2, content2);

            UnityEditor.AssetDatabase.Refresh();
        }

        public static string Encrypt(string Text, string sKey)
        {
            byte[] keyArray = UTF8Encoding.UTF8.GetBytes(sKey);

            RijndaelManaged encryption = new RijndaelManaged();

            encryption.Key = keyArray;

            encryption.Mode = CipherMode.ECB;

            encryption.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = encryption.CreateEncryptor();

            byte[] _EncryptArray = UTF8Encoding.UTF8.GetBytes(Text);

            byte[] resultArray = cTransform.TransformFinalBlock(_EncryptArray, 0, _EncryptArray.Length);

            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        static void WriteFile(string dst, string content)
        {
            var dir = Path.GetDirectoryName(dst);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            File.WriteAllText(dst, content);
        }
#endif
    }
}