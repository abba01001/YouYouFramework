using System;

namespace SoliUtils
{
    public class DebugUtils
    {
        public static void ReportError(string condition, string stackTrace)
        {
#if UNITY_EDITOR || !UNITY_WEBGL
            return;
#endif
            var str = condition + "\n" + stackTrace;
            WeChatMiniGame.ReportGameSceneError(7, 0, str, "");
        }
    }
}
