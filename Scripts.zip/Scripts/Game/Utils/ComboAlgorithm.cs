using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using SoliUtils;

public class ComboAlgorithm
{
    private static Dictionary<int, bool> StopFlag = new Dictionary<int, bool>();
    private const int MaxNum = 13;

    public static Dictionary<int, List<int[]>> FindCombo(int[] arr)
    {
        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = arr[i] % MaxNum;
        }

        Dictionary<int, List<int[]>> resultDic = new Dictionary<int, List<int[]>>();
        for (int i = 0; i < MaxNum; i++)
            resultDic.Add(i, new List<int[]>());

        for (int i = 0; i < MaxNum; i++)
        {
            StopFlag.Clear();
            for (int j = 0; j < MaxNum; j++)
                StopFlag.Add(j, false);
            DoFind(i, new List<int>(arr), new List<int>(), ref resultDic);
        }

        return resultDic;
    }

    public static Dictionary<int, int> FindLink(int[] arr)
    {
        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = arr[i] % MaxNum;
        }

        Dictionary<int, int> lenDic = new Dictionary<int, int>();

        for (int i = 0; i < MaxNum; i++)
        {
            StopFlag.Clear();
            for (int j = 0; j < MaxNum; j++)
                StopFlag.Add(j, false);
            Dictionary<int, List<int[]>> resultDic = new Dictionary<int, List<int[]>>();
            for (int j = 0; j < MaxNum; j++)
                resultDic.Add(j, new List<int[]>());

            DoFind(i, new List<int>(arr), new List<int> { }, ref resultDic);

            var len = 0;
            foreach (var list in resultDic[i])
            {
                len = Math.Max(list.Length, len);
            }

            lenDic.Add(i, len);
        }

        return lenDic;
    }

    private static void DoFind(int key, List<int> inArr, List<int> outArr, ref Dictionary<int, List<int[]>> resultDic)
    {
        if (StopFlag[key % MaxNum])
            return;

        if(inArr.Count > 10)
            inArr.RemoveRange(10, inArr.Count-10);

        long bitFlag = 0L;
        foreach (var a in inArr)
        {
            if (BitUtils.IsFlag(bitFlag, a))
                continue;
            BitUtils.Flag(ref bitFlag, a);
            var val = Math.Abs(key - a) % MaxNum;
            if (IsSimpleMatch(key % MaxNum, a % MaxNum))
            {
                var tempInArr = new List<int>(inArr);
                tempInArr.Remove(a);
                var tempOutArr = new List<int>(outArr);
                if (tempOutArr.Count == 0)
                    tempOutArr.Add(key);
                tempOutArr.Add(a);
                DoFind(a, tempInArr, tempOutArr, ref resultDic);
            }
        }

        if (outArr.Count > 0)
        {
            // var str = "========\n";
            // foreach (var o in outArr) { str += $"{o},"; }
            // Debug.Log(str);
            var k = outArr[0];
            if (resultDic.TryGetValue(k, out var list))
            {
                list.Add(outArr.ToArray());
                if (list.Count >= 8)
                {
                    StopFlag[k % MaxNum] = true;
                }
            }
        }
    }

    private static bool IsSimpleMatch(int value1, int value2)
    {
        if (value1 < 0 || value2 < 0) return false;
        int diff = Math.Abs(value1 - value2);
        return diff == 1 || diff == MaxNum - 1;
    }

    public static int CalculateNeedStep(List<CardData> cardArray)
    {
        List<int> tempList = new List<int>();
        foreach (var item in cardArray)
        {
            bool realValue = false;
            if (!item.IsLocked && item.IsFaceup && item.CardType == CardType.Value)
            {
                if (item.HasCloth())
                {
                }
                else if (item.HasMagicCloth())
                {
                }
                else if (item.HasBird())
                {
                }
                else if (item.HasSuitRope())
                {
                }
                else if (item.HasIce())
                {
                }
                else if (item.HasLinkRope() && !item.CanRemoveLinkRope())
                {
                }
                else if (item.HasLowering())
                {
                }
                else if (item.HasRising())
                {
                }
                else
                {
                    realValue = true;
                }
            }
            if (realValue)
            {
                tempList.Add(item.Value);
            }
        }

        var len = FindLongestConsecutiveSequence(tempList.ToArray());

        // Debug.Log($"=== 控制 == {cardArray.Count} {tempList.Count} {len}");
        return cardArray.Count - len + 1;
    }

    static public int FindLongestConsecutiveSequence(int[] nums)
    {
        if (nums == null || nums.Length == 0)
            return 1;

        var dic = FindCombo(nums);
        int maxLen = int.MinValue;
        foreach (var pair in dic)
        {
            foreach (var list in pair.Value)
            {
                if (list.Length <= maxLen)
                    continue;
                if (list.Length > maxLen)
                {
                    maxLen = list.Length;
                }
            }
        }
        return maxLen - 1;
    }
}