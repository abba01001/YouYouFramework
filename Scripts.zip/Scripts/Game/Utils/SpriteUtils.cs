using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.U2D;
using UnityEngine.UI;
#if UNITY_WEBGL
using WeChatWASM;
#endif

namespace SoliUtils
{
    public static class SpriteUtils
    {
        private static readonly Dictionary<string, SpriteAtlas> _atlasDic = new Dictionary<string, SpriteAtlas>();
        private static Dictionary<int, Texture2D> RobotHeadSprites = new Dictionary<int, Texture2D>();
        #region LoadSprite(同步加载)

        public static void LoadSpriteByAtlas(this Image image, string key, string name)
        {
            image.sprite = LoadSpriteByAtlasKeyAndSpriteName(key, name);
        }

        public static Sprite LoadSpriteByAtlas(string key, string name)
        {
            return LoadSpriteByAtlasKeyAndSpriteName(key, name);
        }

        public static Texture2D LoadTexture2DByAtlas(string key, string name)
        {
            var sprite = LoadSpriteByAtlas(key, name);
            Texture2D texture2D = new Texture2D((int)sprite.textureRect.width, (int)sprite.textureRect.height);
            var pixels = sprite.texture.GetPixels(
                (int)sprite.textureRect.x,
                (int)sprite.textureRect.y,
                (int)sprite.textureRect.width,
                (int)sprite.textureRect.height);
            texture2D.SetPixels(pixels);
            texture2D.Apply();
            return texture2D;
        }

        private static Sprite LoadSpriteByAtlasKeyAndSpriteName(string key, string name)
        {
            if (_atlasDic.TryGetValue(key, out SpriteAtlas atlas))
            {
                return atlas.GetSprite(name);
            }

            var spriteAtlas = GlobalRes.Load<SpriteAtlas>(key);
            _atlasDic.Add(key, spriteAtlas);
            return spriteAtlas.GetSprite(name);
        }

        #endregion

        #region LoadSprite(异步加载)
        private static async Task<T> GetAssetAsync<T>(string assetPath, Action<T> action = null) where T : UnityEngine.Object
        {
            var obj = GlobalRes.GetPreloadResPrefab<T>(assetPath);
            if (obj != null)
            {
                action?.Invoke(obj);
                return obj;
            }
            else
            {
                var handle = await GlobalRes.LoadAssetAsync<T>(assetPath);
                if (handle.Status == AsyncOperationStatus.Succeeded)
                {
                    T loadedAsset = handle.Result;
                    action?.Invoke(loadedAsset);
                    return loadedAsset;
                }
                else
                {
                    return null;
                }
            }
        }

        //获取Texture2d纹理
        public static async Task<Texture2D> GetTextureAsyncByPath(string assetPath, Action<Texture2D> action = null)
        {
            return await GetAssetAsync<Texture2D>(assetPath, action);
        }

        //获取sprite
        public static async Task<Sprite> GetSpriteAsyncByPath(string assetPath, Action<Sprite> action)
        {
            return await GetAssetAsync<Sprite>(assetPath, action);
        }

        //获取atlas图集
        public static async Task<SpriteAtlas> GetAtlasAsyncByPath(string assetPath, Action<SpriteAtlas> action)
        {
            return await GetAssetAsync<SpriteAtlas>(assetPath, action);
        }

        //通过图集设置sprite
        public static async Task SetSpriteByAtlas(this Component component, string key, string name, bool needSetNative = true, Action action = null)
        {
            _ = GetAtlasAsyncByPath(key, (atlas) =>
            {
                SetSpriteAsyncDetail(atlas, component, name, needSetNative, action);
            });
        }

        //设置Prop道具属性sprite
        public static void LoadPropSprite(this Image image, int prop_id, bool needSetNative = true, Action action = null)
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            if (!configService.MergeItemConfig.ContainsKey(prop_id))
            {
                string key = Constants.AtlasNamePath.PropsAtlas;
                string icon = configService.ItemConfig[prop_id].icon;
                image.SetSpriteByAtlas(key, icon, needSetNative, action);
            }
            else
            {
                string key = Constants.AtlasNamePath.MergeItemsAtlas;
                image.SetSpriteByAtlas(key, prop_id.ToString(), needSetNative, action);
            }
        }

        public static void LoadPropSprite(this SpriteRenderer image, int prop_id, bool needSetNative = true, Action action = null)
        {
            IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
            if (!configService.MergeItemConfig.ContainsKey(prop_id))
            {
                string key = Constants.AtlasNamePath.PropsAtlas;
                string icon = configService.ItemConfig[prop_id].icon;
                image.SetSpriteByAtlas(key, icon, needSetNative, action);
            }
            else
            {
                string key = Constants.AtlasNamePath.MergeItemsAtlas;
                image.SetSpriteByAtlas(key, prop_id.ToString(), needSetNative, action);
            }
        }

        static void SetSpriteAsyncDetail(SpriteAtlas atlas, Component component, string name, bool needSetNative = true, Action action = null)
        {
            if (component == null || component.gameObject == null)
            {
                return;
            }
            switch (component)
            {
                case Image image:
                    image.sprite = atlas.GetSprite(name);
                    image.enabled = true;
                    if (needSetNative) image.SetNativeSize();
                    break;
                case SpriteRenderer spriteRenderer:
                    spriteRenderer.sprite = atlas.GetSprite(name);
                    spriteRenderer.enabled = true;
                    break;
                case RawImage rawImage:
                    rawImage.texture = atlas.GetSprite(name).texture;
                    rawImage.enabled = true;
                    break;
                default:
                    break;
            }
            action?.Invoke();
        }
        #endregion
        public static Texture2D ReadTexture(string file_path)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            WXFileSystemManager fs = WX.GetFileSystemManager();
            try
            {
                var data = fs.ReadFileSync(file_path);
                Texture2D t = new Texture2D(1, 1);
                t.LoadImage(data);
                return t;
            }
            catch
            {
                Debug.LogWarning(file_path + " is not exist");
                return null;
            }
#else
            FileStream stream;
            try
            {
                stream = new FileStream(file_path, FileMode.Open, FileAccess.ReadWrite);
                byte[] bb = new byte[stream.Length];
                stream.Read(bb, 0, bb.Length);
                Texture2D t = new Texture2D(1, 1);
                t.LoadImage(bb);
                stream.Close();
                return t;
            }
            catch
            {
                Debug.LogWarning(file_path + " is not exist");
                return null;
            }
#endif

        }

        public static void SetRobotSpriteByIndex(Image image, int index, Action cb = null)
        {
            if (index == -1) return;
            if (RobotHeadSprites.TryGetValue(index, out Texture2D tex) && tex != null)
            {
                if (image == null) return;
                image.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                cb?.Invoke();
            }
            else
            {
                var url = Constants.StorageUrl + $"/avatars/{index}.jpg";
                GameUtils.GetAvatar(url, (ret, filePath) =>
                {
                    if (ret)
                    {
                        var tex = ReadTexture(filePath);
                        if (tex != null)
                        {
                            RobotHeadSprites.TryAdd(index, tex);
                            if (image == null) return;
                            image.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                            cb?.Invoke();
                        }
                    }
                });
            }
        }
    }
}