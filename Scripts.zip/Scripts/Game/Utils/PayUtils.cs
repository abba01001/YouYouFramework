using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using SimpleJSON;
using QFramework;
using UniRx;
using UnityEngine;
using UnityEngine.Networking;

namespace SoliUtils
{
    public class PayUtils
    {
        private static bool orderFlag = false;
        public static void RequestOrder(string product_id, string paramex = "", Action<bool> callback = null)
        {
            if(GameCommon.IsOffMode) return;
#if UNITY_EDITOR
            var e = new RechargeEvent();
            e.ret = true;
            e.product_id = product_id;
            e.paramex = paramex;
            TypeEventSystem.Send<RechargeEvent>(e);
            callback?.Invoke(true);
            return;
#endif

            var configSrv = MainContainer.Container.Resolve<IConfigService>();
            configSrv.ShopConfig.TryGetValue(product_id, out var productCfg);
            if (productCfg == null)
            {
                Debug.LogError($"product_id : {product_id} is not exsit");
                return;
            }

            var dataSrv = MainContainer.Container.Resolve<IDataService>();
            string uid = dataSrv.UserId;
            string device_id = DeviceUtils.GetDeviceId();
            var time = TimeUtils.UtcNow();
            string flag = EncryptUtils.MD5Encrypt(uid + product_id + time + Constants.ServerKey);
            string url = Constants.ApiUrl + "/create_order";
            url = $"{url}?user_id={uid}&product_id={product_id}&time={time}&flag={flag.ToLower()}&device_id={device_id}&paramex={paramex}";
            // Debug.Log("url: "+url);
            StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
            {
                if (ret)
                {
                    var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
                    if (dic != null && dic.TryGetValue("order_id", out var order_id))
                    {
                        Debug.Log("PayUtils, call pay");
                        orderFlag = true;
                        WeChatMiniGame.Pay(productCfg.product_id, productCfg.money, productCfg.game_gold, productCfg.product_name, productCfg.product_desc, order_id.ToString());
                        // int ask_time = 120;
                        // AskOrderInfo(product_id, order_id.ToString(), ask_time, callback);
                        var msg = new Dictionary<string, object>
                        {
                            {"product_id", product_id},
                            {"money", productCfg.money},
                        };
                        AnalyticUtils.ReportEvent(AnalyticsKey.SoliRequestPay, msg);
                    }
                }
                else
                {
                    callback?.Invoke(false);
                }
            }));

            var msg = new Dictionary<string, object>
            {
                {"product_id", product_id},
                {"money", productCfg.money},
                {"paramex", paramex},
            };
            AnalyticUtils.ReportEvent(AnalyticsKey.SoliRequestOrder, msg);
        }

        public static void AskOrderInfo(string product_id, string order_id, int ask_time, Action<bool> callback)
        {
            if(GameCommon.IsOffMode) return;
            if (ask_time <= 0)
                return;
            ask_time--;

            Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe(_ =>
            {
                var dataSrv = MainContainer.Container.Resolve<IDataService>();
                string uid = dataSrv.UserId;
                var time = TimeUtils.UtcNow();
                string flag = EncryptUtils.MD5Encrypt(uid + order_id + time + Constants.ServerKey);
                string url = Constants.ApiUrl + "/order_info";
                url = $"{url}?uid={uid}&order_id={order_id}&time={time}&flag={flag.ToLower()}";
                StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
                {
                    var e = new RechargeEvent();
                    e.product_id = product_id;
                    var configSrv = MainContainer.Container.Resolve<IConfigService>();
                    configSrv.ShopConfig.TryGetValue(product_id, out var productCfg);
                    if (productCfg == null)
                    {
                        Debug.LogError($"product_id : {product_id} is not exsit");
                        return;
                    }
                    if (ret)
                    {
                        var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
                        if (dic != null && dic.TryGetValue("status", out var status))
                        {
                            int st = Convert.ToInt32(status);
                            if (st == 1)
                            {
                                if (IsConfirmOrder(order_id))
                                    return;

                                callback?.Invoke(true);
                                e.ret = true;
                                dic.TryGetValue("paramex", out var paramex);
                                e.paramex = paramex.ToString();
                                dic.TryGetValue("svr_order_id", out var svr_order_id);
                                WeChatMiniGame.ReportPay(svr_order_id.ToString(), order_id, productCfg.money, product_id, productCfg.product_desc);

                                TypeEventSystem.Send<RechargeEvent>(e);
                                ConfirmOrder(order_id);
                                dataSrv.CumulativeRechargeAmount += productCfg.money;
                                dataSrv.CumulativeRechargeCount += 1;
                                
                                AnalyticUtils.ReportUser_SetOnce(AnalyticsKey.FirstCallPayLevel, dataSrv.MaxLevel);
                                AnalyticUtils.ReportUser_SetOnce(AnalyticsKey.FirstPayTime, TimeUtils.UtcNow());
                                AnalyticUtils.ReportUser_Set(AnalyticsKey.LastPayTime, TimeUtils.UtcNow());
                                AnalyticUtils.ReportUser_Add(AnalyticsKey.TotalPayAmount, productCfg.money);
                                AnalyticUtils.ReportUser_Add(AnalyticsKey.TotalPayCount, 1);
                                var msg = new Dictionary<string, object>
                                {
                                    {"product_id", product_id},
                                    {"svr_order_id", svr_order_id},
                                    {"money", productCfg.money},
                                    {AnalyticsKey.MaxLevel, dataSrv.MaxLevel},
                                    {"first_pay", dataSrv.CumulativeRechargeCount == 1}
                                };
                                AnalyticUtils.ReportEvent(AnalyticsKey.SoliPaySuccess, msg);
                            }
                            else
                            {
                                Debug.Log($"PayUtils, AskOrderInfo after pay ask_time:{ask_time}");
                                if (ask_time > 0)
                                    AskOrderInfo(product_id, order_id, ask_time, callback);
                            }
                        }
                        else
                        {
                            callback?.Invoke(false);
                            e.ret = true;
                            if (ask_time > 0)
                                AskOrderInfo(product_id, order_id, ask_time, callback);
                        }
                    }
                    else
                    {
                        callback?.Invoke(false);
                        e.ret = false;
                        if (ask_time > 0)
                            AskOrderInfo(product_id, order_id, ask_time, callback);
                    }
                }));
            });
        }

        //询问未完成订单
        public static void CheckOrder(int ask_time = 10)
        {
            if(GameCommon.IsOffMode) return;
            if (ask_time <= 0)
                return;
            ask_time--;
            Debug.Log($"CheckOrder run");
            Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe(_ =>
            {
                var dataSrv = MainContainer.Container.Resolve<IDataService>();
                string uid = dataSrv.UserId;
                var time = TimeUtils.UtcNow();
                string order_id = "";
                string flag = EncryptUtils.MD5Encrypt(uid + order_id + time + Constants.ServerKey);
                string url = Constants.ApiUrl + "/order_info";
                url = $"{url}?uid={uid}&order_id={order_id}&time={time}&flag={flag.ToLower()}";
                StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
                {
                    Debug.Log($"CheckOrder json : {json}");
                    if (ret)
                    {
                        var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
                        if (dic != null && dic.TryGetValue("order_list", out var order_list))
                        {
                            JSONNode jsonNode = JSON.Parse(json);
                            JSONArray orderList = jsonNode["order_list"].AsArray;
                            if (orderList.Count == 0)
                            {
                                if (ask_time > 0)
                                    CheckOrder(ask_time);
                            }
                            else
                            {
                                foreach (JSONNode order in orderList)
                                {
                                    string orderId = order["order_id"];
                                    string productId = order["product_id"];
                                    AskOrderInfo(productId, orderId, 10, null);
                                }
                            }
                        }
                        else
                        {
                            if (ask_time > 0)
                                CheckOrder(ask_time);
                        }
                    }
                    else
                    {
                        if (ask_time > 0)
                            CheckOrder(ask_time);
                    }
                }));
            });
        }

        //是否已确认订单
        public static bool IsConfirmOrder(string order_id)
        {
            var dataSrv = MainContainer.Container.Resolve<IDataService>();
            if (dataSrv.OrderList != null)
            {
                foreach (var item in dataSrv.OrderList)
                {
                    if (item == order_id)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        //确认订单
        public static void ConfirmOrder(string order_id, int ask_time = 10)
        {
            if(GameCommon.IsOffMode) return;
            if (ask_time <= 0)
                return;
            ask_time--;

            if (IsConfirmOrder(order_id))
                return;

            var dataSrv = MainContainer.Container.Resolve<IDataService>();
            List<string> orders = new List<string>();
            if (dataSrv.OrderList != null)
            {
                orders = dataSrv.OrderList.ToList();
            }
            orders.Add(order_id);
            dataSrv.OrderList = orders.ToArray();
            dataSrv.SaveData(true, true);

            Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe(_ =>
            {
                string uid = dataSrv.UserId;
                var time = TimeUtils.UtcNow();
                string flag = EncryptUtils.MD5Encrypt(uid + order_id + time + Constants.ServerKey);
                string url = Constants.ApiUrl + "/confirm_order";
                url = $"{url}?uid={uid}&order_id={order_id}&time={time}&flag={flag.ToLower()}";
                StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
                {
                    if (ret)
                    {
                        var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
                        if (dic != null && dic.TryGetValue("status", out var status))
                        {
                            int st = Convert.ToInt32(status);
                            if (st == 2)
                            {
                            }
                            else
                            {
                                if (ask_time > 0)
                                    ConfirmOrder(order_id, ask_time);
                            }
                        }
                        else
                        {
                            if (ask_time > 0)
                                ConfirmOrder(order_id, ask_time);
                        }
                    }
                    else
                    {
                        if (ask_time > 0)
                            ConfirmOrder(order_id, ask_time);
                    }
                }));
            });
        }


        static IEnumerator GetRequest(string url, Action<bool, string> callback)
        {
            using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
            {
                yield return webRequest.SendWebRequest();

                if (webRequest.result == UnityWebRequest.Result.ConnectionError || webRequest.result == UnityWebRequest.Result.ProtocolError)
                {
                    Debug.LogError("Error: " + webRequest.error);
                    callback?.Invoke(false, "");
                }
                else
                {
                    // Debug.Log($"{url}, Response=> {webRequest.downloadHandler.text}");
                    callback?.Invoke(true, webRequest.downloadHandler.text);
                }
            }
        }

        public static void OnWxShow()
        {
            Debug.Log("=== PayUtils.OnWxShow");
            int time = 10;
            if (orderFlag)
                time = 60;
            CheckOrder(time);
        }

        public static void OnWxHide()
        {
            Debug.Log("=== PayUtils.OnWxHide");
        }


    }
}