using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
 
namespace SoliUtils
{
    public class ParticleClip : MonoBehaviour
    {
 
        private Renderer _renderer;
 
        void OnEnable()
        {
            ParticleSystemRenderer particleRenderer = GetComponent<ParticleSystemRenderer>();
            var mask = GetComponentInParent<UnityEngine.UI.RectMask2D>();
            if (particleRenderer && mask)
            {
                Vector3[] vector3s = new Vector3[4];
                mask.rectTransform.GetWorldCorners(vector3s);
                Vector4 _ClipRect = new Vector4(vector3s[0].x, vector3s[0].y, vector3s[2].x, vector3s[2].y);
                // Apply the clip rect to the material
                particleRenderer.material.SetVector("_ClipRect", _ClipRect);
                particleRenderer.material.SetFloat("_UNITY_UI_CLIP_RECT", 1);
            }

        }
    }
}