using System;
using System.Collections.Generic;
using QFramework;
using UnityEngine;
// using Unity.Notifications.Android;


namespace SoliUtils
{
    public class NotificationCenter : MonoBehaviour, ISingleton
    {
        public enum PushMessageType
        {
            Activity = 1,
            Harvest,
            Callback,
        }

        private const string HarvestChannel = "harvest_channel";
        private const string CallbackChannel = "callback_channel";
        private const string ActivityChannel = "activity_channel";
        private IConfigService configService;
        private IDataService dataService;
        private List<TimingMessageConfigModel> activityPushList = new List<TimingMessageConfigModel>();
        private TimingMessageConfigModel harvestPush;
        private TimingMessageConfigModel callbackPush;

        private List<Tuple<int, TimingMessageConfigModel>> notificationIdList =
            new List<Tuple<int, TimingMessageConfigModel>>();

        private Dictionary<int, long> notificationInterval = new Dictionary<int, long>();

        public void OnSingletonInit()
        {
        }

        public void Init()
        {
            Debug.Log("NotificationCenter Init");
        }

        public static NotificationCenter Instance
        {
            get { return MonoSingletonProperty<NotificationCenter>.Instance; }
        }

        void Start()
        {
//         configService = MainContainer.Container.Resolve<IConfigService>();
//         dataService = MainContainer.Container.Resolve<IDataService>();
//
//         foreach (var item in configService.TimingMessageConfig.Values)
//         {
//             var pushType = (PushMessageType)item.push_type;
//             switch (pushType)
//             {
//                 case PushMessageType.Activity:
//                     activityPushList.Add(item);
//                     break;
//
//                 case PushMessageType.Harvest:
//                     harvestPush = item;
//                     break;
//
//                 case PushMessageType.Callback:
//                     callbackPush = item;
//                     break;
//             }
//         }
//
// #if UNITY_IOS
// #elif UNITY_ANDROID
//         AndroidNotificationCenter.RegisterNotificationChannel(new AndroidNotificationChannel()
//         {
//             Id = HarvestChannel,
//             Name = HarvestChannel,
//             Description = HarvestChannel,
//             Importance = Importance.High
//         });
//         AndroidNotificationCenter.RegisterNotificationChannel(new AndroidNotificationChannel()
//         {
//             Id = CallbackChannel,
//             Name = CallbackChannel,
//             Description = CallbackChannel,
//             Importance = Importance.High
//         });
//         AndroidNotificationCenter.RegisterNotificationChannel(new AndroidNotificationChannel()
//         {
//             Id = ActivityChannel,
//             Name = ActivityChannel,
//             Description = ActivityChannel,
//             Importance = Importance.High
//         });
//
//         AndroidNotificationCenter.NotificationReceivedCallback receivedNotificationHandler =
//         delegate (AndroidNotificationIntentData data)
//         {
//             Dictionary<string, object> dict = new Dictionary<string, object>
//             {
//                 { AnalyticsKey.NotificationChannel, data.Channel },
//             };
//             AnalyticeUtils.ReportEvent(AnalyticsKey.SoliNotification, dict);
//             switch(data.Channel)
//             {
//                 case HarvestChannel:
//                     Debug.Log("NotificationCenter : CoinFullChannel");
//                     break;
//                 case CallbackChannel:
//                     Debug.Log("NotificationCenter : CallbackChannel");
//                     break;
//                 case ActivityChannel:
//                     Debug.Log("NotificationCenter : ActivityChannel");
//                     break;
//             }
//         };
//         AndroidNotificationCenter.OnNotificationReceived += receivedNotificationHandler;
// #endif
        }

        private void OnApplicationPause(bool pauseStatus)
        {
            if (pauseStatus)
            {
                // if(dataService.TodayNotificationCount >= configService.MessageLimit)
                //     return;
                // HarvestNotification();
                // CallbackNotification();
                // ActivityNotification();
            }
            else
            {
#if UNITY_ANDROID
            CheckNotifications();
#endif
            }
        }

        private void CheckNotifications()
        {
            // Debug.Log("CheckNotifications ========= 1");
            // for (int i = 0; i < notificationIdList.Count; i++)
            // {
            // Debug.Log("CheckNotifications ========= 2");
            //     var item = notificationIdList[i];
            //     var nid = item.Item1;
            //     var push = item.Item2;
            // Debug.Log($"CheckNotifications xx========= {push.id}");
            //     NotificationStatus status = AndroidNotificationCenter.CheckScheduledNotificationStatus(nid);
            //     
            // Debug.Log($"CheckNotifications xxx========= {status}");
            // if(status == NotificationStatus.Delivered)
            //     {
            //         dataService.TodayNotificationCount ++;
            //         notificationIdList.RemoveAt(i);
            //         i--;
            //         notificationInterval.Add(push.id, TimeUtils.UtcNow());
            //     }
            // }
            // AndroidNotificationCenter.CancelAllNotifications();
            // Debug.Log("CheckNotifications ========= 3");
        }

        private void OnApplicationQuit()
        {
            // ActivityNotification();
            // CheckNotifications();
        }


        private void HarvestNotification()
        {
            // if(harvestPush == null)
            //     return;
            //
            // if(notificationInterval.TryGetValue(harvestPush.id, out var t))
            // {
            //     if(TimeUtils.UtcNow() < t+harvestPush.act_interval)
            //         return;
            // }
            //
            // long timeLeft = dataService.LastGoldTime + configService.TimerGoldSecond - TimeUtils.UtcNow();
            // if(timeLeft < 0)
            //     timeLeft = 0;
            //
            // var fireTime = DateTime.Now.AddSeconds(timeLeft);
            // fireTime = CheckFireTime(fireTime);
            //
            // var notification = new AndroidNotification();
            // notification.Title = LocalizationManager.GetTranslation(harvestPush.title);
            // notification.Text = LocalizationManager.GetTranslation(harvestPush.text);
            // notification.FireTime = fireTime;
            // var nid = AndroidNotificationCenter.SendNotification(notification, HarvestChannel);
            // notificationIdList.Add(new Tuple<int, TimingMessageConfigModel>(nid, harvestPush));
        }

        private void CallbackNotification()
        {
            // if(callbackPush == null)
            //     return;
            //
            // if(notificationInterval.TryGetValue(callbackPush.id, out var tt))
            // {
            //     if(TimeUtils.UtcNow() < tt+callbackPush.act_interval)
            //         return;
            // }
            //
            // Debug.Log("=== CallbackNotification 1");
            // long timeLeft = callbackPush.noactive_condition;
            // var fireTime = DateTime.Now.AddSeconds(timeLeft);
            // fireTime = new DateTime(fireTime.Year, fireTime.Month, fireTime.Day);
            // if(callbackPush.pushTime.Length > 0)
            // {
            // Debug.Log("=== CallbackNotification "+callbackPush.pushTime[0]);
            //     var t = callbackPush.pushTime[0].Trim();
            // Debug.Log("=== CallbackNotification "+t);
            //     DateTime dt = DateTime.ParseExact(t, "HH:mm", System.Globalization.CultureInfo.CurrentCulture);
            //     fireTime.AddHours(dt.Hour).AddMinutes(dt.Minute);
            // }
            // else
            //     fireTime.AddHours(12).AddMinutes(30);
            //
            // var notification = new AndroidNotification();
            // notification.Title = LocalizationManager.GetTranslation(callbackPush.title);
            // notification.Text = LocalizationManager.GetTranslation(callbackPush.text);
            // notification.FireTime = fireTime;
            // var nid = AndroidNotificationCenter.SendNotification(notification, CallbackChannel);
            // notificationIdList.Add(new Tuple<int, TimingMessageConfigModel>(nid, callbackPush));
        }

        private void ActivityNotification()
        {
            // Debug.Log("====== ActivityNotification 1");
            // if(activityPushList.Count == 0)
            //     return;
            //
            // Debug.Log("====== ActivityNotification 2");
            // TimingMessageConfigModel tarPush = null;
            // var order = -1;
            // Debug.Log(ActivityManager.Instance.BattlePass.state);
            // Debug.Log(ActivityManager.Instance.Piggy.state);
            // foreach (var item in activityPushList)
            // {
            //     if(item.order >= order)
            //     {
            //         if(notificationInterval.TryGetValue(item.id, out var tt))
            //         {
            //             if(TimeUtils.UtcNow() < tt+item.act_interval)
            //                 continue;
            //         }
            //         if(item.acType == ActivityType.battlepass &&
            //             ActivityManager.Instance.BattlePass.state == ActivityState.underWay &&
            //             dataService.MaxLevel >= item.lv_condition)
            //         {
            //             tarPush = item;
            //             order = item.order;
            //         }
            //         else if(item.acType == ActivityType.piggy &&
            //             ActivityManager.Instance.Piggy.state == ActivityState.underWay &&
            //             dataService.MaxLevel >= item.lv_condition)
            //         {
            //             var piggyData = (PiggyData)ActivityManager.Instance.Piggy?.localData;
            //             if(piggyData == null || !piggyData.isBuy)
            //             {
            //                 tarPush = item;
            //                 order = item.order;
            //             }
            //         }
            //     }
            // }
            // if(tarPush == null)
            // {
            //     return;
            // }
            //
            //
            // if(tarPush.pushTime.Length > 0)
            // {
            //     foreach (var item in tarPush.pushTime)
            //     {
            //         var t = item.Trim();
            //         DateTime dt = DateTime.ParseExact(t, "HH:mm", System.Globalization.CultureInfo.CurrentCulture);
            //         DateTime fireTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
            //         fireTime = fireTime.AddHours(dt.Hour).AddMinutes(dt.Minute);
            //         Debug.Log(fireTime);
            //         if(TimeUtils.ConvertTimestamp(fireTime) > TimeUtils.UtcNow())
            //         {
            //             fireTime = CheckFireTime(fireTime);
            //             var notification = new AndroidNotification();
            //             notification.Title = LocalizationManager.GetTranslation(tarPush.title);
            //             notification.Text = LocalizationManager.GetTranslation(tarPush.text);
            //             notification.FireTime = fireTime;
            //             var nid = AndroidNotificationCenter.SendNotification(notification, ActivityChannel);
            //             notificationIdList.Add(new Tuple<int, TimingMessageConfigModel>(nid, tarPush));
            //             break;
            //         }
            //     }
            //     
            // }
        }

        private DateTime CheckFireTime(DateTime dt)
        {
            if (dt.Hour < 9)
            {
                DateTime fireTime = new DateTime(dt.Year, dt.Month, dt.Day);
                return fireTime.AddHours(9);
            }
            else if (dt.Hour > 19)
            {
                DateTime fireTime = new DateTime(dt.Year, dt.Month, dt.Day);
                return fireTime.AddDays(1).AddHours(9);
            }

            return dt;
        }
    }
}