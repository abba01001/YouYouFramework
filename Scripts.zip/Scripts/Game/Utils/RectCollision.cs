using System;
using System.Collections.Generic;
using UnityEngine;

namespace SoliUtils
{
    public class CardBox
    {
        public float left;
        public float top;
        public float width;
        public float height;
        public float angle;
    }

    public class RectCollision
    {
        // 绕原点逆时针旋转后的点坐标, 默认绕原点旋转
        private Vector2 Rotate(float x, float y, float deg, Vector2 origin)
        {
            var newx = (x - origin.x) * Math.Cos(deg) + (y - origin.y) * Math.Sin(deg) + origin.x;
            var newy = (origin.x - x) * Math.Sin(deg) + (y - origin.y) * Math.Cos(deg) + origin.y;
            return new Vector2((float)newx, (float)newy);
        }

        private float ToDeg(float angle)
        {
            return (float)(angle / 180 * Math.PI);
        }

        private Vector2 GetCenterPoint(CardBox box)
        {
            return new Vector2(box.left + box.width / 2, box.top + box.height / 2);
        }

        //转化为顶点坐标数组
        private Vector2[] ToRect(CardBox box)
        {
            var deg = ToDeg(box.angle);
            var cp = GetCenterPoint(box);
            var a = Rotate(box.left, box.top, deg, cp);
            var b = Rotate(box.left + box.width, box.top, deg, cp);
            var c = Rotate(box.left + box.width, box.top + box.height, deg, cp);
            var d = Rotate(box.left, box.top + box.height, deg, cp);
            List<Vector2> list = new List<Vector2>();
            list.Add(a);
            list.Add(b);
            list.Add(c);
            list.Add(d);
            return list.ToArray();
        }

        /**
     * 计算投影半径
     * @param {Array(Number)} checkAxis 检测轴 [cosθ,sinθ]
     * @param {Array} axis 目标轴 [x,y]
     */
        private float GetProjectionRadius(float[] checkAxis, float[] axis)
        {
            return Math.Abs(axis[0] * checkAxis[0] + axis[1] * checkAxis[1]);
        }

        private bool isCover(float checkAxisRadius, float deg, float[] targetAxis1, float[] targetAxis2)
        {
            // var checkAxis = new[] { (float)Math.Cos(deg), (float)Math.Sin(deg)};
            // var targetAxisRadius = (GetProjectionRadius(checkAxis, targetAxis1) + GetProjectionRadius(checkAxis, targetAxis2)) / 2;
            // var centerPointRadius = GetProjectionRadius(checkAxis, vp1p2);
            // return checkAxisRadius + targetAxisRadius > centerPointRadius;
            return false;
        }

        /**
     * 判断是否碰撞
     * @param {Array} rect1 矩形顶点坐标数组 [Pa,Pb,Pc,Pd]
     * @param {*} rect2 
     */
        public bool IsCollision(CardBox box1, CardBox box2)
        {
            var rect1 = ToRect(box1);
            var rect2 = ToRect(box2);
            var p1 = GetCenterPoint(box1);
            var p2 = GetCenterPoint(box2);

            var vp1p2 = p2 - p1;
            var ab1 = rect1[1] - rect1[0];
            var bc1 = rect1[2] - rect1[1];
            var ab2 = rect2[1] - rect2[0];
            var bc2 = rect2[2] - rect2[1];

            var deg11 = ToDeg(box1.angle);
            var deg12 = ToDeg(90 - box1.angle);
            var deg21 = ToDeg(box2.angle);
            var deg22 = ToDeg(90 - box2.angle);


            return false;
        }
    }
}