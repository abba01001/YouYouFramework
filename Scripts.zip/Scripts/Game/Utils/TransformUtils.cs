using UnityEngine;

namespace SoliUtils
{
    public class TransformUtils
    {
        public static Rect GetUIRect2(RectTransform transform, Canvas canvas)
        {
            Vector3[] WorldCorners = new Vector3[4];
            transform.GetWorldCorners(WorldCorners);
            Bounds bounds = new Bounds(WorldCorners[0], Vector3.zero);
            for (int i = 1; i < 4; ++i)
            {
                bounds.Encapsulate(WorldCorners[i]);
            }

            var min = bounds.min; // LeftBottom
            var worldLeftTop = new Vector3(min.x, min.y + bounds.size.y, min.z);
            var worldRightBottom = new Vector3(min.x + bounds.size.x, min.y, min.z);
            var toPosition = new Vector4(worldRightBottom.x, worldRightBottom.y, worldRightBottom.z, 1.0f);
            var fromPosition = new Vector4(worldLeftTop.x, worldLeftTop.y, worldLeftTop.z, 1.0f);

            if (canvas.renderMode == RenderMode.WorldSpace ||
                canvas.renderMode == RenderMode.ScreenSpaceCamera)
            {
                var toPositionSp = Camera.main.WorldToScreenPoint(toPosition);
                var fromPositionSp = Camera.main.WorldToScreenPoint(fromPosition);
            }
            else if (canvas.renderMode == RenderMode.ScreenSpaceOverlay)
            {
                var toPositionSp = toPosition;
                var fromPositionSp = fromPosition;
            }

            // Debug.DrawLine(fromPosition, toPosition, Color.red);

            var width = toPosition.x - fromPosition.x;
            var height = fromPosition.y - toPosition.y;
            var x = fromPosition.x + width / 2;
            var y = toPosition.y + height / 2;
            return new Rect(x, y, width, height);
        }

        public static Rect GetUIRect(RectTransform rectTransform, Canvas canvas = null)
        {
            // 获取四个世界空间中的角点
            Vector3[] worldCorners = new Vector3[4];
            rectTransform.GetWorldCorners(worldCorners);

            // 转换为屏幕坐标
            Vector3 screenPos1 = RectTransformUtility.WorldToScreenPoint(Camera.main, worldCorners[0]);
            Vector3 screenPos2 = RectTransformUtility.WorldToScreenPoint(Camera.main, worldCorners[2]);

            // 计算宽度和高度
            float width = screenPos2.x - screenPos1.x;
            float height = screenPos2.y - screenPos1.y;

            float x = screenPos1.x + width / 2;
            float y = screenPos1.y + height / 2;

            // 返回屏幕坐标系下的 Rect
            return new Rect(x, y, width, height);
        }
    }
}
