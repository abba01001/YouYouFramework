using System;
using System.Collections.Generic;
using QFramework;
using UniRx;
using UnityEngine;
using SoliUtils;

public class HoldMono : MonoBehaviour
{
    private int openAppTime;
    private IDataService dataService;
    private IStorageService storageService;
    private int requestObsUrlTime = 0;
    private int now_time;
    private void Awake()
    {
        DontDestroyOnLoad(gameObject);
        DeviceUtils.GetLocationInfo(province =>
        {
            // Debug.Log($"HoldMono====== province {province}");
        });

        requestObsUrlTime = TimeUtils.UtcNow();
    }

    void Start()
    {
        Application.logMessageReceived += HandleException;
        Application.logMessageReceivedThreaded += HandleExceptionThreaded;
        Application.targetFrameRate = 60;

        dataService = MainContainer.Container.Resolve<IDataService>();
        storageService = MainContainer.Container.Resolve<IStorageService>();
        openAppTime = TimeUtils.UtcNow();

#if UNITY_EDITOR
        Debug.unityLogger.logEnabled = true;
#else
        var env = DeviceUtils.GetEnvVersion();
        Debug.unityLogger.logEnabled = env != "release";
#endif
    }

    // void Update()
    // {
    //     now_time = TimeUtils.UtcNow();
    //     if(now_time > requestObsUrlTime + 1200)
    //     {
    //         requestObsUrlTime = now_time;
    //         HuaweiCloudUtils.RequestObsUrl(20);
    //     }
    // }

    void HandleException(string condition, string stackTrace, LogType type)
    {
        if (type == LogType.Exception)
        {
            Debug.Log($"HoldMono, HandleException condition = {condition}, stackTrace = {stackTrace}");
            DebugUtils.ReportError(condition, stackTrace);
        }
    }

    void HandleExceptionThreaded(string condition, string stackTrace, LogType type)
    {
        if (type == LogType.Exception)
        {
            Debug.Log($"HoldMono, HandleExceptionThreaded condition = {condition}, stackTrace = {stackTrace}");
            DebugUtils.ReportError(condition, stackTrace);
        }
    }

    void OnWxShow()
    {
        if (string.IsNullOrEmpty(dataService.UserId))
            return;
        dataService.LastQuitTime = TimeUtils.UtcNow();
        AnalyticUtils.ReportUser_Add(AnalyticsKey.AppFullLifeTime, Math.Max(TimeUtils.UtcNow() - openAppTime, 0));
        PayUtils.OnWxShow();
    }

    void OnWxHide()
    {
        if (string.IsNullOrEmpty(dataService.UserId))
            return;
        openAppTime = TimeUtils.UtcNow();
        dataService.SaveData(true, true);
        PayUtils.OnWxHide();
        AnalyticUtils.ReportUser_Set(AnalyticsKey.LastLoginTime, TimeUtils.UtcNow());
    }

    void OnApplicationPause(bool paused)
    {
        if (dataService == null || string.IsNullOrEmpty(dataService.UserId))
            return;
        if (paused)
        {
            dataService.LastQuitTime = TimeUtils.UtcNow();
            AnalyticUtils.ReportUser_Add(AnalyticsKey.AppFullLifeTime, Math.Max(TimeUtils.UtcNow() - openAppTime, 0));
            storageService.SaveData();
        }
        else
        {
            openAppTime = TimeUtils.UtcNow();
        }
    }

    void OnApplicationQuit()
    {
        if (string.IsNullOrEmpty(dataService.UserId))
            return;
        dataService.LastQuitTime = TimeUtils.UtcNow();
        GameController.Instance.OnApplicationQuitEvent();
        AnalyticUtils.ReportUser_Add(AnalyticsKey.AppFullLifeTime, Math.Max(TimeUtils.UtcNow() - openAppTime, 0));
        storageService.SaveData();
    }

    void OnQySdkLogin(string json)
    {
        Debug.Log($"HoldMono.OnQySdkLogin, json:{json}");
        //{"status":1,"msg":"success","data":{"user_id":"26224760","user_name":"je81604553gf","session_id":"tjm7c84mvbqhuddli5af0766i3","open_id":"oF_HF5B6wgtV8MF0D6wS1ymFoHWw","sign":"1fc9abf23f8f831801fc4246fb0b1f69","support_subscribe":[]}}
        try
        {
            var jsonData = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
            if (jsonData != null)
            {
                Debug.Log($"HoldMono.OnQySdkLogin, GameCommon.IsRemoteUser = true");
                object value;
                jsonData.TryGetValue("status", out value);
                if (value != null)
                {
                    var status = Convert.ToInt32(value);
                    if (status == 1)
                    {
                        jsonData.TryGetValue("data", out value);
                        if (value != null)
                        {
                            GameCommon.IsRemoteUser = true;
                            var data = (Dictionary<string, object>)value;
                            data.TryGetValue("user_id", out value);
                            if (value != null)
                            {
                                WeChatMiniGame.UserId = value.ToString();
                            }
                            data.TryGetValue("user_name", out value);
                            if (value != null)
                            {
                                WeChatMiniGame.UserName = value.ToString();
                            }
                            data.TryGetValue("open_id", out value);
                            if (value != null)
                            {
                                WeChatMiniGame.OpenId = value.ToString();
                            }
                            HuaweiCloudUtils.RequestObsUrl();
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            Debug.Log($"HoldMono, OnQySdkLogin {e.ToString()}");
        }

        if (!GameCommon.IsRemoteUser)
        {
            //登录失败 重新发起登录
            WeChatMiniGame.InitQySdk();
        }
    }

    void OnQySdkRewardAd(string place_id)
    {
        AdPlayer.OnRewardAd(place_id);
    }

    void OnReadUserData(string json)
    {
        Debug.Log($"HoldMono, OnReadUserData {json}");
        // var dataService = MainContainer.Container.Resolve<IDataService>();
        // dataService.ReadLocalData();
        // if (!string.IsNullOrEmpty(json))
        // {
        //     var gameData = (Dictionary<string, object>)MiniJSON.Json.Deserialize(json);
        //     if (gameData != null)
        //     {
        //         dataService.ReadGameData(gameData);
        //     }
        // }
        // GameCommon.IsRemoteData = true;
    }

    void OnWriteUserData(string res)
    {
        Debug.Log($"HoldMono, OnWriteUserData {res}");
        WeChatMiniGame.LockWriteOpt = false;
    }

    void OnRankingData(string res)
    {
        Debug.Log($"HoldMono, OnRankingData {res}");
        TypeEventSystem.Send<LevelRankingEvent>(new LevelRankingEvent() { data = res });
    }

    //TODO 分享回调
    void WxShare()
    {

    }

    void OnPaid()
    {
        Debug.Log("HoldMono, OnPaid");
        PayUtils.CheckOrder();
    }

    // void Update()
    // {
    //     if(Input.GetKeyDown(KeyCode.U))
    //     {
    //         GameObjManager.Instance.test();
    //     }
    // }
}