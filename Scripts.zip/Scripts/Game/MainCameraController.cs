
using QFramework;
using UnityEngine;

public class MainCameraController : MonoBehaviour
{
    private Camera camera;
    void Start()
    {
        TypeEventSystem.Register<MainCamerOrthographicSizeEvent>(OnMainCamerOrthographicSizeEvent);
        TypeEventSystem.Register<MainCamerResetEvent>(OnMainCamerResetEvent);
        
        camera = GetComponent<Camera>();
        OnMainCamerResetEvent();
    }

    void OnMainCamerOrthographicSizeEvent(MainCamerOrthographicSizeEvent e)
    {
        camera.orthographicSize = e.orthographicSize;
    }

    void OnMainCamerResetEvent(MainCamerResetEvent e = null)
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        camera.transform.position = new Vector3(dataService.CameraRecord.x, dataService.CameraRecord.y, -1000);
        camera.orthographicSize = dataService.CameraRecord.z;
    }

    void OnDestroy()
    {
        TypeEventSystem.UnRegister<MainCamerOrthographicSizeEvent>(OnMainCamerOrthographicSizeEvent);
        TypeEventSystem.UnRegister<MainCamerResetEvent>(OnMainCamerResetEvent);
    }
}
