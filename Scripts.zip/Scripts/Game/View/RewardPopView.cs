using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using System;
using Activities;
using Coffee.UIExtensions;
using Doozy.Engine;
using UniRx;
using SoliUtils;
using Model;
using QFramework;
using UnityEngine.Rendering;

public class RewardPopView : ViewBase
{
    public class RewardInfo
    {
        public Action endCall;
        public PropChangeWay changeWay;
        public Dictionary<int, int> rewardDic;
        public string title;
        public ActivityType acType = ActivityType.none;
        public object[] param;
    }

    private GameObject rewardItem;
    private GameObject bubbleItem;
    private Transform itemRoot;
    private Button closeBtn;
    private Text titleText;
    private GameObject fakeStart;
    private Vector2 size = new Vector2(130, 130);

    private GameObject Top_title;
    private GameObject Activity_title;
    private Image activityImage;
    private Text activityTitle;
    private Text activityTip;
    private Text activityRank;
    private bool isShowingReward = false;
    private Queue<RewardInfo> infoQueue;
    private string rewardTitle = "恭喜你获得奖励!";
    private Vector3 flyEndPos = default;
    private Dictionary<int, int> BubbleItemRewards;
    [SerializeField] private Image startbtnImage;
    [SerializeField] private GameObject endlessIcon;
    [SerializeField] private Text lvText;
    [SerializeField] private Text lvTitleText;
    protected override void OnAwake()
    {
        infoQueue = new Queue<RewardInfo>();
        rewardItem = transform.Find("Container/RewardItem").gameObject;
        bubbleItem = transform.Find("Container/BubbleItem").gameObject;
        itemRoot = transform.Find("Container/ItemRoot");
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        fakeStart = transform.Get<Transform>("Container/FakeStart").gameObject;
        titleText = transform.Get<Text>("Container/Top_title/Image/Text");
        Top_title = transform.Find("Container/Top_title").gameObject;

        Activity_title = transform.Find("Container/Activity_title").gameObject;
        activityImage = transform.Get<Image>("Container/Activity_title/Image");
        activityTitle = transform.Get<Text>("Container/Activity_title/Title");
        activityTip = transform.Get<Text>("Container/Activity_title/Tip");
        activityRank = transform.Get<Text>("Container/Activity_title/Rank");
        flyEndPos = fakeStart.transform.position;
        transform.Get<Transform>("Overlay").localScale = new Vector3(0, 0, -300);
        rewardItem.SetActive(false);
        bubbleItem.SetActive(false);
    }

    public void RefreshBtn()
    {
        var isOpenEndlessLevel = ActivityManager.Instance.EndlessLevelActivity.IsOpenActivity();
        lvText.text = $"{dataService.NowViewMaxLayer}";
        lvTitleText.text = isOpenEndlessLevel ? "回合" : "关卡";
        startbtnImage.SetSpriteByAtlas(Constants.AtlasNamePath.ViewHomeAtlas,isOpenEndlessLevel ? "syrk_endless_level" : $"syrk_level_{GameUtils.GetLevelHard()}", true);
        endlessIcon.SetActive(isOpenEndlessLevel);
        foreach (var uiShadow in lvText.GetComponents<UIShadow>())
        {
            uiShadow.effectColor = isOpenEndlessLevel ? new Color(0.07450981f, 0.03529412f, 0.03529412f) : new Color(0.1490196f, 0.4627451f, 0.05490196f);
        }
        foreach (var uiShadow in lvTitleText.GetComponents<UIShadow>())
        {
            uiShadow.effectColor = isOpenEndlessLevel ? new Color(0.07450981f, 0.03529412f, 0.03529412f) : new Color(0.1490196f, 0.4627451f, 0.05490196f);
        }
    }
    
    public void SetActivityData(RewardInfo info)
    {
        ActivityType activityType = info.acType;
        if (activityType == ActivityType.wheel)
        {
            Top_title.SetActive(false);
            Activity_title.SetActive(false);
            return;
        }
        Top_title.SetActive(true);
        Activity_title.SetActive(false);
        if (activityType == ActivityType.none) return;

        string key = "";
        string spriteName = "";
        string title = "";
        string tip = "";
        string rank = "";
        Color color = Color.white;
        if(activityType == ActivityType.collectFlower)
        {
            key = Constants.AtlasNamePath.ViewCollectFlowerAtlas;
            spriteName = "hdxh_1";
            title = $"{(string)info.param[1]}";
            tip = $"收集鲜花奖励";
            rank = $"排名:{(int)info.param[0]}";
            color = new Color(213f / 255f, 71f / 255f, 136f / 255f, 1f);
        }
        else if(activityType == ActivityType.passRank)
        {
            key = Constants.AtlasNamePath.ViewPassRankAtlas;
            spriteName = "hdjb_1";
            title = $"{(string)info.param[1]}";
            tip = "奖杯锦标赛已结束";
            rank = $"排名:{(int)info.param[0]}";
            color = new Color(165f / 255f, 116f / 255f, 243f / 255f, 1f);
        }
        else
        {
            return;
        }
        Top_title.SetActive(false);
        Activity_title.SetActive(true);
        activityImage.SetSpriteByAtlas(key, spriteName, true);
        activityTitle.text = title;
        activityTip.text = tip;
        activityTip.color = color;
        activityRank.text = rank;

    }

    protected override void OnShow()
    {
        closeBtn.interactable = false;
        fakeStart.gameObject.SetActive(false);
        SoundPlayer.Instance.PlayMainSound("ShowFx");
        RefreshBtn();
    }

    public void InsertReward(Dictionary<int, int> rewardDic, Action endCall,
        PropChangeWay changeWay, string title,ActivityType activityType,object[] param)
    {
        RewardInfo newInfo = new RewardInfo()
        {
            rewardDic = rewardDic,
            endCall = endCall,
            changeWay = changeWay,
            title = title,
            acType = activityType,
            param = param
        };
        infoQueue.Enqueue(newInfo);
        ShowReward();
    }

    private void InstantiateBubbleItem(Sequence seq,ref Dictionary<int,int> rewards,Dictionary<string,Dictionary<int, Transform>> propTransDic,ref int index)
    {
        if (dataService.RecordBubbleItem != null)
        {
            BubbleItemRewards = new Dictionary<int, int>(dataService.RecordBubbleItem);
            foreach (var pair in BubbleItemRewards)
            {
                if (rewards.ContainsKey(pair.Key))
                {
                    rewards[pair.Key] -= pair.Value;
                    if (rewards[pair.Key] == 0) rewards.Remove(pair.Key);
                }
            }
            InitBubbleItems(seq, BubbleItemRewards, propTransDic, ref index);
            dataService.RecordBubbleItem = null;
        }
    }

    void HandleEfLayer(Transform rewardItem)
    {
        foreach (var t in rewardItem.GetComponentsInChildren<SortingGroup>(true))
        {
            t.sortingLayerName = "UI";
            t.sortingOrder = SortingOrder + 1;
        }
    }
    
    private void InitBubbleItems(Sequence seq,Dictionary<int, int> rewardDic,Dictionary<string,Dictionary<int, Transform>> propTransDic,ref int index)
    {
        Dictionary<int, Transform> transDic = new Dictionary<int, Transform>();

        foreach (var pair in rewardDic)
        {
            Transform newTrans = GameObjManager.Instance.PopGameObject(GameObjType.BubbleRewardItem, bubbleItem).transform;
            newTrans.SetParent(itemRoot);
            newTrans.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            newTrans.GetComponent<CanvasGroup>().alpha = 1;
            GameObject showFxGo = newTrans.Find("ShowFx").gameObject;
            newTrans.Get<Canvas>("PropItem").sortingOrder = SortingOrder + 2;
            HandleEfLayer(newTrans);

            showFxGo.SetActive(false);
            newTrans.gameObject.SetActive(true);
            newTrans.localScale = Vector3.zero;
            float startTime = 0.8f + 0.2f * index;
            seq.InsertCallback(startTime, () =>
            {
                newTrans.Get<Transform>("BG/tx_show_02").localScale = Vector3.one;
                showFxGo.SetActive(true);
                SoundPlayer.Instance.PlayFriendSkill();
            });
            seq.Insert(startTime + 0.2f, newTrans.DOScale(Vector3.one * 1.5f, 0.2f));
            var icon = newTrans.Get<Image>("PropItem/PropImage");
            GameUtils.LoadPropSprite(icon,pair.Key);
            newTrans.Get<Text>("PropItem/NumText").text = GameUtils.GetItemCountText(pair.Key, pair.Value);
            transDic.Add((int) pair.Key, newTrans);
            index++;
        }
        propTransDic.Add("bubble",transDic);
    }

    private void InstantiateNormalItem(Sequence seq,Dictionary<int, int> rewardDic,Dictionary<string,Dictionary<int, Transform>> propTransDic,ref int index)
    {
        Dictionary<int, Transform> transDic = new Dictionary<int, Transform>();
        foreach (var pair in rewardDic)
        {
            Transform newTrans = GameObjManager.Instance.PopGameObject(GameObjType.RewardItem, rewardItem).transform;
            newTrans.SetParent(itemRoot);
            newTrans.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            newTrans.GetComponent<CanvasGroup>().alpha = 1;
            GameObject showFxGo = newTrans.Find("ShowFx").gameObject;
            newTrans.Get<Canvas>("PropItem").sortingOrder = SortingOrder + 2;
            HandleEfLayer(newTrans);

            showFxGo.SetActive(false);
            newTrans.gameObject.SetActive(true);
            newTrans.localScale = Vector3.zero;
            float startTime = 0.8f + 0.2f * index;
            seq.InsertCallback(startTime, () =>
            {
                newTrans.Get<Transform>("BG/tx_show_02").localScale = Vector3.one;
                showFxGo.SetActive(true);
                SoundPlayer.Instance.PlayFriendSkill();
            });
            seq.Insert(startTime + 0.2f, newTrans.DOScale(Vector3.one * 1.5f, 0.2f));
            transDic.Add((int) pair.Key, newTrans);
            var icon = newTrans.Get<Image>("PropItem/PropImage");
            GameUtils.LoadPropSprite(icon,pair.Key);
            newTrans.Get<Text>("PropItem/NumText").text = GameUtils.GetItemCountText(pair.Key, pair.Value);
            index++;
        }
        propTransDic.Add("normal",transDic);
    }

    private void CloseFunc()
    {
        dataService.RecordBubbleItem = null;
        BoxBuilder.HidePopup(gameObject);
    }
    
    private void ShowReward()
    {
        if (isShowingReward) return;
        isShowingReward = true;
        closeBtn.interactable = false;
        RewardInfo nowInfo = infoQueue.Dequeue();
        var rewardDic = nowInfo.rewardDic;
        if(rewardDic.Count <= 0)
        {
            nowInfo.endCall?.Invoke();
            isShowingReward = false;
            if (infoQueue.Count <= 0)
            {
                CloseFunc();
            }
            else
                ShowReward();
            return;
        }

        int count = rewardDic.Count;
        var size = itemRoot.GetComponent<RectTransform>().sizeDelta;
        if(count <= 5)
        {
            size.x = 1000;
        }
        else if(count == 6)
        {
            size.x = 610;
        }
        else if(count == 7 || count == 8)
        {
            size.x = 860;
        }
        else if(count == 9 || count == 10)
        {
            size.x = 950;
        }
        else
        {
            size.x = 1300;
        }
        itemRoot.GetComponent<RectTransform>().sizeDelta = size;

        Dictionary<string,Dictionary<int, Transform>> propTransDic = new Dictionary<string,Dictionary<int, Transform>>(rewardDic.Count);
        SetActivityData(nowInfo);

        int index = 0;
        Sequence seq = DOTween.Sequence();
        InstantiateBubbleItem(seq,ref rewardDic,propTransDic,ref index);
        InstantiateNormalItem(seq,rewardDic,propTransDic,ref index);

        seq.OnComplete(() =>
        {
            closeBtn.interactable = true;
            closeBtn.GetComponent<CanvasGroup>().alpha = 1;
        });

        closeBtn.SetButtonClick(() =>
        {
            GameCommon.IsPlayingCollectAnim = false;
            int propIndex = 0;
            closeBtn.interactable = false;
            closeBtn.GetComponent<CanvasGroup>().DOFade(0, 0.2f);
            if (!(rewardDic.Count == 1 && rewardDic.ContainsKey((int)PropEnum.Coin)) || BubbleItemRewards != null)
            {
                fakeStart.gameObject.SetActive(true);
            }
            bool playGetSound = false;

            foreach (var info in propTransDic)
            {
                Dictionary<int, Transform> dic = new Dictionary<int, Transform>();
                Dictionary<int, int> rewards = new Dictionary<int, int>();
                if (info.Key == "normal")
                {
                    dic = info.Value;
                    rewards = rewardDic;
                }
                else if (info.Key == "bubble")
                {
                    dic = info.Value;
                    rewards = new Dictionary<int, int>(BubbleItemRewards);
                    BubbleItemRewards = null;
                }

                if (dic.Count > 0 && rewards.Count > 0)
                {
                    foreach (var item in rewards)
                    {
                        Transform propTrans = dic[item.Key];
                        propTrans.GetComponent<CanvasGroup>().DOFade(0, 0.5f);
                        propTrans.Get<Transform>("BG/tx_show_02").DOScale(Vector3.zero, 0.5f);
                        propTrans.DOScale(Vector3.one * 0.4f, 0.5f).SetEase(Ease.InCubic);
                        if (item.Key == (int) PropEnum.Coin)
                        {
                            GameUtils.PlayGoldAnim(transform, (int)(dataService.Coin - item.Value),(int)dataService.Coin, propTrans.Get<Transform>("PropItem"),null);
                        }
                        else
                        {
                            Vector3 beginPos = propTrans.position;
                            GameObject newImage = new GameObject(item.Key.ToString(), typeof(RectTransform));
                            newImage.transform.SetParent(transform, false);
                            newImage.transform.position = beginPos;
                            newImage.AddComponent<Image>().LoadPropSprite(item.Key, false);
                            bool isLeft = beginPos.x > flyEndPos.x;
                            Vector3 controlPos = (flyEndPos + beginPos) / 2 +
                                                 (isLeft ? new Vector3(-150, 500, 0) : new Vector3(150, 500, 0));
                            newImage.transform
                                .DOPath(BezierUtils.GetBeizerList(beginPos, controlPos, flyEndPos, 10),
                                    0.8f + 0.2f * (rewardDic.Count - propIndex), PathType.CatmullRom,
                                    gizmoColor: Color.red)
                                .SetEase(Ease.InQuad).OnComplete(() =>
                                {
                                    newImage.SetActive(false);
                                    GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/daoju_anniu_tx_02.prefab",
                                        (daojuFxTrans) =>
                                        {
                                            daojuFxTrans.transform.position = fakeStart.transform.position;
                                        }, true, 2f);
                                });
                            newImage.transform.DOScale(Vector3.one * 1.2f, 0.4f);
                            newImage.transform.DOScale(Vector3.one * 0.7f, 0.4f).SetDelay(0.4f + 0.2f * propIndex);
                            if (!playGetSound)
                            {
                                playGetSound = true;
                                SoundPlayer.Instance.PlayMainSound("daoju_anniu_tx_01(Clone)");
                            }
                        }
                        propIndex++;
                    }
                }
            }

            Observable.Timer(TimeSpan.FromSeconds(0.8f)).Subscribe(_ => {itemRoot.DestroyAllChildren();});
            float time = 0.8f + 0.2f * rewardDic.Count;
            Observable.Timer(TimeSpan.FromSeconds(Mathf.Max(time,2))).Subscribe(_ =>
            {
                nowInfo.endCall?.Invoke();
                isShowingReward = false;
                if (infoQueue.Count <= 0)
                {
                    CloseFunc();
                }
                else
                {
                    Observable.NextFrame().Subscribe(_ => ShowReward());
                }
                TypeEventSystem.Send<GameUpdateItemEvent>();
            });
        });
        if (nowInfo.acType != ActivityType.none )
        {
            ActivityDataModel model = ActivityManager.Instance.GetActivityByType(nowInfo.acType);
            if (model != null && model.RewardTitle != "")
            {
                rewardTitle = model.RewardTitle;
            }
        }
        titleText.text = rewardTitle;
    }
}
