﻿using Doozy.Engine;
using Doozy.Engine.UI;
using Doozy.Engine.UI.Animation;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;
using DG.Tweening;

public class ViewQueueManager : MonoBehaviour, ISingleton
{
    [Serializable]
    private class ViewQueueParamBase
    {
        public bool isWaitting = false;
        public bool canTouch = true;
        public bool isPopup = false;
        public string popupName = "";
        public string viewName = "";
        public string evetName = "";
        public int paramId = -1;
    }
    private class WaitTime : ViewQueueParamBase
    {
        public float time;
        public Action action;
        public Action endAction;
    }
    private class WaitViewClose : ViewQueueParamBase
    {
        public string doozyEventName;
        public string viewNameOnClose;
    }
    private class WaitEventName : ViewQueueParamBase
    {
        public string doozyEventName;
        public string closeDoozyEventName;
    }
    private class WaitPopupViewClose : ViewQueueParamBase
    {
        public Action openAction;
        public string popupViewName;
    }
    private class SequenceEnd : ViewQueueParamBase
    {
        public Func<Tween> tweenCall;
    }
    public static ViewQueueManager Instance
    {
        get { return MonoSingletonProperty<ViewQueueManager>.Instance; }
    }

    //private Graph nowGraph;
    private ViewQueueParamBase nowParamBase;
    [SerializeField] private List<ViewQueueParamBase> doozyList = new List<ViewQueueParamBase>();


    public void OnSingletonInit()
    {
    }

    public void Init()
    {
        //nowGraph = GameObject.FindObjectOfType<GraphController>().Graph;
        UIView.OnUIViewAction += OnUIViewAction;
        UIPopup.OnUIPopupAction += OnUIPopupAction;
        Message.AddListener<GameEventMessage>(OnDoozyEventMessage);
    }

    private void OnDoozyEventMessage(GameEventMessage eventMessage)
    {
        if (nowParamBase != null && nowParamBase is WaitEventName waitEventParam)
        {
            if (waitEventParam.closeDoozyEventName == eventMessage.EventName)
                TurnToNextParam();
        }
    }

    private void OnUIViewAction(UIView view, UIViewBehaviorType behaviorType)
    {
        if (behaviorType == UIViewBehaviorType.Hide && nowParamBase != null)
        {
            WaitViewClose viewCloseParam = nowParamBase as WaitViewClose;
            if (viewCloseParam != null && viewCloseParam.viewNameOnClose == view.ViewName)
                TurnToNextParam();
        }
    }

    private void OnUIPopupAction(UIPopup popView, AnimationType behaviorType)
    {
        if (behaviorType == AnimationType.Hide && nowParamBase != null)
        {
            WaitPopupViewClose popupCloseParam = nowParamBase as WaitPopupViewClose;
            if (popupCloseParam != null && popupCloseParam.popupViewName == popView.PopupName)
            {
                TurnToNextParam();
            }
        }
        UIPopupEvent t = GameObjManager.Instance.PopClass<UIPopupEvent>(true);
        t.Init(popView,behaviorType);
        TypeEventSystem.Send<UIPopupEvent>(t);
    }

    private IEnumerator WaitTimeParam()
    {
        if (nowParamBase == null) yield break;
        if (!(nowParamBase is WaitTime waitTimeParam))
        {
            TurnToNextParam();
            yield break;
        }
        waitTimeParam.action?.Invoke();
        yield return new WaitForSeconds(waitTimeParam.time);
        waitTimeParam.endAction?.Invoke();
        TurnToNextParam();
    }

    public async void AddEventNameClose(string doozyEventName, string closeDoozyEventName, bool isInsert = false, bool isCanTouch = true)
    {
        ViewQueueParamBase paramBase = new WaitEventName()
        {
            doozyEventName = doozyEventName,
            closeDoozyEventName = closeDoozyEventName,
            canTouch = isCanTouch,
            evetName = doozyEventName
        };
        AddViewQueueParam(paramBase, isInsert);
    }

    public void AddWaitViewClose(string doozyEventName, string viewNameOnClose, bool isInsert = false, bool isCanTouch = true)
    {
        ViewQueueParamBase paramBase = new WaitViewClose()
        {
            doozyEventName = doozyEventName,
            viewNameOnClose = viewNameOnClose,
            canTouch = isCanTouch,
            viewName = doozyEventName
        };
        AddViewQueueParam(paramBase, isInsert);
    }

    public async void AddWaitPopupViewClose(string popupName, Action openAction, bool isInsert = false, bool isCanTouch = true)
    {
        ViewQueueParamBase paramBase = new WaitPopupViewClose() {
            popupViewName = popupName,
            openAction = openAction,
            canTouch = isCanTouch,
            isPopup = true,
            popupName = popupName
        };
        AddViewQueueParam(paramBase, isInsert);
    }

    public void AddWaitTime(float time, Action action, Action endAction = null, bool isInsert = false, bool isCanTouch = true)
    {
        ViewQueueParamBase paramBase = new WaitTime()
        {
            time = time,
            action = action,
            endAction = endAction,
            canTouch = isCanTouch,
        };
        AddViewQueueParam(paramBase, isInsert);
    }

    public void AddWaitTween(Func<Tween> tweenCall, bool isInsert = false, bool isCanTouch = true)
    {
        ViewQueueParamBase paramBase = new SequenceEnd()
        {
            tweenCall = tweenCall,
            canTouch = isCanTouch,
        };
        AddViewQueueParam(paramBase, isInsert);
    }

    public void ClearQueue()
    {
        nowParamBase = null;
        doozyList.Clear();
    }

    private int ParamID = -1;
    private void AddViewQueueParam(ViewQueueParamBase paramBase, bool isInsert)
    {
        if (CheckPopupHasAdd(paramBase)) return;
        ParamID++;
        paramBase.paramId = ParamID;
        if (isInsert)
            doozyList.Insert(nowParamBase == null ? 0 : 1, paramBase);
        else
        {
            doozyList.Add(paramBase);
        }
        if (nowParamBase == null)
            TurnToNextParam();
    }

    //Popup是否加入队列
    bool CheckPopupHasAdd(ViewQueueParamBase paramBase)
    {
        bool isAdd = false;
        if (paramBase.isPopup)
        {
            WaitPopupViewClose t = paramBase as WaitPopupViewClose;
            foreach (var pair in doozyList)
            {
                if (t.popupViewName == pair.popupName)
                {
                    if (CheckMultiplyAdd(pair.popupName)) return false;
                    return true;
                }
            }
        }
        return false;
    }

    //Popup参数能否叠加
    bool CheckMultiplyAdd(string popupName)
    {
        if (popupName == Constants.DoozyView.RewardPopup) return true;
        return false;
    }

    private void TurnToNextParam()
    {
        FxMaskView.Instance.CanTouch = true;
        if (nowParamBase != null)
            doozyList.Remove(nowParamBase);
        if (doozyList.Count > 0)
        {
            nowParamBase = doozyList[0];
            RunNowParam();
        }
        else
            nowParamBase = null;
    }
    
    private void RunNowParam()
    {
        if (nowParamBase?.isWaitting != false) return;
        nowParamBase.isWaitting = true;
        FxMaskView.Instance.CanTouch = nowParamBase.canTouch;
        switch (nowParamBase)
        {
            case WaitTime param:
                StartCoroutine(WaitTimeParam());
                break;
            case WaitViewClose param:
                UniRx.Observable.NextFrame().Subscribe(_ => GameEventMessage.SendEvent(param.doozyEventName));
                break;
            case WaitEventName param:
                UniRx.Observable.NextFrame().Subscribe(_ => GameEventMessage.SendEvent(param.doozyEventName));
                break;
            case WaitPopupViewClose param:
                param.openAction();
                break;
            case SequenceEnd param:
                Tween tween = param.tweenCall?.Invoke();
                if (tween != null)
                    tween.onComplete += TurnToNextParam;
                else
                    TurnToNextParam();
                break;
            default:
                break;
        }
    }
}
