using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Timers;
using Activities;
using DG.Tweening;
using SoliUtils;
using UniRx;

public class LavaPassRewardPopView : ViewBase
{
    [SerializeField] private Button closeBtn;
    [SerializeField] private GameObject rewardItem;
    [SerializeField] private Animator animator;
    [SerializeField] private Text Total;
    private Action finishCb;
    private int addVale = 0;
    private bool isShowingReward = false;
    private string rewardTitle = "恭喜你获得奖励!";
    private int oldGoldViewSortingOrder;
    protected override void OnAwake()
    {
        animator.enabled = false;
        rewardItem.SetActive(false);
        closeBtn.SetButtonClick(() =>
        {
            GoldView.Instance.SortingOrder = SortingOrder + 1;
            rewardItem.transform.DOScale(Vector3.zero, 0.3f).SetEase(Ease.InCubic);
            rewardItem.Get<Image>("RewardIcon").color = Color.clear;
            GameUtils.PlayGoldAnim(transform,(int)(dataService.Coin - addVale),
                (int)dataService.Coin,rewardItem.transform,null);
            Observable.Timer(TimeSpan.FromSeconds(1f)).Subscribe(_ =>
            {
                BoxBuilder.HidePopup(gameObject);
                BoxBuilder.HideLavaPassPopup();
                finishCb?.Invoke();
            });
            closeBtn.interactable = false;
        });
    }

    public void ShowReward(Dictionary<int, int> rewardDic, Action endCb, PropChangeWay changeWay)
    {
        finishCb = endCb;
        oldGoldViewSortingOrder = GoldView.Instance.SortingOrder;
        foreach (var info in rewardDic)
        {
            if (info.Key == (int)PropEnum.Coin)
            {
                rewardItem.Get<Image>("RewardIcon").LoadPropSprite((int)PropEnum.MultiplyCoin, false);
                rewardItem.Get<Text>("RewardNum").text = $"x{info.Value}";
                addVale = info.Value;
                break;
            }
        }
        Total.text = $"{ActivityManager.Instance.LavaPassActivity.GetActivityRewardCoin()}";
        SoundPlayer.Instance.PlayMainSound("LavaPass_boxmove");
        GameUtils.PlayAnimation(animator,"ani_LavaPass_Reward_01",0, () =>
        {
            transform.Get<Image>("Container/RewardIcon").color = Color.clear;
            closeBtn.interactable = true;
        },false);
    }

    protected override void OnShow()
    {
        closeBtn.interactable = false;
        SoundPlayer.Instance.PlayMainSound("ShowFx");
        GoldView.Instance.SortingOrder = oldGoldViewSortingOrder;
    }
}