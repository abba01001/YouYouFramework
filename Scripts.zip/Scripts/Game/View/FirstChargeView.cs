﻿using QFramework;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class FirstChargeView : ViewBase
{
    private Text priceText;
    private Text timeText;
    private Transform itemParent;
    private Action onCloseCall;
    [SerializeField]private List<Transform> itemList;
    [SerializeField] private Transform coinItem;
    [SerializeField] private Image Bg;
    private string productKey = "";
    protected override void OnAwake()
    {
        transform.Get<Button>("Content/CloseBtn").SetButtonClick(() => 
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
        });
        transform.Get<Button>("Content/BuyBtn").SetButtonClick(() => 
        {
            SoundPlayer.Instance.PlayButton();
            if(productKey == "") return;
            if (dataService.IsBuyBeginner) return;
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(productKey);
        });
        itemParent = transform.Get<Transform>("Content/Bg");
        priceText = transform.Get<Text>("Content/BuyBtn/Price");
    }

    protected override void OnViewInit(bool isFirst)
    {
        InitPanel();
        TypeEventSystem.Register<GameRechargeEvent>(UpdatPanel);
    }

    private void UpdatPanel(GameRechargeEvent obj)
    {
        BoxBuilder.HidePopup(gameObject);
    }
    
    protected override void OnInitedDestroy()
    {
        onCloseCall?.Invoke();
        onCloseCall = null;
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatPanel);
    }

    public void SetCloseCall(Action _onCloseCall)
    {
        onCloseCall = _onCloseCall;
    }

    protected override void OnShow()
    {
        if (!dataService.IsBuyBeginner)
        {
            if (!dataService.IsSmallBuyBeginner)
            {
                dataService.AddDailyFlag(FlagType.SmallFirstCharge);
            }
            else
            {
                dataService.AddDailyFlag(FlagType.FirstCharge);
            }
        }
    }

    private void InitPanel()
    {
        ShopModel model = null;

        if (!dataService.IsBuyBeginner)
        {
            if (!dataService.IsSmallBuyBeginner)
            {
                model = configService.ShopConfig[Constants.ProductId.SmallFirstPayment];
                Bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewFirstGiftAtlas, "sc_3");
            }
            else
            {
                model = configService.ShopConfig[Constants.ProductId.FirstPayment];
                Bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewFirstGiftAtlas, "sc_3");
            }
        }
        if (model != null)
        {
            productKey = model.product_id;
            Dictionary<int, int> reward = GameUtils.AnalysisPropString(model.reward);
            for (int i = 0; i < itemList.Count; i++)
            {
                itemList[i].gameObject.SetActive(false);
            }
            coinItem.gameObject.SetActive(false);
            int index = 0;
            foreach (var pair in reward)
            {
                if (index > itemList.Count) break;
                Transform item = pair.Key == (int)PropEnum.Coin ? coinItem : itemList[index];
                if (pair.Key != (int)PropEnum.Coin) index++;
                item.gameObject.SetActive(true);
                item.Get<Image>($"Icon").LoadPropSprite(pair.Key ==(int) PropEnum.Coin ?(int) PropEnum.MultiplyCoin : pair.Key,false);
                item.Get<Transform>($"TimeText").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
                item.Get<RectTransform>($"Icon").sizeDelta = new Vector2(145, 145);
                item.Get<Text>($"Value").text = "";
                if (pair.Key == (int)PropEnum.Coin)
                {
                    item.Get<Text>($"Value").text = $"{pair.Value}";
                }
                else if (GameUtils.IsLimitTimeReward(pair.Key))
                {
                    item.Get<Text>($"TimeText").text = $"{pair.Value / 60}m";
                }
                else
                {
                    //item.Get<RectTransform>($"Icon").sizeDelta = new Vector2(130, 130);
                    item.Get<Text>($"Value").text = $"x{pair.Value}";
                }
            }

            priceText.text = model.money.ToString();
        }
    }
}
