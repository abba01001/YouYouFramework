using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using DG.Tweening;
using System;
using UniRx;
using SoliUtils;

public class VipRewardPopView : ViewBase
{
    private GameObject rewardItem;
    private Transform itemRoot;
    private Button reciveBtn;
    private Button closeBtn;
    private RectTransform fakeStart;

    private const string daojuFx = "Assets/Res/Prefabs/FX/daoju_anniu_tx_01.prefab";
    private static Vector2 BtnShowPos = new Vector2(0, -282);
    private static Vector2 BtnHidePos = new Vector2(0, -462);

    protected override void OnAwake()
    {
        rewardItem = transform.Find("Container/RewardItem").gameObject;
        itemRoot = transform.Find("Container/Layout");
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        reciveBtn = transform.Get<Button>("Container/ReciveBtn");
        fakeStart = transform.Get<RectTransform>("Container/FakeStart");

        rewardItem.SetActive(false);
        closeBtn.SetButtonClick(() =>
        {
            reciveBtn.interactable = false;
            BoxBuilder.HidePopup(gameObject);
        });
    }

    protected override void OnShow()
    {
        closeBtn.interactable = false;
        reciveBtn.interactable = false;
        fakeStart.anchoredPosition = BtnHidePos;
        reciveBtn.GetComponent<RectTransform>().anchoredPosition = BtnShowPos;
        //SoundPlayer.Instance.PlayJokerFly();
        ShowReward();
    }

    private void ShowReward()
    {
    }
}
