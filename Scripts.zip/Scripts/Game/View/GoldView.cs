﻿using QFramework;
using System;
using UniRx;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Rendering;
using System.Collections.Generic;
using Doozy.Engine.UI;
using Doozy.Engine.UI.Animation;
using SoliUtils;
using Widgets;
using Activities;

public class GoldView : ViewBase, ISingleton
{
    private class GoldViewParam
    {
        public bool? showBuildCoinRoot = false;
        public bool? canClick = null;

        //为null时不改变层级，否则按照自身的层级进行增减
        public int? diffSortingOrder = null;

        public GoldViewParam(int? _diffSortingOrder = null, bool? _canClick = null, bool? _showBuildCoinRoot = false)
        {
            canClick = _canClick;
            diffSortingOrder = _diffSortingOrder;
            showBuildCoinRoot = _showBuildCoinRoot;
        }
    }

    private static Dictionary<string, GoldViewParam> paramDic = new Dictionary<string, GoldViewParam>()
    {
        //view部分
        { Constants.DoozyView.Game, new GoldViewParam(1, true, false) },
        { Constants.DoozyView.Home, new GoldViewParam(1, true,true) },
        { Constants.DoozyView.Language, new GoldViewParam(-1) },
        { Constants.DoozyView.Saver, new GoldViewParam(1, false) },
        //{ Constants.DoozyView.FxMask,                           new GoldViewParam() },
        //{ Constants.DoozyView.Gold,                             new GoldViewParam() },
        //{ Constants.DoozyView.Result,                           new GoldViewParam() },
        //{ Constants.DoozyView.Setting,                          new GoldViewParam() },
        //{ Constants.DoozyView.Star,                             new GoldViewParam() },

        //Popup部分
        { Constants.DoozyView.DigTreasurePopup, new GoldViewParam(-1) },
        { Constants.DoozyView.WheelPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.CheckInPopup, new GoldViewParam(1, false) },
        { Constants.DoozyView.FirstChargePopup, new GoldViewParam(-1, false) },
        { Constants.DoozyView.FlowerPopup, new GoldViewParam(1, true) },
        { Constants.DoozyView.BoxPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.LoadingPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.RewardPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.ShopPopup, new GoldViewParam(1, false) },
        { Constants.DoozyView.GradientGiftPopup, new GoldViewParam(1, false) },
        { Constants.DoozyView.SeasonPassPopup, new GoldViewParam(1, false) },
        { Constants.DoozyView.SceneChangePopup, new GoldViewParam(-1) },
        { Constants.DoozyView.GMPop, new GoldViewParam(-1) },
        { Constants.DoozyView.EndWinStreakPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.ExitGameTipPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.SolatiumPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.StartGamePopup, new GoldViewParam(1, true,false) },
        { Constants.DoozyView.StartPassRankPopup, new GoldViewParam(-1, true) },
        { Constants.DoozyView.StreakTipPopup, new GoldViewParam(-1, true) },
        { Constants.DoozyView.PassRankPopup, new GoldViewParam(-1, true) },
        { Constants.DoozyView.CollectFlowerPopup, new GoldViewParam(-1, true) },
        { Constants.DoozyView.CollectLoveCardPopup, new GoldViewParam(-1, true) },
        { Constants.DoozyView.BuyItemPopup, new GoldViewParam(1, true,false) },
        { Constants.DoozyView.DataSyncPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.DataSyncConfirmPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.SignInSuccessPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.SignOutConfirmPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.SignOutSuccessPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.UpdateTipPopView, new GoldViewParam(-1) },
        { Constants.DoozyView.CommonLoadingPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.ActivitySeasonPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.UnlockBetPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.FirstTimeSaverPopup, new GoldViewParam(-1) },
        { Constants.DoozyView.SeasonDescPopup, new GoldViewParam() },
        { Constants.DoozyView.SeasonPurchasePopup, new GoldViewParam(1, false) },
        { Constants.DoozyView.UnlockNewFeaturePopup, new GoldViewParam(-1) },
        { Constants.DoozyView.LevelRankingPopup, new GoldViewParam(-1) },
    };
    private SpreadViewHandler spreadViewHandler;
    private GameObject goldRoot;
    public GameObjectData goldRootData;
    private GameObject clickBtn;
    private Text goldText;
    private GameObject buildCoinRoot;
    private Text buildCoinText;
    private GameObject energyRoot;
    private Text energyText;
    private Image energyInfiniteSign;
    private Text energyTimeText;
    private Transform energyFullSign;
    private Button energyBtn;
    private const float HarvestCoinRollTime = 0.3f;

    public const int DefaultSortingOrder = 2;

    private Tween coinTween;
    private Tween buildCoinTween;
    private IDisposable subscription;
    public bool CanClick
    {
        get => clickBtn.activeInHierarchy;
        set => clickBtn.SetActive(value);
    }

    public bool ShowGold
    {
        get => goldRoot.activeInHierarchy;
        set => goldRoot.SetActive(value);
    }

    public static Vector3[] flyGoldPoints = new Vector3[]
    {
        new Vector3(100 * 0.1f, 100 * 1.1f, 0),
        new Vector3(0, 0, 0),
        new Vector3(100 * -0.5f, 100 * 1, 0),
        new Vector3(100 * -0.8f, 100 * -0.6f, 0),
        new Vector3(100 * 0.6f, 100 * 1.1f, 0),
        new Vector3(100 * -1.5f, 100 * 0.3f, 0),
        new Vector3(100 * -0.8f, 100 * 1.3f, 0),
        new Vector3(100 * -1.5f, 100 * 1.3f, 0),
        new Vector3(100 * 0.1f, 100 * -1, 0),
        new Vector3(100 * -0.4f, 100 * 0.1f, 0),
        new Vector3(100 * 0.7f, 100 * 0.3f, 0),
    };

    public static GoldView Instance
    {
        get { return MonoSingletonProperty<GoldView>.Instance; }
    }

    public void OnSingletonInit()
    {
    }

    public void ResetCanvasPos()
    {
        var rectTransform = GetComponent<RectTransform>();
        var offsetMin = rectTransform.offsetMin;
        var offsetMax = rectTransform.offsetMax;
        rectTransform.offsetMin = new Vector2(offsetMin.x, 0);  // left and bottom
        rectTransform.offsetMax = new Vector2(offsetMax.x, 0); // right and top
    }

    protected override void OnAwake()
    {
        spreadViewHandler = new SpreadViewHandler();
        spreadViewHandler.AddItem(transform.Get<Transform>("LayoutGroup"), SpreadViewHandler.Toward.Up);

        reportOnShow = false;
        goldRoot = transform.Find("LayoutGroup/GoldRoot").gameObject;
        goldRootData = new GameObjectData();
        goldRootData.InitViewObj(transform, goldRoot);
        clickBtn = goldRoot.transform.Find("ClickBtn").gameObject;
        goldRoot.transform.Find("ClickBtn/GoldAddImage").gameObject.SetActive(false);//GameUtils.EnableCoinShop);
        goldText = goldRoot.transform.Get<Text>("TextBG/GoldNumText");
        goldRoot.transform.Find("TextBG/CoinImage/Icon").gameObject.SetActive(!GameCommon.IsShieldPurchase);
        clickBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            if (GameCommon.IsShieldPurchase) return;
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowShopPop();
        });

        energyRoot = transform.Find("LayoutGroup/EnergyRoot").gameObject;
        energyText = energyRoot.transform.Get<Text>("TextBG/EnergyNumText");
        energyTimeText = energyRoot.transform.Get<Text>("TextBG/EnergyTimeText");
        energyInfiniteSign = energyRoot.transform.Get<Image>("TextBG/EnergyInfiniteSign");
        energyFullSign = energyRoot.transform.Find("TextBG/EnergyFullSign");
        energyBtn = energyRoot.transform.Get<Button>("ClickBtn");
        energyBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowEnergyPopup();
        });
        UIView.OnUIViewAction += OnUIViewAction;
        UIPopup.OnUIPopupAction += OnUIPopupAction;

        //迁移到view - home
        // buildCoinRoot = transform.Find("LayoutGroup/BuildCoinRoot").gameObject;
        // buildCoinRoot.SetActive(false);
        // buildCoinText = buildCoinRoot.transform.Get<Text>("TextBG/GoldNumText");
    }

    public void SetBuildCoin(GameObject obj)
    {
        buildCoinRoot = obj;
        buildCoinText = buildCoinRoot.transform.Get<Text>("TextBG/GoldNumText");
    }

    public Vector3 EndPos()
    {
        return GameUtils.GetLocalPosition(transform, goldRoot.transform, new Vector3(140, -40, 0));
    }

    private Vector3 GetFlyGoldStartPos(Transform trans)
    {
        var obj = transform.Find("GoldRoot").GetComponent<RectTransform>();
        obj.transform.position = trans.position;
        obj.GetComponent<RectTransform>().sizeDelta = trans.GetComponent<RectTransform>().sizeDelta;
        Vector2 originalAnchoredPosition = obj.anchoredPosition;
        Vector2 size = obj.rect.size;
        Vector2 currentPivot = obj.pivot;
        Vector2 newPivot = new Vector2(0.5f, 0.5f); // Middle Center
        Vector2 oldWorldPosition = obj.TransformPoint(originalAnchoredPosition);
        obj.pivot = newPivot;
        obj.anchorMin = newPivot;
        obj.anchorMax = newPivot;
        Vector2 newAnchoredPosition = obj.InverseTransformPoint(oldWorldPosition);
        Vector2 deltaPivot = newPivot - currentPivot;
        Vector3 deltaPosition = new Vector3(deltaPivot.x * size.x, deltaPivot.y * size.y);
        if (currentPivot != newPivot)
        {
            newAnchoredPosition += (Vector2)deltaPosition;
        }
        return new Vector3(newAnchoredPosition.x, newAnchoredPosition.y, 0);
    }

    private void OnUIPopupAction(UIPopup arg1, AnimationType arg2)
    {
        if (arg2 == AnimationType.Show)
            SetGoldViewParam(arg1.PopupName, arg1.GetComponent<ViewBase>());
        else if (arg2 == AnimationType.Hide)
        {
            UIPopupQueueData popupData = null;
            if (UIPopupManager.PopupQueue.Count > 1)
            {
                for (int i = UIPopupManager.PopupQueue.Count - 1; i >= 0; i--)
                {
                    if (UIPopupManager.PopupQueue[i].PopupName != arg1.PopupName)
                    {
                        popupData = UIPopupManager.PopupQueue[i];
                        break;
                    }
                }
            }

            if (popupData != null)
                SetGoldViewParam(popupData.PopupName, popupData.Popup.GetComponent<ViewBase>());
            else
            {
                foreach (var view in UIView.VisibleViews)
                    SetGoldViewParam(view.ViewName, view.GetComponent<ViewBase>());
            }
        }
    }

    private void OnUIViewAction(UIView arg1, UIViewBehaviorType arg2)
    {
        if (arg2 == UIViewBehaviorType.Show)
            SetGoldViewParam(arg1.ViewName, arg1.GetComponent<ViewBase>());
        else if (arg2 == UIViewBehaviorType.Hide)
        {
            foreach (var view in UIView.VisibleViews)
                SetGoldViewParam(view.ViewName, view.GetComponent<ViewBase>());
        }
    }

    protected override void OnViewInit(bool isFirst)
    {
        goldText.text = dataService.Coin.ToString();
        //buildCoinText.text = dataService.BuildCoin.ToString();
        energyText.text = dataService.Energy.ToString();
        UpdateEnergyRoot();
        if (isFirst == false) return;
        TypeEventSystem.Register<RefreshUserInfoCoin>(OnCoinChange);
        TypeEventSystem.Register<RefreshUserInfoBuildCoin>(OnBuildCoinChange);
        TypeEventSystem.Register<FlowAddEvent>(OnFlowAddEvent);
        TypeEventSystem.Register<CollectFarmingCoin>(OnCollectFarmingCoin);
        TypeEventSystem.Register<RefreshUserInfoEnergy>(OnEnergyChange);
        TypeEventSystem.Register<TogglePopupEvent>(OnTogglePopup);
        subscription = UniRx.Observable.Interval(TimeSpan.FromSeconds(1)).Subscribe(_ =>
        {
            UpdateEnergyRoot();
        });
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<RefreshUserInfoCoin>(OnCoinChange);
        TypeEventSystem.UnRegister<RefreshUserInfoBuildCoin>(OnBuildCoinChange);
        TypeEventSystem.UnRegister<FlowAddEvent>(OnFlowAddEvent);
        TypeEventSystem.UnRegister<CollectFarmingCoin>(OnCollectFarmingCoin);
        TypeEventSystem.UnRegister<RefreshUserInfoEnergy>(OnEnergyChange);
        TypeEventSystem.UnRegister<TogglePopupEvent>(OnTogglePopup);
        subscription?.Dispose();
    }

    protected override void OnShow()
    {
        goldText.text = dataService.Coin.ToString();
        //buildCoinText.text = dataService.BuildCoin.ToString();
        energyText.text = dataService.Energy.ToString();
        CheckUnock();
    }

    private void OnFlowAddEvent(FlowAddEvent obj)
    {
        UniRx.Observable.Timer(TimeSpan.FromSeconds(obj.delayTime)).Subscribe(_ =>
        {
            Transform flowAddTrans = GameObjManager.Instance.PopGameObject(GameObjType.FlowAddGold).transform;
            flowAddTrans.gameObject.SetActive(true);
            flowAddTrans.SetParent(transform, false);
            string addStr = $"+{obj.num}";
            if (obj.num == 0) addStr = "";
            flowAddTrans.Find("Icon/Gold").gameObject.SetActive(obj.propEnum == PropEnum.Coin);
            flowAddTrans.Find("Icon/Flower").gameObject.SetActive(obj.propEnum == PropEnum.CollectFlower);
            flowAddTrans.Find("Icon/Card").gameObject.SetActive(obj.propEnum == PropEnum.CollectCard);
            if (obj.propEnum == PropEnum.CollectCard)
            {
                string key = dataService.CollectLoveCardProgress.SubActivityType == 1 ? "axfk_11" : "axfk_12";
                flowAddTrans.Find("Icon/Card").GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectLoveCardAtlas, key, false);
            }
            flowAddTrans.Find("Icon/Riot").gameObject.SetActive(obj.propEnum == PropEnum.CollectRiot);
            flowAddTrans.Get<Text>("Icon/AddNum").text = addStr;
            flowAddTrans.Get<Text>("Icon/MultipleText").text = obj.multiple > 1 ? $"x{obj.multiple}" : "";
            flowAddTrans.position = new Vector3(obj.pos.x + 20, obj.pos.y, 0);
            UniRx.Observable.Timer(TimeSpan.FromSeconds(120 / 60)).Subscribe(_ =>
            {
                GameObjManager.Instance.PushGameObject(flowAddTrans.gameObject);
            });

            if (!obj.needAddData) return;
            if (obj.propEnum == PropEnum.Coin)
            {
                if (obj.needAddAnim)
                {
                    dataService.AddCoin(obj.num, PropChangeWay.Harvest, obj.pos);
                }
                else
                {
                    dataService.AddCoin(obj.num, PropChangeWay.Harvest);
                }
            }
            else if (obj.propEnum == PropEnum.BuildCoin)
            {

                if (obj.needAddAnim)
                {
                    dataService.AddBuildCoin(obj.num, PropChangeWay.Harvest, obj.pos);
                }
                else
                {
                    dataService.AddBuildCoin(obj.num, PropChangeWay.Harvest);
                }
            }
        });
    }

    public Vector3 GetGoldPos()
    {
        return goldRoot.transform.position;
    }

    public Tween ThreePowerBeizerFlyCoinFromWorldPos(int type, long oldCoin, long newCoin, Vector3 _pos)
    {
        var screenPosition = Camera.main.WorldToScreenPoint(_pos);
        RectTransform canvasRect = goldRoot.GetComponentInParent<Canvas>().GetComponent<RectTransform>();
        Vector2 uiPosition;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            canvasRect,
            screenPosition,
            Camera.main,
            out uiPosition);

        return ThreePowerBeizerFlyCoin(type, oldCoin, newCoin, uiPosition);
    }

    public Tween ThreePowerBeizerFlyCoin(int type, long oldCoin, long newCoin, Vector3 localBeginPos)
    {
        int coinCount = configService.GetCoinFlyCount(newCoin - oldCoin);
        Vector3 endPos = EndPos();

        if (type == (int)PropEnum.BuildCoin)
        {
            endPos = GameUtils.GetLocalPosition(transform, buildCoinRoot.transform, new Vector3(0, 0, 0));
        }

        var control1Pos = new Vector3(localBeginPos.x, 0, 0);
        var control2Pos = new Vector3(endPos.x, 0, 0);
        localBeginPos.z = endPos.z = 0;
        float flyTime = Vector3.Distance(localBeginPos, endPos) / 1300;
        BeizerFlyAnimParam animParam = new BeizerFlyAnimParam(coinCount, localBeginPos,
            new Vector3[] { control1Pos, control2Pos }, endPos, flyTime);
        animParam.IsBuildCoin = type == (int)PropEnum.BuildCoin;
        animParam.scale = 0.7f;
        animParam.startScale = 0.7f;
        animParam.endScale = 0.5f;
        animParam.moveEase = Ease.InQuad;
        animParam.firstArriveCall = () =>
        {
            if (type == (int)PropEnum.Coin)
            {
                ShowGoldNumFx((int)PropEnum.Coin);
                coinTween?.Kill();
                coinTween = DOTween.To(value => { goldText.text = Mathf.Floor(value).ToString(); }, oldCoin, newCoin,
                    HarvestCoinRollTime);
            }
            else
            {
                ShowGoldNumFx((int)PropEnum.BuildCoin);
                buildCoinTween?.Kill();
                buildCoinTween = DOTween.To(value => { buildCoinText.text = Mathf.Floor(value).ToString(); }, oldCoin, newCoin,
                    HarvestCoinRollTime);
            }
        };
        return GameUtils.BeizerFlyCoin(animParam);
    }

    public Tween ThreePowerBeizerFlyCoin(int type, long oldCoin, long newCoin, Transform startTrans)
    {
        int coinCount = configService.GetCoinFlyCount(newCoin - oldCoin);
        Vector3 endPos = goldRoot.transform.localPosition + new Vector3(140, -40, 0);
        Vector3 beginPos = GetFlyGoldStartPos(startTrans);
        if (type == (int)PropEnum.BuildCoin)
        {
            endPos = GameUtils.GetLocalPosition(transform, buildCoinRoot.transform, new Vector3(0, 0, 0));
        }

        var control1Pos = new Vector3(beginPos.x, 0, 0);
        var control2Pos = new Vector3(endPos.x, 0, 0);
        beginPos.z = endPos.z = 0;
        float flyTime = Vector3.Distance(beginPos, endPos) / 1300;
        BeizerFlyAnimParam animParam = new BeizerFlyAnimParam(coinCount, beginPos,
            new Vector3[] { control1Pos, control2Pos }, endPos, flyTime);
        animParam.IsBuildCoin = type == (int)PropEnum.BuildCoin;
        animParam.scale = 0.7f;
        animParam.startScale = 0.7f;
        animParam.endScale = 0.5f;
        animParam.moveEase = Ease.InQuad;
        animParam.firstArriveCall = () =>
        {
            if (type == (int)PropEnum.Coin)
            {
                ShowGoldNumFx((int)PropEnum.Coin);
                coinTween?.Kill();
                coinTween = DOTween.To(value => { goldText.text = Mathf.Floor(value).ToString(); }, oldCoin, newCoin,
                    HarvestCoinRollTime);
            }
            else
            {
                ShowGoldNumFx((int)PropEnum.BuildCoin);
                buildCoinTween?.Kill();
                buildCoinTween = DOTween.To(value => { buildCoinText.text = Mathf.Floor(value).ToString(); }, oldCoin, newCoin,
                    HarvestCoinRollTime);
            }
        };
        return GameUtils.BeizerFlyCoin(animParam);
    }

    public void SetFakeCoin(long oldCoin, long newCoin)
    {
        coinTween?.Kill();
        coinTween = DOTween.To(value => { goldText.text = Mathf.Floor(value).ToString(); }, oldCoin, newCoin,
            HarvestCoinRollTime);
    }

    public long GetNowTextCoin()
    {
        if (int.TryParse(goldText.text, out var result))
        {
            return result;
        }
        return dataService.Coin;
    }

    private void OnCollectFarmingCoin(CollectFarmingCoin obj)
    {
        Observable.Timer(TimeSpan.FromSeconds(1.5f)).Subscribe(_ =>
        {
            dataService.AddCoin(obj.count, PropChangeWay.CollectFarmingCoin);
            dataService.SaveData(true);
        });
    }

    private void OnCoinChange(RefreshUserInfoCoin obj)
    {
        if (obj.param is { Length: > 1 })
        {
            var needChangeText = (bool)obj.param[1];
            if (!needChangeText) return;
        }
        coinTween?.Kill();
        switch (obj.getWay)
        {
            case PropChangeWay.CollectFarmingCoin:
                coinTween = DOTween.To(value => { goldText.text = Mathf.Floor(value).ToString(); }, obj.oldCoin, obj.newCoin,
                    HarvestCoinRollTime);
                break;
            default:
                if (obj.param != null && obj.param.Length > 0)
                {
                    //飘金币动画
                    ThreePowerBeizerFlyCoin((int)PropEnum.Coin, obj.oldCoin, obj.newCoin, (Vector3)obj.param[0]);
                }
                else
                {
                    //直接变动金币数量
                    coinTween = DOTween.To(value => { goldText.text = Mathf.Floor(value).ToString(); }, obj.oldCoin, obj.newCoin,
                        HarvestCoinRollTime);
                }
                break;
        }
    }

    private void OnBuildCoinChange(RefreshUserInfoBuildCoin obj)
    {
        if (obj.param is { Length: > 1 })
        {
            var needChangeText = (bool)obj.param[1];
            if (!needChangeText) return;
        }
        if (obj.param != null && obj.param.Length > 0)
        {
            ThreePowerBeizerFlyCoin((int)PropEnum.BuildCoin, obj.oldCoin, obj.newCoin, (Vector3)obj.param[0]);
        }
        else
        {
            buildCoinTween?.Kill();
            buildCoinTween = DOTween.To(value => { buildCoinText.text = Mathf.Floor(value).ToString(); }, obj.oldCoin,
                obj.newCoin,
                HarvestCoinRollTime);
        }
    }

    private void OnEnergyChange(RefreshUserInfoEnergy obj)
    {
        energyText.text = obj.newValue.ToString();
    }

    private void OnTogglePopup(TogglePopupEvent evt)
    {
        UIPopup currentPopup = UIPopupManager.CurrentVisibleQueuePopup;
        if (currentPopup != null)
        {
            if (currentPopup.Visibility == VisibilityState.Hiding)
            {
                spreadViewHandler.ToggleSpread(false);
            }
            else
            {
                spreadViewHandler.ToggleSpread(true);
            }
        }
        else
        {
            spreadViewHandler.ToggleSpread(false);
        }
    }

    public void ShowGoldNumFx(int type, Action cb = null)
    {
        var fx = GameObjManager.Instance.PopGameObject(GameObjType.AddCoinTextFx);
        fx.GetComponent<SortingGroup>().sortingOrder = SortingOrder + 2;
        var fxCall = fx.GetComponent<ParticleSystemsStoppedCallback>();

        void callBack()
        {
            fxCall.Callback.RemoveListener(callBack);
            GameObjManager.Instance.PushGameObject(fx);
            cb?.Invoke();
        }

        fx.SetActive(true);
        fxCall.Callback.AddListener(callBack);
        fx.transform.SetParent(type == (int)PropEnum.BuildCoin ? buildCoinRoot.transform : goldRoot.transform);
        fx.transform.localScale = Vector3.one;
        fx.transform.localPosition = Vector3.zero;
        fx.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
    }

    private void SetGoldViewParam(string key, ViewBase viewBase)
    {
        if (paramDic.TryGetValue(key, out GoldViewParam viewParam))
        {
            if (viewParam.canClick.HasValue)
                CanClick = viewParam.canClick.Value;
            if (viewParam.diffSortingOrder.HasValue)
                SortingOrder = viewBase.SortingOrder + viewParam.diffSortingOrder.Value;
            //buildCoinRoot.SetActive(viewParam.showBuildCoinRoot.Value);
            energyRoot.SetActive(viewParam.showBuildCoinRoot.Value);
        }
        CheckUnock();
    }

    public void CheckUnock()
    {
        bool unlock = GameUtils.CheckFuncIsUnlock("topResource");
        transform.localScale = unlock ? Vector3.one : Vector3.zero;
    }

    public void ShowBuildCoinRoot(bool bo)
    {
        buildCoinRoot.SetActive(false);
    }

    protected override void OnViewDestroy()
    {
        UIView.OnUIViewAction -= OnUIViewAction;
        UIPopup.OnUIPopupAction -= OnUIPopupAction;
    }

    private void UpdateEnergyRoot()
    {
        IEnergyActivity energyActivity = ActivityManager.Instance.EnergyActivity;
        bool isFull = energyActivity.GetMaxEnergy() == energyActivity.GetCurrentEnergy();
        int infiniteSecond = energyActivity.GetInfiniteSecond();
        if (infiniteSecond > 0)//体力无限
        {
            energyText.gameObject.SetActive(false);
            energyInfiniteSign.gameObject.SetActive(true);
            energyTimeText.gameObject.SetActive(true);
            energyTimeText.text = TimeUtils.SecondFormatDdHhMmSs(infiniteSecond);
            energyFullSign.gameObject.SetActive(false);
        }
        else
        {
            energyText.gameObject.SetActive(true);
            energyInfiniteSign.gameObject.SetActive(false);
            if (isFull)
            {
                energyTimeText.gameObject.SetActive(false);
                energyFullSign.gameObject.SetActive(true);
            }
            else
            {
                energyTimeText.gameObject.SetActive(true);
                energyFullSign.gameObject.SetActive(false);
                int recoverSecond = energyActivity.GetAutoRecoverCountDown();
                energyTimeText.text = TimeUtils.SecondFormatDdHhMmSs(recoverSecond);
            }

        }
        //bool isFull = (isFull || infiniteSecond > 0);
        energyBtn.gameObject.SetActive(!(isFull || infiniteSecond > 0));

    }
}