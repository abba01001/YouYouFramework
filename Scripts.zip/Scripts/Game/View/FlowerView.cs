﻿using Coffee.UIExtensions;
using Doozy.Engine;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UniRx;
using UnityEngine;
using UnityEngine.UI;
using QFramework;
using System;
using SoliUtils;

public class FlowerView : ViewBase
{
    private Button closeBtn;
    private Button leftBtn;
    private Button rightBtn;

    private Text progressText;
    private Image fillMask;
    private GameObject passGift;
    private RectTransform giftRoot;
    private Transform leftContent;
    private Transform rightContent;

    private int nowLeftModelId = 0;
    private int nowMaxUnlockId = 0;

    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Content/BG/CloseBtn");
        leftBtn = transform.Get<Button>("Content/BG/LeftBtn");
        rightBtn = transform.Get<Button>("Content/BG/RightBtn");

        progressText = transform.Get<Text>("Content/BG/FillBG/ProgressText");
        fillMask = transform.Get<Image>("Content/BG/FillBG/FillMask");
        passGift = transform.Find("Content/BG/FillBG/PassGift").gameObject;
        giftRoot = transform.Get<RectTransform>("Content/BG/FillBG/GiftRoot");
        leftContent = transform.Find("Content/BG/Content/Left");
        rightContent = transform.Find("Content/BG/Content/Right");

        closeBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
        });

        leftBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            int nowId = nowLeftModelId;
            RefreshFlowerMap(nowId - 2);
            RefreshFlowerMap(nowId - 1);
        });

        rightBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            int nowId = nowLeftModelId;
            RefreshFlowerMap(nowId + 2);
            RefreshFlowerMap(nowId + 3);
        });
    }

    private void ShowProgress()
    {
        
    }

    protected override void OnShow()
    {
        ShowProgress();
    }

    public void SetShowStar(int oldStar, int newStar)
    {
        ShowFlower();
    }

    private void ShowFlower()
    {
        
    }

    private void OnLeftModelIdChange()
    {
        leftBtn.gameObject.SetActive(nowLeftModelId > 1);
        rightBtn.gameObject.SetActive(nowLeftModelId < nowMaxUnlockId);
    }

    private void RefreshFlowerMap(int showModleId)
    {
       
    }
}
