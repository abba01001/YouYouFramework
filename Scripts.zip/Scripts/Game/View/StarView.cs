﻿using QFramework;
using System;
using UniRx;
using DG.Tweening;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using Random = UnityEngine.Random;
using UnityEngine.Rendering;
using SoliUtils;

public class StarView : ViewBase, ISingleton
{
    private RectTransform starRectTrans;
    private Text starText;

    public bool ShowStar
    {
        get
        {
            return false;
        }
        set
        {
            starRectTrans.gameObject.SetActive(value);
        }
    }

    public static StarView Instance
    {
        get { return MonoSingletonProperty<StarView>.Instance; }
    }

    public void OnSingletonInit()
    {
    }

    protected override void OnAwake()
    {
        reportOnShow = false;
        starRectTrans = transform.Get<RectTransform>("FlowStar");
        starText = starRectTrans.transform.Get<Text>("StarNumText");
        ShowStar = true;
    }

    protected override void OnViewInit(bool isFirst)
    {
        starText.text = dataService.StageStar.ToString();
        if (isFirst == false) return;
        TypeEventSystem.Register<StageStarChange>(OnStageStarChange);
    }
    
    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<StageStarChange>(OnStageStarChange);
    }

    protected override void OnShow()
    {
        starText.text = dataService.StageStar.ToString();
    }

    private void OnStageStarChange(StageStarChange obj)
    {
        starText.text = obj.newStar.ToString();
    }

    public void SetStarOffset(Vector2 offest)
    {
        starRectTrans.anchoredPosition = offest;
    }
}
