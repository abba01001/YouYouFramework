using Doozy.Engine;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Model;
using Activities;
using UniRx;
using SoliUtils;

public class SaverView : ViewBase
{
    private IDisposable subscription;
    private Text priceText;
    private Image savedGold;
    private Text currGold;
    private Button buyBtn;
    private RectTransform reachMinImg;
    private GameObject reachMaxImg;
    private Text minCoinText;
    private RectTransform minCoinTextImg;

    private GameObject pigFullImg;
    private GameObject pigNormalImg;
    private GameObject pigBreakImg;
    private Image coinImg;
    private GameObject tipsPopAnim;
    private Button tipsBG;
    private Text cannotGuideNum;
    private GameObject cannotBuyGuide;
    private int nowSaverGold;
    private ActivityTimeItem timeItem;
    protected override void OnAwake()
    {
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
        });
        tipsPopAnim = transform.Find("Container/TipsPopAnim").gameObject;
        transform.Get<Button>("Container/TipsBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            tipsPopAnim.gameObject.SetActive(true);
            TipsAnim();
        });
        tipsBG = transform.Get<Button>("Container/TipsPopAnim/TipsBG");
        tipsBG.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            tipsPopAnim.gameObject.SetActive(false);
        });
        buyBtn = transform.Get<Button>("Container/BuyBtn");
        buyBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!CheckIfEnough()) return;
            PayUtils.RequestOrder(Constants.ProductId.PiggyBank);
        });
        priceText = transform.Get<Text>("Container/BuyBtn/Price");
        savedGold = transform.Get<Image>("Container/SavedGoldSlider/FillArea");
        currGold = transform.Get<Text>("Container/SavedCoins/SaverCoinNum");
        reachMaxImg = transform.Find("Container/SavedGoldSlider/MaxCoin/ReachMax").gameObject;
        reachMinImg = transform.Get<RectTransform>("Container/SavedGoldSlider/MinCoin/ReachMin");
        minCoinText = transform.Get<Text>("Container/SavedGoldSlider/MinCoin/MinCoinText");
        minCoinTextImg = transform.Get<RectTransform>("Container/SavedGoldSlider/MinCoin");
        coinImg  = transform.Get<Image>("Container/MoreCoinImg");
        pigNormalImg = transform.Find("Container/PigGif").gameObject;
        pigFullImg = transform.Find("Container/PigFullGif_dh").gameObject;
        pigBreakImg = transform.Find("Container/PigFullGif_broken").gameObject;
        cannotBuyGuide = transform.Find("Container/CannotBuyGuide").gameObject;
        cannotGuideNum = cannotBuyGuide.transform.Get<Text>("Text");
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
    }

    protected override void OnShow()
    {
        ActivityDataModel piggy = ActivityManager.Instance.GetActivityByType(ActivityType.piggy);
        PiggyData piggyData = (PiggyData)piggy.localData;
        nowSaverGold = piggyData.piggyCoin;

        pigBreakImg.SetActive(false);
        currGold.text = nowSaverGold.ToString();
        //if (dataService.LastSaverCoin < configService.SaverBankMin) buyBtn.interactable = false;
        savedGold.fillAmount = nowSaverGold * 1f / configService.SaverBankMax;
        ShowCoinProcess();
        CheckIfEnough();
        CheckIfFull();
        LightShineAnim();
        MinCoinShow();
        SetTimeItem();
        UpdatPanel(null);
        cannotGuideNum.text = string.Format("玩游戏积累<color=#FAF459>{0}</color>金币，然后才能购买存钱罐。", configService.SaverBankMin);
    }

    protected override void OnViewInit(bool isFirst)
    {
        SetPrice();
        if (isFirst == false) return;
        TypeEventSystem.Register<GameRechargeEvent>(UpdatPanel);
    }

    protected override void OnInitedDestroy()
    {
        subscription?.Dispose();
        SoundPlayer.Instance.StopLoopSound();
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatPanel);
    }

    private void SetTimeItem()
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.piggy).ActivityBigEndTime);
        if (ActivityManager.Instance.GetActivityByType(ActivityType.piggy).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.PiggyData.ActivityEndTime);
        }
        StopAllCoroutines();
        StartCoroutine(SetTimeItem(timeData));
    }
    
    IEnumerator SetTimeItem(CountTimeData timeData)
    {
        while (!timeItem.gameObject.activeInHierarchy)
        {
            yield return null; 
        }
        timeItem.SetTimeData(timeData);
    }
    
    private void UpdatPanel(GameRechargeEvent obj)
    {
        ActivityDataModel piggy = ActivityManager.Instance.GetActivityByType(ActivityType.piggy);
        bool isShow = piggy.state == ActivityState.underWay && !dataService.PiggyData.FinishGetReward;
        buyBtn.gameObject.SetActive(isShow);
        if (obj != null)
        {
            subscription?.Dispose();
            SoundPlayer.Instance.StopLoopSound();
            SoundPlayer.Instance.PlayMainSound("PigFullGif_broken");
            TypeEventSystem.Send<SaverShowChange>(new SaverShowChange(false));
            pigBreakImg.SetActive(true);
            pigNormalImg.SetActive(false);
            pigFullImg.SetActive(false);
            Observable.Timer(TimeSpan.FromSeconds(1.5)).Subscribe(_ =>
            {
                GameUtils.PlayGoldAnim(transform,(int)(dataService.Coin - dataService.PiggyData.piggyCoin),(int)dataService.Coin,pigBreakImg.transform,
                    () =>
                    {
                        BoxBuilder.HidePopup(gameObject);
                        ActivityManager.Instance.SaveActivityData();
                    });
            });
        }
    }

    private void SetPrice()
    {
        ShopModel model = configService.ShopConfig[Constants.ProductId.PiggyBank];
        priceText.text = model.money.ToString();
        cannotBuyGuide.transform.Get<Text>("CannotBuy/Price").text = model.money.ToString();
    }

    private void ShowCoinProcess()
    {
        bool isReachMin = nowSaverGold >= configService.SaverBankMin;
        bool isFull = nowSaverGold >= configService.SaverBankMax;
        Transform ReachBg = transform.Find("Container/SavedGoldSlider/MaxCoin/ReachBg");
        Transform NoReachBg = transform.Find("Container/SavedGoldSlider/MaxCoin/NoReachBg");
        ReachBg.gameObject.SetActive(isFull);
        NoReachBg.gameObject.SetActive(!isFull);
        Text maxCoinText = (isFull ? ReachBg : NoReachBg).Get<Text>("MaxCoinText");
        maxCoinText.text = configService.SaverBankMax.ToString();
        minCoinText.text = configService.SaverBankMin.ToString();
        currGold.transform.parent.gameObject.SetActive(!isFull);
        reachMinImg.gameObject.SetActive(isReachMin);
        reachMaxImg.SetActive(isFull);
        pigNormalImg.SetActive(!isFull);
        pigFullImg.SetActive(isFull && !dataService.PiggyData.FinishGetReward);
        coinImg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewSaverAtlas, isFull ? "cxg_2" : "cxg_3", true);
        if (isFull && !dataService.PiggyData.FinishGetReward)
        {
            subscription = Observable.Interval(TimeSpan.FromSeconds(27f/60))
                .Subscribe(_ =>  SoundPlayer.Instance.PlayMainSound("PigFullGif_pig"));
            SoundPlayer.Instance.PlayLoopSound("PigFullGif_coinfly", 0, true);
        }
    }

    private bool CheckIfEnough()
    {
        //判断是否可购买，相应的显示
        bool isEnough = nowSaverGold >= configService.SaverBankMin;
        buyBtn.gameObject.SetActive(isEnough);
        cannotBuyGuide.SetActive(!isEnough);
        return isEnough;
    }

    private void CheckIfFull()
    {
        //判断是否集满，以及相关显示
        // bool isShow = nowSaverGold >= configService.SaverBankMax;
        // discountBG.gameObject.SetActive(isShow);
    }

    private void TipsAnim()
    {
        DOTween.Kill(tipsPopAnim, false);
        var seq = DOTween.Sequence();
        seq.SetId(tipsPopAnim);
        Vector3 max = new Vector3(1, 1, 1);
        transform.Find("Container/TipsPopAnim/TipsBG/TipsCardImg").localScale = Vector3.zero;
        transform.Find("Container/TipsPopAnim/TipsBG/Arrow1").localScale = Vector3.zero;
        transform.Find("Container/TipsPopAnim/TipsBG/TipsPigImg").localScale = Vector3.zero;
        transform.Find("Container/TipsPopAnim/TipsBG/Arrow2").localScale = Vector3.zero;
        transform.Find("Container/TipsPopAnim/TipsBG/TipsGoldImg").localScale = Vector3.zero;
        float time = 0.4f;
        seq.Append(transform.Find("Container/TipsPopAnim/TipsBG/TipsCardImg").DOScale(max, time));
        seq.Append(transform.Find("Container/TipsPopAnim/TipsBG/Arrow1").DOScale(max, time));
        seq.Append(transform.Find("Container/TipsPopAnim/TipsBG/TipsPigImg").DOScale(max, time));
        seq.Append(transform.Find("Container/TipsPopAnim/TipsBG/Arrow2").DOScale(max, time));
        seq.Append(transform.Find("Container/TipsPopAnim/TipsBG/TipsGoldImg").DOScale(max, time));
    }

    private void LightShineAnim()
    {
        // //收集满时的闪光动效
        // if (nowSaverGold < configService.SaverBankMax) return;
        // var seq = DOTween.Sequence();
        // //lightBulbs.gameObject.SetActive(true);
        // seq.Append(transform.Find("Container/PigStageBG/Light/Shine1").DOScale(Vector3.one, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine2").DOScale(Vector3.one, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine3").DOScale(Vector3.one, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine4").DOScale(Vector3.one, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine5").DOScale(Vector3.one, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine6").DOScale(Vector3.one, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine7").DOScale(Vector3.one, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine8").DOScale(Vector3.one, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine9").DOScale(Vector3.one, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine10").DOScale(Vector3.one, 0.2f));
        // seq.AppendInterval(0.5f);
        // seq.Append(transform.Find("Container/PigStageBG/Light/Shine1").DOScale(Vector3.zero, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine2").DOScale(Vector3.zero, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine3").DOScale(Vector3.zero, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine4").DOScale(Vector3.zero, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine5").DOScale(Vector3.zero, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine6").DOScale(Vector3.zero, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine7").DOScale(Vector3.zero, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine8").DOScale(Vector3.zero, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine9").DOScale(Vector3.zero, 0.2f));
        // seq.Join(transform.Find("Container/PigStageBG/Light/Shine10").DOScale(Vector3.zero, 0.2f));
        // //seq.Append(transform.Find("PigStageBG/Shine1").DOScale(new Vector3(0, 0, 0), 0.1f));
        // seq.SetLoops(-1);
        // seq.Play();
    }

    private void MinCoinShow()
    {
        //最低可购买金币数相应图标位置
        float xPos = 61f;
        float yPos = ((-1f) * 151f) + ((154f + 151f) * ((float)configService.SaverBankMin / configService.SaverBankMax));
        minCoinTextImg.anchoredPosition = new Vector3(xPos, yPos);
    }
}
