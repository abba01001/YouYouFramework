using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using Doozy.Engine.UI;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

namespace View
{
    public class SeasonDescView : ViewBase
    {
        [SerializeField] private Button CloseBtn;
        [SerializeField] private List<Transform> ShowByOrder;
        
        private UIPopup _uiPopup;
        private bool _animPlayFinish;

        protected override void OnAwake()
        {
            _uiPopup = GetComponent<UIPopup>();
            CloseBtn.SetButtonClick(OnCloseBtnClick);    
            GetComponent<Canvas>().overrideSorting = true;
            GetComponent<Canvas>().sortingOrder = 102;
        }

        protected override async void OnShow()
        {
            foreach (Transform transform in ShowByOrder)
            {
                DoScaleAnim(transform);
                await UniTask.Delay(500);
            }

            _animPlayFinish = true;
        }

        private void DoScaleAnim(Transform transform)
        {
            transform.gameObject.SetActive(true);
            transform.localScale = Vector3.zero;
            transform.DOScale(Vector3.one, 0.5f);
        }

        private void OnCloseBtnClick()
        {
            if (_animPlayFinish == false) return;
            _uiPopup.Hide();
            SoundPlayer.Instance.PlayButton();
        }

        protected override void OnViewDestroy()
        {
            
        }
    }
}