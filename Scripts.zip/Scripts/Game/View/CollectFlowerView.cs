﻿using Activities;
using DG.Tweening;
using Doozy.Engine;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class CollectFlowerView : ViewBase
{
    private Button closeBtn;
    private Button tipBtn;
    private Text tipText;
    private GameObject collectFlowerItem;

    private Transform itemParent;
    private RectTransform itemParentRect;
    private RectTransform scrollRect;
    private Vector2 prefabSize;
    private Vector2 itemParentSize;

    Dictionary<int, CollectFlowerItem> itemList = new Dictionary<int, CollectFlowerItem>();
    ActivityTimeItem timeItem;
    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");

        closeBtn.SetButtonClick(CloseFunc);
        tipBtn = transform.Get<Button>("Container/TipBtn");
        tipBtn.SetButtonClick(BoxBuilder.ShowUnlockCollectFlowerPopView);
        tipText = transform.Get<Text>("Container/bg/Tip");
        collectFlowerItem = transform.Get<Transform>("Container/CollectFlowerItem").gameObject;
        collectFlowerItem.SetActive(false);

        prefabSize = collectFlowerItem.GetComponent<RectTransform>().sizeDelta;
        scrollRect = transform.Get<RectTransform>("Container/ScrollView");
        itemParent = transform.Get<Transform>("Container/ScrollView/Content");
        itemParentRect = itemParent.GetComponent<RectTransform>();
        itemParentSize = itemParentRect.sizeDelta;

        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
    }
    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<UpdateCollectFlowerInfoEvent>(UpdatePanel);
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    //更新排行面板
    private void UpdatePanel(UpdateCollectFlowerInfoEvent obj)
    {
        int index = 0;
        List<CollectFlowerData> list = dataService.CollectFlowerProgress.GetRankData();
        if (list == null || list.Count == 0)
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            return;
        }
        foreach (var item in list)
        {
            itemList[index].gameObject.name = "FlowerItem_" + index;
            itemList[index].SetData(transform,item);
            index++;
        }
        tipText.text = $"当前商贩正在回收鲜花，关卡中消除指定扑克牌即可获得鲜花";
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateCollectFlowerInfoEvent>(UpdatePanel);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    protected override void OnShow()
    {
        dataService.CollectFlowerProgress.IsFirstShow = false;
        ActivityManager.Instance.CollectFlowerActivity.InitRankInfo();
        InitPanel();
        RefreshTimer(null);
        CheckFinish();
    }

    void CheckFinish()
    {
        closeBtn.gameObject.SetActive(true);
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state == ActivityState.waitFinished)
        {
            if (dataService.CollectFlowerProgress.GetMyData().curRank == 0)
            {
                closeBtn.gameObject.SetActive(false);
            }
            else
            {
                closeBtn.gameObject.SetActive(true);
            }
        }
    }

    public void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state == ActivityState.waitFinished)
        {
            if (dataService.CollectFlowerProgress.GetMyData().curRank != 0)
            {
                ActivityManager.Instance.FinishGetReward(ActivityType.collectFlower);
            }
        }
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).ActivityBigEndTime);
            }
            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.CollectFlowerProgress.ActivityEndTime);
            }
            timeData.endText = model.state is ActivityState.finished ? "结束" : model.state is ActivityState.waitFinished && dataService.CollectFlowerProgress.MyData.curRank == 0 ? "领取奖励" : "结束";
        }
        timeItem.SetTimeData(timeData);
    }

    private void InitPanel()
    {
        if (itemList.Count > 0) return;
        int lastRank = dataService.CollectFlowerProgress.GetMyData().lastRank;
        int curRank = dataService.CollectFlowerProgress.GetMyData().curRank;
        scrollRect.sizeDelta = new Vector2(900, 468);
        tipText.text = $"当前商贩正在回收鲜花，关卡中消除指定扑克牌即可获得鲜花";

        if (lastRank == curRank)
        {
            //正常初始化
            PlayInitAnim(lastRank);
        }
        else
        {
            //带动画的初始化
            PlayRankChangeAnim(lastRank, curRank);
        }
    }

    void PlayInitAnim(int curRank)
    {
        int index = 0;
        float duration = 0.4f;
        Sequence seq = DOTween.Sequence();
        foreach (var item in dataService.CollectFlowerProgress.GetRankData())
        {
            GameObject prefab = GameObjManager.Instance.PopGameObject(GameObjType.CollectFlowerItem,collectFlowerItem);
            prefab.transform.SetParent(itemParent);
            prefab.transform.localScale = Vector3.one;
            prefab.SetActive(true);
            prefab.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            SetItemPos(prefab, index);
            prefab.name = "RankItem_" + index;
            itemList.Add(index, prefab.GetComponent<CollectFlowerItem>());
            itemList[index].SetData(transform,item);
            index++;
        }
        itemParentRect.sizeDelta = new Vector2(itemParentSize.x, (index) * (prefabSize.y + 10));

        int count = 0;
        for (int i = 0; i < itemParent.childCount; i++)
        {
            RectTransform rect = itemParent.GetChild(i).GetComponent<RectTransform>();
            rect.anchoredPosition = new Vector2(1000 + count * 180, rect.anchoredPosition.y);
            seq.Join(rect.DOAnchorPos(new Vector2(-30, rect.anchoredPosition.y), duration + count * 0.05f).SetEase(Ease.InOutQuad).OnComplete(() =>
            {
                rect.DOAnchorPos(new Vector2(0,rect.anchoredPosition.y),0.05f).SetEase(Ease.OutSine);
            })); // 并行执行动画
            count++;
        }
    }

    void SetItemPos(GameObject prefab, int index)
    {
        RectTransform rect = prefab.GetComponent<RectTransform>();
        rect.anchoredPosition = new Vector2(0, -index * (prefabSize.y + 10));
    }

    void PlayRankChangeAnim(int lastRank, int curRank)
    {
        if (curRank < lastRank)
        {
            dataService.CollectFlowerProgress.ResetLastRank();
            PlayUpAnim(lastRank, curRank);
        }
        else
        {
            PlayInitAnim(curRank);
        }
    }

    //暂时没有排名下降的情况
    void PlayDownAnim(int lastRank, int curRank)
    {

    }
    void PlayUpAnim(int lastRank, int curRank)
    {
        int index = 0;
        float duration = 0.3f;
        Sequence seq = DOTween.Sequence();
        foreach (var item in dataService.CollectFlowerProgress.GetRankData())
        {
            GameObject prefab = GameObjManager.Instance.PopGameObject(GameObjType.CollectFlowerItem,collectFlowerItem);
            prefab.transform.SetParent(itemParent);
            prefab.transform.localScale = Vector3.one;
            prefab.SetActive(true);
            prefab.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            if(index != curRank)
            {
                if (index > curRank)
                {
                    SetItemPos(prefab, index - 1);
                }
                else
                {
                    SetItemPos(prefab, index);
                }
            }
            else
            {
                SetItemPos(prefab, lastRank);
            }
            prefab.name = "RankItem_" + index;
            itemList.Add(index, prefab.GetComponent<CollectFlowerItem>());
            itemList[index].SetData(transform,item);
            index++;
        }
        itemParentRect.sizeDelta = new Vector2(itemParentSize.x, (index) * (prefabSize.y + 10));

        GameObject myItem = itemList[curRank].gameObject;
        myItem.transform.SetAsLastSibling();
        RectTransform myItemRect = myItem.GetComponent<RectTransform>();
        int count = 0;
        for (int i = 0; i < itemParent.childCount; i++)
        {
            if (i >= lastRank - 4 && i <= lastRank + 4)
            {
                RectTransform rect = itemParent.GetChild(i).GetComponent<RectTransform>();
                rect.anchoredPosition = new Vector2(1000 + count * 180, rect.anchoredPosition.y);
                seq.Join(rect.DOAnchorPos(new Vector2(-30, rect.anchoredPosition.y), 0.6f + count * 0.05f).SetEase(Ease.InOutQuad).OnComplete(() =>
                {
                    rect.DOAnchorPos(new Vector2(0,rect.anchoredPosition.y),0.05f).SetEase(Ease.OutSine);
                })); // 并行执行动画
                count++;
            }
        }

        seq.AppendInterval(0.05f);
        seq.AppendCallback(() =>
        {
            scrollRect.sizeDelta = new Vector2(1155, 468);
            Sequence tempSeq = DOTween.Sequence();
            float time = Math.Clamp(Math.Abs(curRank - lastRank) * 0.1f + 0.2f,0.4f,2f);
            for (int i = 0; i < itemParent.childCount; i++)
            {
                if (i == itemParent.childCount - 1)
                {
                    tempSeq.Join(myItemRect.DOAnchorPos(GetMyFinalPos(),time).SetEase(Ease.OutSine));
                    tempSeq.Join(myItemRect.DOScale(Vector3.one * 1.06f, 0.1f));
                    break;
                } 
                if (i >= curRank)
                {
                    RectTransform rect = itemParent.GetChild(i).GetComponent<RectTransform>();
                    tempSeq.Join(rect.DOAnchorPos(new Vector2(0, rect.anchoredPosition.y - (prefabSize.y + 10)), time).SetEase(Ease.OutSine)); // 并行执行动画
                }
            }
            tempSeq.Insert(time - 0.1f, myItemRect.DOScale(Vector3.one, 0.2f));
        });

    }

    Vector2 GetMyFinalPos(bool isUp = true)
    {
        int index = isUp ? dataService.CollectFlowerProgress.GetMyData().curRank : dataService.CollectFlowerProgress.GetMyData().curRank + 1;
        RectTransform rect = itemList[dataService.CollectFlowerProgress.GetMyData().lastRank].GetComponent<RectTransform>();
        return new Vector2(0, -index * (prefabSize.y + 10));
    }

    Vector2 GetMyCurPos()
    {
        RectTransform rect = itemList[dataService.CollectFlowerProgress.GetMyData().lastRank].GetComponent<RectTransform>();
        return rect.anchoredPosition;
    }

    private void OnDisable()
    {
        if (!GameObjManager.IsNull())
        {
            foreach (var item in itemList)
            {
                GameObjManager.Instance.PushGameObject(item.Value.gameObject);
            }
        }
    }
}
