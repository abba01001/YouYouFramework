﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using QFramework;
using DG.Tweening;
using System;
using Activities;
using Doozy.Engine.UI;
using Model;
using UniRx;
using SoliUtils;

public class HomeMapView : ViewBase
{

    private Transform wholeScroll;
    private Button backBtn;
    private Tween showTween;
    private Transform itemParentRect;
    private GameObject itemPrefab;
    private List<GameObject> itemList = new List<GameObject>();
    protected override void OnAwake()
    {
        wholeScroll = transform.Find("Container/Layout/WholeScroll");
        itemParentRect = transform.Find("Container/Layout/WholeScroll/Content");
        backBtn = transform.Get<Button>("Container/Layout/Button - Back");
        itemPrefab = transform.Find("Container/Layout/Item").gameObject;
        itemPrefab.SetActive(false);
        backBtn.SetButtonClick(()=>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
            // GameUtils.TryShowTriggerGift(true, true);
            showTween?.Kill();
            showTween = null;
        });
    }

    private string GetMapImage(int index)
    {
        List<string> list = new List<string>()
        {
            "map_1_1",
            "map_1_2",
            "map_1_3",
            "map_1_1",
            "map_1_1",
            "map_1_1",
            "map_1_1",
            "map_1_1",
            "map_1_1"
        };
        return list[index];
    }

    protected override void OnShow()
    {
        InitPanel();
        ShowTween();
    }

    private void InitPanel()
    {
        int index = 1;

        // foreach (var dict in configService.GetHomeMapModel())
        // {
        //     foreach (var model in dict.Value)
        //     {
        //         GameObject obj = GameObjManager.Instance.PopGameObject(GameObjType.HomeMapItem, itemPrefab);
        //         obj.name = $"Item_{index}";
        //         obj.GetComponent<CanvasGroup>().alpha = 0;
        //         obj.SetActive(true);
        //         obj.transform.SetParent(itemParentRect);
        //         obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
        //         obj.transform.localScale = Vector3.one;
        //         obj.Get<Button>("Content").SetButtonClick(() =>
        //         {
        //             GameUtils.ChangeMap(model.Value, () =>
        //             {
        //                 BoxBuilder.HidePopup(gameObject);
        //             }, () =>
        //             {
        //                 obj.transform.GetComponent<HomeMapItem>().ShakeLock();
        //             });
        //         });
        //         if (dataService.FarmingProgress.MapInfo.TryGetValue(model.Value.mapId, out var datas) && datas.TryGetValue(model.Value.themeId, out var data))
        //         {
        //             obj.transform.GetComponent<HomeMapItem>().UpdateItem(data,model.Value);
        //         }
        //         else
        //         {
        //             obj.transform.GetComponent<HomeMapItem>().UpdateItem(new ThemeData(),model.Value);
        //         }
                
        //         itemList.Add(obj);
        //         index++;
        //     }
        // }

        itemParentRect.GetComponent<RectTransform>().sizeDelta = new Vector2(404 * (index - 1) + 180, 597);
    }

    private void OnDisable()
    {
        if (!gameObject.activeSelf) return;
        foreach (var VARIABLE in itemList)
        {
            GameObjManager.Instance.PushGameObject(VARIABLE);
        }
    }

    private void ShowTween(float delay = 0)
    {
        int index = 0;
        float showTime = 0.4f;
        float interval = 0.07f;
        Sequence seq = DOTween.Sequence();
        seq.SetId(gameObject);

        foreach (var VARIABLE in itemList)
        {
            RectTransform shopTrans = VARIABLE.GetComponent<RectTransform>();
            if (shopTrans.gameObject.activeSelf)
            {
                CanvasGroup canvasGroup = shopTrans.GetComponent<CanvasGroup>();
                canvasGroup.alpha = 0;
                RectTransform content = shopTrans.Get<RectTransform>("Content");
                Vector2 origPos = content.anchoredPosition;
                content.anchoredPosition = origPos + new Vector2(150, 0);
                Sequence showSeq = DOTween.Sequence();
                showSeq.Append(content.DOAnchorPos(origPos, showTime).SetEase(Ease.OutCubic));
                showSeq.Join(canvasGroup.DOFade(1, showTime).SetEase(Ease.OutQuad));
                seq.Insert(interval * index + delay, showSeq);

                index++;
            }
        }
        showTween = seq;
        seq.OnComplete(() => showTween = null);
    }


}
