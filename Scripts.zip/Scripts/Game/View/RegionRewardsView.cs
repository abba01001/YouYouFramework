using UniRx;
using UnityEngine;
using SoliUtils;
using Button = UnityEngine.UI.Button;
using System.Linq;
using System.Collections.Generic;
using UnityEngine.UI;
using Coffee.UIExtensions;
using System;

public class RegionRewardsView : ViewBase
{
    private Button closeBtn;

    private ListView listView;
    private RegionRewardAdapter listAdapter;
    private GameObject Item;
    private Button processBtn;

    private Slider expSlider;
    private Text expText;
    private Transform lvImgTrans;
    private Text lvText;

    private int RegionId;

    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(() => { BoxBuilder.HidePopup(gameObject); });

        var helpBtn = transform.Get<Button>("Container/helpBtn");
        helpBtn.SetButtonClick(() => { BoxBuilder.ShowInstructionsRewardPopup(); });

        var tipObj = transform.Get<Transform>("Container/tip").gameObject;
        tipObj.SetActive(false);
        processBtn = transform.Get<Button>("Container/processBtn");
        processBtn.SetButtonClick(() =>
        {
            tipObj.SetActive(!tipObj.activeSelf);
        });

        listView = transform.Get<ListView>("Container/ScrollView/Content");
        listAdapter = transform.Get<RegionRewardAdapter>("Container/ScrollView/Content");

        var bg = transform.Get<Image>("Container/bg");
        var bgWidth = bg.rectTransform.rect.width;
        var scSize = listView.transform.parent.GetComponent<RectTransform>().sizeDelta;
        scSize.x = bgWidth;
        listView.transform.parent.GetComponent<RectTransform>().sizeDelta = scSize;

        // Item = transform.Find("Item").gameObject;
        // Item.SetActive(false);

        expSlider = transform.Get<Slider>("Container/processBtn/Slider");
        expText = transform.Get<Text>("Container/processBtn/ProcessText");
        lvImgTrans = transform.Get<Transform>("Container/processBtn/LevelImg");
        lvText = transform.Get<Text>("Container/processBtn/LevelText");
    }

    public void SetRegionId(int region_id)
    {
        RegionId = region_id;
        ShowList();
        ShowExp();

        UniRx.Observable.Timer(TimeSpan.FromSeconds(0.5f)).Subscribe(_ =>
        {
            // dataService.RegionLevelUp(RegionId);
            listView.RefreshData();
            ShowExp();

            var info = dataService.GetRegionInfo(RegionId);
            if (info != null)
            {
                listView.GotoIndex(info.level, 0.5f);
            }
        });
    }

    void ShowList()
    {
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        List<MergeRegionRewardsConfig> data = configService.MergeRegionRewardsConfig.Values
            .Where(config => config.id == RegionId)
            .OrderBy(config => config.level)
            .ToList();
        listAdapter.SetData(data);
    }

    void ShowExp()
    {
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var info = dataService.GetRegionInfo(RegionId);
        lvText.text = info.level.ToString();
        int key = RegionId * 1000 + info.level;
        int next = key + 1;
        if (configService.MergeRegionRewardsConfig.ContainsKey(next))
        {
            int max = configService.MergeRegionRewardsConfig[next].exp;
            lvText.text = $"{info.level + 1}";
            lvImgTrans.GetComponent<UIEffect>().enabled = true;
            expText.text = $"{info.exp}/{max}";
            expSlider.value = info.exp / (float)max;
        }
        else
        {
            lvText.text = $"{info.level}";
            lvImgTrans.GetComponent<UIEffect>().enabled = false;
            expText.text = $"{info.addExp}";
            expSlider.value = 1;
        }
    }



}