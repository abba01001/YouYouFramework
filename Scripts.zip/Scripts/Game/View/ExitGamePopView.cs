﻿using Activities;
using Doozy.Engine;
using Doozy.Engine.UI;
using Model;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public enum ShowType
{
    collectCard,
    collectMusic,
    seed,
    rabbit,
    activityItem,
    plus5,
    energy
}

public class ExitGamePopView : ViewBase
{
    [SerializeField] private Button BuyCardBtn;
    [SerializeField] private Button ContinueBtn;
    [SerializeField] private Button ExitBtn;
    [SerializeField] private Button CloseBtn;
    [SerializeField] private Image PanelBg;
    [SerializeField] private Text BuyPlus5Text;
    [SerializeField] private Text BuyPlus5Num;
    [SerializeField] private Text Title;
    private List<ShowType> _showTypes = new List<ShowType>();
    private List<GameObject> pages = new List<GameObject>();
    private int curOpenType = 1;
    private ShowType curShowType = ShowType.plus5;
    private Button sureBtn;
    private Button cancelBtn;
    [SerializeField] private GameObject[] ItemList;
    private Dictionary<ShowType, GameObject> panels = new Dictionary<ShowType, GameObject>();
    private PageScrollView pageScrollView;
    private Dictionary<string, ShopItem> _shopItems = new Dictionary<string, ShopItem>();
    protected override void OnAwake()
    {
        BuyCardBtn.SetButtonClick(() =>
        {
            GameController.Instance.BattleCtrl.gameData.ExitBuyCard();
            RefreshPlusBtn(null);
        });
        ContinueBtn.SetButtonClick(() =>
        {
            GameController.Instance.BattleCtrl.gameData.UsePlus5Card();
            BoxBuilder.HidePopup(gameObject);
        });
        ExitBtn.SetButtonClick(CloseEvent);
        CloseBtn.SetButtonClick(() =>
        {
            if (curOpenType == 1)
            {
                BoxBuilder.HidePopup(gameObject);
            }
            else
            {
                CloseEvent();
            }
        });
        
        panels.Add(ShowType.collectMusic,transform.Get<Transform>("Container/Panel/CollectMusic").gameObject);
        panels.Add(ShowType.collectCard,transform.Get<Transform>("Container/Panel/CollectCard").gameObject);
        panels.Add(ShowType.energy,transform.Get<Transform>("Container/Panel/Energy").gameObject);
        panels.Add(ShowType.plus5,transform.Get<Transform>("Container/Panel/Plus5").gameObject);
        panels.Add(ShowType.rabbit,transform.Get<Transform>("Container/Panel/Rabbit").gameObject);
        panels.Add(ShowType.seed,transform.Get<Transform>("Container/Panel/Seed").gameObject);
        panels.Add(ShowType.activityItem,transform.Get<Transform>("Container/Panel/ActivityItem").gameObject);

        _shopItems.Add("SeasonPassItem",transform.Get<ShopItem>("Container/ShopItemParent/PageScrollItem/Viewport/Content/SeasonPassItem"));
        _shopItems.Add("FirstChargeItem",transform.Get<ShopItem>("Container/ShopItemParent/PageScrollItem/Viewport/Content/FirstChargeItem"));
        _shopItems.Add("TurnItem",transform.Get<ShopItem>("Container/ShopItemParent/PageScrollItem/Viewport/Content/TurnItem"));
        
        var pageTrans = transform.Find("Container/ShopItemParent/Pages");
        for (int i = 0; i < pageTrans.childCount; i++)
        {
            pages.Add(pageTrans.GetChild(i).Get<Transform>("Icon").gameObject);
            pages[i].transform.parent.gameObject.MSetActive(false);
        }
        Title.text = ActivityManager.Instance.EndlessLevelActivity.IsOpenActivity()
            ? $"回合{dataService.NowViewMaxLayer}"
            : $"第 {dataService.NowViewMaxLayer} 关";
        CheckShopItem();
        SetOpenType();
        HandleOpenType(curOpenType);
    }

    private void SetOpenType()
    {
        if (BattleDataMgr.Instance.GetHandCardsNum() > 0)
        {
            curOpenType = 1;
        }
        else
        {
            curOpenType = 2;
        }
    }

    protected override void OnViewInit(bool isFirstTime)
    {
        TypeEventSystem.Register<GameRechargeEvent>(UpdatePanel);
        TypeEventSystem.Register<BuyPlus5Event>(RefreshPlusBtn);
    }

    protected override void OnViewDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatePanel);
        TypeEventSystem.UnRegister<BuyPlus5Event>(RefreshPlusBtn);
    }

    private void UpdatePanel(GameRechargeEvent e)
    {
        RefreshPlusBtn(null);
        CheckShopItem();
    }

    private void CheckShopItem()
    {
        pageScrollView = transform.Get<PageScrollView>("Container/ShopItemParent/PageScrollItem");
        SetShopItem();

        pageScrollView.InitParams(null, UpdatePage, true, 0);
        int index = 0;
        var count = pageScrollView.GetComponent<ScrollRect>().content.transform.childCount;
        foreach (var obj in pages)
        {
            obj.transform.parent.gameObject.MSetActive(index < count);
            obj.gameObject.MSetActive(index == count - 1);
            index++;
        }
    }
    
    
    private void SetShopItem()
    {
        bool hasSmallFirstCharge = dataService.IsSmallBuyBeginner;
        bool hasFirstCharge = dataService.IsBuyBeginner;
        string productId = "";
        foreach (var pair in _shopItems)
        {
            pair.Value.gameObject.MSetActive(false);
        }
        
        _shopItems["SeasonPassItem"].gameObject.MSetActive(GameUtils.CheckFuncIsUnlock("seasonPass"));
        _shopItems["SeasonPassItem"].GetComponent<ShopItem>().SetPageShopItem(Constants.ProductId.SeasonPass);
        if (!dataService.IsSmallBuyBeginner)
        {
            _shopItems["FirstChargeItem"].gameObject.MSetActive(GameUtils.CheckFuncIsUnlock("giftTimeOne"));
            _shopItems["FirstChargeItem"].GetComponent<ShopItem>().SetPageShopItem(Constants.ProductId.SmallFirstPayment);
        }
        else
        {
            if (!dataService.IsBuyBeginner)
            {
                _shopItems["FirstChargeItem"].gameObject.MSetActive(GameUtils.CheckFuncIsUnlock("giftFirst"));
                _shopItems["FirstChargeItem"].GetComponent<ShopItem>().SetPageShopItem(Constants.ProductId.FirstPayment);
            }
        }
        _shopItems["TurnItem"].gameObject.MSetActive(GameUtils.CheckFuncIsUnlock("giftLimit"));
        _shopItems["TurnItem"].GetComponent<ShopItem>().SetPageShopItem("Turn");
    }
    
    
    
    private void UpdatePage(int pageIndex)
    {
        foreach (var obj in pages)
        {
            obj.MSetActive(false);
        }
        pages[pageIndex].MSetActive(true);
    }
    

    void ShowRestartGamePopup()
    {
        TypeEventSystem.Send(new BattleCommandEvent() { command = BattleCommand.LoseGame });
        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(0.2f);
        GameController.Instance.ExitBattle();
        MoveGameViewBottom t = GameObjManager.Instance.PopClass<MoveGameViewBottom>(true);
        TypeEventSystem.Send<MoveGameViewBottom>(t);
        seq.AppendCallback(() =>
        {
            BoxBuilder.HidePopup(gameObject,true);
            if(ActivityManager.Instance.LavaPassActivity.CheckShowLavaPopup(BoxBuilder.ShowRestartPopup)) return;
            BoxBuilder.ShowRestartPopup();
        });
        ActivityManager.Instance.SaveActivityData();
    }

    protected override void OnShow()
    {
        CloseEvent();
    }

    private void CloseEvent()
    {
        if (_showTypes.Count == 0)
        {
            ShowRestartGamePopup();
        }
        else
        {
            foreach (var pair in panels)
            {
                pair.Value.gameObject.MSetActive(false);
            }
            curShowType = _showTypes[0];
            string panelBg = "";
            switch (curShowType)
            {
                case ShowType.collectCard:
                    panelBg = "ecqr_tc_tc_3";
                    break;
                case ShowType.collectMusic:
                    panelBg = "ecqr_tc_tc_3";
                    break;
                case ShowType.seed:
                    panelBg = "ecqr_tc_tc_3";
                    break;
                case ShowType.rabbit:
                    panelBg = "ecqr_tc_tc_3";
                    break;
                case ShowType.plus5:
                    panelBg = "ecqr_tc_gm";
                    break;
                case ShowType.activityItem:
                    panelBg = "ecqr_tc_tc_3";
                    break;
                case ShowType.energy:
                    panelBg = "ecqr_tc_tc_1";
                    break;
                default:
                    break;
            }

            PanelBg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewExitGameAtlas, panelBg, true);
            ExitBtn.gameObject.MSetActive(curOpenType == 1);
            BuyCardBtn.gameObject.MSetActive(false);
            ContinueBtn.gameObject.MSetActive(false);
            panels[curShowType].gameObject.MSetActive(true);
            RefreshCollect(curShowType,panels[curShowType]);
            _showTypes.RemoveAt(0);
            RefreshPlusBtn(null);
            RefreshActivityItem();
        }
    }

    private void RefreshCollect(ShowType showType,GameObject obj)
    {
        if (showType == ShowType.collectMusic)
        {
            SetCollectMusicReward(obj.transform);
        }
        if (showType == ShowType.collectCard)
        {
            SetCollectLoveCardReward(obj.transform);
        }
    }
    
    private void SetCollectLoveCardReward(Transform obj)
    {
        Transform propItem = obj.Get<Transform>("Progress/NextRewardItem");
        if (ActivityManager.Instance.CollectLoveCardActivity.CurIsMaxLayer())
        {
            propItem.gameObject.SetActive(false);
            return;
        }
        
        int nextCount = ActivityManager.Instance.CollectLoveCardActivity.GetNextLayerCollectCount();
        int curCount = ActivityManager.Instance.CollectLoveCardActivity.GetCurLayerCollectCount();
        obj.Get<Text>("Progress/Text").text = $"{curCount}/{nextCount}";
        obj.Get<Image>("Progress/FillAmount").transform.localScale = new Vector3(ActivityManager.Instance.CollectMusicActivity.GetRatio() * 0.75f,0.75f,0.75f);
        
        propItem.gameObject.SetActive(true);
        foreach (var tempItem in ActivityManager.Instance.CollectLoveCardActivity.GetNextReward())
        {
            int propEnum = int.Parse(tempItem.type.ToString());
            int propCount = tempItem.amount;
            Image propImage = propItem.transform.Get<Image>("PropImage");
            Text timeText = propItem.transform.Get<Text>("TimeText");
            Text numText = propItem.transform.Get<Text>("NumText");
            numText.text = "";
            timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward((int)propEnum));
            if (GameUtils.IsLimitTimeReward((int)propEnum))
            {
                long infiniteTime = propCount;
                timeText.text = infiniteTime / 60 + "m";
            }
            else
            {
                numText.text = propEnum == (int)PropEnum.Coin ? propCount.ToString() : $"x{propCount}";
            }
            propImage.LoadPropSprite(propEnum == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : (int)propEnum);
            break;
        }
    }

    private void SetCollectMusicReward(Transform obj)
    {
        Transform propItem = obj.Get<Transform>("Progress/NextRewardItem");
        if (ActivityManager.Instance.CollectMusicActivity.CurIsMaxLayer())
        {
            propItem.gameObject.SetActive(false);
            return;
        }

        int nextCount = ActivityManager.Instance.CollectMusicActivity.GetNextLayerCollectCount();
        int curCount = ActivityManager.Instance.CollectMusicActivity.GetCurLayerCollectCount();
        obj.Get<Text>("Progress/Text").text = $"{curCount}/{nextCount}";
        obj.Get<Image>("Progress/FillAmount").transform.localScale = new Vector3(ActivityManager.Instance.CollectMusicActivity.GetRatio() * 0.75f,0.75f,0.75f);

        propItem.gameObject.SetActive(true);
        Dictionary<int, int> rewardList = ActivityManager.Instance.CollectMusicActivity.GetNextReward();
        var box = propItem.transform.Get<Transform>("Box");
        var item = propItem.transform.Get<Transform>("Item");
        box.gameObject.SetActive(rewardList.Count > 1);
        item.gameObject.SetActive(rewardList.Count == 1);
        if (rewardList.Count == 1)
        {
            foreach (var pair in rewardList)
            {
                Image propImage = item.transform.Get<Image>("PropImage");
                Text timeText = item.transform.Get<Text>("TimeText");
                Text numText = item.transform.Get<Text>("NumText");
                numText.text = "";
                timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward((int)pair.Key));
                if (GameUtils.IsLimitTimeReward((int)pair.Key))
                {
                    long infiniteTime = pair.Value;
                    timeText.text = infiniteTime / 60 + "m";
                }
                else
                {
                    numText.text = pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
                }

                propImage.LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : (int)pair.Key);
                break;
            }
        }
    }
    
    private void RefreshActivityItem()
    {
        foreach (var obj in ItemList)
        {
            obj.MSetActive(false);
        }
        int index = 0;
        foreach (var model in ActivityManager.Instance.GetCollectActivity())
        {
            BaseActivityData data = ActivityManager.Instance.GetActivityByType(model.type).localData as BaseActivityData;
            if (data.ResultAddCount > 0)
            {
                if(index >= ItemList.Length) return;
                ItemList[index].gameObject.MSetActive(true);
                var icon = ItemList[index].Get<Image>("Icon");
                var text = ItemList[index].Get<Text>("Text");
                icon.SetSpriteByAtlas(Constants.AtlasNamePath.TextureCommonAtlas, GameUtils.GetCollectIcon(model.type), true, () =>
                {
                    float targetHeight = 100;
                    float targetWidth = 80;
                    float originalWidth = icon.sprite.rect.width;
                    float originalHeight = icon.sprite.rect.height;
                    float aspectRatio = originalWidth / originalHeight;
                    float newWidth;
                    float newHeight;
                    if (originalHeight >= originalWidth)
                    {
                        newHeight = targetHeight;
                        newWidth = targetHeight * aspectRatio;
                    }
                    else
                    {
                        newWidth = targetWidth;
                        newHeight = targetWidth / aspectRatio;
                    }
                    icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
                });
                text.text = data.ResultAddCount.ToString();
                index++;
            }
        }
    }

    private void RefreshPlusBtn(BuyPlus5Event obj)
    {
        if(curShowType == ShowType.energy || curOpenType == 1) return;
        bool hasPlus5 = dataService.GetPropNum((int) PropEnum.FreeBuyCard) > 0;
        BuyCardBtn.gameObject.MSetActive(!hasPlus5);
        ContinueBtn.gameObject.MSetActive(hasPlus5);
        BuyPlus5Text.text = hasPlus5 ? "使用+5手牌继续游戏" : "购买+5手牌继续游戏";
        BuyPlus5Num.text = GameController.Instance.BattleCtrl.gameData.GetNowBuyCardCost().ToString();
    }

    private void HandleOpenType(int type)
    {
        if (type == 1)
        {
            if (curOpenType == 1)
            {
                if (!GameUtils.IsSpecialLevel() && ActivityManager.Instance.EnergyActivity.GetInfiniteSecond() <= 0)
                {
                    _showTypes.Add(ShowType.energy);
                }
            }
            if (ActivityManager.Instance.CollectLoveCardActivity.CheckReadyFull())
            {
                _showTypes.Add(ShowType.collectCard);
            }
            if (ActivityManager.Instance.CollectMusicActivity.CheckReadyFull())
            {
                _showTypes.Add(ShowType.collectMusic);
            }
            else if (ActivityManager.Instance.MysteriousSeedActivity.CheckFinalBallon())
            {
                _showTypes.Add(ShowType.seed);
            }
            else if (ActivityManager.Instance.RabbitGiftActivity.CheckLoseThreeWin())
            {
                _showTypes.Add(ShowType.rabbit);
            }
            //处理活动资源
            if (ActivityManager.Instance.GetCollectActivity().Count > 0)
            {
                _showTypes.Add(ShowType.activityItem);
            }
        }
        else
        {
            //弹出加5牌。
            _showTypes.Add(ShowType.plus5);
            HandleOpenType(1);
            
            //            TypeEventSystem.Send<BuyCardsEvent>();
        }
    }
}
