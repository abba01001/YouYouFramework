using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using DG.Tweening;
using Model;
using UniRx;

[RequireComponent(typeof(CanvasGroup))]
public class GradientGiftPopView : ViewBase
{
    int waitToLevel = -1;
    List<int> selectItem = new List<int>(3);

    private Button CloseBtn;
    private Text TitleText;
    private Text TipText;
    private Dictionary<int, GradientItem> itemList = new Dictionary<int, GradientItem>(); 
    ActivityTimeItem timeItem;

    
    private Vector2[] targetPos = new Vector2[]
    {
        new Vector2(-344.5f,0),
        new Vector2(0f,0),
        new Vector2(344.5f,0),
        new Vector2(689,0),
        new Vector2(689,-299),
        new Vector2(344.5f,-299),
        new Vector2(0,-299),
    };
    
    
    protected override void OnAwake()
    {
        Button backCloseBtn = transform.Get<Button>("Overlay");
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        TitleText = transform.Get<Text>("Container/TitleText");
        backCloseBtn.interactable = false;
        backCloseBtn.SetButtonClick(CloseFunc);
        CloseBtn.SetButtonClick(CloseFunc);
        for (int i = 1; i <= 7; i++)
        {
            itemList.Add(i,transform.Get<GradientItem>($"Container/ScrollView/Content/Item{i}"));
        }
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        InitPanel();
        RefreshTimer(null);
    }

    private void InitPanel()
    {
        int startIndex = ActivityManager.Instance.GradientGiftActivity.GetStartIndex();
        if (startIndex > configService.GradientConfig.Count)
        {
            foreach (var temp in itemList)
            {
                temp.Value.gameObject.SetActive(false);
            }
            return;
        }
        int count = 1;
        for (int i = startIndex; i <= startIndex + 6; i++)
        {
            itemList[count].SetData(i);
            count++;
        }
    }

    public void UpdatePanel(UpdateGradientGift obj)
    {
        int startIndex = ActivityManager.Instance.GradientGiftActivity.GetStartIndex();
        if (startIndex > configService.GradientConfig.Count)
        {
            ActivityManager.Instance.GradientGiftActivity.CheckFinishActivity();
            CloseFunc();
            return;
        }
        FxMaskView.Instance.BlockOperation(true);
        Sequence seq = DOTween.Sequence();
        
        SoundPlayer.Instance.PlayMainSound("GradientGift_Move");
        for (int i = 1; i <= 7; i++)
        {
            if (i == 1)
            {
                HandleFirstItemAnim(itemList[i]);
                continue;
            }
            seq.Join(itemList[i].GetComponent<RectTransform>().DOAnchorPos(targetPos[i - 1], 30f / 60));
        }

        seq.AppendCallback(() =>
        {
            HandleSort();
            int count = 1;
            for (int i = startIndex; i <= startIndex + 6; i++)
            {
                itemList[count].SetData(i);
                count++;
            }
            FxMaskView.Instance.BlockOperation(false);
        });
    }

    private void HandleFirstItemAnim(GradientItem item,bool reset = false)
    {
        RectTransform rect = item.transform.Get<RectTransform>("Reward");
        if (reset)
        {
            rect.anchoredPosition = new Vector2(rect.anchoredPosition.x, rect.anchoredPosition.y - 60);
            rect.GetComponent<CanvasGroup>().alpha = 1;
            item.ResetLockObj();
            return;
        }
        rect.DOAnchorPos(new Vector2(rect.anchoredPosition.x, rect.anchoredPosition.y + 60), 0.3f);
        rect.GetComponent<CanvasGroup>().DOFade(0f,0.3f);
    }
    
    private void HandleSort()
    {
        Dictionary<int, GradientItem> tempList = new Dictionary<int, GradientItem>();
        for (int i = 2; i <= 7; i++)
        {
            tempList.Add(i-1,itemList[i]);
        }
        tempList.Add(7,itemList[1]);
        for (int i = 1; i <= 7; i++)
        {
            tempList[i].name = $"Item{i}";
            tempList[i].gameObject.SetActive(false);
        }
        tempList[7].GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -601);
        HandleFirstItemAnim(tempList[7], true);
        itemList = tempList;
    }
    
    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnRefresh()
    {
        base.OnRefresh();
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
        TypeEventSystem.Register<UpdateGradientGift>(UpdatePanel);
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (ActivityManager.Instance.GetActivityByType(ActivityType.gradientGift) != null && ActivityManager.Instance.GetActivityByType(ActivityType.gradientGift).state 
                is ActivityState.waitEntry or ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.gradientGift).ActivityBigEndTime);
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.gradientGift).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.GradientGiftProgress.ActivityEndTime);
        }
        timeItem.SetTimeData(timeData);
    }
    
    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
        TypeEventSystem.UnRegister<UpdateGradientGift>(UpdatePanel);
    }
    protected override async void OnShow()
    {

    }
    
}