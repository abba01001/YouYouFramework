﻿using SoliUtils;
using UnityEngine;
using UnityEngine.UI;

public class BoxLessView : ViewBase
{

    protected override void OnAwake()
    {
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(CloseFunc);
        transform.Get<Button>("Container/StartBtn").SetButtonClick(StartFunc);
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    private void StartFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
        BoxBuilder.ShowStartGamePopup();
    }
}