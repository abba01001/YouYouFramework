﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using QFramework;
using DG.Tweening;
using SoliUtils;
using System;
using System.Linq;
using UniRx;

public enum ShopItemEnum
{
    SeasonPassShopItem = 1,
    BigShopItem = 2,
    SmallShopItem = 3,
    LimitShopItem = 4,
    PassShopItem = 5,
}

public class ShopInfo
{
    public string productKey;
    public string objectName;
    public ShopItemEnum itemType;
    public ShopInfo(string _productKey, string _objectName, ShopItemEnum _itemType)
    {
        productKey = _productKey;
        objectName = _objectName;
        itemType = _itemType;

    }

    public bool IsShow()
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        if (configService.ShopConfig.TryGetValue(productKey, out ShopModel model))
        {
            return model.unlock == 1;
        }
        return false;
    }

}

public class ShopPopView : ViewBase
{
    private Transform coinLayout;
    private Transform mergeLayout;
    private Transform coinWholeScroll;
    private Button backBtn;
    private Tween showTween;
    private Transform itemParent;
    private Transform smallItemParent;
    private bool isLoading = false;
    private List<ShopItem> itemList = new List<ShopItem>();

    private GameObject BigShopItem;
    private GameObject SmallShopItem;
    private GameObject SeasonPassShopItem;
    private GameObject LimitShopItem;
    private GameObject PassShopItem;

    private ActivityTimeItem timeItem;
    private GameObject mergeBubble;

    private static readonly List<ShopInfo> shopWholeList = new List<ShopInfo>()
    {
        
        // new ShopInfo(Purchaser.BattlePassProductKey, "product_season"),
        new ShopInfo("SeasonPass", "1",ShopItemEnum.SeasonPassShopItem),
        new ShopInfo("WeeklySubscription", "2",ShopItemEnum.BigShopItem),
        new ShopInfo("MonthlySubscription", "3",ShopItemEnum.BigShopItem),
        new ShopInfo("DailyPurchaseLimit_1", "4",ShopItemEnum.LimitShopItem),
        new ShopInfo("WeeklyPurchaseLimit_1", "5",ShopItemEnum.LimitShopItem),
        new ShopInfo("MonthlyPurchaseLimit_1", "6",ShopItemEnum.LimitShopItem),

        new ShopInfo("PropsPack_1", "7",ShopItemEnum.PassShopItem),
        new ShopInfo("PropsPack_2", "8",ShopItemEnum.PassShopItem),
        new ShopInfo("PropsPack_3", "9",ShopItemEnum.PassShopItem),
        new ShopInfo("PropsPack_4", "10",ShopItemEnum.PassShopItem),
        new ShopInfo("PropsPack_5", "11",ShopItemEnum.PassShopItem),
        new ShopInfo("PropsPack_6", "12",ShopItemEnum.PassShopItem),

        new ShopInfo("CoinsPack_1", "Small/13",ShopItemEnum.SmallShopItem),
        new ShopInfo("CoinsPack_2", "Small/14",ShopItemEnum.SmallShopItem),
        new ShopInfo("CoinsPack_3", "Small/15",ShopItemEnum.SmallShopItem),
        new ShopInfo("CoinsPack_4", "Small/16",ShopItemEnum.SmallShopItem),
        new ShopInfo("CoinsPack_5", "Small/17",ShopItemEnum.SmallShopItem),
        new ShopInfo("CoinsPack_6", "Small/18",ShopItemEnum.SmallShopItem),
        new ShopInfo("CoinsPack_7", "Small/19",ShopItemEnum.SmallShopItem),
        new ShopInfo("CoinsPack_8", "Small/20",ShopItemEnum.SmallShopItem),
    };

    protected override void OnAwake()
    {
        coinLayout = transform.Find("Container/Layout1");
        mergeLayout = transform.Find("Container/Layout2");
        mergeBubble = transform.Find("Container/MergeBubble").gameObject;
        mergeBubble.gameObject.SetActive(false);

        coinWholeScroll = coinLayout.Find("WholeScroll");
        itemParent = coinWholeScroll.Find("Content");
        smallItemParent = coinWholeScroll.Find("Content/Small");
        backBtn = transform.Get<Button>("Container/Button - Back");
        BigShopItem = transform.Get<Transform>("Container/BigShopItem").gameObject;
        BigShopItem.SetActive(false);
        SmallShopItem = transform.Get<Transform>("Container/SmallShopItem").gameObject;
        SmallShopItem.SetActive(false);
        LimitShopItem = transform.Get<Transform>("Container/LimitShopItem").gameObject;
        LimitShopItem.SetActive(false);
        PassShopItem = transform.Get<Transform>("Container/PassShopItem").gameObject;
        PassShopItem.SetActive(false);
        SeasonPassShopItem = transform.Get<Transform>("Container/SeasonPassShopItem").gameObject;
        SeasonPassShopItem.SetActive(false);
        backBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
            showTween?.Kill();
            showTween = null;
            dataService.ReceiveMergeShopItems();
        });

        var toggleCoin = transform.Get<Toggle>("Container/Tab/ToggleCoin");
        var toggleMerge = transform.Get<Toggle>("Container/Tab/ToggleMerge");

        toggleCoin.onValueChanged.AddListener(delegate
        {
            coinLayout.gameObject.SetActive(true);
            mergeLayout.gameObject.SetActive(false);
            toggleCoin.transform.Get<Text>("Label").color = new Color32(255, 232, 105, 255);
            toggleMerge.transform.Get<Text>("Label").color = new Color32(215, 146, 107, 255);
        });
        toggleMerge.onValueChanged.AddListener(delegate
        {
            coinLayout.gameObject.SetActive(false);
            mergeLayout.gameObject.SetActive(true);
            toggleMerge.transform.Get<Text>("Label").color = new Color32(255, 232, 105, 255);
            toggleCoin.transform.Get<Text>("Label").color = new Color32(215, 146, 107, 255);
            RefreshMergeShopSize();
        });
        toggleCoin.isOn = false;
        toggleCoin.isOn = true;

        timeItem = mergeLayout.Get<ActivityTimeItem>("ActivityTimeItem");
        RefreshTimer();
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<PurchaseSuccess>(OnPurchaseSuccess);
        TypeEventSystem.Register<GlobalTimerRefreshEvent>(OnGlobalTimerRefreshEvent);
        TypeEventSystem.Register<GameRechargeEvent>(UpdatPanel);
        TypeEventSystem.Register<BuyItemFromMergeShop>(OnBuyItemFromMergeShop);

    }

    private void UpdatPanel(GameRechargeEvent obj)
    {
        RefreshProduct();
        CheckShowLimitItem();
    }

    protected override void OnViewDestroy()
    {
        TypeEventSystem.UnRegister<PurchaseSuccess>(OnPurchaseSuccess);
        TypeEventSystem.UnRegister<GlobalTimerRefreshEvent>(OnGlobalTimerRefreshEvent);
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatPanel);
        TypeEventSystem.UnRegister<BuyItemFromMergeShop>(OnBuyItemFromMergeShop);
        if (!GameObjManager.IsNull())
        {
            foreach (var shopItem in itemList)
            {
                GameObjManager.Instance.PushGameObject(shopItem.gameObject);
            }
        }
    }

    protected override void OnShow()
    {
        CreateShopItem();
        IEnumerator Refresh()
        {
            while (isLoading)
            {
                yield return null;
            }
            RefreshProduct();
            ShowTween();
        }

        StartCoroutine(Refresh());
    }

    private void CreateShopItem()
    {
        isLoading = true;
        GameObject Init(GameObject obj, Transform parent, int index)
        {
            obj.transform.SetParent(parent);
            obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            obj.transform.localScale = Vector3.one;
            obj.transform.name = index.ToString();

            obj.SetActive(true);
            if (!shopWholeList[index - 1].IsShow()) obj.SetActive(false);
            if (index is 4 or 5 or 6)
            {
                FlagType type = index == 4 ? FlagType.DailyBuy : index == 5 ? FlagType.WeekBuy : FlagType.MonthBuy;
                bool isShow = !dataService.CheckTimeFlag(type);
                obj.SetActive(isShow);
            }
            if (index >= shopWholeList.Count)
            {
                isLoading = false;
                smallItemParent.SetAsLastSibling();
            }
            return obj;
        }

        int index = 1;
        foreach (var info in shopWholeList)
        {
            GameObjType objType;
            Transform parent = itemParent;
            GameObject obj;
            if (info.itemType == ShopItemEnum.SeasonPassShopItem)
            {
                objType = GameObjType.SeasonPassShopItem;
                obj = SeasonPassShopItem;
            }
            else if (info.itemType == ShopItemEnum.BigShopItem)
            {
                objType = GameObjType.BigShopItem;
                obj = BigShopItem;
            }
            else if (info.itemType == ShopItemEnum.LimitShopItem)
            {
                objType = GameObjType.LimitShopItem;
                obj = LimitShopItem;
            }
            else if (info.itemType == ShopItemEnum.PassShopItem)
            {
                objType = GameObjType.PassShopItem;
                obj = PassShopItem;
            }
            else
            {
                objType = GameObjType.SmallShopItem;
                parent = smallItemParent;
                obj = SmallShopItem;
            }
            GameObject item = Init(GameObjManager.Instance.PopGameObject(objType, obj), parent, index);
            itemList.Add(item.GetComponent<ShopItem>());
            item.GetComponent<ShopItem>().SetShopInfo(info, transform);
            index++;
        }
    }

    private void CheckShowLimitItem()
    {
        itemList[3].gameObject.SetActive(!dataService.CheckTimeFlag(FlagType.DailyBuy));
        itemList[4].gameObject.SetActive(!dataService.CheckTimeFlag(FlagType.WeekBuy));
        itemList[5].gameObject.SetActive(!dataService.CheckTimeFlag(FlagType.MonthBuy));
    }

    private void RefreshProduct()
    {
        if (!gameObject.activeSelf) return;
        if (itemList.Count == 0) return;
        int index = 0;
        foreach (var shopInfo in shopWholeList)
        {
            itemList[index].SetShopInfo(shopInfo, transform);
            index++;
        }
    }

    private void ShowTween(float delay = 0)
    {
        int index = 0;
        float showTime = 0.4f;
        float interval = 0.07f;
        Sequence seq = DOTween.Sequence();
        seq.SetId(gameObject);
        shopWholeList.ForEach(info =>
        {
            if (index > 5) return;
            RectTransform shopTrans = coinWholeScroll.Get<RectTransform>($"Content/{info.objectName}");
            if (shopTrans && shopTrans.gameObject.activeSelf)
            {
                CanvasGroup canvasGroup = shopTrans.GetComponent<CanvasGroup>();
                canvasGroup.alpha = 0;
                RectTransform content = shopTrans.Get<RectTransform>("ProductContent");
                Vector2 origPos = content.anchoredPosition;
                content.anchoredPosition = origPos + new Vector2(150, 0);
                Sequence showSeq = DOTween.Sequence();
                showSeq.Append(content.DOAnchorPos(origPos, showTime).SetEase(Ease.OutCubic));
                showSeq.Join(canvasGroup.DOFade(1, showTime).SetEase(Ease.OutQuad));
                seq.Insert(interval * index + delay, showSeq);

                index++;
            }
        });
        showTween = seq;
        seq.OnComplete(() => showTween = null);
    }

    private void OnRewardAdvertisingFinish()
    {
        if (dataService.TodayWatchShopAdTime >= configService.CoinRewardVideoDailyTimes) return;
        dataService.TodayWatchShopAdTime++;
        var rewardDic = new Dictionary<int, int>() { { (int)PropEnum.Coin, configService.CoinRewardVideoValue } };
        BoxBuilder.ShowRewardPop(rewardDic, PropChangeWay.ShopAd);
        RefreshProduct();
    }

    private void OnPurchaseSuccess(PurchaseSuccess obj)
    {
        // if (obj.productKey == Purchaser.FirstChargeProductKey)
        // {
        //     dataService.IsBuyBeginner = true;
        //     dataService.BeginnerGiftEndTime = TimeUtils.UtcNow();
        //     dataService.NowTriggerGiftEndTime = dataService.BeginnerGiftEndTime;
        //     RefreshProduct();
        // }
        // string productId = obj.purchasedProduct.definition.id;
        // string rewardStr = configService.ShopConfig[productId].reward;
        // if (!string.IsNullOrEmpty(rewardStr))
        //     BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(rewardStr), PropChangeWay.Shop);
    }

    private void OnGlobalTimerRefreshEvent(GlobalTimerRefreshEvent obj)
    {
        // if (triggerGiftTimeText.gameObject.activeInHierarchy)
        // {
        //     TimeSpan sp = TimeSpan.FromSeconds(dataService.NowTriggerGiftEndTime - TimeUtils.UtcNow());
        //     if (sp.Days > 0)
        //         triggerGiftTimeText.text = string.Format("{0:D2}D {1:D2}:{2:D2}:{3:D2}", sp.Days, sp.Hours, sp.Minutes, sp.Seconds);
        //     else
        //         triggerGiftTimeText.text = string.Format("{0:D2}:{1:D2}:{2:D2}", sp.Hours, sp.Minutes, sp.Seconds);
        // }
    }

    void RefreshMergeShopSize()
    {
        var info = dataService.GetMergeShopData();
        if(info == null)
            return;
        float itemWidth = 340;
        float space = 20;
        float width = info.items.Length * itemWidth + (info.items.Length - 1) * space;
        float screenWidth = Screen.width / (float)Screen.height * 750;
        if (width < screenWidth)
        {
            Transform sc = mergeLayout.Get<Transform>("ScrollView");
            Transform content = sc.Get<Transform>("Content");
            var size = sc.GetComponent<RectTransform>().sizeDelta;
            size.x = width;
            sc.GetComponent<RectTransform>().sizeDelta = size;
            content.GetComponent<RectTransform>().sizeDelta = size;
            sc.transform.GetComponent<ScrollRect>().enabled = false;
            ListView lv = content.GetComponent<ListView>();
            Observable.TimerFrame(1).Subscribe((_) =>
            {
                lv.ReFillData();
                // lv.RefreshData();
            });
        }

    }

    void RefreshTimer()
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>(true);
        timeData.Clear();
        DateTime today = DateTime.Today;
        timeData.endTime = today.AddDays(1).AddSeconds(-1);
        timeItem.SetTimeData(timeData);
    }

    void RefreshMergeBubble()
    {
        var info = dataService.GetMergeShopData();
        if (info.storage != null)
        {
            mergeBubble.SetActive(true);
            ShowItems(info.storage.ToList());
        }
    }

    Sequence seq;
    List<int> items;
    int itemIndex;
    public void ShowItems(List<int> _items = null)
    {
        if (seq != null)
        {
            DOTween.Kill(seq);
            seq = null;
        }
        if (_items != null)
            items = _items;

        itemIndex = (++itemIndex) % items.Count;

        var itemId = items[itemIndex];
        var iconTrans = mergeBubble.Get<Transform>("Icon");
        iconTrans.DOKill();
        iconTrans.DOScale(Vector3.one * 0.1f, 0.2f).SetEase(Ease.InSine).OnComplete(() =>
        {
            iconTrans.DOScale(Vector3.one, 0.2f).SetEase(Ease.InSine).OnComplete(() =>
            {
                if (seq != null)
                {
                    DOTween.Kill(seq);
                    seq = null;
                }
                seq = DOTween.Sequence();
                seq.AppendInterval(3);
                seq.AppendCallback(() =>
                {
                    var info = dataService.GetMergeShopData();
                    if (info.storage != null)
                        ShowItems(info.storage.ToList());
                    seq = null;
                });
                seq.SetTarget(seq);
            });
            var icon = iconTrans.GetComponent<Image>();
            icon.LoadPropSprite(itemId, true, () =>
            {
                float targetHeight = 55;
                float targetWidth = 55;
                float originalWidth = icon.sprite.rect.width;
                float originalHeight = icon.sprite.rect.height;
                float aspectRatio = originalWidth / originalHeight;
                float newWidth;
                float newHeight;
                if (originalHeight >= originalWidth)
                {
                    newHeight = targetHeight;
                    newWidth = targetHeight * aspectRatio;
                }
                else
                {
                    newWidth = targetWidth;
                    newHeight = targetWidth / aspectRatio;
                }
                icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
            });
        });
    }

    private void OnBuyItemFromMergeShop(BuyItemFromMergeShop e)
    {
        Transform sc = mergeLayout.Get<Transform>("ScrollView");
        Transform content = sc.Get<Transform>("Content");
        ListView lv = content.GetComponent<ListView>();

        RefreshMergeBubble();

        var icon = mergeBubble.transform.Get<Image>("Icon");
        var obj = (lv.Adapter as MergeShopAdapter).GetCellObject(e.idx);
        if (obj != null)
        {
            MergeShopItemCell cell = obj.GetComponent<MergeShopItemCell>();
            var newIcon = GameObject.Instantiate(cell.iconImg.gameObject, icon.transform.parent);
            newIcon.transform.position = obj.transform.position;
            newIcon.transform.DOScale(0.3f, 0.5f);
            newIcon.transform.DOCurMove(icon.transform.position, 0.5f).OnComplete(() =>
            {
                GameObject.Destroy(newIcon.gameObject);
            });
        }

        Observable.TimerFrame(10).Subscribe((_) =>
        {
            lv.RefreshData();
        });

    }
}
