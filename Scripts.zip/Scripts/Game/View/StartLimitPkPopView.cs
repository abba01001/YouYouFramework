using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using DG.Tweening;
using Model;
using UniRx;

[RequireComponent(typeof(CanvasGroup))]
public class StartLimitPkPopView : ViewBase
{
    private Text TipText;
    private Text EnterBtnText;
    private Transform CloseBtn;
    private IDisposable subscription;
    private IDisposable subscription1;
    private ActivityTimeItem timeItem;
    private Action btnEvent;
    private string uiType = "";
    private bool InitFinish = false;
    private Animator startAnimator;
    private Animator headAnimator;
    private bool isPlayingAnim = false;
    private GameObject LeftWinFlag;
    private GameObject LeftWinEf;
    private GameObject RightWinFlag;
    private GameObject RightWinEf;
    private GameObject Progress;
    [SerializeField]private Image[] headList;
    [SerializeField]private Image headLImage;
    [SerializeField] private GameObject myWinFlag;
    [SerializeField] private GameObject robotWinFlag;
    protected override void OnAwake()
    {
        TipText = transform.Get<Text>("Container/StartContent/TipText");
        Progress = transform.Get<Transform>("Container/StartContent/Progress").gameObject;
        Progress.SetActive(true);
        LeftWinFlag = transform.Get<Transform>("Container/StartContent/Progress/Left/Bg/WinFlag").gameObject;
        LeftWinEf = transform.Get<Transform>("Container/StartContent/Progress/Left/Effect").gameObject;
        RightWinFlag = transform.Get<Transform>("Container/StartContent/Progress/Right/Bg/WinFlag").gameObject;
        RightWinEf = transform.Get<Transform>("Container/StartContent/Progress/Right/Effect").gameObject;
        EnterBtnText = transform.Get<Text>("Container/StartContent/EnterBtn/Text");
        //transform.Get<Button>("Overlay").SetButtonClick(CloseFunc);
        CloseBtn = transform.Get<Transform>("Container/StartContent/CloseBtn");
        CloseBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            if (uiType == "result")
            {
                ActivityManager.Instance.LimitPkActivity.CheckGetReward(CloseFunc);
            }
            CloseFunc();
        });
        CloseBtn.gameObject.SetActive(true);
        transform.Get<Button>("Container/StartContent/EnterBtn").SetButtonClick(EnterGameFunc);
        timeItem = transform.Get<ActivityTimeItem>("Container/StartContent/ActivityTimeItem");
        startAnimator = transform.Get<Animator>("Container/StartContent");
        startAnimator.enabled = false;
        headAnimator = transform.Get<Animator>("Container/StartContent/Progress/Right/Bg/Mask");
        headAnimator.enabled = false;
        InitFinish = true;
        SetBg(uiType);
        transform.Get<Button>("Container/StartContent/TipBtn").SetButtonClick(BoxBuilder.ShowUnlockLimitPkPopup);
        WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
        {
            if (ret)
            {
                var nameTrans = transform.Get<Text>("Container/StartContent/Progress/Left/Bg/Name");
                
                if(nameTrans == null) return;
                nameTrans.text = dataService.UserName;
                transform.Get<Text>("Container/BattleContent/Left/Bg/Name").text = dataService.UserName;
                
                //设置头像
                var tex = SpriteUtils.ReadTexture(filePath);
                if (tex != null)
                {
                    transform.Get<Image>("Container/StartContent/Progress/Left/Bg/Mask/Icon2").sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                    transform.Get<Image>("Container/BattleContent/Left/Bg/Icon").sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                }
            }
        });
    }

    public void SetBg(string type)
    {
        uiType = type;
        if (!InitFinish || uiType == "") return;
        bool EnableTime = true;
        string tip = "";
        string btnText = "";
        timeItem.gameObject.SetActive(false);

        transform.Get<Transform>("Container/StartContent").gameObject.SetActive(type == "start" || type == "result" || type == "matchSuccess");
        transform.Get<Transform>("Container/BattleContent").gameObject.SetActive(type == "battle");

        transform.Get<Text>("Container/StartContent/Progress/Bg/LeftValue/Value").text = $"{dataService.LimitPkData.MyIntegral}";
        transform.Get<Text>("Container/StartContent/Progress/Bg/RightValue/Value").text = $"{dataService.LimitPkData.RobotIntegral}";
        transform.Get<Text>("Container/StartContent/Progress/Left/Bg/Name").text = dataService.UserName;
        transform.Get<Text>("Container/BattleContent/Left/Bg/Name").text = dataService.UserName;
        if (dataService.LimitPkData.RobotName == "")
        {
            var id = GameUtils.GetRandomRobotID();
            dataService.LimitPkData.RobotName = GameUtils.GetRobotInfo(id).name;
        }
        transform.Get<Text>("Container/StartContent/Progress/Right/Bg/Name").text = dataService.LimitPkData.RobotName;
        transform.Get<Text>("Container/BattleContent/Right/Bg/Name").text = dataService.LimitPkData.RobotName;
        
        SpriteUtils.SetRobotSpriteByIndex(headList[1], dataService.LimitPkData.RobotHeadIconIndex);
        SpriteUtils.SetRobotSpriteByIndex(headLImage, dataService.LimitPkData.RobotHeadIconIndex);
        
        LeftWinFlag.SetActive(false);
        LeftWinEf.SetActive(false);
        RightWinFlag.SetActive(false);
        RightWinEf.SetActive(false);
        if (type == "start")
        {
            timeItem.gameObject.SetActive(true);
            tip = "收集手套数量超越对手,即可赢得奖励!";
            btnText = "开始匹配";

            startAnimator.enabled = true;
            startAnimator.Play("ani_StartLimitPK_StartContent0", 0, 0);

            btnEvent = () =>
            {
                if (isPlayingAnim) return;
                isPlayingAnim = true;
                PlayHeadAnim();
                UniRx.Observable.Timer(TimeSpan.FromSeconds(150f / 60)).Subscribe(_ =>
                {
                    subscription.Dispose();
                    headAnimator.enabled = false;
                });
                dataService.LimitPkData.UserActivative = true;
                dataService.LimitPkData.PopUI = true;
                RefreshActivityTimer t = GameObjManager.Instance.PopClass<RefreshActivityTimer>(true);
                t.Init(ActivityType.limitPk);
                TypeEventSystem.Send<RefreshActivityTimer>(t);
                UniRx.Observable.Timer(TimeSpan.FromSeconds(120f / 60)).Subscribe(_ =>
                {
                    TypeEventSystem.Send<MatchSucessEvent>();
                });
            };
        }
        else if (type == "matchSuccess")
        {
            dataService.LimitPkData.IsFirstShow = false;
            timeItem.gameObject.SetActive(true);
            btnText = "开始游戏";
            if (type == "matchSuccess") startAnimator.enabled = false;
            PlayFillAnim();
            RefreshTimer(null);
            btnEvent = () =>
            {
                if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockLimitPkPopup))
                {
                    dataService.AddFirstPopup(Constants.DoozyView.UnlockLimitPkPopup);
                    ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.UnlockLimitPkPopup, BoxBuilder.ShowUnlockLimitPkPopup, true);
                }
                ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);
                SoundPlayer.Instance.PlayButton();
                BoxBuilder.HidePopup(gameObject);
            };
        }
        else if (type == "result")
        {
            bool isWin = dataService.LimitPkData.IsWin();
            tip = isWin ? "成功击败你的对手,赢取你的奖励!" : "失败!";
            btnText = isWin ? "领取奖励" : "继续挑战!";
            CloseBtn.gameObject.SetActive(!isWin);
            LeftWinFlag.SetActive(isWin);
            LeftWinEf.SetActive(isWin);
            RightWinFlag.SetActive(!isWin);
            RightWinEf.SetActive(!isWin);


            Sequence seq = DOTween.Sequence();
            seq.Append(PlayFillAnim());
            seq.AppendCallback(() =>
            {
                startAnimator.enabled = true;
                startAnimator.Play("ani_StartLimitPK_StartContent_end", 0, 0);
                SoundPlayer.Instance.PlayMainSound("win_spark_tx");
            });
            btnEvent = () =>
            {
                ActivityManager.Instance.LimitPkActivity.CheckGetReward(CloseFunc);
            };
        }
        else if (type == "battle")
        {
            myWinFlag.SetActive(dataService.LimitPkData.MyIntegral > dataService.LimitPkData.RobotIntegral);
            robotWinFlag.SetActive(dataService.LimitPkData.MyIntegral <= dataService.LimitPkData.RobotIntegral);
            transform.Get<Text>("Container/BattleContent/Left/Bar/Value").text = $"{dataService.LimitPkData.MyIntegral}";
            transform.Get<Text>("Container/BattleContent/Right/Bar/Value").text = $"{dataService.LimitPkData.RobotIntegral}";
            SoundPlayer.Instance.PlayMainSound("PKBoxing_vs");
        }

        EnterBtnText.text = btnText;
        TipText.text = tip;

    }

    private void PlayHeadAnim()
    {
        SoundPlayer.Instance.PlayMainSound("PKBoxing_Match");
        headAnimator.enabled = true;
        var list = new List<int>();
        SpriteUtils.SetRobotSpriteByIndex(headList[0],GameUtils.GetRandomRobotIcon(ref list));
        int count = 2;
        subscription = Observable.Interval(TimeSpan.FromSeconds(10f/60))
            .Subscribe(_ =>
                {
                    if (count > 2) count = 0;
                    int tempIndex = GameUtils.GetRandomRobotIcon(ref list);
                    SpriteUtils.SetRobotSpriteByIndex(headList[count], tempIndex);
                    if (count == 1)
                    {
                        dataService.LimitPkData.RobotHeadIconIndex = tempIndex;
                    }
                    count++;
                }
            );
        headAnimator.Play("ani_StartLimitPK_StartContent_Icon", 0, 0);
    }

    Sequence PlayFillAnim()
    {
        Sequence seq = DOTween.Sequence();

        RectTransform leftRect = transform.Find("Container/StartContent/Progress/Bg/LeftValue").GetComponent<RectTransform>();
        RectTransform rightRect = transform.Find("Container/StartContent/Progress/Bg/RightValue").GetComponent<RectTransform>();
        int totalCount = Mathf.Max(dataService.LimitPkData.MyIntegral + dataService.LimitPkData.RobotIntegral, 1);

        float myPercent = Mathf.Clamp((float)dataService.LimitPkData.LastMyIntegral / totalCount, 75f / 380, 305f / 380);
        float robotPercent = Mathf.Clamp((float)dataService.LimitPkData.LastRobotIntegral / totalCount, 75f / 380, 305f / 380);
        if (dataService.LimitPkData.LastMyIntegral == 0 && dataService.LimitPkData.LastRobotIntegral == 0)
        {
            myPercent = robotPercent = 0.5f;
        }
        leftRect.sizeDelta = new Vector2(380 * myPercent, 34);
        rightRect.sizeDelta = new Vector2(380 * robotPercent, 34);

        myPercent = Mathf.Clamp((float)dataService.LimitPkData.MyIntegral / totalCount, 75f / 380, 305f / 380);
        robotPercent = Mathf.Clamp((float)dataService.LimitPkData.RobotIntegral / totalCount, 75f / 380, 305f / 380);
        if (dataService.LimitPkData.MyIntegral == 0 && dataService.LimitPkData.RobotIntegral == 0)
        {
            myPercent = robotPercent = 0.5f;
        }

        seq.AppendInterval(0.3f);
        seq.Join(leftRect.DOSizeDelta(new Vector2(380 * myPercent, 34), 0.5f).SetEase(Ease.Linear));
        seq.Join(rightRect.DOSizeDelta(new Vector2(380 * robotPercent, 34), 0.5f).SetEase(Ease.Linear));

        ActivityManager.Instance.LimitPkActivity.RecordLastIntegral();
        return seq;
    }

    private void UpdatePanel(MatchSucessEvent obj)
    {
        ActivityManager.Instance.LimitPkActivity.SetMatchFlag(true);
        startAnimator.enabled = true;
        startAnimator.Play("ani_StartLimitPK_StartContent", 0, 0);
        isPlayingAnim = false;
        subscription1 = Observable.Timer(TimeSpan.FromSeconds(142f / 60)).Subscribe(_ =>
        {
            SetBg("matchSuccess");
        });
    }

    public void DoAnim()
    {
        Observable.Timer(TimeSpan.FromSeconds(165f / 60)).Subscribe(_ =>
        {
            CloseFunc();
        });
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (ActivityManager.Instance.GetActivityByType(ActivityType.limitPk) != null && ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).state
                is ActivityState.waitEntry or ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).ActivityBigEndTime);
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.LimitPkData.ActivityEndTime);
        }
        timeItem.SetTimeData(timeData);
    }

    private void CloseFunc()
    {
        if(isPlayingAnim) return;
        subscription1?.Dispose();
        subscription?.Dispose();
        Progress.SetActive(false);
        SoundPlayer.Instance.PlayCertainButton(6);
        TypeEventSystem.Send<ResetBattleRenderTimeEvent>();
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnRefresh()
    {
        base.OnRefresh();
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<MatchSucessEvent>(UpdatePanel);
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<MatchSucessEvent>(UpdatePanel);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }
    private void EnterGameFunc()
    {
        btnEvent?.Invoke();
    }

}