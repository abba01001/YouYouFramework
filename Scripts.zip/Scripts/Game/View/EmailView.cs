﻿using QFramework;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;
using UIEffect = Coffee.UIExtensions.UIEffect;

public class EmailView : ViewBase
{
    [SerializeField] private Button closeBtn;
    [SerializeField] private Button getBtn;
    [SerializeField] private Button getAllBtn;
    [SerializeField] private Button deleteBtn;
    [SerializeField] private GameObject EmailTagItem;
    [SerializeField] private RectTransform TagScrollRect;
    [SerializeField] private RectTransform RewardScrollRect;
    [SerializeField] private GameObject EmailContent;
    [SerializeField] private GameObject NoEmailContent;
    [SerializeField] private Text PageContent;
    [SerializeField] private Text PageTitle;
    [SerializeField] private RectTransform DescScrollRect;
    
    private GameObject lastSelectTag;
    private List<GameObject> tagList = new List<GameObject>();
    [SerializeField] private List<GameObject> propList;
    protected override void OnAwake()
    {
        EmailTagItem.gameObject.SetActive(false);
        closeBtn.SetButtonClick(CloseFunc);
        getBtn.SetButtonClick(CheckGetReward);
        getAllBtn.SetButtonClick(CheckGetAllReward);
        deleteBtn.SetButtonClick(DeleteAllEmail);
    }
    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<UpdateEmailInfoEvent>(UpdatePanel);
    }

    void UpdatePanel(UpdateEmailInfoEvent obj)
    {
        List<EmailInfoModel> list = dataService.EmailList;
        bool hasEmail = list is {Count: > 0};
        EmailContent.SetActive(hasEmail);
        NoEmailContent.SetActive(!hasEmail);

        UpdateTagItem(list);
        
        deleteBtn.GetComponent<UIEffect>().effectFactor = 0;
        if (dataService.EmailList is { Count: > 0 })
        {
            foreach (var model in dataService.EmailList)
            {
                if (!string.IsNullOrEmpty(model.rewards) && model.receive == 0 || model.read == 0)
                {
                    deleteBtn.GetComponent<UIEffect>().effectFactor = 1;
                    break;
                }
            }
        }
    }

    void DeleteAllEmail()
    {
        bool canDelete = true;
        if (dataService.EmailList is { Count: > 0 })
        {
            foreach (var model in dataService.EmailList)
            {
                if (!string.IsNullOrEmpty(model.rewards) && model.receive == 0 || model.read == 0)
                {
                    canDelete = false;
                    break;
                }
            }
        }
        if (canDelete)
        {
            GameUtils.RequestEmailInfo("5");
        }
    }
    
    void CheckGetAllReward()
    {
        GameUtils.RequestEmailInfo("6","-1", () =>
        {
            if (dataService.EmailList is { Count: > 0 })
            {
                Dictionary<int, int> rewards = new Dictionary<int, int>();
                foreach (var model in dataService.EmailList)
                {
                    if (!string.IsNullOrEmpty(model.rewards) && model.receive == 0)
                    {
                        foreach (var VARIABLE in GameUtils.AnalysisPropString(model.rewards))
                        {
                            if (!rewards.ContainsKey(VARIABLE.Key))
                            {
                                rewards.Add(VARIABLE.Key,VARIABLE.Value);
                            }
                            else
                            {
                                rewards[VARIABLE.Key] += VARIABLE.Value;
                            }
                        }
                        model.receive = 2;
                    }
                }
                BoxBuilder.ShowRewardPop(rewards,PropChangeWay.Email);
                TypeEventSystem.Send<UpdateEmailInfoEvent>();
            }
        });
    }
    
    void CheckGetReward()
    {
        if(lastSelectTag == null) return;
        Dictionary<int, int> reward = GameUtils.AnalysisPropString(lastSelectTag.GetComponent<EmailTagItem>().GetInfo().rewards);
        GameUtils.RequestEmailInfo("3", lastSelectTag.GetComponent<EmailTagItem>().GetInfo().mid, () =>
        {
            BoxBuilder.ShowRewardPop(reward,PropChangeWay.Email);
        });
    }
    
    void UpdateTagItem(List<EmailInfoModel> list)
    {
        foreach (var go in tagList)
        {
            go.SetActive(false);
        }
        if (list is {Count: > 0})
        {
            int index = 0;
            foreach (var pair in list)
            {
                GameObject go = null;
                if (index < tagList.Count)
                {
                    go = tagList[index];
                }
                else
                {
                    go = GameObjManager.Instance.PopGameObject(GameObjType.EmailTagItem,EmailTagItem);
                    go.transform.SetParent(TagScrollRect);
                    go.transform.localScale = Vector3.one;
                    go.transform.SetLocalPositionAndRotation(Vector3.zero,Quaternion.identity);
                    tagList.Add(go);
                }
                go.SetActive(true);
                go.GetComponent<EmailTagItem>().SetData(pair);
                go.GetComponent<Button>().SetButtonClick(() =>
                {
                    if (lastSelectTag)
                    {
                        lastSelectTag.GetComponent<EmailTagItem>().SetSelect(false);
                        lastSelectTag = null;
                    }
                    go.GetComponent<EmailTagItem>().SetSelect(true);
                    lastSelectTag = go;
                    UpdatePage(go.GetComponent<EmailTagItem>().GetInfo());
                });
                index++;
            }

            if (!lastSelectTag)
            {
                tagList[0].GetComponent<EmailTagItem>().SetSelect(true);
                lastSelectTag = tagList[0];
            }
            UpdatePage(lastSelectTag.GetComponent<EmailTagItem>().GetInfo());
            Vector2 size = TagScrollRect.GetComponent<RectTransform>().sizeDelta;
            TagScrollRect.GetComponent<RectTransform>().sizeDelta = new Vector2(size.x,index * EmailTagItem.GetComponent<RectTransform>().sizeDelta.y);
        }
    }
    
    void UpdatePage(EmailInfoModel model)
    {
        if(model == null) return;
        PageContent.text = model.content;
        Observable.NextFrame().Subscribe(_ =>
        {
            DescScrollRect.sizeDelta = new Vector2(0,PageContent.preferredHeight);
            DescScrollRect.anchoredPosition = Vector2.zero;
        });
        PageTitle.text = model.title;

        Dictionary<int, int> reward = GameUtils.AnalysisPropString(model.rewards);
        foreach (var go in propList)
        {
            go.SetActive(false);
        }

        int index = 0;
        foreach (var pair in reward)
        {
            if(index >= propList.Count) break;
            propList[index].gameObject.SetActive(true);
            propList[index].Get<Image>($"PropImage").LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : pair.Key);
            propList[index].Get<UIEffect>($"PropImage").effectFactor = model.receive != 0 ? 1 : 0;
            propList[index].Get<UIEffect>($"Bg").effectFactor = model.receive != 0 ? 1 : 0;
            propList[index].Get<Transform>($"TimeText").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
            propList[index].Get<Text>($"NumText").text = "";
            propList[index].Get<Transform>($"FinishGet").gameObject.SetActive(model.receive != 0);
            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                propList[index].Get<Text>($"TimeText").text = $"{pair.Value / 60}m";
            }
            else
            {
                propList[index].Get<Text>($"NumText").text =
                    pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
            }
            index++;
        }
        getBtn.gameObject.SetActive(model.receive == 0);
        if(reward.Count == 0) getBtn.gameObject.SetActive(false);
    }
    
    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateEmailInfoEvent>(UpdatePanel);
    }

    protected override void OnShow()
    {
        UpdatePanel(null);
    }

    public void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    private void OnDisable()
    {
        ClearList();
    }

    private void ClearList()
    {
        if (!GameObjManager.IsNull())
        {
            foreach (var item in tagList)
            {
                GameObjManager.Instance.PushGameObject(item);
            }
        }
        tagList.Clear();
    }
    
}
