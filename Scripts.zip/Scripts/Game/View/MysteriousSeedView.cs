﻿using System;
using System.Collections.Generic;
using Activities;
using DG.Tweening;
using QFramework;
using Model;
using UnityEngine;
using SoliUtils;
using UniRx;
using UnityEngine.UI;

public class MysteriousSeed : ViewBase
{
    private Button closeBtn;
    private Button tipBtn;
    private Image fillAmount;
    private RectTransform progressBg;
    private ActivityTimeItem timeItem;

    private Vector2 TreeRootOrignPos = new Vector2(-650,1047);
    private Vector2 TreeTrunkOrignPos = new Vector2(648,433);
    private int TreeRootInterval = 650;//树干间隔
    private int TreeTrunkInterval = 500;//树枝间隔
    
    [SerializeField] private GameObject TreeRootPrefab;
    [SerializeField] private GameObject TreeTrunkPrefab;
    [SerializeField] private GameObject TreeHead;
    [SerializeField] private RectTransform BackBg;
    [SerializeField] private RectTransform Middlebg;
    [SerializeField] private RectTransform FrongBg;
    [SerializeField] private RectTransform TreeRoot;
    [SerializeField] private ScrollRect TrunkScroll;
    [SerializeField] private RectTransform ScrollContentRect;
    [SerializeField] private RectTransform Progress;
    [SerializeField] private GameObject Cat;
    [SerializeField] private GameObject LevelObj;

    private bool isMoving = false;
    private int TreeLayer = 8;
    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/Content/CloseBtn");
        closeBtn.SetButtonClick(CloseFunc);
        tipBtn = transform.Get<Button>("Container/Content/TipBtn");
        tipBtn.SetButtonClick(BoxBuilder.ShowUnlockMysteriousSeed);
        progressBg =  transform.Get<RectTransform>("Container/Content/Progress/FillAmount");
        fillAmount = transform.Get<Image>("Container/Content/Progress/FillAmount/Value");
        timeItem = transform.Get<ActivityTimeItem>("Container/Content/ActivityTimeItem");
        TrunkScroll.onValueChanged.RemoveListener(OnValueChange);
        TrunkScroll.onValueChanged.AddListener(OnValueChange);
        TreeRootPrefab.SetActive(false);
        TreeTrunkPrefab.SetActive(false);
        LevelObj.SetActive(false);
    }

    public void OnValueChange(Vector2 pos)
    {
        HandleBgPos();
    }

    void UpdateCatBallom()
    {
        int failCount = dataService.MysteriousSeedProgress.failCount;
        for (int i = 0; i < 3; i++)
        {
            Cat.transform.Find($"{i}").gameObject.MSetActive(false);
        }
        for (int i = 0; i < 3 - failCount; i++)
        {
            Cat.transform.Find($"{i}").gameObject.MSetActive(true);
        }
    }
    
    private void HandleBgPos()
    {
        Middlebg.anchoredPosition = ScrollContentRect.anchoredPosition;
        FrongBg.anchoredPosition = ScrollContentRect.anchoredPosition;
        TreeRoot.anchoredPosition = ScrollContentRect.anchoredPosition;
        Progress.anchoredPosition = ScrollContentRect.anchoredPosition;
        if (ScrollContentRect.anchoredPosition.y <= -420)
        {
            return;
        }
        BackBg.anchoredPosition = ScrollContentRect.anchoredPosition;
    }
    
    protected override void OnViewInit(bool isFirst)
    {
        if (!isFirst) return;
        TypeEventSystem.Register<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    private void CloseFunc()
    {
        // BaseActivityData data =
        //     ActivityManager.Instance.GetActivityByType(ActivityType.mysteriousSeed).localData as BaseActivityData;
        // data.ActivityEndTime = ActivityManager.Instance.GetActivitySeverTime();
        SoundPlayer.Instance.PlayCertainButton(6);
        if (ActivityManager.Instance.MysteriousSeedActivity.CheckIsMaxLevel())
        {
            dataService.MysteriousSeedProgress.FinishGetReward = true;
        }
        SoundPlayer.Instance.CheckActivityBgm(false,ActivityType.mysteriousSeed);
        BoxBuilder.HidePopup(gameObject);
    }

    //更新排行面板
    private void UpdatePanel(UpdateRankViewEvent obj)
    {
    }

    private float GetPos(int layer,int progress)
    {
        configService.MysteriousSeedConfig.TryGetValue(layer + 1,out MysteriousSeedModel model);
        float totalLength = 0;
        float beforeLayerLength = 0;
        if (model != null)
        {
            if (layer > 0)
            {
                for (int i = 0; i < layer; i++)
                {
                    beforeLayerLength = GetTreeTrunkPos(i).y;
                }
                totalLength = TreeTrunkInterval / (model.progress) * progress;
                totalLength += beforeLayerLength;
            }
            else
            {
                totalLength = GetTreeTrunkPos(0).y / (model.progress) * progress;
            }
            return totalLength;
        }
        else
        {
            for (int i = 0; i < layer; i++)
            {
                beforeLayerLength = GetTreeTrunkPos(i).y;
            }
            return beforeLayerLength;
        }
    }
    
    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.mysteriousSeed);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance
                    .GetActivityByType(ActivityType.mysteriousSeed).ActivityBigEndTime);
            }

            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.MysteriousSeedProgress.ActivityEndTime);
            }
        }

        timeItem.SetTimeData(timeData);
    }

    protected override void OnShow()
    {
        TreeLayer = configService.MysteriousSeedConfig.Count;
        SoundPlayer.Instance.CheckActivityBgm(true,ActivityType.mysteriousSeed);
        InitPanel();
        InitTreeRoot();
        InitTreeTrunk();
        InitProgress();
        UpdateProgress();
        RefreshTimer(null);
        UpdateCatBallom();
        bool isFirst = HandleFirstEntry();
        if (!isFirst)
        {
            SetLastPos();
            SetCurPos();
        }
    }

    private void SetLastPos()
    {
        var pos = new Vector2(0, -GetPos(dataService.MysteriousSeedProgress.lastLayer,dataService.MysteriousSeedProgress.lastProgress));
        ScrollContentRect.anchoredPosition = pos;
        Cat.GetComponent<RectTransform>().anchoredPosition = -pos;
        HandleBgPos();
    }

    private void SetCurPos()
    {
        if (dataService.MysteriousSeedProgress.lastProgress == dataService.MysteriousSeedProgress.curProgress &&
            dataService.MysteriousSeedProgress.lastLayer == dataService.MysteriousSeedProgress.curLayer)
        {
            return;
        }

        isMoving = true;
        var pos = new Vector2(0, -GetPos(dataService.MysteriousSeedProgress.curLayer,dataService.MysteriousSeedProgress.curProgress));
        Cat.GetComponent<RectTransform>().DOAnchorPos(-pos, 1f).SetEase(Ease.Linear).OnComplete(() =>
        {
            isMoving = false;
        });
        ScrollContentRect.DOAnchorPos(pos,1f).SetEase(Ease.Linear);
        UpdateProgress(true);
        ActivityManager.Instance.MysteriousSeedActivity.RefreshLast();
        
    }
    
    private bool HandleFirstEntry()
    {
        if (dataService.MysteriousSeedProgress.PopBtn)
        {
            var treeHeadRect = TreeHead.GetComponent<RectTransform>();
            FxMaskView.Instance.BlockOperation(true);
            dataService.MysteriousSeedProgress.PopBtn = false;
            ScrollContentRect.anchoredPosition = new Vector2(0,-(treeHeadRect.anchoredPosition.y + treeHeadRect.sizeDelta.y));
            ScrollContentRect.DOAnchorPos(Vector2.zero,3f).SetEase(Ease.Linear);
            Observable.Timer(TimeSpan.FromSeconds(3f)).Subscribe(_ =>
            {
                if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockMysteriousSeedPopup))
                {
                    dataService.AddFirstPopup(Constants.DoozyView.UnlockMysteriousSeedPopup);
                    BoxBuilder.ShowUnlockMysteriousSeed();
                }
                FxMaskView.Instance.BlockOperation(false);
            });
            return true;
        }
        return false;
    }

    private void InitTreeRoot()
    {
        int finalY = 0;
        for (int i = 0; i < TreeLayer - 3; i++)
        {
            GameObject obj = Instantiate(TreeRootPrefab);
            obj.SetActive(true);
            obj.transform.SetParent(TreeRoot);
            obj.transform.localScale = Vector3.one;
            obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            finalY = (int)TreeRootOrignPos.y + i * TreeRootInterval;
            obj.GetComponent<RectTransform>().anchoredPosition = new Vector2(TreeRootOrignPos.x, finalY);
        }
        var treeHeadRect = TreeHead.GetComponent<RectTransform>();
        treeHeadRect.anchoredPosition = new Vector2(treeHeadRect.anchoredPosition.x, finalY + 579);
        treeHeadRect.transform.SetAsLastSibling();
        treeHeadRect.gameObject.SetActive(true);
        ScrollContentRect.sizeDelta = new Vector2(ScrollContentRect.sizeDelta.x,treeHeadRect.anchoredPosition.y + treeHeadRect.sizeDelta.y);
    }

    private void InitTreeTrunk()
    {
        for (int i = 0; i < TreeLayer; i++)
        {
            GameObject obj = Instantiate(TreeTrunkPrefab);
            obj.SetActive(true);
            obj.transform.SetParent(ScrollContentRect);
            obj.transform.localScale = Vector3.one;
            obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            obj.GetComponent<RectTransform>().anchoredPosition = GetTreeTrunkPos(i);
        }
    }

    private Vector2 GetTreeTrunkPos(int layer)
    {
        return new Vector2(TreeTrunkOrignPos.x, TreeTrunkOrignPos.y + layer * TreeTrunkInterval);
    }
    
    private void InitProgress()
    {
        for (int i = 0; i < TreeLayer; i++)
        {   
            GameObject obj = Instantiate(LevelObj);
            Vector2 size = i == 0 ? new Vector2(28,TreeTrunkInterval - 80) : new Vector2(28,TreeTrunkInterval);
            InitBar(obj,configService.MysteriousSeedConfig[i+1],size);
            obj.Get<Text>("Text").text = $"{i + 1}";
            obj.SetActive(true);
            obj.transform.SetParent(Progress);
            obj.transform.localScale = Vector3.one;
            obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            obj.GetComponent<RectTransform>().anchoredPosition = new Vector2(-592, 210 + i * TreeTrunkInterval);
        }
        progressBg.sizeDelta = new Vector2(40, TreeTrunkInterval * TreeLayer - 80);
        fillAmount.GetComponent<RectTransform>().sizeDelta = new Vector2(28,0);
    }

    private void InitBar(GameObject levelObj,MysteriousSeedModel model,Vector2 size)
    {
        var bar = levelObj.Get<Transform>("Bar");
        bar.GetComponent<RectTransform>().sizeDelta = size;
        int count = 0;
        var len = size.y / model.progress;
        for (int i = 0; i < bar.childCount; i++)
        {
            if (i >= model.progress) break;
            var obj = bar.GetChild(i).gameObject;
            obj.MSetActive(true);
            obj.GetComponent<RectTransform>().anchoredPosition = new Vector2(13.5f,-(model.progress - i - 1) * len);
            count++;
        }
    }

    private void UpdateProgress(bool needAnim = false)
    {
        float max = progressBg.sizeDelta.y - 15;

        if (configService.MysteriousSeedConfig.TryGetValue(dataService.MysteriousSeedProgress.curLayer + 1,out MysteriousSeedModel mod))
        {
            int total = 0;
            int cur = 0;
            int initLength = 428;
            float value = 0;
            float percent = (float) dataService.MysteriousSeedProgress.curProgress / mod.progress;
            foreach (var model in configService.MysteriousSeedConfig)
            {
                total += model.Value.progress;
            }

            if (dataService.MysteriousSeedProgress.curLayer > 0)
            {
                for (int i = 1; i < dataService.MysteriousSeedProgress.curLayer + 1; i++)
                {
                    if (configService.MysteriousSeedConfig.TryGetValue(i, out MysteriousSeedModel model))
                    {
                        cur += model.progress;
                    }
                }

                value = initLength + (dataService.MysteriousSeedProgress.curLayer - 1) * TreeTrunkInterval +
                        TreeTrunkInterval * percent;
            }
            else
            {
                value = initLength * percent;
            }

            if (!needAnim)
            {
                fillAmount.GetComponent<RectTransform>().sizeDelta = new Vector2(28, value);
            }
            else
            {
                fillAmount.GetComponent<RectTransform>().DOSizeDelta(new Vector2(28, value), 1f);
            }
        }
        else
        {
            fillAmount.GetComponent<RectTransform>().sizeDelta = new Vector2(28, max);
        }
    }
    
    private void InitPanel()
    {
    }
}