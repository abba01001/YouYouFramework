﻿using Activities;
using DG.Tweening;
using Doozy.Engine;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using Doozy.Engine.UI;
using Model;
using UnityEngine;
using UnityEngine.PlayerLoop;
using UnityEngine.UI;
using SoliUtils;

public class LevelPassView : ViewBase
{
    private Button closeBtn;
    private Button tipBtn;
    private Text tipText;
    private GameObject collectFlowerItem;

    private Text enterBtnText;
    private Transform itemParent;
    private RectTransform itemParentRect;
    private RectTransform scrollRect;
    private Vector2 prefabSize;
    private Vector2 itemParentSize;

    List<BoatItem> itemList = new List<BoatItem>();
    ActivityTimeItem timeItem;
    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/bg/CloseBtn");
        closeBtn.SetButtonClick(CloseFunc);
        tipBtn = transform.Get<Button>("Container/bg/TipBtn");
        tipBtn.SetButtonClick(BoxBuilder.ShowUnlockLevelPassPopView);
        enterBtnText = transform.Get<Text>("Container/bg/EnterBtn/Text");
        transform.Get<Button>("Container/bg/EnterBtn").SetButtonClick(() =>
        {
            if(GetComponent<UIPopup>().IsShowing || GetComponent<UIPopup>().IsHiding) return;
            if (ActivityManager.Instance.LevelPassActivity.CheckCanGetReward())
            {
                ActivityManager.Instance.LevelPassActivity.CheckGetReward(CloseFunc);
            }
            else
            {
                CloseFunc();
                if (ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state == ActivityState.underWay)
                {
                    ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);
                }
            }
        });
    }
    protected override void OnViewInit(bool isFirst)
    {
        if(isFirst)
        {
            TypeEventSystem.Register<UpdateCollectFlowerInfoEvent>(UpdatePanel);
        }
    }
    
    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        foreach (var item in itemList)
        {
            item.Clear();
        }
        BoxBuilder.HidePopup(gameObject);
        ActivityManager.Instance.LevelPassActivity.CheckFinishActivity();
    }

    //更新排行面板
    private void UpdatePanel(UpdateCollectFlowerInfoEvent obj)
    {
        int index = 0;
        List<LevelPassData> list = dataService.LevelPassProgress.GetRankData();
        if (list == null || list.Count == 0)
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            return;
        }
        foreach (var item in list)
        {
            itemList[index].SetData(item);
            index++;
        }
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateCollectFlowerInfoEvent>(UpdatePanel);
    }

    protected override void OnShow()
    {
         InitPanel();
         dataService.LevelPassProgress.IsFirstShow = false;
    }

    private void InitPanel()
    {
        if (itemList.Count > 0) return;
        Transform itemParent = transform.Get<Transform>("Container/BoatItem");
        for (int i = 0; i < itemParent.childCount; i++)
        {
            Transform item = itemParent.GetChild(i);
            itemList.Add(item.GetComponent<BoatItem>());
        }
        UpdatePanel(null);
        transform.Get<Transform>("ani_start").gameObject.SetActive(false);
        enterBtnText.text = "出发";
        bool canGetReward = ActivityManager.Instance.LevelPassActivity.CheckCanGetReward();
        closeBtn.gameObject.SetActive(!canGetReward);
        if (ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state == ActivityState.waitFinished)
        {
            enterBtnText.text = "结束";
        }
        if (canGetReward)
        {
            enterBtnText.text = "领取奖励";
        }
    }

    public void PlayStartAnim()
    {
        transform.Get<Transform>("ani_start").gameObject.SetActive(true);
        SoundPlayer.Instance.PlayMainSound("dragonboat_ani_start");
    }
}
