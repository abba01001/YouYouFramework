﻿using Doozy.Engine;
using Doozy.Engine.UI;
using QFramework;
using System.Collections;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using UniRx;
using System;
using Model;
using Activities;
using SoliUtils;

public class SolatiumPopView : ViewBase
{
    private Button closeBtn;
    private Text coinText;
    private Transform coinImage;

    private int coinNum;

    protected override void OnAwake()
    {
        coinText = transform.Get<Text>("Container/CoinText");
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        coinImage = transform.Find("Container/CoinImage");

        //closeBtn.SetButtonClick(CloseFunc);
        closeBtn.interactable = false;

        GameController.Instance.ExitBattle();
    }

    protected override void OnShow()
    {
        SoundPlayer.Instance.PlayFailGame();
    }

    public void SetCoinText(int coin)
    {
        coinNum = coin;
        coinText.text = "0";
        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(0.6f);
        seq.Append(DOTween.To(x => coinText.text = ((int)x).ToString(), 0, coinNum, 0.3f));
        seq.AppendInterval(0.3f);
        seq.AppendCallback(CloseFunc);
    }

    private void CloseFunc()
    {
        closeBtn.interactable = false;
        if (ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.winStreak)) dataService.ActivitySaveData.winStreak.WinCount = 0;
        dataService.AddProp((int)PropEnum.Coin, coinNum, PropChangeWay.Solatium, coinImage.position);
        UniRx.Observable.Timer(TimeSpan.FromSeconds(1.5)).Subscribe(_ =>
        {
            BoxBuilder.ShowSceneChangePop(() =>
            {
                TypeEventSystem.Send(new BattleCommandEvent() { command = BattleCommand.LoseGame });
                GameEventMessage.SendEvent(Constants.DoozyEvent.GameEnd);
                BoxBuilder.HidePopup(gameObject);
            }, BoxBuilder.HideSceneChangePop);
        });
    }
}
