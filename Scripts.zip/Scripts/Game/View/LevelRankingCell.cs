using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class LevelRankingCell : ListViewCell
{
    private Image rankImg;
    private Text rankText;
    private Image headImg;
    private Text nameText;
    private Text levelText;
    private Transform endlessItem;
    private Text endlessText;

    void Awake()
    {
        rankImg = transform.Get<Image>("LevelIcon");
        rankText = transform.Get<Text>("LevelIcon/Text");
        headImg = transform.Get<Image>("HeadIcon/Image");
        nameText = transform.Get<Text>("Name");
        levelText = transform.Get<Text>("Level");
        endlessItem = transform.Get<Transform>("Cup");
        endlessText = transform.Get<Text>("Cup/NumText");
    }

    public override void FillData(params object[] data)
    {
        int idx = (int)data[0];
        var dat = (Tuple<int, string, string, string, int, int>)data[1];
        int rank = dat.Item1;
        string id = dat.Item2;
        string name = dat.Item3;
        string avatar = dat.Item4;
        int level = dat.Item5;
        int endless = dat.Item6;
        if (rank <= 3)
        {
            rankImg.enabled = true;
            rankText.text = "";
            rankImg.SetSpriteByAtlas(Constants.AtlasNamePath.TextureCommonAtlas, "hd_pm_" + rank, true);
        }
        else
        {
            rankImg.enabled = false;
            if(rank > 999)
                rankText.text = "999+";
            else
                rankText.text = rank.ToString();
        }

        // nameText.text = name;
        GameUtils.SetTextWithEllipsis(nameText, name);
        levelText.text = level.ToString();
        endlessItem.gameObject.SetActive(endless > 0);
        endlessText.text = endless.ToString();
        
        GameUtils.GetAvatar(
            Constants.DefaultAvatarUrl,
            (ret,filePath) =>
            {
                if (string.IsNullOrEmpty(filePath))
                    return;
                if (headImg.Equals(null))
                    return;
                var tex = SpriteUtils.ReadTexture(filePath);
                if (tex != null)
                {
                    headImg.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                }
            });
        
        if (string.IsNullOrEmpty(avatar))
        {
            avatar = Constants.DefaultAvatarUrl;
        }
        GameUtils.GetAvatar(
            avatar,
            (ret, filePath) =>
            {
                if (string.IsNullOrEmpty(filePath))
                    return;
                if (headImg.Equals(null))
                    return;
                var tex = SpriteUtils.ReadTexture(filePath);
                if (tex != null)
                {
                    headImg.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                }
            });
    }
}