using Cysharp.Threading.Tasks;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

namespace View
{
    public class DataSyncConfirmPopView : ViewBase
    {
        [SerializeField] private DataItemComponent data;
        [SerializeField] private Button YesBtn;
        [SerializeField] private Button NoBtn;

        private MainData _mainData;
        protected override void OnAwake()
        {
            YesBtn.SetButtonClick(OnYesBtnClick);
            NoBtn.SetButtonClick(OnNoBtnClick);
        }

        public void SetData(MainData mainData)
        {
            _mainData = mainData;
            data.Init(mainData);
        }

        private async void OnYesBtnClick()
        {
            // 确认同步数据
            // 到这才是真正关联成功了
            // FirebaseUtils.Instance.FirebaseLinkWithFacebookSuccess();
            TypeEventSystem.Send<FbLinkStateRefreshEvent>();
            if (_mainData.isRemote)
            {
                // 选择远端数据才需要退出，刷新
                dataService.SaveData(_mainData.remoteJson);
                dataService.ReadLocalData();
                // 现在无法刷新UI，只能先强制退出
                await UniTask.Delay(100);
//                Application.Quit();
//                NativeToolMgr.INSTANCE.DoQuitApplication();
                SceneMgr.Instance.LoadLauncherScene();
            }
            
            BoxBuilder.HideDataSyncConfirmPopup();
            BoxBuilder.ShowSignInSuccessPopup();
        }
        
        private void OnNoBtnClick()
        {
            // 放弃同步数据
            BoxBuilder.HideDataSyncConfirmPopup();
        }

        protected override void OnViewDestroy()
        {
            
        }
    }
}