using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using Coffee.UIExtensions;
using QFramework;

public class MergeShopItemCell : ListViewCell
{
    private Image quaImg;
    private Text nameText;
    private Text lvText;
    private Text limitText;
    public Image iconImg;
    private Button buyBtn;
    private GameObject priceIcon;
    private Text priceText;
    private Text offText;
    private GameObject emptyObj;


    void Awake()
    {
        gameObject.SetActive(true);
        quaImg = transform.Get<Image>("QuaImg");
        nameText = transform.Get<Text>("NameText");
        lvText = transform.Get<Text>("LevelText");
        limitText = transform.Get<Text>("LimitText");
        iconImg = transform.Get<Image>("Icon");
        buyBtn = transform.Get<Button>("BuyBtn");
        priceIcon = transform.Get<Transform>("BuyBtn/Icon").gameObject;
        priceText = transform.Get<Text>("BuyBtn/Price");
        offText = transform.Get<Text>("BuyBtn/OffImg/OffText");
        emptyObj = transform.Get<Transform>("Empty").gameObject;
    }

    public override async void FillData(params object[] data)
    {
        int index = (int)data[0];

        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        MergeShopInfoModel info = dataService.GetMergeShopData();
        var date = info.date;

        int itemId = info.items[index];

        if (configService.MergeItemConfig[itemId].rarity <= 2)
            await quaImg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas, "shop_new_hcw_1", true);
        else
            await quaImg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewShopAtlas, "shop_new_hcw_2", true);
        nameText.text = configService.MergeItemConfig[itemId].name;
        int lv = 1;
        int lastItemId = itemId;
        while (configService.MergeItemConfig.ContainsKey(lastItemId) && configService.MergeItemConfig[lastItemId].mergeItem != -1)
        {
            lv++;
            lastItemId = configService.MergeItemConfig[lastItemId].mergeItem;
        }
        lvText.text = $"Lv.{lv}";
        var gradient = lvText.GetComponent<UIGradient>();
        gradient.color1 = new Color32();
        gradient.color2 = new Color32();
        if (lv == 1)
        {
            gradient.color1 = new Color32(255, 250, 189, 255);
            gradient.color2 = new Color32(132, 223, 12, 255);
        }
        else if (lv == 2)
        {
            gradient.color1 = new Color32(189, 255, 242, 255);
            gradient.color2 = new Color32(11, 190, 235, 255);
        }
        else if (lv == 3)
        {
            gradient.color1 = new Color32(255, 225, 231, 255);
            gradient.color2 = new Color32(255, 66, 133, 255);
        }
        else
        {
            gradient.color1 = new Color32(255, 234, 115, 255);
            gradient.color2 = new Color32(243, 69, 8, 255);
        }

        limitText.text = $"剩余: {info.limits[index] - info.boughts[index]}";
        iconImg.LoadPropSprite(itemId, true, () =>
        {
            float targetHeight = 100;
            float targetWidth = 100;
            float originalWidth = iconImg.sprite.rect.width;
            float originalHeight = iconImg.sprite.rect.height;
            float aspectRatio = originalWidth / originalHeight;
            float newWidth;
            float newHeight;
            if (originalHeight >= originalWidth)
            {
                newHeight = targetHeight;
                newWidth = targetHeight * aspectRatio;
            }
            else
            {
                newWidth = targetWidth;
                newHeight = targetWidth / aspectRatio;
            }
            iconImg.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
        });

        int price = 0;
        if (info.products[index] != "")
        {
            if (configService.ShopConfig.ContainsKey(info.products[index]))
            {
                price = configService.ShopConfig[info.products[index]].money;
                priceText.text = $"{price}元";
                priceIcon.SetActive(false);
            }
            offText.transform.parent.gameObject.SetActive(false);
        }
        else
        {
            priceIcon.SetActive(true);
            price = (int)Math.Round(configService.MergeItemConfig[itemId].price * info.offs[index]);
            priceText.text = $"{price}";
            offText.transform.parent.gameObject.SetActive(info.offs[index] < 1);
            offText.text = $"{info.offs[index] * 10}";
        }

        bool empty = info.limits[index] - info.boughts[index] <= 0;
        nameText.gameObject.SetActive(!empty);
        lvText.gameObject.SetActive(!empty);
        limitText.gameObject.SetActive(!empty);
        iconImg.gameObject.SetActive(!empty);
        buyBtn.gameObject.SetActive(!empty);
        emptyObj.SetActive(empty);

        buyBtn.onClick.RemoveAllListeners();
        buyBtn.onClick.AddListener(() =>
        {
            if (info.products[index] != "")
            {
                PayUtils.RequestOrder(info.products[index]);
            }
            else
            {
                int ret = dataService.BuyMergeShopItem(date, index);
                if (ret == 1)
                {
                    BoxBuilder.ShowToast("建造币不足，前往挑战关卡吧~");
                    PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartGamePopup, () =>
                    {
                        SoundPlayer.Instance.PlayButton();
                        BoxBuilder.ShowStartGamePopup();
                    });
                }
                else if (ret == 2)
                {
                    BoxBuilder.ShowToast("商店已刷新，请重新购买");
                    BoxBuilder.HideShopPop();
                }
                else
                {
                    FillData(data);
                    RefreshUserInfoBuildCoin t1 = GameObjManager.Instance.PopClass<RefreshUserInfoBuildCoin>(true);
                    t1.Init(dataService.BuildCoin + price, dataService.BuildCoin, PropChangeWay.Shop, null);
                    TypeEventSystem.Send<RefreshUserInfoBuildCoin>(t1);
                    TypeEventSystem.Send<BuyItemFromMergeShop>(new BuyItemFromMergeShop(index));
                }
            }
        });
    }

}