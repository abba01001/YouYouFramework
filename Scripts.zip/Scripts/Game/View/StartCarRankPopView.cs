using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using Model;

[RequireComponent(typeof(CanvasGroup))]
public class StartCarRankPopView : ViewBase
{

    private Button CloseBtn;
    private ActivityTimeItem timeItem;
    private Action startGame;
    protected override void OnAwake()
    {
        Button backCloseBtn = transform.Get<Button>("Overlay");
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        backCloseBtn.interactable = false;
        backCloseBtn.SetButtonClick(CloseFunc);
        CloseBtn.SetButtonClick(CloseFunc);
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(EnterGameFunc);
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        SetBg();
    }

    public void SetBg()
    {
        bool EnableTime = true;
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeData.endTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeItem.gameObject.SetActive(true);
        
        if (ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.carRank))
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.CarRankProgress.ActivityEndTime);
        }
        startGame = () =>
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);
            if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockCarRankPopup))
            {
                dataService.AddFirstPopup(Constants.DoozyView.UnlockCarRankPopup);
                ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.UnlockCarRankPopup, BoxBuilder.ShowUnlockCarRankPopView, true);
            }
            CloseFunc();
        };

        timeItem.gameObject.SetActive(EnableTime);
        RefreshTimer(null);
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (ActivityManager.Instance.GetActivityByType(ActivityType.carRank) != null && ActivityManager.Instance.GetActivityByType(ActivityType.carRank).state
                is ActivityState.waitEntry or ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.carRank).ActivityBigEndTime);
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.carRank).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.CarRankProgress.ActivityEndTime);
        }
        timeItem.SetTimeData(timeData);
    }
    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        UIPopup popup = GetComponent<UIPopup>();
        popup.Hide();
        if (popup.AddToPopupQueue)
            UIPopupManager.RemoveFromQueue(popup);
    }

    protected override void OnRefresh()
    {
        base.OnRefresh();
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }
    protected override async void OnShow()
    {

    }

    private void EnterGameFunc()
    {
        startGame?.Invoke();
    }
    
}