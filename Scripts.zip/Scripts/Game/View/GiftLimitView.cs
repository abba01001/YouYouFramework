﻿using QFramework;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class GiftLimitView : ViewBase
{
    private Text priceText;
    private Text timeText;
    private Transform itemParent;
    [SerializeField] private GameObject weekObj;
    [SerializeField] private GameObject monthObj;
    private static readonly List<ShopInfo> shopWholeList = new List<ShopInfo>()
    {
        new ShopInfo("WeeklySubscription", "2", ShopItemEnum.BigShopItem),
        new ShopInfo("MonthlySubscription", "3", ShopItemEnum.BigShopItem),
    };
    protected override void OnAwake()
    {
        transform.Get<Button>("Content/CloseBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
        });
    }

    protected override void OnViewInit(bool isFirst)
    {
        TypeEventSystem.Register<GameRechargeEvent>(UpdatPanel);
    }

    private void UpdatPanel(GameRechargeEvent obj)
    {
        InitPanel();
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatPanel);
    }

    protected override void OnShow()
    {
        if (!dataService.CheckFirstPopup(Constants.DoozyView.SubscribeChargePopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.SubscribeChargePopup);
        }
        InitPanel();
    }

    private void InitPanel()
    {
        weekObj.GetComponent<ShopItem>().SetShopInfo(shopWholeList[0],transform);
        monthObj.GetComponent<ShopItem>().SetShopInfo(shopWholeList[1],transform);
    }
}