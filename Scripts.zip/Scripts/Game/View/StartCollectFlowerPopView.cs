using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using Model;

[RequireComponent(typeof(CanvasGroup))]
public class StartCollectFlowerPopView : ViewBase
{
    private Button CloseBtn;
    private ActivityTimeItem timeItem;

    protected override void OnAwake()
    {
        Button backCloseBtn = transform.Get<Button>("Overlay");
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        backCloseBtn.interactable = false;
        backCloseBtn.SetButtonClick(CloseFunc);
        CloseBtn.SetButtonClick(CloseFunc);
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(EnterGameFunc);
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        InitPanel();
    }

    private void InitPanel()
    {
        RefreshTimer(null);
        dataService.CollectFlowerProgress.PopBtn = false;
    }

    private void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower) != null && ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state 
                is ActivityState.waitEntry or ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).ActivityBigEndTime);
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.CollectFlowerProgress.ActivityEndTime);
        }
        timeItem.SetTimeData(timeData);
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }
    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }
    private void EnterGameFunc()
    {
        if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockCollectFlowerPopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.UnlockCollectFlowerPopup);
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.UnlockCollectFlowerPopup, BoxBuilder.ShowUnlockCollectFlowerPopView, true);
        }
        ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);

        CloseFunc();
        dataService.CollectFlowerProgress.UserActivative = true;
        RefreshActivityTimer t = GameObjManager.Instance.PopClass<RefreshActivityTimer>(true);
        t.Init(ActivityType.collectFlower);
        TypeEventSystem.Send<RefreshActivityTimer>(t);
    }
    
}