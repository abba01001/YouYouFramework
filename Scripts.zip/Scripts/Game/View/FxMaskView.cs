using QFramework;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using System.Collections.Generic;
using Doozy.Engine.Nody;
using System;
using Cysharp.Threading.Tasks;
using UniRx;
using SoliUtils;

public class FxMaskView : MonoBehaviour, ISingleton
{
    private GameObject cantTouchObj;
    private Image blackImage;
    [SerializeField]
    private GameObject rookieTip;
    [SerializeField]
    private GameObject dragTip;
    [SerializeField]
    private GameObject animTip;
    [SerializeField]
    
    private GameObject pressMergeTip;

    private Dictionary<string, GameObject> fxDic = new Dictionary<string, GameObject>();
    public GraphController graphController;
    public static bool Inited;
    public bool CanTouch
    {
        get
        {
            if (cantTouchObj == null)
                return false;
            return !cantTouchObj.activeSelf;
        }
        set
        {
            if (cantTouchObj != null)
                cantTouchObj.SetActive(!value);
        }
    }

    private IDisposable subscription;
    public static FxMaskView Instance
    {
        get
        {
            return MonoSingletonProperty<FxMaskView>.Instance;
        }
    }

    public void OnSingletonInit() { }

    // private List<string> preLoadResList = new List<string>();
    void Start()
    {
        Inited = true;
        cantTouchObj = transform.Find("CantTouch").gameObject;
        CanTouch = true;
        blackImage = transform.Get<Image>("BlackImage");
        TypeEventSystem.Register<RookieTriggerBeginEvent>(OnRookieTriggerBeginEvent);
        TypeEventSystem.Register<RookieTriggerEndEvent>(OnRookieTriggerEndEvent);
        TypeEventSystem.Register<PressMergeItemEvent>(OnPressMergeItemEvent);
        TypeEventSystem.Register<UnlockMergeItemEvent>(OnUnlockMergeItemEvent); 
        // preLoadResList = new List<string>()
        // {
        //     "Assets/Res/Prefabs/Item/RookieTipItem.prefab"
        // };
        // await GlobalRes.PreLoad(preLoadResList);
    }

    void OnDestroy()
    {
        TypeEventSystem.UnRegister<RookieTriggerBeginEvent>(OnRookieTriggerBeginEvent);
        TypeEventSystem.UnRegister<RookieTriggerEndEvent>(OnRookieTriggerEndEvent);
        TypeEventSystem.UnRegister<PressMergeItemEvent>(OnPressMergeItemEvent);
        TypeEventSystem.UnRegister<UnlockMergeItemEvent>(OnUnlockMergeItemEvent);
        // GlobalRes.RemovePreLoad(preLoadResList);
    }

    public Tween DoFade(float time)
    {
        return blackImage.DOFade(0.6f, time);
    }
    public Tween DoFade(float toAlpha, float time)
    {
        return blackImage.DOFade(toAlpha, time);
    }

    public void SetAlpha(float toAlpha)
    {
        if (gameObject == null)
            return;
        if (blackImage == null)
            blackImage = GetComponent<Image>();
        if (blackImage != null)
            blackImage.color = new Color(0, 0, 0, toAlpha > 1 ? toAlpha / 255 : toAlpha);
    }

    public void OnRookieTriggerBeginEvent(RookieTriggerBeginEvent e)
    {
        switch (e.rookieType)
        {
            case RookieModel.RookieType.Click:
                var configService = MainContainer.Container.Resolve<IConfigService>();
                var rookieModel = configService.RookieClickConfig[e.rookieId];
                ShowRookieTipView(e.rookieId, e.pos, e.touchRect, rookieModel.force, rookieModel.touchMaskTime);
                if (rookieModel.touchMaskTime > 0)
                {
                    CanTouch = false;
                    UniRx.Observable.Timer(TimeSpan.FromSeconds(rookieModel.touchMaskTime)).Subscribe(_ =>
                    {
                        CanTouch = true;
                    });
                }
                break;
            case RookieModel.RookieType.Drag:
                ShowRookieDragView(e.rookieId, e.dragModel, e.objs);
                break;
            case RookieModel.RookieType.Anim:
                ShowRookieAnimTipView(e.rookieId, e.animModel);
                break;
        }


    }

    public void OnRookieTriggerEndEvent(RookieTriggerEndEvent e)
    {

    }

    private void OnUnlockMergeItemEvent(UnlockMergeItemEvent e)
    {
        int gridId = e.gridId;
        int itemId = e.itemId;
        var configService = MainContainer.Container.Resolve<IConfigService>();
        if (configService.MergeItemConfig[itemId].mergeItem < 0)
        {
            return;
        }
        Transform homeMapBtnTf = HomeView.Instace.homeMapBtn.transform;
        if (!homeMapBtnTf.gameObject.activeSelf)
        {
            return;
        }
        ShowUnlockMergeItemTips(gridId,itemId);
    }

    private async void ShowUnlockMergeItemTips(int gridId,int itemId)
    {
        MergeItem mergeItem = GetMergeItem(gridId, itemId);
        int delayCount = 0;
        while (mergeItem == null)
        {
            await UniTask.Delay(100);
            delayCount++;
            if (delayCount > 30)
            {
                return;
            }
            mergeItem = GetMergeItem(gridId, itemId);
        }
        Transform homeMapBtnTf = HomeView.Instace.homeMapBtn.transform;
        var obj = GameObjManager.Instance.PopGameObject(GameObjType.UnlockMergeTipItem);
        obj.transform.SetParent(transform);
        obj.transform.GetComponent<RectTransform>().offsetMin = Vector2.zero;
        obj.transform.GetComponent<RectTransform>().offsetMax = Vector2.zero;
        obj.transform.localScale = Vector3.one;
        obj.SetActive(true);
        obj.GetComponent<UnlockMergeTipItem>().Show(mergeItem, homeMapBtnTf.position, () =>
        {
            GameObjManager.Instance.PushGameObject(obj);
            homeMapBtnTf.GetComponent<Animator>().Play("Pressed", 0);
            Sequence sequence = DOTween.Sequence();
            sequence.AppendInterval(0.15f);
            sequence.AppendCallback(() => { homeMapBtnTf.GetComponent<Animator>().Play("Normal", 0); });
            sequence.SetAutoKill(true);
            sequence.Play();
        });


    }

    private MergeItem GetMergeItem(int gridId,int itemId)
    {
        MergeItem[] items = GetItems();
        if (items == null)
        {
            return null;
        }
        MergeItem mergeItem = Array.Find(items, element => element.GridId == gridId&& element.GetItemId() == itemId);
        return mergeItem;
    }

    private MergeItem[] GetItems()
    {
        if (MergeGameController.Instance == null)
        {
            return null;
        }
        Transform transform = MergeGameController.Instance.transform;
        MergeItem[] items = transform.GetComponentsInChildren<MergeItem>(false);
        if (items == null || items.Length == 0)
        {
            return null;
        }
        return items;
    }

    private void Test()
    {
        
    }

    private void OnPressMergeItemEvent(PressMergeItemEvent e)
    {
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        int itemId = e.item.GetItemId();
        if(dataService.IsUnlockGrid(e.item.GridId) && configService.GetMergeItemEndType(itemId) == Constants.MergeItemType.Normal)
        {
            pressMergeTip.GetComponent<PressMergeTipItem>().Show(e.item);
        }
    }

    public void ShowRookieAnimTipView(int rookieId, RookieAnimModel animModel)
    {
        animTip.SetActive(true);
        animTip.GetComponent<RookieAnimItem>().Show(rookieId,animModel);
    }

    private async void ShowRookieDragView(int rookieId, RookieDragModel dragModel, List<GameObject> objs)
    {
        while (!GameUtils.IsFullyEnterGame() || Camera.main == null)
        {
            await UniTask.Delay(200);
        }
        await UniTask.DelayFrame(1);
        await UniTask.Delay(1000);

        dragTip.SetActive(true);
        dragTip.GetComponent<RookieDragItem>().Show(rookieId, dragModel, objs, null);
    }


    private async void ShowRookieTipView(int rookieId, Vector2 pos, Rect touchRect, bool force, float touchMaskTime)
    {
        while (!GameUtils.IsFullyEnterGame() || Camera.main == null)
        {
            await UniTask.Delay(200);
        }
        await UniTask.DelayFrame(5);
        var obj = GameObjManager.Instance.PopGameObject(GameObjType.RookieTipItem, rookieTip);
        obj.transform.SetParent(transform);
        obj.transform.localPosition = new Vector3(0, 0, 200);
        obj.transform.GetComponent<RectTransform>().offsetMin = Vector2.zero;
        obj.transform.GetComponent<RectTransform>().offsetMax = Vector2.zero;
        obj.transform.localScale = Vector3.one;
        obj.SetActive(true);
        obj.GetComponent<RookieTipItem>().Show(rookieId, pos, touchRect, () =>
        {
            GameObjManager.Instance.PushGameObject(obj);
        }, force, touchMaskTime);
    }

    public void AddFx(string keyName, GameObject fxGo)
    {
        if (fxDic.ContainsKey(keyName))
        {
            Debug.Log("FxView Has Same Key ==> " + keyName);
            return;
        }
        fxDic[keyName] = fxGo;
        fxGo.transform.SetParent(transform, false);
    }

    public GameObject GetFx(string keyName)
    {
        if (fxDic.ContainsKey(keyName))
            return fxDic[keyName];
        return null;
    }

    public GameObject RemoveFx(string keyName, Transform newParent)
    {
        if (fxDic.ContainsKey(keyName))
        {
            GameObject fxGo = fxDic[keyName];
            fxDic.Remove(keyName);
            fxGo.transform.SetParent(newParent, false);
            return fxGo;
        }
        return null;
    }

    /// <summary>
    /// 屏蔽操作
    /// </summary>
    /// <param name="block"> true 和 false 要成对出现，有屏蔽也要有取消屏蔽 </param>
    public void BlockOperation(bool block)
    {
        TimerCloseBlock(block);
        if (cantTouchObj != null)
        {
            cantTouchObj.SetActive(block);
        }
        SetCantTouchSortOrder(100 + GameCommon.VisiblePopupCount * 10 + 1);
    }

    //防止开启了忘记关闭
    private void TimerCloseBlock(bool bo)
    {
        if (bo)
        {
            subscription?.Dispose();
            subscription = Observable.Timer(TimeSpan.FromSeconds(4f))
                .Subscribe(_ => BlockOperation(false));
        }
    }

    public void SetBlackSortOrder(int order = 30)
    {
        blackImage.GetComponent<Canvas>().sortingOrder = order;
    }

    public void SetCantTouchSortOrder(int order = 30)
    {
        if (cantTouchObj != null)
        {
            cantTouchObj.GetComponent<Canvas>().sortingOrder = order;
        }
    }
}
