﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using System;
using Doozy.Engine.UI;

public class UnlockCollectWaterPopView : ViewBase
{
    private GameObject guideRoot;
    private Button continueBtn;
    private Button closeBtn;

    protected override void OnAwake()
    {
        guideRoot = transform.Find("Container/Guide").gameObject;
        closeBtn = transform.Get<Button>("Container/Guide/CloseBtn");
        closeBtn.interactable = false;
        SoundPlayer.Instance.PlayWheelEnd();
    }

    protected override void OnShow()
    {
        guideRoot.SetActive(false);
        DoGuideAnim();
    }

    private void DoGuideAnim()
    {
        guideRoot.SetActive(true);
        Sequence seq = DOTween.Sequence();
        foreach (Transform item in guideRoot.transform)
        {
            item.localScale = Vector3.zero;
            seq.Append(item.DOScale(Vector3.one, 0.5f).SetEase(Ease.OutCubic));
        }
        seq.AppendCallback(() => closeBtn.interactable = true);
        closeBtn.SetButtonClick(
            () => {
                //ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);
                BoxBuilder.HidePopup(gameObject);
            });
    }
}
