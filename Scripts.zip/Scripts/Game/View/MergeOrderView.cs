using UniRx;
using UnityEngine;
using SoliUtils;
using Button = UnityEngine.UI.Button;
using System.Linq;
using System.Collections.Generic;
using UnityEngine.UI;
using System;

public class MergeOrderView : ViewBase
{
    private Button closeBtn;
    private Button okBtn;
    private List<GameObject> TaskItems;
    private List<GameObject> RewardItems;
    private MergeOrderNpcScrollView scrollView;
    private GameObject lockView;
    private GameObject taskView;
    private int currentNpcId;
    private List<int> NpcIds = new List<int>();
    // private Dictionary<int, bool> unlockNpc = new Dictionary<int, bool>();

    private Image rewardIcon;
    // private Text rewardCountText;
    private Image rewardProcessImg;
    private Text rewardProcessText;
    private GameObject itemModel;
    private GameObject timerObj;
    private List<Text> timerTexts = new List<Text>();
    private GameObject rewardObj;
    private GameObject arrowObj;

    protected override void OnAwake()
    {
        // NpcIds = configService.MergeItemConfig.Values
        //     .Where(cfg => cfg.itemType == (int)Constants.MergeItemType.Npc)
        //     .Select(cfg=>cfg.id)
        //     .ToList();
        NpcIds = dataService.GetUnlockNpcIds();
        currentNpcId = NpcIds[0];

        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(() =>
        {
            BoxBuilder.HidePopup(gameObject);
            if (dataService.OldDataVersionFlag)
            {
                BoxBuilder.ShowMergeVersionRewardPopup();
            }
        });

        arrowObj = transform.Get<Transform>("Container/TaskLayout/img/arrow").gameObject;
        rewardObj = transform.Get<Transform>("Container/TaskLayout/reward").gameObject;

        okBtn = transform.Get<Button>("Container/TaskLayout/reward/OkBtn");
        okBtn.SetButtonClick(() =>
        {
            if (dataService.IsFinishOrder(currentNpcId))
            {
                if (dataService.CommitMergeOrder(currentNpcId))
                {
                    BoxBuilder.HidePopup(gameObject);
                }
            }
            else
            {
                BoxBuilder.ShowToast("前往战斗获取宝箱吧");
            }
        });

        taskView = transform.Find("Container/TaskLayout").gameObject;
        lockView = transform.Find("Container/LockView").gameObject;
        lockView.SetActive(false);

        rewardIcon = transform.Get<Image>("Container/TaskLayout/reward/Icon");
        RewardItems = new List<GameObject>();
        // rewardCountText = transform.Get<Text>("Container/TaskLayout/reward/CountText");
        // rewardProcessImg = transform.Get<Image>("Container/TaskLayout/reward/processImg");
        // rewardProcessText = transform.Get<Text>("Container/TaskLayout/reward/processText");

        itemModel = transform.Get<Transform>($"Container/TaskLayout/img/Item").gameObject;
        itemModel.SetActive(false);
        TaskItems = new List<GameObject>();

        scrollView = transform.Get<MergeOrderNpcScrollView>("Container/ScrollView");

        var npcs = Enumerable.Range(0, NpcIds.Count)
                .Select(i => new NpcItemData(NpcIds[i]))
                .ToArray();

        scrollView.UpdateData(npcs);
        scrollView.SelectCell(NpcIds.IndexOf(currentNpcId));
        scrollView.OnSelectionChanged(OnSelectionChanged);

        timerObj = transform.Get<Transform>("Container/TaskLayout/img/Timer").gameObject;
        timerObj.SetActive(false);

        for (int i = 1; i <= 4; i++)
        {
            timerTexts.Add(transform.Get<Text>($"Container/TaskLayout/img/Timer/TimerText{i}"));
        }

    }

    void ShowOrder()
    {
        foreach (var item in TaskItems)
        {
            GameObject.DestroyImmediate(item);
        }
        TaskItems.Clear();
        foreach (var item in RewardItems)
        {
            GameObject.DestroyImmediate(item);
        }
        RewardItems.Clear();
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var orderData = dataService.GetMergeOrder(currentNpcId, out var _);
        if (orderData != null && !orderData.over)
        {
            timerObj.SetActive(false);
            int processMax = 0;
            int processNow = 0;
            foreach (var item in orderData.items)
            {
                var newItem = GameObject.Instantiate(itemModel, itemModel.transform.parent);
                newItem.SetActive(true);
                TaskItems.Add(newItem);
            }
            for (int i = 0; i < TaskItems.Count; i++)
            {
                Text nameText = TaskItems[i].Get<Text>("NameText");
                Text countText = TaskItems[i].Get<Text>("CountText");
                Image icon = TaskItems[i].Get<Image>("Icon");
                Image gou = TaskItems[i].Get<Image>("Gou");
                int item_id = orderData.items[i];
                nameText.text = configService.MergeItemConfig[item_id].name;
                countText.text = $"{orderData.process[i]}/{orderData.count[i]}";
                if (orderData.process[i] == orderData.count[i])
                {
                    countText.color = new Color32(27, 155, 4, 255);
                }
                // countText.gameObject.SetActive(orderData.process[i] < orderData.count[i]);
                gou.gameObject.SetActive(orderData.process[i] >= orderData.count[i]);
                icon.LoadPropSprite(item_id, true, () =>
                {
                    float targetHeight = 100;
                    float targetWidth = 80;
                    float originalWidth = icon.sprite.rect.width;
                    float originalHeight = icon.sprite.rect.height;
                    float aspectRatio = originalWidth / originalHeight;
                    float newWidth;
                    float newHeight;
                    if (originalHeight >= originalWidth)
                    {
                        newHeight = targetHeight;
                        newWidth = targetHeight * aspectRatio;
                    }
                    else
                    {
                        newWidth = targetWidth;
                        newHeight = targetWidth / aspectRatio;
                    }
                    icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
                });
                processMax += orderData.count[i];
                processNow += Math.Min(orderData.process[i], orderData.count[i]);
            }

            rewardIcon.gameObject.SetActive(false);
            int order_id = orderData.id;
            var orderInfo = configService.MergeOrderListConfig[order_id];
            string rewards_str = orderInfo.rewards;
            string[] rewards = rewards_str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            foreach (var rewardItemStr in rewards)
            {
                var _rewards = rewardItemStr.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
                int reward_item_id = int.Parse(_rewards[0]);
                int reward_item_num = int.Parse(_rewards[1]);
                var _rewardIcon = Instantiate(rewardIcon, rewardIcon.transform.parent);
                RewardItems.Add(_rewardIcon.gameObject);
                _rewardIcon.transform.localScale = Vector3.one;
                _rewardIcon.gameObject.SetActive(true);
                _rewardIcon.LoadPropSprite(reward_item_id, true, () =>
                {
                    float targetHeight = 70;
                    float targetWidth = 70;
                    float originalWidth = _rewardIcon.sprite.rect.width;
                    float originalHeight = _rewardIcon.sprite.rect.height;
                    float aspectRatio = originalWidth / originalHeight;
                    float newWidth;
                    float newHeight;
                    if (originalHeight >= originalWidth)
                    {
                        newHeight = targetHeight;
                        newWidth = targetHeight * aspectRatio;
                    }
                    else
                    {
                        newWidth = targetWidth;
                        newHeight = targetWidth / aspectRatio;
                    }
                    _rewardIcon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
                });
                if (configService.MergeItemConfig.ContainsKey(reward_item_id))
                    _rewardIcon.transform.Find("CountText").GetComponent<Text>().text = $"x{reward_item_num}";
                else
                    _rewardIcon.transform.Find("CountText").GetComponent<Text>().text = $"{reward_item_num}";
            }

            arrowObj.SetActive(true);
            rewardObj.SetActive(true);

            // rewardProcessText.text = $"{processNow} / {processMax}";
            // rewardProcessImg.rectTransform.sizeDelta = new Vector2(122 * Math.Min(1, processNow/(float)processMax), 24);
        }
        else
        {
            arrowObj.SetActive(false);
            rewardObj.SetActive(false);
            timerObj.SetActive(true);
            RefreshTimer();
        }

        LayoutRebuilder.ForceRebuildLayoutImmediate(taskView.GetComponent<RectTransform>());
    }

    private void RefreshTimer()
    {
        DateTime now = DateTime.Now;
        DateTime midnight = DateTime.Today.AddDays(1);
        TimeSpan timeRemaining = midnight - now;
        int hoursRemaining = timeRemaining.Hours;
        int minutesRemaining = timeRemaining.Minutes;
        int secondRemaining = timeRemaining.Seconds;
        int hourTens = hoursRemaining / 10;
        int hourOnes = hoursRemaining % 10;
        int minuteTens = minutesRemaining / 10;
        int minuteOnes = minutesRemaining % 10;

        if (hoursRemaining == 0 && minutesRemaining == 0)
            return;

        timerTexts[0].text = hourTens.ToString();
        timerTexts[1].text = hourOnes.ToString();
        timerTexts[2].text = minuteTens.ToString();
        timerTexts[3].text = minuteOnes.ToString();

        UniRx.Observable.Timer(TimeSpan.FromSeconds(secondRemaining)).Subscribe(_ =>
        {
            RefreshTimer();
        }).AddTo(this);
    }

    public void SetNpcId(int npc_id)
    {
        currentNpcId = npc_id;
        ShowOrder();
        scrollView.SelectCell(NpcIds.IndexOf(currentNpcId));
    }

    void OnSelectionChanged(int index)
    {
        var npc_id = NpcIds[index];
        // if(unlockNpc.ContainsKey(npc_id))
        // {
        taskView.SetActive(true);
        lockView.SetActive(false);
        SetNpcId(NpcIds[index]);
        // }
        // else
        // {
        //     taskView.SetActive(false);
        //     lockView.SetActive(true);
        // }
    }


}