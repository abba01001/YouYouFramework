﻿using Activities;
using Doozy.Engine;
using Doozy.Engine.UI;
using Model;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class VictoryPopView : ViewBase
{
    [SerializeField] private Button ExitBtn;
    [SerializeField] private Button CloseBtn;
    [SerializeField] private GameObject coinPrefab;
    [SerializeField] private GameObject bornCoinEf;
    [SerializeField] private RectTransform sprite;
    [SerializeField] private Animator selfAnim;
    [SerializeField] private Animator spriteAnim;
    [SerializeField] private GameObject spriteEf;
    private List<Transform> _list = new List<Transform>();
    protected override void OnAwake()
    {
        if (spriteEf != null)
        {
            spriteEf.gameObject.MSetActive(false);
        }
        selfAnim.enabled = false;
        spriteAnim.gameObject.MSetActive(false);
        bornCoinEf.gameObject.MSetActive(false);
        //CloseBtn.SetButtonClick(() => { BoxBuilder.HidePopup(gameObject); });
    }

    protected override void OnShow()
    {
        coinPrefab.gameObject.MSetActive(false);
        spriteAnim.gameObject.SetActive(true);
        spriteAnim.SetTrigger("Ruchang");
        Observable.Timer(TimeSpan.FromSeconds(110f / 60)).Subscribe(_ =>
        {
            selfAnim.enabled = true;
            Observable.Timer(TimeSpan.FromSeconds(0.5f)).Subscribe(_ =>
            {
                bornCoinEf.gameObject.MSetActive(true);
                Tween tween = ThreePowerBeizerFlyCoin(30, Vector3.zero);
                Observable.Timer(TimeSpan.FromSeconds(tween.Duration())).Subscribe(_ =>
                {
                });
            });
        });
    }

    protected override void OnViewInit(bool isFirstTime)
    {
        TypeEventSystem.Register<GameRechargeEvent>(UpdatePanel);
    }

    void UpdatePanel(GameRechargeEvent obj)
    {

    }

    public GameObject GetSpriteToResultView()
    {
        return sprite.gameObject;
    }


    public Tween ThreePowerBeizerFlyCoin(int coinCount, Vector3 startPos)
    {
        Vector3 endPos = new Vector3(sprite.anchoredPosition.x, sprite.anchoredPosition.y, 0);
        Vector3 beginPos = startPos;

        var control1Pos = new Vector3(beginPos.x, 0, 0);
        var control2Pos = new Vector3(endPos.x, 0, 0);
        beginPos.z = endPos.z = 0;
        float flyTime = Vector3.Distance(beginPos, endPos) / 1300;
        BeizerFlyAnimParam animParam = new BeizerFlyAnimParam(coinCount, beginPos,
            new Vector3[] {control1Pos, control2Pos}, endPos, flyTime);
        animParam.scale = 0.7f;
        animParam.startScale = 0.7f;
        animParam.endScale = 0.5f;
        animParam.moveEase = Ease.InQuad;
        animParam.firstArriveCall = () =>
        {
            if (spriteEf != null)
            {
                spriteEf.gameObject.MSetActive(true);
            }
        };
        return BeizerFlyCoin(animParam);
    }

    public Tween BeizerFlyCoin(BeizerFlyAnimParam animParam)
    {
        Sequence rootSeq = DOTween.Sequence();
        for (int i = 0; i < animParam.goCount; i++)
        {
            var coin = GameObjManager.Instance.PopGameObject(GameObjType.VictoryCoin, coinPrefab);
            coin.SetActive(true);
            coin.transform.SetParent(transform, false);
            coin.transform.Find("TX_jinbi_01").gameObject.MSetActive(true);
            coin.transform.Find("jingbishouji_01").gameObject.MSetActive(false);
            coin.transform.localScale = Vector3.one * 0.4f;
            coin.transform.localPosition = Vector3.zero;
            _list.Add(coin.transform);
        }
        
        for (var i = 0; i < animParam.goCount; i++)
        {
            int index = i;
            Vector3 offset = index < GoldView.flyGoldPoints.Length
                ? GoldView.flyGoldPoints[index]
                : (new Vector3(GameUtils.RandomRange(-1f, 1f), GameUtils.RandomRange(-1f, 1f)) * 100);
            Vector3 startPos = animParam.beginPos + (offset * animParam.scale) + animParam.splitOffset;

            Sequence seq = DOTween.Sequence();
            Transform coinTrans = _list[i].transform;
            coinTrans.localScale = Vector3.one * animParam.startScale;
            seq.Append(coinTrans.transform.DOLocalMove(startPos, animParam.splitTime).SetEase(Ease.OutQuad));

            seq.Join(coinTrans.transform.DOScale(Vector3.one * animParam.scale, animParam.splitTime));
            seq.AppendInterval(animParam.intervalTime * index + animParam.stopTime);

            seq.Append(coinTrans.transform.DOLocalPath(animParam.GetBeizerList(startPos), animParam.flyTime,
                PathType.CatmullRom, gizmoColor: Color.red).SetEase(animParam.moveEase));
            seq.Join(coinTrans.transform.DOScale(Vector3.one * animParam.endScale, animParam.flyTime)
                .SetEase(Ease.InQuart));
            if (index == 0)
            {
                SoundPlayer.Instance.PlayGoldFly(2);
                seq.AppendCallback(() => animParam.firstArriveCall?.Invoke());
            }
            seq.AppendCallback(() =>
            {
                coinTrans.Find("TX_jinbi_01").gameObject.MSetActive(false);
                coinTrans.Find("jingbishouji_01").gameObject.MSetActive(true);
                animParam.everyArriveCall?.Invoke(index);
            });
            rootSeq.Join(seq);
        }

        rootSeq.AppendCallback(() =>
        {
            animParam.endCall?.Invoke();
            if (spriteEf != null)
            {
                spriteEf.gameObject.MSetActive(false);
            }
        });
        rootSeq.onKill += () =>
        {
            foreach (var item in _list)
            {
                if (item != null)
                    GameObjManager.Instance.PushGameObject(item.gameObject);
            }
        };
        return rootSeq;
    }



    protected override void OnViewDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatePanel);
    }
}