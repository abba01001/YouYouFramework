using System;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using UniRx;
using Doozy.Engine;
using System.Collections.Generic;
using Activities;
using Doozy.Engine.UI;
using Model;
using SoliUtils;

public class ResultView : ViewBase
{
    [SerializeField] private Button continueBtn;
    [SerializeField] private Text closeTip;
    [SerializeField] private GameObject coinPrefab;
    private GameObject caidaiFx;
    private GameObject winFx;
    private Animator selfAnim;
    private const string caidaiFxStr = "Assets/Res/Prefabs/FX/jiesuan_caidai_tx_01.prefab";
    private const string winFxStr = "Assets/Res/Prefabs/FX/jiesuan_win_dh_01.prefab";
    private GameObject sprite;
    private int getBuildCoin;
    private int getCoin;
    private Dictionary<int, int> tempRewardDic = new Dictionary<int, int>();
    private List<GameObject> ItemList = new List<GameObject>();
    private Transform ItemParent;
    private readonly int rookieId = 27;
    GameFinishEvent uiData;
    private List<Transform> _list = new List<Transform>();
    private Transform box;

    protected override void OnAwake()
    {
        coinPrefab.gameObject.MSetActive(false);
        selfAnim = GetComponent<Animator>();
        selfAnim.enabled = false;
        continueBtn.SetButtonClick(ContinueBtnEvent);
        ItemParent = transform.Find("Content/Reward/Item/Activity");
        box = transform.Find("Content/Reward/Item/Box");
        for (int i = 0; i < ItemParent.childCount; i++)
        {
            ItemList.Add(ItemParent.GetChild(i).gameObject);
        }

        foreach (var t in transform.GetComponentsInChildren<Canvas>(true))
        {
            t.sortingLayerName = "UI";
        }
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<GameFinishEvent>(OnGameFinishEvent);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<GameFinishEvent>(OnGameFinishEvent);
    }

    private void SetCanClose(bool canClose)
    {
        if (canClose)
        {
            continueBtn.gameObject.SetActive(true);
            closeTip.DOFade(1, 0.2f).SetDelay(0.01f);
            continueBtn.interactable = true;
        }
        else
        {
            closeTip.DOFade(0, 0);
            continueBtn.gameObject.SetActive(false);
        }
    }

    protected override void OnShow()
    {
        // sprite = BoxBuilder.GetVictoryPopupSprite();
        // if (sprite != null) sprite.transform.SetParent(transform.Find("Content"));
        BoxBuilder.HideVictoryPopup();
        selfAnim.enabled = false;
        box.gameObject.SetActive(true);
        SetCanClose(false);
        if (uiData == null) return;
        //getBuildCoin = uiData.gameData.CaculateAddBuildCoin();
        getCoin = uiData.gameData.GetCoin() + uiData.gameData.GetLeftCardCoin() + uiData.gameData.GetGuaranteeCoin();
        //ActivityManager.Instance.CheckOpenActivity(true);
        dataService.SaveData(true);

        GlobalRes.DynamicLoadPrefab(winFxStr, (tempGo) =>
        {
            winFx = tempGo;
            FxMaskView.Instance.AddFx(winFxStr, winFx);
            winFx.transform.position = Vector3.zero;
            winFx.SetActive(true);
        });

        SoundPlayer.Instance.PlayFirework();


        Sequence seq = DOTween.Sequence();
        seq.InsertCallback(4f, () => SetCanClose(true));


        foreach (var item in ItemList)
        {
            item.gameObject.SetActive(false);
            item.Get<Text>("Text").text = "0";
        }

        ShowReward();
        //HomeView.waitShowBox = true;
    }

    private void ShowReward()
    {
        selfAnim.enabled = true;
        selfAnim.SetTrigger("ShowReward");
        CheckCollectAnim();

        Observable.Timer(TimeSpan.FromSeconds(1.5f)).Subscribe(_ =>
        {
            int activityCount = 0;
            foreach (var model in ActivityManager.Instance.GetCollectActivity())
            {
                BaseActivityData data =
                    ActivityManager.Instance.GetActivityByType(model.type).localData as BaseActivityData;
                if (data.ResultAddCount > 0) activityCount++;
            }
            // int count = activityCount + 1;
            // for (int i = 0; i < count; i++)
            // {
            //     ThreePowerBeizerFlyCoin(30,Vector3.zero, i);
            // }
        });
    }

    private void CheckCollectAnim()
    {
        GlobalRes.DynamicLoadPrefab(caidaiFxStr, (tempGo) =>
        {
            SoundPlayer.Instance.PlayMainSound("Continue_Confetti");
            caidaiFx = tempGo;
            FxMaskView.Instance.AddFx(caidaiFxStr, caidaiFx);
            caidaiFx.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 426);
            SetParticlePlay(true);
            CheckPowerItemUnlock();
            dataService.TodayLevelPassTimes++;
        });
        ItemList[0].gameObject.SetActive(true);
        ItemList[0].Get<Text>("Text").text = getCoin.ToString();
        int index = 1;
        foreach (var model in ActivityManager.Instance.GetCollectActivity())
        {
            BaseActivityData data =
                ActivityManager.Instance.GetActivityByType(model.type).localData as BaseActivityData;
            if (data.ResultAddCount > 0)
            {
                ItemList[index].gameObject.MSetActive(true);
                var icon = ItemList[index].Get<Image>("Icon");
                var text = ItemList[index].Get<Text>("Text");
                icon.SetSpriteByAtlas(Constants.AtlasNamePath.TextureCommonAtlas, GameUtils.GetCollectIcon(model.type),
                    true, () =>
                    {
                        float targetHeight = 100;
                        float targetWidth = 80;
                        float originalWidth = icon.sprite.rect.width;
                        float originalHeight = icon.sprite.rect.height;
                        float aspectRatio = originalWidth / originalHeight;
                        float newWidth;
                        float newHeight;
                        if (originalHeight >= originalWidth)
                        {
                            newHeight = targetHeight;
                            newWidth = targetHeight * aspectRatio;
                        }
                        else
                        {
                            newWidth = targetWidth;
                            newHeight = targetWidth / aspectRatio;
                        }

                        icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
                    });
                text.text = data.ResultAddCount.ToString();
                index++;
            }
        }

        Observable.NextFrame().Subscribe(_ =>
        {
            ItemParent.gameObject.MSetActive(false);
            ItemParent.gameObject.MSetActive(true);
        });
    }

    private void CheckPowerItemUnlock()
    {
        foreach (var item in configService.PowerItemConfig)
        {
            PowerItemModel model = item.Value;
            if (model.unlockReward > 0 && model.unlockLevel <= dataService.MaxLevel &&
                !dataService.GetPowerItemIsUnlock(item.Key))
            {
                dataService.SetUnlockPowerItem(item.Key);
                dataService.AddProp(item.Key, model.unlockReward, PropChangeWay.UnlockPowerItem);
            }
        }
    }

    private void OnDisable()
    {
        FxMaskView.Instance.RemoveFx(winFxStr, null);
        if (sprite != null)
        {
            Destroy(sprite);
            sprite = null;
        }

        GameCommon.IsExitGame = true;
        Destroy(winFx, 2);
        winFx = null;
        tempRewardDic.Clear();
    }

    private void OnGameFinishEvent(GameFinishEvent e)
    {
        uiData = e;
    }

    private void SetParticlePlay(bool isPlay)
    {
        if (caidaiFx == null) return;
        ParticleSystem.MainModule particleInfo = caidaiFx.GetComponent<ParticleSystem>().main;
        particleInfo.loop = isPlay;
    }

    private void ContinueBtnEvent()
    {
        SoundPlayer.Instance.PlayButton();
        continueBtn.interactable = false;
        selfAnim.SetTrigger("HideReward");

        FlyRewardBox(null);
        box.gameObject.SetActive(false);

        Observable.Timer(TimeSpan.FromSeconds(2.5f)).Subscribe(_ =>
        {
            if (levelBoxBtnData != null)
            {
                levelBoxBtnData.gameObject.GetComponent<Button>().interactable = true;
                levelBoxBtnData.Reset();
            }
            if (CheckGuideLevel())
            {
                CleanEffect();
                return;
            }

            if (ActivityManager.Instance.LavaPassActivity.CheckShowLavaPopup(GameUtils.ExitResultView))
            {
                CleanEffect();
                return;
            }

            ExitResultView();
        });
    }

    private void ExitResultView()
    {
        BoxBuilder.ShowSceneChangePop(() =>
        {
            GameEventMessage.SendEvent(Constants.DoozyEvent.GameEnd);
            CleanEffect();
        }, BoxBuilder.HideSceneChangePop);
    }

    private void CleanEffect()
    {
        if (caidaiFx == null) return;
        SetParticlePlay(false);
        FxMaskView.Instance.RemoveFx(caidaiFxStr, null);
        Destroy(caidaiFx);
        caidaiFx = null;
    }

    private bool CheckGuideLevel()
    {
        if (dataService.MaxLevel < int.Parse(configService.ValueConfig["GuideEndStage"]))
        {
            closeTip.DOFade(0, 0);
            GameCommon.SetTweenSpeed(0.65f);
            GoldView.Instance.SortingOrder = SortingOrder + 1;
            //GoldView.Instance.ShowBuildCoinRoot(true);
            foreach (var pair in dataService.GetResultProp())
            {
                if (pair.Key == (int) PropEnum.Coin)
                {
                    // GoldView.Instance.ThreePowerBeizerFlyCoin((int) PropEnum.Coin, dataService.Coin - pair.Value,
                    //     dataService.Coin, ItemList[0].transform.position);
                    //ItemList[0].SetActive(false);
                }
                // else if (pair.Key == (int)PropEnum.BuildCoin)
                // {
                //     GoldView.Instance.ThreePowerBeizerFlyCoin((int)PropEnum.BuildCoin,dataService.BuildCoin - pair.Value, dataService.BuildCoin,ItemList[1].transform.position);
                //     ItemList[1].SetActive(false);
                // }
            }

            Observable.Timer(TimeSpan.FromSeconds(1.7f)).Subscribe(_ =>
            {
                GameCommon.SetTweenSpeed(1f);
                BoxBuilder.ShowNextStartPopup();
            });
            dataService.ClearResultProp();
            dataService.SaveData(true);
            return true;
        }

        return false;
    }


    public Tween ThreePowerBeizerFlyCoin(int coinCount, Vector3 startPos,int index)
    {
        Vector3 endPos = new Vector3(sprite.GetComponent<RectTransform>().anchoredPosition.x, sprite.GetComponent<RectTransform>().anchoredPosition.y, 0);
        Vector3 beginPos = startPos;

        var control1Pos = new Vector3(beginPos.x, 0, 0);
        var control2Pos = new Vector3(endPos.x, 0, 0);
        beginPos.z = endPos.z = 0;
        float flyTime = Vector3.Distance(beginPos, endPos) / 1300;
        BeizerFlyAnimParam animParam = new BeizerFlyAnimParam(coinCount, beginPos,
            new Vector3[] {control1Pos, control2Pos}, endPos, flyTime);
        animParam.parent = ItemList[index].transform;
        animParam.scale = 0.7f;
        animParam.startScale = 0.7f;
        animParam.endScale = 0.5f;
        animParam.moveEase = Ease.InQuad;
        animParam.firstArriveCall = () => { };
        return BeizerFlyCoin(animParam);
    }

    public Tween BeizerFlyCoin(BeizerFlyAnimParam animParam)
    {
        Sequence rootSeq = DOTween.Sequence();
        for (int i = 0; i < animParam.goCount; i++)
        {
            var coin = GameObjManager.Instance.PopGameObject(GameObjType.VictoryCoin, coinPrefab);
            coin.SetActive(true);
            coin.transform.Find("TX_jinbi_01").gameObject.MSetActive(true);
            coin.transform.Find("jingbishouji_01").gameObject.MSetActive(false);
            coin.transform.localScale = Vector3.one * 0.4f;
            coin.transform.localPosition = Vector3.zero;
            coin.transform.SetParent(transform);
            animParam.beginPos = coin.transform.position;
            _list.Add(coin.transform);
        }

        var control1Pos = new Vector3(animParam.beginPos.x, 0, 0);
        var control2Pos = new Vector3(animParam.endPos.x, 0, 0);
        float flyTime = Vector3.Distance(animParam.beginPos, animParam.endPos) / 1300;
        animParam.flyTime = flyTime;
        animParam.controlPosArray = new[] {control1Pos, control2Pos};
        for (var i = 0; i < animParam.goCount; i++)
        {
            int index = i;
            Vector3 offset = index < GoldView.flyGoldPoints.Length
                ? GoldView.flyGoldPoints[index]
                : (new Vector3(GameUtils.RandomRange(-1f, 1f), GameUtils.RandomRange(-1f, 1f)) * 100);
            Vector3 startPos = animParam.beginPos + (offset * animParam.scale) + animParam.splitOffset;

            Sequence seq = DOTween.Sequence();
            Transform coinTrans = _list[i].transform;
            coinTrans.localScale = Vector3.one * animParam.startScale;
            seq.Append(coinTrans.transform.DOLocalMove(startPos, animParam.splitTime).SetEase(Ease.OutQuad));

            seq.Join(coinTrans.transform.DOScale(Vector3.one * animParam.scale, animParam.splitTime));
            seq.AppendInterval(animParam.intervalTime * index + animParam.stopTime);

            seq.Append(coinTrans.transform.DOLocalPath(animParam.GetBeizerList(startPos), animParam.flyTime,
                PathType.CatmullRom, gizmoColor: Color.red).SetEase(animParam.moveEase));
            seq.Join(coinTrans.transform.DOScale(Vector3.one * animParam.endScale, animParam.flyTime)
                .SetEase(Ease.InQuart));
            if (index == 0)
            {
                SoundPlayer.Instance.PlayGoldFly(2);
                seq.AppendCallback(() => animParam.firstArriveCall?.Invoke());
            }

            seq.AppendCallback(() =>
            {
                coinTrans.Find("TX_jinbi_01").gameObject.MSetActive(false);
                coinTrans.Find("jingbishouji_01").gameObject.MSetActive(true);
                animParam.everyArriveCall?.Invoke(index);
            });
            rootSeq.Join(seq);
        }

        rootSeq.AppendCallback(() => animParam.endCall?.Invoke());
        rootSeq.onKill += () =>
        {
            foreach (var item in _list)
            {
                if (item != null)
                    GameObjManager.Instance.PushGameObject(item.gameObject);
            }
        };
        return rootSeq;
    }


    private GameObjectData levelBoxBtnData;
    //������е���ť
    private void FlyRewardBox(Action callBack)
    {
        levelBoxBtnData = HomeView.Instace.levelBoxBtnData;
        levelBoxBtnData.transform.SetParent(transform);
        levelBoxBtnData.transform.localPosition = levelBoxBtnData.viewLocalPosition;
        Vector3 pos = levelBoxBtnData.transform.position;
        levelBoxBtnData.transform.DOMoveX(pos.x-80, 0.5f).From(true);
        levelBoxBtnData.gameObject.SetActive(true);
        levelBoxBtnData.gameObject.GetComponent<Button>().interactable = false;
        GameObject go = GameObjManager.Instance.PopGameObject(GameObjType.RewardBoxItem);
        go.SetActive(true);
        go.transform.SetParent(transform);
        go.transform.localScale = Vector3.one;
        go.transform.localPosition = Vector3.zero;
        RectTransform rectTransform = go.GetComponent<RectTransform>();
        rectTransform.offsetMin = Vector2.zero;
        rectTransform.offsetMax = Vector2.zero;
        RewardBoxItem rewardBoxItem = go.GetComponent<RewardBoxItem>();
        rewardBoxItem.SetSortingOrder(transform.GetComponent<Canvas>().sortingOrder + 1);
        rewardBoxItem.StartPlay(pos, () =>
        {
            HomeView.Instace.UpdateLevelBoxRemind();
            GameObjManager.Instance.PushGameObject(go);
            if(callBack != null)
                callBack.Invoke();
        });
    }
}