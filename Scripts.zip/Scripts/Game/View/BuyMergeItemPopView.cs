﻿using SoliUtils;
using UnityEngine;
using UnityEngine.UI;

public class BuyMergeItemPopView : ViewBase
{
    protected override void OnAwake()
    {
        reportOnShow = false;
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
            GoldView.Instance.SortingOrder = 92;
            GoldView.Instance.ShowBuildCoinRoot(false);
        });
    }

    public void SetBuyItem(int item_id,int grid_id)
    {
        MergeItemConfig config = configService.MergeItemConfig[item_id];
        transform.Get<Text>("Container/ItemNameText").text = config.name;
        transform.Get<Text>("Container/BuyBtn/StageCost").text = config.price.ToString();
        transform.Get<Button>("Container/BuyBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(2);
            if (dataService.BuildCoin >= config.price)
            {
                if (!dataService.OpenMergeMapBox(grid_id))
                {
                    BoxBuilder.ShowToast("打开宝箱失败");
                }
                else
                {
                    dataService.UseProp((int)PropEnum.BuildCoin, PropChangeWay.BuyMergeItem, config.price);
                    BoxBuilder.HidePopup(gameObject);
                }
            }
            else
            {
                BoxBuilder.ShowToast("建造币不足");
            }
        });
        Image propImage = transform.Get<Image>("Container/ItemIcon");
        propImage.LoadPropSprite(item_id,true,()=> {
            RectTransform rtf = propImage.GetComponent<RectTransform>();
            Debug.Log(rtf.sizeDelta);
            rtf.sizeDelta = rtf.sizeDelta / 100;
            Debug.Log(rtf.sizeDelta);
        });
    }

}