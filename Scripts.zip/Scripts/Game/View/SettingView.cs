using System.Linq;
using Doozy.Engine;
using Doozy.Engine.UI;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

namespace View
{
    public class SettingView : ViewBase
    {
        [SerializeField] private Button closeBtn;
        [SerializeField] private Button gmBtn;
        [SerializeField] private Button fbSaveBtn;
        [SerializeField] private Button fbConnectBtn;
        [SerializeField] private Button languageBtn;
        [SerializeField] private Button musicBtn;
        [SerializeField] private Button soundBtn;
        [SerializeField] private GameObject musicMute;
        [SerializeField] private GameObject soundMute;
        [SerializeField] private Text versionText;
        [SerializeField] private Text userId;
        protected override void OnAwake()
        {
            //            languageText.text = Constants.LanguageDic.First(x => x.Value.Equals(LocalizationManager.CurrentLanguage)).Key;
            musicBtn.SetButtonClick(OnMusicBtnClick);
            soundBtn.SetButtonClick(OnSoundBtnClick);
            closeBtn.SetButtonClick(ExitFunc);//() =>
                                              //GameEventMessage.SendEvent(Constants.DoozyEvent.BackHomeView)

            //);
            gmBtn.SetButtonClick(() => BoxBuilder.ShowGm());
            fbSaveBtn.SetButtonClick(OnFbSaveBtnClick);
            fbConnectBtn.SetButtonClick(OnFbUnlinkBtnClick);
            languageBtn.SetButtonClick(OnLanguageBtnClick);
            AddEvent();
#if UNITY_EDITOR
            gmBtn.gameObject.SetActive(true);
#else
            gmBtn.gameObject.SetActive(GameCommon.IsGmMode);
#endif
            // WeChatMiniGame.CheckWxAuthInfo((ret, path) =>
            // {
            // });
        }

        private void ExitFunc()
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
        }

        private void AddEvent()
        {
            TypeEventSystem.Register<MusicMuteEvent>(OnMusicMuteEvent);
            TypeEventSystem.Register<SoundMuteEvent>(OnSoundMuteEvent);
            TypeEventSystem.Register<FbLinkStateRefreshEvent>(OnFbLinkStateRefresh);
        }

        private void RemoveEvent()
        {
            TypeEventSystem.UnRegister<MusicMuteEvent>(OnMusicMuteEvent);
            TypeEventSystem.UnRegister<SoundMuteEvent>(OnSoundMuteEvent);
            TypeEventSystem.UnRegister<FbLinkStateRefreshEvent>(OnFbLinkStateRefresh);
        }

        private void OnMusicMuteEvent(MusicMuteEvent obj)
        {
            // musicMute.SetActive(obj.isMute);
        }

        private void OnSoundMuteEvent(SoundMuteEvent obj)
        {
            // soundMute.SetActive(obj.isMute);
        }

        private void OnFbLinkStateRefresh(FbLinkStateRefreshEvent obj)
        {
            BtnShowCtrl();
        }

        protected override void OnShow()
        {
            musicMute.SetActive(dataService.MusicMute);
            soundMute.SetActive(dataService.SoundMute);
            BtnShowCtrl();
            // var assetVersion = (long)storageService.Load<object>(Constants.StorageKey.AssetVersion, 0L);
            // versionText.text = $"v{DeviceUtils.GetVersionName()} r{Constants.ResVersion}-{assetVersion}";

            versionText.text = $"{DeviceUtils.GetEnvVersion()}-{DeviceUtils.GetVersionName()}";
            userId.text = $"UID : {dataService.UserId}";
        }

        private void BtnShowCtrl()
        {
            switch (dataService.UserType)
            {
                case 0:
                    fbSaveBtn.gameObject.SetActive(false);
                    fbConnectBtn.gameObject.SetActive(false);
                    break;
                case 1:
                    fbConnectBtn.gameObject.SetActive(false);
                    fbSaveBtn.gameObject.SetActive(false);
                    break;
            }
        }

        private void OnMusicBtnClick()
        {
            SoundPlayer.Instance.PlayButton();
            dataService.MusicMute = !dataService.MusicMute;
            musicMute.SetActive(dataService.MusicMute);
            if (dataService.MusicMute)
                SoundPlayer.Instance.PauseBgm();
            else
                SoundPlayer.Instance.UnPauseBgm();
        }

        private void OnSoundBtnClick()
        {
            SoundPlayer.Instance.PlayButton();
            dataService.SoundMute = !dataService.SoundMute;
            soundMute.SetActive(dataService.SoundMute);
        }

        private void OnFbSaveBtnClick()
        {
            SoundPlayer.Instance.PlayButton();
            Debug.Log($">>> SettingView >> OnFbSaveBtnClick ...");
#if UNITY_EDITOR
            Debug.LogError($">>> SettingView >> 先用真机测试吧，编辑器上有点问题，等找到原因再放出来 ...");
            return;
#endif
            // 监听登录结果
            // LoginMgr.ON_LOGIN_RESULT += OnLoginCallBack;

            // 登录
            // LoginMgr.INSTANCE.DoLogout();
            // LoginMgr.INSTANCE.DoLogin();
        }

        //         private void OnLoginCallBack(SignCallBackMsg callback)
        //         {
        //             if (callback.state)
        //             {
        // //                FirebaseUtils.Instance.FirebaseLinkWithFacebookAccount(callback.token, BtnShowCtrl);
        //                 string userId = LoginMgr.INSTANCE.GetUserId();
        //                 Debug.Log($">>> SettingView >> OnLoginCallBack ...callback  userId:{userId}");
        //                 BoxBuilder.ShowCommonLoadingPopup();
        //                 FirebaseUtils.Instance.FirebaseLinkWithFacebookAccount(userId, () =>
        //                 {
        //                     BoxBuilder.ShowDataSyncPopup();
        //                     BoxBuilder.HideCommonLoadingPopup();
        //                 });
        //                 return;
        //             }
        //             Debug.Log($">>> SettingView >> OnLoginCallBack ...callback failed:{callback.errorMsg}");   
        //         }

        private void OnFbUnlinkBtnClick()
        {
            // SoundPlayer.Instance.PlayButton();
            // BoxBuilder.ShowSignOutConfirmPopup(() => FirebaseUtils.Instance.FirebaseUnlinkWithFacebookAccount(BtnShowCtrl));
            // Debug.Log($">>> SettingView >> OnFbConnectBtnClick ... userType:{dataService.UserType}");
        }

        private void OnLanguageBtnClick()
        {
            GlobalRes.DynamicLoadView(Constants.DoozyView.Language, () =>
            {
                SoundPlayer.Instance.PlayButton();
                // GameEventMessage.SendEvent(Constants.DoozyEvent.ShowLanguage);
            });
        }

        protected override void OnViewDestroy()
        {
            // LoginMgr.ON_LOGIN_RESULT -= OnLoginCallBack;
            RemoveEvent();
        }
    }
}