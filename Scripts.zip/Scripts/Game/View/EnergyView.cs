﻿using Activities;
using SoliUtils;
using System;
using UniRx;
using UnityEngine;
using UnityEngine.UI;

public class EnergyView : ViewBase
{
    private Transform _timeTransform;
    private Text _energyText;
    private Text _timeText;
    private Text _coinCostText;
    private Transform _adCountTransform;
    private Text _adCountText;
    private Text _adBtnText;
    private Text _adCDText;
    private IEnergyActivity _energyActivity;
    private IDisposable _subscription;
    protected override void OnAwake()
    {
        _energyActivity = ActivityManager.Instance.EnergyActivity;

        Button _closeBtn = transform.Get<Button>("Container/CloseBtn");
        _closeBtn.SetButtonClick(CloseFunc);

        Transform energy = transform.Find("Container/Energy");
        _energyText = energy.Get<Text>("EnergyBg/EnergyText");
        _timeTransform = energy.Find("TimeBg");
        _timeText = energy.Get<Text>("TimeBg/TimeText");

        Transform coinPanel = transform.Find("Container/CoinPanel");
        Button coinBtn = coinPanel.Get<Button>("Button");
        coinBtn.SetButtonClick(OnClickCoinBtn);
        _coinCostText = coinPanel.Get<Text>("Button/Text");

        Transform adPanel = transform.Find("Container/ADPanel");
        Button adBtn = adPanel.Get<Button>("Button");
        adBtn.SetButtonClick(OnClickADBtn);
        
        _adBtnText = adPanel.Get<Text>("Button/Text");
        _adCDText = adPanel.Get<Text>("Button/CDText");
        _adCountTransform = adPanel.Find("Count");
        _adCountText = adPanel.Get<Text>("Count/Text");
    }


    protected override void OnViewInit(bool isFirst)
    {
        UpdateEnergyText();
        UpdateTimeText();
        UpdateCostText();
        UpdateADBtn();

        if (!isFirst)
        {
            return;
        }
        _subscription = UniRx.Observable.Interval(TimeSpan.FromSeconds(1)).Subscribe(_ =>
        {
            UpdateEnergyText();
            UpdateTimeText();
            UpdateCostText();
            UpdateADBtn();
            bool isFull = ActivityManager.Instance.EnergyActivity.GetMaxEnergy() == ActivityManager.Instance.EnergyActivity.GetCurrentEnergy();
            if (isFull)
            {
                BoxBuilder.HidePopup(gameObject);
            }
        });
    }

   

    protected override void OnInitedDestroy()
    {
        _subscription?.Dispose();
    }

    protected override void OnShow()
    {

    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
        //_energyActivity.UseEnergy(1);
    }

    private void OnClickCoinBtn()
    {
        SoundPlayer.Instance.PlayButton();
        if (_energyActivity.GetCurrentEnergy() < _energyActivity.GetMaxEnergy())
        {
            if (_energyActivity.BuyEnergy())
            {
                UpdateEnergyText();
                BoxBuilder.ShowToast("购买成功");
            }
            else
            {
                BoxBuilder.ShowToast("您的金币不足");
            }
        }
        else
        {
            BoxBuilder.ShowToast("您的体力已满");
        }
    }

    private void OnClickADBtn()
    {
        if (GetADRemainCount() > 0)
        {
            //SoundPlayer.Instance.PlayButton();
#if UNITY_EDITOR
            _energyActivity.OnWatchADComplete();
            return;
#endif
            AdPlayer.ShowEnergyAd(() =>
            {
                //BoxBuilder.HidePopup(gameObject);
                _energyActivity.OnWatchADComplete();
            });
            
        }
        
    }

    private void UpdateEnergyText()
    {
        _energyText.text = _energyActivity.GetCurrentEnergy().ToString();
        
    }

    private void UpdateTimeText()
    {
        int second = _energyActivity.GetAutoRecoverCountDown();
        if (second > 0)
        {
            _timeTransform.gameObject.SetActive(true);
            _timeText.text = TimeUtils.SecondFormatDdHhMmSs(second);
        }
        else
        {
            _timeTransform.gameObject.SetActive(false);
        }
        
    }

    private void UpdateCostText()
    {
        int cost = _energyActivity.GetBuyEnergyCost();
        _coinCostText.text = cost.ToString();
    }

    public void UpdateADBtn()
    {
        int remainCount = GetADRemainCount();
        _adCountText.text = remainCount.ToString();
        if (remainCount > 0)
        {
            _adBtnText.gameObject.SetActive(true);
            _adCDText.gameObject.SetActive(false);
            _adCountTransform.gameObject.SetActive(true);
        }
        else
        {
            _adBtnText.gameObject.SetActive(false);
            _adCDText.gameObject.SetActive(true);
            _adCountTransform.gameObject.SetActive(false);
            int second = _energyActivity.GetCD();
            _adCDText.text = TimeUtils.SecondFormatDdHhMmSs(second);
        }
        
    }

    private int GetADRemainCount()
    {
        int dayADCount = _energyActivity.GetDayADCount();
        int remainCount = _energyActivity.GetConfig().ad_count - dayADCount;
        return remainCount;
    }
}