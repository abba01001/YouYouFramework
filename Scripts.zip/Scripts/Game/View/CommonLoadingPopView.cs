using DG.Tweening;
using UnityEngine;

public class CommonLoadingPopView : ViewBase
{
    [SerializeField] private Transform loadingTrans;
    protected override void OnAwake()
    {
        reportOnShow = false;
        loadingTrans.DOLocalRotate(new Vector3(0, 0, -360), 2, RotateMode.FastBeyond360)
            .SetLoops(-1, LoopType.Restart);
    }

    protected override void OnViewDestroy()
    {
        loadingTrans.DOKill();
    }
}