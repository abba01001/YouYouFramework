
using UnityEngine;
using SoliUtils;
using Button = UnityEngine.UI.Button;
using UnityEngine.UI;
using UniRx;

public class MergeUnlockGridView : ViewBase
{
    private Transform frame;
    private ThroughButton closeBtn;
    private Slider proSlider;
    private Text proText;
    private Button healBtn;
    private int gridId = -1;
    private bool closeFlag = false;

    protected override void OnAwake()
    {
        frame = transform.Get<Transform>("Frame");

        closeBtn = transform.Get<ThroughButton>("CloseBtn");
        // closeBtn.SetButtonClick(() => { BoxBuilder.HidePopup(gameObject); });


        healBtn = transform.Get<Button>("Frame/HealBtn");
        healBtn.SetButtonClick(() =>
        {
            if (closeFlag)
                return;
            closeFlag = true;
            BoxBuilder.HidePopup(gameObject);
            BoxBuilder.ShowInstructionsPurifyPopup();
        });

        proSlider = transform.Get<Slider>("Frame/Slider");
        proText = transform.Get<Text>("Frame/ProText");

    }

    void ShowTip()
    {
        var camera = Camera.main;
        var wolrdPos = MergeGameController.Instance.GetGridWorldPos(gridId);
        wolrdPos.z = 0;
        Vector3 screenPos = camera.WorldToScreenPoint(wolrdPos);
        RectTransformUtility.ScreenPointToLocalPointInRectangle(frame.parent.GetComponent<RectTransform>(),
            screenPos, camera, out Vector2 uiPos);
        frame.localPosition = uiPos + new Vector2(0, 25);

        int now = dataService.GetGridExp(gridId);
        int max = configService.MergeMapConfig[gridId].unlock_exp;

        proText.text = $"{now}/{max}";
        proSlider.value = now / (float)max;

        closeBtn.EnterEvent = () =>
        {
            if (closeFlag)
                return;
            closeFlag = true;
            Observable.NextFrame().Subscribe((x) =>
            {
                BoxBuilder.HidePopup(gameObject);
            });
        };
    }


    public void SetGridId(int grid_id)
    {
        closeFlag = false;
        gridId = grid_id;
        ShowTip();
    }
}