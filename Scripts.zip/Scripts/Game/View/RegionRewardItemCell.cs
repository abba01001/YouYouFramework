using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using Coffee.UIExtensions;

public class RegionRewardItemCell : ListViewCell
{
    void Awake()
    {
        gameObject.SetActive(true);
    }

    public override void FillData(params object[] data)
    {
        var levelText = transform.Get<Text>("LevelText");
        var gotImg = transform.Get<Image>("GotImg");
        var levelImg = transform.Get<Image>("LevelImg");


        var dat = (MergeRegionRewardsConfig)data[0];
        levelText.text = dat.level.ToString();

        var dataService = MainContainer.Container.Resolve<IDataService>();
        var info = dataService.GetRegionInfo(dat.id);

        var uf = levelImg.GetComponent<UIEffect>();
        uf.enabled = dat.level > info.level;
        gotImg.gameObject.SetActive(dat.level <= info.level);

        if (dat.cloud_id > 0)
        {
            return;
        }
        if (dat.build_lv > 0)
        {
            var iconImg = transform.Get<Image>("Icon");
            iconImg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewRegionRewards, $"island_zxqs_tb_{dat.id}", true);
            return;
        }

        var itemId = -1;
        if (!string.IsNullOrEmpty(dat.rewards))
        {
            string rewards_str = dat.rewards;
            string[] rewards = rewards_str.Split(GameUtils.SecondSeparator, StringSplitOptions.RemoveEmptyEntries);
            rewards = rewards[0].Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
            itemId = int.Parse(rewards[0]);
        }
        if (itemId != -1)
        {
            var iconImg = transform.Get<Image>("Icon");
            var getBtn = transform.Get<Button>("GetBtn");
            var nameText = transform.Get<Text>("NameText");

            List<int> rewardLv = new List<int>(info.rewardLv);
            if(rewardLv.Contains(dat.level))
            {
                getBtn.gameObject.SetActive(true);
                gotImg.gameObject.SetActive(false);
                getBtn.onClick.RemoveAllListeners();
                getBtn.onClick.AddListener(()=>{
                    dataService.GetRegionReward(dat.id, dat.level);
                    getBtn.gameObject.SetActive(false);
                    gotImg.gameObject.SetActive(true);
                });
            }
            else
            {
                getBtn.gameObject.SetActive(false);
            }

            var configService = MainContainer.Container.Resolve<IConfigService>();
            nameText.text = configService.GetItemName(itemId);
            iconImg.rectTransform.sizeDelta = Vector2.zero;
            iconImg.LoadPropSprite(itemId, true, () =>
            {
                float targetHeight = 100;
                float targetWidth = 80;
                float originalWidth = iconImg.sprite.rect.width;
                float originalHeight = iconImg.sprite.rect.height;
                float aspectRatio = originalWidth / originalHeight;
                float newWidth;
                float newHeight;
                if (originalHeight >= originalWidth)
                {
                    newHeight = targetHeight;
                    newWidth = targetHeight * aspectRatio;
                }
                else
                {
                    newWidth = targetWidth;
                    newHeight = targetWidth / aspectRatio;
                }
                iconImg.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
            });
        }

    }

}