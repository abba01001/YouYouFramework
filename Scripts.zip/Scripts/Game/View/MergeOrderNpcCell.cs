﻿using FancyScrollView;
using SoliUtils;
using UnityEngine;
using UnityEngine.UI;

class MergeOrderNpcCell : FancyCell<NpcItemData, NpcContext>
{
    [SerializeField] Animator animator = default;
    [SerializeField] Image image = default;
    [SerializeField] Image NpcImage = default;
    [SerializeField] Text NameText = default;

    static class AnimatorHash
    {
        public static readonly int Scroll = Animator.StringToHash("scroll");
    }

    public override void Initialize()
    {
    }

    public override void UpdateContent(NpcItemData itemData)
    {
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();

        var dataService = MainContainer.Container.Resolve<IDataService>();
        var mergeItemData = dataService.GetMergeData();
        bool isUnlock = false;
        foreach (var item in mergeItemData)
        {
            if(item.Value == itemData.NpcId)
            {
                isUnlock = true;
                break;
            }
        }

        if(isUnlock)
        {
            if (configService.MergeItemConfig.ContainsKey(itemData.NpcId))
                NameText.text = configService.MergeItemConfig[itemData.NpcId].name;
            else
                NameText.text = "未知角色";
        }
        else
        {
            NameText.text = "未知角色";
        }

        _ = NpcImage.SetSpriteByAtlas(Constants.AtlasNamePath.MergeOrderAtlas, $"npc_{itemData.NpcId}", true);
        NpcImage.color = isUnlock ? Color.white : Color.black;

        // NpcImage.LoadPropSprite(itemData.NpcId, true, ()=>{
        //     float targetSize = 200;
        //     float originalWidth = NpcImage.sprite.rect.width;
        //     float originalHeight = NpcImage.sprite.rect.height;
        //     float aspectRatio = originalWidth / originalHeight;
        //     float newWidth;
        //     float newHeight;
        //     if (originalHeight >= originalWidth)
        //     {
        //         newHeight = targetSize;
        //         newWidth = targetSize * aspectRatio;
        //     }
        //     else
        //     {
        //         newWidth = targetSize;
        //         newHeight = targetSize / aspectRatio;
        //     }
        //     NpcImage.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
        // });

        var selected = Context.SelectedIndex == Index;
    }

    public override void UpdatePosition(float position)
    {
        currentPosition = position;

        if (animator.isActiveAndEnabled)
        {
            animator.Play(AnimatorHash.Scroll, -1, position);
        }

        animator.speed = 0;
    }

    float currentPosition = 0;

    void OnEnable() => UpdatePosition(currentPosition);
}