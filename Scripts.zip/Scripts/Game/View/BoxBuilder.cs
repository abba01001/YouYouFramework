using System;
using System.Collections.Generic;
using Activities;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using Doozy.Engine;
using Doozy.Engine.UI;
using Model;
using QFramework;
using UnityEngine;
using UnityEngine.Events;
using SoliUtils;
using View;
using UnityEngine.UI;

public class BoxBuilder
{
    private static UIPopup checkInPopup;
    private static UIPopup firstChargePopup;
    private static UIPopup homeMapPopup;
    private static UIPopup gradientGiftPopup;
    private static UIPopup giftGradientDigPopup;
    private static UIPopup giftGradientCookPopup;
    private static UIPopup failGameGiftPopup;
    private static UIPopup flowerPopup;
    private static UIPopup brokenPopup;
    private static UIPopup boxPopup;
    private static UIPopup loadingPop;
    private static UIPopup rewardPop;
    private static UIPopup shopPop;
    private static UIPopup sceneChangePop;
    private static UIPopup GMPop;
    private static UIPopup endWinStreakPop;
    private static UIPopup exitGameTipPop;
    private static UIPopup solatiumPopup;
    private static UIPopup startGamePopup;
    private static UIPopup exitGamePopup;
    private static UIPopup giftBuyItemPopup;
    private static UIPopup unlockRabbitPopup;
    private static UIPopup unlockLimitPkPopup;
    private static UIPopup seasonPassPopup;
    private static UIPopup startSeassPassPopup;
    private static UIPopup dailyAdRewardPopup;
    private static UIPopup saverPopup;
    private static UIPopup rabbitGiftPopup;
    private static UIPopup startPassRankPopup;
    private static UIPopup startCarRankPopup;
    private static UIPopup startLimitPkPopup;
    private static UIPopup levelPass;
    private static UIPopup startLevelPassPopup;
    private static UIPopup startLavaPassPopup;
    private static UIPopup lavaPassPopup;
    private static UIPopup lavaPassRewardPopup;
    private static UIPopup startCollectFlowerPopup;
    private static UIPopup startMysteriousSeedPopup;
    private static UIPopup startCollectLoveCardPopup;
    private static UIPopup startEndlessLevelPopup;
    private static UIPopup endlessLevelRankPopup;
    private static UIPopup unlockEndlessLevelPopup;
    private static UIPopup unlockDigTreasurePopup;
    private static UIPopup unlockMysteriousSeed;
    private static UIPopup unlockCookMealPopup;
    private static UIPopup mysteriousSeedPopup;
    private static UIPopup wheelPopup;
    private static UIPopup settingPopup;
    private static UIPopup streakTipPopup;
    private static UIPopup passRankPopup;
    private static UIPopup carRankPopup;
    private static UIPopup collectFlowerPopup;
    private static UIPopup giftDragOnePopup;
    private static UIPopup giftDragTwoPopup;
    private static UIPopup giftDragSixPopup;
    private static UIPopup giftPlusOnePopup;
    private static UIPopup giftPlusFourPopup;
    private static UIPopup giftDiscountPopup;
    private static UIPopup collectLoveCardPopup;
    private static UIPopup collectMusicPopup;
    private static UIPopup cookMealPopup;
    private static UIPopup collectWaterPopup;
    private static UIPopup collectHoneyPopup;
    private static UIPopup popCollectRewardPopup;
    private static UIPopup digTreasurePopup;
    private static UIPopup popRewardPopup;
    private static UIPopup buyItemPopup;
    private static UIPopup buyMergeItemPopup;
    private static UIPopup winingStreakPopup;
    private static UIPopup dataSyncPopup;
    private static UIPopup dataSyncConfirmPopup;
    private static UIPopup updateTipPopup;
    private static UIPopup signOutConfirmPopup;
    private static UIPopup signOutSuccessPopup;
    private static UIPopup signInSuccessPopup;
    private static UIPopup commonLoadingPopup;
    private static UIPopup activitySeasonPopup;
    private static UIPopup unlockBetPopup;
    private static UIPopup unlockStartGamePopup;
    private static UIPopup unlockCollectWaterPopup;
    private static UIPopup unlockCollectHoneyPopup;
    private static UIPopup unlockWinStreakPopup;
    private static UIPopup unlockseasonPassPopup;
    private static UIPopup unlocklevelPassPopup;
    private static UIPopup UnlockLavaPassPopup;
    private static UIPopup unlockCollectFlowerPopup;
    private static UIPopup unlockCollectLoveCardPopup;
    private static UIPopup unlockPassRankPopup;
    private static UIPopup unlockCarRankPopup;
    private static UIPopup firstTimeSaverPopup;
    private static UIPopup firstTimeSeason;
    private static UIPopup seasonDescPopup;
    private static UIPopup seasonRewardGetPopup;
    private static UIPopup unlockNewFeaturePopup;
    private static UIPopup harvestPopup;
    private static UIPopup vipPopup;
    private static UIPopup victoryPopup;
    private static UIPopup vipRewardPopup;
    private static UIPopup triggerGiftPopup;
    private static UIPopup levelRankingPopup;
    private static UIPopup regionRewardsPopup;
    private static UIPopup mergeOrderPopup;
    private static UIPopup mergeOrderBoughtPopup;
    private static UIPopup mergeUnlockGridPopup;
    private static UIPopup coinAdPopup;
    private static UIPopup specialCardTipPopup;
    private static UIPopup gameResultPopup;
    private static UIPopup subscribeChargePopup;
    private static UIPopup heartBeatGift;
    private static UIPopup emailPopup;
    private static UIPopup illustratedGuidePopup;
    private static UIPopup energyPopup;
    private static UIPopup boxLessPopup;
    private static UIPopup deleteMergeItemPopup;
    private static UIPopup instructionsPurifyPopup;
    private static UIPopup instructionsRewardPopup;
    private static UIPopup hotAirBallPopup;
    private static UIPopup mergeVersionRewardPopup;
    
    private static void ShowPopup(UIPopup uiPopup, bool instantAction = false)
    {
        uiPopup.Show(instantAction);
        UIPopupManager.AddToQueue(uiPopup, instantAction);
        UIPopup popup = UIPopupManager.CurrentVisibleQueuePopup;
        TogglePopupEvent evt = new TogglePopupEvent();
        evt.isShow = true;
        evt.popupName = uiPopup.PopupName;
        TypeEventSystem.Send<TogglePopupEvent>(evt);
    }

    public static void HidePopup(GameObject popupGo, bool instantAction = false) => HidePopup(popupGo.GetComponent<UIPopup>(), instantAction);
    private static void HidePopup(UIPopup uiPopup, bool instantAction = false)
    {
        UIPopupManager.RemoveFromQueue(uiPopup.PopupName);
        uiPopup.Hide(instantAction);
        UIPopup popup = UIPopupManager.CurrentVisibleQueuePopup;
        TogglePopupEvent evt = new TogglePopupEvent();
        evt.isShow = false;
        evt.popupName = uiPopup.PopupName;
        TypeEventSystem.Send<TogglePopupEvent>(evt);
    }

    public static UIPopup GetPopup(string popueName)
    {
        foreach (UIPopupQueueData link in UIPopupManager.PopupQueue)
            if (link.PopupName.Equals(popueName))
                return link.Popup;
        return null;
    }

    public static async void ShowTip(string msg, Action yesAct = null, Action noAct = null)
    {
        if (boxPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.BoxPopup);
            await task;
            boxPopup = task.Result;
        }
        boxPopup.Data.SetLabelsTexts(msg);
        boxPopup.Data.SetButtonsLabels("YES", "NO");
        boxPopup.Data.SetButtonsCallbacks(() =>
        {
            if (yesAct != null)
                yesAct();
            HidePopup(boxPopup);
            SoundPlayer.Instance.PlayButton();
        }, () =>
        {
            if (noAct != null)
                noAct();
            HidePopup(boxPopup);
            SoundPlayer.Instance.PlayButton();
        },
        () =>
        {
            if (noAct != null)
                noAct();
            HidePopup(boxPopup);
            SoundPlayer.Instance.PlayButton();
        });
        ShowPopup(boxPopup, false);
    }

    public static async void SetLoadingPopShow(bool isShow, bool instantAction = false)
    {
        if (loadingPop == null && !isShow) return;
        if (loadingPop == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.LoadingPopup);
            await task;
            loadingPop = task.Result;
        }
        if (isShow)
            loadingPop.Show(instantAction);
        else
            loadingPop.GetComponent<LoadingPopView>().ToHide(instantAction);
    }

    public static async void SetLoadingPopShow(bool isShow, float waitTime, bool isUseFull, Action onMaxWaitCall, bool instantAction = false)
    {
        if (loadingPop == null && !isShow) return;
        if (loadingPop == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.LoadingPopup);
            await task;
            loadingPop = task.Result;
        }
        if (isShow)
        {
            loadingPop.Show(instantAction);
            loadingPop.GetComponent<LoadingPopView>().SetMaxWaitTime(waitTime, isUseFull, onMaxWaitCall, instantAction);
        }
        else
        {
            loadingPop.GetComponent<LoadingPopView>().ToHide(instantAction);
        }
    }

    public static async void ShowLavaPassRewardPopup(Dictionary<int, int> rewardDic, PropChangeWay changeWay, Action endCall = null, bool instantAction = false)
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        foreach (var pair in rewardDic)
        {
            dataService.AddProp(pair.Key, pair.Value, changeWay, Vector3.zero, false);
        }
        dataService.SaveData(true, true);
        if (lavaPassRewardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.LavaPassRewardPopup);
            await task;
            lavaPassRewardPopup = task.Result;
        }
        ShowPopup(lavaPassRewardPopup, instantAction);
        lavaPassRewardPopup.GetComponent<LavaPassRewardPopView>().ShowReward(rewardDic, endCall, changeWay);
    }

    public static async void ShowRewardPop(Dictionary<int, int> rewardDic, PropChangeWay changeWay, Action endCall = null,
        bool instantAction = false, string title = null, ActivityType activityType = ActivityType.none, object[] param = null,Action startCall = null)
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        startCall?.Invoke();
        dataService.SaveRewardData(rewardDic, changeWay);
        if (rewardPop == null || rewardPop.IsHiding)
        {
            if (rewardDic.Count <= 0)
            {
                endCall?.Invoke();
                return;
            }
            else
            {
                var task = UIPopupManager.GetPopup(Constants.DoozyView.RewardPopup);
                await task;
                rewardPop = task.Result;
            }
        }
        ShowPopup(rewardPop, instantAction);
        rewardPop.GetComponent<RewardPopView>().InsertReward(rewardDic, endCall, changeWay, title, activityType, param);
    }

    public static async void ShowShopPop(bool instantAction = false)
    {
        if (GameCommon.IsShieldPurchase) return;
        if (shopPop != null) return;
        if (shopPop == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.ShopPopup);
            await task;
            shopPop = task.Result;
        }
        ShowPopup(shopPop, instantAction);
    }

    public static void HideShopPop()
    {
        if (shopPop != null)
        {
            HidePopup(shopPop, false);
        }
    }

    public static async void ShowSceneChangePop(TweenCallback midChange, Action endChange = null)
    {
        if (sceneChangePop == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SceneChangePopup);
            await task;
            sceneChangePop = task.Result;
        }
        ShowPopup(sceneChangePop, false);
        sceneChangePop.GetComponent<SceneChangePopView>().RunSceneChangeShow(midChange, endChange);
    }

    public static void HideSceneChangePop()
    {
        if (sceneChangePop == null) return;
        sceneChangePop.GetComponent<SceneChangePopView>().RunSceneChangeHide();
    }

    public static async void ShowGm()
    {

        // #if !UNITY_EDITOR && !TestMode
        //         return;
        // #endif
        if (GMPop == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GMPop);
            await task;
            GMPop = task.Result;
        }
        ShowPopup(GMPop, false);
    }

    public static void HideExitGameTipPopup(bool instantAction = false)
    {
        if (exitGameTipPop == null || exitGameTipPop.IsHidden) return;
        HidePopup(exitGameTipPop);
        exitGameTipPop = null;
    }

    public static async void ShowSolatiumPopup(int value = 0, bool instantAction = false)
    {
        if (GameController.Instance.IsRendering) return;
        if (solatiumPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SolatiumPopup);
            await task;
            solatiumPopup = task.Result;
        }
        solatiumPopup.GetComponent<SolatiumPopView>().SetCoinText(value);
        ShowPopup(solatiumPopup, instantAction);
    }

    public static async void ShowStartGamePopup()
    {
        if (startGamePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartGamePopup);
            await task;
            startGamePopup = task.Result;
        }
        ShowPopup(startGamePopup, false);
    }

    public static async void ShowUnlockRabbitPopup()
    {
        if (unlockRabbitPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockRabbitPopup);
            await task;
            unlockRabbitPopup = task.Result;
        }
        ShowPopup(unlockRabbitPopup, false);
    }

    public static void HideRabbitPopup()
    {
        if (rabbitGiftPopup == null) return;
        HidePopup(rabbitGiftPopup);
    }
    
    public static void HideMysteriousPopup()
    {
        if (mysteriousSeedPopup == null) return;
        HidePopup(mysteriousSeedPopup);
    }
    
    public static void HideVictoryPopup()
    {
        if (victoryPopup == null) return;
        HidePopup(victoryPopup);
    }

    public static async void ShowUnlockLimitPkPopup()
    {
        if (unlockLimitPkPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockLimitPkPopup);
            await task;
            unlockLimitPkPopup = task.Result;
        }
        ShowPopup(unlockLimitPkPopup, false);
    }

    public static async void ShowSeasonPassPopup()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        if (seasonPassPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SeasonPassPopup);
            await task;
            seasonPassPopup = task.Result;
        }
        ShowPopup(seasonPassPopup, false);
    }

    public static async void ShowStartSeasonPassPopup(string type)
    {
        if (startSeassPassPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartSeassPassPopup);
            await task;
            startSeassPassPopup = task.Result;
        }
        ShowPopup(startSeassPassPopup, false);
        startSeassPassPopup.GetComponent<StartSeasonPassPopView>().SetType(type);
    }

    public static async void ShowDailyAdRewardPopup()
    {
        if (dailyAdRewardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.DailyAdRewardPopup);
            await task;
            dailyAdRewardPopup = task.Result;
        }
        ShowPopup(dailyAdRewardPopup, false);
    }

    public static async void ShowSaverPopup()
    {
        if (saverPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SaverPopup);
            await task;
            saverPopup = task.Result;
        }
        ShowPopup(saverPopup, false);
    }

    public static async void ShowRabbitGiftPopup()
    {
        if (rabbitGiftPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.RabbitGiftPopup);
            await task;
            rabbitGiftPopup = task.Result;
        }
        ShowPopup(rabbitGiftPopup, false);
    }

    public static async void ShowStartPassRankPopup()
    {
        if (startPassRankPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartPassRankPopup);
            await task;
            startPassRankPopup = task.Result;
        }
        ShowPopup(startPassRankPopup, false);
    }
    
    public static async void ShowStartCarRankPopup()
    {
        if (startCarRankPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartCarRankPopup);
            await task;
            startCarRankPopup = task.Result;
        }
        ShowPopup(startCarRankPopup, false);
    }


    public static async void ShowStartLimitPkPopup(string type,bool needDoAnim = false)
    {
        if (startLimitPkPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartLimitPkPopup);
            await task;
            startLimitPkPopup = task.Result;
        }
        startLimitPkPopup.GetComponent<StartLimitPkPopView>().SetBg(type);
        if (needDoAnim)
        {
            startLimitPkPopup.GetComponent<StartLimitPkPopView>().DoAnim();
        }
        ShowPopup(startLimitPkPopup, false);
    }

    public static async void ShowLevelPassPopup(bool firstEntry = false)
    {
        if (levelPass == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.LevelPassPopup);
            await task;
            levelPass = task.Result;
        }
        ShowPopup(levelPass, false);
        if (firstEntry)
        {
            levelPass.GetComponent<LevelPassView>().PlayStartAnim();
        }
    }

    public static async void ShowStartLavaPassPopup(int uiType)
    {
        if (startLavaPassPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartLavaPass);
            await task;
            startLavaPassPopup = task.Result;
        }
        ShowPopup(startLavaPassPopup, false);
        startLavaPassPopup.GetComponent<StartLavaPassPopView>().SetType(uiType);
    }

    public static async void ShowLavaPassPopup(Action cb = null)
    {
        if (lavaPassPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.LavaPassPopup);
            await task;
            lavaPassPopup = task.Result;
        }
        ShowPopup(lavaPassPopup, false);
        lavaPassPopup.GetComponent<LavaPassView>().SetFinishCb(cb);
    }

    public static void HideLavaPassPopup()
    {
        if (lavaPassPopup == null) return;
        lavaPassPopup.GetComponent<LavaPassView>().DoFinishCb();
        HidePopup(lavaPassPopup);
    }

    public static async void ShowStartLevelPassPopup()
    {
        if (startLevelPassPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartLevelPassPopup);
            await task;
            startLevelPassPopup = task.Result;
        }
        ShowPopup(startLevelPassPopup, false);
    }

    public static async void ShowStartCollectFlowerPopup()
    {
        if (startCollectFlowerPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartCollectFlowerPopup);
            await task;
            startCollectFlowerPopup = task.Result;
        }
        ShowPopup(startCollectFlowerPopup, false);
    }

    public static async void ShowStartMysteriousSeedPopup()
    {
        if (startMysteriousSeedPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartMysteriousSeedPopup);
            await task;
            startMysteriousSeedPopup = task.Result;
        }
        ShowPopup(startMysteriousSeedPopup, false);
    }
    
    public static async void ShowStartEndlessLevelPopup()
    {
        if (startEndlessLevelPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartEndlessLevelPopup);
            await task;
            startEndlessLevelPopup = task.Result;
        }
        ShowPopup(startEndlessLevelPopup, false);
    }

    public static async void ShowEndlessLevelRankPopup()
    {
        if (endlessLevelRankPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.EndlessLevelRankPopup);
            await task;
            endlessLevelRankPopup = task.Result;
        }
        ShowPopup(endlessLevelRankPopup, false);
    }

    public static async void ShowStartCollectLoveCardPopup()
    {
        if (startCollectLoveCardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartCollectLoveCardPopup);
            await task;
            startCollectLoveCardPopup = task.Result;
        }
        ShowPopup(startCollectLoveCardPopup, false);
    }

    public static async void ShowSpecialCardTipPopup(CardData data)
    {
        if (specialCardTipPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SpecialCardTipPopup);
            await task;
            specialCardTipPopup = task.Result;
        }
        ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.SpecialCardTipPopup, () =>
        {
            specialCardTipPopup.GetComponent<SpecialCardTipView>().SetDetail(data);
            ShowPopup(specialCardTipPopup, false);
        });
    }

    public static async void ShowGameResultPopup()
    {
        if (gameResultPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GameResultPopup);
            await task;
            gameResultPopup = task.Result;
        }
        ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.GameResultPopup, () =>
        {
            ShowPopup(gameResultPopup, false);
        });
    }

    public static async void ShowWheelPopup()
    {
        if (wheelPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.WheelPopup);
            await task;
            wheelPopup = task.Result;
        }
        ShowPopup(wheelPopup, false);
    }

    public static async void ShowMysteriousSeedPopup()
    {
        if (mysteriousSeedPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.MysteriousSeedPopup);
            await task;
            mysteriousSeedPopup = task.Result;
        }
        ShowPopup(mysteriousSeedPopup, false);
    }

    public static async void ShowSettingPopup()
    {
        if (settingPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SettingPopup);
            await task;
            settingPopup = task.Result;
        }
        ShowPopup(settingPopup, false);
    }

    public static void HideSettingPopup()
    {
        if (settingPopup != null)
        {
            HidePopup(settingPopup, false);
        }
    }


    public static async void ShowStreakTipPopup(bool instantAction = false)
    {
        if (streakTipPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StreakTipPopup);
            await task;
            streakTipPopup = task.Result;
        }
        ShowPopup(streakTipPopup, instantAction);
    }

    public static async void ShowPassRankPopup(bool instantAction = false)
    {
        if (passRankPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.PassRankPopup);
            await task;
            passRankPopup = task.Result;
        }
        ShowPopup(passRankPopup, instantAction);
    }
    
    public static async void ShowCarRankPopup(bool instantAction = false)
    {
        if (carRankPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.CarRankPopup);
            await task;
            carRankPopup = task.Result;
        }
        ShowPopup(carRankPopup, instantAction);
    }

    public static async void ShowCollectFlowerPopup(bool instantAction = false)
    {
        if (collectFlowerPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.CollectFlowerPopup);
            await task;
            collectFlowerPopup = task.Result;
        }
        ShowPopup(collectFlowerPopup, instantAction);
    }

    public static async void ShowCollectLoveCardPopup(bool instantAction = false)
    {
        if (collectLoveCardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.CollectLoveCardPopup);
            await task;
            collectLoveCardPopup = task.Result;
        }
        ShowPopup(collectLoveCardPopup, instantAction);
    }

    public static async void ShowCollectMusicPopup()
    {
        if (collectMusicPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.CollectMusicPopup);
            await task;
            collectMusicPopup = task.Result;
        }
        ShowPopup(collectMusicPopup);
    }

    public static async void ShowCookMealPopup()
    {
        if (cookMealPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.CookMealPopup);
            await task;
            cookMealPopup = task.Result;
        }
        ShowPopup(cookMealPopup);
    }

    public static async void ShowCollectWaterPopup()
    {
        if (collectWaterPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.CollectWaterPopup);
            await task;
            collectWaterPopup = task.Result;
        }
        ShowPopup(collectWaterPopup);
    }

    public static async void ShowCollectHoneyPopup()
    {
        if (collectHoneyPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.CollectHoneyPopup);
            await task;
            collectHoneyPopup = task.Result;
        }
        ShowPopup(collectHoneyPopup);
    }

    public static async void ShowPopCollectRewardPopup(ActivityType activityType,Dictionary<int,int> rewardDic, Action startAction, Action endAction)
    {
        if (popCollectRewardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.PopCollectRewardPopup);
            await task;
            popCollectRewardPopup = task.Result;
        }
        ShowPopup(popCollectRewardPopup);
        popCollectRewardPopup.GetComponent<PopCollectRewardView>().SetParams(activityType,rewardDic, startAction, endAction);
    }

    public static async void ShowDigTreasurePopup()
    {
        if (digTreasurePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.DigTreasurePopup);
            await task;
            digTreasurePopup = task.Result;
        }
        ShowPopup(digTreasurePopup);
    }

    public static async void ShowPopRewardPopup(Action startAction, Action midAction, Action endAction, params object[] args)
    {
        if (popRewardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.PopRewardPopup);
            await task;
            popRewardPopup = task.Result;
        }
        ShowPopup(popRewardPopup);
        popRewardPopup.GetComponent<PopRewardPopView>().SetParams(startAction, midAction, endAction, args);
    }

    public static async void ShowBuyItemPopup(int prop_id, bool instantAction = false)
    {
        if (buyItemPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.BuyItemPopup);
            await task;
            buyItemPopup = task.Result;
        }
        ShowPopup(buyItemPopup, instantAction);
        buyItemPopup.GetComponent<BuyItemPopView>().SetBuyItem(prop_id);
    }

    public static async void ShowBuyMergeItemPopup(int item_id,int grid_id, bool instantAction = false)
    {
        if (buyMergeItemPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.BuyMergeItemPopup);
            await task;
            buyMergeItemPopup = task.Result;
        }
        ShowPopup(buyMergeItemPopup, instantAction);
        buyMergeItemPopup.GetComponent<BuyMergeItemPopView>().SetBuyItem(item_id, grid_id);
    }

    public static async void ShowDataSyncPopup(bool instantAction = false)
    {
        if (dataSyncPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.DataSyncPopup);
            await task;
            dataSyncPopup = task.Result;
        }
        ShowPopup(dataSyncPopup, instantAction);
    }

    public static void HideDataSyncPopup()
    {
        HidePopup(dataSyncPopup);
    }

    public static async void ShowDataSyncConfirmPopup(MainData data, bool instantAction = false)
    {
        if (dataSyncConfirmPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.DataSyncConfirmPopup);
            await task;
            dataSyncConfirmPopup = task.Result;
        }
        ShowPopup(dataSyncConfirmPopup, instantAction);
        dataSyncConfirmPopup.GetComponent<DataSyncConfirmPopView>().SetData(data);
    }

    public static void HideDataSyncConfirmPopup()
    {
        HidePopup(dataSyncConfirmPopup);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="showBtnType">0两个按钮都显示,1只显示jump,2只显示close</param>
    public static async void ShowUpdateTipPopup(int showBtnType, Action jumpCb, Action closeCb, string content, string jumpText = "", string closeText = "", string title = "")
    {
        if (updateTipPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UpdateTipPopView);
            await task;
            updateTipPopup = task.Result;
        }
        ShowPopup(updateTipPopup);
        updateTipPopup.GetComponent<UpdateTipPopView>().SetUI(showBtnType, jumpCb, closeCb, content, jumpText, closeText, title);
    }

    public static void HideUpdateTipPopup()
    {
        HidePopup(updateTipPopup);
    }

    public static async void ShowSignOutConfirmPopup(UnityAction yesCall, bool instantAction = false)
    {
        if (signOutConfirmPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SignOutConfirmPopup);
            await task;
            signOutConfirmPopup = task.Result;
        }
        ShowPopup(signOutConfirmPopup, instantAction);
        signOutConfirmPopup.GetComponent<SignOutConfirmPopView>().SetYesBtnCall(yesCall);
    }

    public static async void ShowSignOutSuccessPopup(bool instantAction = false)
    {
        if (signOutSuccessPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SignOutSuccessPopup);
            await task;
            signOutSuccessPopup = task.Result;
        }
        ShowPopup(signOutSuccessPopup, instantAction);
    }

    public static async void ShowSignInSuccessPopup(bool instantAction = false)
    {
        if (signInSuccessPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SignInSuccessPopup);
            await task;
            signInSuccessPopup = task.Result;
        }
        ShowPopup(signInSuccessPopup, instantAction);
    }

    public static async void ShowCommonLoadingPopup(bool instantAction = false)
    {
        if (commonLoadingPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.CommonLoadingPopup);
            await task;
            commonLoadingPopup = task.Result;
        }
        ShowPopup(commonLoadingPopup, instantAction);
    }

    public static void HideCommonLoadingPopup()
    {
        HidePopup(commonLoadingPopup);
    }

    public static bool IsActivitySeasonVisible()
    {
        return activitySeasonPopup != null && activitySeasonPopup.IsVisible;
    }

    public static async void ShowUnlockBetPopView(bool showGuide = false)
    {
        if (unlockBetPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockBetPopup);
            await task;
            unlockBetPopup = task.Result;
        }
        ShowPopup(unlockBetPopup, false);
        if (unlockBetPopup) unlockBetPopup.GetComponent<UnlockBetPopView>().DoGuideAnim();
    }

    public static async void ShowUnlockStartGamePopView()
    {
        if (unlockStartGamePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockStartGamePopup);
            await task;
            unlockStartGamePopup = task.Result;
        }
        ShowPopup(unlockStartGamePopup, false);
    }
    
    public static async void ShowUnlockCollectWaterPopView()
    {
        if (unlockCollectWaterPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockCollectWaterPopup);
            await task;
            unlockCollectWaterPopup = task.Result;
        }
        ShowPopup(unlockCollectWaterPopup, false);
    }
    
    public static async void ShowUnlockCollectHoneyPopView()
    {
        if (unlockCollectHoneyPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockCollectHoneyPopup);
            await task;
            unlockCollectHoneyPopup = task.Result;
        }
        ShowPopup(unlockCollectHoneyPopup, false);
    }

    public static async void ShowLava()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        if (!dataService.LavaPassProgress.UserActivative)
        {
            BoxBuilder.ShowStartLavaPassPopup(0);
        }
        else
        {
            if (ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).state == ActivityState.finished)
            {
                BoxBuilder.ShowStartLavaPassPopup(2);
            }
            else
            {
                BoxBuilder.ShowLavaPassPopup();
            }
        }
    }
    
    public static async void ShowUnlockWinStreakPopView()
    {
        if (unlockWinStreakPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockWinStreakPopup);
            await task;
            unlockWinStreakPopup = task.Result;
        }
        ShowPopup(unlockWinStreakPopup, false);
    }

    public static async void ShowUnlockSeasonPassPopView()
    {
        if (unlockseasonPassPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockSeasonPassPopup);
            await task;
            unlockseasonPassPopup = task.Result;
        }
        ShowPopup(unlockseasonPassPopup, false);
    }

    public static async void ShowUnlockLevelPassPopView()
    {
        if (unlocklevelPassPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlocklevelPassPopup);
            await task;
            unlocklevelPassPopup = task.Result;
        }
        ShowPopup(unlocklevelPassPopup, false);
    }

    public static async void ShowUnlockLavaPassPopView()
    {
        if (UnlockLavaPassPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockLavaPass);
            await task;
            UnlockLavaPassPopup = task.Result;
        }
        ShowPopup(UnlockLavaPassPopup, false);
    }

    public static async void ShowUnlockCollectFlowerPopView()
    {
        if (unlockCollectFlowerPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockCollectFlowerPopup);
            await task;
            unlockCollectFlowerPopup = task.Result;
        }
        ShowPopup(unlockCollectFlowerPopup, false);
    }

    public static async void ShowUnlockCollectLoveCardPopView()
    {
        if (unlockCollectLoveCardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockCollectLoveCardPopup);
            await task;
            unlockCollectLoveCardPopup = task.Result;
        }
        ShowPopup(unlockCollectLoveCardPopup, false);
    }

    public static async void ShowUnlockPassRankPopView()
    {
        if (unlockPassRankPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockPassRankPopup);
            await task;
            unlockPassRankPopup = task.Result;
        }
        ShowPopup(unlockPassRankPopup, false);
    }
    
    public static async void ShowUnlockCarRankPopView()
    {
        if (unlockCarRankPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockCarRankPopup);
            await task;
            unlockCarRankPopup = task.Result;
        }
        ShowPopup(unlockCarRankPopup, false);
    }

    public static async void ShowUnlockEndlessLevel()
    {
        if (unlockEndlessLevelPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockEndlessLevelPopup);
            await task;
            unlockEndlessLevelPopup = task.Result;
        }
        ShowPopup(unlockEndlessLevelPopup, false);
    }
    
    public static async void ShowUnlockDigTreasure()
    {
        if (unlockDigTreasurePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockDigTreasurePopup);
            await task;
            unlockDigTreasurePopup = task.Result;
        }
        ShowPopup(unlockDigTreasurePopup, false);
    }
    
    public static async void ShowUnlockMysteriousSeed()
    {
        if (unlockMysteriousSeed == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockMysteriousSeedPopup);
            await task;
            unlockMysteriousSeed = task.Result;
        }
        ShowPopup(unlockMysteriousSeed, false);
    }
    
    public static async void ShowUnlockCookMeal()
    {
        if (unlockCookMealPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockCookMealPopup);
            await task;
            unlockCookMealPopup = task.Result;
        }
        ShowPopup(unlockCookMealPopup, false);
    }


    public static async void ShowFirstTimeSaver()
    {
        if (firstTimeSaverPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.FirstTimeSaverPopup);
            await task;
            firstTimeSaverPopup = task.Result;
        }
        ShowPopup(firstTimeSaverPopup, false);
    }

    public static void HideTimeSaver()
    {
        if (firstTimeSaverPopup == null || firstTimeSaverPopup.IsHidden) return;
        HidePopup(firstTimeSaverPopup);
    }

    public static async void ShowFirstTimeSeason()
    {
        if (firstTimeSeason == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.FirstTimeSeasonPopup);
            await task;
            firstTimeSeason = task.Result;
        }
        ShowPopup(firstTimeSeason, false);
    }

    public static void HideTimeSeason()
    {
        if (firstTimeSeason == null || firstTimeSeason.IsHidden) return;
        HidePopup(firstTimeSeason);
    }

    public static async void ShowSeasonDescPopup(bool instantAction = false)
    {
        if (seasonDescPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SeasonDescPopup);
            await task;
            seasonDescPopup = task.Result;
        }
        ShowPopup(seasonDescPopup, instantAction);
    }

    public static async void ShowUnlockNewFeaturePopup(Transform target, Vector3 targetPos, UnityAction<GameObject> showCall, UnityAction hideCall, bool instantAction = false)
    {
        if (unlockNewFeaturePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.UnlockNewFeaturePopup);
            await task;
            unlockNewFeaturePopup = task.Result;
        }
        ShowPopup(unlockNewFeaturePopup, instantAction);
        unlockNewFeaturePopup.GetComponent<UnlockNewFeaturePopup>().SetTargetInfo(target, targetPos, showCall, hideCall);
    }

    public static async void ShowCheckIn()
    {
        if (checkInPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.CheckInPopup);
            await task;
            checkInPopup = task.Result;
        }
        ShowPopup(checkInPopup, false);
    }

    public static async void ShowFirstCharge(Action onCloseCall)
    {
        if (!GameUtils.EnableCoinShop) return;
        if (firstChargePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.FirstChargePopup);
            await task;
            firstChargePopup = task.Result;
        }
        ShowPopup(firstChargePopup, false);
    }

    public static async void ShowSubscribeCharge()
    {
        if (!GameUtils.EnableCoinShop) return;
        if (subscribeChargePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.SubscribeChargePopup);
            await task;
            subscribeChargePopup = task.Result;
        }
        ShowPopup(subscribeChargePopup);
    }

    public static async void ShowHeartBeatGift()
    {
        if (!GameUtils.EnableCoinShop) return;
        if (heartBeatGift == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.HeartBeatGift);
            await task;
            heartBeatGift = task.Result;
        }
        ShowPopup(heartBeatGift);
    }

    public static async void ShowEmailPopup()
    {
        if (emailPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.EmailPopup);
            await task;
            emailPopup = task.Result;
        }
        ShowPopup(emailPopup);
    }


    public static async void ShowHomeMap()
    {
        if (homeMapPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.HomeMapPopup);
            await task;
            homeMapPopup = task.Result;
        }
        ShowPopup(homeMapPopup, false);
    }

    public static async void ShowGradientGift()
    {
        if (gradientGiftPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GradientGiftPopup);
            await task;
            gradientGiftPopup = task.Result;
        }
        ShowPopup(gradientGiftPopup, false);
    }
    
    public static async void ShowGiftGradientDig()
    {
        if (giftGradientDigPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GiftGradientDigPopup);
            await task;
            giftGradientDigPopup = task.Result;
        }
        ShowPopup(giftGradientDigPopup, false);
    }
    
    public static async void ShowGiftGradientCook()
    {
        if (giftGradientCookPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GiftGradientCookPopup);
            await task;
            giftGradientCookPopup = task.Result;
        }
        ShowPopup(giftGradientCookPopup, false);
    }

    public static async void ShowFailGameGift(string ProductId = "", bool IsAdType = false)
    {
        if (failGameGiftPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.FailGameGiftPopup);
            await task;
            failGameGiftPopup = task.Result;
        }
        failGameGiftPopup.GetComponent<FailGameGiftPopView>().SetGiftType(ProductId, IsAdType);
        ShowPopup(failGameGiftPopup, false);
    }

    public static async void ShowFlower(int oldStar, int newStar)
    {
        if (flowerPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.FlowerPopup);
            await task;
            flowerPopup = task.Result;
        }
        ShowPopup(flowerPopup, false);
        flowerPopup.GetComponent<FlowerView>().SetShowStar(oldStar, newStar);
    }

    public static async void ShowBroken(string ProductId = "")
    {
        if (brokenPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.BrokenPopup);
            await task;
            brokenPopup = task.Result;
        }
        ShowPopup(brokenPopup, false);
        brokenPopup.GetComponent<BrokenPopView>().SetGiftType(ProductId);
    }

    public static async void ShowHarvestPop()
    {
        if (harvestPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.HarvestPopup);
            await task;
            harvestPopup = task.Result;
        }
        ShowPopup(harvestPopup, false);
    }

    public static async void ShowCoinAdPop(GameObject lastPop = null)
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var now = TimeUtils.UtcNow();
        if (!TimeUtils.IsSameDay(dataService.LastCoinAdTime, now))
        {
            dataService.LastCoinAdTime = now;
        }

        if (false)
        {
            Debug.LogError("=======没广告次数了");
        }
        else
        {
            if (lastPop)
                HidePopup(lastPop);
            if (coinAdPopup == null)
            {
                var task = UIPopupManager.GetPopup(Constants.DoozyView.CoinAdPopup);
                await task;
                coinAdPopup = task.Result;
            }
            ShowPopup(coinAdPopup, false);
        }
    }

    public static async void ShowVipPopup()
    {
        if (vipPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.VipPopup);
            await task;
            vipPopup = task.Result;
        }
        ShowPopup(vipPopup, false);
    }
    
    public static async void ShowVictoryPopup()
    {
        if (victoryPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.VictoryPopup);
            await task;
            victoryPopup = task.Result;
        }
        ShowPopup(victoryPopup, false);
    }

    public static GameObject GetVictoryPopupSprite()
    {
        if (victoryPopup != null)
        {
            return victoryPopup.GetComponent<VictoryPopView>().GetSpriteToResultView();
        }
        return null;
    }

    public static async void ShowTriggerGift(Action onCloseCall)
    {
        if (triggerGiftPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.TriggerGiftPopup);
            await task;
            triggerGiftPopup = task.Result;
        }
        ShowPopup(triggerGiftPopup, false);
        triggerGiftPopup.GetComponent<TriggerGiftPopView>().SetCloseCall(onCloseCall);
    }

    public static async void ShowVipReward()
    {
        if (vipRewardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.VipRewardPopup);
            await task;
            vipRewardPopup = task.Result;
        }
        ShowPopup(vipRewardPopup, false);
    }

    public static async void ShowLevelRankingPopup()
    {
        if (levelRankingPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.LevelRankingPopup);
            await task;
            levelRankingPopup = task.Result;
        }
        ShowPopup(levelRankingPopup, false);
    }

    public static async void ShowRegionRewardsPopup(int region_id)
    {
        if (regionRewardsPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.RegionRewardsPopup);
            await task;
            regionRewardsPopup = task.Result;
        }
        ShowPopup(regionRewardsPopup, false);
        regionRewardsPopup.GetComponent<RegionRewardsView>().SetRegionId(region_id);
    }

    public static async void ShowMergeOrderPopup(int npc_id)
    {
        if (mergeOrderPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.MergeOrderPopup);
            await task;
            mergeOrderPopup = task.Result;
        }
        ShowPopup(mergeOrderPopup, false);
        mergeOrderPopup.GetComponent<MergeOrderView>().SetNpcId(npc_id);
    }

    public static async void ShowMergeOrderBroughtPopup(int npc_id)
    {
        if (mergeOrderBoughtPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.MergeOrderBoughtPopup);
            await task;
            mergeOrderBoughtPopup = task.Result;
        }
        ShowPopup(mergeOrderBoughtPopup, false);
        mergeOrderBoughtPopup.GetComponent<MergeOrderBoughtView>().SetNpcId(npc_id);
    }

    public static async void ShowHotAirBallPopup(int ballId)
    {
        if (hotAirBallPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.HotAirBallPopup);
            await task;
            hotAirBallPopup = task.Result;
        }
        ShowPopup(hotAirBallPopup, false);
        hotAirBallPopup.GetComponent<HotAirBallView>().SetBallId(ballId);
    }

    public static void HideHotAirBallPopup()
    {
        if (hotAirBallPopup == null || hotAirBallPopup.IsHidden) return;
        HidePopup(hotAirBallPopup);
    }

    public static async void ShowMergeUnlockGridPopup(int grid_id)
    {
        if(UIPopupManager.IsPopVisible(Constants.DoozyView.MergeUnlockGridPopup))
            return;
        if (mergeUnlockGridPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.MergeUnlockGridPopup);
            await task;
            mergeUnlockGridPopup = task.Result;
        }
        ShowPopup(mergeUnlockGridPopup, false);
        mergeUnlockGridPopup.GetComponent<MergeUnlockGridView>().SetGridId(grid_id);
    }

    public static async void ShowIllustratedGuidePopup()
    {
        if (illustratedGuidePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.IllustratedGuidePopup);
            await task;
            illustratedGuidePopup = task.Result;
        }
        ShowPopup(illustratedGuidePopup, false);
    }

    public static async void ShowEnergyPopup()
    {
        if (energyPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.EnergyPopup);
            await task;
            energyPopup = task.Result;
        }
        ShowPopup(energyPopup, false);
    }
    //宝箱不足
    public static async void ShowBoxLessPopup()
    {
        if (boxLessPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.BoxLessPopup);
            await task;
            boxLessPopup = task.Result;
        }
        ShowPopup(boxLessPopup, false);
    }
    //净化土地说明
    public static async void ShowInstructionsPurifyPopup()
    {
        if (instructionsPurifyPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.InstructionsPurifyPopup);
            await task;
            instructionsPurifyPopup = task.Result;
        }
        ShowPopup(instructionsPurifyPopup, false);
    }
    //奖励说明
    public static async void ShowInstructionsRewardPopup()
    {
        if (instructionsRewardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.InstructionsRewardPopup);
            await task;
            instructionsRewardPopup = task.Result;
        }
        ShowPopup(instructionsRewardPopup, false);
    }

    public static async void ShowDeleteMergeItemPopup(MergeItem item)
    {
        if (deleteMergeItemPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.DeleteMergeItemPopup);
            await task;
            deleteMergeItemPopup = task.Result;
        }
        ShowPopup(deleteMergeItemPopup, false);
        deleteMergeItemPopup.GetComponent<DeleteMergeItemView>().SetParams(item);

    }

    public static void ClearNowShowPopup()
    {
        foreach (var popup in UIPopup.VisiblePopups)
        {
            if (popup != startGamePopup && !popup.IsHiding)
            {
                HidePopup(popup);
            }
        }
    }

    public static void ExitResultView()
    {
        BoxBuilder.ShowSceneChangePop(() =>
        {
            GameEventMessage.SendEvent(Constants.DoozyEvent.GameEnd);
        }, BoxBuilder.HideSceneChangePop);
    }

    public static void HideEndlessLevelRankPopup()
    {
        if (endlessLevelRankPopup == null || endlessLevelRankPopup.IsHidden) return;
        HidePopup(endlessLevelRankPopup);
    }

    public static void HideDigTreasurePopup()
    {
        if (digTreasurePopup == null || digTreasurePopup.IsHidden) return;
        HidePopup(digTreasurePopup);
    }

    public static void HideCollectFlowerPopup()
    {
        if (collectFlowerPopup == null || collectFlowerPopup.IsHidden) return;
        HidePopup(collectFlowerPopup);
    }

    public static async void ShowGiftDragOnePopup()
    {
        if (giftDragOnePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GiftDragOnePopup);
            await task;
            giftDragOnePopup = task.Result;
        }
        ShowPopup(giftDragOnePopup, false);
    }
    
    public static async void ShowGiftPlusOnePopup()
    {
        if (giftPlusOnePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GiftPlusOnePopup);
            await task;
            giftPlusOnePopup = task.Result;
        }
        ShowPopup(giftPlusOnePopup, false);
    }
    
    public static async void ShowGiftPlusFourPopup()
    {
        if (giftPlusFourPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GiftPlusFourPopup);
            await task;
            giftPlusFourPopup = task.Result;
        }
        ShowPopup(giftPlusFourPopup, false);
    }
    
    public static async void ShowGiftDiscountPopup()
    {
        if (giftDiscountPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GiftDiscountPopup);
            await task;
            giftDiscountPopup = task.Result;
        }
        ShowPopup(giftDiscountPopup, false);
    }
    
    public static async void ShowGiftDragTwoPopup()
    {
        if (giftDragTwoPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GiftDragTwoPopup);
            await task;
            giftDragTwoPopup = task.Result;
        }
        ShowPopup(giftDragTwoPopup, false);
    }
    
    public static async void ShowGiftDragSixPopup()
    {
        if (giftDragSixPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GiftDragSixPopup);
            await task;
            giftDragSixPopup = task.Result;
        }
        ShowPopup(giftDragSixPopup, false);
    }
 

    
    public static void HideCookMealPopup()
    {
        if (cookMealPopup == null || cookMealPopup.IsHidden) return;
        HidePopup(cookMealPopup);
    }

    public static async void ShowRestartPopup()
    {
        if (startGamePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartGamePopup);
            await task;
            startGamePopup = task.Result;
            startGamePopup.GetComponent<StartGamePopView>().SetRestart();
        }
        ShowPopup(startGamePopup, false);
    }

    public static async void ShowExitGamePopup()
    {
        if (GameUtils.CheckDirectShowRestart()) return;
        if (exitGamePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.ExitGamePopup);
            await task;
            exitGamePopup = task.Result;
        }
        ShowPopup(exitGamePopup, false);
    }
    
    public static async void ShowGiftBuyItemPopup(ActivityType activityType)
    {
        if (giftBuyItemPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.GiftBuyItemPopup);
            await task;
            giftBuyItemPopup = task.Result;
        }
        ShowPopup(giftBuyItemPopup, false);
        giftBuyItemPopup.GetComponent<GiftBuyItemView>().SetParams(activityType);
    }

    public static async void HideGiftBuyItemPopup()
    {
        if (giftBuyItemPopup == null || giftBuyItemPopup.IsHidden) return;
        HidePopup(giftBuyItemPopup);
    }
    

    public static async void ShowNextStartPopup()
    {
        if (startGamePopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.StartGamePopup);
            await task;
            startGamePopup = task.Result;
            startGamePopup.GetComponent<StartGamePopView>().SetNextStart();
        }
        ShowPopup(startGamePopup, false);
    }
    
    public static async void ShowToast(string txt,int zDepth = 0)
    {
        _ = GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/View/Toast.prefab", (obj) =>
        {
            UICanvas canvas = UICanvas.GetUICanvas("MyPopupCanvas", true);
            obj.transform.SetParent(canvas.transform);
            obj.transform.localScale = Vector3.one;
            obj.transform.localPosition = new Vector3(0, 0, zDepth);
            obj.transform.Get<Text>("Container/Message").text = txt;
            obj.SetActive(true);
        }, true, 3f);
    }

    public static async void ShowMergeVersionRewardPopup()
    {
        if (mergeVersionRewardPopup == null)
        {
            var task = UIPopupManager.GetPopup(Constants.DoozyView.MergeVersionRewardPopup);
            await task;
            mergeVersionRewardPopup = task.Result;
        }
        ShowPopup(mergeVersionRewardPopup, false);
    }
}
