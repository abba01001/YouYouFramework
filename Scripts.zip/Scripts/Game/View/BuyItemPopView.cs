﻿using Doozy.Engine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class BuyItemPopView : ViewBase
{

    protected override void OnAwake()
    {
        reportOnShow = false;
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
            GoldView.Instance.SortingOrder = 92;
            GoldView.Instance.ShowBuildCoinRoot(false);
        });
    }

    public void SetBuyItem(int prop_id)
    {
        ItemModel itemModel = configService.ItemConfig[prop_id];
        PowerItemModel powerItemModel = configService.PowerItemConfig[prop_id];

        transform.Get<Text>("Container/ItemNameText").text = itemModel.name;
        transform.Get<Text>("Container/DesText").text = itemModel.desc;
        if (powerItemModel.bundle > 1)
            transform.Get<Text>("Container/ItemIcon/BuyNumText").text = "x" + powerItemModel.bundle;
        else
            transform.Get<Text>("Container/ItemIcon/BuyNumText").gameObject.SetActive(false);
        transform.Get<Text>("Container/BuyBtn/StageCost").text = powerItemModel.Price.ToString();
        transform.Get<Button>("Container/BuyBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(2);
            long nowCoin = dataService.Coin - dataService.GetPreAddItemConsume();
            if (nowCoin > powerItemModel.Price)
            {
                dataService.OperatePreAddItem(1,prop_id);
                BoxBuilder.HidePopup(gameObject);
                GoldView.Instance.SortingOrder = 92;
            }
            else
            {
                BoxBuilder.ShowShopPop();
            }
        });
        Image propImage = transform.Get<Image>("Container/ItemIcon");
        propImage.LoadPropSprite(prop_id);
    }
}
