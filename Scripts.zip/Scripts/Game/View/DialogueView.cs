﻿using DG.Tweening;
using QFramework;
using SoliUtils;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogueView : ViewBase
{
    private DialogueItem _leftItem;
    private DialogueItem _rightItem;
    private GameObject _maskGO;
    private RectTransform _topMaskRtf;
    private RectTransform _bottomMaskRtf;

    private RookieDialogueDicModel _dialogueDicModel;
    private int _currentIndex;
    private IConfigService _configService = MainContainer.Container.Resolve<IConfigService>();
    private int rookieId;
    private Sequence _sequence;
    private bool _showing;
    private bool _registerEvent = false;

    public void OnSingletonInit()
    {
    }
    protected override void OnAwake() 
    {
        _maskGO = transform.Find("Mask").gameObject;
        _topMaskRtf = transform.Get<RectTransform>("Mask/Top");
        _bottomMaskRtf = transform.Get<RectTransform>("Mask/Bottom");
        transform.Get<Button>("Mask/Btn").onClick.AddListener(OnClickNext);

        _leftItem = new DialogueItem(transform.Find("Left").gameObject);
        _rightItem = new DialogueItem(transform.Find("Right").gameObject);
        _leftItem.btn.onClick.AddListener(OnClickSkip);
        _rightItem.btn.onClick.AddListener(OnClickSkip);
        _maskGO.SetActive(false);
        _leftItem.SetActive(false);
        _rightItem.SetActive(false);

    }
    protected override void OnViewInit(bool isFirstTime) 
    {
        if (_registerEvent)
        {
            return;
        }
        _registerEvent = true;
        TypeEventSystem.Register<RookieTriggerBeginEvent>(OnRookieTriggerBeginEvent);
    }

    protected override void OnInitedDestroy() 
    {
        _registerEvent = false;
        TypeEventSystem.UnRegister<RookieTriggerBeginEvent>(OnRookieTriggerBeginEvent);
    }

    private void OnRookieTriggerBeginEvent(RookieTriggerBeginEvent evt)
    {
        if (evt.rookieType == RookieModel.RookieType.Dialogue)
        {
            rookieId = evt.rookieId;
            ShowDialogue(evt.dialogueDicModel);
        }
    }


    
    public void ShowDialogue(RookieDialogueDicModel dialogueDicModel)
    {
        _showing = false;
        _dialogueDicModel = dialogueDicModel;
        _currentIndex = 0;
        _maskGO.SetActive(true);
        Tween tween = ShowMask();
        tween.OnComplete(()=> 
        {
            _showing = true;
            CheckShowNext(); 
        });
    }


    private Tween ShowMask()
    {
        _topMaskRtf.DOAnchorPosY(0f, 0.6f);
        Tween tween = _bottomMaskRtf.DOAnchorPosY(0f, 0.6f);
        return tween;
    }

    private Tween HideMask()
    {
        _topMaskRtf.DOAnchorPosY(160f, 0.6f);
        Tween tween = _bottomMaskRtf.DOAnchorPosY(-160f, 0.6f);
        return tween;
    }

    private bool CheckShowNext()
    {
        if (_sequence != null)
        {
            _sequence.Kill(false);
            _sequence = null;

        }
        _currentIndex++;
        if (_currentIndex > _dialogueDicModel.dic.Values.Count)
        {
            return false;
        }
        RookieDialogueModel dialogueModel = _dialogueDicModel.dic[_currentIndex];
        _sequence = ShowDialogueItem(dialogueModel);
        return true;

    }

    private void PlaySound(int spriteIndex)
    {
        if (spriteIndex == 0)
        {
            SoundPlayer.Instance.PlayXJLZuo01();
        }
        else if (spriteIndex == 1)
        {
            SoundPlayer.Instance.PlayXJLZan01();
        }
        else if (spriteIndex == 2)
        {
            SoundPlayer.Instance.PlayXJLZan02();
        }
        else if (spriteIndex == 3)
        {
            SoundPlayer.Instance.PlayXJLZan04();
        }
        else if (spriteIndex == 4)
        {
            SoundPlayer.Instance.PlayXJLZan03();
        }
        else if (spriteIndex == 5)
        {
            SoundPlayer.Instance.PlayXJLFei01();
        }
        else if (spriteIndex == 6)
        {
            SoundPlayer.Instance.PlayXJLFei02();
        }

    }

    private Sequence ShowDialogueItem(RookieDialogueModel dialogueModel)
    {
        DialogueItem currentItem;
        if (dialogueModel.position == 0)
        {
            _leftItem.SetActive(true);
            _rightItem.SetActive(false);
            currentItem = _leftItem;
        }
        else
        {
            _leftItem.SetActive(false);
            _rightItem.SetActive(true);
            currentItem = _rightItem;
        }
        
        


        //currentItem.dialogueText.text = dialogueModel.text;
        //LoadIcon(currentItem, dialogueModel.item_id);
        Dictionary<int, MergeItemConfig> mergeItemConfigDic = _configService.MergeItemConfig;
        if (mergeItemConfigDic.ContainsKey(dialogueModel.item_id))
        {
            MergeItemConfig mergeItemConfig = mergeItemConfigDic[dialogueModel.item_id];//View\View_MergeOrder
            currentItem.nameText.text = mergeItemConfig.name;
            _ = currentItem.icon.SetSpriteByAtlas(Constants.AtlasNamePath.MergeOrderAtlas, "npc_30003");
        }
        else
        {
            currentItem.nameText.text = "奥莉";
            currentItem.icon.sprite = currentItem.defaultSprite;
            //int index = Random.Range(0, _sprites.Count);
            //currentItem.SetIconSprite(_sprites[index]);
            //currentItem.SetIconOffset(Vector2.zero);
            int index = Random.Range(0, 7);
            PlaySound(index);
        }
        
        currentItem.dialogueText.text = "";
        Sequence sequence = DOTween.Sequence();
        Tween tween = currentItem.dialogueText.DOText(dialogueModel.text, dialogueModel.text.Length * 0.1f).SetEase(DG.Tweening.Ease.Linear).OnComplete(() => {
            //Debug.Log("tween Complete.......");
        });
        sequence.Join(tween);
        sequence.SetAutoKill(false);
        sequence.Play();
        return sequence;
    }

    //private void LoadIcon(DialogueItem currentItem, int itemId)
    //{
    //    if (itemId == 1)
    //    {
    //        currentItem.icon.sprite = currentItem.defaultSprite;
    //        ResetIconSize(currentItem.icon);
    //        return;
    //    }
    //    currentItem.icon.LoadPropSprite(itemId, true, () =>
    //    {
    //        ResetIconSize(currentItem.icon);
    //    });
    //}

    private void ResetIconSize(Image icon)
    {
        float targetHeight = 250;
        float targetWidth = 200;
        float originalWidth = icon.sprite.rect.width;
        float originalHeight = icon.sprite.rect.height;
        float aspectRatio = originalWidth / originalHeight;
        float newWidth;
        float newHeight;
        if (originalHeight >= originalWidth)
        {
            newHeight = targetHeight;
            newWidth = targetHeight * aspectRatio;
        }
        else
        {
            newWidth = targetWidth;
            newHeight = targetWidth / aspectRatio;
        }
        icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
    }

    private void OnClickSkip()
    {
        OnDialogueEnd();
    }

    private void OnClickNext()
    {
        if (!_showing)
        {
            return;
        }
        if (!CheckShowNext())
        {
            OnDialogueEnd();
        }
    }



    private void OnDialogueEnd()
    {
        _leftItem.SetActive(false);
        _rightItem.SetActive(false);
        _showing = false;
        Tween tween = HideMask();
        tween.OnComplete(() => {
            //UIView.HideView(Constants.DoozyView.Dialogue, true);
            _maskGO.SetActive(false);
            RookieTriggerEndEvent t = GameObjManager.Instance.PopClass<RookieTriggerEndEvent>(true);
            t.Init2(rookieId);
            TypeEventSystem.Send<RookieTriggerEndEvent>(t);
        });
    }

    public class DialogueItem
    {
        public GameObject go;
        public Button btn;
        
        public Sprite defaultSprite;
        public Image icon;
        public Vector2 iconAnchoredPosition;
        public Animator animator;
        public Text dialogueText;
        public Text nameText;
        public DialogueItem(GameObject go)
        {
            this.go = go;
            icon = go.transform.Get<Image>("Image");
            defaultSprite = icon.sprite;
            iconAnchoredPosition = icon.GetComponent<RectTransform>().anchoredPosition;
            btn = go.transform.Get<Button>("Btn");
            dialogueText = go.transform.Get<Text>("Text");
            Transform headTF = go.transform.Find("Head");
            //animator = headTF.Get<Animator>("Icon");
            //icon = headTF.Get<Image>("Icon");
            //defaultSprite = icon.sprite;
            nameText = headTF.Get<Text>("Name/Text");
        }

        public void SetIconOffset(Vector2 offset)
        {
            icon.GetComponent<RectTransform>().anchoredPosition = iconAnchoredPosition + offset;
        }

        public void SetActive(bool value)
        {
            go.SetActive(value);
        }

        public void SetIconSprite(Sprite sprite)
        {
            icon.sprite = sprite;
            icon.SetNativeSize();
        }

       

    }

}
