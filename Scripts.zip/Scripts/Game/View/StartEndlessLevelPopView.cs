using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using Model;

[RequireComponent(typeof(CanvasGroup))]
public class StartEndlessLevelPopView : ViewBase
{
    private Button CloseBtn;
    private GameObject CollectLoveCardContent;
    private ActivityTimeItem timeItem;
    private Action startGame;

    protected override void OnAwake()
    {
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        CloseBtn.SetButtonClick(CloseFunc);
        CloseBtn.gameObject.SetActive(false);
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(EnterGameFunc);
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        InitPanel();
    }

    private void InitPanel()
    {
        RefreshTimer(null);
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).ActivityBigEndTime);
            }
            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.EndlessLevelProgress.ActivityEndTime);
            }
            timeData.endText = model.state is ActivityState.finished ? "结束" : model.state is ActivityState.waitFinished && dataService.EndlessLevelProgress.MyData.curRank == 0 ? "领取奖励" : "结束";
        }
        timeItem.SetTimeData(timeData);
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    private void EnterGameFunc()
    {
        ActivityManager.Instance.EndlessLevelActivity.EnableActivity();
        if (GameCommon.IsShowingStartGamePopup)
        {
            BoxBuilder.ShowEndlessLevelRankPopup();
        }
        else
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.EndlessLevelRankPopup,BoxBuilder.ShowEndlessLevelRankPopup,true);
        }

        ActivityManager.Instance.EndlessLevelActivity.GetRankReward(1);
        CloseFunc();
    }
}