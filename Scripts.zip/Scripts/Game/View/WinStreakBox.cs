using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using UniRx;
using SoliUtils;

public class WinStreakBox : MonoBehaviour
{
    public Image Bg;
    public Image Fg;
    public Transform[] Cards;
    public Transform[] ImageCards;
    public GameObject flashObj;
    public Camera CardCamera;
    public RawImage CardImage;
    public GameObject winStreakCardObj;
    public GameObject imageCardsObj;
    public GameObject tickObj;
    public void ShowBox(int stepIdx, string[] winStreakCards)
    {
        SetTick(false);
        winStreakCardObj.SetActive(true);
        imageCardsObj.SetActive(false);
        if (stepIdx == 0 || winStreakCards == null)
        {
            for (int i = 0; i < Cards.Length; i++)
            {
                if(Cards[i].childCount > 0)
                    GameObjManager.Instance.PushGameObject(Cards[i].GetChild(0).gameObject);
            }
            Bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, "he1_2",false);
            Fg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, "he1_1", false);
            return;
        }
        CardCamera.enabled = true;
        var tarTex = new RenderTexture(398, 304, 16, RenderTextureFormat.ARGB32);
        CardCamera.targetTexture = tarTex;
        CardImage.texture = tarTex;
        int level = stepIdx < 2 ? 1 : (stepIdx < 4 ? 2 : 3);
        Bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, $"he{level}_2", false);
        Fg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, $"he{level}_1", false);

        var dataService = MainContainer.Container.Resolve<IDataService>();
        for (int i = 0; i < winStreakCards.Length; i++)
        {
            if(i >= Cards.Length)
                break;
            var cardTypeStr = winStreakCards[i];
            if(Constants.String2CardTypeDic.TryGetValue(cardTypeStr, out var cardType) &&
                Constants.CardType2ObjDic.TryGetValue(cardType, out var gameObjType))
            {
                var card = GameObjManager.Instance.PopGameObject(gameObjType);
                card.SetActive(true);
                card.transform.SetParent(Cards[i]);
                card.transform.localPosition = Vector3.zero;
                card.transform.localEulerAngles = Vector3.zero;
                card.transform.localScale = Vector3.one;
                UniRx.Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
                {
                    //card.GetComponent<BaseCard>()?.SetBack(dataService.CardBackId, dataService.NowBet);
                    card.GetComponent<BaseCard>()?.SetStreakBack();
                });
                var c = card.transform.Find("card");
                c.localEulerAngles = Vector3.zero;
                if(cardType == CardType.Value || cardType == CardType.TwoValue)
                    card.GetComponent<BaseCard>().IsFaceUp = false;
            }
            else
            {
                Debug.LogError(cardTypeStr);
            }
        }
    }

    public void SetTick(bool isSet)
    {
        tickObj.SetActive(isSet);
        flashObj.SetActive(isSet);
    }

    private void OnDestroy() 
    {
        CardCamera.enabled = false;
    }
}
