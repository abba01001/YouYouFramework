﻿
using UnityEngine.UI;
using QFramework;
using SoliUtils;

public class HarvestPopView : ViewBase
{
    private Text coinNumText;
    private Button noAdBtn;
    private Button adBtn;

    protected override void OnAwake()
    {
        coinNumText = transform.Get<Text>("Container/CoinNum");
        noAdBtn = transform.Get<Button>("Container/NoAdBtn");
        adBtn = transform.Get<Button>("Container/AdBtn");

        transform.Get<Button>("Container/CloseBtn").SetButtonClick(() => BoxBuilder.HidePopup(gameObject));
    }

    protected override void OnShow()
    {
        int harvestCoin = 50;
        coinNumText.text = harvestCoin.ToString();

        noAdBtn.SetButtonClick(() =>
        {
            BoxBuilder.HidePopup(gameObject);
            TypeEventSystem.Send<HomeHarvestEvent>(new HomeHarvestEvent(harvestCoin));
        });

        adBtn.SetButtonClick(() =>
        {
            AdPlayer.ShowHarvestAd(() =>
            {
                BoxBuilder.HidePopup(gameObject);
                TypeEventSystem.Send<HomeHarvestEvent>(new HomeHarvestEvent(harvestCoin * 2));
                dataService.SaveData(true);
            });
        });
    }
}
