using System;
using System.Collections.Generic;
using MiniJSON;
using QFramework;
using UniRx;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using BaseMeshEffect = Coffee.UIExtensions.BaseMeshEffect;
using Button = UnityEngine.UI.Button;
using WeChatWASM;
using System.Collections;
using UnityEngine.Networking;
using SimpleJSON;
using Doozy.Engine.UI;
using Activities;

public class LevelRankingView : ViewBase
{
    private Button closeBtn;
    private Toggle nationalBtn;
    private Toggle provinceBtn;
    private Toggle friendsBtn;
    private ListView nationalListView;
    private ListView provinceListView;
    private RawImage friendsListView;
    private LevelRankingAdapter nationalListAdapter;
    private LevelRankingAdapter provinceListAdapter;
    private GameObject selfItem;
    private Image selfRankImg;
    private Text selfRankText;
    private Image selfHeadImg;
    private Text selfNameText;
    private Text selfLevelText;
    private Transform selEndlessItem;
    private Text selEndlessText;

    private bool showProvince;
    private int pageIdx = 1;
    private string nationalData;
    private string provinceData;

    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(() => { BoxBuilder.HidePopup(gameObject); });

        nationalListView = transform.Get<ListView>("Container/NationalScrollView/Content");
        provinceListView = transform.Get<ListView>("Container/ProvinceScrollView/Content");
        nationalListAdapter = transform.Get<LevelRankingAdapter>("Container/NationalScrollView/Content");
        provinceListAdapter = transform.Get<LevelRankingAdapter>("Container/ProvinceScrollView/Content");
        friendsListView = transform.Get<RawImage>("Container/FriendsScrollView");
        nationalListView.transform.parent.gameObject.SetActive(true);
        provinceListView.transform.parent.gameObject.SetActive(false);
        friendsListView.gameObject.SetActive(false);
        nationalBtn = transform.Get<Toggle>("Container/bg/btnLayout/NationalTog");
        var nationalText = nationalBtn.transform.Find("Label").GetComponent<Text>();
        var nationalBaseMeshEffect = nationalBtn.transform.Find("Label").GetComponents<BaseMeshEffect>();
        provinceBtn = transform.Get<Toggle>("Container/bg/btnLayout/ProvinceTog");
        var provinceText = provinceBtn.transform.Find("Label").GetComponent<Text>();
        var provinceBaseMeshEffect = provinceBtn.transform.Find("Label").GetComponents<BaseMeshEffect>();
        friendsBtn = transform.Get<Toggle>("Container/bg/btnLayout/FriendsTog");
        var friendsText = friendsBtn.transform.Find("Label").GetComponent<Text>();
        var friendsBaseMeshEffect = friendsBtn.transform.Find("Label").GetComponents<BaseMeshEffect>();
        foreach (var eff in nationalBaseMeshEffect)
        {
            eff.enabled = true;
        }

        foreach (var eff in provinceBaseMeshEffect)
        {
            eff.enabled = false;
        }

        foreach (var eff in friendsBaseMeshEffect)
        {
            eff.enabled = false;
        }

        var uncheckColor = new Color(136 / 255f, 56 / 255f, 6 / 255f, 1);
        nationalText.color = Color.white;
        provinceText.color = uncheckColor;
        friendsText.color = uncheckColor;
        nationalBtn.onValueChanged.AddListener((check) =>
        {
            foreach (var eff in nationalBaseMeshEffect)
            {
                eff.enabled = check;
            }

            nationalText.color = check ? Color.white : uncheckColor;
            if (!check)
                return;
            if (pageIdx == 1)
                return;
            if (pageIdx == 3)
                WeChatMiniGame.HideOpenData();
            pageIdx = 1;
            RequestRank(1, true);
            nationalListView.transform.parent.gameObject.SetActive(true);
            provinceListView.transform.parent.gameObject.SetActive(false);
            friendsListView.gameObject.SetActive(false);
            nationalListView.RefreshData();
        });
        provinceBtn.onValueChanged.AddListener((check) =>
        {
            foreach (var eff in provinceBaseMeshEffect)
            {
                eff.enabled = check;
            }

            provinceText.color = check ? Color.white : uncheckColor;
            if (!check)
                return;
            if (pageIdx == 2)
                return;
            if (pageIdx == 3)
                WeChatMiniGame.HideOpenData();
            pageIdx = 2;
            RequestRank(2, true);
            nationalListView.transform.parent.gameObject.SetActive(false);
            provinceListView.transform.parent.gameObject.SetActive(true);
            friendsListView.gameObject.SetActive(false);
            provinceListView.RefreshData();
        });
        friendsBtn.onValueChanged.AddListener((check) =>
        {
            foreach (var eff in friendsBaseMeshEffect)
            {
                eff.enabled = check;
            }

            friendsText.color = check ? Color.white : uncheckColor;
            if (!check)
                return;
            if (pageIdx == 3)
                return;

            pageIdx = 3;
            nationalListView.transform.parent.gameObject.SetActive(false);
            provinceListView.transform.parent.gameObject.SetActive(false);
            friendsListView.gameObject.SetActive(true);


            UICanvas canvas = UICanvas.GetUICanvas(UIPopup.DEFAULT_POPUP_CANVAS_NAME, true);
            var scaler = canvas.GetComponent<CanvasScaler>();
            var referenceResolution = scaler.referenceResolution;
            var screenMatchMode = scaler.screenMatchMode;
            var matchWidthOrHeight = scaler.matchWidthOrHeight;
            float screenWidth = Screen.width;
            float screenHeight = Screen.height;

            var p = friendsListView.transform.position;
            Rect rect = friendsListView.rectTransform.rect;

            // WeChatMiniGame.ShowOpenData(friendsListView.texture, (int)p.x, Screen.height - (int)p.y,
            //  (int)((screenWidth / referenceResolution.x) * rect.width),
            //   (int)((screenWidth / referenceResolution.x) * rect.height));

            float scaleFactor = screenWidth / referenceResolution.x;
            if (screenMatchMode == CanvasScaler.ScreenMatchMode.MatchWidthOrHeight)
            {
                // 根据 matchWidthOrHeight 的值调整缩放比例
                scaleFactor = Mathf.Lerp(screenWidth / referenceResolution.x, screenHeight / referenceResolution.y, matchWidthOrHeight);
            }

            int width = (int)(rect.width * scaleFactor);
            int height = (int)(rect.height * scaleFactor);
            // int x = (int)(p.x * scaleFactor);
            // int y = Screen.height - (int)(p.y * scaleFactor);
            WeChatMiniGame.ShowOpenData(friendsListView.texture, 0, 0, width, height);


            // var rectTransform = friendsListView.GetComponent<RectTransform>();
            // Vector3 screenPosition = RectTransformUtility.WorldToScreenPoint(Camera.main, rectTransform.position);
            //    Vector2 size = rectTransform.rect.size;
            //     Vector3[] corners = new Vector3[4];
            //     rectTransform.GetWorldCorners(corners);
            //     for (int i = 0; i < corners.Length; i++)
            //     {
            //         corners[i] = RectTransformUtility.WorldToScreenPoint(Camera.main, corners[i]);
            //     }
            // float screenWidth = Mathf.Abs(corners[3].x - corners[0].x);
            // float screenHeight = Mathf.Abs(corners[1].y - corners[0].y);
            // var screenSize = new Vector2(screenWidth, screenHeight);
            // screenPosition.x -= screenSize.x / 2;
            // screenPosition.y = Screen.height - (screenPosition.y + screenSize.y / 2);
            // WeChatMiniGame.ShowOpenData(friendsListView.texture, (int)screenPosition.x, (int)screenPosition.y,
            //     (int)screenSize.x,
            //     (int)screenSize.y);

            Dictionary<string, string> msgData = new Dictionary<string, string>();
            msgData.Add("type", "showFriendsRank");
            var msg = Json.Serialize(msgData);

            var authOpt = new AuthorizeOption
            {
                scope = "scope.WxFriendInteraction",
                success = result =>
                {
                    if (pageIdx == 3)
                    {
                        WX.GetOpenDataContext().PostMessage(msg);
                    }
                },
                fail = result => { }
            };
            WX.Authorize(authOpt);
            WeChatMiniGame.OpenDataPostMessage(msg);

            RefreshSelfRank(false, 0, 0);
        });


        selfItem = transform.Get<Transform>("Container/SelfItem").gameObject;
        selfRankImg = selfItem.transform.Get<Image>("LevelIcon");
        selfRankText = selfItem.transform.Get<Text>("LevelIcon/Text");
        selfHeadImg = selfItem.transform.Get<Image>("HeadIcon/Image");
        selfNameText = selfItem.transform.Get<Text>("Name");
        selfLevelText = selfItem.transform.Get<Text>("Level");
        selEndlessItem = selfItem.transform.Get<Transform>("Cup");
        selEndlessText = selfItem.transform.Get<Text>("Cup/NumText");

        TypeEventSystem.Register<LevelRankingEvent>(OnLevelRankingEvent);
        RefreshSelfInfo();
        // RefreshSelfRank(false, 0, 0);

        Show();
        WeChatMiniGame.CheckWxAuthInfo((ret, filepath) =>
        {
        });
    }

    void Show()
    {
        string province = dataService.UserProvince;
        showProvince = !string.IsNullOrEmpty(province) && province.ToLower() != "null" &&
                       province.ToLower() != "undefined";
        if (!showProvince)
        {
            provinceBtn.transform.Get<Text>("Label").text = "地区";
        }
        else
        {
            provinceBtn.transform.Get<Text>("Label").text = dataService.UserProvince;
        }

        RequestRank(1, true);
        RequestRank(2, false);
    }

    private void OnLevelRankingEvent(LevelRankingEvent e)
    {
        if (string.IsNullOrEmpty(e.data))
            return;

        var dic = (Dictionary<string, object>)MiniJSON.Json.Deserialize(e.data);
        if (dic == null)
            return;

        if (e.rankType == 1 || e.rankType == 2)
        {
            int myRank = int.MaxValue;
            JSONNode jsonNode = JSON.Parse(e.data);
            if (dic.TryGetValue("leaderboard", out var _leaderboard))
            {
                JSONArray leaderboard = jsonNode["leaderboard"].AsArray;
                List<Tuple<int, string, string, string, int, int>> rank_data =
                    new List<Tuple<int, string, string, string, int, int>>();
                foreach (JSONNode _data in leaderboard)
                {
                    int result;
                    var _id = _data["user_id"] != null ? Convert.ToString(_data["user_id"]) : "";
                    var user_name = _data["name"] != null ? Convert.ToString(_data["name"]) : "";
#if UNITY_EDITOR
                    if (_id.Length < 6)
                        user_name = "r." + user_name;
#endif
                    var user_avatar = _data["avatar"] != null ? Convert.ToString(_data["avatar"]) : "";
                    var max_level = _data["cur_level"] != null && int.TryParse(_data["cur_level"], out result) ? result : 1;
                    var endless_score = _data["endless_score"] != null && int.TryParse(_data["endless_score"], out result) ? result : 0;
                    var rank = _data["rank"] != null && int.TryParse(_data["rank"], out result) ? result : 999;

                    rank_data.Add(new Tuple<int, string, string, string, int, int>(rank, _id,
                        user_name, user_avatar, max_level, endless_score));
                }

                bool reset = false;
                for (int i = 0; i < rank_data.Count; i++)
                {
                    var data = rank_data[i];
                    if (data.Item2 == dataService.UserId)
                    {
                        var endless_score = ActivityManager.Instance.EndlessLevelActivity.GetMyIntegral();
                        if (dataService.MaxLevel != data.Item5 || endless_score != data.Item6)
                        {
                            rank_data[i] = new Tuple<int, string, string, string, int, int>(data.Item1, data.Item2,
                                dataService.UserName, dataService.UserAvatar, dataService.MaxLevel, endless_score);
                            reset = true;
                        }
                        break;
                    }
                }
                if (!reset)
                {
                    var data = rank_data[rank_data.Count - 1];
                    var endless_score = ActivityManager.Instance.EndlessLevelActivity.GetMyIntegral();
                    if (dataService.MaxLevel > data.Item5 || (dataService.MaxLevel == data.Item5 && endless_score > data.Item6))
                    {
                        reset = true;
                        for (int i = 0; i < rank_data.Count; i++)
                        {
                            var _data = rank_data[i];
                            if (_data.Item2 == dataService.UserId)
                            {
                                if (dataService.MaxLevel != data.Item5 || endless_score != data.Item6)
                                {
                                    rank_data[i] = new Tuple<int, string, string, string, int, int>(data.Item1, data.Item2,
                                        dataService.UserName, dataService.UserAvatar, dataService.MaxLevel, endless_score);
                                }
                                break;
                            }
                        }
                    }
                }
                if (reset)
                {
                    rank_data.Sort((x, y) =>
                    {
                        int result = y.Item5.CompareTo(x.Item5);
                        if (result == 0)
                        {
                            result = y.Item6.CompareTo(x.Item6);
                        }
                        if (result == 0)
                        {
                            result = x.Item1.CompareTo(y.Item1);
                        }
                        return result;
                    });
                    for (int i = 0; i < rank_data.Count; i++)
                    {
                        var data = rank_data[i];
                        if (data.Item1 != i + 1)
                        {
                            rank_data[i] = new Tuple<int, string, string, string, int, int>(i + 1, data.Item2,
                                data.Item3, data.Item4, data.Item5, data.Item6);
                        }
                        if (data.Item2 == dataService.UserId)
                        {
                            myRank = i + 1;
                        }
                    }
                }
                else
                {
                    rank_data.Sort((x, y) =>
                    {
                        int result = y.Item5.CompareTo(x.Item5);
                        if (result == 0)
                        {
                            result = y.Item6.CompareTo(x.Item6);
                        }
                        if (result == 0)
                        {
                            result = x.Item1.CompareTo(y.Item1);
                        }
                        return result;
                    });
                }

                if (e.rankType == 1)
                    nationalListAdapter.SetData(rank_data);
                else if (e.rankType == 2)
                    provinceListAdapter.SetData(rank_data);
                Observable.NextFrame().Subscribe((x) => { nationalListView.ReFillData(); });

            }
            if (dic.TryGetValue("mydata", out var _mydata))
            {
                JSONNode mydata = jsonNode["mydata"].AsObject;
                if (pageIdx != 3)
                {
                    int myrank = mydata != null && mydata["rank"] != null && int.TryParse(mydata["rank"], out myrank) ? myrank : 1000;
                    if (myRank != int.MaxValue)
                    {
                        myrank = myRank;
                    }
                    int myscore = mydata != null && mydata["endless_score"] != null && int.TryParse(mydata["endless_score"], out myscore) ? myscore : 0;
                    myscore = dataService?.EndlessLevelProgress?.MyData?.integration ?? myscore;
                    RefreshSelfRank(true, myrank, myscore);
                }
            }
        }

        // UniRx.Observable.Timer(TimeSpan.FromSeconds(0.1f)).Subscribe(_ =>
        // {
        //     // nationalListView.ReFillData();
        //     // provinceListView.ReFillData();
        // });
    }

    private void RefreshSelfInfo()
    {
        var avatar = dataService.UserAvatar;
        if (string.IsNullOrEmpty(avatar))
        {
            avatar = Constants.DefaultAvatarUrl;
        }

        GameUtils.GetAvatar(
            avatar,
            (ret, filePath) =>
            {
                if (string.IsNullOrEmpty(filePath))
                    return;
                if (selfHeadImg.Equals(null))
                    return;
                var tex = SpriteUtils.ReadTexture(filePath);
                if (tex != null)
                {
                    selfHeadImg.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                }
            });
        selfNameText.text = dataService.UserName;
    }

    private void RefreshSelfRank(bool show, int rank, int endless_score)
    {
        selfItem.SetActive(show);
        selfRankImg.enabled = false;
        if (rank > 999)
            selfRankText.text = "999+";
        else
            selfRankText.text = rank.ToString();
        selfLevelText.text = dataService.MaxLevel.ToString();
        selEndlessItem.gameObject.SetActive(endless_score > 0);
        selEndlessText.text = endless_score.ToString();
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<LevelRankingEvent>(OnLevelRankingEvent);
        if (pageIdx == 3)
            WeChatMiniGame.HideOpenData();
    }

    IEnumerator GetRequest(string url, Action<bool, string> callback)
    {
        using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
        {
            yield return webRequest.SendWebRequest();

            if (webRequest.result == UnityWebRequest.Result.ConnectionError || webRequest.result == UnityWebRequest.Result.ProtocolError)
            {
                Debug.LogError("Error: " + webRequest.error);
                callback?.Invoke(false, "");
            }
            else
            {
                // Debug.Log($"{url}, Response=> {webRequest.downloadHandler.text}");
                callback?.Invoke(true, webRequest.downloadHandler.text);
            }
        }
    }

    void RequestRank(int _type, bool show = false)
    {
        if (_type == 1 && nationalData != null)
        {
            if (show)
                TypeEventSystem.Send<LevelRankingEvent>(new LevelRankingEvent() { rankType = _type, data = nationalData });
            return;
        }
        if (_type == 2 && provinceData != null)
        {
            if (show)
                TypeEventSystem.Send<LevelRankingEvent>(new LevelRankingEvent() { rankType = _type, data = provinceData });
            return;
        }
        var dataSrv = MainContainer.Container.Resolve<IDataService>();
        string uid = dataSrv.UserId;
        var time = TimeUtils.UtcNow();
        string flag = EncryptUtils.MD5Encrypt(uid + time + Constants.ServerKey);
        string url = Constants.ApiUrl + "/rank";
        url = $"{url}?uid={uid}&type={_type}&time={time}&flag={flag.ToLower()}";
        // Debug.LogError("RequestRank url: " + url);
        StaticCoroutine.StartCoroutine(GetRequest(url, (ret, json) =>
        {
            // Debug.Log("RequestRank res: " + json);
            if (ret)
            {
                if (_type == 1)
                    nationalData = json;
                else if (_type == 2)
                    provinceData = json;
                if (show)
                    TypeEventSystem.Send<LevelRankingEvent>(new LevelRankingEvent() { rankType = _type, data = json });
            }
        }));
    }
}