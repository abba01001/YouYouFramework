using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;

[RequireComponent(typeof(CanvasGroup))]
public class StartMysteriousSeedPopView : ViewBase
{
    private Button CloseBtn;
    private GameObject CollectLoveCardContent;
    private ActivityTimeItem timeItem;
    private Action startGame;

    protected override void OnAwake()
    {
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        CloseBtn.SetButtonClick(CloseFunc);
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(EnterGameFunc);
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        InitPanel();
    }

    private void InitPanel()
    {
        RefreshTimer(null);
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (ActivityManager.Instance.GetActivityByType(ActivityType.mysteriousSeed) != null && ActivityManager.Instance.GetActivityByType(ActivityType.mysteriousSeed).state
                is ActivityState.waitEntry or ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.mysteriousSeed).ActivityBigEndTime);
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.mysteriousSeed).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.MysteriousSeedProgress.ActivityEndTime);
        }
        timeItem.SetTimeData(timeData);
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    private void EnterGameFunc()
    {
        ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.MysteriousSeedPopup, BoxBuilder.ShowMysteriousSeedPopup, true);
        CloseFunc();
    }
}