﻿using QFramework;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class GiftPlusOneView : ViewBase
{
    private Text priceText;
    private Text timeText;
    private Transform itemParent;
    [SerializeField] private GameObject BigShopItem1;
    [SerializeField] private GameObject BigShopItem2;
    protected override void OnAwake()
    {
        transform.Get<Button>("Content/CloseBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
        });
    }

    protected override void OnViewInit(bool isFirst)
    {
        TypeEventSystem.Register<GameRechargeEvent>(UpdatPanel);
        TypeEventSystem.Register<HideGiftPlusPopup>(ClosePanel);
    }

    private void UpdatPanel(GameRechargeEvent obj)
    {

    }
    
    private void ClosePanel(HideGiftPlusPopup obj)
    {
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatPanel);
        TypeEventSystem.UnRegister<HideGiftPlusPopup>(ClosePanel);
    }

    protected override void OnShow()
    {
        if (!dataService.CheckFirstPopup(Constants.DoozyView.GiftPlusOnePopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.GiftPlusOnePopup);
        }

        UpdateInfo();
    }


    private void UpdateInfo()
    {
        string str = $"{Constants.ProductId.GiftPlusOne}_{dataService.GiftPlusOneData.curIndex}_";
        List<ShopModel> models = new List<ShopModel>();
        for (int i = 1; i <= 3; i++)
        {
            string product_id = str + $"{i}";
            configService.ShopConfig.TryGetValue(product_id, out ShopModel model);
            models.Add(model);
        }
        
        if (models.Count >= 3)
        {
            var buyBtn = transform.Get<Button>("Content/BuyBtn");
            buyBtn.SetButtonClick(() =>
            {
                SoundPlayer.Instance.PlayButton();
                PayUtils.RequestOrder(models[2].product_id);
            });
            buyBtn.gameObject.Get<Text>("Price").text = models[2].money.ToString();
            UpdateSHopItem(BigShopItem1.Get<Transform>("ProductContent/Reward"),models[0],GameUtils.AnalysisPropString(models[0].reward));
            UpdateSHopItem(BigShopItem2.Get<Transform>("ProductContent/Reward"),models[1],GameUtils.AnalysisPropString(models[1].reward));
        }
    }

    private void UpdateSHopItem(Transform rewardParent,ShopModel model,Dictionary<int,int> rewardDic)
    {
        var buyBtn = rewardParent.parent.Get<Button>("BuyBtn");
        buyBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(model.product_id);
        });
        buyBtn.gameObject.Get<Text>("Price").text = model.money.ToString();
        
        for (int i = 0; i < rewardParent.childCount; i++)
        {
            rewardParent.GetChild(i).gameObject.SetActive(false);
        }
        int count = 0;
        foreach (var pair in rewardDic)
        {
            if (count >= rewardParent.childCount) break;
            var child = rewardParent.GetChild(count);
            child.gameObject.MSetActive(true);
            GameUtils.LoadPropSprite(child.Get<Image>($"PropImage"), pair.Key);
            child.Get<Transform>($"TimeText").gameObject.MSetActive(GameUtils.IsLimitTimeReward(pair.Key));
            child.Get<Text>($"TimeText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            child.Get<Text>($"NumText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
            count++;
        }
    }
}