using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelRankingAdapter : ListViewAdapter
{
    private List<Tuple<int, string, string, string, int, int>> _data;

    public override int GetCount()
    {
        return _data?.Count ?? 0;
    }

    public override void FillItemData(ListViewCell item, int cellindex)
    {
        item.FillData(cellindex, _data[cellindex]);
    }

    public override int GetCellPrefabIndex(int index)
    {
        return 0;
    }

    public void SetData(List<Tuple<int, string, string, string, int, int>> data)
    {
        _data = data;
    }
}