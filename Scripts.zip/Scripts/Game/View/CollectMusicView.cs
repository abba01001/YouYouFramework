﻿using Activities;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class CollectMusicView : ViewBase
{
    private Button closeBtn;
    private Button tipBtn;
    private RectTransform fillAmount;
    private Text progressText;
    private ActivityTimeItem timeItem;
    private Transform nextRewardItem;
    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(CloseFunc);
        tipBtn = transform.Get<Button>("Container/TipBtn");
        fillAmount = transform.Get<RectTransform>("Container/Progress/FillAmount");
        progressText = transform.Get<Text>("Container/Progress/Text");
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        nextRewardItem = transform.Get<Transform>("Container/Progress/NextRewardItem");
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(() =>
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);
            BoxBuilder.HidePopup(gameObject);
        });
    }
    protected override void OnViewInit(bool isFirst)
    {
        if(!isFirst) return;
        TypeEventSystem.Register<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    private (Vector2,Vector2) GetOffset(int index)
    {
        return index switch
        {
            0 => (new Vector2(0, 30), new Vector2(0, 0)),
            1 => (new Vector2(96, 30), new Vector2(0, 0)),
            2 => (new Vector2(332, 30), new Vector2(0, 0)),
            _ => (new Vector2(664, 30), new Vector2(-100, 0))
        };
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }
    
    //更新排行面板
    private void UpdatePanel(UpdateRankViewEvent obj)
    {

    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    private void SetNextReward()
    {
        if (ActivityManager.Instance.CollectMusicActivity.CurIsMaxLayer())
        {
            nextRewardItem.gameObject.SetActive(false);
            return;
        }
        nextRewardItem.gameObject.SetActive(true);
        Dictionary<int, int> rewardList = ActivityManager.Instance.CollectMusicActivity.GetNextReward();
        
        var box = nextRewardItem.transform.Get<Transform>("Box");
        var item = nextRewardItem.transform.Get<Transform>("Item");
        box.gameObject.SetActive(rewardList.Count > 1);
        item.gameObject.SetActive(rewardList.Count == 1);
        if (rewardList.Count == 1)
        {
            foreach (var pair in rewardList)
            {
                Image propImage = item.transform.Get<Image>("PropImage");
                Text timeText = item.transform.Get<Text>("TimeText");
                Text numText = item.transform.Get<Text>("NumText");
                numText.text = "";
                timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward((int)pair.Key));
                if (GameUtils.IsLimitTimeReward((int)pair.Key))
                {
                    long infiniteTime = pair.Value;
                    timeText.text = infiniteTime / 60 + "m";
                }
                else
                {
                    numText.text = pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
                }

                propImage.LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : (int)pair.Key);
                break;
            }
        }
    }
    
    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.collectMusic);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.collectMusic).ActivityBigEndTime);
            }
            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.CollectMusicProgress.ActivityEndTime);
            }
        }
        timeItem.SetTimeData(timeData);
    }
    
    void SetProgress()
    {
        int nextCount = ActivityManager.Instance.CollectMusicActivity.GetNextLayerCollectCount();
        int curCount = ActivityManager.Instance.CollectMusicActivity.GetCurLayerCollectCount();
        progressText.text = $"{curCount}/{nextCount}";
        fillAmount.sizeDelta = new Vector2(Mathf.Min(ActivityManager.Instance.CollectMusicActivity.GetRatio() * 595,595), fillAmount.sizeDelta.y);
    }
    
    protected override void OnShow()
    {
        InitPanel();
        RefreshTimer(null);
    }

    private void InitPanel()
    {
        SetNextReward();
        SetProgress();
    }
}
