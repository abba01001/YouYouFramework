using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class CardBox : MonoBehaviour
{
    public Image Bg;
    public Image Fg;
    public Transform[] ImageCards;
    public GameObject flashObj;
    public GameObject tickObj;
    private float time = 0.8f;
    private Dictionary<int, List<Vector3>> cardPos = new Dictionary<int, List<Vector3>>() {
    { 1, new List<Vector3> { new Vector3(-27,85), new Vector3(-350, 85), new Vector3(0,28) } },
    { 2, new List<Vector3> { new Vector3(-15,89), new Vector3(-350, 89), new Vector3(0, 15) } },
    { 3, new List<Vector3> { new Vector3(1,90), new Vector3(-350, 90), new Vector3(0, 7) } },
    { 4, new List<Vector3> { new Vector3(25,88), new Vector3(-350, 88), new Vector3(0, -3) } },
    { 5, new List<Vector3> { new Vector3(50,76), new Vector3(-350, 76), new Vector3(0, -15) } },
};
    public void ShowImageBox(int showCount = 0,int lastCount = -1)
    {
        SetTick(false);
        int level = showCount < 2 ? 1 : (showCount < 4 ? 2 : 3);
        for (int i = 1; i <= 5; i++)
        {
            ImageCards[i - 1].gameObject.SetActive(i <= showCount);
        }
        if(showCount == lastCount || lastCount > showCount || lastCount == -1)
        {
            Bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, $"he{level}_2", false);
            Fg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, $"he{level}_1", false);
        }
        else
        {
            PlayAnim(showCount, lastCount, level);
        }

    }

    private void PlayAnim(int showCount,int lastCount,int level)
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        Sequence seq = DOTween.Sequence();

        Transform cardObj = ImageCards[showCount - 1];
        seq.SetId(transform);

        cardObj.localScale = Vector3.zero;
        cardObj.localPosition = cardPos[showCount][1];
        cardObj.transform.localRotation = Quaternion.identity;

        Vector3 targetPos = cardPos[showCount][0];
        float rotateY = cardPos[showCount][2].y;

        seq.Insert(0f, cardObj.DOScale(Vector3.one * 0.2f, 0f));
        seq.Append(cardObj.DOScale(Vector3.one, time / 2).SetEase(Ease.OutQuad));
        Vector3 startPoint = cardObj.localPosition;
        Vector3 endPoint = new Vector3(targetPos.x, targetPos.y, cardObj.localPosition.z);
        Vector3 controlPoint = new Vector3(startPoint.x + (endPoint.x - startPoint.x) / 2f, startPoint.y + 100f, startPoint.z);
        Vector3[] path = new Vector3[] { startPoint, controlPoint, endPoint };
        seq.Insert(time / 2, cardObj.DOLocalRotate(new Vector3(0, 0, rotateY), time, RotateMode.FastBeyond360).SetEase(Ease.OutQuad));
        seq.Insert(time / 2, cardObj.DOLocalPath(path, time).SetEase(Ease.OutSine)).OnComplete(()=> {
            Bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, $"he{level}_2", false);
            Fg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStreakTipAtlas, $"he{level}_1", false);
        });
        seq.Insert(time / 5 + time, transform.DOScale(new Vector3(1f, 0.7f), 0.15f).SetEase(Ease.OutSine));
        seq.Insert(time / 5 + time + 0.15f, transform.DOScale(new Vector3(0.6f, 1f), 0.15f).SetEase(Ease.OutSine));
        seq.Insert(time / 5 + time + 0.15f * 2, transform.DOScale(new Vector3(0.8f, 0.8f), 0.15f).SetEase(Ease.OutSine));
        dataService.ActivitySaveData.winStreak.LastWinCount = dataService.ActivitySaveData.winStreak.WinCount;
        dataService.SaveData(true);
    }

    public void SetTick(bool isSet)
    {
        tickObj.SetActive(isSet);
        flashObj.SetActive(isSet);
    }

    private void OnDestroy() 
    {

    }
}
