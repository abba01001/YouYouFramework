﻿using System.Collections;
using System.Collections.Generic;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Doozy.Engine;
using System;
using Doozy.Engine.UI;
using UniRx;
using Coffee.UIExtensions;
using SoliUtils;

public class VipPopView : ViewBase
{
    private Button singleBuyBtn;
    private Button successionBuyBtn;
    private GameObject alreadyVip;
    private Text singlePriceText;
    private Text freeTrialText;
    private Text successionPriceText;
    private Text discountText;

    private const string SingleMonthKey = "one_month_vip";
    private const string SuccessionMonthKey = "vip_2";

    protected override void OnAwake()
    {
        singleBuyBtn = transform.Get<Button>("Container/BG/SingleBuyBtn");
        successionBuyBtn = transform.Get<Button>("Container/BG/SuccessionBuyBtn");
        alreadyVip = transform.Find("Container/BG/AlreadyVip").gameObject;

        singlePriceText = singleBuyBtn.transform.Get<Text>("Price");
        freeTrialText = successionBuyBtn.transform.Get<Text>("FreeTrialText");
        successionPriceText = successionBuyBtn.transform.Get<Text>("FreeTrialText/Price");
        discountText = successionBuyBtn.transform.Get<Text>("DiscountBG/DiscountText");

        transform.Get<Button>("Container/BG/CloseBtn").SetButtonClick(() => BoxBuilder.HidePopup(gameObject));
        // singleBuyBtn.SetButtonClick(() => Purchaser.Instance.BuyProduct(SingleMonthKey));
        // successionBuyBtn.SetButtonClick(() => Purchaser.Instance.BuyProduct(SuccessionMonthKey));
    }

    protected override void OnViewInit(bool isFirstTime)
    {
        if (!isFirstTime) return;
        TypeEventSystem.Register<PurchaseSuccess>(OnPurchaseSuccess);
    }

    protected override void OnShow()
    {
        RefreshState();
    }

    private void RefreshState()
    {
        switch (dataService.VipBuyType)
        {
            case 0:
                alreadyVip.SetActive(false);
                singleBuyBtn.gameObject.SetActive(true);
                successionBuyBtn.gameObject.SetActive(true);
                string disCountStr = "优惠";
                // if (Purchaser.Instance.IsInitialized())
                // {
                //     var subscriptionInfo = Purchaser.Instance.GetSubscriptionInfo();
                //     freeTrialText.text = subscriptionInfo?.isFreeTrial() == Result.True ? string.Format(LocalizationManager.GetTranslation("vip_botton_trial"), (int)Math.Round(subscriptionInfo.getFreeTrialPeriod().TotalDays)) : "";
                //     singlePriceText.text = Purchaser.Instance.GetProduct(SingleMonthKey).metadata.localizedPriceString;
                //     successionPriceText.text = Purchaser.Instance.GetProduct(SuccessionMonthKey).metadata.localizedPriceString;
                //     discountText.text = configService.ShopConfig[Purchaser.Instance.GetProductID(SuccessionMonthKey)].discount + "%" + disCountStr;
                // }
                // else
                // {
                //     ShopModel singleMonthModel = configService.ShopConfig[Purchaser.Instance.GetProductID(SingleMonthKey)];
                //     ShopModel SuccessionMonthModel = configService.ShopConfig[Purchaser.Instance.GetProductID(SuccessionMonthKey)];
                //     singlePriceText.text = singleMonthModel.GetShowPrice();
                //     successionPriceText.text = SuccessionMonthModel.GetShowPrice();
                //     discountText.text = SuccessionMonthModel.discount + "%" + disCountStr;
                // }
                break;
            case 1:
            case 2:
            case 3:
            case 4:
                alreadyVip.SetActive(true);
                singleBuyBtn.gameObject.SetActive(false);
                successionBuyBtn.gameObject.SetActive(false);
                break;
            default:
                break;
        }
    }

    private void OnPurchaseSuccess(PurchaseSuccess obj)
    {
        // Product product = obj.purchasedProduct;
        // string productKey = Purchaser.Instance.GetProductKey(product);
        // if (productKey == SingleMonthKey || productKey == SuccessionMonthKey)
        // {
        //     RefreshState();
        //     long nowTime = TimeUtils.UtcNow();
        //     if (nowTime < dataService.VipEndTime && !TimeUtils.IsSameDay(nowTime, dataService.VipLastRewardTime))
        //         BoxBuilder.ShowVipReward();
        // }
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<PurchaseSuccess>(OnPurchaseSuccess);
    }
}
