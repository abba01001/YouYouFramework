﻿using System.Collections;
using System.Collections.Generic;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Doozy.Engine;
using System;
using Doozy.Engine.UI;
using SoliUtils;
using UnityEngine.Rendering;
using Object = System.Object;

public class ViewBase : MonoBehaviour
{
    private static bool isInit = false;
    protected bool reportOnShow = true;
    protected bool reportOnHide = true;
    protected IDataService dataService;
    protected IConfigService configService;
    protected IStorageService storageService;

    private Canvas selfCanvas;
    public int SortingOrder { get => selfCanvas.sortingOrder; set => selfCanvas.sortingOrder = value; }

    protected void Awake()
    {
        selfCanvas = GetComponent<Canvas>();

        TypeEventSystem.Register<ViewRefreshEvent>(Refresh);
        isInit = true;
        dataService = MainContainer.Container.Resolve<IDataService>();
        configService = MainContainer.Container.Resolve<IConfigService>();
        storageService = MainContainer.Container.Resolve<IStorageService>();
        OnAwake();
        OnViewInit(true);
        if (transform.Find("Overlay") && transform.Find("Overlay").childCount == 0)
        {
            transform.Find("Overlay").DOScale(1.5f * Vector3.one, 0.5f);
        }
    }

    // private void ConfigInitFinishEvent(GameEventMessage message)
    // {
    //     if (message?.EventName == Constants.DoozyEvent.ConfigInitFinish)
    //     {
    //         isInit = true;

    //         dataService = MainContainer.Container.Resolve<IDataService>();
    //         configService = MainContainer.Container.Resolve<IConfigService>();
    //         storageService = MainContainer.Container.Resolve<IStorageService>();
    //         Message.RemoveListener<GameEventMessage>(ConfigInitFinishEvent);
    //         OnViewInit(true);
    //         TypeEventSystem.Send<TriggrePopupEvent>();

    //     }
    // }

    private void OnEnable()
    {
        if (!isInit) return;

        if (reportOnShow)
        {
            var msg = new Dictionary<string, object>();
            msg.Add(AnalyticsKey.ViewName, gameObject.name);
            AnalyticUtils.ReportEvent(AnalyticsKey.SoliShowView, msg);
        }
        HandleLayer();
        OnShow();
    }

    private void HandleLayer()
    {
        if (this.GetComponent<UIPopup>())
        {
            GameCommon.VisiblePopupCount += 1;
            var efScale = Camera.main.orthographicSize / 400;
            var canvas = this.GetComponent<Canvas>();
            if (canvas != null)
            {
                canvas.overrideSorting = true;
                int oriSortOrder = canvas.sortingOrder;
                canvas.sortingOrder = 100 + GameCommon.VisiblePopupCount * 10;
                var cavs = this.GetComponentsInChildren<Canvas>(true);
                foreach (var cav in cavs)
                {
                    if (cav != canvas)
                    {
                        cav.sortingLayerName = "UI";
                        int diff = cav.sortingOrder - oriSortOrder;
                        cav.sortingOrder = canvas.sortingOrder + diff;
                    }
                }

                var ps = this.GetComponentsInChildren<ParticleSystem>(true);
                foreach (var p in ps)
                {
                    ParticleSystemRenderer r = p.GetComponent<ParticleSystemRenderer>();

                    r.sortingLayerName = "UI";
                    int d = r.sortingOrder - oriSortOrder;
                    r.sortingOrder = canvas.sortingOrder + d;

                    var mainModule = p.main;
                    // 获取缩放模式
                    if (mainModule.scalingMode != ParticleSystemScalingMode.Hierarchy)
                    {
                        Vector3 initScale = r.transform.localScale;
                        r.transform.localScale = initScale * efScale;
                    }
                }

                var sg = this.GetComponentsInChildren<SortingGroup>(true);
                foreach (var t in sg)
                {
                    t.sortingLayerName = "UI";
                    int d = t.sortingOrder - oriSortOrder;
                    t.sortingOrder = canvas.sortingOrder + d;
                }
            }
        }
    }

    private void OnDisable()
    {
        if (!isInit) return;
        if (reportOnHide)
        {
            var msg = new Dictionary<string, object>();
            msg.Add(AnalyticsKey.ViewName, gameObject.name);
            AnalyticUtils.ReportEvent(AnalyticsKey.SoliHideView, msg);
        }
        if (this.GetComponent<UIPopup>())
        {
            if (UIPopup.VisiblePopups.Count == 0) GameCommon.VisiblePopupCount = 0;
        }
    }

    private void OnDestroy()
    {
        if (isInit)
            OnInitedDestroy();
        OnViewDestroy();
        TypeEventSystem.UnRegister<ViewRefreshEvent>(Refresh);
    }

    private void Refresh(ViewRefreshEvent obj)
    {
        OnViewInit(false);
        OnRefresh();
    }

    protected virtual void OnAwake() { }
    protected virtual void OnViewInit(bool isFirstTime) { }
    protected virtual void OnShow() { }
    protected virtual void OnViewDestroy() { }
    protected virtual void OnInitedDestroy() { }
    protected virtual void OnRefresh() { }

}
