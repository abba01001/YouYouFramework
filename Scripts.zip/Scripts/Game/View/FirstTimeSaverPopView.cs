using Doozy.Engine;
using Doozy.Engine.UI;
using QFramework;
using System.Collections;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using System;
using UniRx;
using Model;
using Activities;
using SoliUtils;

public class FirstTimeSaverPopView : ViewBase
{
    private Button BG;
    private Image Label;
    private GameObject Fx;
    private Text Desc;
    protected override void OnAwake()
    {
        BG = transform.Get<Button>("Container/FirstTimeSaverBG");
        Desc = transform.Get<Text>("Container/FirstTimeSaverBG/Image/Text");
        Label = transform.Get<Image>("Container/FirstTimeSaverBG/Image");
        Fx = transform.Find("Container/FirstTimeSaverBG/gongneng_kaiqi_tx_02").gameObject;
        InitPanel();
    }

    protected override void OnShow()
    {
        SoundPlayer.Instance.PlayButton();
        Label.transform.localScale = Vector3.zero;
    }
    
    

    public void InitPanel()
    {
        TypeEventSystem.Send<HomeViewPigEvent>(new HomeViewPigEvent(true));
        Desc.text = "每次游戏,小猪都会产生 <color=#DD5715>一笔额外金币</color>!\n你可以用 <color=#DD5715>超优惠的价格</color>获取这些金币。";
        UniRx.Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
        {
            BG.SetButtonClick(() => {
                BG.interactable = false;
                SoundPlayer.Instance.PlayCertainComboPoint(1);
                Label.GetComponents<DOTweenAnimation>()[1].DOPlayById("end");
                UniRx.Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
                {
                    TypeEventSystem.Send<HomeViewPigEvent>(new HomeViewPigEvent(false, ()=>{
                        Fx.SetActive(false);
                    }));
                    Fx.SetActive(true);
                });
            });
        });
    }
    
    private void OnDestroy() 
    {
        
    }
}
