﻿using Activities;
using Doozy.Engine;
using Doozy.Engine.UI;
using Model;
using QFramework;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class EndWinStreakPopView : ViewBase
{

    private Button sureBtn;
    private Button cancelBtn;

    private Transform winStreakBox;
    private GameObject fx;

    protected override void OnAwake()
    {
        sureBtn = transform.Get<Button>("Container/Panel/SureBtn");
        cancelBtn = transform.Get<Button>("Container/Panel/CancelBtn");
        winStreakBox = transform.Find("Container/Panel/Image/Box");
        fx = winStreakBox.transform.Find("win_box_tx_all").gameObject;
        fx.SetActive(false);
        transform.Find("anim_show").gameObject.SetActive(true);
        SetValue();
    }

    public void SetValue()
    {
        winStreakBox.gameObject.SetActive(false);
        var fillAmount = configService.GetWinStreakIdx(dataService.SuccessiveVictory, out var stepIdx);

        var proText = transform.Get<Text>("Container/Panel/Image/Box/ProgressText");
        proText.text = fillAmount >= 1 ? "MAX" : (int)(fillAmount*5) + "/" + 5;
        transform.Get<Image>("Container/Panel/Image/Box/ProgressImg").fillAmount = fillAmount;

        var winStreakCards = configService.GetWinStreakRewardCards(dataService.MaxLevel, stepIdx);
        var streakBox = transform.Find("Container/Panel/Image/Box/WinStreakBox");
        streakBox.GetComponent<WinStreakBox>().ShowBox(stepIdx, winStreakCards);

        fx.SetActive(fillAmount >= 1);
    }

    private void OnDestroy() 
    {
        Destroy(winStreakBox);
    }
}
