using Doozy.Engine;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class LanguageView : ViewBase
{
    Dictionary<string, Transform> LanguageTrans;

    protected override void OnAwake()
    {
        // reportOnShow = false;
        // transform.Get<Button>("CloseBtn").SetButtonClick(() => 
        // {
        //     GameEventMessage.SendEvent(Constants.DoozyEvent.BackHomeView);
        //     SoundPlayer.Instance.PlayCertainButton(6);
        // });

        // Transform panelTrans = transform.Find("Panel");
        // LanguageTrans = new Dictionary<string, Transform>(panelTrans.childCount);
        // foreach (Transform trans in panelTrans)
        // {
        //     LanguageTrans.Add(trans.name, trans);
        //     bool isSelect = LocalizationManager.CurrentLanguage == Constants.LanguageDic[trans.name];
        //     GameObject selectGo = trans.Find("Select").gameObject;
        //     selectGo.SetActive(isSelect);

        //     trans.GetComponent<Button>().SetButtonClick(() =>
        //     {
        //         SoundPlayer.Instance.PlayCertainButton(2);
        //         if (selectGo.activeSelf) return;
        //         foreach (var item in LanguageTrans.Values)
        //             item.Find("Select").gameObject.SetActive(false);
        //         selectGo.SetActive(true);
        //         string toLanguage = Constants.LanguageDic[trans.name];
        //         dataService.SelectLanguage = toLanguage;
        //         LocalizationManager.CurrentLanguage = toLanguage;
        //     });
        // }
    }
}
