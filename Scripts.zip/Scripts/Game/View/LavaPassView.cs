﻿using System;
using System.Collections.Generic;
using Activities;
using DG.Tweening;
using Doozy.Engine.UI;
using Model;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class LavaPassView : ViewBase
{

    private int curIndex = 0;
    private Action finishCb;
    private Vector3 OrignPlayerPos;
    private bool isPlayingAnim = false;
    private bool isPlayingDropSound = false;
    private List<GameObject> headList = new List<GameObject>();

    [SerializeField] private Text rewardText;
    [SerializeField] private Transform Mine;
    [SerializeField] private List<Transform> pathList = new List<Transform>();
    [SerializeField] private List<Transform> dropPathList = new List<Transform>();
    [SerializeField] private GameObject dropEf;
    [SerializeField] private GameObject headPrefab;
    [SerializeField] private Text lvNum;
    [SerializeField] private Text lvTotal;
    [SerializeField] private Text playerNum;
    [SerializeField] private Text playerTotal;
    [SerializeField] private GameObject continueBtn;
    ActivityTimeItem timeItem;
    protected override void OnAwake()
    {
        headPrefab.SetActive(false);
        continueBtn.SetActive(false);
        OrignPlayerPos = transform.Get<Transform>("Container/Content/EntryPlayer/1").transform.position;
        timeItem = transform.Get<ActivityTimeItem>("Container/Content/ActivityTimeItem");
        transform.Get<Button>("Container/Content/CloseBtn").SetButtonClick(CloseFunc);
        transform.Get<Button>("Overlay").SetButtonClick(() =>
        {
            if (continueBtn.activeSelf)
            {
                CloseFunc();
            }
        });
        transform.Get<Button>("Container/Content/TipBtn").SetButtonClick(BoxBuilder.ShowUnlockLavaPassPopView);
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).ActivityBigEndTime);
            }
            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.LavaPassProgress.ActivityEndTime);
            }

            if (model.state is ActivityState.finished)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.LavaPassProgress.ActivityEndTime + ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).OpenInterval);
            }
        }
        timeItem.SetTimeData(timeData);
    }
    
    private Tween PlayForwardAnim(Transform head,Vector3 myPos,Vector3 targetPos,float jumpTime = 0.8f)
    {
        Sequence seq = DOTween.Sequence();
        Vector3[] bezierArray = BezierUtils.GetBeizerList(myPos, (myPos + targetPos) / 2 + new Vector3(0,100,0), targetPos, 20);
        seq.Append(head.DOPath(bezierArray, jumpTime, PathType.CatmullRom).SetEase(Ease.OutCubic)).OnStart(() =>
        {
            SoundPlayer.Instance.PlayMainSound("LavaPass_jump");
        });
        seq.AppendCallback(() =>
        {
            head.transform.position = targetPos;
        });
        return seq;
    }

    private Vector3 GetDropOffset(int curIndex)
    {
        float x = 0;
        float y = 0;

        x = GameUtils.RandomRange(-100f, 100f);
        if (curIndex == 1)
        {
            x = GameUtils.RandomRange(-200f, 250f);
        }
        return new Vector3(x, y, 0);
    }
    
    public Tween PlayDropAnim(Transform head,Vector3 myPos,int curIndex,float jumpTime = 1f)
    {
        Transform targetTrans = dropPathList[curIndex].transform;

        Sequence seq = DOTween.Sequence();
        Vector3 targetPos = targetTrans.position + GetDropOffset(curIndex);
        Vector3[] bezierArray = BezierUtils.GetBeizerList(myPos, (myPos + targetPos) / 2 + new Vector3(0,100,0), targetPos, 12);
        seq.Join(head.DOPath(bezierArray, jumpTime, PathType.CatmullRom).SetEase(Ease.OutCubic)).OnStart(() =>
        {
            SoundPlayer.Instance.PlayMainSound("LavaPass_jump");
        });
        seq.InsertCallback(jumpTime - 0.1f, () =>
        {
            head.GetComponent<Image>().DOFillAmount(0, 1f).SetEase(Ease.Linear);
            head.Get<Image>("Icon").DOFillAmount(0, 1f).SetEase(Ease.Linear);
        });
        seq.InsertCallback(jumpTime, () =>
        {
            GameObject ef = GameObjManager.Instance.PopGameObject(GameObjType.LavaDropFx, dropEf);
            if (!isPlayingDropSound)
            {
                isPlayingDropSound = true;
                SoundPlayer.Instance.PlayMainSound("LavaPass_drown");
            }
            ef.SetActive(true);
            ef.transform.SetParent(head);
            ef.transform.SetLocalPositionAndRotation(Vector3.zero,Quaternion.identity);
            ef.transform.SetParent(head.parent);
            head.DOMove(new Vector3(targetPos.x, targetPos.y - 100, targetPos.z), 1f).SetEase(Ease.Linear).OnComplete(
                () =>
                {
                    GameObjManager.Instance.PushGameObject(ef);
                });
        });
        return seq;
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    public void SetFinishCb(Action cb)
    {
        finishCb = cb;
    }

    public void DoFinishCb()
    {
        finishCb?.Invoke();
        finishCb = null;
    }
    
    private void CloseFunc()
    {
        if(isPlayingAnim) return;
        DoFinishCb();
        ActivityManager.Instance.LavaPassActivity.CheckFinishActivity();
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
        if(GameUtils.IsInHomeView()) SoundPlayer.Instance.CheckActivityBgm(false,ActivityType.lavaPass);
        SoundPlayer.Instance.PlayEnvironmentSound();
    }

    private void OnDisable()
    {
        if (!GameObjManager.IsNull())
        {
            foreach (var item in headList)
            {
                GameObjManager.Instance.PushGameObject(item.gameObject);
            }
        }
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    protected override void OnShow()
    {
        SoundPlayer.Instance.CheckActivityBgm(true,ActivityType.lavaPass);
        SoundPlayer.Instance.PlayEnvironmentSound("Assets/Res/Audio/sound/LavaPass_lavaflow.ogg");
        RefreshTimer(null);
        UpdatePanel();
        isPlayingAnim = true;
        HandleMyAnim();
        InitPlayerHead();
        HandleRobotAnim();
        dataService.LavaPassProgress.lastWinCount = dataService.LavaPassProgress.winCount;
        dataService.LavaPassProgress.lastRobotCount = dataService.LavaPassProgress.robotCount;
        if (!GameUtils.IsInHomeView())
        {
            UIView.HideView(Constants.DoozyView.Result,true);
        }

        dataService.LavaPassProgress.IsFirstShow = false;
    }

    private void UpdatePanel()
    {
        lvTotal.text = $"{configService.LavaPassConfig.Count}";
        rewardText.text = $"{ActivityManager.Instance.LavaPassActivity.GetActivityRewardCoin()}";
        var startLv = dataService.LavaPassProgress.lastWinCount;
        var endLv = dataService.LavaPassProgress.winCount;
        lvNum.text = startLv.ToString();
        DOTween.To(() => startLv, x => {startLv = Mathf.RoundToInt(x);lvNum.text = startLv.ToString();
        }, endLv, 1f).SetDelay(0.5f);

        playerTotal.text = "100";
        var startCount = dataService.LavaPassProgress.lastRobotCount + 1;
        var endCount = dataService.LavaPassProgress.robotCount + 1;
        playerNum.text = startCount.ToString();
        DOTween.To(() => startCount, x => {startCount = Mathf.RoundToInt(x);playerNum.text = startCount.ToString();
        }, endCount, 1f).SetDelay(0.5f);
    }

    private void InitPlayerHead()
    {
        int count = dataService.LavaPassProgress.lastRobotCount;
        int lastWinCount = dataService.LavaPassProgress.lastWinCount;
        if (count == 0)
        {
            count = dataService.LavaPassProgress.robotCount;
        }
        count = Mathf.Clamp(count, 0, 30);

        var list = new List<int>();
        Vector3 myInitPos =  lastWinCount == 0 ? OrignPlayerPos : pathList[lastWinCount - 1].position;
        for (int i = 0; i < count; i++)
        {
            GameObject head = GameObjManager.Instance.PopGameObject(GameObjType.LavaHead, headPrefab);
            head.transform.SetParent(headPrefab.transform.parent);
            head.transform.localScale = Vector3.zero;
            head.transform.SetAsFirstSibling();
            var result = GetOffsetPosAndScale(lastWinCount,i);
            head.transform.localScale = Vector3.one * result.Item1;
            head.transform.position = myInitPos + result.Item2;
            head.GetComponent<Image>().fillAmount = 1;
            int value = GameUtils.GetRandomRobotIcon(ref list);
            var image = head.Get<Image>("Icon");
            image.fillAmount = 1;
            SpriteUtils.SetRobotSpriteByIndex(image,value,()=> image.gameObject.SetActive(true));
            head.SetActive(true);
            headList.Add(head);
        }
    }
    
    public (int, string) GetValues()
    {
        return (10, "Hello");
    }

    private (float,Vector3) GetOffsetPosAndScale(int index, int startIndex)
    {
        int x = 0;
        int y = 0;
        int z = 0;
        float scale = 1f;
        if (index == 0)
        {
            int line = startIndex / 4;
            int count = startIndex % 4;
            int baseX = 40;
            if (line > 0) baseX -= line * 5;
            bool isMiddleLine = line is > 2 and < 4;
            int baseValue = baseX * ((count / 2) + 1);
            int randomValue = isMiddleLine ? GameUtils.RandomRange(0, 20) : GameUtils.RandomRange(0, 10);
            if (count % 2 == 0)
            {
                x = -baseValue;
                y = count == 0 ? 2 + line * 10 : 5 + line * 10;
                if(line != 0) y += randomValue;
            }
            else
            {
                x = baseValue;
                y = count == 1 ? 2 + line * 10 : 5 + line * 10;
                if(line != 0) y += randomValue;
            }
            scale = line > 1f ? 1f + 0.02f * line : 1f;
        }
        else
        {
            int line = startIndex / 4;
            int count = startIndex % 4;
            int baseX = 25;
            if (line > 0) baseX -= line * 5;
            int baseValue = baseX * ((count / 2) + 1);
            if (count % 2 == 0)
            {
                x = -baseValue;
                y = count == 0 ? 2 + line * 2 : 5 + line * 2;
                if(line != 0) y +=  GameUtils.RandomRange(0, 10);
            }
            else
            {
                x = baseValue;
                y = count == 1 ? 2 + line * 2 : 5 + line * 2;
                if(line != 0) y +=  GameUtils.RandomRange(0, 10);
            }
            scale = line > 1f ? 1f + 0.02f * line : 1f;
        }
        return (scale,new Vector3(x, y, z));
    }

    
    
    private Tween HandleMyAnim()
    {
        int lastWinCount = dataService.LavaPassProgress.lastWinCount;
        int curWinCount = dataService.LavaPassProgress.winCount;
        Mine.transform.position = lastWinCount == 0 ? OrignPlayerPos : pathList[lastWinCount - 1].position;

        var Image = Mine.Get<Image>("Icon");
        
        WeChatMiniGame.CheckWxAuthInfo((ret, filePath) =>
        {
            if (ret)
            {
                var tex = SpriteUtils.ReadTexture(filePath);
                if (tex != null)
                {
                    Image.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                    Image.enabled = true;
                    Image.gameObject.SetActive(true);
                }
            }
        });
        
        Sequence seq = DOTween.Sequence();
        seq.AppendInterval(0.5f);
        Image.fillAmount = 1;
        Image.fillAmount = 1;
        if (curWinCount > lastWinCount)
        {
            for (int i = lastWinCount; i <= curWinCount; i++)
            {
                int index = i;
                if (index == lastWinCount) continue;
                Vector3 startPos = index - 2 >= 0 ? pathList[index - 2].position : OrignPlayerPos;
                Vector3 targetPos = index - 1 >= 0 ? pathList[index - 1].position : OrignPlayerPos;
                seq.Append(PlayForwardAnim(Mine,startPos,targetPos));
            }
        }

        if (dataService.LavaPassProgress.isFailState == 1)
        {
            seq.Append(PlayDropAnim(Mine,Mine.transform.position,lastWinCount));
        }

        seq.AppendInterval(1f);
        seq.AppendCallback(() =>
        {
            continueBtn.gameObject.SetActive(true);
            if (ActivityManager.Instance.LavaPassActivity.CheckGetReward(CloseFunc, null))
            {
                transform.Get<Image>("Container/Bg/Reward").color = Color.clear;
            }
            isPlayingAnim = false;
        });
        return seq;
    }

    private Tween HandleRobotAnim()
    {
        int lastWinCount = dataService.LavaPassProgress.lastWinCount;
        int curWinCount = dataService.LavaPassProgress.winCount;
        int lastRobotCount = dataService.LavaPassProgress.lastRobotCount;
        int curRobotCount = dataService.LavaPassProgress.robotCount;
        Sequence seq = DOTween.Sequence();
        if (curWinCount > lastWinCount)
        {
            int failCount = lastRobotCount - curRobotCount;
            if (failCount > dataService.LavaPassProgress.robotCount)
            {
                failCount = GameUtils.RandomRange(1,15);
            }
            failCount = Mathf.Clamp(failCount, 0, 15);
            int index = 0;
            for (int i = 0; i < failCount; i++)
            {
                seq.Insert(0.6f + 0.05f * index,PlayDropAnim(headList[index].transform, headList[index].transform.position, curWinCount - 1,GameUtils.RandomRange(0.5f,1.1f)));
                index++;
            }

            for (int i = failCount; i < headList.Count; i++)
            {
                index = i;
                Vector3 targetPos = curWinCount - 1 >= 0 ? pathList[curWinCount - 1].position : headList[i].transform.position;
                var result = GetOffsetPosAndScale(curWinCount,index);
                targetPos += result.Item2;
                seq.Insert(0.7f + 0.02f * index,PlayForwardAnim(headList[index].transform, headList[index].transform.position, targetPos,GameUtils.RandomRange(0.5f,1.1f)));
            }
        }

        if (dataService.LavaPassProgress.isFailState == 1)
        {
            int failCount = GameUtils.RandomRange(1,headList.Count);
            int index = 0;
            for (int i = 0; i < failCount; i++)
            {
                seq.Insert(0.6f + 0.05f * index,PlayDropAnim(headList[index].transform, headList[index].transform.position,lastWinCount,GameUtils.RandomRange(0.5f,1.1f)));
                index++;
            }
        }
        return null;
    }
    
}
