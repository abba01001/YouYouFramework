using System;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using UniRx;
using Doozy.Engine;
using System.Collections.Generic;
using Activities;
using Doozy.Engine.UI;
using Model;
using SoliUtils;

public class RookieView : ViewBase
{
    private List<Button> helpBtns;
    private GameObject processObj;
    private Image iconImg;
    private Text proText;
    private Animator xjlAnimator;
    private int level = 0;

    protected override void OnAwake()
    {
        level = dataService.GetRookieStatus();
        transform.GetComponent<Canvas>().sortingLayerName = "default";
        xjlAnimator = transform.Get<Animator>("View_Result_xjl_guochang_01/xjl_guochang_01");

        helpBtns = new List<Button>();
        helpBtns.Add(transform.Get<Button>("helpBtn1"));
        helpBtns.Add(transform.Get<Button>("helpBtn2"));
        helpBtns.Add(transform.Get<Button>("helpBtn3"));
        foreach (var btn in helpBtns)
        {
            btn.gameObject.SetActive(false);
        }

        processObj = transform.Find("processImg").gameObject;
        processObj.SetActive(false);
        iconImg = transform.Get<Image>("processImg/Icon");
        proText = transform.Get<Text>("processImg/processText");
        processObj.GetComponent<Canvas>().sortingLayerName = "UI";

        for (int i = 0; i < helpBtns.Count; i++)
        {
            var lv = i + 1;
            helpBtns[i].SetButtonClick(() =>
            {
                enterBattle(lv);
            });
        }

        // UniRx.Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe(_ =>
        // {
        //     if(level == 3)
        //         helpBtns[2].gameObject.SetActive(true);
        //     else
        //         helpBtns[level].gameObject.SetActive(true);
        // });
        if (level == 0)
        {
            xjlAnimator.Play("View_Result_xjl_zuo_dou_01");
            helpBtns[0].gameObject.SetActive(true);
            SoundPlayer.Instance.PlayXJLZuo01();
        }
        else if (level == 1)
        {
            xjlAnimator.Play("View_Result_xjl_zanli_01");
            helpBtns[1].gameObject.SetActive(true);
            SoundPlayer.Instance.PlayXJLZan01();
        }
        else
        {
            xjlAnimator.Play("View_Result_xjl_zanli_02");
            helpBtns[2].gameObject.SetActive(true);
            SoundPlayer.Instance.PlayXJLZan02();
        }
    }

    protected override void OnViewInit(bool isFirst)
    {
        TypeEventSystem.Register<GameFinishEvent>(OnGameFinishEvent);
        TypeEventSystem.Register<CollectTaskCardEvent>(OnCollectTaskCardEvent);
        TypeEventSystem.Register<PlayGameEntryAnim>(OnPlayGameEntryAnim);
        TypeEventSystem.Register<RookieTriggerEndEvent>(OnRookieTriggerEndEvent);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<GameFinishEvent>(OnGameFinishEvent);
        TypeEventSystem.UnRegister<CollectTaskCardEvent>(OnCollectTaskCardEvent);
        TypeEventSystem.UnRegister<PlayGameEntryAnim>(OnPlayGameEntryAnim);
        TypeEventSystem.UnRegister<RookieTriggerEndEvent>(OnRookieTriggerEndEvent);
    }

    private void OnRookieTriggerEndEvent(RookieTriggerEndEvent e)
    {
        if (configService.RookieConfig.TryGetValue(e.rookieId, out var cfg))
        {
            if (cfg.triggerParam != null && cfg.triggerParam.ContainsKey("rookie_complete"))
            {
                UniRx.Observable.Timer(TimeSpan.FromSeconds(0.1f)).Subscribe(_ =>
                {
                    BackMainScene();
                });
            }
        }
    }

    private void OnPlayGameEntryAnim(PlayGameEntryAnim e)
    {
        processObj.SetActive(true);
        var process = BattleDataMgr.Instance.GetTaskProcess();
        proText.text = $"{process.Item1} / {process.Item2}";
    }

    private void OnGameFinishEvent(GameFinishEvent e)
    {
        if (e.gameData.RemainDeskCardNum != 0)
            return;

        level++;
        dataService.SetRookieStatus(level);

        SoundPlayer.Instance.PlayXJLFei01();

        var newIcon = GameObject.Instantiate(iconImg.gameObject, iconImg.transform.parent);
        newIcon.transform.DOCurMove(xjlAnimator.transform.position, 0.5f).OnComplete(() =>
        {
            xjlAnimator.SetTrigger("NextAnim");
            GameObject.Destroy(newIcon.gameObject);
            processObj.SetActive(false);
            UniRx.Observable.Timer(TimeSpan.FromSeconds(2)).Subscribe((_) =>
            {
                if (level < helpBtns.Count)
                    helpBtns[level].gameObject.SetActive(true);

                if (level == 1)
                {
                    SoundPlayer.Instance.PlayXJLZan01();
                }
                else if (level == 2)
                {
                    SoundPlayer.Instance.PlayXJLZan02();
                }
                else if (level == 3)
                {
                    SoundPlayer.Instance.PlayXJLZan04();
                }

                if (level == 3)
                {
                    UniRx.Observable.Timer(TimeSpan.FromSeconds(1)).Subscribe((_) =>
                    {
                        dataService.SetRookieStatus(4);
                        TypeEventSystem.Send<RookieStoryOverEvent>();
                        xjlAnimator.transform.parent.DOScale(Vector3.one * 0.9f, 0.7f);
                        xjlAnimator.transform.parent.DOMove(new Vector3(-490, -38, 0), 0.7f).OnComplete(() =>
                        {
                            xjlAnimator.transform.parent.gameObject.SetActive(false);
                        });
                    });
                }
            });
        });
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.F2))
        {
            dataService.SetRookieStatus(4);
            BackMainScene();
        }
    }

    private void BackMainScene()
    {
        BoxBuilder.ShowSceneChangePop(() =>
        {
            MergeGameController.Instance.Show(true);
            GlobalRes.DynamicLoadView(Constants.DoozyView.Home, () =>
            {
                GameEventMessage.SendEvent(Constants.DoozyEvent.GoHome);
            });
        }, BoxBuilder.HideSceneChangePop);
    }

    private void OnCollectTaskCardEvent(CollectTaskCardEvent e)
    {
        var newIcon = GameObject.Instantiate(iconImg.gameObject, iconImg.transform.parent);
        newIcon.transform.position = e.pos;
        // newIcon.transform.DOScale(0.3f, 0.8f);
        newIcon.transform.DOCurMove(iconImg.transform.position, 0.8f).OnComplete(() =>
        {
            GameObject.Destroy(newIcon.gameObject);

            var process = BattleDataMgr.Instance.GetTaskProcess();
            proText.text = $"{process.Item1} / {process.Item2}";
        });
    }

    private void enterBattle(int lv)
    {
        SoundPlayer.Instance.PlayButton();
        string[] names = { "xsgk_4", "xsgk_6", "xsgk_5" };
        string key = Constants.AtlasNamePath.ViewRookieAtlas;
        iconImg.SetSpriteByAtlas(key, names[lv - 1], true);

        LevelUtils.LoadRookieLevel(lv, model =>
            {
                TypeEventSystem.Send(new StartGameEvent(0, model, 0, 0, null, null));
            });

        helpBtns[lv - 1].gameObject.SetActive(false);
        var canvas = transform.GetComponent<Canvas>();
        canvas.sortingLayerName = "default";
    }

    protected override void OnShow()
    {
    }

}