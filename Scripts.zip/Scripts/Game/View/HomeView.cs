using Activities;
using DG.Tweening;
using Doozy.Engine.UI;
using Model;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Coffee.UIExtensions;
using UniRx;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using Random = UnityEngine.Random;


public class HomeView : ViewBase
{
    [SerializeField] private GameObject endlessIcon;
    [SerializeField] private Text lvText;
    [SerializeField] private Text lvTitleText;
    [SerializeField] private GameObject buildCoinRoot;
    [SerializeField] private Text buildCoinText;
    [SerializeField] private GameObject infiniteImage;
    [SerializeField] private Button startBtn;
    [SerializeField] private Image startImage;
    [SerializeField] private Button wheelBtn;
    [SerializeField] private Button firstGiftBtn;
    [SerializeField] private Button heartBeatGiftBtn;
    [SerializeField] private ActivityTimeItem heartBeatGiftTimer;
    [SerializeField] private Button subscribeBtn;
    [SerializeField] private Button giftDragOneBtn;
    [SerializeField] private Button giftDragTwoBtn;
    [SerializeField] private Button giftDragSixBtn;
    [SerializeField] private Button giftPlusOneBtn;
    [SerializeField] private Button giftPlusFourBtn;
    [SerializeField] private Button giftDiscountBtn;
    [SerializeField] private Button lavaPassBtn;
    [SerializeField] private Button endlessBtn;
    [SerializeField] private Button rabbitGiftBtn;
    [SerializeField] private Button digBtn;
    [SerializeField] private Button seedBtn;
    [SerializeField] private Button cookBtn;
    [SerializeField] private Button waterBtn;
    [SerializeField] private Button honeyBtn;
    [SerializeField] private GameObject catalogueBtn;
    [SerializeField] private GridLayoutGroup _activityBtnParent;
    [SerializeField] private GridLayoutGroup _layoutGroup;
    private bool InitCollectText = false;
    private bool InitSeasonText = false;
    private bool InitPiggyText = false;
    private bool InitMusicText = false;

    private GameObject catalogueItem;
    private Text streakCountText;
    private GameObject passRankBtn;
    private GameObject carRankBtn;
    private GameObject collectFlowerBtn;
    private GameObject collectItemFx;
    private GameObject shopBtn;
    private GameObject limitPkBtn;
    private GameObject levelPassBtn;
    private GameObject adRewardBtn;
    private GameObject gradientGiftBtn;
    private GameObject giftGradientDigBtn;
    private GameObject giftGradientCookBtn;
    private GameObject piggyBtn;
    private GameObject collectLoveCardBtn;
    private GameObject collectMusicBtn;
    private Animator loveCardAnimator;
    private bool IsPlayingGetReward;
    private GameObject getBtn;
    private GameObject getBtnEf;
    private Image getBtnImage;
    public Button homeMapBtn;
    private GameObject levelBoxBtn;

    private Image collectLoveCardProgress;
    private Image collectMusicProgress;
    private Text wheelBtnText;

    private GameObject seasonPassBtn;
    private Vector3 OrignSeasonPos;
    private Vector3 OrignPiggyPos;
    private Image seasonPassImage;
    private Text seasonPassText;
    private GameObject ballonGift;

    private Button rankBtn;

    private Dictionary<ActivityType, ActivityTimeItem> activityTimeList = new();
    private Dictionary<ActivityType, Animator> animatorList = new();
    private Coroutine triggerGiftCoroutine;
    private GameObject farmingPrefab;
    private bool isLoadingFarming = false;
    private bool isLoadingCatalogueItem = false;
    private SpreadViewHandler spreadViewHandler;
    public GameObjectData levelBoxBtnData;
    public static HomeView Instace;
    // private List<string> preLoadResList = new List<string>();

    protected override void OnAwake()
    {
        Instace = this;
        spreadViewHandler = new SpreadViewHandler();
        spreadViewHandler.SetCallBack(OnSpreadViewComplete);
        spreadViewHandler.AddItem(transform.Get<Transform>("Dynamic/ActivityBtns"), SpreadViewHandler.Toward.Bottom);
        spreadViewHandler.AddItem(transform.Get<Transform>("Dynamic/AdRewardBtn"), SpreadViewHandler.Toward.Left);
        spreadViewHandler.AddItem(transform.Get<Transform>("Dynamic/WheelBtn"), SpreadViewHandler.Toward.Left);
        spreadViewHandler.AddItem(transform.Get<Transform>("Dynamic/CollectLoveCardBtn"), SpreadViewHandler.Toward.Up);
        spreadViewHandler.AddItem(transform.Get<Transform>("Dynamic/BuildCoin"), SpreadViewHandler.Toward.Up);

        spreadViewHandler.AddItem(transform.Get<Transform>("Static/GiftBtns"), SpreadViewHandler.Toward.Right);
        spreadViewHandler.AddItem(transform.Get<Transform>("Static/CatalogueBtn"), SpreadViewHandler.Toward.Up);
        spreadViewHandler.AddItem(transform.Get<Transform>("Static/BottomLayout"), SpreadViewHandler.Toward.Bottom);
        spreadViewHandler.AddItem(transform.Get<Transform>("Static/BottomLeftLayout"), SpreadViewHandler.Toward.Left);
        spreadViewHandler.AddItem(transform.Get<Transform>("Static/Button - StartGame"), SpreadViewHandler.Toward.Bottom);


        seasonPassBtn = transform.Get<Transform>("Static/GiftBtns/SeasonPassBtn").gameObject;
        seasonPassImage = transform.Get<Image>("Static/GiftBtns/SeasonPassBtn/Progress/Value");
        seasonPassText = transform.Get<Text>("Static/GiftBtns/SeasonPassBtn/Progress/Text");
        seasonPassBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("seasonPass", true)) return;
            BoxBuilder.ShowSeasonPassPopup();
        });
        passRankBtn = transform.Get<Transform>("Dynamic/ActivityBtns/PassRankBtn").gameObject;
        carRankBtn = transform.Get<Transform>("Dynamic/ActivityBtns/CarRankBtn").gameObject;
        shopBtn = transform.Get<Transform>("Static/BottomLayout/ShopBtn").gameObject;
        shopBtn.transform.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowShopPop();
        });

        homeMapBtn = transform.Get<Button>("Static/BottomLayout/HomeMapBtn");
        homeMapBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowIllustratedGuidePopup();
        });

        rankBtn = transform.Get<Button>("Static/BottomLayout/RankBtn");

        
        limitPkBtn = transform.Get<Transform>("Dynamic/ActivityBtns/LimitPkBtn").gameObject;
        levelPassBtn = transform.Get<Transform>("Dynamic/ActivityBtns/LevelPassBtn").gameObject;
        adRewardBtn = transform.Get<Transform>("Dynamic/AdRewardBtn").gameObject;
        collectFlowerBtn = transform.Get<Transform>("Dynamic/ActivityBtns/CollectFlowerBtn").gameObject;
        collectItemFx = transform.Find("btnFx").gameObject;

        levelBoxBtn = transform.Get<Transform>("Static/BottomLeftLayout/LevelBoxBtn").gameObject;
        levelBoxBtnData = new GameObjectData();
        levelBoxBtnData.InitViewObj(transform,levelBoxBtn.gameObject);

        collectLoveCardBtn = transform.Get<Transform>("Dynamic/CollectLoveCardBtn").gameObject;
        collectLoveCardProgress = transform.Get<Image>("Dynamic/CollectLoveCardBtn/Progress/Value");

        collectMusicBtn = transform.Get<Transform>("Dynamic/CollectMusicBtn").gameObject;
        collectMusicProgress = transform.Get<Image>("Dynamic/CollectMusicBtn/Progress/Value");

        piggyBtn = transform.Get<Transform>("Static/GiftBtns/PiggyBtn").gameObject;
        gradientGiftBtn = transform.Get<Transform>("Static/GiftBtns/GradientGiftBtn").gameObject;
        giftGradientCookBtn = transform.Get<Transform>("Static/GiftBtns/GiftGradientCookBtn").gameObject;
        giftGradientDigBtn = transform.Get<Transform>("Static/GiftBtns/GiftGradientDigBtn").gameObject;
        getBtn = transform.Get<Transform>("Dynamic/GetBtn").gameObject;
        getBtnImage = transform.Get<Image>("Dynamic/GetBtn/Icon");
        getBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            ActivityManager.Instance.FarmingActivity.GetHarvestCoin(() =>
            {
                getBtnEf.gameObject.SetActive(false);
                getBtn.GetComponent<DOTweenAnimation>().DORewind();
                ActivityManager.Instance.FarmingActivity.CheckChangeBg();
            });
        });

        wheelBtnText = transform.Get<Text>("Dynamic/WheelBtn/Text");

        GoldView.Instance.SetBuildCoin(buildCoinRoot.gameObject);

        activityTimeList = new Dictionary<ActivityType, ActivityTimeItem>
        {
            { ActivityType.collectLoveCard, transform.Get<ActivityTimeItem>("Dynamic/CollectLoveCardBtn/ActivityTimeItem") },
            { ActivityType.collectMusic, transform.Get<ActivityTimeItem>("Dynamic/CollectMusicBtn/ActivityTimeItem") },
            { ActivityType.passRank, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/PassRankBtn/ActivityTimeItem") },
            { ActivityType.carRank, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/CarRankBtn/ActivityTimeItem") },
            { ActivityType.collectFlower, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/CollectFlowerBtn/ActivityTimeItem") },
            { ActivityType.seasonPass, transform.Get<ActivityTimeItem>("Static/GiftBtns/SeasonPassBtn/ActivityTimeItem") },
            { ActivityType.farmingCollect, transform.Get<ActivityTimeItem>("Dynamic/GetBtn/ActivityTimeItem") },
            { ActivityType.piggy, transform.Get<ActivityTimeItem>("Static/GiftBtns/PiggyBtn/ActivityTimeItem") },
            { ActivityType.gradientGift, transform.Get<ActivityTimeItem>("Static/GiftBtns/GradientGiftBtn/ActivityTimeItem") },
            { ActivityType.giftGradientCook, transform.Get<ActivityTimeItem>("Static/GiftBtns/GiftGradientCookBtn/ActivityTimeItem") },
            { ActivityType.giftGradientDig, transform.Get<ActivityTimeItem>("Static/GiftBtns/GiftGradientDigBtn/ActivityTimeItem") },
            { ActivityType.limitPk, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/LimitPkBtn/ActivityTimeItem") },
            { ActivityType.levelPass, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/LevelPassBtn/ActivityTimeItem") },
            { ActivityType.lavaPass, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/LavaPassBtn/ActivityTimeItem") },
            { ActivityType.rabbitGift, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/RabbitGiftBtn/ActivityTimeItem") },
            { ActivityType.digTreasure, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/DigBtn/ActivityTimeItem") },
            { ActivityType.mysteriousSeed, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/SeedBtn/ActivityTimeItem") },
            { ActivityType.cookMeal, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/CookBtn/ActivityTimeItem") },
            { ActivityType.collectWater, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/WaterBtn/ActivityTimeItem") },
            { ActivityType.collectHoney, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/HoneyBtn/ActivityTimeItem") },
            { ActivityType.endlessLevel, transform.Get<ActivityTimeItem>("Dynamic/ActivityBtns/EndlessBtn/ActivityTimeItem") },
            { ActivityType.adReward, transform.Get<ActivityTimeItem>("Dynamic/AdRewardBtn/ActivityTimeItem") },
            { ActivityType.giftDragOne, transform.Get<ActivityTimeItem>("Static/GiftBtns/GiftDragOneBtn/ActivityTimeItem") },
            { ActivityType.giftDragTwo, transform.Get<ActivityTimeItem>("Static/GiftBtns/GiftDragTwoBtn/ActivityTimeItem") },
            { ActivityType.giftDragSix, transform.Get<ActivityTimeItem>("Static/GiftBtns/GiftDragSixBtn/ActivityTimeItem") },
            { ActivityType.giftPlusOne, transform.Get<ActivityTimeItem>("Static/GiftBtns/GiftPlusOneBtn/ActivityTimeItem") },
            { ActivityType.giftPlusFour, transform.Get<ActivityTimeItem>("Static/GiftBtns/GiftPlusFourBtn/ActivityTimeItem") },
            { ActivityType.giftDiscount, transform.Get<ActivityTimeItem>("Static/GiftBtns/GiftDiscountBtn/ActivityTimeItem") },
        };

        animatorList = new Dictionary<ActivityType, Animator>()
        {
            {ActivityType.passRank, transform.Get<Animator>("Dynamic/ActivityBtns/PassRankBtn/Icon")},
            {ActivityType.collectFlower, transform.Get<Animator>("Dynamic/ActivityBtns/CollectFlowerBtn/Icon")},
            {ActivityType.limitPk, transform.Get<Animator>("Dynamic/ActivityBtns/LimitPkBtn/Icon")},
            {ActivityType.levelPass, transform.Get<Animator>("Dynamic/ActivityBtns/LevelPassBtn/Icon")},
            {ActivityType.lavaPass, transform.Get<Animator>("Dynamic/ActivityBtns/LavaPassBtn/Icon")},
            {ActivityType.endlessLevel, transform.Get<Animator>("Dynamic/ActivityBtns/EndlessBtn/Icon")},
        };
    }

    private void OnFlyFarmingCollectText(CollectFarmingCoin obj)
    {
        if (obj.playBeforeAnim) PlayBeforeAnim();
        Transform flowAddTrans = GameObjManager.Instance.PopGameObject(GameObjType.FlowAddFarmingCollect).transform;
        flowAddTrans.gameObject.SetActive(true);
        flowAddTrans.SetParent(getBtn.transform, false);
        flowAddTrans.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
        flowAddTrans.position = getBtn.transform.position;
        string addStr = $"+{obj.count}";
        flowAddTrans.Get<Text>("Icon/AddNum").text = addStr;
        Observable.Timer(TimeSpan.FromSeconds(120 / 60)).Subscribe(_ =>
        {
            GameObjManager.Instance.PushGameObject(flowAddTrans.gameObject);
        });
    }

    private void PlayBeforeAnim()
    {
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        IConfigService configService = MainContainer.Container.Resolve<IConfigService>();
        bool playGoldEf = false;
        for (int i = 1; i <= dataService.FarmingProgress.lastMapId; i++)
        {
            int index = 1;
            float randomTIme = GameUtils.RandomRange(1.42f, 1.6f);
            index = i == dataService.FarmingProgress.lastMapId ? dataService.FarmingProgress.lastMaxThemeId : 4;
            for (int j = 1; j < index; j++)
            {
                FarmingModel model = configService.GetFarmingModel(i, j, 1);
                int count = GameUtils.RandomRange(model.collectCount, model.collectCount * 9);
                count = Mathf.Min(count, 24);
                for (int k = 0; k < count; k++)
                {
                    Transform starTrans = GameObjManager.Instance.PopGameObject(GameObjType.FlyFarmingItem).transform;
                    starTrans.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewFarmingAtlas, $"gs_{i}_{j}", true);
                    starTrans.SetParent(transform, false);
                    starTrans.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                    starTrans.localScale = Vector3.zero;
                    starTrans.localPosition =
                        new Vector3(GameUtils.RandomRange(-100, 100), GameUtils.RandomRange(-100, 100), 0) +
                        homeMapBtn.transform.position; //+ new Vector3(-1000,-200,0);
                    starTrans.gameObject.SetActive(true);
                    starTrans.DOScale(Vector3.one, GameUtils.RandomRange(0.2f, 1f));
                    Vector3 startPos = starTrans.position + new Vector3(GameUtils.RandomRange(-100, 100), GameUtils.RandomRange(-100, 100), 0);
                    Vector3 controlPos = startPos + new Vector3(800, 200, 0);
                    Vector3 endPos = UIView.GetViews(Doozy.Engine.UI.Base.NamesDatabase.GENERAL, Constants.DoozyView.Gold)[0]
                        .GetComponent<GoldView>().GetGoldPos() + new Vector3(GameUtils.RandomRange(-50f, 50f), 0, 0); //new Vector3(-500,200);
                    Vector3[] bezierArray = BezierUtils.GetBeizerList(startPos, controlPos, endPos, 10);
                    Sequence seq = DOTween.Sequence();
                    starTrans.DOPath(bezierArray, randomTIme, PathType.Linear).SetEase(Ease.InSine).OnComplete(
                        () =>
                        {
                            if (!playGoldEf)
                            {
                                playGoldEf = true;
                                GoldView.Instance.ShowGoldNumFx((int)PropEnum.Coin);
                            }
                            starTrans.gameObject.SetActive(false);
                            GameObjManager.Instance.PushGameObject(starTrans.gameObject);
                        }
                    );
                }
            }
        }
    }

    private void OnRefreshHeartBeatGift(RefreshHeartBeatGift obj)
    {
        if (dataService.CheckTimeFlag(FlagType.ShowHeartBeatGift))
        {
            CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>(true);
            timeData.Clear();
            timeData.endTime = TimeUtils.IntToDateTime(dataService.GetTimeFlagDic()[FlagType.ShowHeartBeatGift]);
            heartBeatGiftTimer.SetTimeData(timeData);
        }
    }

    private void Start()
    {
        // CheckVersionUpdata();
    }

    private void RefreshRedDotRemind()
    {
        Dictionary<int,Transform> _list = new Dictionary<int,Transform>()
        {
            {RedDotId.IllustratedGuide,homeMapBtn.transform},
            {RedDotId.CookGuide,cookBtn.transform},
            {RedDotId.FlowerGuide,collectFlowerBtn.transform},
            {RedDotId.LimitPkGuide,limitPkBtn.transform},
            {RedDotId.BoatGuide,levelPassBtn.transform},
            {RedDotId.LavaPassGuide,lavaPassBtn.transform},
            {RedDotId.GradientGiftGuide,gradientGiftBtn.transform},
            {RedDotId.GradientCookGuide,giftGradientCookBtn.transform},
            {RedDotId.GradientDigGuide,giftGradientDigBtn.transform},
            {RedDotId.SubscribeGuide,subscribeBtn.transform}
        };
        foreach (var pair  in _list)
        {
            RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(pair.Key);
            RedDotMgr.Instance.CreateRedDot(rootNode, pair.Value, new Vector2(35, 48));
        }
    }
    
    protected override void OnViewInit(bool isFirst)
    {
        CheckTriggerPopup();
        SoundPlayer.Instance.ChangeBgm();
        rankBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowLevelRankingPopup();
        });
        wheelBtn.SetButtonClick(() =>
        {
            if (!GameUtils.CheckFuncIsUnlock("luckyWheel", true)) return;
            int curIndex = dataService.WheelProgress.curIndex;
            if (curIndex >= configService.WheelOpenInterval.Length) curIndex = configService.WheelOpenInterval.Length - 1;
            BoxBuilder.ShowToast($"通关{configService.WheelOpenInterval[curIndex] - dataService.WheelProgress.curLevel}次,参与幸运轮盘活动");
        });
        firstGiftBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.FirstChargePopup,
                () => BoxBuilder.ShowFirstCharge(null));
        });
        heartBeatGiftBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.HeartBeatGift, BoxBuilder.ShowHeartBeatGift);
        });
        subscribeBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.SubscribeChargePopup, BoxBuilder.ShowSubscribeCharge);
        });
        giftPlusOneBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.GiftPlusOnePopup, BoxBuilder.ShowGiftPlusOnePopup);
        });
        giftPlusFourBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.GiftPlusFourPopup, BoxBuilder.ShowGiftPlusFourPopup);
        });
        giftDiscountBtn.SetButtonClick(() =>
        {
            if (!GameUtils.CheckFuncIsUnlock("giftDiscount", true)) return;
            SoundPlayer.Instance.PlayButton();
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.GiftDiscountPopup, BoxBuilder.ShowGiftDiscountPopup);
        });
        giftDragOneBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.GiftDragOnePopup, BoxBuilder.ShowGiftDragOnePopup);
        });
        giftDragTwoBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.GiftDragTwoPopup, BoxBuilder.ShowGiftDragTwoPopup);
        });
        giftDragSixBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.GiftDragSixPopup, BoxBuilder.ShowGiftDragSixPopup);
        });
        lavaPassBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("lavaPass", true)) return;
            BoxBuilder.ShowLava();
        });
        endlessBtn.SetButtonClick(() =>
        {
            if (!dataService.EndlessLevelProgress.UserActivative)
            {
                BoxBuilder.ShowStartEndlessLevelPopup();
            }
            else
            {
                BoxBuilder.ShowEndlessLevelRankPopup();
            }
        });
        rabbitGiftBtn.SetButtonClick(() =>
        {
            if (!GameUtils.CheckFuncIsUnlock("rabbitGift", true)) return;
            BoxBuilder.ShowRabbitGiftPopup();
        });
        digBtn.SetButtonClick(() =>
        {
            if (!GameUtils.CheckFuncIsUnlock("digTreasure", true)) return;
            BoxBuilder.ShowDigTreasurePopup();
        });
        seedBtn.SetButtonClick(() =>
        {
            if (!GameUtils.CheckFuncIsUnlock("mysteriousSeed", true)) return;
            BoxBuilder.ShowMysteriousSeedPopup();
        });
        cookBtn.SetButtonClick(() =>
        {
            if (!GameUtils.CheckFuncIsUnlock("cookMeal", true)) return;
            BoxBuilder.ShowCookMealPopup();
        });
        honeyBtn.SetButtonClick(() =>
        {
            if (!GameUtils.CheckFuncIsUnlock("collectHoney", true)) return;
            BoxBuilder.ShowCollectHoneyPopup();
        });
        waterBtn.SetButtonClick(() =>
        {
            if (!GameUtils.CheckFuncIsUnlock("collectWater", true)) return;
            BoxBuilder.ShowCollectWaterPopup();
        });
        passRankBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("passRank", true)) return;
            if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.passRank))
            {
                GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>().ShowText(
                    TextAnchor.LowerRight, passRankBtn.transform, Vector2.zero - new Vector2(0, 30), "活动未开启");
                return;
            }
            BoxBuilder.ShowPassRankPopup();
        });
        carRankBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("carRank", true)) return;
            if (!ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.carRank))
            {
                GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>().ShowText(
                    TextAnchor.LowerRight, carRankBtn.transform, Vector2.zero - new Vector2(0, 30), "活动未开启");
                return;
            }
            BoxBuilder.ShowCarRankPopup();
        });
        collectFlowerBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("collectFlower", true)) return;
            if (!dataService.CollectFlowerProgress.UserActivative)
            {
                BoxBuilder.ShowStartCollectFlowerPopup();
                return;
            }
            BoxBuilder.ShowCollectFlowerPopup();
        });
        limitPkBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("limitPk", true)) return;
            if (ActivityManager.Instance.GetActivityByType(ActivityType.limitPk).state == ActivityState.waitFinished)
            {
                BoxBuilder.ShowStartLimitPkPopup("result");
                return;
            }
            if (!dataService.LimitPkData.MatchFlag)
            {
                BoxBuilder.ShowStartLimitPkPopup("start");
            }
            else
            {
                BoxBuilder.ShowStartLimitPkPopup("matchSuccess");
            }
        });
        levelPassBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("levelPass", true)) return;
            if (!dataService.LevelPassProgress.UserActivative)
            {
                BoxBuilder.ShowStartLevelPassPopup();
            }
            else
            {
                BoxBuilder.ShowLevelPassPopup();
            }
        });
        adRewardBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowDailyAdRewardPopup();
        });
        collectLoveCardBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("collectLoveCard", true)) return;
            if (GameCommon.IsPlayingCollectAnim) return;
            BoxBuilder.ShowCollectLoveCardPopup();
        });
        collectMusicBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("collectMusic", true)) return;
            BoxBuilder.ShowCollectMusicPopup();
        });
        collectMusicBtn.Get<Button>("NextRewardItem/Box").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if (!GameUtils.CheckFuncIsUnlock("collectMusic", true)) return;
            Dictionary<int, int> rewards = ActivityManager.Instance.CollectMusicActivity.GetNextReward();
            GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                .ShowItem(TextAnchor.LowerCenter, collectMusicBtn.Get<Transform>("NextRewardItem/Box"), Vector2.zero, rewards);
        });
        piggyBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowSaverPopup();
        });
        gradientGiftBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowGradientGift();
        });
        giftGradientDigBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowGiftGradientDig();
        });
        giftGradientCookBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowGiftGradientCook();
        });

        levelBoxBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            int boxNum = dataService.GetUnPutLevelBoxNumber();
            if (boxNum == 0)
            {
                // BoxBuilder.ShowToast("前往挑战关卡获取宝箱吧~~");
                BoxBuilder.ShowBoxLessPopup();
            }
            else
            {
                var fromPos = levelBoxBtn.transform.position;
                if (!dataService.PutMergeLevelBox(fromPos))
                {
                    BoxBuilder.ShowToast("空间不足");
                }
            }
            UpdateLevelBoxRemind();
        });

        if (isFirst)
        {
            RefreshRedDotRemind();
            TypeEventSystem.Register<CheckAddCollectItem>(OnCheckAddCollectItem);
            TypeEventSystem.Register<RefreshUserInfoBuildCoin>(OnRefreshBuildCoin);
            TypeEventSystem.Register<UpdateWheelEvent>(OnRefreshWheelText);
            TypeEventSystem.Register<UpdateEmailInfoEvent>(OnRefreshEmailInfo);
            TypeEventSystem.Register<SendUpdateSeasonRemid>(UpdateSeasonRewardRemind);
            TypeEventSystem.Register<CollectFarmingCoin>(OnFlyFarmingCollectText);
            TypeEventSystem.Register<TriggrePopupEvent>(CheckTriggerPopup);
            TypeEventSystem.Register<RefreshHeartBeatGift>(OnRefreshHeartBeatGift);
            TypeEventSystem.Register<RefreshActivityTimer>(OnRefreshActivityTimer);
            TypeEventSystem.Register<RefreshEndlessLevel>(OnRefreshEndlessLevel);
            TypeEventSystem.Register<RefreshActivityRank>(OnRefreshActivityRank);
            TypeEventSystem.Register<HomeViewSeasonPassEvent>(OnHomeViewSeasonPassEvent);
            TypeEventSystem.Register<HomeViewPigEvent>(OnHomeViewPigEvent);
            TypeEventSystem.Register<PropChangeEvent>(OnPropChangeEvent);
            TypeEventSystem.Register<UpdateFarmingPanelEvent>(UpdateFarmingPanel);
            TypeEventSystem.Register<GlobalTimerRefreshEvent>(OnGlobalTimerRefreshEvent);
            TypeEventSystem.Register<PlayGetLoveCardReward>(OnPlayGetLoveCardReward);
            TypeEventSystem.Register<PlayGetMusicReward>(OnPlayGetMusicReward);
            TypeEventSystem.Register<TogglePopupEvent>(OnTogglePopup); 
        }
    }

    protected override void OnRefresh()
    {
        OnShow();
    }

    private void CheckBornBallon()
    {
        if (ballonGift != null && ballonGift.gameObject.activeSelf) return;
        if (ActivityManager.Instance.AdRewardActivity.CheckBallonShow())
        {
            if (ballonGift == null)
            {
                GlobalRes.DynamicLoadPrefab(Constants.ItemNamePath.BallonGift, (obj) =>
                {
                    ballonGift = obj;
                    ballonGift.transform.SetParent(transform.Find("Dynamic"), false);
                    ballonGift.GetComponent<BallonGiftItem>().StartFly();
                });
            }
            else
            {
                ballonGift.SetActive(true);
                ballonGift.GetComponent<BallonGiftItem>().StartFly();
            }
        }
        else
        {
            Destroy(ballonGift);
            ballonGift = null;
        }
    }

    //检测弹窗Popup
    void CheckTriggerPopup(TriggrePopupEvent obj = null)
    {
        if (GameCommon.IsAddingCollect || GameCommon.IsPlayingCollectAnim || !gameObject.activeSelf)
        {
            return;
        }
        StaticCoroutine.StopCoroutine(CheckPopup());
        StaticCoroutine.StartCoroutine(CheckPopup());
    }

    private IEnumerator CheckPopup()
    {
        yield return new WaitUntil(() =>
        {
            return GameCommon.VisiblePopupCount == 0 && !GameUtils.IsSpecialLevel() && GameUtils.IsInHomeView() && !GameCommon.IsExitGame;
        });

        if (dataService.OldDataVersionFlag && dataService.IsRookieShowed(20))
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.MergeVersionRewardPopup, () =>
            {
                BoxBuilder.ShowMergeVersionRewardPopup();
            });
        }
        
        ActivityManager.Instance.CheckDailyPopup();
        ActivityManager.Instance.CheckActivityPopup();
        OnRefreshActivityTimer(null);
    }

    void Test1()
    {
        PopupQueueManager.Instance.AddTweenTask(() =>
        {
            Sequence seq = DOTween.Sequence();

            seq.AppendCallback(() => GameUtils.LogError("111111111111111"));
            seq.AppendInterval(1f);
            seq.AppendCallback(() => GameUtils.LogError("2222222222222222"));
            seq.AppendInterval(1f);
            seq.AppendCallback(() => GameUtils.LogError("3333333333333333"));
            seq.AppendInterval(1f);
            seq.AppendCallback(() => GameUtils.LogError("44444444444444444"));
            return seq;
        },1);
        PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.CheckInPopup,BoxBuilder.ShowCheckIn);
        PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.FirstChargePopup,()=>BoxBuilder.ShowFirstCharge(null));
        PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.WheelPopup,BoxBuilder.ShowWheelPopup);
        // GameUtils.LogError(GoldView.Instance.EndPos());
        // GoldView.Instance.ThreePowerBeizerFlyCoin((int) PropEnum.Coin, 10, 50,Vector3.zero);
        // PopupQueueManager.Instance.AddToQueue(Constants.DoozyView.PopCollectRewardPopup, () =>
        // {
        //     BoxBuilder.ShowPopCollectRewardPopup(ActivityType.collectWater, new Dictionary<int, int>(){{1,1000}}, null, null);
        // }));
        dataService.AddProp((int)PropEnum.TimeItemWindmill,600,PropChangeWay.Shop);
        //GameUtils.PlayGoldAnim(transform,500,1000,startBtn.transform,null);
        // dataService.DigTreasureProgress.curLayer = 4;
        // dataService.DigTreasureProgress.OccupyGridList.Clear();
        // dataService.DigTreasureProgress.GetRewardList.Clear();
        // dataService.DigTreasureProgress.RewardGridDic.Clear();
        
        // Dictionary<int, int> rewards = new Dictionary<int, int>() {{1, 1000}, {2, 2000}, {3, 1000}};
        // Dictionary<int, int> reward1 = new Dictionary<int, int>() {{10030101, 1}, {10020101, 1}, {15, 10010101}};
        // dataService.RecordBubbleItem = reward1;
        // BoxBuilder.ShowRewardPop(rewards,PropChangeWay.Shop);
        
        //BoxBuilder.ShowVictoryPopup();
        // BoxBuilder.ShowPopRewardPopup(() =>
        // {
        //     Transform propItem = transform.Get<Transform>("Dynamic/TopLayout/CollectLoveCardBtn/NextRewardItem");
        //     propItem.gameObject.SetActive(false);
        // },null,SetCollectLoveCardReward,ActivityType.collectLoveCard,new PlayGetLoveCardReward(PropEnum.Coin,1000,true),startBtn.transform.position);

        //BoxBuilder.ShowWheelPopup();
        // ActivityManager.Instance.DigTreasureActivity.GMAddCount(500);
        //ActivityManager.Instance.FinishGetReward(ActivityType.mysteriousSeed);
        // GameUtils.LogError(ActivityManager.Instance.CollectMusicActivity.IsOpenActivity());
        // GameUtils.LogError(ActivityManager.Instance.CanShowActivityBtn(ActivityType.collectMusic),"------",!dataService.CollectMusicProgress.FinishGetReward);
        //BoxBuilder.ShowMysteriousSeedPopup();
        // ActivityManager.Instance.LavaPassActivity.GMAddWinCount(1);
        // BoxBuilder.ShowLavaPassPopup();
        // ActivityManager.Instance.EndlessLevelActivity.EnableActivity();
        // OnRefreshEndlessLevel(null);
        // BoxBuilder.ShowRabbitGiftPopup();
        //BoxBuilder.ShowStartLavaPassPopup();
        //BoxBuilder.ShowDigTreasurePopup();
    }

    void Test2()
    {
        GameUtils.LogError(dataService.GetPropNum((int)PropEnum.TimeItemWindmill) - ActivityManager.Instance.GetActivitySeverTime());
    }

    void Test3()
    {
    }

    void Test4()
    {
        BoxBuilder.HideVictoryPopup();
        Observable.Timer(TimeSpan.FromSeconds(0.4f)).Subscribe(_ =>
        {
            BoxBuilder.ShowVictoryPopup();
        });
    }
    protected override void OnShow()
    {
        BackdropMono.Instance.SwitchBackdrop();
        GameUtils.RequestEmailInfo("1");
        StopAllCoroutines();
        StartCoroutine(GameUtils.CheckKeys(Test1, Test2, Test3, Test4));
        ActivityManager.Instance.ClearPopFlag();
        BackdropMono.Instance.ChangeBackdropState(false);
        // GlobalRes.DynamicLoadView(Constants.DoozyView.Gold, () =>
        // {
        //     GoldView.Instance.ResetCanvasPos();
        //     // if (dataService.MaxLevel == 1)
        //     // {
        //     //     GoldView.Instance.ShowBuildCoinRoot(false);
        //     // }
        // });
        CheckBtnState();
        CheckPreUnlockBtn();
        CheckInterAd();
        //CheckBornBallon();
        OnRefreshWheelText(null);
        OnRefreshActivityRank(null);
        OnRefreshActivityTimer(null);
        OnRefreshHeartBeatGift(null);
        OnRefreshBuildCoin(null);
        SetStageHardShow();
        UpdateLevelBoxRemind();
        TypeEventSystem.Send<ShowHomeViewEvent>();
        var canvasGroup = GetComponent<CanvasGroup>();
        canvasGroup.blocksRaycasts = false;
    }

    private void RefreshActivityBtnLayOut()
    {
        int index = 0;
        for (int i = 0; i < _activityBtnParent.transform.childCount; i++)
        {
            if (_activityBtnParent.transform.GetChild(i).gameObject.activeSelf) index++;
            if(index > 4) break;
        }

        if (index > 4)
        {
            _activityBtnParent.transform.localScale = Vector3.one * 0.8f;
            _layoutGroup.constraintCount = 5;
        }
        else
        {
            _activityBtnParent.transform.localScale = Vector3.one;
            _layoutGroup.constraintCount = 4;
        }
    }

    private void OnRefreshBuildCoin(RefreshUserInfoBuildCoin obj)
    {
        buildCoinText.text = dataService.BuildCoin.ToString();
    }
    
    private void OnRefreshEndlessLevel(RefreshEndlessLevel obj)
    {
        var isOpenEndlessLevel = ActivityManager.Instance.EndlessLevelActivity.IsOpenActivity();
        lvText.text = $"{dataService.NowViewMaxLayer}";
        lvTitleText.text = isOpenEndlessLevel ? "回合" : "关卡";
        endlessIcon.SetActive(isOpenEndlessLevel);
        foreach (var uiShadow in lvText.GetComponents<UIShadow>())
        {
            uiShadow.effectColor = isOpenEndlessLevel ? new Color(0.07450981f, 0.03529412f, 0.03529412f) : new Color(0.1490196f, 0.4627451f, 0.05490196f);
        }
        foreach (var uiShadow in lvTitleText.GetComponents<UIShadow>())
        {
            uiShadow.effectColor = isOpenEndlessLevel ? new Color(0.07450981f, 0.03529412f, 0.03529412f) : new Color(0.1490196f, 0.4627451f, 0.05490196f);
        }


        if (isOpenEndlessLevel)
        {
            startImage.SetSpriteByAtlas(Constants.AtlasNamePath.ViewHomeAtlas, "syrk_endless_level", true);
            GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/endless_anniu_tx_01.prefab", (obj) =>
            {
                obj.transform.SetParent(startBtn.transform);
                obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                obj.transform.localScale = Vector3.one;
                obj.SetActive(true);
            }, true, 3f);
        }
        else
        {
            startImage.SetSpriteByAtlas(Constants.AtlasNamePath.ViewHomeAtlas, $"syrk_level_{GameUtils.GetLevelHard()}", true);
        }

    }

    private void OnRefreshEmailInfo(UpdateEmailInfoEvent obj = null)
    {
        catalogueBtn.transform.Find("Remind").gameObject.SetActive(false);
        if (dataService.EmailList is { Count: > 0 })
        {
            foreach (var model in dataService.EmailList)
            {
                if (model.read == 0 || model.receive == 0)
                {
                    catalogueBtn.transform.Find("Remind").gameObject.SetActive(true);
                    break;
                }
            }
        }
    }

    private void UpdateFarmingPanel(UpdateFarmingPanelEvent obj = null)
    {
        if (isLoadingFarming) return;
        dataService.FarmingProgress.InitInfo();
        if (farmingPrefab == null)
        {
            isLoadingFarming = true;
            GlobalRes.DynamicLoadPrefab(Constants.ItemNamePath.FarmingPrefab, (obj) =>
            {
                isLoadingFarming = false;
                farmingPrefab = obj;
                farmingPrefab.transform.SetParent(transform.Find("Dynamic"));
                farmingPrefab.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                farmingPrefab.transform.localScale = Vector3.one;
                farmingPrefab.SetActive(true);
                farmingPrefab.GetComponent<FarmingPrefab>().UpdatePanel();
            });
        }
        else
        {
            farmingPrefab.SetActive(true);
            farmingPrefab.GetComponent<FarmingPrefab>().UpdatePanel();
        }

        bool canGetReward = ActivityManager.Instance.FarmingActivity.CanGetReward();
        getBtnImage.GetComponent<UIEffect>().colorFactor = !canGetReward ? 1 : 0;
        if (canGetReward)
        {
            if (getBtnEf == null)
            {
                GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/tx_farming_01.prefab", (obj) =>
                {
                    getBtnEf = obj;
                    obj.gameObject.SetActive(true);
                    obj.transform.SetParent(getBtn.transform);
                    obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                });
            }
            else
            {
                getBtnEf.gameObject.SetActive(true);
            }
        }
        else
        {
            if (getBtnEf != null)
            {
                getBtnEf.gameObject.SetActive(false);
            }
        }
        if (canGetReward) getBtn.GetComponent<DOTweenAnimation>().DOPlay();
        transform.Get<ActivityTimeItem>("Dynamic/GetBtn/ActivityTimeItem").gameObject.SetActive(!canGetReward);
        if (canGetReward)
        {
            getBtn.GetComponent<DOTweenAnimation>().DORestart();
        }
    }

    void CheckBtnState()
    {
        if (GameCommon.IsAddingCollect || GameCommon.IsPlayingCollectAnim) return;

        seasonPassBtn.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.seasonPass));
        piggyBtn.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.piggy) && !dataService.PiggyData.FinishGetReward && !dataService.PiggyData.PopBtn);
        gradientGiftBtn.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.gradientGift) && !dataService.GradientGiftProgress.FinishGetReward);
        giftGradientCookBtn.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.giftGradientCook) && !dataService.GiftGradientCookProgress.FinishGetReward);
        giftGradientDigBtn.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.giftGradientDig) && !dataService.GiftGradientDigProgress.FinishGetReward);
        giftPlusOneBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.giftPlusOne) && !dataService.GiftPlusOneData.FinishGetReward);
        giftPlusFourBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.giftPlusFour) && !dataService.GiftPlusFourData.FinishGetReward);
        giftDiscountBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.giftDiscount) && !dataService.GiftDiscountData.FinishGetReward);


        giftDragOneBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.giftDragOne) && !dataService.GiftDragOneData.FinishGetReward);
        giftDragTwoBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.giftDragTwo) && !dataService.GiftDragTwoData.FinishGetReward);
        giftDragSixBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && ActivityManager.Instance.CanShowActivityBtn(ActivityType.giftDragSix) && !dataService.GiftDragSixData.FinishGetReward);

        seedBtn.gameObject.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.mysteriousSeed) && !dataService.MysteriousSeedProgress.FinishGetReward);
        cookBtn.gameObject.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.cookMeal) && !dataService.CookMealProgress.FinishGetReward);
        waterBtn.gameObject.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.collectWater) && !dataService.CollectWaterProgress.FinishGetReward);
        honeyBtn.gameObject.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.collectHoney) && !dataService.CollectHoneyProgress.FinishGetReward);
        digBtn.gameObject.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.digTreasure) && !dataService.DigTreasureProgress.FinishGetReward);


        collectFlowerBtn.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.collectFlower));
        limitPkBtn.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.limitPk));
        levelPassBtn.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.levelPass));
        lavaPassBtn.gameObject.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.lavaPass));
        endlessBtn.gameObject.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.endlessLevel));
        rabbitGiftBtn.gameObject.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.rabbitGift));
        adRewardBtn.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.adReward) && !dataService.AdRewardProgress.FinishGetReward);
        collectLoveCardBtn.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.collectLoveCard) && !dataService.CollectLoveCardProgress.FinishGetReward);
        collectMusicBtn.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.collectMusic) && !dataService.CollectMusicProgress.FinishGetReward);
        passRankBtn.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.passRank));
        carRankBtn.MSetActive(ActivityManager.Instance.CanShowActivityBtn(ActivityType.carRank));
        firstGiftBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && GameUtils.CheckCanShowFirstCharge());
        heartBeatGiftBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && !dataService.IsBuyHeartBeatGift && dataService.CheckTimeFlag(FlagType.ShowHeartBeatGift));
        subscribeBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && GameUtils.CheckFuncIsUnlock("subscribe"));
        subscribeBtn.gameObject.ShowRemind(GameUtils.CamGetSubscribeReward());
        shopBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && GameUtils.CheckFuncIsUnlock("shop"));
        rankBtn.gameObject.MSetActive(GameUtils.CheckFuncIsUnlock("rank"));
        wheelBtn.gameObject.MSetActive(!GameCommon.IsShieldPurchase && GameUtils.CheckFuncIsUnlock("luckyWheel"));
        levelBoxBtn.gameObject.MSetActive(GameUtils.CheckFuncIsUnlock("passbox"));
        homeMapBtn.gameObject.MSetActive(GameUtils.CheckFuncIsUnlock("book"));
        catalogueBtn.gameObject.MSetActive(GameUtils.CheckFuncIsUnlock("setting"));
        buildCoinRoot.gameObject.MSetActive(GameUtils.CheckFuncIsUnlock("topResource"));

        RefreshActivityBtnLayOut();
    }

    void CheckPreUnlockBtn()
    {
        if(!dataService.IsHasFirstNpc()) return;
        foreach (var model in configService.UnlockConfig)
        {
            if (model.Value.previewLevel != 0)
            {
                GameObject btn = null;
                bool inRange = model.Value.previewLevel <= dataService.MaxLevel && dataService.MaxLevel < model.Value.unlockLevel;
                if (Enum.TryParse(model.Value.type, out ActivityType activityType))
                {
                    activityTimeList.TryGetValue(activityType, out ActivityTimeItem timeItem);
                    ActivitiesSwitchModel switchModel = ActivityManager.Instance.GetActivitySwitchModel(activityType);
                    if (!switchModel.inOpenTime)
                    {
                        inRange = false;
                    }
                    if (timeItem != null) btn = timeItem.transform.parent.gameObject;
                    if (btn != null)
                    {
                        RefreshBtnAnim(activityType, !inRange);
                    }
                }
                if (model.Value.type == "luckyWheel")
                {
                    btn = wheelBtn.gameObject;
                }
                GameUtils.SetPreUnlock(inRange, btn?.gameObject);
            }
        }
    }

    //刷新计时器
    void OnRefreshActivityTimer(RefreshActivityTimer obj)
    {
        void SetTime(ActivityType activityType)
        {
            CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>(true);
            timeData.Clear();

            if (activityType == ActivityType.farmingCollect)
            {
                if (dataService.FarmingProgress.collectTimer != -1)
                {
                    timeData.endTime = TimeUtils.IntToDateTime(dataService.FarmingProgress.collectTimer);
                }
            }
            else
            {
                ActivityDataModel model = ActivityManager.Instance.GetActivityByType(activityType);
                if (model == null)
                {
                    timeData.endText = "结束";
                }
                else
                {
                    timeData.endText = model.state is ActivityState.finished ? "结束" : model.state is ActivityState.waitFinished ? "结束" : null;
                    if (model.state is ActivityState.waitEntry)
                    {
                        timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(activityType).ActivityBigEndTime);
                    }
                    BaseActivityData data = model.localData as BaseActivityData;
                    if (model.state is ActivityState.underWay)
                    {
                        timeData.endTime = TimeUtils.IntToDateTime(data.ActivityEndTime);
                    }

                    if (activityType == ActivityType.collectLoveCard)
                    {
                        if (model.state is ActivityState.finished)
                        {
                            InitCollectText = false;
                        }
                    }
                    else if (activityType == ActivityType.collectMusic)
                    {
                        if (model.state is ActivityState.finished)
                        {
                            InitMusicText = false;
                        }
                    }
                    else if (activityType == ActivityType.seasonPass)
                    {
                        if (model.state is ActivityState.finished)
                        {
                            InitSeasonText = false;
                        }
                    }
                    else if (activityType == ActivityType.piggy)
                    {
                        if (model.state is ActivityState.underWay)
                        {
                            InitPiggyText = false;
                        }
                    }
                    else if (activityType == ActivityType.lavaPass)
                    {
                        if (model.state is ActivityState.finished)
                        {
                            timeData.endTime = TimeUtils.IntToDateTime(dataService.LavaPassProgress.ActivityEndTime + ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).OpenInterval);
                        }
                    }
                    if (model.state is ActivityState.finished || model.state is ActivityState.waitFinished)
                    {
                        RefreshBtnBg(true, activityType);
                    }
                    else
                    {
                        RefreshBtnBg(false, activityType);
                    }
                    //RefreshBtnAnim(activityType, dataService.MaxLevel >= model.unlockStage);
                }
            }

            if (activityTimeList.TryGetValue(activityType, out ActivityTimeItem item))
            {
                item.SetTimeData(timeData);
            }
        }

        if (obj == null)
        {
            foreach (var item in activityTimeList)
            {
                SetTime(item.Key);
            }
        }
        else
        {
            SetTime(obj.activityType);
        }
        OnRefreshActivityRank(null);
    }

    private void RefreshBtnBg(bool change, ActivityType activityType)
    {
        Dictionary<ActivityType, Tuple<string, string>> dic = new Dictionary<ActivityType, Tuple<string, string>>()
        {
            {ActivityType.seasonPass,new Tuple<string, string>("syrk_1", "syrk_1_2") },
            {ActivityType.passRank,new Tuple<string, string>("syrk_1", "syrk_1_2") },
            {ActivityType.collectFlower,new Tuple<string, string>("syrk_5", "syrk_5_2") },
            {ActivityType.limitPk,new Tuple<string, string>("syrk_3", "syrk_3_2") },
            {ActivityType.levelPass,new Tuple<string, string>("syrk_3", "syrk_3_2") },
            {ActivityType.lavaPass,new Tuple<string, string>("syrk_2", "syrk_2_2") },
            {ActivityType.endlessLevel,new Tuple<string, string>("syrk_2", "syrk_2_2") },
        };

        if (dic.TryGetValue(activityType, out Tuple<string, string> list))
        {
            bool has = false;
            Image btn = null;
            Image bar = null;
            foreach (var pair in activityTimeList)
            {
                if (activityType == pair.Key)
                {
                    if (pair.Value.transform.Find("Bg"))
                    {
                        bar = pair.Value.transform.Find("Bg").GetComponent<Image>();
                        btn = pair.Value.transform.parent.GetComponent<Image>();
                        has = true;
                    }
                    break;
                }
            }
            if (has)
            {
                string value1 = !change ? list.Item1 : "syrk_6";
                string value2 = !change ? list.Item2 : "syrk_6_2";
                btn.SetSpriteByAtlas(Constants.AtlasNamePath.ViewHomeAtlas, value1);
                bar.SetSpriteByAtlas(Constants.AtlasNamePath.ViewHomeAtlas, value2);
            }
        }
    }

    private void RefreshBtnAnim(ActivityType activityType, bool enable)
    {
        if (animatorList.TryGetValue(activityType, out Animator anim))
        {
            // if (state is ActivityState.underWay)
            // {
            //     anim.SetBool("ShowFinishEf",true);
            // }
            // else
            // {
            //     anim.SetBool("ShowFinishEf",false);
            // }
            if (anim != null)
            {
                anim.SetBool("ShowFinishEf", enable);
            }
        }
    }

    private void OnPropChangeEvent(PropChangeEvent obj)
    {
        //SetStageHardShow();
    }

    private void SetStageHardShow()
    {
        var isOpenEndlessLevel = ActivityManager.Instance.EndlessLevelActivity.IsOpenActivity();
        lvText.text = $"{dataService.NowViewMaxLayer}";
        lvTitleText.text = isOpenEndlessLevel ? "回合" : "关卡";
        startImage.SetSpriteByAtlas(Constants.AtlasNamePath.ViewHomeAtlas, isOpenEndlessLevel ? "syrk_endless_level" : $"syrk_level_{GameUtils.GetLevelHard()}", true);
        endlessIcon.SetActive(isOpenEndlessLevel);
        foreach (var uiShadow in lvText.GetComponents<UIShadow>())
        {
            uiShadow.effectColor = isOpenEndlessLevel ? new Color(0.07450981f, 0.03529412f, 0.03529412f) : new Color(0.1490196f, 0.4627451f, 0.05490196f);
        }
        foreach (var uiShadow in lvTitleText.GetComponents<UIShadow>())
        {
            uiShadow.effectColor = isOpenEndlessLevel ? new Color(0.07450981f, 0.03529412f, 0.03529412f) : new Color(0.1490196f, 0.4627451f, 0.05490196f);
        }
    }

    private void CheckInterAd()
    {
        var hasShowWheel = false;
        if (hasShowWheel)
        {

        }

        if (!hasShowWheel && dataService.InterAdInterval >= configService.GetInterAdInterval())
        {
            AdPlayer.ShowInterAd(AdPlayer.InsetAd, (place_id) => { dataService.InterAdInterval = 0; });
        }
    }

    private void OnRefreshActivityRank(RefreshActivityRank obj)
    {
        bool isDuring;
        if (dataService.CollectFlowerProgress != null)
        {
            isDuring = dataService.CollectFlowerProgress.ActivityBeginTime > 0;
            collectFlowerBtn.transform.Find("Icon/Text").GetComponent<Text>().text = isDuring ? $"{dataService.CollectFlowerProgress.GetMyData().curRank + 1}" : "";
        }
        if (dataService.LevelPassProgress != null)
        {
            isDuring = dataService.LevelPassProgress.ActivityBeginTime > 0;
            levelPassBtn.transform.Find("Text").GetComponent<Text>().text = isDuring ? $"{dataService.LevelPassProgress.GetMyData().curRank + 1}" : "";
        }
        if (dataService.LimitPkData != null)
        {
            isDuring = dataService.LimitPkData.ActivityBeginTime > 0;
            limitPkBtn.transform.Find("Text").GetComponent<Text>().text = isDuring ? $"{dataService.LimitPkData.GetMyRank()}" : "";
        }
        if (dataService.PassRankProgress != null)
        {
            isDuring = dataService.PassRankProgress.ActivityBeginTime > 0;
            passRankBtn.transform.Find("Icon/Text").GetComponent<Text>().text = isDuring ? $"{dataService.PassRankProgress.GetMyData().rank + 1}" : "";
        }
        if (dataService.PassRankProgress != null)
        {
            isDuring = dataService.PassRankProgress.ActivityBeginTime > 0;
            passRankBtn.transform.Find("Icon/Text").GetComponent<Text>().text = isDuring ? $"{dataService.PassRankProgress.GetMyData().rank + 1}" : "";
        }
        if (dataService.EndlessLevelProgress != null)
        {
            isDuring = dataService.EndlessLevelProgress.ActivityBeginTime > 0;
            endlessBtn.transform.Find("Text").GetComponent<Text>().text = isDuring ? $"{dataService.EndlessLevelProgress.GetMyData().curRank + 1}" : "";
        }
    }

    private void CheckSeasonPass()
    {
        if (InitSeasonText) return;
        if (ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.seasonPass))
        {
            int nextCount = ActivityManager.Instance.SeasonPassActivity.GetNextLayerCollectCount();
            int curCount = ActivityManager.Instance.SeasonPassActivity.GetCurLayerCollectCount();
            transform.Get<Text>("Static/GiftBtns/SeasonPassBtn/Progress/Text").DOText($"{curCount}", 0.4f, true, ScrambleMode.Numerals);
            transform.Get<Text>("Static/GiftBtns/SeasonPassBtn/Progress/Text/Total").text = $"{nextCount}";
            UpdateSeasonRewardRemind();
            float value = ActivityManager.Instance.SeasonPassActivity.GetRatio();
            if (dataService.SeasonPassProgress.curLayer == 0)
            {
                value = 1;
            }
            seasonPassImage.fillAmount = value;
            InitSeasonText = true;
        }
    }

    private void CheckPiggy()
    {
        if (InitPiggyText) return;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.piggy).state == ActivityState.underWay)
        {
            bool isFull = dataService.PiggyData.piggyCoin >= configService.SaverBankMax;
            //saverFullGo.gameObject.SetActive(isFull);
            InitPiggyText = true;
        }
    }

    private void CheckCollectLoveCard()
    {
        if (InitCollectText) return;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).state == ActivityState.underWay)
        {
            int nextCount = ActivityManager.Instance.CollectLoveCardActivity.GetNextLayerCollectCount();
            int curCount = ActivityManager.Instance.CollectLoveCardActivity.GetCurLayerCollectCount();
            transform.Get<Text>("Dynamic/CollectLoveCardBtn/Progress/Text").text = $"{curCount}";
            transform.Get<Text>("Dynamic/CollectLoveCardBtn/Progress/Text/Total").text = $"{nextCount}";
            string key = dataService.CollectLoveCardProgress.SubActivityType == 1 ? "axfk_11" : "axfk_12";
            transform.Get<Image>("Dynamic/CollectLoveCardBtn/LastRewardItem/Icon").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectLoveCardAtlas, key, true);

            collectLoveCardProgress.fillAmount = ActivityManager.Instance.CollectLoveCardActivity.GetRatio();
            InitCollectText = true;
            SetCollectLoveCardReward();
        }
    }

    private void CheckCollectMusic()
    {
        if (InitMusicText) return;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectMusic).state == ActivityState.underWay)
        {
            int nextCount = ActivityManager.Instance.CollectMusicActivity.GetNextLayerCollectCount();
            int curCount = ActivityManager.Instance.CollectMusicActivity.GetCurLayerCollectCount();
            transform.Get<Text>("Dynamic/CollectMusicBtn/Progress/Text").text = $"{curCount}";
            transform.Get<Text>("Dynamic/CollectMusicBtn/Progress/Text/Total").text = $"{nextCount}";

            collectMusicProgress.fillAmount = ActivityManager.Instance.CollectMusicActivity.GetRatio();
            InitMusicText = true;
            SetCollectMusicReward();
        }
    }

    private void SetCollectLoveCardReward()
    {
        Transform propItem = transform.Get<Transform>("Dynamic/CollectLoveCardBtn/NextRewardItem");
        if (ActivityManager.Instance.CollectLoveCardActivity.CurIsMaxLayer())
        {
            propItem.gameObject.SetActive(false);
            return;
        }
        propItem.gameObject.SetActive(true);
        foreach (var tempItem in ActivityManager.Instance.CollectLoveCardActivity.GetNextReward())
        {
            int propEnum = int.Parse(tempItem.type.ToString());
            int propCount = tempItem.amount;
            Image propImage = propItem.transform.Get<Image>("PropImage");
            Text timeText = propItem.transform.Get<Text>("TimeText");
            Text numText = propItem.transform.Get<Text>("NumText");
            numText.text = "";
            timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward((int)propEnum));
            if (GameUtils.IsLimitTimeReward((int)propEnum))
            {
                long infiniteTime = propCount;
                timeText.text = infiniteTime / 60 + "m";
            }
            else
            {
                numText.text = propEnum == (int)PropEnum.Coin ? propCount.ToString() : $"x{propCount}";
            }
            propImage.LoadPropSprite(propEnum == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : (int)propEnum);
            break;
        }
    }

    private void SetCollectMusicReward()
    {
        Transform propItem = transform.Get<Transform>("Dynamic/CollectMusicBtn/NextRewardItem");
        if (ActivityManager.Instance.CollectMusicActivity.CurIsMaxLayer())
        {
            propItem.gameObject.SetActive(false);
            return;
        }

        propItem.gameObject.SetActive(true);
        Dictionary<int, int> rewardList = ActivityManager.Instance.CollectMusicActivity.GetNextReward();
        var box = propItem.transform.Get<Transform>("Box");
        var item = propItem.transform.Get<Transform>("Item");
        box.gameObject.SetActive(rewardList.Count > 1);
        item.gameObject.SetActive(rewardList.Count == 1);
        if (rewardList.Count == 1)
        {
            foreach (var pair in rewardList)
            {
                Image propImage = item.transform.Get<Image>("PropImage");
                Text timeText = item.transform.Get<Text>("TimeText");
                Text numText = item.transform.Get<Text>("NumText");
                numText.text = "";
                timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward((int)pair.Key));
                if (GameUtils.IsLimitTimeReward((int)pair.Key))
                {
                    long infiniteTime = pair.Value;
                    timeText.text = infiniteTime / 60 + "m";
                }
                else
                {
                    numText.text = pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
                }

                propImage.LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : (int)pair.Key);
                break;
            }
        }
    }

    //添加收集物品动画
    private void OnCheckAddCollectItem(CheckAddCollectItem obj)
    {
        if(GameUtils.IsSpecialLevel()) return;
        FxMaskView.Instance.BlockOperation(true);
        GameCommon.IsAddingCollect = true;
        Sequence rootSeq = DOTween.Sequence();
        foreach (var pair in dataService.GetResultProp())
        {
            if (pair.Key == (int) PropEnum.Coin)
            {
                rootSeq.Join(GameUtils.PlayGoldAnim(transform, (int) (dataService.Coin - pair.Value), (int) dataService.Coin,
                    transform.Get<Transform>("Static/StartFlyTrans"), null));
            }
            else if (pair.Key == (int) PropEnum.BuildCoin)
            {
                rootSeq.Join(GoldView.Instance.ThreePowerBeizerFlyCoin((int) PropEnum.BuildCoin, dataService.BuildCoin - pair.Value,
                    dataService.BuildCoin, startBtn.transform));
            }
            else if (pair.Key == (int) PropEnum.PiggyCoin)
            {
                if (ActivityManager.Instance.CheckActivityIsUnderWay(ActivityType.piggy) &&
                    !dataService.PiggyData.FinishGetReward)
                {
                    if (dataService.PiggyData.piggyCoin - pair.Value < configService.SaverBankMax)
                    {
                        rootSeq.Join(AddSaverGoldAnim(dataService.PiggyData.piggyCoin, GameUtils.RandomRange(5, 10)));
                    }
                }
            }
            else
            {
                rootSeq.Join(FlyAdItemEffect((int) pair.Key, (int) pair.Value));
            }
        }
        
        // if (addCount > 0)
        // {
        //     ActivityManager.Instance.CollectLoveCardActivity.CheckGetReward();
        //     time = Mathf.Max(time, FlyCollectItemEffect(ActivityType.collectLoveCard, addCount));
        //     Observable.Timer(TimeSpan.FromSeconds(2f * 1 / 0.75f)).Subscribe(_ => PlayCollectFillAnim(ActivityType.collectLoveCard));
        // }
        // addCount = ActivityManager.Instance.CollectMusicActivity.GetAddCount();
        // if (addCount > 0)
        // {
        //     ActivityManager.Instance.CollectMusicActivity.CheckGetReward();
        //     time = Mathf.Max(time, FlyCollectItemEffect(ActivityType.collectMusic, addCount));
        //     Observable.Timer(TimeSpan.FromSeconds(2f * 1 / 0.75f)).Subscribe(_ => PlayCollectFillAnim(ActivityType.collectMusic));
        // }
        // addCount = ActivityManager.Instance.SeasonPassActivity.GetAddCount();
        // if (addCount > 0)
        // {
        //     time = Mathf.Max(time, FlyCollectItemEffect(ActivityType.seasonPass, addCount));
        //     Observable.Timer(TimeSpan.FromSeconds(2f * 1 / 0.75f)).Subscribe(_ => PlaySeasonFillAnim());
        // }
        
        Dictionary<ActivityType, int> dic = new Dictionary<ActivityType, int>()
        {
            {ActivityType.limitPk,ActivityManager.Instance.LimitPkActivity.GetAddCount()},
            {ActivityType.endlessLevel,ActivityManager.Instance.EndlessLevelActivity.GetAddCount()},
            {ActivityType.cookMeal,ActivityManager.Instance.CookMealActivity.GetAddCount()},
            {ActivityType.digTreasure,ActivityManager.Instance.DigTreasureActivity.GetAddCount()},
            {ActivityType.passRank,ActivityManager.Instance.PassRankActivity.GetAddCount()},
            {ActivityType.carRank,ActivityManager.Instance.CarRankActivity.GetAddCount()},
            {ActivityType.collectFlower,ActivityManager.Instance.CollectFlowerActivity.GetAddCount()},
            {ActivityType.collectLoveCard,ActivityManager.Instance.CollectLoveCardActivity.GetAddCount()},
            {ActivityType.collectMusic,ActivityManager.Instance.CollectMusicActivity.GetAddCount()},
            {ActivityType.seasonPass,ActivityManager.Instance.SeasonPassActivity.GetAddCount()},
        };
        foreach (var pair in dic)
        {
            if (pair.Value > 0 && ActivityManager.Instance.CheckActivityIsUnderWay(pair.Key))
            {
                Tween tween = FlyCollectItemEffect(pair.Key, pair.Value);
                if (pair.Key == ActivityType.collectLoveCard)
                {
                    ActivityManager.Instance.CollectLoveCardActivity.CheckGetReward();
                    tween.OnComplete(() =>
                    {
                        PlayCollectFillAnim(ActivityType.collectLoveCard);
                    });
                }
                if (pair.Key == ActivityType.collectMusic)
                {
                    ActivityManager.Instance.CollectMusicActivity.CheckGetReward();
                    tween.OnComplete(() =>
                    {
                        PlayCollectFillAnim(ActivityType.collectMusic);
                    });
                }
                if (pair.Key == ActivityType.collectMusic)
                {
                    tween.OnComplete(() =>
                    {
                        PlaySeasonFillAnim();
                    });
                }

                if (tween != null) rootSeq.Join(tween);
            }
        }
        rootSeq.JoinCallback(() =>
        {
            GameCommon.IsAddingCollect = false;
            CheckTriggerPopup();
            ActivityManager.Instance.ClearResultAddCount();
            dataService.ClearResultProp();
            FxMaskView.Instance.BlockOperation(false);
            dataService.SaveData(true);
        });
        GameUtils.LogError("时间++",rootSeq.Duration());
        if (rootSeq.Duration() != 0)
        {
            PopupQueueManager.Instance.AddTweenTask(() => rootSeq,0);
        }
    }

    //每秒刷新一次
    private void OnGlobalTimerRefreshEvent(GlobalTimerRefreshEvent obj)
    {
        if (!gameObject.activeInHierarchy) return;
        CheckBtnState();
        CheckPreUnlockBtn();
        RefreshActTimer();
    }

    void CheckVersionUpdata()
    {
        if (FirebaseUtils.Instance.FirebaseGetAppVersion() != null &&
            configService.UpdateTipsOpenLv <= dataService.MaxLevel)
        {
            if (DeviceUtils.VersionNameToNum(FirebaseUtils.Instance.FirebaseGetAppVersion()) >
                DeviceUtils.GetVersionNum())
            {
                //BoxBuilder.ShowUpdateTipPopup();
            }
        }
    }

    private void RefreshActTimer()
    {
        CheckCollectLoveCard();
        CheckCollectMusic();
        CheckSeasonPass();
        CheckPiggy();
    }

    #region 存钱罐相关
    private Tween AddSaverGoldAnim(int newCoin, int coinCount)
    {
        // var seq = DOTween.Sequence();
        // Vector3 startPos = startBtn.transform.position;
        // Vector3 endPos = piggyBtn.transform.position;
        // Vector3 controlPos = startPos + new Vector3(-300, 300);
        // controlPos.z = 0;
        // BeizerFlyAnimParam animParam = new BeizerFlyAnimParam(coinCount, startPos,
        //     new Vector3[] { controlPos }, endPos - new Vector3(20, 0, 0), 1f);
        // animParam.scale = 0.7f;
        // animParam.startScale = 0.7f;
        // animParam.endScale = 0.5f;
        // animParam.moveEase = Ease.InQuad;
        // animParam.intervalTime = 0.03f;
        // animParam.firstArriveCall = () =>
        // {
        //     // if (newCoin >= configService.SaverBankMax) saverFullAnimGo.Play("Full_AddCoin", 0, 0);
        // };
        // animParam.endCall = CheckPiggy;
        // return GameUtils.BeizerFlyCoin(animParam);
        return null;
    }

    private void OnHomeViewPigEvent(HomeViewPigEvent e)
    {
        // var canvas = piggyBtn.gameObject.GetComponent<Canvas>();
        // var canvasGroup = piggyBtn.GetComponent<CanvasGroup>();
        // if (e.top)
        // {
        //     canvasGroup.alpha = 0;
        //     canvasGroup.blocksRaycasts = false;
        //     piggyBtn.SetActive(true);
        //     Observable.NextFrame().Subscribe(_ =>
        //     {
        //         canvas.enabled = false;
        //         canvas.sortingOrder = 200;
        //         canvasGroup.alpha = 1;
        //         piggyBtn.transform.localScale = Vector3.zero;
        //         OrignPiggyPos = piggyBtn.transform.position;
        //         OrignPiggyPos.z = 0;
        //         Observable.Timer(TimeSpan.FromSeconds(0.04f)).Subscribe(_ =>
        //         {
        //             piggyBtn.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
        //         });
        //     });
        // }
        // else
        // {
        //     canvas.enabled = true;
        //     Sequence seq = DOTween.Sequence();
        //     seq.Append(piggyBtn.transform.DOScale(Vector3.one, 0.05f).SetEase(Ease.OutQuart));
        //     seq.AppendInterval(2f);
        //     seq.AppendCallback(() => { e.callback?.Invoke(); });
        //     seq.Append(piggyBtn.transform.DOMove(OrignPiggyPos, 0.8f)).SetEase(Ease.InOutCubic);
        //     seq.AppendCallback(() =>
        //     {
        //         canvasGroup.blocksRaycasts = true;
        //         canvas.sortingOrder = 0;
        //         BoxBuilder.HideTimeSaver();
        //     });
        // }
    }

    #endregion

    //赛季通行证
    private void OnHomeViewSeasonPassEvent(HomeViewSeasonPassEvent e)
    {
        var canvas = seasonPassBtn.gameObject.GetComponent<Canvas>();
        if (e.top)
        {
            canvas.enabled = false;
            canvas.sortingOrder = 200;
            seasonPassBtn.GetComponent<CanvasGroup>().alpha = 1;
            seasonPassBtn.gameObject.SetActive(true);
            seasonPassBtn.transform.localScale = Vector3.zero;
            OrignSeasonPos = seasonPassBtn.transform.position;
            UniRx.Observable.Timer(TimeSpan.FromSeconds(0.04f)).Subscribe(_ =>
            {
                seasonPassBtn.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
            });
        }
        else
        {
            canvas.enabled = true;
            Sequence seq = DOTween.Sequence();
            seq.Append(seasonPassBtn.transform.DOScale(Vector3.one, 0.05f).SetEase(Ease.OutQuart));
            seq.AppendInterval(2f);
            seq.AppendCallback(() => { e.callback?.Invoke(); });
            seq.Append(seasonPassBtn.transform.DOMove(OrignSeasonPos, 0.8f)).SetEase(Ease.InOutCubic);
            seq.AppendCallback(() =>
            {
                canvas.sortingOrder = 0;
                BoxBuilder.HideTimeSeason();
            });
        }
    }

    Tween FlyCollectItemEffect(ActivityType activityType, int flyCount = 0, Action action = null)
    {
        GameObject btn = null;
        string atlas = "";
        string key = "";
        int textCount = flyCount;
        GameObjType objType = GameObjType.FlyFlowerItem;
        bool needResetSize = false;
        float scaleFactor = 0.8f;
        switch (activityType)
        {
            case ActivityType.collectFlower:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "rose";
                btn = collectFlowerBtn;
                break;
            case ActivityType.endlessLevel:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "hg";
                btn = endlessBtn.gameObject;
                break;
            case ActivityType.rabbitGift:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "tzls_4";
                btn = rabbitGiftBtn.gameObject;
                break;
            case ActivityType.digTreasure:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "dig";
                btn = digBtn.gameObject;
                break;
            case ActivityType.cookMeal:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "cook";
                btn = cookBtn.gameObject;
                break;
            case ActivityType.collectWater:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "tzls_4";
                btn = waterBtn.gameObject;
                break;
            case ActivityType.collectHoney:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "tzls_4";
                btn = honeyBtn.gameObject;
                break;
            case ActivityType.collectLoveCard:
                btn = collectLoveCardBtn;
                objType = GameObjType.FlyLoveCardItem;
                atlas = Constants.AtlasNamePath.ViewCollectLoveCardAtlas;
                key = dataService.CollectLoveCardProgress?.SubActivityType == 1 ? "axfk_11" : "axfk_12";
                flyCount = 1;
                scaleFactor = 2f;
                needResetSize = true;
                break;
            case ActivityType.collectMusic:
                btn = collectMusicBtn;
                objType = GameObjType.FlyLoveCardItem;
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "xzyf_yf";
                flyCount = 1;
                scaleFactor = 2f;
                needResetSize = true;
                break;
            case ActivityType.passRank:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "hdjb_ts_1";
                btn = passRankBtn;
                break;
            case ActivityType.carRank:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "lt";
                btn = carRankBtn;
                break;
            case ActivityType.seasonPass:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "syrk_1_4";
                btn = seasonPassBtn;
                break;
            case ActivityType.limitPk:
                atlas = Constants.AtlasNamePath.TextureCommonAtlas;
                key = "qjbs_13";
                btn = limitPkBtn;
                break;
            default:
                break;
        }
        if (!GameObjManager.Instance.CheckGoHasPreLoad(objType))
        {
            action?.Invoke();
            return null;
        }
        if (btn == null || flyCount == 0) return null;
        flyCount = Math.Min(flyCount, 5);

        Sequence rootSeq = DOTween.Sequence();
        Vector3 startPos = btn.transform.position;
        Vector3 waitPos = startPos + new Vector3(-200, 200);
        if (activityType == ActivityType.collectMusic || activityType == ActivityType.collectLoveCard)
        {
            startPos = Vector3.zero;
            waitPos = Vector3.zero;
        }
        Vector3 endPos = btn.transform.position;
        Vector3 controlPos = startPos + new Vector3(100, 200);
        Animator btnAnim = btn.GetComponent<Animator>();
        if (btnAnim) btnAnim.enabled = false;
        for (int i = 0; i < flyCount; i++)
        {
            int index = i;
            Transform starTrans = GameObjManager.Instance.PopGameObject(objType).transform;
            if (atlas != "" && key != "")
            {
                starTrans.GetComponent<Image>().SetSpriteByAtlas(atlas, key, false);
            }

            Text text = starTrans.Get<Text>("Text");
            if (index == flyCount - 1)
            {
                text.transform.localScale = Vector3.one;
                text.text = $"+{textCount}";
            }
            else
            {
                text.transform.localScale = Vector3.zero;
            }

            starTrans.GetComponent<Canvas>().sortingOrder = i + 5;
            starTrans.SetParent(transform, false);
            starTrans.localScale = Vector3.zero;
            starTrans.position = waitPos;
            Vector3 offset = new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f)) * 50;
            Vector3 beginPos = waitPos + offset;
            if (activityType == ActivityType.collectMusic || activityType == ActivityType.collectLoveCard)
            {
                beginPos += new Vector3(-300, 199);
            }

            Vector3[] bezierArray = BezierUtils.GetBeizerList(beginPos, controlPos, endPos, 5);

            Sequence seq = DOTween.Sequence();
            seq.AppendInterval(0.7f + 0.04f * index);
            seq.AppendCallback(() => starTrans.gameObject.SetActive(true));
            seq.Append(starTrans.DOMove(beginPos, 0.3f).SetEase(Ease.OutQuad));
            seq.Join(starTrans.DOScale(Vector3.one * scaleFactor, 0.3f));
            seq.AppendInterval(0.2f);
            if (needResetSize)
            {
                seq.Join(starTrans.DOScale(Vector3.one, 1f));
                seq.Join(starTrans.DOPath(bezierArray, 1f, PathType.CatmullRom).SetEase(Ease.InSine));
            }
            else
            {
                seq.Append(starTrans.DOPath(bezierArray, 1f, PathType.CatmullRom).SetEase(Ease.InSine));
            }

            seq.AppendCallback(() =>
            {
                seq.Join(btn.transform.DOScale(Vector3.one * 1.4f, 0.1f));
                seq.Join(btn.transform.DOScale(Vector3.one, 0.1f));
                GameObject newStarFx = GameObjManager.Instance.PopGameObject(GameObjType.CollectItemFx, collectItemFx);
                newStarFx.transform.SetParent(btn.transform);
                newStarFx.transform.localScale = Vector3.one;
                newStarFx.transform.position = endPos;
                newStarFx.SetActive(true);
                GameObjManager.Instance.PushGameObject(starTrans.gameObject);
                GameObjManager.Instance.PushGameObject(newStarFx.gameObject, 2);
            });
            rootSeq.Join(seq);
        }

        rootSeq.AppendCallback(() =>
        {
            SoundPlayer.Instance.PlayStarHit();
            action?.Invoke();
        });
        rootSeq.AppendInterval(0.5f).OnComplete(() =>
        {
            if (btnAnim) btnAnim.enabled = true;
        });
        return rootSeq;
    }

    Tween FlyAdItemEffect(int prop, int flyCount = 0, Action action = null)
    {
        GameObject btn = startBtn.gameObject;
        string atlas = "";
        string key = "";
        int textCount = flyCount;
        GameObjType objType = GameObjType.FlyFlowerItem;
        Vector3 tempOffset = Vector3.zero;
        bool needResetSize = false;
        float scaleFactor = 1.5f;
        if (btn == null || flyCount == 0) return null;
        flyCount = Math.Min(flyCount, 5);

        Sequence rootSeq = DOTween.Sequence();
        Vector3 startPos = Vector3.zero;
        Vector3 waitPos = startPos + tempOffset;
        Vector3 endPos = btn.transform.position;
        Vector3 controlPos = startPos + new Vector3(100, 200);
        Animator btnAnim = btn.GetComponent<Animator>();
        if (btnAnim) btnAnim.enabled = false;

        for (int i = 0; i < flyCount; i++)
        {
            int index = i;
            Transform starTrans = GameObjManager.Instance.PopGameObject(objType).transform;
            starTrans.GetComponent<Image>().LoadPropSprite((int)prop, false);
            Text text = starTrans.Get<Text>("Text");
            if (text != null)
            {
                text.text = "";
            }
            starTrans.GetComponent<Canvas>().sortingOrder = i + 5;
            starTrans.SetParent(transform, false);
            starTrans.localScale = Vector3.zero;
            starTrans.position = waitPos;
            Vector3 offset = new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f)) * 50;
            Vector3 beginPos = waitPos + offset;
            Vector3[] bezierArray = BezierUtils.GetBeizerList(beginPos, controlPos, endPos, 5);

            Sequence seq = DOTween.Sequence();
            seq.AppendInterval(0.7f + 0.04f * index);
            seq.AppendCallback(() =>
            {
                starTrans.gameObject.SetActive(true);
            });
            
            seq.Append(starTrans.DOMove(beginPos, 0.3f).SetEase(Ease.OutQuad));
            seq.Join(starTrans.DOScale(Vector3.one * scaleFactor, 0.3f));
            seq.AppendInterval(0.2f);
            seq.AppendCallback(() =>
            {
                if (index == 0)
                {
                    SoundPlayer.Instance.PlayMainSound("daoju_anniu_tx_01(Clone)");
                }
            });
            if (needResetSize)
            {
                seq.Join(starTrans.DOScale(Vector3.one, 1f));
                seq.Join(starTrans.DOPath(bezierArray, 1f, PathType.CatmullRom).SetEase(Ease.InSine));
            }
            else
            {
                seq.Append(starTrans.DOPath(bezierArray, 1f, PathType.CatmullRom).SetEase(Ease.InSine));
            }

            seq.AppendCallback(() =>
            {
                seq.Join(btn.transform.DOScale(Vector3.one * 1.4f, 0.1f));
                seq.Join(btn.transform.DOScale(Vector3.one, 0.1f));
                SoundPlayer.Instance.PlayStarHit();
                GameObject newStarFx = Instantiate(collectItemFx.gameObject, btn.transform);
                newStarFx.transform.position = endPos;
                newStarFx.SetActive(true);
                Destroy(starTrans.gameObject);
                Destroy(newStarFx, 2);
            });
            rootSeq.Join(seq);
        }

        rootSeq.AppendCallback(() => { action?.Invoke(); });
        rootSeq.AppendInterval(0.5f).OnComplete(() =>
        {
            if (btnAnim) btnAnim.enabled = true;
        });
        return rootSeq;
    }

    float PlayCollectFillAnim(ActivityType acType)
    {
        Sequence seq = DOTween.Sequence();
        int getRewardCount = 0;
        int nextCount = 0;
        int curCount = 0;
        Image progress = null;
        float ratio = 0f;
        Text valueTex;
        Text totalTex;
        switch (acType)
        {
            case ActivityType.collectMusic:
                nextCount = ActivityManager.Instance.CollectMusicActivity.GetNextLayerCollectCount();
                curCount = ActivityManager.Instance.CollectMusicActivity.GetCurLayerCollectCount();
                getRewardCount = dataService.CollectMusicProgress.getRewardCount;
                progress = collectMusicProgress;
                ratio = ActivityManager.Instance.CollectMusicActivity.GetRatio();
                valueTex = transform.Get<Text>("Dynamic/CollectMusicBtn/Progress/Text");
                totalTex = transform.Get<Text>("Dynamic/CollectMusicBtn/Progress/Text/Total");
                break;
            case ActivityType.collectLoveCard:
                nextCount = ActivityManager.Instance.CollectLoveCardActivity.GetNextLayerCollectCount();
                curCount = ActivityManager.Instance.CollectLoveCardActivity.GetCurLayerCollectCount();
                getRewardCount = dataService.CollectLoveCardProgress.getRewardCount;
                progress = collectLoveCardProgress;
                ratio = ActivityManager.Instance.CollectLoveCardActivity.GetRatio();
                valueTex = transform.Get<Text>("Dynamic/CollectLoveCardBtn/Progress/Text");
                totalTex = transform.Get<Text>("Dynamic/CollectLoveCardBtn/Progress/Text/Total");
                break;
            default:
                return seq.Duration();
        }

        if (getRewardCount > 0)
        {
            for (int i = 0; i < getRewardCount; i++)
            {
                seq.Append(progress.DOFillAmount(1f, 0.4f));
                seq.Append(progress.DOFillAmount(0, 0));
            }
            seq.Append(progress.DOFillAmount(ratio, 0.4f));
        }
        else
        {
            seq.Join(progress.DOFillAmount(ratio, 0.4f));
        }

        valueTex.DOText($"{curCount}", 0.4f, true, ScrambleMode.Numerals);
        totalTex.text = $"{nextCount}";
        return seq.Duration();
    }

    float PlaySeasonFillAnim()
    {
        Sequence seq = DOTween.Sequence();
        int getRewardCount = dataService.SeasonPassProgress.getRewardCount;
        int nextCount = ActivityManager.Instance.SeasonPassActivity.GetNextLayerCollectCount();
        int curCount = ActivityManager.Instance.SeasonPassActivity.GetCurLayerCollectCount();
        if (getRewardCount > 0)
        {
            for (int i = 0; i < getRewardCount; i++)
            {
                seq.Append(seasonPassImage.DOFillAmount(1, 0.4f));
                seq.Append(seasonPassImage.DOFillAmount(0, 0f));
            }
            seq.Append(seasonPassImage.DOFillAmount(ActivityManager.Instance.SeasonPassActivity.GetRatio(), 0.4f));
        }
        else
        {
            seq.Join(seasonPassImage.DOFillAmount(ActivityManager.Instance.SeasonPassActivity.GetRatio(), 0.4f));
        }

        UpdateSeasonRewardRemind();
        transform.Get<Text>("Static/GiftBtns/SeasonPassBtn/Progress/Text").DOText($"{curCount}", 0.4f, true, ScrambleMode.Numerals);
        transform.Get<Text>("Static/GiftBtns/SeasonPassBtn/Progress/Text/Total").text = $"{nextCount}";
        dataService.SeasonPassProgress.getRewardCount = 0;
        return seq.Duration();
    }

    public void UpdateSeasonRewardRemind(SendUpdateSeasonRemid obj = null)
    {
        int count = ActivityManager.Instance.SeasonPassActivity.GetCanGetRewardCount();
        transform.Get<Transform>("Static/GiftBtns/SeasonPassBtn/Remind").gameObject.SetActive(count > 0);
        if (count > 0)
        {
            transform.Get<Text>("Static/GiftBtns/SeasonPassBtn/Remind/Text").text = $"{count}";
        }
    }

    public void UpdateLevelBoxRemind()
    {
        int count = dataService.GetUnPutLevelBoxNumber();
        levelBoxBtn.Get<Transform>("Remind").gameObject.SetActive(count > 0);
        if (count > 0)
        {
            levelBoxBtn.Get<Text>("Remind/Text").text = $"{count}";
        }
    }

    


    private void OnSpreadViewComplete(bool spread)
    {
        if (GameUtils.IsInHomeView() && GameCommon.IsExitGame && !spread)
        {
            OnCheckAddCollectItem(null);
            GameCommon.IsExitGame = false;
        }
        if (GameCommon.GMAddCollectResource && !spread)
        {
            OnCheckAddCollectItem(null);
            GameCommon.GMAddCollectResource = false;
        }
    }

    public bool RookieAble
    {
        get
        {
            if(this.spreadViewHandler.allVisible)
            {
                return true;
            }
            return false;
        }
        
    }

    private void OnRefreshWheelText(UpdateWheelEvent obj)
    {
        int curIndex = dataService.WheelProgress.curIndex;
        if (curIndex >= configService.WheelOpenInterval.Length) curIndex = configService.WheelOpenInterval.Length - 1;
        wheelBtnText.text = $"{dataService.WheelProgress.curLevel}/{configService.WheelOpenInterval[curIndex]}";
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<CheckAddCollectItem>(OnCheckAddCollectItem);
        TypeEventSystem.UnRegister<RefreshUserInfoBuildCoin>(OnRefreshBuildCoin);
        TypeEventSystem.UnRegister<UpdateWheelEvent>(OnRefreshWheelText);
        TypeEventSystem.UnRegister<UpdateEmailInfoEvent>(OnRefreshEmailInfo);
        TypeEventSystem.UnRegister<SendUpdateSeasonRemid>(UpdateSeasonRewardRemind);
        TypeEventSystem.UnRegister<CollectFarmingCoin>(OnFlyFarmingCollectText);
        TypeEventSystem.UnRegister<TriggrePopupEvent>(CheckTriggerPopup);
        TypeEventSystem.UnRegister<RefreshActivityRank>(OnRefreshActivityRank);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(OnRefreshActivityTimer);
        TypeEventSystem.UnRegister<RefreshHeartBeatGift>(OnRefreshHeartBeatGift);
        TypeEventSystem.UnRegister<RefreshEndlessLevel>(OnRefreshEndlessLevel);
        TypeEventSystem.UnRegister<HomeViewSeasonPassEvent>(OnHomeViewSeasonPassEvent);
        TypeEventSystem.UnRegister<HomeViewPigEvent>(OnHomeViewPigEvent);
        TypeEventSystem.UnRegister<PropChangeEvent>(OnPropChangeEvent);
        TypeEventSystem.UnRegister<UpdateFarmingPanelEvent>(UpdateFarmingPanel);
        TypeEventSystem.UnRegister<GlobalTimerRefreshEvent>(OnGlobalTimerRefreshEvent);
        TypeEventSystem.UnRegister<PlayGetLoveCardReward>(OnPlayGetLoveCardReward);
        TypeEventSystem.UnRegister<PlayGetMusicReward>(OnPlayGetMusicReward);
        TypeEventSystem.UnRegister<TogglePopupEvent>(OnTogglePopup);
    }

    private void OnPlayGetLoveCardReward(PlayGetLoveCardReward obj)
    {
        if (!obj.needPlay)
        {
            SetCollectLoveCardReward();
            return;
        }

        Observable.Timer(TimeSpan.FromSeconds(2.5f)).Subscribe(_ =>
        {
            BoxBuilder.ShowPopRewardPopup(() =>
            {
                Transform propItem = transform.Get<Transform>("Dynamic/CollectLoveCardBtn/NextRewardItem");
                propItem.gameObject.SetActive(false);
            }, null, SetCollectLoveCardReward, ActivityType.collectLoveCard, obj, startBtn.transform.position);
        });
    }

    private void OnPlayGetMusicReward(PlayGetMusicReward obj)
    {
        if (!obj.needPlay)
        {
            SetCollectMusicReward();
            return;
        }

        Observable.Timer(TimeSpan.FromSeconds(2.5f)).Subscribe(_ =>
        {
            BoxBuilder.ShowPopRewardPopup(() =>
            {
                Transform propItem = transform.Get<Transform>("Dynamic/CollectMusicBtn/NextRewardItem");
                propItem.gameObject.SetActive(false);
            }, null, SetCollectMusicReward, ActivityType.collectMusic, obj, startBtn.transform.position);
        });
    }

    private void OnTogglePopup(TogglePopupEvent evt)
    {
        UIPopup currentPopup = UIPopupManager.CurrentVisibleQueuePopup;
        if (currentPopup !=  null)
        {
            if(currentPopup.Visibility == VisibilityState.Hiding)
            {
                spreadViewHandler.ToggleSpread(false);
            }
            else
            {
                spreadViewHandler.ToggleSpread(true);
            }
        }
        else
        {
            spreadViewHandler.ToggleSpread(false);
        }
    }


    public void SettingOpenBtnEvent()
    {
        if (isLoadingCatalogueItem) return;
        if (catalogueItem == null)
        {
            isLoadingCatalogueItem = true;
            GlobalRes.DynamicLoadPrefab(Constants.ItemNamePath.CatalogueItem, (obj) =>
            {
                catalogueItem = obj;
                catalogueItem.transform.SetParent(transform);
                RectTransform rectTransform = catalogueItem.GetComponent<RectTransform>();
                rectTransform.offsetMin = new Vector2(0, rectTransform.offsetMin.y);
                rectTransform.offsetMax = new Vector2(0, rectTransform.offsetMax.y);
                rectTransform.offsetMin = new Vector2(rectTransform.offsetMin.x, 0);
                rectTransform.offsetMax = new Vector2(rectTransform.offsetMax.x, 0);
                catalogueItem.transform.localScale = Vector3.one;
                catalogueItem.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                catalogueItem.SetActive(true);
                isLoadingCatalogueItem = false;
            });
        }
        else
        {
            catalogueItem.SetActive(true);
        }
        GameUtils.RequestEmailInfo("1");
    }

    public void GMBtnEvent()
    {
        SoundPlayer.Instance.PlayButton();
        BoxBuilder.ShowGm();
    }

    public void AddGoldBtnEvent()
    {
        SoundPlayer.Instance.PlayButton();
        BoxBuilder.ShowShopPop();
    }

    public void StartBtnEvent()
    {
        //if (GameCommon.IsAddingCollect || GameCommon.IsPlayingCollectAnim) return;
        if (GameUtils.IsSpecialLevel())
        {
            _ = GlobalRes.DynamicLoadView(Constants.DoozyView.Game, () =>
            {
                //BoxBuilder.ClearNowShowPopup();
                //ViewQueueManager.Instance.ClearQueue();
                LevelUtils.LoadLevel(dataService.MaxLevel, model =>
                {
                    BoxBuilder.ShowSceneChangePop(() =>
                    {
                        GameUtils.CosumeAndReportStartEvent(dataService.MaxLevel, model);
                    }, BoxBuilder.HideSceneChangePop);
                });
            });
            return;
        }
        PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.StartGamePopup, () =>
        {
            SoundPlayer.Instance.PlayButton();
            BoxBuilder.ShowStartGamePopup();
        });
    }

    

    private void OnApplicationPause(bool pause)
    {
        if (dataService == null) return;
    }

    protected override void OnViewDestroy()
    {
        // GlobalRes.RemovePreLoad(preLoadResList);
    }
}