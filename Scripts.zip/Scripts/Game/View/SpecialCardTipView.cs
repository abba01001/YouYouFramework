﻿using System;
using System.Collections.Generic;
using DG.Tweening;
using Game.Cards;
using QFramework;
using UnityEngine.UI;
using UniRx;
using UnityEngine;
using SoliUtils;
using TMPro;
using UnityEngine.Rendering;

public class SpecialCardTipView : ViewBase
{
    private BaseCard card1 = null;
    private BaseCard card2 = null;
    protected override void OnAwake()
    {
        transform.Get<Button>("Overlay").SetButtonClick(CloseFunc);
        transform.Find($"Container/ItemParent/Card1").gameObject.SetActive(false);
        transform.Find($"Container/ItemParent/Card2").gameObject.SetActive(false);
        transform.Find("Container/Rope").gameObject.SetActive(false);
    }

    private void CloseFunc()
    {
        GameCommon.IsShowSpeialCardTiping = false;
        SoundPlayer.Instance.PlayCertainButton(6);
        TypeEventSystem.Send<ResetBattleRenderTimeEvent>();
        BoxBuilder.HidePopup(gameObject);
    }

    public void SetDetail(CardData data)
    {
        bool hasMod = false;
        CardDescModel model = null;

        //判断挂件
        foreach (var VARIABLE in data.cm.modifiers)
        {
            if (VARIABLE.modType != ModifierType.None && VARIABLE.modType != ModifierType.Coin)
            {
                foreach (var info in configService.CardDescConfig)
                {
                    if (info.Value.ModType == VARIABLE.modType)
                    {
                        hasMod = true;
                        model = info.Value;
                        HandlePairCard(model, info.Value.ModType, data);
                        break;
                    }
                }
            }
        }

        //判断类型
        if (!hasMod)
        {
            foreach (var info in configService.CardDescConfig)
            {
                if (info.Value.CardType == data.cm.cardType)
                {
                    model = info.Value;
                    HandlePairCard(model, info.Value.CardType, data);
                    break;
                }
            }
        }
        Observable.Timer(TimeSpan.FromSeconds(0.22f)).Subscribe(_ =>
            {
                if (card1 != null) card1.transform.Find("card").SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                if (card2 != null) card2.transform.Find("card").SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                SetTextLayer();
            }
        );
    }

    private void SetTextLayer()
    {
        if (card1 != null)
        {
            var objs = card1.gameObject.GetComponentsInChildren<TextMeshPro>();
            foreach (var text in objs)
            {
                SortingGroup t = text.gameObject.AddComponent<SortingGroup>();
                t.sortingLayerName = "UI";
                t.sortingOrder = 200;
            }
        }

        if (card2 != null)
        {
            var objs = card2.gameObject.GetComponentsInChildren<TextMeshPro>();
            foreach (var text in objs)
            {
                SortingGroup t = text.gameObject.AddComponent<SortingGroup>();
                t.sortingLayerName = "UI";
                t.sortingOrder = 200;
            }
        }
    }

    void HandlePairCard(CardDescModel model, ModifierType modifierType, CardData data)
    {
        CardData tempData1 = data.Copy();
        CardData tempData2 = data.Copy();
        if (modifierType == ModifierType.Rising || modifierType == ModifierType.Lowering)
        {
            if (tempData1.cm.modifiers.Length > 0)
            {
                tempData1.cm.modifiers[0].modType = ModifierType.Rising;
            }
            card1 = InstantiateCard(model, tempData1, 1);
            if (tempData2.cm.modifiers.Length > 0)
            {
                tempData2.cm.modifiers[0].modType = ModifierType.Lowering;
            }
            card2 = InstantiateCard(model, tempData2, 2);
            Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
                {
                    (card1 as ValueCard).ShowRisingEff();
                    (card2 as ValueCard).ShowLoweringEff();
                }
            );
        }
        else if (modifierType == ModifierType.LinkRope)
        {
            if (tempData1.cm.modifiers.Length > 0)
            {
                tempData1.cm.modifiers[0].modType = ModifierType.LinkRope;
            }
            card1 = InstantiateCard(model, tempData1, 1);
            if (tempData2.cm.modifiers.Length > 0)
            {
                tempData2.cm.modifiers[0].modType = ModifierType.LinkRope;
            }
            card2 = InstantiateCard(model, tempData2, 2);
            Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
                {
                    transform.Find("Container/Rope").gameObject.SetActive(true);
                }
            );
        }
        else if (modifierType == ModifierType.Water)
        {
            if (tempData1.cm.modifiers.Length > 0)
            {
                tempData1.cm.modifiers[0].modType = ModifierType.Water;
            }
            card1 = InstantiateCard(model, tempData1, 1);

            tempData1.cm.modifiers = null;
            tempData2.cm.cardType = CardType.Anchor;
            card2 = InstantiateCard(model, tempData2, 2);
        }
        else if (modifierType == ModifierType.BigBomb)
        {
            card1 = InstantiateCard(model, data, 1);
            Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
                {
                    card1.transform.GetComponentInChildren<BigBombMod>().Active();
                }
            );
        }
        else if (modifierType == ModifierType.Bomb)
        {
            var rect = transform.Get<RectTransform>("Container/ItemParent");
            rect.anchoredPosition = new Vector2(rect.anchoredPosition.x, rect.anchoredPosition.y - 45);
            card1 = InstantiateCard(model, data, 1);
            Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
                {
                    card1.transform.GetComponentInChildren<BombMod>().Active();
                }
            );
        }
        else if (modifierType == ModifierType.Lightning)
        {
            card1 = InstantiateCard(model, data, 1);
            Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
                {
                    card1.transform.GetComponentInChildren<LightningMod>().Active();
                }
            );
        }
        else if (modifierType == ModifierType.GreenLeaf)
        {
            card1 = InstantiateCard(model, data, 1);
            Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
                {
                    transform.Find("Container/Bird").gameObject.SetActive(true);
                }
            );
        }
        else
        {
            card1 = InstantiateCard(model, data, 1);
        }
    }

    void HandlePairCard(CardDescModel model, CardType cardType, CardData data)
    {
        CardData tempData1 = data.Copy();
        CardData tempData2 = data.Copy();
        if (cardType == CardType.Lock || cardType == CardType.Key)
        {
            tempData1.cm.cardType = CardType.Key;
            card1 = InstantiateCard(model, tempData1, 1);
            tempData2.cm.cardType = CardType.Lock;
            card2 = InstantiateCard(model, tempData2, 2);
        }
        else if (cardType == CardType.Banana || cardType == CardType.Monkey)
        {
            tempData1.cm.cardType = CardType.Banana;
            card1 = InstantiateCard(model, tempData1, 1);
            tempData2.cm.cardType = CardType.Monkey;
            card2 = InstantiateCard(model, tempData2, 2);
        }
        else if (cardType == CardType.Anchor)
        {
            if (tempData1.cm.modifiers.Length > 0)
            {
                tempData1.cm.modifiers[0].modType = ModifierType.Water;
            }
            card1 = InstantiateCard(model, tempData1, 1);

            tempData1.cm.modifiers = null;
            tempData2.cm.cardType = CardType.Anchor;
            card2 = InstantiateCard(model, tempData2, 2);
        }
        else if (cardType == CardType.Monochrome || cardType == CardType.Rudder)
        {
            tempData1.cm.suit = 0;
            card1 = InstantiateCard(model, tempData1, 1);
            tempData2.cm.suit = 1;
            card2 = InstantiateCard(model, tempData2, 2);
            if (cardType == CardType.Rudder)
            {
                Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ =>
                    {
                        card1.IsFaceUp = true;
                        card2.IsFaceUp = true;
                    }
                );
            }
        }
        else
        {
            card1 = InstantiateCard(model, data, 1);
        }
    }

    BaseCard InstantiateCard(CardDescModel model, CardData data, int cardIndex)
    {
        transform.Get<Text>("Container/Title").text = model.mainTitle;
        transform.Get<Text>("Container/ViceTitle").text = model.viceTitle;
        transform.Get<Text>("Container/Desc").text = model.desc;
        data.cm.faceUp = true;
        data.cm.SetValue(0);
        data.cm.SetValue2(12);
        BaseCard card = CreateCard(9997 + cardIndex, data.cm, 1, 1);
        Transform parent = transform.Find($"Container/ItemParent/Card{cardIndex}");
        card.transform.SetParent(parent);
        card.transform.parent.gameObject.SetActive(true);
        card.gameObject.transform.localPosition = new Vector3(0, 0, -100);
        if (model.CardType != CardType.TwoValue)
        {
            parent.transform.localScale = Vector3.one * 1.5f;
        }
        else
        {
            parent.transform.localScale = Vector3.one;
        }
        card.transform.Find("card").SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
        card.transform.DOScale(Vector3.one, 0.4f);

        var canvas = this.GetComponent<Canvas>();
        if (canvas != null)
        {
            int newSortOrder = 100 + GameCommon.VisiblePopupCount * 10;
            var cavs = card.GetComponentsInChildren<Canvas>(true);
            foreach (var cav in cavs)
            {
                if (cav != canvas)
                {
                    cav.sortingLayerName = "UI";
                    cav.sortingOrder = newSortOrder + 5;
                }
            }

            var sg = card.GetComponentsInChildren<SortingGroup>(true);
            foreach (var t in sg)
            {
                t.sortingLayerName = "UI";
                t.sortingOrder = newSortOrder + 5;
            }

            var sr = card.GetComponentsInChildren<SpriteRenderer>(true);
            foreach (var t in sr)
            {
                t.sortingLayerName = "UI";
                t.sortingOrder = newSortOrder + 5;
            }
        }
        return card;
    }


    BaseCard CreateCard(int cardId, CardModel cardModel, int cardBackId, int betValue)
    {
        var gameObjType = Constants.CardType2ObjDic[cardModel.cardType];
        var card = GameObjManager.Instance.PopGameObject(gameObjType);
        card.SetActive(true);
        var cardMono = card.GetComponent<BaseCard>();
        cardMono.CardId = cardId;
        CardData cardData = new CardData(cardId, cardModel);
        cardMono.SetData(cardData, cardBackId, betValue);
        cardMono.ShowModifier(true);
        cardMono.ResetVisible();
        return cardMono;
    }

    protected override void OnShow()
    {
        SoundPlayer.Instance.PlayMainSound("Card_new_tx");
    }
}
