﻿using QFramework;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class GiftDiscountView : ViewBase
{
    private Text priceText;
    private Text timeText;
    private Transform itemParent;
    [SerializeField] private GameObject BigShopItem1;
    [SerializeField] private ActivityTimeItem timeItem;
    protected override void OnAwake()
    {
        transform.Get<Button>("Content/CloseBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
        });
    }

    protected override void OnViewInit(bool isFirst)
    {
        TypeEventSystem.Register<GameRechargeEvent>(UpdatPanel);
        TypeEventSystem.Register<HideDiscountGiftPopup>(ClosePanel);
    }

    private void UpdatPanel(GameRechargeEvent obj)
    {

    }
    
    private void ClosePanel(HideDiscountGiftPopup obj)
    {
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatPanel);
        TypeEventSystem.UnRegister<HideDiscountGiftPopup>(ClosePanel);
    }

    protected override void OnShow()
    {
        if (!dataService.CheckFirstPopup(Constants.DoozyView.GiftDiscountPopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.GiftDiscountPopup);
        }

        UpdateInfo();
        RefreshTimer();
    }

    void RefreshTimer()
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>(true);
        timeData.Clear();
        timeData.endTime = TimeUtils.IntToDateTime(dataService.GiftDiscountData.ActivityEndTime);
        timeItem.SetTimeData(timeData);
    }
    
    private void UpdateInfo()
    {
        configService.ShopConfig.TryGetValue(Constants.ProductId.DiscountGift, out ShopModel model);
        UpdateSHopItem(BigShopItem1.Get<Transform>("ProductContent/Reward"),model,GameUtils.AnalysisPropString(model.reward));
    }

    private void UpdateSHopItem(Transform rewardParent,ShopModel model,Dictionary<int,int> rewardDic)
    {
        var buyBtn = rewardParent.parent.Get<Button>("BuyBtn");
        buyBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(model.product_id,null);
        });
        buyBtn.gameObject.Get<Text>("Price").text = model.money.ToString();
        
        for (int i = 0; i < rewardParent.childCount; i++)
        {
            rewardParent.GetChild(i).gameObject.SetActive(false);
        }
        int count = 0;
        foreach (var pair in rewardDic)
        {
            if (count >= rewardParent.childCount) break;
            var child = rewardParent.GetChild(count);
            child.gameObject.MSetActive(true);
            GameUtils.LoadPropSprite(child.Get<Image>($"PropImage"), pair.Key);
            child.Get<Transform>($"TimeText").gameObject.MSetActive(GameUtils.IsLimitTimeReward(pair.Key));
            child.Get<Text>($"NumText").text = "";
            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                child.Get<Text>($"TimeText").text = GameUtils.GetItemCountText(pair.Key, pair.Value);
            }
            else
            {
                child.Get<Text>("NumText").text = GameUtils.GetItemCountText(pair.Key, pair.Value);
            }
            count++;
        }
    }
}