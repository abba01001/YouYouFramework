

using System.Collections.Generic;
using Coffee.UIExtensions;
using SoliUtils;
using UnityEngine;
using UnityEngine.UI;

public class MergeVersionRewardView : ViewBase
{
    void Start()
    {
        var PropItem = transform.Find("Container/Content/Rewards/PropItem");
        var getBtn = transform.Get<Button>("Container/Content/GetBtn");
        string rewards = dataService.GetOldDataVersionRewards();
        Dictionary<int, int> reward = GameUtils.AnalysisPropString(rewards);

        getBtn.SetButtonClick(() =>
        {
            if (!dataService.OldDataVersionFlag)
            {
                BoxBuilder.HidePopup(gameObject);
                return;
            }
            BoxBuilder.ShowRewardPop(reward, PropChangeWay.MergeVersion);
            BoxBuilder.HidePopup(gameObject);
            dataService.OldDataVersionFlag = false;
        });

        int index = 0;
        foreach (var pair in reward)
        {
            var item = GameObject.Instantiate(PropItem, PropItem.parent);
            item.Get<Image>($"PropImage").LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : pair.Key);
            // item.Get<UIEffect>($"PropImage").effectFactor = 1;
            // item.Get<UIEffect>($"Bg").effectFactor = 1;
            item.Get<Transform>($"TimeText").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
            item.Get<Text>($"NumText").text = "";
            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                item.Get<Text>($"TimeText").text = $"{pair.Value / 60}m";
            }
            else
            {
                item.Get<Text>($"NumText").text =
                    pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
            }
            index++;
        }
        PropItem.gameObject.SetActive(false);

    }


}