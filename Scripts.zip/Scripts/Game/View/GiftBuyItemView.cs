﻿using Activities;
using Doozy.Engine;
using Doozy.Engine.UI;
using Model;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
public class GiftBuyItemView : ViewBase
{
    [SerializeField] private Button BuyBtn;
    [SerializeField] private Button CloseBtn;
    [SerializeField] private Text title;
    [SerializeField] private GameObject rewardItem;
    private ShopModel _model;
    protected override void OnAwake()
    {
        BuyBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            if(_model == null) return;
            PayUtils.RequestOrder(_model.product_id);
        });
        CloseBtn.SetButtonClick(() =>
        {
            BoxBuilder.HidePopup(gameObject);
        });
        
    }

    public void SetParams(ActivityType activityType)
    {
        if (activityType == ActivityType.digTreasure)
        {
            configService.ShopConfig.TryGetValue("ShovelGift", out ShopModel model);
            InitReward(model);
        }
        else if (activityType == ActivityType.cookMeal)
        {
            configService.ShopConfig.TryGetValue("ChefhatGift", out ShopModel model);
            InitReward(model);
        }
    }

    private void InitReward(ShopModel model)
    {
        _model = model;
        Dictionary<int, int> rewards = GameUtils.AnalysisPropString(model.reward);
        title.text = model.product_desc;
        foreach (var pair in rewards)
        {
            GameUtils.LoadPropSprite(rewardItem.Get<Image>("PropImage"),pair.Key);
            rewardItem.Get<Text>("NumText").text = pair.Value.ToString();
        }
        BuyBtn.gameObject.Get<Text>("Price").text = model.money.ToString();
    }
    
    protected override void OnViewInit(bool isFirstTime)
    {
        TypeEventSystem.Register<GameRechargeEvent>(UpdatePanel);
    }

    protected override void OnViewDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatePanel);
    }

    private void UpdatePanel(GameRechargeEvent e)
    {

    }

}
