using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RegionRewardAdapter : ListViewAdapter
{
    private List<MergeRegionRewardsConfig> _data;
    private int region_id;

    public override int GetCount()
    {
        return (_data?.Count ?? 0) + 1;
    }

    public override void FillItemData(ListViewCell item, int cellindex)
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var info = dataService.GetRegionInfo(region_id);
        if (cellindex == info.level)
        {
        }
        else
        {
            int key = cellindex;
            if (cellindex > info.level)
            {
                key--;
            }
            item.FillData(_data[key]);
        }
    }

    public override int GetCellPrefabIndex(int index)
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var info = dataService.GetRegionInfo(region_id);
        if (index == info.level)
            return 3;

        int key = region_id * 1000 + index + 1;
        if (index > info.level)
        {
            key--;
        }
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var m = configService.MergeRegionRewardsConfig[key];
        if (m.build_lv > 0)
            return 1;
        if (m.cloud_id > 0)
            return 2;

        return 0;
    }

    public void SetData(List<MergeRegionRewardsConfig> data)
    {
        region_id = data[0].id;
        _data = data;
    }
}