﻿using QFramework;
using System;
using System.Collections;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using SoliUtils;

public class SceneChangePopView : ViewBase, ISingleton
{
    private RectTransform carvedImage;
    private RectTransform left;
    private RectTransform right;
    private RectTransform down;
    private RectTransform up;
    private Image shaderBlack;

    private Sequence nowSeq;

    private static Vector2 CarvedSize = new Vector2(3500, 3500);

    public static SceneChangePopView Instance
    {
        get { return MonoSingletonProperty<SceneChangePopView>.Instance; }
    }

    public void OnSingletonInit()
    {
    }

    protected override void OnAwake()
    {
        carvedImage = transform.Get<RectTransform>("Container/CarvedImage");
        left = transform.Get<RectTransform>("Container/Left");
        right = transform.Get<RectTransform>("Container/Right");
        down = transform.Get<RectTransform>("Container/Down");
        up = transform.Get<RectTransform>("Container/Up");
        shaderBlack = transform.Get<Image>("Container/ShaderBlack");
        shaderBlack.material = new Material(shaderBlack.material);
    }

    //public void RunSceneChange(TweenCallback midChange, Action endChange)
    //{
    //    carvedImage.sizeDelta = CarvedSize;
    //    Sequence seq = DOTween.Sequence();
    //    seq.Append(carvedImage.DOSizeDelta(Vector2.zero,0.5f).SetEase(Ease.OutSine));
    //    seq.AppendCallback(midChange);
    //    seq.AppendInterval(0.2f);
    //    seq.Append(carvedImage.DOSizeDelta(CarvedSize,0.5f).SetEase(Ease.InSine));
    //    seq.OnComplete(() =>
    //    {
    //        GetComponent<UIPopup>().Hide(true);
    //        endChange?.Invoke();
    //    });

    //    Vector2 horizontalSize = new Vector2(Screen.width, Screen.height);
    //    Vector2 verticalSize = new Vector2(Screen.width, Screen.height);

    //    seq.OnUpdate(() =>
    //    {
    //        Vector2 size = carvedImage.sizeDelta;
    //        float halfX = size.x / 2;
    //        float halfY = size.y / 2;

    //        horizontalSize.x = Math.Max(Screen.width / 2 - halfX + 10, 0);
    //        verticalSize.y = Math.Max(Screen.height / 2 - halfY + 10, 0);

    //        left.sizeDelta = horizontalSize;
    //        right.sizeDelta = horizontalSize;
    //        down.sizeDelta = verticalSize;
    //        up.sizeDelta = verticalSize;
    //    });
    //}

    public void RunSceneChangeShow(TweenCallback midChange, Action endChange)
    {
        nowSeq?.Kill(true);
        carvedImage.sizeDelta = CarvedSize;
        Sequence seq = DOTween.Sequence();
        float maxRadius = Math.Max(Screen.width, Screen.height) / 2;
        seq.Append(shaderBlack.material.DOFloat(maxRadius, "_Radius", 0f));
        seq.Append(shaderBlack.material.DOFloat(0, "_Radius", 0.5f).SetEase(Ease.OutSine));
        seq.AppendCallback(() =>
        {
            BackdropMono.Instance.SwitchBackdrop();
            midChange();
            SoundPlayer.Instance.ForceCleanSound();
            SoundPlayer.Instance.CheckActivityBgm(GameController.Instance.IsPlaying,ActivityType.lavaPass);
        });
        seq.AppendInterval(0.2f);
        seq.OnComplete(() =>
        {
            endChange?.Invoke();
        });

        Vector2 horizontalSize = new Vector2(Screen.width, Screen.height);
        Vector2 verticalSize = new Vector2(Screen.width, Screen.height);

        seq.OnUpdate(() =>
        {
            if (carvedImage != null)
            {
                Vector2 size = carvedImage.sizeDelta;
                float halfX = size.x / 2;
                float halfY = size.y / 2;

                horizontalSize.x = Math.Max(Screen.width / 2 - halfX + 10, 0);
                verticalSize.y = Math.Max(Screen.height / 2 - halfY + 10, 0);

                left.sizeDelta = horizontalSize;
                right.sizeDelta = horizontalSize;
                down.sizeDelta = verticalSize;
                up.sizeDelta = verticalSize;
            }
        });
        nowSeq = seq;
    }

    public void RunSceneChangeHide()
    {
        Vector2 horizontalSize = new Vector2(Screen.width, Screen.height);
        Vector2 verticalSize = new Vector2(Screen.width, Screen.height);
        Sequence seq = DOTween.Sequence();
        float maxRadius = Math.Max(Screen.width, Screen.height) / 2;

        nowSeq?.Kill(true);
        seq.Append(shaderBlack.material.DOFloat(maxRadius, "_Radius", 0.5f).SetEase(Ease.InSine));
        seq.OnUpdate(() =>
        {
            if (carvedImage != null)
            {
                Vector2 size = carvedImage.sizeDelta;
                float halfX = size.x / 2;
                float halfY = size.y / 2;

                horizontalSize.x = Math.Max(Screen.width / 2 - halfX + 10, 0);
                verticalSize.y = Math.Max(Screen.height / 2 - halfY + 10, 0);

                left.sizeDelta = horizontalSize;
                right.sizeDelta = horizontalSize;
                down.sizeDelta = verticalSize;
                up.sizeDelta = verticalSize;
            }
        });

        seq.OnComplete(() => BoxBuilder.HidePopup(gameObject, true));
        nowSeq = seq;
    }
}