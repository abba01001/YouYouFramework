using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using Coffee.UIExtensions;
using DG.Tweening;
using Model;

[RequireComponent(typeof(CanvasGroup))]
public class DailyAdRewardPopView : ViewBase
{
    private int Length = 687;

    private Button CloseBtn;
    private ActivityTimeItem timeItem;
    private GameObject adRewardItem;
    private Transform itemParent;
    private Dictionary<int, AdRewardItem> itemList;
    private RectTransform progressFill;
    private Text progressText;
    private GameObject finalRewardEf;
    private DOTweenAnimation anim;
    protected override void OnAwake()
    {
        itemList = new Dictionary<int, AdRewardItem>();
        Button backCloseBtn = transform.Get<Button>("Overlay");
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        backCloseBtn.interactable = false;
        backCloseBtn.SetButtonClick(CloseFunc);
        CloseBtn.SetButtonClick(CloseFunc);
        progressFill = transform.Get<RectTransform>("Container/Progress/FillAmount");
        progressText = transform.Get<Text>("Container/Progress/Text");
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        itemParent = transform.Get<Transform>("Container/ScrollView/Content");
        adRewardItem = transform.Get<Transform>("Container/AdRewardItem").gameObject;
        adRewardItem.SetActive(false);
        transform.Get<Text>("Container/TipText").text = $"在游戏中任何位置观看{configService.ValueConfig["AdRewardProgress"]}个广告以获得奖励！";
        transform.Get<Button>("Container/Progress/Icon2").SetButtonClick(() =>
        {
            ActivityManager.Instance.AdRewardActivity.CheckFinalReward(()=>BoxBuilder.HidePopup(gameObject), () =>
            {
                GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                    .ShowItem(TextAnchor.LowerCenter, transform.Get<Transform>("Container/Progress/Icon2"), Vector2.zero,
                        GameUtils.AnalysisPropString(configService.ValueConfig["AdRewardProgressCumulative"]));
            });
        });
        finalRewardEf = transform.Get<Transform>("Container/Progress/Icon2/tx_show_01").gameObject;
        anim = transform.Get<DOTweenAnimation>("Container/Progress/Icon2");
        UpdatePanel();
    }



    private void CloseFunc()
    {
        finalRewardEf.SetActive(false);
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnRefresh()
    {
        base.OnRefresh();
    }

    private void UpdatePanel(UpdateAdRewardPanel obj = null)
    {
        int index = 0;
        if (itemList.Count == 0)
        {
            foreach (var item in configService.AdRewardConfig)
            {
                index++;
                GameObject prefab = GameObjManager.Instance.PopGameObject(GameObjType.AdRewardItem,adRewardItem);
                prefab.transform.SetParent(itemParent);
                prefab.transform.localScale = Vector3.one;
                prefab.SetActive(true);
                prefab.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                prefab.name = "AdRewardItem_" + index;
                itemList.Add(index, prefab.GetComponent<AdRewardItem>());
                itemList[index].SetData(index);
            }
        }
        else
        {
            foreach (var item in configService.AdRewardConfig)
            {
                index++;
                itemList[index].SetData(index);
            }
        }

        Vector2 itemParentSize = itemParent.GetComponent<RectTransform>().sizeDelta;
        Vector2 prefabSize = adRewardItem.GetComponent<RectTransform>().sizeDelta;

        itemParent.GetComponent<RectTransform>().sizeDelta = new Vector2((index) * prefabSize.x, itemParentSize.y);
        int temp = Mathf.Clamp(dataService.AdRewardProgress.curLayer - 1,0,ActivityManager.Instance.AdRewardActivity.GetMaxLayer() - 4);
        itemParent.GetComponent<RectTransform>().DOAnchorPos(new Vector2(temp * -prefabSize.x,0),0.5f);

        SetProgress();
        RefreshTimer();
        transform.Get<Button>("Container/Progress/Icon2").GetComponent<UIEffect>().effectFactor =
            dataService.CheckDailyFlag(FlagType.FinalAdReward) ? 1 : 0;
        if (dataService.AdRewardProgress.totalProgress >= ActivityManager.Instance.AdRewardActivity.GetMaxProgress() && !dataService.CheckDailyFlag(FlagType.FinalAdReward))
        {
            finalRewardEf.transform.localScale = Vector3.zero;
            finalRewardEf.transform.DOScale(Vector3.one, 0.2f).SetDelay(0.3f);
            finalRewardEf.SetActive(true);
            anim.isActive = true;
            anim.DORewind();
        }
        else
        {
            finalRewardEf.SetActive(false);
            anim.DOPause();
            anim.isActive = false;
        }
    }

    void RefreshTimer()
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();

        timeData.endTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (ActivityManager.Instance.GetActivityByType(ActivityType.adReward) != null && ActivityManager.Instance.GetActivityByType(ActivityType.adReward).state 
                is ActivityState.waitEntry or ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.adReward).ActivityBigEndTime);
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.adReward).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.AdRewardProgress.ActivityEndTime);
        }
        timeItem.SetTimeData(timeData);
    }

    private void SetProgress()
    {
        progressFill.DOSizeDelta(new Vector2(Length * ActivityManager.Instance.AdRewardActivity.GetRatio(), 60), 0.5f);
        progressText.text = $"{ActivityManager.Instance.AdRewardActivity.GetCurLayerCollectCount()}/{ActivityManager.Instance.AdRewardActivity.GetNextLayerCollectCount()}";
    }
    
    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<UpdateAdRewardPanel>(UpdatePanel);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateAdRewardPanel>(UpdatePanel);
    }
    protected override void OnShow()
    {

    }
    
    private void OnDisable()
    {
        if (!GameObjManager.IsNull())
        {
            foreach (var item in itemList)
            {
                GameObjManager.Instance.PushGameObject(item.Value.gameObject);
            }
        }
    }
    
}