﻿using System;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QFramework;
using SoliUtils;

public class CoinAdPopView : ViewBase
{
    private Text coinNumText;
    private Button adBtn;

    protected override void OnAwake()
    {
        coinNumText = transform.Get<Text>("Container/CoinNum");
        adBtn = transform.Get<Button>("Container/AdBtn");

        transform.Get<Button>("Container/CloseBtn").SetButtonClick(() => BoxBuilder.HidePopup(gameObject));
    }

    protected override void OnShow()
    {
        adBtn.SetButtonClick(() =>
        {
            AdPlayer.ShowCoinAd(() =>
            {
                BoxBuilder.HidePopup(gameObject);
                dataService.SaveData(true);
            });
        });
    }
}
