using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using DG.Tweening;
using Model;
using UniRx;

[RequireComponent(typeof(CanvasGroup))]
public class StartLavaPassPopView : ViewBase
{
    private Button CloseBtn;
    [SerializeField] private GameObject StartPanel;
    [SerializeField] private GameObject TipPanel;
    [SerializeField] private GameObject TipPanelAnim;
    [SerializeField] private Text TipPanelNum;
    [SerializeField] private Text TipText;
    [SerializeField] private Text TipPanelTotal;
    [SerializeField] private Text StartPanelReward;
    private ActivityTimeItem timeItem;
    private Action startGame;
    private bool isPlayingAnim = false;
    protected override void OnAwake()
    {
        StartPanel.Get<Button>("CloseBtn").SetButtonClick(CloseFunc);
        StartPanel.Get<Button>("EnterBtn").SetButtonClick(EnterGameFunc);
        TipPanel.GetComponent<Button>().SetButtonClick(StartMatch);
        timeItem = transform.Get<ActivityTimeItem>("Container/StartPanel/ActivityTimeItem");
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).ActivityBigEndTime);
            }
            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.LavaPassProgress.ActivityEndTime);
            }

            if (model.state is ActivityState.finished)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.LavaPassProgress.ActivityEndTime + ActivityManager.Instance.GetActivityByType(ActivityType.lavaPass).OpenInterval);
            }
        }
        timeItem.SetTimeData(timeData);
    }

    public void SetType(int uiType)
    {
        StartPanel.transform.localScale = Vector3.zero;
        TipPanel.transform.localScale = Vector3.zero;
        StartPanel.MSetActive(uiType == 0 || uiType == 2);
        TipPanel.MSetActive(uiType == 1);
        if (uiType == 1)
        {
            TipPanel.transform.DOScale(Vector3.one, 0.2f);
        }
        else
        {
            StartPanelReward.text = $"{ActivityManager.Instance.LavaPassActivity.GetActivityRewardCoin()}";
            StartPanel.transform.DOScale(Vector3.one, 0.2f);
            TipText.text = uiType == 0 ? "熔岩任务开始了！打通7个关卡，完成挑战！" : "您挑战失败!"+"\n"+
            "下一个熔岩任务将在倒计时结束后开启!";
            StartPanel.Get<Button>("EnterBtn").gameObject.SetActive(uiType == 0);
        }
    }

    protected override void OnShow()
    {
        RefreshTimer(null);
    }

    private void CloseFunc()
    {
        if(isPlayingAnim) return;
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
        if (dataService.LavaPassProgress.isFailState == 1)
        {
            BoxBuilder.HideLavaPassPopup();
        }
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    private void StartMatch()
    {
        if (GameCommon.IsShowingStartGamePopup)
        {
            BoxBuilder.ShowLavaPassPopup();
        }
        else
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.LavaPassPopup,()=>BoxBuilder.ShowLavaPassPopup(),true);
        }
        CloseFunc();
    }

    private void StartPlayMatchAnim()
    {
        isPlayingAnim = true;
        Observable.Timer(TimeSpan.FromSeconds(2f)).Subscribe(_ =>
        {
            isPlayingAnim = false;
        });
        TipPanelTotal.text = $"{ActivityManager.Instance.LavaPassActivity.GetActivityRewardCoin()}";
        TipPanelNum.text = "0";
        TipPanel.SetActive(true);
        TipPanel.transform.localScale = Vector3.one;
        TipPanelAnim.SetActive(true);
        TipPanelNum.DOText("100", 1.3f, true, ScrambleMode.Numerals).SetDelay(0.7f);
        SoundPlayer.Instance.PlayMainSound("ani_TipPanel");
        var list = new List<int>();
        var iconParent = TipPanel.Get<Transform>("Icon2");
        for (int i = 0; i < iconParent.childCount; i++)
        {
            int value = GameUtils.GetRandomRobotIcon(ref list);
            var image = iconParent.GetChild(i).Get<Image>("Icon");
            SpriteUtils.SetRobotSpriteByIndex(image,value,()=> image.gameObject.SetActive(true));
        }
        
        var startValue = 0;
        var endValue = 100;
        DOTween.To(() => startValue, x => {startValue = Mathf.RoundToInt(x);TipPanelNum.text = startValue.ToString();
        }, endValue, 1.3f).SetDelay(0.7f);
    }
    
    private void EnterGameFunc()
    {
        StartPanel.transform.DOScale(Vector3.zero, 0.2f).OnComplete(() =>
        {
            StartPanel.SetActive(false);
            ActivityManager.Instance.LavaPassActivity.EnableActivity();
            StartPlayMatchAnim();
        });

        return;
    }
}