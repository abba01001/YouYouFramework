
using UnityEngine;
using SoliUtils;
using Button = UnityEngine.UI.Button;
using System.Collections.Generic;
using UnityEngine.UI;

public class MergeOrderBoughtView : ViewBase
{
    private Button closeBtn;
    private Button okBtn;
    private Text priceText;
    private List<GameObject> Items;
    private int currentNpcId = 1200000;

    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(() => { BoxBuilder.HidePopup(gameObject); });

        okBtn = transform.Get<Button>("Container/OkBtn");
        okBtn.SetButtonClick(() =>
        {
            int price = dataService.GetMergeOrderPrice(currentNpcId);
            if(price > 0)
            {
                dataService.BuyAndCommitMergeOrder(currentNpcId);
                BoxBuilder.HidePopup(gameObject);
                BoxBuilder.HidePopup(BoxBuilder.GetPopup(Constants.DoozyView.MergeOrderPopup).gameObject);
            }
            else
            {
                BoxBuilder.ShowToast("金币不足");
            }
        });

        Items = new List<GameObject>();
        for (int i = 0; i < 4; i++)
        {
            var item = transform.Get<Transform>($"Container/TaskLayout/Item{i + 1}");
            Items.Add(item.gameObject);
        }

        priceText = transform.Get<Text>("Container/OkBtn/PriceText");
    }

    void ShowOrder()
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var orderData = dataService.GetMergeOrder(currentNpcId, out var _);
        if (orderData != null)
        {
            for (int i = 0; i < 4; i++)
            {
                Items[i].SetActive(false);
            }
            for (int i = 0; i < orderData.items.Length; i++)
            {
                Text countText = Items[i].Get<Text>("CountText");
                Image icon = Items[i].Get<Image>("Icon");
                int item_id = orderData.items[i];
                bool finish = orderData.process[i] >= orderData.count[i];
                Items[i].SetActive(!finish);
                if(!finish)
                {
                    countText.text = $"x{orderData.count[i]-orderData.process[i]}";
                    icon.LoadPropSprite(item_id, true, () =>
                    {
                        float targetHeight = 100;
                        float targetWidth = 80;
                        float originalWidth = icon.sprite.rect.width;
                        float originalHeight = icon.sprite.rect.height;
                        float aspectRatio = originalWidth / originalHeight;
                        float newWidth;
                        float newHeight;
                        if (originalHeight >= originalWidth)
                        {
                            newHeight = targetHeight;
                            newWidth = targetHeight * aspectRatio;
                        }
                        else
                        {
                            newWidth = targetWidth;
                            newHeight = targetWidth / aspectRatio;
                        }
                        icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
                    });
                }
            }
        }
        int price = dataService.GetMergeOrderPrice(currentNpcId);
        priceText.text = price.ToString();
    }

    public void SetNpcId(int npc_id)
    {
        currentNpcId = npc_id;
        ShowOrder();
    }
}