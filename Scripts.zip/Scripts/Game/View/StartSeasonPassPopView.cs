using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using Model;

[RequireComponent(typeof(CanvasGroup))]
public class StartSeasonPassPopView : ViewBase
{
    int waitToLevel = -1;
    List<int> selectItem = new List<int>(3);

    private Button CloseBtn;
    private Text TitleText;
    private Text TipText;
    private ActivityTimeItem timeItem;
    private GameObject StartBg;
    private GameObject DetailBg;
    private GameObject BuyBtn;
    protected override void OnAwake()
    {
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        TitleText = transform.Get<Text>("Container/TitleText");
        TipText = transform.Get<Text>("Container/TipText");
        CloseBtn.SetButtonClick(CloseFunc);
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        StartBg = transform.Find("Container/StartBg").gameObject;
        DetailBg = transform.Find("Container/DetailBg").gameObject;
        transform.Get<Button>("Container/DetailBg/Btn").SetButtonClick(() =>
        {
            EnterGameFunc(2);
        });
        transform.Get<Button>("Container/StartBg/Btn").SetButtonClick(() =>
        {
            EnterGameFunc(1);
        });
    }

    private void EnterGameFunc(int type)
    {
        if (type == 1)
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);
            if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockSeasonPassPopup))
            {
                dataService.AddFirstPopup(Constants.DoozyView.UnlockSeasonPassPopup);
                ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.UnlockSeasonPassPopup, BoxBuilder.ShowUnlockSeasonPassPopView, true);
            }
            BoxBuilder.HidePopup(gameObject);
        }
        else
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(Constants.ProductId.SeasonPass);
        }
    }
    
    public void SetType(string type)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass).ActivityBigEndTime);
        if (ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.SeasonPassProgress.ActivityEndTime);
        }
        timeItem.gameObject.SetActive(true);

        if (type == "start")
        {
            TitleText.text = "赛季通行证";
            TipText.text = "赛季通行证活动开始啦，收集幸运草来获得丰厚的奖励吧！";
        }
        else if (type == "detail")
        {
            TitleText.text = "赛季通行证";
            TipText.text = "购买黄金赛季通行证，有机会赚取以上丰厚的奖励！";
            UpdateDetail();
        }
        StartBg.SetActive(type == "start");
        DetailBg.SetActive(type == "detail");
        
        StopAllCoroutines();
        StartCoroutine(SetTimeItem(timeData));
        
        RefreshActivityTimer t = GameObjManager.Instance.PopClass<RefreshActivityTimer>(true);
        t.Init(ActivityType.seasonPass);
        TypeEventSystem.Send<RefreshActivityTimer>(t);
    }

    private void UpdateDetail()
    {
        ShopModel model = configService.ShopConfig[Constants.ProductId.SeasonPass];
        transform.Get<Text>("Container/DetailBg/Btn/Price").text = model.money.ToString();

        if (configService.ValueConfig.TryGetValue("SeasonPassShow", out string reward))
        {
            Dictionary<int, int> temp = GameUtils.AnalysisPropString(reward);

            foreach (var pair in temp)
            {
                if (pair.Key == (int)PropEnum.Coin)
                {
                    transform.Get<Text>("Container/DetailBg/Coin/NumText").text = pair.Value.ToString();
                    break;
                }
            }
            
        }
        
    }
    
    private void UpdatePanel(GameRechargeEvent obj)
    {
        TypeEventSystem.Send<SendUpdateSeasonRemid>();
        BoxBuilder.HidePopup(gameObject);
    }
    
    IEnumerator SetTimeItem(CountTimeData timeData)
    {
        while (!timeItem.gameObject.activeInHierarchy)
        {
            yield return null; 
        }
        timeItem.SetTimeData(timeData);
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnRefresh()
    {
        base.OnRefresh();
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<GameRechargeEvent>(UpdatePanel);

    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatePanel);
    }
    protected override async void OnShow()
    {

    }
    
}