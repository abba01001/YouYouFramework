using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Timers;
using Activities;
using DG.Tweening;
using QFramework;
using SoliUtils;
using UniRx;

public class PopCollectRewardView : ViewBase
{
    [SerializeField] private GameObject WaterPanel;
    [SerializeField] private GameObject HoneyPanel;
    [SerializeField] private List<GameObject> WaterPanelRewards;
    [SerializeField] private List<GameObject> HoneyPanelRewards;
    [SerializeField] private Button enterBtn;
    [SerializeField] private GameObject fakeStart;
    [SerializeField] private Animator _animator;
    private Dictionary<int, int> rewardDic;
    private ActivityType curAcType;
    private Action openAction;
    private Action finishAction;
    protected override void OnAwake()
    {
        enterBtn.SetButtonClick(GetReward);

    }

    public void SetParams(ActivityType activityType,Dictionary<int,int> rewards,Action startAction,Action endAction)
    {
        WaterPanel.gameObject.SetActive(activityType == ActivityType.collectWater);
        HoneyPanel.gameObject.SetActive(activityType == ActivityType.collectHoney);
        rewardDic = rewards;
        openAction = startAction;
        finishAction = endAction;
        curAcType = activityType;
        UpdateRewards(activityType);
    }

    private void GetReward()
    {
        List<GameObject> list = null;
        if (curAcType == ActivityType.collectWater)
        {
            list = WaterPanelRewards;
        }
        else if (curAcType == ActivityType.collectHoney)
        {
            list = HoneyPanelRewards;
        }
        if(list == null) return;
        
        int propIndex = 0;
        int oldGoldViewSortingOrder = GoldView.Instance.SortingOrder;
        enterBtn.interactable = false;
        enterBtn.GetComponent<CanvasGroup>().DOFade(0, 0.2f);
        if (!(rewardDic.Count == 1 && rewardDic.ContainsKey((int) PropEnum.Coin)))
        {
            fakeStart.gameObject.SetActive(true);
        }

        Vector3 endPos = fakeStart.transform.position;
        bool playGetSound = false;
        foreach (var item in rewardDic)
        {
            if(propIndex >= list.Count) break;
            Transform propTrans = list[propIndex].transform;
            propTrans.GetComponent<CanvasGroup>().DOFade(0, 0.5f);
            propTrans.DOScale(Vector3.one * 0.4f, 0.5f).SetEase(Ease.InCubic);
            if (item.Key == (int) PropEnum.Coin)
            {
                GoldView.Instance.SortingOrder = SortingOrder + 1;
                GameUtils.PlayGoldAnim(transform,(int)(dataService.Coin - item.Value),(int)dataService.Coin,propTrans,null);
            }
            else
            {
                Vector3 beginPos = propTrans.position;
                GameObject newImage = new GameObject(item.Key.ToString(), typeof(RectTransform));
                newImage.transform.SetParent(transform, false);
                newImage.transform.position = beginPos;
                newImage.AddComponent<Image>().LoadPropSprite(item.Key, false);
                bool isLeft = beginPos.x > endPos.x;
                Vector3 controlPos = (endPos + beginPos) / 2 +
                                     (isLeft ? new Vector3(-150, 500, 0) : new Vector3(150, 500, 0));
                newImage.transform
                    .DOPath(BezierUtils.GetBeizerList(beginPos, controlPos, endPos, 10),
                        0.8f + 0.2f * (rewardDic.Count - propIndex), PathType.CatmullRom, gizmoColor: Color.red)
                    .SetEase(Ease.InQuad).OnComplete(() =>
                    {
                        newImage.SetActive(false);
                        GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/daoju_anniu_tx_02.prefab",
                            (daojuFxTrans) => { daojuFxTrans.transform.position = fakeStart.transform.position; }, true,
                            2f);
                    });
                newImage.transform.DOScale(Vector3.one * 1.2f, 0.4f);
                newImage.transform.DOScale(Vector3.one * 0.7f, 0.4f).SetDelay(0.4f + 0.2f * propIndex);
                if (!playGetSound)
                {
                    playGetSound = true;
                    SoundPlayer.Instance.PlayMainSound("daoju_anniu_tx_01(Clone)");
                }
            }

            propIndex++;
        }

        float time = 0.8f + 0.2f * rewardDic.Count;
        Observable.Timer(TimeSpan.FromSeconds(Mathf.Max(time, 2))).Subscribe(_ =>
        {
            if (curAcType == ActivityType.collectWater)
            {
                if (ActivityManager.Instance.CollectWaterActivity.IsMaxLevel())
                {
                    dataService.CollectWaterProgress.FinishGetReward = true;
                }
            }
            else if (curAcType == ActivityType.collectHoney)
            {
                if (ActivityManager.Instance.CollectHoneyActivity.IsMaxLevel())
                {
                    dataService.CollectHoneyProgress.FinishGetReward = true;
                }
            }
            dataService.SaveData(true);
            GoldView.Instance.SortingOrder = oldGoldViewSortingOrder;
            BoxBuilder.HidePopup(gameObject);
        });
    }
    
    protected override void OnShow()
    {
        fakeStart.gameObject.SetActive(false);
        SoundPlayer.Instance.PlayMainSound("ani_CollectLoveCardBtn_01");
    }

    private void UpdateRewards(ActivityType acType)
    {
        List<GameObject> list = null;
        if (acType == ActivityType.collectWater)
        {
            list = WaterPanelRewards;
        }
        else if (acType == ActivityType.collectHoney)
        {
            list = HoneyPanelRewards;
        }
        if(list == null) return;
        foreach (var go in list)
        {
            go.MSetActive(false);
        }

        int id = 0;
        foreach (var pair in rewardDic)
        {
            if(id >= list.Count) break;
            list[id].gameObject.MSetActive(true);
            int propId = pair.Key;
            if (propId == (int) PropEnum.Coin) propId = (int) PropEnum.MultiplyCoin;

            var icon = list[id].Get<Image>("PropImage");
            icon.LoadPropSprite(pair.Key == (int)PropEnum.Coin ?(int)PropEnum.MultiplyCoin: pair.Key,true,
                () =>
                {
                    float targetHeight = 100;
                    float targetWidth = 80;
                    float originalWidth = icon.sprite.rect.width;
                    float originalHeight = icon.sprite.rect.height;
                    float aspectRatio = originalWidth / originalHeight;
                    float newWidth;
                    float newHeight;
                    if (originalHeight >= originalWidth)
                    {
                        newHeight = targetHeight;
                        newWidth = targetHeight * aspectRatio;
                    }
                    else
                    {
                        newWidth = targetWidth;
                        newHeight = targetWidth / aspectRatio;
                    }
                    icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
                });
            
            list[id].Get<Transform>("TimeText").gameObject.MSetActive(GameUtils.IsLimitTimeReward(pair.Key));
            list[id].Get<Text>("NumText").text = "";

            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                list[id].Get<Text>("TimeText").text = $"{pair.Value / 60}m";
            }
            else
            {
                list[id].Get<Text>("NumText").text = pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
            }
            id++;
        }
    }
}