using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Timers;
using Activities;
using DG.Tweening;
using QFramework;
using SoliUtils;
using UniRx;

public class PopRewardPopView : ViewBase
{
    [SerializeField] private Button closeBtn;
    [SerializeField] private GameObject rewardItem;
    [SerializeField] private Animator animator;
    [SerializeField] private Text Total;
    private Action finishCb;
    private int addVale = 0;
    private bool isShowingReward = false;
    private string rewardTitle = "恭喜你获得奖励!";
    private int oldGoldViewSortingOrder;
    private ActivityType acType;
    private PropEnum proEnum;
    private PlayGetLoveCardReward playGetLoveCardReward;
    private PlayGetMusicReward playGetMusicReward;
    private Vector3 startBtnPos;
    private Action endAction;
    private Action midAction;
    private Action startAction;
    protected override void OnAwake()
    {
        animator.enabled = false;
        // rewardItem.SetActive(false);
        closeBtn.SetButtonClick(() =>
        {
            if (acType == ActivityType.collectLoveCard)
            {
                GetLoveCardReward();
                closeBtn.interactable = false;
            }
            else if (acType == ActivityType.collectMusic)
            {
                GetMusicReward();
                closeBtn.interactable = false;
            }
        });
    }

    public void SetParams(Action startAction,Action midAction,Action endAction,params object[] args)
    {
        acType = (ActivityType) args[0];
        if (acType == ActivityType.collectLoveCard)
        {
            startAction ?.Invoke();
            this.startAction = startAction;
            this.midAction = midAction;
            this.endAction = endAction;
            playGetLoveCardReward = (PlayGetLoveCardReward) args[1];
            startBtnPos = (Vector3) args[2];
            SetLoveCardReward(false);
        }
        else if (acType == ActivityType.collectMusic)
        {
            startAction ?.Invoke();
            this.startAction = startAction;
            this.midAction = midAction;
            this.endAction = endAction;
            playGetMusicReward = (PlayGetMusicReward) args[1];
            startBtnPos = (Vector3) args[2];
            SetMusicReward(false);
        }
    }

    private void SetLoveCardReward(bool next)
    {
        Transform propItem = transform.Get<Transform>("Container/Content/NextRewardItem");
        propItem.gameObject.SetActive(true);
        List<SeasonLvRewardItem> list = next ? ActivityManager.Instance.CollectLoveCardActivity.GetNextReward() :  ActivityManager.Instance.CollectLoveCardActivity.GetCurReward();
        foreach (var tempItem in list)
        {
            int propEnum = int.Parse(tempItem.type.ToString());
            int propCount = tempItem.amount;
            Image propImage = propItem.transform.Get<Image>("PropImage");
            Text timeText = propItem.transform.Get<Text>("TimeText");
            Text numText = propItem.transform.Get<Text>("NumText");
            numText.text = "";
            timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward(propEnum));
            if (GameUtils.IsLimitTimeReward(propEnum))
            {
                long infiniteTime = propCount;
                timeText.text = infiniteTime / 60 + "m";
            }
            else
            {
                numText.text = propEnum == (int)PropEnum.Coin ? propCount.ToString() : $"x{propCount}";
            }
            propImage.LoadPropSprite(propEnum == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : propEnum);
            break;
        }
    }
    
    private void SetMusicReward(bool next)
    {
        Transform propItem = transform.Get<Transform>("Container/Content/NextRewardItem");
        propItem.gameObject.SetActive(true);
        Dictionary<int,int> list = next ? ActivityManager.Instance.CollectMusicActivity.GetNextReward() :  ActivityManager.Instance.CollectMusicActivity.GetCurReward();
        foreach (var pair in list)
        {
            Image propImage = propItem.transform.Get<Image>("PropImage");
            Text timeText = propItem.transform.Get<Text>("TimeText");
            Text numText = propItem.transform.Get<Text>("NumText");
            numText.text = "";
            timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward((int)pair.Key));
            if (GameUtils.IsLimitTimeReward((int)pair.Key))
            {
                long infiniteTime = pair.Value;
                timeText.text = infiniteTime / 60 + "m";
            }
            else
            {
                numText.text = pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
            }
            propImage.LoadPropSprite(pair.Key == (int)PropEnum.Coin ?(int) PropEnum.MultiplyCoin : (int)pair.Key);
            break;
        }
    }

    
    
    private void GetLoveCardReward()
    {
        if (playGetLoveCardReward.propEnum == (int)PropEnum.Coin)
        {
            transform.Get<Transform>("Container/Content/NextRewardItem").gameObject.SetActive(false);
            GameUtils.PlayGoldAnim(transform,(int)(dataService.Coin - playGetLoveCardReward.count),(int)dataService.Coin,transform.Find("Container/Root"),null);
        }
        else
        {
            animator.Play("ani_CollectLoveCardBtn_03", 0, 0);
            SoundPlayer.Instance.PlayMainSound("daoju_anniu_tx_01(Clone)");
            Observable.Timer(TimeSpan.FromSeconds(55f / 60)).Subscribe(_ =>
            {
                GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/daoju_anniu_tx_02.prefab",
                    (daojuFxTrans) => { daojuFxTrans.transform.position = startBtnPos; }, true, 2f);
            });
        }

        if (!ActivityManager.Instance.CollectLoveCardActivity.CurIsMaxLayer())
        {
            SoundPlayer.Instance.PlayMainSound("ani_CollectLoveCardBtn_02", 55f / 60);
        }

        Observable.Timer(TimeSpan.FromSeconds(65f / 60)).Subscribe(_ =>
        {
            if (ActivityManager.Instance.CollectLoveCardActivity.CurIsMaxLayer())
            {
                ActivityManager.Instance.FinishGetReward(ActivityType.collectLoveCard);
                BoxBuilder.HidePopup(gameObject);
                GameCommon.IsPlayingCollectAnim = false;
                return;
            }

            Observable.Timer(TimeSpan.FromSeconds(130f / 60)).Subscribe(_ =>
            {
                endAction?.Invoke();
                GameCommon.IsPlayingCollectAnim = false;
                BoxBuilder.HidePopup(gameObject);
                TypeEventSystem.Send<TriggrePopupEvent>();
            });
            SetLoveCardReward(true);
            animator.Play("ani_CollectLoveCardBtn_02", 0, 0);
        });
    }

    private void GetMusicReward()
    {
        if (playGetMusicReward.propEnum == (int)PropEnum.Coin)
        {
            int oldSort = GoldView.Instance.SortingOrder;
            GoldView.Instance.SortingOrder = SortingOrder + 50;
            transform.Get<Transform>("Container/Content/NextRewardItem").gameObject.SetActive(false);
            GoldView.Instance.ThreePowerBeizerFlyCoin((int)PropEnum.Coin, dataService.Coin - playGetMusicReward.count,
                dataService.Coin,
                Vector3.zero);
            Observable.Timer(TimeSpan.FromSeconds(1f)).Subscribe(_ => { GoldView.Instance.SortingOrder = oldSort; });
        }
        else
        {
            animator.Play("ani_CollectLoveCardBtn_03", 0, 0);
            SoundPlayer.Instance.PlayMainSound("daoju_anniu_tx_01(Clone)");
            Observable.Timer(TimeSpan.FromSeconds(55f / 60)).Subscribe(_ =>
            {
                GlobalRes.DynamicLoadPrefab("Assets/Res/Prefabs/FX/daoju_anniu_tx_02.prefab",
                    (daojuFxTrans) => { daojuFxTrans.transform.position = startBtnPos; }, true, 2f);
            });
        }

        if (!ActivityManager.Instance.CollectMusicActivity.CurIsMaxLayer())
        {
            SoundPlayer.Instance.PlayMainSound("ani_CollectLoveCardBtn_02", 55f / 60);
        }

        Observable.Timer(TimeSpan.FromSeconds(65f / 60)).Subscribe(_ =>
        {
            if (ActivityManager.Instance.CollectMusicActivity.CurIsMaxLayer())
            {
                ActivityManager.Instance.FinishGetReward(ActivityType.collectMusic);
                BoxBuilder.HidePopup(gameObject);
                GameCommon.IsPlayingCollectAnim = false;
                return;
            }

            Observable.Timer(TimeSpan.FromSeconds(130f / 60)).Subscribe(_ =>
            {
                endAction?.Invoke();
                GameCommon.IsPlayingCollectAnim = false;
                BoxBuilder.HidePopup(gameObject);
                TypeEventSystem.Send<TriggrePopupEvent>();
            });
            SetMusicReward(true);
            animator.Play("ani_CollectLoveCardBtn_02", 0, 0);
        });
    }

    protected override void OnShow()
    {
        animator.enabled = true;
        Observable.NextFrame().Subscribe(_ =>
        {
            animator.Play("ani_CollectLoveCardBtn_01", 0, 0);
        });
        SoundPlayer.Instance.PlayMainSound("ani_CollectLoveCardBtn_01");
    }
}