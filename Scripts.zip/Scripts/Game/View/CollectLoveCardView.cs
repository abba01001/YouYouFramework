﻿using Activities;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class CollectLoveCardView : ViewBase
{
    private Button closeBtn;
    private Button tipBtn;
    private RectTransform fillAmount;
    private Text progressText;
    private Transform nextRewardItem;
    private Dictionary<int, LoveCardItem> itemList;
    private ActivityTimeItem timeItem;
    
    [SerializeField] private EfficientScrollRect _scrollRect;
    [SerializeField] private GameObject loveCardItem;
    protected override void OnAwake()
    {
        itemList = new Dictionary<int, LoveCardItem>();
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(CloseFunc);
        tipBtn = transform.Get<Button>("Container/TipBtn");
        tipBtn.SetButtonClick(BoxBuilder.ShowUnlockCollectLoveCardPopView);
        nextRewardItem = transform.Get<Transform>("Container/Progress/NextRewardItem");
        fillAmount = transform.Get<RectTransform>("Container/Progress/FillAmount");
        progressText = transform.Get<Text>("Container/Progress/Text");
        loveCardItem.SetActive(false);
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
    }
    protected override void OnViewInit(bool isFirst)
    {
        if(isFirst)
        {
            TypeEventSystem.Register<UpdateRankViewEvent>(UpdatePanel);
        }

    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }
    
    //更新排行面板
    private void UpdatePanel(UpdateRankViewEvent obj)
    {

    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateRankViewEvent>(UpdatePanel);
    }

    protected override void OnShow()
    {
        InitPanel();
        StopAllCoroutines();
        StartCoroutine(SetTimeItem());
    }
    
    void StartInitItem()
    {
        _scrollRect.Init(GameObjType.LoveCardItem,loveCardItem, GetData());
    }
    
    object[] GetData()
    {
        Dictionary<int, List<SeasonLvRewardItem>> list = ActivityManager.Instance.CollectLoveCardActivity.GetRewardConfig();
        
        object[] data = new object[list.Count];
        int index = 0;
        foreach (var VARIABLE in list)
        {
            data[index] = VARIABLE.Value;
            index++;
        }
        return data;
    }

    IEnumerator SetTimeItem()
    {
        while (!timeItem.gameObject.activeInHierarchy)
        {
            yield return null; // 等待下一帧
        }
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).ActivityBigEndTime);
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.CollectLoveCardProgress.ActivityEndTime);
        }
        timeItem.SetTimeData(timeData);
    }

    private void InitPanel()
    {
        if (itemList.Count > 0) return;
        
        string title = "";
        string key = "";
        string bg = "";
        if (dataService.CollectLoveCardProgress.SubActivityType == 1)
        {
            key = "axfk_11";
            bg = "axfk_bj_1";
            title = "爱心方块收集活动";
        }
        else
        {
            key = "axfk_12";
            bg = "axfk_bj_2";
            title = "黑桃梅花收集活动";
        }
        transform.Get<Image>("Container/Progress/LastRewardItem/Icon")
            .SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectLoveCardAtlas, key, true);
        transform.Get<Text>("Container/Bg/TitleText").text = title;        
        transform.Get<Image>("Container/BottomBg").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectLoveCardAtlas, bg, true);
        
        StartInitItem();
        LocatePos();
        SetNextReward();
        SetProgress(ActivityManager.Instance.CollectLoveCardActivity.GetNextReward());
    }

    private void LocatePos()
    {
        _scrollRect.SetScrollPos(dataService.CollectLoveCardProgress.curLayer);
    }

    void SetProgress(List<SeasonLvRewardItem> nextReward)
    {
        int nextCount = ActivityManager.Instance.CollectLoveCardActivity.GetNextLayerCollectCount();
        int curCount = ActivityManager.Instance.CollectLoveCardActivity.GetCurLayerCollectCount();
        progressText.text = $"{curCount}/{nextCount}";
        fillAmount.sizeDelta = new Vector2(Mathf.Min(ActivityManager.Instance.CollectLoveCardActivity.GetRatio() * 659,659), fillAmount.sizeDelta.y);
    }
    
    private void SetNextReward()
    {
        if (ActivityManager.Instance.CollectLoveCardActivity.CurIsMaxLayer())
        {
            nextRewardItem.gameObject.SetActive(false);
            return;
        }
        nextRewardItem.gameObject.SetActive(true);
        foreach (var tempItem in ActivityManager.Instance.CollectLoveCardActivity.GetNextReward())
        {
            int prop_id = int.Parse(tempItem.type.ToString());
            int propCount = tempItem.amount;
            Image propImage = nextRewardItem.transform.Get<Image>("PropImage");
            Text timeText = nextRewardItem.transform.Get<Text>("TimeText");
            Text numText = nextRewardItem.transform.Get<Text>("NumText");
            numText.text = "";
            timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward(prop_id));
            if (GameUtils.IsLimitTimeReward(prop_id))
            {
                long infiniteTime = propCount;
                timeText.text = infiniteTime / 60 + "m";
            }
            else
            {
                numText.text = prop_id == (int)PropEnum.Coin ? propCount.ToString() : $"x{propCount}";
            }
            propImage.LoadPropSprite(prop_id == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : prop_id);
            break;
        }
    }
}
