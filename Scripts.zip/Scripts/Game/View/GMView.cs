﻿using Doozy.Engine.UI;
using QFramework;
using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Activities;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine;
using System.Globalization;
using System.IO;
using MiniJSON;
using SoliUtils;
using System.Threading;
using System.Security.Cryptography;
using System.Text;
using UnityEngine.Networking;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using Model;
using UniRx;

public class GMView : ViewBase
{
    Transform changeBackground;
    Transform setTimeScale;
    Transform winGame;
    Transform addGold;
    Transform addStar;
    Transform addProp;
    Transform levelInputField;
    Transform coverCardMultiple;
    Transform levelExperience;
    Transform addActivityCollect;
    Transform finishActivity;
    Transform netTime;
    private RawImage rankImg;

    const string White_Backdrop = "White";
    const string Green_Backdrop = "Green";


    private string SignWithHmacSha1(string key, string data)
    {
        using (var hmac = new HMACSHA1(Encoding.UTF8.GetBytes(key)))
        {
            byte[] hashValue = hmac.ComputeHash(Encoding.UTF8.GetBytes(data));
            return Convert.ToBase64String(hashValue);
        }
    }

    private string FormatDate(DateTime dateTime)
    {
        return dateTime.ToString("ddd, dd MMM yyyy HH:mm:ss 'GMT'", CultureInfo.InvariantCulture);
    }

    private bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain,
        SslPolicyErrors sslPolicyErrors)
    {
        return true;
    }

    protected override void OnAwake()
    {
        ServicePointManager.ServerCertificateValidationCallback = ValidateServerCertificate;

        reportOnShow = false;
        changeBackground = transform.Find("Container/Scroll View/Viewport/Layout/ChangeBackground");
        setTimeScale = transform.Find("Container/Scroll View/Viewport/Layout/SetTimeScale");
        winGame = transform.Find("Container/Scroll View/Viewport/Layout/WinGame");
        addGold = transform.Find("Container/Scroll View/Viewport/Layout/AddGold");
        addStar = transform.Find("Container/Scroll View/Viewport/Layout/AddStar");
        addProp = transform.Find("Container/Scroll View/Viewport/Layout/AddProp");
        levelInputField = transform.Find("Container/Scroll View/Viewport/Layout/InputLevel");
        addActivityCollect = transform.Find("Container/Scroll View/Viewport/Layout/AddActivityCollect");
        finishActivity = transform.Find("Container/Scroll View/Viewport/Layout/FinishActivity");
        netTime = transform.Find("Container/Scroll View/Viewport/Layout/NetTime");
        coverCardMultiple = transform.Find("Container/Scroll View/Viewport/Layout/CoverCardMultiple");
        levelExperience = transform.Find("Container/Scroll View/Viewport/Layout/LevelExperience");
        var toggle = transform.Get<Toggle>("Container/Scroll View/Viewport/Layout/TopUI/Toggle");
        var randomToggle = transform.Get<Toggle>("Container/Scroll View/Viewport/Layout/Random/Toggle");
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(CloseFunc);
        toggle.onValueChanged.AddListener(delegate { ToggleValueChanged(toggle); });
        randomToggle.onValueChanged.AddListener(delegate { RandomToggleValueChanged(toggle); });
        randomToggle.isOn = GameCommon.IsRandomMode;

        void showAvatar(string url)
        {
            var avatar = transform.Find("Avatar").GetComponent<Image>();
            GameUtils.GetAvatar(url, (ret, path) =>
                {
                    if (ret)
                    {
                        var tex = SpriteUtils.ReadTexture(path);
                        if (tex != null && avatar != null)
                        {
                            avatar.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
                        }
                    }
                });
        }

#if WEIXINMINIGAME && !UNITY_EDITOR
        if (string.IsNullOrEmpty(dataService.UserAvatar))
        {
            WeChatMiniGame.CheckWxAuthInfo((ret, path) =>
            {
                showAvatar(dataService.UserAvatar);
            });
        }
        else
        {
            showAvatar(dataService.UserAvatar);
        }
#else
        showAvatar(Constants.DefaultAvatarUrl);
#endif

        rankImg = transform.Find("Ranking").GetComponent<RawImage>();
        // CanvasScaler scaler = gameObject.GetComponent<CanvasScaler>();
        // var referenceResolution = scaler.referenceResolution;
        // var p = rank_img.transform.position;
        // WX.ShowOpenData(rank_img.texture, (int)p.x, Screen.height - (int)p.y,
        //     (int)((Screen.width / referenceResolution.x) * rank_img.rectTransform.rect.width),
        //     (int)((Screen.width / referenceResolution.x) * rank_img.rectTransform.rect.height));
        // WX.ShowOpenData(rankImg.texture, 0, 0, Screen.width, Screen.height);
        var testBtn = transform.Find("TestBtn").GetComponent<Button>();
        testBtn.onClick.AddListener(() =>
        {
            dataService.AddMergeLevelBox();
            
        });
    }

    protected override void OnViewDestroy()
    {
    }

    protected override void OnShow()
    {
        //#if !UNITY_EDITOR && !TestMode
        //        CloseFunc();
        //        return;
        //#endif
        bool isGaming = GameController.Instance.IsPlaying;
        InitChangeBackground();
        InitSetTimeScale();
        InitWinGame(isGaming);
        InitAddGold();
        InitAddStar(isGaming);
        InitAddPorp(isGaming);
        InitInputLevel(isGaming);
        InitFinishActivity(isGaming);
        InitNetTime(isGaming);
        InitAddActivityCollect(isGaming);
        InitCoverCardMultiple(isGaming);
        InitLevelExperience(isGaming);
    }

    private void CloseFunc()
    {
        BoxBuilder.HidePopup(gameObject);
    }

    private void InitChangeBackground()
    {
        changeBackground.gameObject.SetActive(true);
        Text nowConfigText = changeBackground.Get<Text>("NowText");
        string nowHomeBackStr = BackdropMono.Instance.GetNowBackdrop(false);
        if (GameUtils.GMmapId == 0)
        {
            GameUtils.GMmapId = dataService.FarmingProgress.curMapId;
            GameUtils.GMthemeId = dataService.FarmingProgress.curThemeId;
        }

        changeBackground.Get<Text>("ConfigBtn/Text").text = $"下一份配置";
        nowConfigText.text = $"当前地图Id:{GameUtils.GMmapId}主题Id:{GameUtils.GMthemeId}";
        changeBackground.Get<Button>("ConfigBtn").SetButtonClick(() =>
        {
            CheckMap();
            string str1 =
                $"Assets/Res/Textures/Background/Map{GameUtils.GMmapId}_{GameUtils.GMthemeId}/zdbj_{GameUtils.GMmapId}_{GameUtils.GMthemeId}.jpg";
            string str2 =
                $"Assets/Res/Textures/Background/Map{GameUtils.GMmapId}_{GameUtils.GMthemeId}/zybj_{GameUtils.GMmapId}_{GameUtils.GMthemeId}.jpg";
            nowConfigText.text = $"当前地图Id:{GameUtils.GMmapId}主题Id:{GameUtils.GMthemeId}";
            BackdropMono.Instance.SetBackdropDefault(str1, str2);
            CloseFunc();
            BoxBuilder.HidePopup(BoxBuilder.GetPopup(Constants.DoozyView.SettingPopup).gameObject);
        });

        changeBackground.Get<Button>("ResetBtn").SetButtonClick(() =>
        {
            GameUtils.GMmapId = dataService.FarmingProgress.curMapId;
            GameUtils.GMthemeId = dataService.FarmingProgress.curThemeId;
            string str1 =
                $"Assets/Res/Textures/Background/Map{GameUtils.GMmapId}_{GameUtils.GMthemeId}/zdbj_{GameUtils.GMmapId}_{GameUtils.GMthemeId}.jpg";
            string str2 =
                $"Assets/Res/Textures/Background/Map{GameUtils.GMmapId}_{GameUtils.GMthemeId}/zybj_{GameUtils.GMmapId}_{GameUtils.GMthemeId}.jpg";
            BackdropMono.Instance.SetBackdropDefault(str1, str2);
            CloseFunc();
            BoxBuilder.HidePopup(BoxBuilder.GetPopup(Constants.DoozyView.SettingPopup).gameObject);
        });
        changeBackground.Get<Button>("WhiteBtn").SetButtonClick(() =>
        {
            nowConfigText.text = "当前：" + White_Backdrop;
            BackdropMono.Instance.SetBackdropWhite();
        });

        changeBackground.Get<Button>("GreenBtn").SetButtonClick(() =>
        {
            nowConfigText.text = "当前：" + Green_Backdrop;
            BackdropMono.Instance.SetBackdropGreen();
        });
    }

    private void CheckMap()
    {
        GameUtils.GMthemeId++;
        if (GameUtils.GMthemeId > 3)
        {
            GameUtils.GMthemeId = 1;
            GameUtils.GMmapId++;
        }

        if (GameUtils.GMmapId > 3)
        {
            GameUtils.GMmapId = 1;
        }
    }

    private void InitSetTimeScale()
    {
        setTimeScale.gameObject.SetActive(true);
        InputField input = setTimeScale.Get<InputField>("InputField");
        Text nowConfigText = setTimeScale.Get<Text>("NowScaleText");
        nowConfigText.text = "当前：" + Time.timeScale;

        setTimeScale.Get<Button>("SetBtn").SetButtonClick(() =>
        {
            string numStr = input.text;
            if (string.IsNullOrEmpty(numStr)) return;
            float num = 0;
            try
            {
                num = Convert.ToSingle(numStr);
            }
            catch
            {
                return;
            }

            if (num >= 0 && num <= 5.0001f)
                Time.timeScale = num;
            nowConfigText.text = "当前：" + Time.timeScale;
        });
    }

    private void InitWinGame(bool isGaming)
    {
        winGame.gameObject.SetActive(isGaming);
        if (!isGaming) return;
        InputField input = winGame.Get<InputField>("InputField");
        winGame.Get<Button>("WinBtn").SetButtonClick(() =>
        {
            string numStr = input.text;
            int num = 3;
            if (!string.IsNullOrEmpty(numStr))
            {
                try
                {
                    num = Convert.ToInt32(numStr);
                }
                catch
                {
                }
            }

            if (num < 0) num = 0;


            // GameController.Instance.BattleCtrl.gameData.BattleIntegral =
            //     configService.GetStarIntegralRatio()[Math.Clamp(num, 1, 3)];
            TypeEventSystem.Send<GM_WinGame>(new GM_WinGame(num));
            TypeEventSystem.Send<PlayGameExitAnim>();
            CloseFunc();
        });
    }

    private void InitAddGold()
    {
        addGold.gameObject.SetActive(true);
        InputField input = addGold.Get<InputField>("InputField");
        addGold.Get<Button>("AddBtn").SetButtonClick(() =>
        {
            string numStr = input.text;
            if (string.IsNullOrEmpty(numStr)) return;
            long num = 0;
            try
            {
                num = Convert.ToInt64(numStr);
            }
            catch
            {
                return;
            }

            if (num >= 0)
            {
                dataService.AddCoin(num, PropChangeWay.GM);
                dataService.PiggyData.AddPiggyCoin((int)num);
                dataService.PiggyData.UpdatePiggyCoin();
            }
            else
                dataService.ConsumeCoin(-num, PropChangeWay.GM);

            storageService.SaveData();
        });
        addGold.Get<Button>("SetBtn").SetButtonClick(() =>
        {
            string numStr = input.text;
            if (string.IsNullOrEmpty(numStr)) return;
            long num = 0;
            try
            {
                num = Convert.ToInt64(numStr);
            }
            catch
            {
                return;
            }

            long diffNum = num - dataService.Coin;
            if (diffNum >= 0)
            {
                dataService.AddCoin(diffNum, PropChangeWay.GM);
                dataService.PiggyData.AddPiggyCoin((int)num);
                dataService.PiggyData.UpdatePiggyCoin();
            }
            else
                dataService.ConsumeCoin(-diffNum, PropChangeWay.GM);

            storageService.SaveData();
        });
    }

    private void InitAddStar(bool isGaming)
    {
        addStar.gameObject.SetActive(!isGaming);
        if (isGaming) return;
        InputField input = addStar.Get<InputField>("InputField");
        addStar.Get<Button>("WithWheelBtn").SetButtonClick(() =>
        {
            string numStr = input.text;
            if (string.IsNullOrEmpty(numStr)) return;
            int num = Convert.ToInt32(numStr);
            if (num <= 0) return;
            dataService.AddProp((int)PropEnum.StageStar, num, PropChangeWay.GM);
            dataService.AddProp((int)PropEnum.WheelStar, num, PropChangeWay.GM);
            BackdropMono.Instance.SwitchBackdrop();
            FindObjectOfType<HomeView>().SendMessage("OnRefresh");
            storageService.SaveData();
        });
        addStar.Get<Button>("NotWheelBtn").SetButtonClick(() =>
        {
            string numStr = input.text;
            if (string.IsNullOrEmpty(numStr)) return;
            int num = Convert.ToInt32(numStr);
            if (num <= 0) return;
            dataService.AddProp((int)PropEnum.StageStar, num, PropChangeWay.GM);
            BackdropMono.Instance.SwitchBackdrop();
            FindObjectOfType<HomeView>().SendMessage("OnRefresh");
            storageService.SaveData();
        });
        addStar.Get<Button>("ReduceStarBtn").SetButtonClick(() =>
        {
            string numStr = input.text;
            if (string.IsNullOrEmpty(numStr)) return;
            int num = Convert.ToInt32(numStr);
            if (num <= 0) return;
            dataService.UseProp((int)PropEnum.StageStar, PropChangeWay.GM, num);
            BackdropMono.Instance.SwitchBackdrop();
            FindObjectOfType<HomeView>().SendMessage("OnRefresh");
            storageService.SaveData();
        });
    }

    private void InitAddPorp(bool isGaming)
    {
        addProp.gameObject.SetActive(!isGaming);
        if (isGaming) return;
        InputField itemInput = addProp.Get<InputField>("ItemInputField");
        InputField numInput = addProp.Get<InputField>("NumInputField");
        addProp.Get<Button>("AddBtn").SetButtonClick(() =>
        {
            string idStr = itemInput.text;
            string numStr = numInput.text;
            if (string.IsNullOrEmpty(numStr) || string.IsNullOrEmpty(idStr)) return;
            int id = Convert.ToInt32(idStr);
            long num = Convert.ToInt64(numStr);
            dataService.AddProp(id, num, PropChangeWay.GM);
            storageService.SaveData();
        });
        addProp.Get<Button>("SetBtn").SetButtonClick(() =>
        {
            string idStr = itemInput.text;
            string numStr = numInput.text;
            if (string.IsNullOrEmpty(numStr) || string.IsNullOrEmpty(idStr)) return;
            int id = Convert.ToInt32(idStr);
            long num = Convert.ToInt64(numStr);
            long diffNum = num - dataService.GetPropNum(id);
            if (diffNum >= 0)
                dataService.AddProp(id, diffNum, PropChangeWay.GM);
            else
                dataService.UseProp(id, PropChangeWay.GM, -diffNum);
            storageService.SaveData();
        });
    }


    private void InitInputLevel(bool isGaming)
    {
        levelInputField.gameObject.SetActive(!isGaming);
        if (isGaming) return;

        InputField input = levelInputField.Get<InputField>("InputField");
        levelInputField.Get<Button>("GotoBtn").SetButtonClick(() =>
        {
            string lvNum = input.text;
            int toLevel = dataService.MaxLevel;

            if (!string.IsNullOrWhiteSpace(lvNum))
                toLevel = Convert.ToInt32(lvNum);

            dataService.MaxLevel = toLevel;
            FindObjectOfType<HomeView>().SendMessage("OnShow");
            CloseFunc();
            storageService.SaveData();
        });
        levelInputField.Get<Button>("GotoEndlessBtn").SetButtonClick(() =>
        {
            if(ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state != ActivityState.underWay) return;
            string lvNum = input.text;
            int toLevel = ActivityManager.Instance.EndlessLevelActivity.GetMyData().level;

            if (!string.IsNullOrWhiteSpace(lvNum))
                toLevel = Convert.ToInt32(lvNum);

            int maxLevel = configService.GetStageConfig.Last().Value.id;
            toLevel = toLevel % maxLevel;
            
            ActivityManager.Instance.EndlessLevelActivity.GetMyData().level = toLevel;
            dataService.EndlessLevelProgress.ViewMaxLayer = toLevel;
            FindObjectOfType<HomeView>().SendMessage("OnShow");
            CloseFunc();
            storageService.SaveData();
        });
    }

    IEnumerator StartTimer()
    {
        while (true)
        {
            yield return new WaitForSeconds(1f);
            netTime.Get<Text>("Time/Text").text = ActivityManager.Instance.GetActivityNowDateTime().ToString();
        }
    }
    
    private void InitNetTime(bool isGaming)
    {
        netTime.gameObject.SetActive(!isGaming);
        if (isGaming) return;
        InputField monthInput = netTime.Get<InputField>("Month");
        monthInput.text = ActivityManager.Instance.GetActivityNowDateTime().Month.ToString();
        
        InputField dayInput = netTime.Get<InputField>("Day");
        dayInput.text = ActivityManager.Instance.GetActivityNowDateTime().Day.ToString();
        
        InputField hourInput = netTime.Get<InputField>("Hour");
        hourInput.text = ActivityManager.Instance.GetActivityNowDateTime().Hour.ToString();
        
        InputField minuteInput = netTime.Get<InputField>("Minute");
        minuteInput.text = ActivityManager.Instance.GetActivityNowDateTime().Minute.ToString();

        netTime.Get<Text>("Time/Text").text = ActivityManager.Instance.GetActivityNowDateTime().ToString();
        netTime.Get<Text>("RegisterDate/Text").text = TimeUtils.IntToDateTime(dataService.RegisterTime).ToString();
        netTime.Get<Text>("RegisterDay/Text").text = $"第{TimeUtils.GetRegisterDay(dataService.RegisterTime)}天";
        StartCoroutine("StartTimer");

        netTime.Get<Button>("GotoBtn").SetButtonClick(() =>
        {
            var month = int.Parse(monthInput.text);
            var day = int.Parse(dayInput.text);
            var hour = int.Parse(hourInput.text);
            var minute = int.Parse(minuteInput.text);

            DateTime tempDate = ActivityManager.Instance.GetActivityNowDateTime();
            DateTime newDate = new DateTime(tempDate.Year, month, day, hour, minute, 0, DateTimeKind.Local);
            int time = TimeUtils.DateTimeToLong(newDate);
            ActivityManager.Instance.OpereateServerTime(time);
            FindObjectOfType<HomeView>().SendMessage("OnShow");
            Observable.Timer(TimeSpan.FromSeconds(1.1f)).Subscribe(_ =>
            {
                TypeEventSystem.Send<RefreshActivityTimer>();
            });
            CloseFunc();
            BoxBuilder.HideSettingPopup();
        });
    }
    
    private void InitFinishActivity(bool isGaming)
    {
        finishActivity.gameObject.SetActive(!isGaming);
        if (isGaming) return;

        InputField input = finishActivity.Get<InputField>("InputField");
        input.text = "默认15秒";
        finishActivity.Get<Button>("FinishAll").SetButtonClick(() =>
        {
            Dropdown dropdown = finishActivity.Find("Dropdown").GetComponent<Dropdown>();
            string lvNum = input.text;
            int num = 15;
            if (!string.IsNullOrWhiteSpace(lvNum))
                num = Convert.ToInt32(lvNum);
            foreach (var info in dropdown.options)
            {
                ActivityType activityType = SelectActivity(info.text);
                if (ActivityManager.Instance.GetActivityByType(activityType).state == ActivityState.underWay)
                {
                    BaseActivityData data =
                        ActivityManager.Instance.GetActivityByType(activityType).localData as BaseActivityData;
                    data.ActivityEndTime = ActivityManager.Instance.GetActivitySeverTime() + num;
                    ActivityManager.Instance.SendRefreshActivityTimer(activityType);
                }
            }
            dataService.SaveData(true,true);
            FindObjectOfType<HomeView>().SendMessage("OnShow");
            CloseFunc();
            BoxBuilder.HideSettingPopup();
            storageService.SaveData();
        });
        finishActivity.Get<Button>("GotoBtn").SetButtonClick(() =>
        {
            Dropdown dropdown = finishActivity.Find("Dropdown").GetComponent<Dropdown>();
            int selectedOptionIndex = dropdown.value;
            string selectedOptionText = dropdown.options[selectedOptionIndex].text;
            ActivityType activityType = SelectActivity(selectedOptionText);
            string lvNum = input.text;
            int num = 15;
            if (!string.IsNullOrWhiteSpace(lvNum))
                num = Convert.ToInt32(lvNum);
            if (ActivityManager.Instance.GetActivityByType(activityType).state == ActivityState.underWay)
            {
                BaseActivityData data =
                    ActivityManager.Instance.GetActivityByType(activityType).localData as BaseActivityData;
                data.ActivityEndTime = ActivityManager.Instance.GetActivitySeverTime() + num;
                ActivityManager.Instance.SendRefreshActivityTimer(activityType);
            }

            FindObjectOfType<HomeView>().SendMessage("OnShow");
            CloseFunc();
            BoxBuilder.HideSettingPopup();
            storageService.SaveData();
        });
    }

    private ActivityType SelectActivity(string str,int num = 0)
    {
        ActivityType activityType = ActivityType.none;
        switch (str)
        {
            case "存钱罐":
                activityType = ActivityType.piggy;
                break;
            case "鲜花收集":
                activityType = ActivityType.collectFlower;
                break;
            case "红色/黑色纸牌收集":
                activityType = ActivityType.collectLoveCard;
                break;
            case "锦标赛":
                activityType = ActivityType.passRank;
                break;
            case "赛车赛":
                activityType = ActivityType.carRank;
                break;
            case "连胜活动":
                activityType = ActivityType.winStreak;
                break;
            case "无尽关卡":
                activityType = ActivityType.endlessLevel;
                break;
            case "快速10关挑战":
                activityType = ActivityType.levelPass;
                break;
            case "熔岩连胜":
                activityType = ActivityType.lavaPass;
                break;
            case "限时1V1对决":
                activityType = ActivityType.limitPk;
                break;
            case "赛季通行证":
                activityType = ActivityType.seasonPass;
                break;
            case "梯度礼包":
                activityType = ActivityType.gradientGift;
                break;
            case "每日广告":
                activityType = ActivityType.adReward;
                break;
            case "兔子连胜":
                activityType = ActivityType.rabbitGift;
                break;
            case "挖宝活动":
                activityType = ActivityType.digTreasure;
                break;
            case "收集音符":
                activityType = ActivityType.collectMusic;
                break;
            case "收集水滴":
                activityType = ActivityType.collectWater;
                break;
            case "收集蜂蜜":
                activityType = ActivityType.collectHoney;
                break;
            case "做饭活动":
                activityType = ActivityType.cookMeal;
                break;
            case "神秘种子活动":
                activityType = ActivityType.mysteriousSeed;
                break;
            case "1拖6礼包":
                activityType = ActivityType.giftDragSix;
                break;
            case "1拖2礼包":
                activityType = ActivityType.giftDragTwo;
                break;
            case "1拖1礼包":
                activityType = ActivityType.giftDragOne;
                break;
            case "1+1礼包":
                activityType = ActivityType.giftPlusOne;
                break;
            case "1+4礼包":
                activityType = ActivityType.giftPlusFour;
                break;
            
            case "神秘种子进度":
                ActivityManager.Instance.MysteriousSeedActivity.GMAddCount(num);
                break;
            case "做饭次数":
                ActivityManager.Instance.CookMealActivity.GMAddCount(num);
                break;
            case "水滴":
                ActivityManager.Instance.CollectWaterActivity.GMAddCount(num);
                break;
            case "蜂蜜":
                ActivityManager.Instance.CollectHoneyActivity.GMAddCount(num);
                break;
            case "音符数量":
                ActivityManager.Instance.CollectMusicActivity.GMAddCount(num);
                break;
            case "挖宝次数":
                ActivityManager.Instance.DigTreasureActivity.GMAddCount(num);
                break;
            case "赛季通行证积分":
                ActivityManager.Instance.SeasonPassActivity.GMAddIntegral(num);
                break;
            case "收集鲜花数":
                ActivityManager.Instance.CollectFlowerActivity.GMAddFlower(num);
                break;
            case "收集爱心方块牌数":
                ActivityManager.Instance.CollectLoveCardActivity.GMAddCount(num);
                break;
            case "1V1积分":
                ActivityManager.Instance.LimitPkActivity.GMAddCount(num);
                break;
            case "无尽关卡活动皇冠数":
                ActivityManager.Instance.EndlessLevelActivity.GMAddCount(num);
                break;
            case "快速10关挑战数":
                ActivityManager.Instance.LevelPassActivity.GMAddWinCount(num);
                break;
            case "熔岩挑战关卡数":
                ActivityManager.Instance.LavaPassActivity.GMAddWinCount(num);
                break;
            case "锦标赛奖杯数":
                ActivityManager.Instance.PassRankActivity.GMAddCupCount(num);
                break;
            case "赛车轮胎数":
                ActivityManager.Instance.CarRankActivity.GMAddCupCount(num);
                break;
            case "建造币":
                if (num >= 0)
                    dataService.AddBuildCoin(num, PropChangeWay.GM);
                else
                    dataService.ConsumeBuildCoin(-num, PropChangeWay.GM);
                break;
            case "每日广告次数":
                ActivityManager.Instance.AdRewardActivity.GMAddCount(num);
                break;
            case "兔子连胜次数":
                ActivityManager.Instance.RabbitGiftActivity.GMAddCount(num);
                break;
            case "幸运转盘通关数":
                ActivityManager.Instance.WheelActivity.GMAddCount(num);
                break;
            default:
                break;
        }
        return activityType;
    }
    
    private void InitAddActivityCollect(bool isGaming)
    {
        addActivityCollect.gameObject.SetActive(!isGaming);
        if (isGaming) return;

        InputField input = addActivityCollect.Get<InputField>("InputField");
        addActivityCollect.Get<Button>("GotoBtn").SetButtonClick(() =>
        {
            Dropdown dropdown = addActivityCollect.Find("Dropdown").GetComponent<Dropdown>();
            int selectedOptionIndex = dropdown.value;
            string selectedOptionText = dropdown.options[selectedOptionIndex].text;
            string lvNum = input.text;
            int num = 1;
            if (!string.IsNullOrWhiteSpace(lvNum))
                num = Convert.ToInt32(lvNum);
            SelectActivity(selectedOptionText,num);
            GameCommon.GMAddCollectResource = true;
            CloseFunc();
            BoxBuilder.HideSettingPopup();
            storageService.SaveData();
        });
    }

    private void InitCoverCardMultiple(bool isGaming)
    {
        InputField input = coverCardMultiple.Get<InputField>("InputField");
        Text NowNumText = coverCardMultiple.Get<Text>("NowNumText");
        NowNumText.text = $"当前：{GameCommon.CoverCardMultiple} {(isGaming ? "战斗中不允许修改" : "")}";
        coverCardMultiple.Get<Button>("GotoBtn").SetButtonClick(() =>
        {
            if (isGaming) return;
            string numStr = input.text;
            if (string.IsNullOrWhiteSpace(numStr)) return;
            GameCommon.CoverCardMultiple = Convert.ToSingle(numStr, CultureInfo.InvariantCulture);
            NowNumText.text = $"当前：{GameCommon.CoverCardMultiple}";
        });
    }

    private void InitLevelExperience(bool isGaming)
    {
        InputField input = levelExperience.Get<InputField>("InputField");
        Text NowNumText = levelExperience.Get<Text>("NowNumText");
        IDataService dataService = MainContainer.Container.Resolve<IDataService>();
        NowNumText.text = $"当前：{dataService.LevelExperienceValue} {(isGaming ? "战斗中不允许修改" : "")}";
        levelExperience.Get<Button>("GotoBtn").SetButtonClick(() =>
        {
            if (isGaming) return;
            string numStr = input.text;
            if (string.IsNullOrWhiteSpace(numStr)) return;
            dataService.LevelExperienceValue = Convert.ToInt32(numStr);
            NowNumText.text = $"当前：{dataService.LevelExperienceValue}";
            storageService.SaveData();
        });
    }

    void ToggleValueChanged(Toggle toggle)
    {
        TypeEventSystem.Send<GM_HideUI>(new GM_HideUI(toggle.isOn));
    }

    void RandomToggleValueChanged(Toggle toggle)
    {
        GameCommon.IsRandomMode = toggle.isOn;
    }
}