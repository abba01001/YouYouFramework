﻿using QFramework;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class GiftDragSixView : ViewBase
{
    private Text priceText;
    private Text timeText;
    private Transform itemParent;
    [SerializeField] private GameObject BigShopItem1;
    [SerializeField] private GameObject BigShopItem2;
    [SerializeField] private ActivityTimeItem timeItem;
    protected override void OnAwake()
    {
        transform.Get<Button>("Content/CloseBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(6);
            BoxBuilder.HidePopup(gameObject);
        });
    }

    protected override void OnViewInit(bool isFirst)
    {
        TypeEventSystem.Register<GameRechargeEvent>(UpdatPanel);
        TypeEventSystem.Register<HideGiftDragPopup>(ClosePanel);
    }

    private void UpdatPanel(GameRechargeEvent obj)
    {

    }
    
    private void ClosePanel(HideGiftDragPopup obj)
    {
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatPanel);
        TypeEventSystem.UnRegister<HideGiftDragPopup>(ClosePanel);
    }

    protected override void OnShow()
    {
        if (!dataService.CheckFirstPopup(Constants.DoozyView.GiftDragSixPopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.GiftDragSixPopup);
        }

        UpdateInfo();
        RefreshTimer();
    }

    void RefreshTimer()
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>(true);
        timeData.Clear();
        timeData.endTime = TimeUtils.IntToDateTime(dataService.GiftDragSixData.ActivityEndTime);
        timeItem.SetTimeData(timeData);
    }
    
    private void UpdateInfo()
    {
        string product_id = Constants.ProductId.GiftDragSix_6_1;
        if (dataService.GiftDragSixData.curIndex == 1)
        {
            product_id = Constants.ProductId.GiftDragSix_6_1;
        }
        else if (dataService.GiftDragSixData.curIndex == 2)
        {
            product_id = Constants.ProductId.GiftDragSix_6_2;
        }
        else
        {
            product_id = Constants.ProductId.GiftDragSix_6_3;
        }
        configService.ShopConfig.TryGetValue(product_id, out ShopModel model);
        if (model != null)
        {
            var buyBtn = BigShopItem1.Get<Button>("ProductContent/BuyBtn");
            buyBtn.SetButtonClick(() =>
            {
                SoundPlayer.Instance.PlayButton();
                PayUtils.RequestOrder(model.product_id);
            });
            buyBtn.gameObject.Get<Text>("Price").text = model.money.ToString();
            UpdateSHopItem(BigShopItem1.Get<Transform>("ProductContent/Reward"),GameUtils.AnalysisPropString(model.reward));
            UpdateSHopItem(BigShopItem2.Get<Transform>("ProductContent/Reward"),GameUtils.AnalysisPropString(model.rewardFree));
        }
    }

    private void UpdateSHopItem(Transform rewardParent,Dictionary<int,int> rewardDic)
    {
        for (int i = 0; i < rewardParent.childCount; i++)
        {
            rewardParent.GetChild(i).gameObject.SetActive(false);
        }
        int count = 0;
        foreach (var pair in rewardDic)
        {
            if (count >= rewardParent.childCount) break;
            var child = rewardParent.GetChild(count);
            child.gameObject.MSetActive(true);
            GameUtils.LoadPropSprite(child.Get<Image>($"PropImage"), pair.Key);
            child.Get<Transform>($"TimeText").gameObject.MSetActive(GameUtils.IsLimitTimeReward(pair.Key));
            child.Get<Text>($"NumText").text = "";
            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                child.Get<Text>($"TimeText").text = $"{pair.Value / 60}m";
            }
            else
            {
                child.Get<Text>("NumText").text = pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
            }
            count++;
        }
    }
}