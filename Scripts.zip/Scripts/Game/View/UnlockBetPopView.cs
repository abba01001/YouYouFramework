﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class UnlockBetPopView : ViewBase
{
    private GameObject unlockBetRoot;
    private GameObject guideRoot;
    private Transform betLayout;
    private Transform betUnlockItem;
    private Button continueBtn;
    private Button closeBtn;
    

    protected override void OnAwake()
    {
        unlockBetRoot = transform.Find("Container/UnlockBet").gameObject;
        guideRoot = transform.Find("Container/Guide").gameObject;
        betLayout = unlockBetRoot.transform.Find("BetLayout");
        betUnlockItem = unlockBetRoot.transform.Find("BetUnlockItem");
        continueBtn = transform.Get<Button>("Container/UnlockBet/ContinueBtn");
        closeBtn = transform.Get<Button>("Container/Guide/CloseBtn");
        betUnlockItem.gameObject.SetActive(false);
        continueBtn.interactable = false;
        closeBtn.interactable = false;
        SoundPlayer.Instance.PlayWheelEnd();
    }

    protected override void OnShow()
    {
        unlockBetRoot.SetActive(true);
        guideRoot.SetActive(false);

        int lastShowBetLevel = dataService.LastShowBetLevel;
        dataService.LastShowBetLevel = dataService.OpenBetLevel;
        for (int i = lastShowBetLevel + 1; i <= dataService.OpenBetLevel; i++)
        {
            Transform newItem = Instantiate(betUnlockItem, betLayout);
            newItem.gameObject.SetActive(true);
            BetModel betModel = configService.BetConfig[i];
            newItem.Get<Text>("BetText").text = "x" + betModel.bet;
        }

        continueBtn.interactable = true;
        continueBtn.SetButtonClick(() =>
        {
            if (lastShowBetLevel < 2 && dataService.OpenBetLevel >= 2)
                DoGuideAnim();
            else
                BoxBuilder.HidePopup(gameObject);
        });
    }

    public void DoGuideAnim()
    {
        unlockBetRoot.SetActive(false);
        guideRoot.SetActive(true);
        Sequence seq = DOTween.Sequence();
        foreach (Transform item in guideRoot.transform)
        {
            item.localScale = Vector3.zero;
            seq.Append(item.DOScale(Vector3.one, 0.5f).SetEase(Ease.OutCubic));
        }
        seq.AppendCallback(() => closeBtn.interactable = true);
        closeBtn.SetButtonClick(() => BoxBuilder.HidePopup(gameObject));
    }
}
