using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MergeShopAdapter : ListViewAdapter
{
    private Dictionary<int, GameObject> cellObjs = new Dictionary<int, GameObject>();

    public override int GetCount()
    {
        var dataService = MainContainer.Container.Resolve<IDataService>();
        MergeShopInfoModel info = dataService.GetMergeShopData();
        if(info == null)
            return 0;
        return info.items.Length;
    }

    public override void FillItemData(ListViewCell item, int cellindex)
    {
        item.FillData(cellindex);
        if(cellObjs.ContainsKey(cellindex))
            cellObjs[cellindex] = item.gameObject;
        else
            cellObjs.Add(cellindex, item.gameObject);
    }

    public override int GetCellPrefabIndex(int index)
    {
        return 0;
    }

    public GameObject GetCellObject(int celllidex)
    {
        cellObjs.TryGetValue(celllidex, out var cellObj);
        return cellObj;
    }

}