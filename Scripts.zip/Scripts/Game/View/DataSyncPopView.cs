using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using SoliUtils;

namespace View
{
    public class DataSyncPopView : ViewBase
    {
        [SerializeField] private DataItemComponent localData;
        [SerializeField] private DataItemComponent remoteData;

        private MainData _localData;
        private MainData _remoteData;
        private string _remoteGameDataStr;
        private int _nextBuildId;
        private long _remoteCoins;
        private long _remoteStars;
        private int _maxLevel;

        protected override async void OnAwake()
        {
            
        }

        protected override void OnShow()
        {
            
        }

        protected override void OnViewDestroy()
        {
            
        }

        private async Task InitRemoteData()
        {
            // _remoteGameDataStr = await FirebaseUtils.Instance.FirestoreGetUser();
            Debug.Log($">>> DataSyncPopView >> InitRemoteData >> gameDataStr:{_remoteGameDataStr}");
            var gameData = string.IsNullOrEmpty(_remoteGameDataStr) ? new Dictionary<string, object>() :
                (Dictionary<string, object>) MiniJSON.Json.Deserialize(_remoteGameDataStr);
            if (gameData.TryGetValue(Constants.StorageKey.UserInfoData, out var userInfoDataObj))
            {
                object tempObj;
                var userInfoData = (Dictionary<string, object>)userInfoDataObj;
                _maxLevel = userInfoData.TryGetValue(Constants.StorageKey.MaxLevel, out tempObj)
                    ? Convert.ToInt32(tempObj)
                    : 1;
                _nextBuildId = userInfoData.TryGetValue(Constants.StorageKey.NextBuildId, out tempObj)
                    ? Convert.ToInt32(tempObj)
                    : 1;
                if (userInfoData.TryGetValue(Constants.StorageKey.PropDic, out tempObj))
                {
                    var propDicData = (Dictionary<string, object>)tempObj;
                    var propDic = new Dictionary<int, long>(propDicData.Count);
                    foreach (var pair in propDicData)
                    {
                        if ((int) Convert.ToInt32(pair.Key) == (int)PropEnum.Coin) _remoteCoins = Convert.ToInt32(pair.Value);
                        if ((int) Convert.ToInt32(pair.Key) == (int)PropEnum.StageStar) _remoteStars = Convert.ToInt32(pair.Value);
                    }
                }
                else
                {
                    InitDefaultData();
                }
            }
            else
            {
                InitDefaultData();
            }
        }

        private void InitDefaultData()
        {
            foreach (var pair in GameUtils.AnalysisPropString(configService.OriginalItem))
            {
                if ((int) Convert.ToInt32(pair.Key) == (int)PropEnum.Coin) _remoteCoins = Convert.ToInt32(pair.Value);
                if ((int) Convert.ToInt32(pair.Key) == (int)PropEnum.StageStar) _remoteStars = Convert.ToInt32(pair.Value);
            }
            _nextBuildId = 1;
            _maxLevel = 1;
        }
    }

    public class MainData
    {
        public bool isRemote;
        public long coins;
        public long stars;
        public int stage;
        public int garden;
        public string remoteJson;
        
        public MainData(){}

        public MainData(bool isRemote, long coins, long stars, int stage, int garden, string remoteJson = "")
        {
            this.isRemote = isRemote;
            this.coins = coins;
            this.stars = stars;
            this.stage = stage;
            this.garden = garden;
            this.remoteJson = remoteJson;
        }
    }
}