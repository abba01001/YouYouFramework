using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using System;
using SoliUtils;
using UniRx;

public class CheckInView : ViewBase
{
    private const int GridCount = 9;

    [SerializeField] private Button claimBtn;
    [SerializeField] private Transform signPanle;
    [SerializeField] private GameObject showFx;
    [SerializeField] private GameObject Mask;
    [SerializeField] private Transform Title;
    private bool isSelect = false;
    private float elaspTime;
    private bool stopAnim = false;
    private Dictionary<int,Transform> gridDIc = new Dictionary<int, Transform>();
    protected override void OnShow()
    {
        Mask.SetActive(false);
        SoundPlayer.Instance.PlayMainSound("Pop_CheckIn");
        showFx.SetActive(false);
        for (int i = 1; i <= GridCount; i++)
        {
            int index = i;
            Transform gridBtn = signPanle.transform.Find("GridPanel/Grid" + index);
            gridDIc.Add(index,gridBtn);
            gridBtn.GetComponent<DOTweenAnimation>().DOComplete();
            gridBtn.Get<Button>("RewardBG").SetButtonClick(() =>
            {
                SignIn(index);
            });
            Observable.Timer(TimeSpan.FromSeconds(0.7f + index * 0.1)).Subscribe(_=>
            {
                gridBtn.Find("Guide").gameObject.SetActive(true);
            });
            gridBtn.Find("RewardBG").GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCheckInAtlas,"mrfl_1",true);
            Transform rewardLayout = gridBtn.Find("RewardLayout");
            foreach (Transform item in rewardLayout)
                item.gameObject.SetActive(false);
        }
        RandomVibrate();
    }

    private void Update()
    {
        elaspTime += Time.deltaTime;
        if (elaspTime > 2 && !stopAnim)
        {
            RandomVibrate();
            elaspTime = 0;
        }
    }

    private void RandomVibrate()
    {
        int index = GameUtils.RandomRange(1, 10);
        gridDIc[index].GetComponent<DOTweenAnimation>().DORestart();
        SoundPlayer.Instance.PlayMainSound("Tip_Shake");
    }

    private (Dictionary<int, int> rewardDic, List<Dictionary<int, int>> leftRewardList) GetReward()
    {
        Dictionary<int, int> rewardDic = new Dictionary<int, int>();
        float totalWeight = 0;
        float randomValue = GameUtils.RandomRange(0, 1f);
        // GameUtils.Shuffle


        int id = -1;
        foreach (var pair in configService.SignInConfig)
        {
            totalWeight += pair.Value.weight;
            if (totalWeight > randomValue)
            {
                id = pair.Key;
                rewardDic = GameUtils.AnalysisPropString(configService.SignInConfig[pair.Key].reward);
                break;
            }
        }

        List<Dictionary<int, int>> leftRewardList = new List<Dictionary<int, int>>();
        foreach (var pair in configService.SignInConfig)
        {
            if (pair.Key != id)
            {
                leftRewardList.Add(GameUtils.AnalysisPropString(configService.SignInConfig[pair.Key].reward));
            }
        }
        GameUtils.Shuffle(leftRewardList);
        return (rewardDic,leftRewardList);
    }
    
    private void SignIn(int selectGridIndex)
    {
        if(isSelect) return;
        isSelect = true;
        SoundPlayer.Instance.PlayMainSound("CheckIn_Click");
        var (rewardDic, leftRewardList) = GetReward();
        
        foreach (var pair in rewardDic)
        {
            Transform gridBtn = gridDIc[selectGridIndex];
            var item = gridDIc[selectGridIndex].Find($"RewardLayout/item1");
            item.gameObject.SetActive(true);
            var propImage = item.Find("RewardImage").GetComponent<Image>();
            
            propImage.LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : pair.Key,false, () =>
            {
                propImage.color = Color.white;
                gridBtn.Find("RewardLayout").gameObject.SetActive(true);
            });
            if (GameUtils.PropSizeDic.TryGetValue(pair.Key, out Vector2 value))
            {
                propImage.GetComponent<RectTransform>().sizeDelta = GameUtils.PropSizeDic[pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : pair.Key] * 0.6f;
            }
            else
            {
                propImage.GetComponent<RectTransform>().sizeDelta = 240f * Vector2.one * 0.6f;
            }

            item.Find("Infinite").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
            Text rewardNumText = item.Get<Text>("RewardText");
            rewardNumText.text = GameUtils.IsLimitTimeReward(pair.Key) ? $"{pair.Value / 60}分钟" : $"x{pair.Value}";
            break;
        }
        
        Sequence seq = DOTween.Sequence();
        seq.AppendCallback(() =>
        {
            Transform gridBtn = gridDIc[selectGridIndex];
            Canvas canvas = gridBtn.Find("RewardLayout/item1").gameObject.AddComponent<Canvas>();
            canvas.overrideSorting = true;
            canvas.sortingOrder = SortingOrder + 100;
            canvas.sortingLayerName = "UI";
            gridBtn.transform.DOScale(Vector3.one * 1.25f, 0.2f).SetEase(Ease.OutCubic);
            gridBtn.Find("RewardBG").GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCheckInAtlas,"mrfl_2",true);
            showFx.transform.SetParent(gridBtn.Find("RewardLayout"));
            showFx.transform.localPosition = Vector3.zero;
            showFx.SetActive(true);
            transform.Get<Image>("Overlay").color = Color.clear;
            Mask.gameObject.SetActive(true);
            Title.SetParent(Mask.transform);
            gridBtn.SetParent(Mask.transform);
        });
        seq.AppendInterval(0.4f);
        seq.AppendInterval(HandleLeft(leftRewardList, selectGridIndex).Duration() + 0.8f);
        seq.AppendCallback(() =>
        {
            PopupQueueManager.Instance.AddPopupTask(Constants.DoozyView.RewardPopup, () =>
            {
                BoxBuilder.ShowRewardPop(rewardDic, PropChangeWay.SignIn);
            },true,1);
            Observable.TimerFrame(6).Subscribe(_ =>
            {
                BoxBuilder.HidePopup(gameObject);
            });
            dataService.AddDailyFlag(FlagType.SignIn);
        });
        stopAnim = true;
        SoundPlayer.Instance.PlayButton();
    }

    Tween HandleLeft(List<Dictionary<int, int>> leftRewardList,int selectGridIndex)
    {
        int index = 0;
        Sequence seq = DOTween.Sequence();
        foreach (var grid in gridDIc)
        {
            if(grid.Key == selectGridIndex) continue;
            seq.AppendCallback(() =>
            {
                Transform gridBtn = grid.Value;
                gridBtn.Find("RewardBG").GetComponent<Image>()
                    .SetSpriteByAtlas(Constants.AtlasNamePath.ViewCheckInAtlas, "mrfl_2", true);
                var item = grid.Value.Find($"RewardLayout/item1");
                item.gameObject.SetActive(true);

                if (index < leftRewardList.Count)
                {
                    foreach (var pair in leftRewardList[index])
                    {
                        var propImage = item.Find("RewardImage").GetComponent<Image>();
                        propImage.LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : pair.Key, false,
                            () =>
                            {
                                propImage.color = Color.white;
                                gridBtn.Find("RewardLayout").gameObject.SetActive(true);
                            });
                        
                        if (GameUtils.PropSizeDic.TryGetValue(pair.Key, out Vector2 value))
                        {
                            propImage.GetComponent<RectTransform>().sizeDelta = GameUtils.PropSizeDic[pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : pair.Key] * 0.6f;
                        }
                        else
                        {
                            propImage.GetComponent<RectTransform>().sizeDelta = 240f * Vector2.one * 0.6f;
                        }
                        item.Find("Infinite").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
                        Text rewardNumText = item.Get<Text>("RewardText");
                        rewardNumText.text = GameUtils.IsLimitTimeReward(pair.Key) ? $"{pair.Value / 60}分钟" : $"x{pair.Value}";
                    }

                    index++;
                }
            });
            seq.AppendInterval(0.1f);
        }
        return seq;
    }
    
}
