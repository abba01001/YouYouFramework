﻿using Doozy.Engine;
using Doozy.Engine.UI;
using UnityEngine.UI;
using QFramework;
using SoliUtils;

public class GameResultView : ViewBase
{
    protected override void OnAwake()
    {
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(CloseFunc);
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.ShowSceneChangePop(() =>
        {
            TypeEventSystem.Send(new BattleCommandEvent() { command = BattleCommand.LoseGame });
            GameEventMessage.SendEvent(Constants.DoozyEvent.GameEnd);
            BoxBuilder.HidePopup(gameObject);
        }, BoxBuilder.HideSceneChangePop);
    }
    
    protected override void OnShow()
    {

    }
}
