using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;

[RequireComponent(typeof(CanvasGroup))]
public class StartLevelPassPopView : ViewBase
{
    private Button CloseBtn;
    private GameObject CollectLoveCardContent;
    private ActivityTimeItem timeItem;
    private Action startGame;

    protected override void OnAwake()
    {
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        CloseBtn.SetButtonClick(CloseFunc);
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(EnterGameFunc);
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        InitPanel();
    }

    private void InitPanel()
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).ActivityBigEndTime);
        if (ActivityManager.Instance.GetActivityByType(ActivityType.levelPass).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.LevelPassProgress.ActivityEndTime);
        }
        dataService.LevelPassProgress.PopBtn = false;

        StopAllCoroutines();
        StartCoroutine(SetTimeItem(timeData));
        RefreshActivityTimer t = GameObjManager.Instance.PopClass<RefreshActivityTimer>(true);
        t.Init(ActivityType.levelPass);
        TypeEventSystem.Send<RefreshActivityTimer>(t);
    }

    IEnumerator SetTimeItem(CountTimeData timeData)
    {
        while (!timeItem.gameObject.activeInHierarchy)
        {
            yield return null; 
        }
        timeItem.SetTimeData(timeData);
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;

    }

    protected override void OnInitedDestroy()
    {

    }

    private void EnterGameFunc()
    {
        if (GameCommon.IsShowingStartGamePopup)
        {
            BoxBuilder.ShowLevelPassPopup(true);
        }
        else
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.LevelPassPopup,()=>BoxBuilder.ShowLevelPassPopup(true),true);
        }
        CloseFunc();
        dataService.LevelPassProgress.UserActivative = true;
        RefreshActivityTimer t = GameObjManager.Instance.PopClass<RefreshActivityTimer>(true);
        t.Init(ActivityType.levelPass);
        TypeEventSystem.Send<RefreshActivityTimer>(t);
    }
}