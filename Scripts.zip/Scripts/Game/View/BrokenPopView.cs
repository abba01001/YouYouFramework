using System.Collections;
using System.Collections.Generic;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class BrokenPopView : ViewBase
{
    private string productKey = "";
    private Transform itemParent;
    [SerializeField]private List<Transform> itemList;
    [SerializeField]private Transform coinItem;
    public void SetGiftType(string ProductId)
    {
        productKey = ProductId;
        UpdateRewardItem();
    }

    
    void CloseFunc(GameRechargeEvent e = null)
    {
        BoxBuilder.HidePopup(gameObject);
    }
    
    protected override void OnViewInit(bool isFirstTime)
    {
        if (isFirstTime)
        {
            TypeEventSystem.Register<GameRechargeEvent>(CloseFunc);
        }
    }

    protected override void OnViewDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(CloseFunc);
    }

    private void UpdateRewardItem()
    {
        if(productKey == "") return;
        int index = 0;
        coinItem.gameObject.SetActive(false);
        foreach (var pair in itemList)
        {
            pair.gameObject.SetActive(false);
        }

        ShopModel model = configService.ShopConfig[productKey];
        transform.Get<Text>("Container/BuyBtn/Price").text = model.money.ToString();

        index = 0;
        foreach (var pair in GameUtils.AnalysisPropString(model.reward))
        {
            Transform item = pair.Key == (int)PropEnum.Coin ? coinItem : itemList[index];
            if(item == null) break;
            item.gameObject.SetActive(true);
            item.Get<Image>("Icon").LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : pair.Key,false);
            item.Get<Text>("Value").text = "";
            item.Get<Text>($"TimeText").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                item.Get<Text>($"TimeText").text = $"{pair.Value / 60}:00";
            }
            else
            {
                item.Get<Text>($"Value").text = pair.Value.ToString();
            }
            if(pair.Key != (int)PropEnum.Coin) index++;
        }
    }
    
    protected override void OnShow()
    {
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(() => CloseFunc());
        transform.Get<Button>("Container/BuyBtn").SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayButton();
            PayUtils.RequestOrder(productKey);
        });
        UpdateRewardItem();
        // if (configService.BrokenReceiveDailyTimes <= dataService.TodayBrokenReceiveTime)
        // {
        //     BoxBuilder.HidePopup(gameObject);
        //     return;
        // }
    }
}
