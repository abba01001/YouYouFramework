using Doozy.Engine.UI;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using SoliUtils;

namespace View
{
    public class SignOutConfirmPopView : ViewBase
    {
        [SerializeField] private Button YesBtn;
        [SerializeField] private Button NoBtn;
        
        private UIPopup _uiPopup;
        private UnityAction _yesCall;
        
        protected override void OnAwake()
        {
            _uiPopup = GetComponent<UIPopup>();
            YesBtn.SetButtonClick(OnYesBtnClick);
            NoBtn.SetButtonClick(OnNoBtnClick);
        }

        public void SetYesBtnCall(UnityAction call)
        {
            _yesCall = call;
        }

        private void OnYesBtnClick()
        {
            _uiPopup.Hide();
            BoxBuilder.ShowSignOutSuccessPopup();
            _yesCall?.Invoke();
        }
        
        private void OnNoBtnClick()
        {
            _uiPopup.Hide();
        }
    }
}