﻿using Activities;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using DG.Tweening;
using Doozy.Engine.UI.Base;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;
using UnityEngine.Rendering;
using UIEffect = Coffee.UIExtensions.UIEffect;

public class CookMealView : ViewBase
{
    private Button closeBtn;
    private Button continueBtn;
    private Animator selfAnim;
    private GameObject finishPanel;
    private GameObject finishMeal;
    private GameObject finishMealEf;
    private Button tipBtn;
    private Image coinFill;
    private Text coinText;
    private ActivityTimeItem timeItem;
    [SerializeField] private List<GameObject> diceList;
    [SerializeField] private List<GameObject> orderList = new List<GameObject>();
    [SerializeField] private List<GameObject> flyMaterialList = new List<GameObject>();
    [SerializeField] private Text countText;
    [SerializeField] private GameObject iconEf;
    [SerializeField] private List<GameObject> rewardList = new List<GameObject>();
    [SerializeField] private GameObject tripplEf;
    private List<List<Image>> DiceImageList = new List<List<Image>>();
    private List<List<int>> RandomList = new List<List<int>>();//骰子6个面对应的贴图索引
    private Dictionary<int,GameObject> MaterialDic = new Dictionary<int,GameObject>();
    private CookMealModel curMealModel;
    private bool changeCoin = false;
    private bool isPlayingDice = false;
    private GameObjectData goldRootData = null;
    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(CloseFunc);
        selfAnim = transform.GetComponent<Animator>();
        tipBtn = transform.Get<Button>("Container/TipBtn");
        tipBtn.SetButtonClick(BoxBuilder.ShowUnlockCookMeal);
        coinFill = transform.Get<Image>("Container/CoinProgress/Value");
        coinText = transform.Get<Text>("Container/CoinProgress/Coin/Value");
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        continueBtn = transform.Get<Button>("FinishPanel/CloseBtn");
        continueBtn.SetButtonClick(CloseFinishPanel);
        finishPanel = transform.Get<Transform>("FinishPanel").gameObject;
        finishPanel.gameObject.SetActive(false);
        finishMeal = transform.Get<Transform>("FinishMeal").gameObject;
        finishMeal.gameObject.SetActive(false);
        finishMealEf = transform.Get<Transform>("tx").gameObject;
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(DiceFunc);
        transform.Get<Canvas>("Container/DicePanel").sortingLayerName = "UI";
        transform.Get<Canvas>("Container/DicePanel").sortingOrder += SortingOrder + 2;
        transform.Get<SortingGroup>("Container/DicePanel").sortingOrder += SortingOrder + 1;
    }

    private void DiceFunc()
    {
        if (isPlayingDice) return;
        ActivityManager.Instance.CookMealActivity.Dice(() =>
        {
            isPlayingDice = true;
            var startValue = int.Parse(countText.text);
            var endValue = ActivityManager.Instance.CookMealActivity.GetCookCount();
            DOTween.To(() => startValue, x => {startValue = Mathf.RoundToInt(x);countText.text = startValue.ToString();}, endValue, 0.5f);
            int index = 0;
            List<int> finalMaterials = ActivityManager.Instance.CookMealActivity.GetFinalMaterial();
            foreach (var go in diceList)
            {
                int diceIndex = index;
                Animator animator = go.Get<Animator>("dice");
                GameUtils.PlayAnimation(animator, "ani_dice_roll", 0);
                List<int> material1 = null;
                Observable.TimerFrame(index).Subscribe(_ =>
                    material1 = GetRandomMaterials(diceIndex, 3, finalMaterials[diceIndex]));
                Observable.TimerFrame(6).Subscribe(_ => UpdateDiceImage(diceIndex, material1));
                index++;
            }
            Observable.TimerFrame(90).Subscribe(_ => PlayFlyMaterialAnim());
        }, () =>
        {
            BoxBuilder.ShowGiftBuyItemPopup(ActivityType.cookMeal);
        });
    }

    private void PlayFlyMaterialAnim()
    {
        bool special = RandomList[0][0] == RandomList[1][0] && RandomList[0][0]  == RandomList[2][0];
        float tweenTime = special ? SpecialFly() : NormalFly();
        Observable.Timer(TimeSpan.FromSeconds(tweenTime)).Subscribe(_ =>
        {
            changeCoin = false;
            if (!ActivityManager.Instance.CookMealActivity.CheckJumpNextLayer())
            {
                isPlayingDice = false;
            }
        });
    }

    //3倍飞行
    private float SpecialFly()
    {
        float firstFlyTime = 0.3f;//第一次向上飞行时间
        float secondFlyTime = 0.5f;//第二次飞到目标时间
        for (int i = 0; i < 3; i++)
        {
            int index = i;
            float delayFlyTime = index == 0 ? 0f : index == 1 ? 0.05f : 0.1f;//延迟飞行时间
            Vector3 orignPos = flyMaterialList[index].transform.position;
            flyMaterialList[index].transform.DOScale(Vector3.one * 1.25f, firstFlyTime).SetEase(Ease.InSine);
            flyMaterialList[index].GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas,
                "zc_sc_" + RandomList[index][0]);
            PlayFlyItem(flyMaterialList[index], flyMaterialList[1].transform.position + new Vector3(0, 80, 0),
                false, firstFlyTime, delayFlyTime,
                null, () =>
                {
                    flyMaterialList[index].SetActive(false);
                    tripplEf.SetActive(true);
                    tripplEf.Get<Image>("reward").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas,
                        "zc_sc_" + RandomList[index][0]);
                    GameUtils.PlayAnimation(selfAnim,"ani_CookMeal_Triple_01",0, () =>
                    {
                        tripplEf.SetActive(false);
                        flyMaterialList[index].transform.DOScale(Vector3.one * 0.75f, secondFlyTime).SetEase(Ease.InSine);
                        Vector3 finalPos = GetFlyTargetPos(index);
                        PlayFlyItem(flyMaterialList[index], finalPos, true, secondFlyTime, 0, null, () =>
                        {
                            flyMaterialList[index].SetActive(false);
                            flyMaterialList[index].transform.position = orignPos;
                            flyMaterialList[index].transform.localScale = Vector3.one;
                            FlyCallBack(index);
                        });
                    },false);
                });
        }
        return 3.5f;
    }

    //正常飞行
    private float NormalFly()
    {
        float firstFlyTime = 0.3f;//第一次向上飞行时间
        float secondFlyTime = 0.6f;//第二次飞到目标时间
        for (int i = 0; i < 3; i++)
        {
            int index = i;
            float delayFlyTime = index == 0 ? 0f : index == 1 ? 0.05f : 0.1f;//延迟飞行时间
            Vector3 orignPos = flyMaterialList[index].transform.position;
            flyMaterialList[index].transform.DOScale(Vector3.one * 0.75f, firstFlyTime).SetEase(Ease.InSine);
            flyMaterialList[index].GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas,
                "zc_sc_" + RandomList[index][0]);
            PlayFlyItem(flyMaterialList[index], flyMaterialList[index].transform.position + new Vector3(0, 80, 0),
                false, firstFlyTime, delayFlyTime,
                null, () =>
                {
                    Vector3 finalPos = GetFlyTargetPos(index);
                    PlayFlyItem(flyMaterialList[index], finalPos, true, secondFlyTime, delayFlyTime =0.2f, null, () =>
                    {
                        flyMaterialList[index].SetActive(false);
                        flyMaterialList[index].transform.position = orignPos;
                        flyMaterialList[index].transform.localScale = Vector3.one;
                        FlyCallBack(index);
                    });
                });
        }
        return 2.5f;
    }

    private void UpdateFinalReward()
    {
        foreach (var go in rewardList)
        {
            go.MSetActive(false);
        }

        int index = 0;
        foreach (var pair in GameUtils.AnalysisPropString(curMealModel.reward))
        {
            var obj = rewardList[index];
            var icon = obj.Get<Image>("RewardIcon");
            GameUtils.LoadPropSprite(icon,pair.Key);
            obj.Get<Transform>("TimeText").gameObject.MSetActive(GameUtils.IsLimitTimeReward(pair.Key));
            obj.Get<Text>("RewardNum").text = "";
            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                obj.Get<Text>("TimeText").text = $"{pair.Value / 60}m";
            }
            else
            {
                obj.Get<Text>("RewardNum").text = pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
            }
            
            obj.MSetActive(true);
            index++;
        }
    }
    
    private Vector3 GetFlyTargetPos(int index)
    {
        Vector3 targetPos = Vector3.zero;
        CookMealModel model = GetDiceMealSuit();
        MealMaterialType matType = (MealMaterialType) RandomList[index][0];

        if (matType == MealMaterialType.Coin)
        {
            targetPos = goldRootData.transform.position + new Vector3(165, -55, 0); //new Vector3(-300, -300, 0);
        }
        else if (matType == MealMaterialType.Pine)
        {
            targetPos = transform.Get<Transform>("Container/CoinProgress/Coin/Icon").position;
        }
        else
        {
            targetPos = MaterialDic[(int)matType].transform.Find("Icon").position;
        }
        return targetPos;
    }

    //获取骰子6个面对应的
    private CookMealModel GetDiceMealSuit()
    {
        CookMealModel model = ActivityManager.Instance.CookMealActivity.GetCurLayerMealSuit();
        model.SuitInfo.Add((int)MealMaterialType.Coin,new List<int>());
        model.SuitInfo.Add((int)MealMaterialType.Pine,new List<int>());
        return model;
    }

    private void UpdateCoinProgress(bool needAnim = false)
    {
        if (needAnim)
        {
            coinFill.DOFillAmount((float) dataService.CookMealProgress.CoinProgress / curMealModel.CoinProgress, 0.3f).SetEase(Ease.OutQuad);
        }
        else
        {
            coinFill.fillAmount = (float) dataService.CookMealProgress.CoinProgress / curMealModel.CoinProgress;
        }

        coinText.text = $"{curMealModel.CoinProgressNum}";
    }
    
    private void FlyCallBack(int index)
    {
        Vector3 targetPos = Vector3.zero;
        int matType = RandomList[index][0];
        if (matType == (int)MealMaterialType.Coin)
        {
            if (!changeCoin)
            {
                changeCoin = true;
                GoldView.Instance.SetFakeCoin(GoldView.Instance.GetNowTextCoin(), dataService.Coin);
            }
        }
        else if (matType == (int)MealMaterialType.Pine)
        {
            UpdateCoinProgress(true);
            GameUtils.SpawnIconEffect(transform.Find("Container/CoinProgress/Coin/Icon").transform,GameObjType.CollectItemFx,iconEf);
        }
        else
        {
            float tweenTime = 0.2f;
            int total = 0;
            curMealModel.SuitInfo.TryGetValue(matType, out List<int> list);
            if (list != null) total = list[0];
            Image progressImage = MaterialDic[matType].transform.Get<Image>("Progress/Value");
            Text progressText = MaterialDic[matType].transform.Get<Text>("Progress/Text");
            int value = ActivityManager.Instance.CookMealActivity.GetMaterialProgress(matType);
            float progress = (float) value / total;
            progress = Mathf.Round(progress * 100f) / 100f;
            progressImage.DOFillAmount(progress, tweenTime);
            GameUtils.SpawnIconEffect(MaterialDic[matType].transform.Find("Icon").transform,GameObjType.CollectItemFx,iconEf);

            float orignCount = Mathf.Clamp((float) (value - 1) / total, 0, 1);
            DOTween.To(value => { progressText.text = Mathf.Floor(value).ToString(); }, orignCount * 100,
                progress * 100,
                tweenTime).SetEase(Ease.OutQuad).OnComplete(
                () =>
                {
                    var progressObj = MaterialDic[matType].transform.Find("Progress");
                    var finishObj = MaterialDic[matType].transform.Find("Finish").gameObject;
                    if (progress >= 1f)
                    {
                        progressObj.transform.DOScale(Vector3.zero, 0.3f).OnComplete(() =>
                        {
                            progressObj.gameObject.MSetActive(false);
                            progressObj.localScale = Vector3.one;
                            finishObj.gameObject.MSetActive(true);
                        });
                    }
                });
        }
    }
    
    private void UpdateDiceImage(int index,List<int> randomList)
    {
        int id = 0;
        foreach (var image in DiceImageList[index])
        {
            image.SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas,"zc_sc_" + randomList[id]);
            id++;
        }
    }

    private List<int> GetRandomMaterials(int index,int dontSetIndex = -1,int materialFinalIndex = -1)
    {
        if (RandomList[index].Count == 0)
        {
            CookMealModel model = GetDiceMealSuit();
            List<MealMaterialType> modelSuitInfoList = new List<MealMaterialType>();
            foreach (var pair in model.SuitInfo)
            {
                modelSuitInfoList.Add((MealMaterialType)pair.Key);
            }
            
            List<MealMaterialType> tempSuitInfo = new List<MealMaterialType>(modelSuitInfoList);
            for (int i = 0; i < 6; i++)
            {
                int randomPos = GameUtils.RandomRange(0, tempSuitInfo.Count);
                MealMaterialType matType = tempSuitInfo[randomPos];
                RandomList[index].Add((int)matType);
                tempSuitInfo.Remove(matType);
            }
        }

        if (dontSetIndex != -1)
        {
            List<int> tempRandomList = new List<int>(RandomList[index]);
            if (materialFinalIndex != -1) tempRandomList.Remove(materialFinalIndex);

            int lastValue = RandomList[index][dontSetIndex];
            if (lastValue != materialFinalIndex) tempRandomList.Remove(lastValue);
            else tempRandomList.Remove(RandomList[index][0]);

            GameUtils.Shuffle(tempRandomList);

            if (materialFinalIndex != -1) tempRandomList.Insert(0, materialFinalIndex);
            
            if(lastValue != materialFinalIndex) tempRandomList.Insert(dontSetIndex,lastValue);
            else tempRandomList.Insert(dontSetIndex,RandomList[index][0]);

            RandomList[index] = new List<int>(tempRandomList);
        }

        return RandomList[index];
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (!isFirst) return;
        TypeEventSystem.Register<UpdateCookFinishEvent>(ShowRewardPanel);
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
        TypeEventSystem.Register<CookGetProgressCoin>(PlayGetProgressCoin);
        TypeEventSystem.Register<GameRechargeEvent>(UpdateCount);
    }

    private void UpdateCount(GameRechargeEvent obj)
    {
        countText.text = ActivityManager.Instance.CookMealActivity.GetCookCount().ToString();
    }
    
    void PlayGetProgressCoin(CookGetProgressCoin obj)
    {
        GameUtils.PlayGoldAnim(transform, (int) GoldView.Instance.GetNowTextCoin(), (int) dataService.Coin,
            transform.Find("Container/CoinProgress"),
            () => { UpdateCoinProgress(true); },false);
    }

    private void CloseFunc()
    {
        if(isPlayingDice) return;
        SoundPlayer.Instance.CheckActivityBgm(false,ActivityType.cookMeal);
        SoundPlayer.Instance.PlayCertainButton(6);
        goldRootData.Reset();
        BoxBuilder.HidePopup(gameObject);
    }

    private void CloseFinishPanel()
    {
        finishMealEf.SetActive(true);
        selfAnim.enabled = false;
        finishMeal.gameObject.SetActive(true);
        finishPanel.SetActive(false);
        float delayTime = 0.3f;
        float flyTime = 0.5f;
        Vector3 targetPos = orderList[curMealModel.Layer - 1].transform.Find("Icon").position;
        Vector3 targetScale = orderList[curMealModel.Layer - 1].transform.Find("Icon").localScale;
        finishMeal.transform.DOScale(targetScale, flyTime).SetEase(Ease.InSine).SetDelay(delayTime);
        finishMealEf.transform.DOScale(Vector3.zero, delayTime).SetEase(Ease.Linear);
        PlayFlyItem(finishMeal,targetPos,false,flyTime,delayTime,null, PlayJumpAnim);
    }

    private void PlayJumpAnim()
    {
        Vector3 orignPos = new Vector3(0, 91, 0);
        Vector3 orignScale = Vector3.one * 0.8f;
        finishMeal.gameObject.SetActive(false);
        finishMeal.transform.localPosition = orignPos;
        finishMeal.transform.localScale = orignScale;
        finishMealEf.gameObject.SetActive(false);
        finishMealEf.transform.localScale = Vector3.one;

        
        if (ActivityManager.Instance.CookMealActivity.CheckIsMaxLayer())
        {
            BoxBuilder.HidePopup(gameObject);
            dataService.CookMealProgress.FinishGetReward = true;
            return;
        }
        
        GameUtils.PlayAnimation(selfAnim,"ani_FinishPanel_02",0, null,true);
        UpdatePanel();
    }

    private void UpdatePanel()
    {
        CookMealModel lastMealModel = curMealModel;
        UpdateCurMealModel();
        InitMaterialDic();

        List<int> frame = new List<int>() {30, 96, 101, 106, 111, 153, 158, 163};
        Observable.TimerFrame(frame[0]).Subscribe(_ =>
        {
            transform.Get<Text>("Container/MealPanel/Bar/Text").text = curMealModel.MealName;
            transform.Get<Image>("Container/MealPanel/Icon").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas, $"zc_c_{curMealModel.MealType}");
        });
        
        foreach (var pair in curMealModel.SuitInfo)
        {
            var go = MaterialDic[pair.Key];
            int index = int.Parse(go.name);
            Observable.TimerFrame(frame[index]).Subscribe(_ =>
            {
                go.transform.Get<Image>("Icon").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas,$"zc_sc_{pair.Key}");
                int value = ActivityManager.Instance.CookMealActivity.GetMaterialProgress(pair.Key);
                float progress = (float) value / pair.Value[0];
                progress = Mathf.Round(progress * 100f) / 100f;
                go.transform.Get<Image>("Progress/Value").fillAmount = progress;
                go.transform.Get<Text>("Progress/Text").text = $"{progress * 100}";
                go.transform.Find("Finish").gameObject.MSetActive(progress >= 1f);
                go.transform.Find("Progress").gameObject.MSetActive(progress < 1f);
            });
        }


        var lastOrder = orderList[lastMealModel.Layer - 1];
        var curOrder = orderList[curMealModel.Layer - 1];
        Sequence seq = DOTween.Sequence();

        curOrder.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas, $"zc_3");
        lastOrder.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas, $"zc_2");

        foreach (var ef in lastOrder.GetComponentsInChildren<UIEffect>(true))
        {
            ef.effectFactor = 1;
        }
        lastOrder.GetComponent<UIEffect>().effectFactor = 1;
        lastOrder.transform.Get<Transform>("Finish").localScale = Vector3.zero;
        lastOrder.transform.Get<Transform>("Finish").gameObject.MSetActive(true);
        lastOrder.transform.Get<Image>("GiftIconAnim").gameObject.MSetActive(false);
        seq.Insert(0f, lastOrder.transform.Get<Transform>("Icon").DOScale(Vector3.one * 0.35f, 15f / 60));
        seq.Insert(15f/60, lastOrder.transform.Get<Transform>("Icon").DOScale(Vector3.zero, 15f / 60));
        seq.Insert(30f/60, lastOrder.transform.Get<Transform>("Finish").DOScale(Vector3.one * 0.8f, 16f / 60));
        seq.Insert(46f/60, lastOrder.transform.Get<Transform>("Finish").DOScale(Vector3.one * 0.65f, 7f / 60));
        seq.Insert(64f/60, lastOrder.transform.Get<Transform>("Empty").DOScale(Vector3.one * 0.23f, 8f / 60));
        seq.Insert(72f/60, lastOrder.transform.Get<Transform>("Empty").DOScale(Vector3.zero, 21f / 60));
        
        
        foreach (var ef in curOrder.GetComponentsInChildren<UIEffect>(true))
        {
            ef.effectFactor = 0;
        }
        curOrder.GetComponent<UIEffect>().effectFactor = 0;
        curOrder.transform.Get<Transform>("Icon").localScale = Vector3.zero;
        curOrder.transform.Get<Transform>("Icon").gameObject.MSetActive(true);
        seq.Insert(93f, curOrder.transform.Get<Transform>("Icon").DOScale(Vector3.one * 0.35f, 13f / 60));
        seq.Insert(106f/60, curOrder.transform.Get<Transform>("Icon").DOScale(Vector3.one * 0.28f, 10f / 60));
        seq.Insert(64f/60, curOrder.transform.Get<Transform>("Empty").DOScale(Vector3.one * 0.23f, 8f / 60));
        seq.Insert(72f/60, curOrder.transform.Get<Transform>("Empty").DOScale(Vector3.zero, 21f / 60));
        seq.InsertCallback(93f / 60, () =>
        {
            isPlayingDice = false;
        });
        //UpdateMealList(true);
        
        for (int i = 0; i < 3; i++)
        {
            int index = i;
            Observable.TimerFrame(frame[index + 5]).Subscribe(_ =>
            {
                List<int> material = GetRandomMaterials(index);
                UpdateDiceImage(index,material);
            });
            RandomList[index].Clear();
        }
    }

    private void ShowRewardPanel(UpdateCookFinishEvent obj)
    {
        finishMeal.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas, $"zc_c_{curMealModel.MealType}");
        finishPanel.Get<Image>("Icon/Meal").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas, $"zc_c_{curMealModel.MealType}");
        FxMaskView.Instance.BlockOperation(true);

        var curOrder = orderList[curMealModel.Layer - 1];
        curOrder.transform.Get<Image>("Gift").gameObject.MSetActive(false);
        curOrder.transform.Get<Image>("GiftIconAnim").gameObject.MSetActive(true);
        UpdateFinalReward();
        GameUtils.PlayAnimation(selfAnim,"ani_FinishPanel_01",0, () =>
        {
            FxMaskView.Instance.BlockOperation(false);
        },false);
    }
    
    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateCookFinishEvent>(ShowRewardPanel);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
        TypeEventSystem.UnRegister<CookGetProgressCoin>(PlayGetProgressCoin);
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdateCount);
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.cookMeal);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance
                    .GetActivityByType(ActivityType.cookMeal).ActivityBigEndTime);
            }

            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.CookMealProgress.ActivityEndTime);
            }
        }

        timeItem.SetTimeData(timeData);
    }

    protected override void OnShow()
    {
        if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockCookMealPopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.UnlockCookMealPopup);
            BoxBuilder.ShowUnlockCookMeal();
        }
        if (ActivityManager.Instance.CookMealActivity.CheckIsMaxLayer())
        {
            BoxBuilder.HidePopup(gameObject);
            return;
        }
        
        goldRootData = GoldView.Instance.goldRootData;
        goldRootData.transform.SetParent(transform);
        goldRootData.rectTransform.anchoredPosition = new Vector2(20, -16f);
        GoldView.Instance.SortingOrder = SortingOrder + 1;
        
        SoundPlayer.Instance.CheckActivityBgm(true,ActivityType.cookMeal);
        dataService.CookMealProgress.IsFirstShow = false;
        GoldView.Instance.ShowBuildCoinRoot(false);
        countText.text = ActivityManager.Instance.CookMealActivity.GetCookCount().ToString();
        InitPanel();
        RefreshTimer(null);
        UpdateCurMealModel();
        InitDiceImageList();
        InitMaterialDic();
        UpdateMaterialList();
        UpdateMealList();
        UpdateCoinProgress(false);
    }

    private void InitDiceImageList()
    {
        for (int i = 0; i < 3; i++)
        {
            int index = i;
            Animator animator = diceList[i].Get<Animator>("dice");
            animator.enabled = false;
            List<Image> list = new List<Image>();
            for (int j = 0; j < 6; j++)
            {
                list.Add(diceList[i].Get<Image>($"dice/0{j + 1}"));
            }
            DiceImageList.Add(list);
            Observable.TimerFrame(index).Subscribe(_ =>
            {
                List<int> material = GetRandomMaterials(index);
                UpdateDiceImage(index,material);
            });
            RandomList.Add(new List<int>());
        }
    }

    private void PlayFlyItem(GameObject orignObj, Vector3 targetPos,bool needCurve, float flyTime,float delayTime, Action startAction,
        Action endAction)
    {
        Sequence seq = DOTween.Sequence();
        Vector3 startPos = orignObj.transform.position;
        Vector3 endPos = targetPos;
        endPos.z = startPos.z;

        Vector3 midPoint = (startPos + endPos) / 2;
        Vector3 controlPos = needCurve ? 
            midPoint + new Vector3(0, Mathf.Abs(endPos.y - startPos.y) * 0.5f, 0) : 
            endPos;

        
        Vector3[] bezierArray = BezierUtils.GetBeizerList(startPos, controlPos, endPos, 10);
        seq.InsertCallback(delayTime, () =>
        {
            orignObj.MSetActive(true);
        });
        seq.Insert(delayTime, orignObj.transform.DOPath(bezierArray, flyTime, PathType.CatmullRom).SetEase(Ease.OutFlash));
        seq.InsertCallback(flyTime + delayTime, () => endAction());
    }

    private void InitMaterialDic()
    {
        MaterialDic.Clear();
        if (curMealModel.MealType == (int) MealType.None) return;
        int id = 1;
        foreach (var pair in curMealModel.SuitInfo)
        {
            var go = transform.Get<Transform>($"Container/MealPanel/{id}").gameObject;
            go.Get<Transform>("Progress").localScale = Vector3.one;
            MaterialDic.Add(pair.Key,go);
            id++;
        }
    }
    
    //更新菜品
    private void UpdateMaterialList()
    {
        if(curMealModel.MealType ==(int)MealType.None) return;
        transform.Get<Text>("Container/MealPanel/Bar/Text").text = curMealModel.MealName;
        transform.Get<Image>("Container/MealPanel/Icon").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas, $"zc_c_{curMealModel.MealType}");
        foreach (var pair in curMealModel.SuitInfo)
        {
            var go = MaterialDic[pair.Key];
            go.SetActive(true);
            go.transform.Get<Image>("Icon").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas,$"zc_sc_{pair.Key}");
            int value = ActivityManager.Instance.CookMealActivity.GetMaterialProgress(pair.Key);
            float progress = (float) value / pair.Value[0];
            progress = Mathf.Round(progress * 100f) / 100f;
            go.transform.Get<Image>("Progress/Value").fillAmount = progress;
            go.transform.Get<Text>("Progress/Text").text = $"{progress * 100}";
            go.transform.Find("Finish").gameObject.MSetActive(progress >= 1f);
            go.transform.Find("Progress").gameObject.MSetActive(progress < 1f);
        }
        foreach (var go in flyMaterialList)
        {
            go.MSetActive(false);    
        }
    }

    //更新菜品对应的食材列表
    private void UpdateMealList(bool jumpNext = false)
    {
        foreach (var pair in configService.CookMealConfig)
        {
            var go = orderList[pair.Value.Layer - 1];
            bool hasGet = curMealModel.Layer > pair.Value.Layer;
            bool isCurLayer = curMealModel.Layer == pair.Value.Layer;
            bool isNextLayer = curMealModel.Layer < pair.Value.Layer;
            if (isCurLayer)
            {
                go.transform.Get<Image>("Icon").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas,$"zc_c_{(int)pair.Value.MealType}");
                go.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas, $"zc_3");
            }
            else
            {
                go.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCookMealAtlas, $"zc_2");
            }
            int factor = isNextLayer ? 1 : 0;
            foreach (var ef in go.GetComponentsInChildren<UIEffect>(true))
            {
                ef.effectFactor = factor;
            }
            go.GetComponent<UIEffect>().effectFactor = factor;
            go.transform.Get<Image>("Icon").gameObject.MSetActive(isCurLayer);
            go.transform.Get<Image>("Empty").gameObject.MSetActive(isNextLayer);
            go.transform.Get<Image>("Finish").gameObject.MSetActive(hasGet);
            var gift = go.transform.Get<Image>("Gift");
            var giftAnim = go.transform.Get<Image>("GiftIconAnim");
            gift.gameObject.MSetActive(isNextLayer || isCurLayer);
            giftAnim.gameObject.MSetActive(false);
            gift.GetComponent<Button>().SetButtonClick(() =>
            {
                Dictionary<int, int> rewards = GameUtils.AnalysisPropString(pair.Value.reward);
                GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                    .ShowItem(TextAnchor.LowerCenter, gift.transform, Vector2.zero, rewards);
            });
            giftAnim.GetComponent<Button>().SetButtonClick(() =>
            {
                Dictionary<int, int> rewards = GameUtils.AnalysisPropString(pair.Value.reward);
                GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                    .ShowItem(TextAnchor.LowerCenter, giftAnim.transform, Vector2.zero,rewards);
            });
        }
    }

    private void UpdateCurMealModel()
    {
        curMealModel = ActivityManager.Instance.CookMealActivity.GetCurLayerMealSuit();
    }
    
    private void InitPanel()
    {
        
    }
}