﻿using System;
using System.Collections.Generic;
using Activities;
using DG.Tweening;
using QFramework;
using Doozy.Engine.UI;
using SoliUtils;
using UniRx;
using UnityEngine;
using UnityEngine.UI;

public class WheelView : ViewBase
{
    [SerializeField] private Button closeBtn;
    [SerializeField] private Button spinBtn;
    [SerializeField] private Transform selectIcon;
    [SerializeField] private List<GameObject> rewardList;
    [SerializeField] private Transform WheelBg;
    [SerializeField] private Transform Reward;
    [SerializeField] private Button testBtn;
    [SerializeField] private Image payTitleImage;
    [SerializeField] private Image payWheelImage;
    [SerializeField] private GameObject payText;
    [SerializeField] private GameObject normalText;
    [SerializeField] private Image spinBtnImage;
    [SerializeField] private Image payBtnImage;
    [SerializeField] private CanvasGroup payEffectBg;
    [SerializeField] private Animator anim;

    [SerializeField] private List<GameObject> normalLightList;
    [SerializeField] private List<GameObject> normalSelectList;
    [SerializeField] private List<GameObject> payLightList;
    [SerializeField] private List<GameObject> paySelectList;
    
    
    [SerializeField] private AnimationCurve animationCurve;
    [Header("转圈总时长(秒))")] [SerializeField] private float duration = 4f; // 动画总时长
    [Header("固定转圈数(圈)")] [SerializeField] private int circleCount = 5;
    private bool EnableRotate = false;
    private bool isRotating = false;

    private float circleAngle = -360;
    private float perGridAngle = -45f;
    
    private float animationTime;
    private int lastGridIndex = -1;
    private int uiType = 1;
    private float accumulatedRotation = 0;
    private float lastAccumulatedRotation = -1;
    private IDisposable subscription;
    protected override void OnAwake()
    {
        closeBtn.SetButtonClick(CloseFunc);
        spinBtn.SetButtonClick(() =>
        {
            if(isRotating) return;
            if (uiType == 1)
            {
                HandleRotate();
            }
            else
            {
                PayUtils.RequestOrder(Constants.ProductId.WheelGiftPack);
            }
        });
    }

    private void Update()
    {
        PlayRotate();
    }

    private void PlayRotate()
    {
        if (EnableRotate && animationTime < duration)
        {
            animationTime += Time.deltaTime;
            float t = Mathf.Clamp01(animationTime / duration);
            float curveValue = animationCurve.Evaluate(t);
            selectIcon.transform.localRotation = Quaternion.Euler(0, 0,
                curveValue * (circleAngle * circleCount + lastGridIndex * perGridAngle));
            PlayLightEf();
        }
        else
        {
            EnableRotate = false;
            animationTime = 0;
        }
    }
    
    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<GameRechargeEvent>(OnPurchaseSuccess);
    }
    
    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(OnPurchaseSuccess);
    }

    protected override void OnShow()
    {
        // Purchaser.Instance.InitPurchasing();
        ResetSelectEf();
        spinBtn.interactable = false;
        SoundPlayer.Instance.PlayWheelBgm(true);
        SoundPlayer.Instance.PlayMainSound("Wheel_open");
        GameUtils.PlayAnimation(anim,"ani_Wheel_01",0, () =>
        {

            GameUtils.PlayAnimation(anim, "ani_Wheel_02", 0, null, false);
            subscription?.Dispose();
            subscription = Observable.Interval(TimeSpan.FromSeconds(30f/60)).Subscribe(_ =>  SoundPlayer.Instance.PlayMainSound("Wheel1_standby"));
            spinBtn.interactable = true;
        },false);
        InitReward(false);
        ChangeWheelType(1);
        if (dataService.WheelProgress.isPay)
        {
            ChangeWheelType(2);
            Observable.Timer(TimeSpan.FromSeconds(100f / 60)).Subscribe(_ =>
            {
                HandleRotate();
            });
        }
    }

    private void OnPurchaseSuccess(GameRechargeEvent obj)
    {
        if (dataService.WheelProgress.isPay)
        {
            HandleRotate();
        }
    }

    private void InitReward(bool isPaid)
    {
        List<WheelRewardModel> rewards = ActivityManager.Instance.WheelActivity.GetShowReward(isPaid);
        foreach (var model in rewards)
        {
            int index = 0;
            var proItem1 = rewardList[model.grid].transform.Find("Item/PropItem1");
            var proItem2 = rewardList[model.grid].transform.Find("Item/PropItem2");

            Dictionary<int, int> reward = GameUtils.AnalysisPropString(model.reward);
            proItem1.gameObject.SetActive(reward.Count >= 1);
            proItem2.gameObject.SetActive(reward.Count >= 2);

            foreach (var pair in reward)
            {
                Transform item = null;
                item = index == 0 ? proItem1 : proItem2;
                var icon = item.Get<Image>("PropImage");
                int propId = pair.Key == (int) PropEnum.Coin ? (int) PropEnum.MultiplyCoin : pair.Key;
                GameUtils.LoadPropSprite(icon,propId);
                item.Get<Transform>("TimeText").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
                item.Get<Text>("NumText").text = "";
                if (GameUtils.IsLimitTimeReward(pair.Key))
                {
                    item.Get<Text>("TimeText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
                }
                else
                {
                    item.Get<Text>("NumText").text = GameUtils.GetItemCountText(pair.Key,pair.Value);
                }
                index++;
            }
        }
    }

    public void ResetWheel()
    {
        isRotating = true;
        ResetSelectEf();
        SoundPlayer.Instance.PlayMainSound("Wheel_upgrade");
        SoundPlayer.Instance.PlayWheelBgm(true);
        Sequence seq = DOTween.Sequence();
        float angle = 45f;
        float circle = 360f;
        float targetAngle = lastGridIndex * angle;
        if (lastGridIndex == -1)
        {
            targetAngle = circle;
        }
        seq.Insert(0f,selectIcon.DOBlendableLocalRotateBy(new Vector3(0, 0,targetAngle), 1.5f,RotateMode.FastBeyond360)).SetEase(Ease.InOutQuad);
        seq.Insert(0f,Reward.DOBlendableLocalRotateBy(new Vector3(0, 0, -circle), 1.5f,RotateMode.FastBeyond360)).SetEase(Ease.InOutQuad);
        seq.Insert(0f,WheelBg.DOBlendableLocalRotateBy(new Vector3(0, 0, -circle), 1.5f,RotateMode.FastBeyond360)).SetEase(Ease.InOutQuad);
        HandleRewardEf();
        InitReward(true);
    }

    private void HandleRewardEf()
    {
        Sequence seq = DOTween.Sequence();
        float time = 0f;
        foreach (var go in rewardList)
        {
            var proItem1 = go.transform.Find("Item/PropItem1");
            var proItem2 = go.transform.Find("Item/PropItem2");
            seq.Insert(time,proItem1.transform.DOScale(Vector3.zero,0.4f));
            seq.Insert(time + 0.5f,proItem1.transform.DOScale(Vector3.one,0.4f));
            seq.Insert(time,proItem2.transform.DOScale(Vector3.zero,0.4f));
            seq.Insert(time + 0.5f,proItem2.transform.DOScale(Vector3.one,0.4f));
            time += 0.05f;
        }
        seq.InsertCallback(0.4f, () =>
        {
            ChangeWheelType(2);
        });
    }

    private void ChangeWheelType(int type)
    {
        uiType = type;
        lastGridIndex = -1;
        payText.gameObject.SetActive(type == 2);
        normalText.gameObject.SetActive(type == 1);
        closeBtn.gameObject.SetActive(type == 2);
        if (type == 1)
        {
            spinBtnImage.color = Color.white;
            payBtnImage.color = Color.clear;
            payTitleImage.color = Color.clear;
            payWheelImage.color = Color.clear;
            payEffectBg.alpha = 0;
            isRotating = false;
        }
        else
        {
            configService.ShopConfig.TryGetValue(Constants.ProductId.WheelGiftPack, out ShopModel model);
            if (model != null) payText.Get<Text>("Text").text = $"{model.money}元";
            payTitleImage.DOColor(Color.white, 0.5f);
            payWheelImage.DOColor(Color.white, 0.5f);
            payBtnImage.DOColor(Color.white, 0.5f);
            spinBtnImage.DOColor(Color.clear, 0.5f).SetDelay(0.3f);
            payEffectBg.DOFade(1f,0.5f).SetDelay(0.3f);
            subscription?.Dispose();
            subscription = Observable.Interval(TimeSpan.FromSeconds(30f/60)).Subscribe(_ =>  SoundPlayer.Instance.PlayMainSound("Wheel2_standby"));
            GameUtils.PlayAnimation(anim, "ani_Wheel_03", 0, () =>
            {
                isRotating = false;
            }, false);
        }
    }

    private void HandleRotate()
    {
        isRotating = true;
        ResetLightEf();
        ResetSelectEf();
        Sequence seq = DOTween.Sequence();

        lastAccumulatedRotation = -1;
        WheelRewardModel model = ActivityManager.Instance.WheelActivity.GetRandomReward(uiType == 2);
        lastGridIndex = model.grid;
        EnableRotate = true;
        subscription?.Dispose();
        SoundPlayer.Instance.PlayWheelBgm(false);
        if (uiType == 1)
        {
            SoundPlayer.Instance.PlayMainSound("Wheel1_spin");
        }
        else
        {
            SoundPlayer.Instance.PlayMainSound("Wheel2_spin");
        }
        seq.InsertCallback(duration + 0.02f, () => HandleSelectIcon(-lastGridIndex * perGridAngle));
        seq.Insert(duration + 2.2f,HandleRewardObj(lastGridIndex));
        seq.InsertCallback(duration + 2.5f,() =>
        {
            ActivityManager.Instance.WheelActivity.CheckGetReward(GameUtils.AnalysisPropString(model.reward), uiType,
                null, () =>
                {
                    isRotating = false;
                    if (uiType == 1)
                    {
                        ResetWheel();
                        ActivityManager.Instance.WheelActivity.ResetProgress();
                    }
                    else
                    {
                        ActivityManager.Instance.WheelActivity.SetPayState(false);
                        CloseFunc();
                    }
                });
        });
    }

    private void ResetLightEf()
    {
        anim.enabled = false;
        foreach (var go in normalLightList)
        {
            go.MSetActive(false);
        }
        foreach (var go in payLightList)
        {
            go.MSetActive(false);
        }
    }
    
    private void ResetSelectEf()
    {
        anim.enabled = false;
        foreach (var go in normalSelectList)
        {
            go.MSetActive(false);
        }
        foreach (var go in paySelectList)
        {
            go.MSetActive(false);
        }
    }
    private void PlayLightEf()
    {
        Vector3 currentRotation = selectIcon.localRotation.eulerAngles;
        float deltaAngle = Mathf.DeltaAngle(accumulatedRotation, currentRotation.z);
        accumulatedRotation += deltaAngle;
        if(lastAccumulatedRotation == accumulatedRotation) return;
        
        float angle = Mathf.Abs(accumulatedRotation) % 360;
        (int first,int second,int third,int fourth) = GetLightRangeIndex(angle);
        int tempSelectIndex = GetSelectIndex(angle);
        int lightIndex = 0;
        int selectIndex = 0;
        if (uiType == 1)
        {
            foreach (var go in normalLightList)
            {
                go.MSetActive(lightIndex == first || lightIndex == second || lightIndex == third || lightIndex == fourth);
                lightIndex++;
            }
            foreach (var go in normalSelectList)
            {
                go.MSetActive(selectIndex == tempSelectIndex);
                selectIndex++;
            }
        }
        else
        {
            foreach (var go in payLightList)
            {
                go.MSetActive(lightIndex == first || lightIndex == second || lightIndex == third || lightIndex == fourth);
                lightIndex++;
            }
            foreach (var go in paySelectList)
            {
                go.MSetActive(selectIndex == tempSelectIndex);
                selectIndex++;
            }
        }

        lastAccumulatedRotation = accumulatedRotation;
    }

    private int GetSelectIndex(float angle)
    {
        angle = (angle % 360 + 360) % 360;
        int index = Mathf.RoundToInt(angle / 45);
        if (angle < 30) index = 0;
        return index;
    }
    
    private (int, int,int,int) GetLightRangeIndex(float angle)
    {
        int first = -1;
        int second = -1;
        int third = -1;
        int endIndex = -1;

        angle = (angle % 360 + 360) % 360;
        int index = Mathf.CeilToInt(angle / 15);
        first = index;
        endIndex = (index + 3) % 24;

        second = (index + 1) % 24;
        third = (index + 2) % 24;

        if (index == 21 && angle >= 315)
        {
            first = 21;
            second = 22;
            third = 23;
            endIndex = 0;
        }
        else if (index == 22 && angle >= 330)
        {
            first = 22;
            second = 23;
            third = 0;
            endIndex = 1;
        }
        else if (index == 23 && angle >= 345)
        {
            first = 23;
            second = 0;
            third = 1;
            endIndex = 2;
        }
        return (first, second, third, endIndex);
    }


    private void BlockInput(bool bo)
    {
        FxMaskView.Instance.BlockOperation(bo);
    }
    
    private void CloseFunc()
    {
        if(isRotating) return;
        subscription?.Dispose();
        SoundPlayer.Instance.ChangeBgm();
        TypeEventSystem.Send<UpdateWheelEvent>();
        BoxBuilder.HidePopup(gameObject);
    }

    private void HandleSelectIcon(float angle)
    {
        (int first,int second,int third,int fourth) = GetLightRangeIndex(angle);
        int tempSelectIndex = GetSelectIndex(angle);
        
        if (first == -1 || second == -1 || third == -1 || fourth == -1 || tempSelectIndex == -1) return ;
        int lightIndex = 0;
        List<GameObject> lightList = uiType == 1 ? normalLightList : payLightList;
        List<GameObject> selectList = uiType == 1 ? normalSelectList : paySelectList;
        
        AddFlashingEffect(lightList, first);
        AddFlashingEffect(lightList, second);
        AddFlashingEffect(lightList, third);
        AddFlashingEffect(lightList, fourth);
        AddFlashingEffect(selectList, tempSelectIndex);
    }
    
    private void AddFlashingEffect(List<GameObject> list, int index)
    {
        GameObject light = list[index];

        Observable.Timer(TimeSpan.FromSeconds(0.25f)).Subscribe(_ =>  light.SetActive(false));
        Observable.Timer(TimeSpan.FromSeconds(0.5f)).Subscribe(_ =>  light.SetActive(true));
        Observable.Timer(TimeSpan.FromSeconds(0.75f)).Subscribe(_ =>  light.SetActive(false));
        Observable.Timer(TimeSpan.FromSeconds(1f)).Subscribe(_ =>  light.SetActive(true));
        Observable.Timer(TimeSpan.FromSeconds(1.25f)).Subscribe(_ =>  light.SetActive(false));
        Observable.Timer(TimeSpan.FromSeconds(1.5f)).Subscribe(_ =>  light.SetActive(true));
    }
    
    private Sequence HandleRewardObj(int realIndex)
    {
        Sequence seq = DOTween.Sequence();
        if (realIndex < rewardList.Count)
        {
            var proItem1 = rewardList[realIndex].transform.Find("Item/PropItem1");
            var proItem2 = rewardList[realIndex].transform.Find("Item/PropItem2");
            seq.Insert(0f,proItem1.transform.DOScale(Vector3.zero,0.2f)).SetEase(Ease.OutQuad);
            seq.Insert(0.1f,proItem2.transform.DOScale(Vector3.zero,0.2f)).SetEase(Ease.OutQuad);
        }
        return seq;
    }
}
