using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

namespace View
{
    public class DataItemComponent : MonoBehaviour
    {
        [SerializeField] private Text coinText;
        [SerializeField] private Text starText;
        [SerializeField] private Text stageText;
        [SerializeField] private Text gardenText;
        [SerializeField] private Button confirmBtn;

        private MainData _data;
        private string _remoteJson;

        public void Init(MainData data)
        {
            _data = data;
            confirmBtn?.SetButtonClick(OnConfirmBtnClick);
            coinText.text = data.coins.ToString();
            starText.text = data.stars.ToString();
            stageText.text = data.stage.ToString();
            gardenText.text = data.garden.ToString();
        }

        private void OnConfirmBtnClick()
        {
            BoxBuilder.ShowDataSyncConfirmPopup(_data);
            BoxBuilder.HideDataSyncPopup();
        }
    }
}