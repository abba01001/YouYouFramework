﻿using Activities;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class RabbitGiftView : ViewBase
{
    private Button closeBtn;
    private Button tipBtn;
    private RectTransform fillAmount;
    private ActivityTimeItem timeItem;
    [SerializeField] private List<Image> bgImage;
    [SerializeField] private GameObject bgEffect;
    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(CloseFunc);
        tipBtn = transform.Get<Button>("Container/TipBtn");
        tipBtn.SetButtonClick(BoxBuilder.ShowUnlockRabbitPopup);
        fillAmount = transform.Get<RectTransform>("Container/Progress/Value");
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(() =>
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);
            if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockRabbitPopup))
            {
                dataService.AddFirstPopup(Constants.DoozyView.UnlockRabbitPopup);
                ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.UnlockRabbitPopup, BoxBuilder.ShowUnlockRabbitPopup, true);
            }
            CloseFunc();
        });
    }
    protected override void OnViewInit(bool isFirst)
    {
        if(!isFirst) return;
        TypeEventSystem.Register<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    private (Vector2,Vector2) GetOffset(int index)
    {
        return index switch
        {
            0 => (new Vector2(0, 30), new Vector2(0, 0)),
            1 => (new Vector2(96, 30), new Vector2(0, 0)),
            2 => (new Vector2(332, 30), new Vector2(0, 0)),
            _ => (new Vector2(664, 30), new Vector2(-100, 0))
        };
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }
    
    //更新排行面板
    private void UpdatePanel(UpdateRankViewEvent obj)
    {

    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.rabbitGift);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.rabbitGift).ActivityBigEndTime);
            }
            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.RabitGiftProgress.ActivityEndTime);
            }
        }
        timeItem.SetTimeData(timeData);
    }
    
    protected override void OnShow()
    {
        InitPanel();
        RefreshTimer(null);
    }

    private void InitPanel()
    {
        var iconRect = fillAmount.Get<RectTransform>("Icon");
        fillAmount.sizeDelta = new Vector2(0, 30);
        var (obj1, obj2)= GetOffset(dataService.RabitGiftProgress.curWinCount);
        int index = dataService.RabitGiftProgress.curWinCount - 1;
        float time = 0.5f;
        float delay = 0.3f;
        Sequence seq = DOTween.Sequence();
        if (dataService.RabitGiftProgress.lastWinCount != dataService.RabitGiftProgress.curWinCount)
        {
            var (obj3, obj4)= GetOffset(dataService.RabitGiftProgress.lastWinCount);
            fillAmount.sizeDelta = obj3;
            iconRect.anchoredPosition = obj4;
            seq.Insert(delay,fillAmount.DOSizeDelta(obj1, time).SetEase(Ease.OutBack));
            seq.Insert(delay,iconRect.DOAnchorPos(obj2, time));
            seq.InsertCallback(delay, () =>
            {
                SoundPlayer.Instance.PlayMainSound("Rabbit_progress");
            });
            if (index is >= 0 and < 3)
            {
                Observable.Timer(TimeSpan.FromSeconds(delay+time)).Subscribe(_ =>
                {
                    bgImage[index].SetSpriteByAtlas(Constants.AtlasNamePath.ViewRabbitGiftAtlas, "tzls_3");
                    bgEffect.SetActive(true);
                    bgEffect.transform.SetParent(bgImage[index].transform);
                    bgEffect.transform.localPosition = new Vector3(0, 51,-48);
                });
            }
        }
        else
        {
            fillAmount.sizeDelta = obj1;
            iconRect.anchoredPosition = obj2;
            if (index is >= 0 and < 3)
            {
                bgImage[index].SetSpriteByAtlas(Constants.AtlasNamePath.ViewRabbitGiftAtlas,"tzls_3");
            }
        }
        iconRect.gameObject.SetActive(dataService.RabitGiftProgress.curWinCount != 0);
        ActivityManager.Instance.RabbitGiftActivity.ResetLastWinCount();
    }
}
