using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using UniRx;
using DG.Tweening;
using System;
using System.Linq;
using Doozy.Engine;
using Coffee.UIExtensions;
using Doozy.Engine.UI.Animation;
using SoliUtils;

[RequireComponent(typeof(CanvasGroup))]
public class StreakTipPopView : ViewBase
{
    RectTransform rect;
    Transform progressTrans;
    protected override void OnAwake()
    {
        rect = transform.Find("Container/Progress/Image").GetComponent<RectTransform>();
        progressTrans = transform.Find("Container/Progress/Image");
        transform.Get<Button>("Container/BackBtn").SetButtonClick(CloseFunc);
        transform.Get<Button>("Container/TipBtn").SetButtonClick(()=> {
            BoxBuilder.ShowUnlockWinStreakPopView();
        });
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        UIPopup popup = GetComponent<UIPopup>();
        popup.Hide();
        if (popup.AddToPopupQueue)
            UIPopupManager.RemoveFromQueue(popup);
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
    }

    protected override void OnInitedDestroy()
    {
    }
    protected override void OnShow()
    {
        int progress = Math.Min(dataService.SuccessiveVictory, 5);
        progressTrans.localScale = progress == 0 ? Vector3.zero : Vector3.one;
        rect.sizeDelta = new Vector2(1032 / 5 * progress, rect.sizeDelta.y);

        for (int i = 1; i <= 5; i++)
        {
            CardBox tempComponent = transform.Find($"Container/CardBox{i}").GetComponent<CardBox>();
            tempComponent.ShowImageBox(i);
            tempComponent.SetTick(i == progress);
        }
    }

    public void UpdatePanel()
    {

    }

}