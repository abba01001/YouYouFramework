using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using DG.Tweening;
using Model;
using UniRx;

[RequireComponent(typeof(CanvasGroup))]
public class GiftGradientCookPopView : ViewBase
{
    int waitToLevel = -1;
    List<int> selectItem = new List<int>(3);
    [SerializeField] private RectTransform progressRect;
    [SerializeField] private Text progressText;
    [SerializeField] private Button collectBtn;
    private Button CloseBtn;
    private Text TipText;
    private Dictionary<int, GradientCookItem> itemList = new Dictionary<int, GradientCookItem>(); 
    ActivityTimeItem timeItem;

    
    private Vector2[] targetPos = new Vector2[]
    {
        new Vector2(-344.5f,0),
        new Vector2(0f,0),
        new Vector2(0,-247),
        new Vector2(344.5f,-247),
        new Vector2(344.5f,0),
        new Vector2(689f,0),
        new Vector2(689,-247),
        new Vector2(0,-601),
    };
    
    
    protected override void OnAwake()
    {
        Button backCloseBtn = transform.Get<Button>("Overlay");
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        collectBtn.SetButtonClick(() =>
        {
            GradientModel model = ActivityManager.Instance.GiftGradientCookActivity.GetCurLayerCollectModel();
            if (model != null)
            {
                GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>()
                    .ShowItem(TextAnchor.LowerCenter, collectBtn.GetComponent<Transform>(), Vector2.zero,GameUtils.AnalysisPropString(model.collectReward));
            }
        });
        backCloseBtn.interactable = false;
        backCloseBtn.SetButtonClick(CloseFunc);
        CloseBtn.SetButtonClick(CloseFunc);
        for (int i = 1; i <= 7; i++)
        {
            itemList.Add(i,transform.Get<GradientCookItem>($"Container/ScrollView/Content/Item{i}"));
        }
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        InitPanel();
        RefreshTimer(null);
    }

    private void InitPanel()
    {
        int startIndex = ActivityManager.Instance.GiftGradientCookActivity.GetStartIndex();
        if (startIndex > configService.GiftGradientCookConfig.Count)
        {
            foreach (var temp in itemList)
            {
                temp.Value.gameObject.SetActive(false);
            }
            return;
        }
        int count = 1;
        for (int i = startIndex; i <= startIndex + 6; i++)
        {
            itemList[count].SetData(i);
            count++;
        }
    }

    public void UpdatePanel(UpdateGiftCook obj)
    {
        int startIndex = ActivityManager.Instance.GiftGradientCookActivity.GetStartIndex();
        if (startIndex > configService.GiftGradientCookConfig.Count)
        {
            ActivityManager.Instance.GiftGradientCookActivity.CheckFinishActivity();
            CloseFunc();
            return;
        }
        FxMaskView.Instance.BlockOperation(true);
        Sequence seq = DOTween.Sequence();
        
        SoundPlayer.Instance.PlayMainSound("GradientGift_Move");
        for (int i = 1; i <= 7; i++)
        {
            if (i == 1)
            {
                HandleFirstItemAnim(itemList[i]);
                continue;
            }
            seq.Join(itemList[i].GetComponent<RectTransform>().DOAnchorPos(targetPos[i - 1], 30f / 60));
        }

        seq.AppendCallback(() =>
        {
            HandleSort();
            int count = 1;
            for (int i = startIndex; i <= startIndex + 6; i++)
            {
                itemList[count].SetData(i);
                count++;
            }
            FxMaskView.Instance.BlockOperation(false);
        });
    }

    private void HandleFirstItemAnim(GradientCookItem item,bool reset = false)
    {
        RectTransform rect = item.transform.Get<RectTransform>("Reward");
        if (reset)
        {
            rect.anchoredPosition = new Vector2(rect.anchoredPosition.x, rect.anchoredPosition.y - 60);
            rect.GetComponent<CanvasGroup>().alpha = 1;
            item.ResetLockObj();
            return;
        }
        rect.DOAnchorPos(new Vector2(rect.anchoredPosition.x, rect.anchoredPosition.y + 60), 0.3f);
        rect.GetComponent<CanvasGroup>().DOFade(0f,0.3f);
    }
    
    private void HandleSort()
    {
        Dictionary<int, GradientCookItem> tempList = new Dictionary<int, GradientCookItem>();
        for (int i = 2; i <= 7; i++)
        {
            tempList.Add(i-1,itemList[i]);
        }
        tempList.Add(7,itemList[1]);
        for (int i = 1; i <= 7; i++)
        {
            tempList[i].name = $"Item{i}";
            tempList[i].gameObject.SetActive(false);
        }
        tempList[7].GetComponent<RectTransform>().anchoredPosition = targetPos[7];
        HandleFirstItemAnim(tempList[7], true);
        itemList = tempList;
    }
    
    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
        TypeEventSystem.Register<UpdateGiftCook>(UpdatePanel);
        TypeEventSystem.Register<UpdateGiftCookProgress>(UpdateProgress);
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (ActivityManager.Instance.GetActivityByType(ActivityType.giftGradientCook) != null && ActivityManager.Instance.GetActivityByType(ActivityType.giftGradientCook).state 
                is ActivityState.waitEntry or ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.giftGradientCook).ActivityBigEndTime);
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.giftGradientCook).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.GiftGradientCookProgress.ActivityEndTime);
        }
        timeItem.SetTimeData(timeData);
    }
    
    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
        TypeEventSystem.UnRegister<UpdateGiftCook>(UpdatePanel);
        TypeEventSystem.UnRegister<UpdateGiftCookProgress>(UpdateProgress);
    }
    
    private void UpdateProgress(UpdateGiftCookProgress obj)
    {
        float percent = (float)dataService.GiftGradientCookProgress.CollecProgress / ActivityManager.Instance.GiftGradientCookActivity.GetMaxProgress();
        progressRect.sizeDelta = new Vector2(659 * percent,51);
        progressText.text = $"{dataService.GiftGradientCookProgress.CollecProgress}/{ActivityManager.Instance.GiftGradientCookActivity.GetMaxProgress()}";
    }
    
    protected override void OnShow()
    {
        float percent = (float)dataService.GiftGradientCookProgress.CollecProgress / ActivityManager.Instance.GiftGradientCookActivity.GetMaxProgress();
        progressRect.sizeDelta = new Vector2(659 * percent,51);
        progressText.text = $"{dataService.GiftGradientCookProgress.CollecProgress}/{ActivityManager.Instance.GiftGradientCookActivity.GetMaxProgress()}";
    }
    
}