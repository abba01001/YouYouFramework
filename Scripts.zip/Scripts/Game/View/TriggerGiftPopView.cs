﻿using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Doozy.Engine;
using System;
using Doozy.Engine.UI;
using UniRx;
using Coffee.UIExtensions;
using System.Collections.Generic;
using QFramework;
using SoliUtils;

public class TriggerGiftPopView : ViewBase
{
    private Text timeText;

    private bool isSuccessBuy;
    private Action onCloseCall;

    protected override void OnAwake()
    {
        timeText = transform.Get<Text>("Content/TimeBG/TimeText");
    }

    protected override void OnViewInit(bool isFirstTime)
    {
        if (!isFirstTime) return;
        TypeEventSystem.Register<GlobalTimerRefreshEvent>(OnGlobalTimerRefreshEvent);
        TypeEventSystem.Register<PurchaseSuccess>(OnPurchaseSuccess);
    }

    protected override void OnShow()
    {
        if (!CheckCanShow()) return;
        OnGlobalTimerRefreshEvent(null);
        // Product product = Purchaser.Instance.GetProduct(Purchaser.BattlePassProductKey);
        ShopModel shopModel = configService.ShopConfig[dataService.NowTriggerGiftProductID];
        transform.Get<Text>("Content/DiscountBG/Discount").text = $"+{shopModel.extea}%";
        // transform.Get<Text>("Content/BuyBtn/Price").text = product?.metadata.localizedPriceString ?? shopModel.GetShowPrice();
        transform.Get<Button>("Content/CloseBtn").SetButtonClick(() => BoxBuilder.HidePopup(gameObject));
        transform.Get<Button>("Content/BuyBtn").SetButtonClick(() =>
        {
            if (!CheckCanShow()) return;
            // Purchaser.Instance.BuyProduct(Purchaser.Instance.GetProductKey(dataService.NowTriggerGiftProductID));
        });

        Dictionary<int, int> rewardDic = GameUtils.AnalysisPropString(shopModel.reward);
        Transform countParent = transform.Find("Content/Count" + rewardDic.Count);
        int index = 1;
        foreach (var item in rewardDic)
        {
            Transform itemTrans = transform.Find("Content/" + item.Key);
            itemTrans.gameObject.SetActive(true);
            itemTrans.Get<Text>("NumText").text = "×" + item.Value;
            itemTrans.SetParent(countParent.Find("Point" + index), false);
            itemTrans.localPosition = Vector3.zero;
            index++;
            if (index > 3) break;
        }
    }

    public void SetCloseCall(Action _onCloseCall)
    {
        onCloseCall = _onCloseCall;
    }

    private void OnGlobalTimerRefreshEvent(GlobalTimerRefreshEvent obj)
    {
        if (CheckCanShow())
        {
            TimeSpan sp = TimeSpan.FromSeconds(dataService.NowTriggerGiftEndTime - TimeUtils.UtcNow());
            if (sp.Days > 0)
                timeText.text = string.Format("{0:D2}D {1:D2}:{2:D2}:{3:D2}", sp.Days, sp.Hours, sp.Minutes, sp.Seconds);
            else
                timeText.text = string.Format("{0:D2}:{1:D2}:{2:D2}", sp.Hours, sp.Minutes, sp.Seconds);
        }
    }

    private void OnPurchaseSuccess(PurchaseSuccess obj)
    {
        // Product product = obj.purchasedProduct;
        // if (product.definition.id == dataService.NowTriggerGiftProductID)
        // {
        //     isSuccessBuy = true;
        //     dataService.NowTriggerGiftProductID = "";
        //     dataService.NowTriggerGiftEndTime = TimeUtils.UtcNow();
        //     ShopModel shopModel = configService.ShopConfig[product.definition.id];
        //     BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(shopModel.reward), PropChangeWay.TriggerGift, () => BoxBuilder.HidePopup(gameObject));
        // }
    }

    private bool CheckCanShow()
    {
        if (isSuccessBuy) return false;
        if (string.IsNullOrEmpty(dataService.NowTriggerGiftProductID))
        {
            BoxBuilder.HidePopup(gameObject);
            return false;
        }
        if (dataService.NowTriggerGiftEndTime <= TimeUtils.UtcNow())
        {
            BoxBuilder.HidePopup(gameObject);
            return false;
        }
        return true;
    }

    protected override void OnInitedDestroy()
    {
        onCloseCall?.Invoke();
        onCloseCall = null;
        TypeEventSystem.UnRegister<GlobalTimerRefreshEvent>(OnGlobalTimerRefreshEvent);
        TypeEventSystem.UnRegister<PurchaseSuccess>(OnPurchaseSuccess);
    }
}
