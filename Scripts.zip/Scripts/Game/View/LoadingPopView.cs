using QFramework;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;

public class LoadingPopView : ViewBase
{
    private Transform fullTrans;
    private Transform petiteTrans;

    private Image fillImage;
    private Text progressText;
    private RectTransform handleImage;

    const float fillLength = 372f;

    Sequence loadSeq;

    protected override void OnAwake()
    {
        reportOnShow = false;
        fullTrans = transform.Find("Container/FullScene");
        petiteTrans = transform.Find("Container/PetiteScene");
    }

    protected override void OnViewDestroy()
    {
        StopAllCoroutines();
        KillLoadSeq();
    }

    protected override void OnShow()
    {
        float scale = Math.Max(Screen.width / Constants.ResolutionWidth, Screen.height / Constants.ResolutionHeight);
        transform.localScale = Vector3.one * scale;
    }

    private void OnEnable()
    {
        KillLoadSeq();
    }

    private float GetFillProgress()
    {
        return fillImage.fillAmount;
    }

    private void SetIsFullLoad(bool isFullLoad)
    {
        fullTrans.gameObject.SetActive(isFullLoad);
        petiteTrans.gameObject.SetActive(!isFullLoad);
        Transform trans = isFullLoad ? fullTrans : petiteTrans;
        fillImage = trans.Get<Image>("Image/Fill");
        progressText = trans.Get<Text>("Image/ProgressText");
        handleImage = trans.Get<RectTransform>("Image/Fill/Handle");
    }

    private void SetFillProgress(float progress)
    {
        fillImage.fillAmount = progress;
        handleImage.anchoredPosition = new Vector2(fillLength * progress, 0);
        progressText.text = $"{(int)(progress * 100)}";
    }

    public void ToHide(bool instantAction)
    {
        KillLoadSeq();
        loadSeq = DOTween.Sequence();
        loadSeq.Append(DOTween.To(GetFillProgress, SetFillProgress, 1f, Mathf.Clamp(1 - GetFillProgress(), 0.2f, 0.5f)));
        if (instantAction)
            loadSeq.AppendInterval(0.2f);
        loadSeq.AppendCallback(() =>
        {
            loadSeq = null;
            BoxBuilder.HidePopup(gameObject, instantAction);
        });
    }

    private void OnDisable()
    {
        StopAllCoroutines();
        KillLoadSeq();
    }

    private void KillLoadSeq()
    {
        if (loadSeq?.IsPlaying() == true)
            loadSeq.Kill(false);
        loadSeq = null;
    }

    public void SetMaxWaitTime(float maxWaitTime, bool isUseFull, Action onMaxWaitCall, bool instantAction)
    {
        KillLoadSeq();
        SetIsFullLoad(isUseFull);
        SetFillProgress(0);
        maxWaitTime /= 6;
        loadSeq = DOTween.Sequence();
        loadSeq.Append(DOTween.To(GetFillProgress, SetFillProgress, 0.25f, maxWaitTime * 1f));
        loadSeq.Append(DOTween.To(GetFillProgress, SetFillProgress, 0.43f, maxWaitTime * 1f));
        loadSeq.AppendInterval(maxWaitTime * 0.5f);
        loadSeq.Append(DOTween.To(GetFillProgress, SetFillProgress, 0.56f, maxWaitTime * 0.5f));
        loadSeq.AppendInterval(maxWaitTime * 0.2f);
        loadSeq.Append(DOTween.To(GetFillProgress, SetFillProgress, 0.8f, maxWaitTime * 0.8f));
        loadSeq.Append(DOTween.To(GetFillProgress, SetFillProgress, 1f, maxWaitTime * 2f));
        loadSeq.AppendCallback(() =>
        {
            loadSeq = null;
            onMaxWaitCall?.Invoke();
            BoxBuilder.HidePopup(gameObject, instantAction);
        });
    }
}
