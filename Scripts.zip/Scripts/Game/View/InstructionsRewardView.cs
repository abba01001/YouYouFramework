﻿using DG.Tweening;
using SoliUtils;
using UnityEngine;
using UnityEngine.UI;

public class InstructionsRewardView : ViewBase
{

    private Button closeBtn;
    private GameObject closeTips;
    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/Btn");
        closeBtn.SetButtonClick(CloseFunc);
        closeTips = transform.Find("Container/Content/CloseTips").gameObject;

    }

    protected override void OnShow()
    {
        closeTips.SetActive(false);
        closeBtn.interactable = false;
        Sequence seq = DOTween.Sequence();
        for (int i = 1; i <= 3; i++)
        {
            Transform image = transform.Find("Container/Content/Image" + i);
            image.localScale = Vector3.zero;
            seq.Append(image.DOScale(Vector3.one, 0.5f).SetEase(Ease.OutCubic));
            Transform arrow = transform.Find("Container/Content/Arrow" + i);
            if (arrow != null)
            {
                arrow.localScale = Vector3.zero;
                seq.Append(arrow.DOScale(Vector3.one, 0.5f).SetEase(Ease.OutCubic));
            }
        }
        seq.AppendCallback(() => {

            closeTips.SetActive(true);
            closeBtn.interactable = true;
        });

    }



    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }
}