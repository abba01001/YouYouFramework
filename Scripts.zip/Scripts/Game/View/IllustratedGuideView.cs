using Activities;
using DG.Tweening;
using Model;
using QFramework;
using SoliUtils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UniRx;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class IllustratedGuideView : ViewBase
{
    [SerializeField] private EfficientScrollRect _npcScrollRect;
    [SerializeField] private GameObject _npcItem;
    [SerializeField] private ScrollRect _goodsScrollRect;
    [SerializeField] private GameObject _goodsItem;
    [SerializeField] private GameObject _pieceItem;


    [SerializeField] private List<Sprite> _tabBtnBgSprites = new List<Sprite>();
    [SerializeField] private List<Sprite> _tabBtnIconSprites = new List<Sprite>();

    private RectTransform _goodScrollRectTransform;
    private List<GoodsItemRect> _goodsItemRectList;
    private Button _closeBtn;
    private TabBtn _tabBtn;
    private bool _initedNPCPanel;
    private GameObject _tips;
    public static IllustratedGuideView Instance;
    public int sortingOrder;

    private GameObjectData goldRootData;
    private Transform goldParent;
    private int goldIndex;
    private int goldSortingOrder;
    private Sequence mySequence;

    protected override void OnAwake()
    {
        Instance = this;
        _npcScrollRect.gameObject.SetActive(false);
        _npcItem.SetActive(false);
        _tips = transform.Find("Container/Tips").gameObject;

        _goodsScrollRect.onValueChanged.AddListener(OnGoodsScrollValueChange);
        _goodScrollRectTransform = _goodsScrollRect.GetComponent<RectTransform>();
        _goodsScrollRect.gameObject.SetActive(false);
        _goodsItem.SetActive(false);

        _closeBtn = transform.Get<Button>("Container/CloseBtn");
        _closeBtn.SetButtonClick(CloseFunc);

        _tabBtn = transform.Get<Transform>("Container/TabBtn").gameObject.AddComponent<TabBtn>();
        _tabBtn.Init(OnSelectTabBtn,_tabBtnBgSprites, _tabBtnIconSprites);
        _tabBtn.selectedItemParent = transform.Find("Container/Bg");


        RedDotNode rootNode = RedDotMgr.Instance.GetModuleRootNode(RedDotId.IllustratedGuide);
        List<TabBtn.TabBtnItem> btns = _tabBtn.GetBtnItemList();
        for(int i=0;i< btns.Count; i++)
        {
            TabBtn.TabBtnItem btnItem = btns[i];
            RedDotNode childNode = rootNode.GetChildNode(i+1);
            RedDotMgr.Instance.CreateRedDot(childNode, btnItem.button.transform, new Vector2(55, 15));
        }
    }



    protected override void OnViewInit(bool isFirst)
    {
        TypeEventSystem.Register<PropChangeEvent>(OnPropChangeEvent);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<PropChangeEvent>(OnPropChangeEvent);
    }

    protected override void OnShow()
    {
        goldRootData = GoldView.Instance.goldRootData;
        goldSortingOrder = GoldView.Instance.SortingOrder;
        sortingOrder = gameObject.GetComponent<Canvas>().sortingOrder;
        _tabBtn.OnSelectBtn(0);
        UpdateTabBtnTips();
    }

    private void CloseFunc()
    {
        if (mySequence != null)
        {
            mySequence.Kill(true);
            mySequence = null;
        }

        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }


    public void PlayGoldAnim(Transform startTrans,long oldCoin,long newCoin)
    {
        //_playingGoldAnim = true;
        if (goldRootData.transform.parent != transform)
        {
            goldRootData.transform.SetParent(transform);
            goldRootData.rectTransform.anchoredPosition = new Vector2(48f, -25f);
            GoldView.Instance.SortingOrder = sortingOrder + 1;
        }

        GoldView.Instance.ThreePowerBeizerFlyCoin((int)PropEnum.Coin, oldCoin, newCoin, startTrans);

        if (mySequence != null)
        {
            mySequence.Kill(false);
        }
        mySequence = DOTween.Sequence();
        mySequence.SetAutoKill(true);
        mySequence.AppendInterval(2f);
        mySequence.OnComplete(() =>
        {
            GoldView.Instance.SortingOrder = goldSortingOrder;
            goldRootData.Reset();
            mySequence = null;
        });
    }

    

    private void OnPropChangeEvent(PropChangeEvent evt)
    {
        UpdateTabBtnTips();
    }

    private void UpdateTabBtnTips()
    {
        //List<TabBtn.TabBtnItem> list = _tabBtn.GetBtnItemList();
        //for(int i = 0; i < list.Count; i++)
        //{
        //    list[i].SetTipsActive(ActivityManager.Instance.IllustratedGuideActivity.CheckCanReward(i+1));
        //}
    }

    private void OnSelectTabBtn(int index)
    {
        if (index == 0)
        {
            ShowNPCPanel();
        }
        else
        {
            ShowGoodsPanel(index);
        }
    }

    private void OnGoodsScrollValueChange(Vector2 pos)
    {
        float y = _goodsScrollRect.content.anchoredPosition.y;
        float minY = y;
        float maxY = minY + _goodScrollRectTransform.sizeDelta.y;
        //Debug.Log("minY===" + minY+ " maxY==="+ maxY);
        GoodsItemRect itemRect;
        for (int i=0;i< _goodsItemRectList.Count; i++)
        {
            itemRect = _goodsItemRectList[i];
            if (itemRect.startPosY > maxY || itemRect.startPosY+ itemRect.height < minY)
            {
                itemRect.SetVisible(false);
            }
            else
            {
                itemRect.SetVisible(true);
            }
        }
    }

    
    private void ShowNPCPanel()
    {
        _npcScrollRect.gameObject.SetActive(true);
        _goodsScrollRect.gameObject.SetActive(false);
        _tips.gameObject.SetActive(false);
        if (!_initedNPCPanel)
        {
            _initedNPCPanel = true;
            List<MergeIllustratedData> datas = ActivityManager.Instance.IllustratedGuideActivity.GetDataListByTabIndex(1);
            _npcScrollRect.LineSpace = 20;
            _npcScrollRect.SetUpdateItemCb((obj) =>
            {
                IllustratedNPCItem item = obj as IllustratedNPCItem;
                item.transform.localScale = Vector3.one;
                item.SetParentScrollRect(_npcScrollRect);
            });
            _npcScrollRect.Init(GameObjType.IllustratedNPCItem, _npcItem, datas.ToArray());
        }
        
    }

    
    private void ShowGoodsPanel(int tabBtnIndex)
    {
        _npcScrollRect.gameObject.SetActive(false);
        _goodsScrollRect.gameObject.SetActive(true);
        SetRectAnchoredPositionY(_goodsScrollRect.content, 0);
        List<MergeIllustratedData> datas = ActivityManager.Instance.IllustratedGuideActivity.GetDataListByTabIndex(tabBtnIndex+1);
        if (datas.Count == 0)
        {
            _goodsScrollRect.gameObject.SetActive(false);
            _tips.gameObject.SetActive(true);
            return;
        }
        _tips.gameObject.SetActive(false);
        if (_goodsItemRectList != null)
        {
            for(int i=0;i< _goodsItemRectList.Count; i++)
            {
                _goodsItemRectList[i].ClearItem();
            }
        }
        _goodsItemRectList = new List<GoodsItemRect>();

        for(int i = 0; i < datas.Count; i++)
        {
            GoodsItemRect itemRect = new GoodsItemRect();
            itemRect.index = i;
            itemRect.Init(datas[i], _goodsScrollRect.content, _goodsItem);
            _goodsItemRectList.Add(itemRect);
        }

        int posY = 0;
        int space = 14;
        for(int i=0;i< _goodsItemRectList.Count; i++)
        {
            GoodsItemRect itemRect = _goodsItemRectList[i];
            itemRect.startPosY = posY;
            posY += itemRect.height + space;
        }
        Vector2 sizeDelta = _goodsScrollRect.content.sizeDelta;
        sizeDelta.y = posY;
        _goodsScrollRect.content.sizeDelta = sizeDelta;

        OnGoodsScrollValueChange(Vector2.zero);
    }

    private void SetRectAnchoredPositionY(RectTransform rectTransform,int posY)
    {
        Vector2 anchoredPosition = rectTransform.anchoredPosition;
        anchoredPosition.y = posY;
        rectTransform.anchoredPosition = anchoredPosition;
    }

    public class GoodsItemRect
    {
        private MergeIllustratedData _data;
        private GameObject _itemPrefab;
        private Transform _content;
        private IllustratedGoodsItem item;
        private bool _visible = false;
        public int index;
        public int startPosY;
        public int height;

         
        public void Init(MergeIllustratedData data,Transform content, GameObject itemPrefab)
        {
            _data = data;
            _content = content;
            _itemPrefab = itemPrefab;
            
            int lineCount = Mathf.CeilToInt(_data.pieceConfigs.Count / 5f);
            height = 280 + (lineCount - 1) * 200;
            //GameObjManager.Instance.PopGameObject(objType, itemPrefab).GetComponent<ScrollItem>();
        }

        public void SetVisible(bool visible)
        {
            if (_visible == visible)
            {
                return;
            }
            _visible = visible;
            if (_visible)
            {
                if (item == null)
                {
                    item = GameObjManager.Instance.PopGameObject(GameObjType.IllustratedGoodsItem, _itemPrefab).GetComponent<IllustratedGoodsItem>();
                    item.transform.SetParent(_content);
                    item.gameObject.SetActive(true);
                    item.transform.localScale = Vector3.one;
                    item.Init();
                    item.SetAnchoredPosition(new Vector3(0, -startPosY,0));
                    item.SetData(_data);
                }
            }
            else
            {
                ClearItem();
            }
        }

        public void ClearItem()
        {
            if (item != null)
            {
                GameObjManager.Instance.PushGameObject(item.gameObject);
                item = null;
            }
        }
    }


    public class TabBtn:MonoBehaviour
    {
        public Transform selectedItemParent;
        private List<TabBtnItem> _btnItems;
        private TabBtnItem _selectedItem;
        private UnityAction<int> _callBack;
        private int _selectedIndex;
        public void Init(UnityAction<int> callBack,List<Sprite> btnBgSprites,List<Sprite> btnIconSprites)
        {
            _callBack = callBack;
            _btnItems = new List<TabBtnItem>();
            Transform itemPrefab = transform.Find("Item");
            Transform itemTransform = itemPrefab;
            for(int i = 0; i < btnIconSprites.Count; i++)
            {
                if (i > 0)
                {
                    itemTransform = Transform.Instantiate(itemPrefab, itemPrefab.parent);
                }
                TabBtnItem btnItem = new TabBtnItem();
                btnItem.Init(i,itemTransform, btnBgSprites, btnIconSprites[i]);
                btnItem.button.onClick.AddListener(()=>
                {
                    if (_selectedIndex != btnItem.index)
                    {
                        OnSelectBtn(btnItem.index);
                    }
                });
                _btnItems.Add(btnItem);
            }
        }

        public List<TabBtnItem> GetBtnItemList()
        {
            return _btnItems;
        }

        public void OnSelectBtn(int index)
        {
            _selectedIndex = index;
            _callBack.Invoke(index);
            TabBtnItem btnItem;
            for (int i=0;i< _btnItems.Count; i++)
            {
                btnItem = _btnItems[i];
                if (btnItem.index == index)
                {
                    btnItem.ChangeBgState(1);
                    btnItem.button.transform.SetParent(selectedItemParent);
                    _selectedItem = btnItem;
                }
                else
                {
                    btnItem.ChangeBgState(0);
                    btnItem.button.transform.SetParent(btnItem.transform);
                }
            }
        }

        private void Update()
        {
            if (_selectedItem != null && _selectedItem.button.transform.position != _selectedItem.transform.position)
            {
                _selectedItem.button.transform.position = _selectedItem.transform.position;
            }
        }


        public class TabBtnItem
        {
            public Transform transform;
            public Button button;
            public int index;
            private List<Sprite> _btnBgSprites;
            private Image _bgImage;
            //private GameObject _tipsGO;
            
            public void Init(int index,Transform transform, List<Sprite> btnBgSprites,Sprite iconSprite)
            {
                this.index = index;
                this.transform = transform;
                _btnBgSprites = btnBgSprites;
                button = transform.Get<Button>("Btn");
                //_tipsGO = transform.Find("Btn/Tips").gameObject;
                _bgImage = transform.Get<Image>("Btn/Bg");
                Image iconImage = transform.Get<Image>("Btn/Icon");
                iconImage.sprite = iconSprite;
                iconImage.SetNativeSize();
            }

            //public void SetTipsActive(bool active)
            //{
            //    _tipsGO.SetActive(active);
            //}

            public void ChangeBgState(int index)
            {
                _bgImage.sprite = _btnBgSprites[index];
                _bgImage.SetNativeSize();
            }
        }

        
    }
}
