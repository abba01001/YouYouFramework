﻿using System;
using Activities;
using DG.Tweening;
using QFramework;
using System.Collections;
using System.Collections.Generic;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class CarRankView : ViewBase
{
    private Button closeBtn;
    private Button tipBtn;
    private ActivityTimeItem timeItem;
    private bool IsPlayingAnim = false;
    private bool IsNeedScroll = true;
    [SerializeField] private EfficientScrollRect _scrollRect;
    [SerializeField] private GameObject rankItem;
    [SerializeField] private RectMask2D _rectMask2D;
    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(CloseFunc);
        rankItem.SetActive(false);
        tipBtn = transform.Get<Button>("Container/TipBtn");
        tipBtn.SetButtonClick(BoxBuilder.ShowUnlockCarRankPopView);
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
    }

    private void CloseFunc()
    {
        if(IsPlayingAnim) return;
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    //更新排行面板
    private void UpdatePanel(UpdateRankViewEvent obj)
    {

    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    protected override void OnShow()
    {
        InitPanel();
        RefreshTimer(null);
        TypeEventSystem.Send<RefreshActivityRank>();
    }

    void StartInitItem()
    {
        _scrollRect.Init(GameObjType.CarRankItem, rankItem, GetData());
        _scrollRect.SetScrollPos(GetLastIndex());
        if (NeedPlayUpDownAnim())
        {
            _scrollRect.SetUpdateItemCb((obj) =>
            {
                foreach (var scrollItem in _scrollRect.GetItemList())
                {
                    scrollItem.gameObject.MSetActive(scrollItem.Index != dataService.CarRankProgress.myData.rank);
                }
                rankItem.transform.SetAsLastSibling();
            });
            foreach (var scrollItem in _scrollRect.GetItemList())
            {
                scrollItem.gameObject.MSetActive(scrollItem.Index != dataService.CarRankProgress.myData.rank);
            }
        }
    }
    
    object[] GetData()
    {
        List<CarRankData> list = dataService.CarRankProgress.GetRankData();
        object[] data = new object[list.Count];
        int index = 0;
        foreach (var VARIABLE in list)
        {
            data[index] = VARIABLE;
            index++;
        }
        return data;
    }

    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.carRank);
        if (model != null)
        {
            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.CarRankProgress.ActivityEndTime);
            }
        }
        timeItem.SetTimeData(timeData);
    }

    private void InitPanel()
    {
        StartInitItem();
        
        int lastRank = dataService.CarRankProgress.GetMyData().lastRank;
        int index = 0;
        foreach (var scrollItem in _scrollRect.GetItemList())
        {
            RectTransform rect = scrollItem.transform.GetComponent<RectTransform>();
            rect.anchoredPosition = new Vector2(1000, rect.anchoredPosition.y);
            rect.DOAnchorPos(new Vector2(-30, rect.anchoredPosition.y), Mathf.Min(0.3f + index * 0.05f, 0.6f))
                .SetEase(Ease.InOutQuad).OnComplete(() =>
                {
                    rect.DOAnchorPos(new Vector2(0,rect.anchoredPosition.y),0.05f).SetEase(Ease.OutSine);
                });
            
            if (NeedPlayUpDownAnim() && scrollItem.Index == lastRank)
            {
                InitRankAnim(rect,index);
            }
            index++;
        }

        if (!NeedPlayUpDownAnim())
        {
            Observable.Timer(TimeSpan.FromSeconds(1f)).Subscribe(_ => IsPlayingAnim = false);
        }
    }

    private void InitRankAnim(RectTransform rect,int index)
    {
        IsPlayingAnim = true;
        float time = Mathf.Min(0.3f + index * 0.05f, 0.6f);
        Sequence seq = DOTween.Sequence();
        rankItem.GetComponent<CarRankItem>().SetData(dataService.CarRankProgress.GetMyData());
        rankItem.transform.SetParent(_scrollRect.GetContentRect());
        rankItem.transform.SetAsLastSibling();
        rankItem.SetActive(true);
        RectTransform tempRect = rankItem.transform.GetComponent<RectTransform>();
        tempRect.anchoredPosition = new Vector2(1000, rect.anchoredPosition.y);
        tempRect.DOAnchorPos(new Vector2(-30, tempRect.anchoredPosition.y),time)
            .SetEase(Ease.InOutQuad).OnComplete(() =>
            {
                tempRect.DOAnchorPos(new Vector2(0, tempRect.anchoredPosition.y), 0.05f).SetEase(Ease.OutSine);
            });
        Observable.Timer(TimeSpan.FromSeconds(time + 0.2f)).Subscribe(_ =>
        {
            AdjustPivot(tempRect,Vector2.one * 0.5f);
            _rectMask2D.padding = new Vector4(-50, 0, -50, 0);
            seq.Join(tempRect.DOScale(Vector3.one * 1.1f, 0.2f));
            seq.Join(PlayRankChangeAnim());
        });
    }
    
    private Tween PlayRankChangeAnim()
    {
        Sequence seq = DOTween.Sequence();
        int curRank = dataService.CarRankProgress.GetMyData().rank;
        float scrollTime = GetScrollTime();
        if(IsNeedScroll) _scrollRect.SetScrollPos(GetCurIndex(),true,scrollTime);
        RectTransform tempRect = rankItem.transform.GetComponent<RectTransform>();
        seq.Join(tempRect.DOScale(Vector3.one , 0.2f)).SetDelay(scrollTime - 0.2f);
        seq.Join(tempRect.DOAnchorPos(new Vector2(tempRect.sizeDelta.x / 2, -curRank * tempRect.sizeDelta.y - tempRect.sizeDelta.y / 2), scrollTime)).OnComplete(
            () =>
            {
                tempRect.gameObject.SetActive(false);
                foreach (var scrollItem in _scrollRect.GetItemList())
                {
                    scrollItem.gameObject.MSetActive(true);
                }
                _rectMask2D.padding = Vector4.zero;
                _scrollRect.SetUpdateItemCb(null);
                dataService.CarRankProgress.ResetLastRank();
                IsPlayingAnim = false;
            });
        return seq;
    }

    float GetScrollTime()
    {
        int lastRank = dataService.CarRankProgress.GetMyData().lastRank;
        int curRank = dataService.CarRankProgress.GetMyData().rank;
        int index = Mathf.Abs(lastRank - curRank);
        return Mathf.Clamp(index * 0.1f, 0.6f, 1.5f);
    }

    void AdjustPivot(RectTransform rectTransform, Vector2 newPivot)
    {
        // 保存当前视觉位置
        Vector2 originalSize = rectTransform.rect.size;
        Vector2 originalPivot = rectTransform.pivot;
        Vector2 originalPosition = rectTransform.anchoredPosition;

        // 更新 pivot
        rectTransform.pivot = newPivot;

        // 计算新的 anchoredPosition
        Vector2 pivotDelta = newPivot - originalPivot;
        Vector2 sizeDelta = originalSize * pivotDelta;

        rectTransform.anchoredPosition = originalPosition + sizeDelta;
    }

    private bool NeedPlayUpDownAnim()
    {
        return dataService.CarRankProgress.GetMyData().rank != dataService.CarRankProgress.GetMyData().lastRank;
    }
    
    private int GetCurIndex()
    {
        return Mathf.Max(dataService.CarRankProgress.GetMyData().rank - 3,0);
    }

    private int GetLastIndex()
    {
        return Mathf.Max(dataService.CarRankProgress.GetMyData().lastRank - 3,0);
    }
}