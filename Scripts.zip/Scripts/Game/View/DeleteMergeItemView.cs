﻿using SoliUtils;
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class DeleteMergeItemView : ViewBase
{
    private IDataService _dataService;
    private IConfigService _configService;
    private Text _priceText;
    private Image _icon;
    private MergeItem _item;
    protected override void OnAwake()
    {
        _dataService = MainContainer.Container.Resolve<IDataService>();
        _configService = MainContainer.Container.Resolve<IConfigService>();
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(CloseFunc);
        transform.Get<Button>("Container/RecycleBtn").SetButtonClick(RecycleFunc);
        _priceText = transform.Get<Text>("Container/RecycleBtn/Price");
        _icon = transform.Get<Image>("Container/Icon");
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    private void RecycleFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
        _dataService.RecycleMergeItem(_item.GridId);
    }

    public void SetParams(MergeItem item)
    {
        _item = item;
        int itemId = item.GetItemId();
        MergeItemConfig config = _configService.MergeItemConfig[itemId];
        string[] texts = config.sale.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
        _priceText.text = texts[1];
        LoadIcon(itemId);

    }

    private void LoadIcon(int itemId)
    {
        _icon.LoadPropSprite(itemId, true, () => 
        {
            //float targetHeight = 188;
            //float targetWidth = 188;
            float maxHeight = 188;
            float maxWidth = 188;
            float originalWidth = _icon.sprite.rect.width;
            float originalHeight = _icon.sprite.rect.height;
            float aspectRatio = originalWidth / originalHeight;
            float newWidth;
            float newHeight;
            float scaleHeight = maxHeight / originalHeight;
            float scaleWidth = maxWidth / originalWidth;
            float scale = Mathf.Min(scaleHeight, scaleWidth);
            newHeight = originalHeight * scale;
            newWidth = originalWidth * scale;
            _icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
        });
    }
}