using System;
using System.Linq;
using System.Collections.Generic;
using Activities;
using UniRx;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using UnityEngine.Rendering;
using Doozy.Engine.UI;
using Doozy.Engine.UI.Animation;
using SoliUtils;

public class GameView : ViewBase
{
    [SerializeField] private InputField valueInputField;

    [SerializeField] private Button undoBtn;
    [SerializeField] private GameObject freeUndoBG;
    [SerializeField] private Text freeUndoNum;
    [SerializeField] private Text undoCost;

    [SerializeField] private Button jokerBtn;
    [SerializeField] private Text jokerCost;
    [SerializeField] private GameObject freeJoker;

    [SerializeField] private RectTransform buyCardRect;
    [SerializeField] private Text buyCardCost;
    [SerializeField] private GameObject freeBuyCard;
    [SerializeField] private RectTransform endGameBtn;

    [SerializeField] private Button settingBtn;
    [SerializeField] private Button skipBtn;
    [SerializeField] private RectTransform settingBG;
    [SerializeField] private Button settingMask;
    [SerializeField] private GameObject musicMute;
    [SerializeField] private GameObject soundMute;
    [SerializeField] private RectTransform comboBg;
    [SerializeField] private Animator comboBgAnim;
    [SerializeField] private RectTransform comboRoot;

    RectTransform addRewardParent;
    RectTransform addValueTrans;
    RectTransform addJokerTrans;
    RectTransform addCoinTrans;

    private RectTransform curRewardTrans;
    private RectTransform nextRewardTrans;

    private List<RectTransform> comboProgress;
    private int lastListNum;
    private RectTransform nowComboRewardRect;
    private IDisposable runningComboSubscribe;
    private List<GameObject> flyComboList = new List<GameObject>();

    private static Vector2 ShowEndGamePos = new Vector2(277, 67);
    private static Vector2 HideEndGamePos = new Vector2(277, -107);
    private static Vector2 ShowBuyCardPos = new Vector2(-128, 103);
    private static Vector2 HideBuyCardPos = new Vector2(-128, -109);
    private bool isShowBuyCard;

    private GameObject buyCardTipFx;
    private GameObject jokerCardTipFx;
    private GameObject undoTipFx;
    private RectTransform bottomRect;

    private bool isShowSetting;
    private bool isPlayingScaleAnim;
    private int lastStarCount;

    private Tween coinRollTween;
    private Tween comboRootSacle;
    private Sequence flyStepStarTween;
    private Sequence flyStepCoinTween;
    private Sequence comboRewardRootSeq;
    private Queue<bool?[]> comboColorQueue = new Queue<bool?[]>();
    private int showCoinTextNum;
    private int toShowCoinReward;
    private int toShowStarReward;
    private bool isRookieLevel = false;
    private GameObject flower;
    private GameObject collectItemFx;
    private Text lvText;
    private RectTransform lvTextBg;
    private RectTransform groupRect;
    private Text flowerText;
    private List<ComboChangeEvent> ComboChangeEventList = new List<ComboChangeEvent>();
    private bool InComboAnim = false;
    private int comboStep;

    protected override void OnAwake()
    {
        GlobalRes.DynamicLoadView(Constants.DoozyView.Result);
        // GlobalRes.DynamicLoadView(Constants.DoozyView.Star);

        addRewardParent = comboBg.Get<RectTransform>("AddReward");
        addValueTrans = addRewardParent.Get<RectTransform>("AddValueCard");
        addJokerTrans = addRewardParent.Get<RectTransform>("AddJokerCard");
        addCoinTrans = addRewardParent.Get<RectTransform>("AddCoin");
        curRewardTrans = addRewardParent.Get<RectTransform>("CurReward");
        nextRewardTrans = addRewardParent.Get<RectTransform>("NextReward");

        isShowSetting = false;
        settingBG.localScale = new Vector3(1, 0, 1);
        settingMask.gameObject.SetActive(false);
        settingMask.SetButtonClick(() => SetSettingBGOpen(false));
        endGameBtn.GetComponent<Button>().SetButtonClick(ExitBtnEvent);
        skipBtn.gameObject.SetActive(false);
        skipBtn.GetComponent<Button>().SetButtonClick(() =>
        {
            GameUtils.SetTimeScale(100f);
        });
        SetSettingBGOpen(false);

        isShowBuyCard = false;
        buyCardRect.anchoredPosition = HideBuyCardPos;
        buyCardRect.GetComponent<Button>().onClick.AddListener(() =>
        {
            if (GameController.Instance.IsRendering) return;
            SoundPlayer.Instance.PlayMainSound("Plus5");
            TypeEventSystem.Send<BuyCardsEvent>();
        });

        buyCardTipFx = buyCardRect.transform.Find("TipFx").gameObject;
        jokerCardTipFx = jokerBtn.transform.Find("TipFx").gameObject;
        undoTipFx = undoBtn.transform.Find("TipFx").gameObject;
        buyCardTipFx.SetActive(false);
        jokerCardTipFx.SetActive(false);
        undoTipFx.SetActive(false);
        bottomRect = transform.Find("Layout/Bottom").GetComponent<RectTransform>();
        flower = transform.Find("Layout/Group/Flower").gameObject;
        collectItemFx = flower.transform.Find("fx").gameObject;
        flowerText = flower.Get<Text>("Text");
        groupRect = transform.Get<RectTransform>("Layout/Group");
        lvText = transform.Get<Text>("Layout/Group/LevelTitle/Num");
        lvTextBg = transform.Get<RectTransform>("Layout/Group/LevelTitle/TextBG");
        comboBg.gameObject.SetActive(false);
    }

    void Update()
    {
        if (!InComboAnim)
        {
            if (ComboChangeEventList.Count > 0)
            {
                var comboEvent = ComboChangeEventList[0];
                ComboChangeEventList.RemoveAt(0);
                ShowComboAnim(comboEvent);
            }
        }
    }

    void ShowComboAnim(ComboChangeEvent e)
    {
        if (e.comboLimit == int.MaxValue)
        {
            comboBg.gameObject.SetActive(false);
            return;
        }
        bool undo = e.comboStep < comboStep;
        comboStep = e.comboStep;
        comboBg.gameObject.SetActive(true);
        InComboAnim = true;
        bool nearCombo = e.comboCount == e.comboLimit - 1;
        bool finishCombo = e.comboCount > 0 && e.comboCount == e.comboLimit;
        bool isShowFlowerIcon = ActivityManager.Instance.GetActivityByType(ActivityType.collectFlower).state == ActivityState.underWay && e.colors.Count > 1;
        bool isSameColorCombo = true;
        // if (e.colors.Count > 1)
        // {
        //     foreach (var value in e.colors)
        //     {
        //         if (value != e.colors[0])
        //         {
        //             isSameColorCombo = false;
        //             break;
        //         }
        //     }
        // }
        // else
        // {
        //     isSameColorCombo = false;
        // }
        isSameColorCombo = false; //屏蔽同色combo

        var gameData = GameController.Instance.BattleCtrl.gameData;
        RefreshComboReward(e.comboStep,
            configService.GetComboItemReward(gameData.Level, e.comboStep),
            configService.GetComboItemReward(gameData.Level, e.comboStep + 1));

        nowComboRewardRect.Find("ShowFx").gameObject.SetActive(nearCombo);
        curRewardTrans.Find("double").DOScale(isSameColorCombo ? Vector3.one : Vector3.zero, 0.3f);
        curRewardTrans.Find("flower").DOScale(isShowFlowerIcon ? Vector3.one : Vector3.zero, 0.3f);
        
        if (nearCombo)
        {
            comboBg.DOScale(Vector3.one * 1.02f, 0.5f).SetEase(Ease.InOutSine).
                SetLoops(-1, LoopType.Yoyo).OnComplete(() =>
                {
                    comboBg.localScale = Vector3.one;
                });
        }
        else
        {
            comboBg.DOKill(true);
        }

        for (int i = 0; i < comboProgress.Count; i++)
        {
            RectTransform rect = comboProgress[i];
            rect.gameObject.SetActive(i < e.comboLimit);
        }

        comboRoot.DOSizeDelta(new Vector2(Math.Max(155, 29 * (e.comboLimit + 2) + 15), 54), 0.3f);

        List<GameObject> points = new List<GameObject>();
        int showAnimFrame = 0;
        for (int i = 0; i < comboProgress.Count; i++)
        {
            Transform obj = comboProgress[i];
            bool isShow = i < e.comboCount;
            SortingGroup sorting = obj.Get<SortingGroup>("GetCombo");
            var redObj = obj.Find("GetCombo/RedCombo").gameObject;
            var blackObj = obj.Find("GetCombo/BlackCombo").gameObject;
            redObj.transform.DOKill(true);
            blackObj.transform.DOKill(true);
            if (isShow)
            {
                bool comboColor = e.colors[i];
                points.Add(comboColor ? redObj : blackObj);
                int idx = points.Count;
                if (!points[idx - 1].activeSelf)
                    showAnimFrame += 2;
                if (!(!redObj.activeSelf && comboColor))
                    redObj.SetActive(comboColor);
                if (!(!blackObj.activeSelf && !comboColor))
                    blackObj.SetActive(!comboColor);
                int frame = showAnimFrame;
                UniRx.Observable.TimerFrame(frame).Subscribe(_ =>
                    {
                        points[idx - 1].SetActive(true);
                        points[idx - 1].transform.Find("combo_tx_01").gameObject.SetActive(!undo);
                    });
            }
            else
            {
                redObj.SetActive(false);
                blackObj.SetActive(false);
            }
        }
        if (showAnimFrame > 0)
        {
            comboBg.DOScale(Vector3.one * 0.9f, 0.1f).OnComplete(() =>
            {
                comboBg.DOScale(Vector3.one, 0.2f).SetEase(Ease.InOutSine);
            });
        }
        UniRx.Observable.TimerFrame(showAnimFrame).Subscribe(_ =>
            {
                if (!finishCombo)
                {
                    InComboAnim = false;
                }
            });

        if (finishCombo)
        {
            comboBgAnim.enabled = false;
            comboBgAnim.enabled = true;
            comboBgAnim.Play("combo_dh_01", 0, 0);

            int delayFrame = showAnimFrame + 30;
            int intervalFrame = 1;
            for (int i = 0; i <= points.Count; i++)
            {
                int idx = i;
                if (idx < points.Count)
                {
                    UniRx.Observable.TimerFrame(delayFrame + intervalFrame * (idx + 1)).Subscribe(_ =>
                        {
                            points[idx].SetActive(false);
                        });
                }
                else
                {
                    UniRx.Observable.TimerFrame(delayFrame + intervalFrame * (idx + 1)).Subscribe(_ =>
                        {
                            //临时处理，不要在view直接AddComboCards
                            var reward = configService.GetComboItemReward(gameData.Level, e.comboStep);
                            var cardType = reward.rewardType == 2 ? CardType.Value : CardType.Joker;
                            BattleDataMgr.Instance.AddComboCards(isSameColorCombo ? 2 : 1, cardType, 0.1f);

                            curRewardTrans.gameObject.SetActive(false);

                            UniRx.Observable.TimerFrame(30).Subscribe(_ =>
                            {
                                addRewardParent.GetComponent<Animator>().enabled = true;
                                addRewardParent.GetComponent<Animator>().Play("ani_game_addreward", 0, 0);

                                UniRx.Observable.TimerFrame(30).Subscribe(_ =>
                                {
                                    curRewardTrans.gameObject.SetActive(true);
                                    InComboAnim = false;
                                });
                            });
                        });
                }

            }
        }
    }

    void Start()
    {
        GameObjTransInfo.UndoPos =
            Camera.main.ScreenToWorldPoint(
                RectTransformUtility.WorldToScreenPoint(Camera.main, undoBtn.transform.position));
        GameObjTransInfo.JokerPos =
            Camera.main.ScreenToWorldPoint(
                RectTransformUtility.WorldToScreenPoint(Camera.main, jokerBtn.transform.position));
        GameObjTransInfo.BuyCardsPos = new Vector3(ShowBuyCardPos.x,
            ShowBuyCardPos.y - GetComponent<RectTransform>().rect.height / 2, 0);

        var gmBtn = transform.Find("Layout/Bottom/SettingBG/Button - GM");
        if (gmBtn != null)
        {
#if UNITY_EDITOR
            gmBtn.gameObject.SetActive(true);
#else
            gmBtn.gameObject.SetActive(GameCommon.IsGmMode);
#endif
        }

        TypeEventSystem.Send<BigBombEvent>(new BigBombEvent(false));
        comboProgress = new List<RectTransform>();
        for (int i = 0; i < comboRoot.childCount; i++)
        {
            RectTransform newProgress = comboRoot.GetChild(i).GetComponent<RectTransform>();
            newProgress.gameObject.SetActive(false);
            newProgress.Find("GetCombo/RedCombo").gameObject.SetActive(false);
            newProgress.Find("GetCombo/BlackCombo").gameObject.SetActive(false);
            comboProgress.Add(newProgress);
        }
    }

    void CheckCollectFlower(AddFlowerEvent obj = null)
    {
        flower.SetActive(dataService.CollectFlowerEnableState() == 1);
        if (obj == null)
        {
            flowerText.text = $"{ActivityManager.Instance.CollectFlowerActivity.GetReadyAddCount()}";
            curRewardTrans.Find("flower").localScale = Vector3.zero;
        }
        else
        {
            PlayAddFlowerAnim(obj);
        }
    }

    void InitLevelTitle()
    {
        lvText.text = dataService.NowMaxLevel.ToString();
        Observable.NextFrame().Subscribe(_ =>
        {
            lvTextBg.sizeDelta = new Vector2(lvText.preferredWidth + 90, 56);
            lvTextBg.parent.GetComponent<RectTransform>().sizeDelta = lvTextBg.sizeDelta;
        });
    }

    Tween PlayAddFlowerAnim(AddFlowerEvent obj)
    {
        int orignCount = dataService.CollectFlowerProgress.ResultAddCount - Mathf.Abs(obj.addCount);
        int endCount = dataService.CollectFlowerProgress.ResultAddCount;
        if (obj.addCount < 0)
        {
            DOTween.To(value => { flowerText.text = Mathf.Floor(value).ToString(); }, orignCount, endCount, 0.2f).SetEase(Ease.OutQuad);
            return null;
        }
        int textCount = Mathf.Max(obj.addCount, 5);
        GameObjType objType = GameObjType.FlyFlowerItem;
        Vector3 tempOffset = Vector3.zero;
        float scaleFactor = 0.8f;

        if (!GameObjManager.Instance.CheckGoHasPreLoad(objType)) return null;
        textCount = Math.Min(textCount, 5);

        Sequence rootSeq = DOTween.Sequence();
        Vector3 startPos = curRewardTrans.Find("flower").transform.position;
        Vector3 endPos = flower.transform.position;
        Vector3 controlPos = startPos + new Vector3(-300, -200);

        for (int i = 0; i < textCount; i++)
        {
            int index = i;
            Transform starTrans = GameObjManager.Instance.PopGameObject(objType).transform;
            starTrans.GetComponent<Image>().SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectFlowerAtlas, "rose", false);


            Text text = starTrans.Get<Text>("Text");
            if (index == textCount - 1)
            {
                text.transform.localScale = Vector3.one;
                text.text = $"+{obj.addCount}";
            }
            else
            {
                text.transform.localScale = Vector3.zero;
            }

            starTrans.GetComponent<Canvas>().sortingOrder = i + 1;
            starTrans.SetParent(transform, false);
            starTrans.localScale = Vector3.zero;
            starTrans.position = startPos;
            Vector3 beginPos = startPos + new Vector3(GameUtils.RandomRange(-25f, 25f), GameUtils.RandomRange(-100f, 0f));
            Vector3[] bezierArray = BezierUtils.GetBeizerList(beginPos, controlPos, endPos, 5);

            Sequence seq = DOTween.Sequence();
            seq.AppendInterval(0.7f + 0.04f * index);
            seq.AppendCallback(() => starTrans.gameObject.SetActive(true));
            seq.Append(starTrans.DOMove(beginPos, 0.3f).SetEase(Ease.OutQuad));
            // seq.Join(curRewardTrans.Find("flower").DOScale(Vector3.zero, 0.3f));
            seq.Join(starTrans.DOScale(Vector3.one * scaleFactor, 0.3f));
            seq.AppendInterval(0.2f);
            seq.Append(starTrans.DOPath(bezierArray, 1f, PathType.CatmullRom).SetEase(Ease.InSine));
            seq.AppendCallback(() =>
            {
                seq.Join(flower.transform.DOScale(Vector3.one * 1.4f, 0.1f));
                seq.Join(flower.transform.DOScale(Vector3.one, 0.1f));
                if (index == 0) SoundPlayer.Instance.PlayStarHit();
                GameObject newStarFx = GameObjManager.Instance.PopGameObject(GameObjType.CollectItemFx, collectItemFx);
                newStarFx.transform.SetParent(flower.transform);
                newStarFx.transform.localScale = Vector3.one;
                newStarFx.transform.position = endPos;
                newStarFx.SetActive(true);
                GameObjManager.Instance.PushGameObject(starTrans.gameObject);
                GameObjManager.Instance.PushGameObject(newStarFx.gameObject, 2);
            });
            rootSeq.Join(seq);
        }

        rootSeq.AppendCallback(() =>
        {
            // curRewardTrans.Find("flower").DOScale(Vector3.one, 0.3f);
            DOTween.To(value => { flowerText.text = Mathf.Floor(value).ToString(); }, orignCount, endCount, 0.2f).SetEase(Ease.OutQuad);
        });
        return rootSeq;
    }

    private void SetSkipBtnState(ShowGameSkipBtn obj)
    {
        skipBtn.gameObject.MSetActive(false);
        return;
        skipBtn.gameObject.SetActive(obj.isShow);
        if (!obj.isShow)
        {
            GameUtils.SetTimeScale(1);
        }
    }

    protected override void OnViewInit(bool isFirst)
    {
        musicMute.SetActive(dataService.MusicMute);
        soundMute.SetActive(dataService.SoundMute);
        if (isFirst == false) return;
        TypeEventSystem.Register<UpdateUndoBtnState>(OnUpdateUndoBtnState);
        TypeEventSystem.Register<UpdateCurRewardState>(OnUpdateCurRewardState);
        TypeEventSystem.Register<GameInitFinishEvent>(OnGameInitFinish);
        TypeEventSystem.Register<PlayGameExitAnim>(HandleExitAnim);
        TypeEventSystem.Register<PlayGameEntryAnim>(HandleEntryAnim);
        TypeEventSystem.Register<ShowGameSkipBtn>(SetSkipBtnState);
        TypeEventSystem.Register<AddFlowerEvent>(CheckCollectFlower);
        TypeEventSystem.Register<AddComboFinishCoinEvent>(AddComboFinishCoin);
        TypeEventSystem.Register<HandCardChangeEvent>(OnHandCardChangeEvent);
        TypeEventSystem.Register<MoveGameViewBottom>(MoveBottom);
        TypeEventSystem.Register<MusicMuteEvent>(OnMusicMuteEvent);
        TypeEventSystem.Register<SoundMuteEvent>(OnSoundMuteEvent);
        TypeEventSystem.Register<ScaleJokerEvent>(OnScaleJokerEvent);
        TypeEventSystem.Register<ScaleUndoEvent>(OnScaleUndoEvent);
        TypeEventSystem.Register<PropChangeEvent>(OnPropChangeEvent);
        TypeEventSystem.Register<CanUndoChangeEvent>(OnCanUndoChangeEvent);
        TypeEventSystem.Register<GameRewardChangeEvent>(OnGameRewardChangeEvent);
        TypeEventSystem.Register<RefreshGameViewEvent>(OnRefreshGameViewEvent);
        TypeEventSystem.Register<GM_HideUI>(OnGmHideUI);
        TypeEventSystem.Register<UIPopupEvent>(OnUIPopupEvent);
        TypeEventSystem.Register<GameUpdateItemEvent>(OnRefreshReward);
        TypeEventSystem.Register<BigBombEvent>(OnBigBombEvent);
        // TypeEventSystem.Register<ComboNumEvent>(OnComboNumEvent);
        TypeEventSystem.Register<ComboChangeEvent>(OnComboChangeEvent);

    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateUndoBtnState>(OnUpdateUndoBtnState);
        TypeEventSystem.UnRegister<UpdateCurRewardState>(OnUpdateCurRewardState);
        TypeEventSystem.UnRegister<GameInitFinishEvent>(OnGameInitFinish);
        TypeEventSystem.UnRegister<PlayGameExitAnim>(HandleExitAnim);
        TypeEventSystem.UnRegister<PlayGameEntryAnim>(HandleEntryAnim);
        TypeEventSystem.UnRegister<ShowGameSkipBtn>(SetSkipBtnState);
        TypeEventSystem.UnRegister<AddFlowerEvent>(CheckCollectFlower);
        TypeEventSystem.UnRegister<AddComboFinishCoinEvent>(AddComboFinishCoin);
        TypeEventSystem.UnRegister<HandCardChangeEvent>(OnHandCardChangeEvent);
        TypeEventSystem.UnRegister<MoveGameViewBottom>(MoveBottom);
        TypeEventSystem.UnRegister<MusicMuteEvent>(OnMusicMuteEvent);
        TypeEventSystem.UnRegister<SoundMuteEvent>(OnSoundMuteEvent);
        TypeEventSystem.UnRegister<ScaleJokerEvent>(OnScaleJokerEvent);
        TypeEventSystem.UnRegister<ScaleUndoEvent>(OnScaleUndoEvent);
        TypeEventSystem.UnRegister<PropChangeEvent>(OnPropChangeEvent);
        TypeEventSystem.UnRegister<CanUndoChangeEvent>(OnCanUndoChangeEvent);
        TypeEventSystem.UnRegister<GameRewardChangeEvent>(OnGameRewardChangeEvent);
        TypeEventSystem.UnRegister<RefreshGameViewEvent>(OnRefreshGameViewEvent);
        TypeEventSystem.UnRegister<GM_HideUI>(OnGmHideUI);
        TypeEventSystem.UnRegister<UIPopupEvent>(OnUIPopupEvent);
        TypeEventSystem.UnRegister<GameUpdateItemEvent>(OnRefreshReward);
        TypeEventSystem.UnRegister<BigBombEvent>(OnBigBombEvent);
        // TypeEventSystem.UnRegister<ComboNumEvent>(OnComboNumEvent);
        TypeEventSystem.UnRegister<ComboChangeEvent>(OnComboChangeEvent);
    }

    private void OnUIPopupEvent(UIPopupEvent e)
    {
        if ((e.popup.PopupName == Constants.DoozyView.ExitGameTipPopup ||
             e.popup.PopupName == Constants.DoozyView.EndWinStreakPopup)
            && e.animationType == AnimationType.Hide)
        {
            buyCardTipFx.SetActive(true);
            jokerCardTipFx.SetActive(true);
            undoTipFx.SetActive(true);
            UniRx.Observable.EveryUpdate()
                .Where(_ => Input.GetMouseButtonDown(0) || Input.touchCount > 0)
                .First()
                .Subscribe(_ =>
                {
                    buyCardTipFx.SetActive(false);
                    jokerCardTipFx.SetActive(false);
                    undoTipFx.SetActive(false);
                });
        }
    }

    private void OnGmHideUI(GM_HideUI e)
    {
        comboBg.gameObject.SetActive(e.isVisibel);
        GoldView.Instance.ShowGold = e.isVisibel;
    }

    private void OnGameRewardChangeEvent(GameRewardChangeEvent e)
    {
        if (e.prop == (int)PropEnum.StageStar)
        {
            toShowStarReward = e.newNum;
            if (e.isAdd)
            {
                AddComboStar(e);
            }
        }

        if (e.prop == (int)PropEnum.Coin)
        {
            toShowCoinReward = e.newNum;
            if (e.isAdd && e.changeWay == PropChangeWay.ComboStep)
            {
                int flyCoinCount = configService.GetCoinFlyCount(e.newNum - e.oldNum);
            }
            else if (e.isAdd && e.changeWay == PropChangeWay.CoinMod)
            {
            }
            else
            {
                CreatRollCoinTween(-1);
            }
        }
    }

    private Tween CreatRollCoinTween(float rollTime)
    {
        if (coinRollTween == null && rollTime <= 0)
        {
            return null;
        }

        if (coinRollTween != null)
            coinRollTween.Kill(false);
        coinRollTween = DOTween.To(value =>
        {
            long diff = toShowCoinReward - showCoinTextNum;
            showCoinTextNum = toShowCoinReward - (int)(diff / rollTime * (rollTime - value));
        }, 0, rollTime, rollTime);
        coinRollTween.onComplete += () =>
        {
            showCoinTextNum = toShowCoinReward;
            coinRollTween = null;
        };
        return coinRollTween;
    }

    private void AddComboStar(GameRewardChangeEvent e)
    {
 
    }

    //Combo������Combo���
    public void AddComboFinishCoin(AddComboFinishCoinEvent e)
    {
        FlowAddEvent t = GameObjManager.Instance.PopClass<FlowAddEvent>(true);
        t.Init(e.addCoin, 1, addCoinTrans.transform.position - new Vector3(0, 50, 0), PropEnum.Coin, 0, true);
        TypeEventSystem.Send<FlowAddEvent>(t);
    }

    private void OnRefreshReward(GameUpdateItemEvent e)
    {
        if (!GameController.Instance.IsPlaying) return;
        RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
        t.Init(GameController.Instance.BattleCtrl.gameData);
        OnRefreshGameViewEvent(t);
    }

    private void OnRefreshGameViewEvent(RefreshGameViewEvent e)
    {
        SetCostText(jokerCost, e.gameData.GetNowBuyJokerCost());
        SetCostText(undoCost, e.gameData.GetNowUndoCost());
        SetCostText(buyCardCost, e.gameData.GetNowBuyCardCost());
    }

    private void OnComboChangeEvent(ComboChangeEvent e)
    {
        if (isRookieLevel) return;
        ComboChangeEventList.Add(e);
    }

    public void OnUpdateCurRewardState(UpdateCurRewardState obj)
    {
        curRewardTrans.gameObject.SetActive(obj.state);
    }

    //刷新奖励
    private void RefreshComboReward(int comboStep, ComboRewardModel nowRewardModel, ComboRewardModel nextRewardModel)
    {
        addCoinTrans.gameObject.SetActive(false);
        addValueTrans.gameObject.SetActive(false);
        addJokerTrans.gameObject.SetActive(false);

        void RefreshRewardShow()
        {
            nextRewardTrans.Find("coin").gameObject.SetActive(nextRewardModel.rewardType == 1);
            nextRewardTrans.Find("card").gameObject.SetActive(nextRewardModel.rewardType == 2);
            nextRewardTrans.Find("wild").gameObject.SetActive(nextRewardModel.rewardType == 3);
            string num = "+" + nextRewardModel.rewardNum;
            if (nextRewardModel.rewardType == 1)
            {
                num = "+" + (nextRewardModel.rewardNum * dataService.NowBet);
            }
            //nextRewardTrans.Find("Text").GetComponent<Text>().text = num;
            nextRewardTrans.gameObject.SetActive(true);

            curRewardTrans.Find("coin").gameObject.SetActive(nowRewardModel.rewardType == 1);
            curRewardTrans.Find("card").gameObject.SetActive(nowRewardModel.rewardType == 2);
            curRewardTrans.Find("wild").gameObject.SetActive(nowRewardModel.rewardType == 3);
            curRewardTrans.Find("double").DOScale(Vector3.zero, 0.3f);
            num = "+" + nowRewardModel.rewardNum;
            if (nowRewardModel.rewardType == 1)
            {
                num = "+" + (nowRewardModel.rewardNum * dataService.NowBet);
            }

            nowComboRewardRect = curRewardTrans;
            nowComboRewardRect.gameObject.SetActive(true);
            nowComboRewardRect.anchoredPosition = new Vector2(0, 0);
            GameObjTransInfo.ComboAddCardPos =
                Camera.main.ScreenToWorldPoint(
                    RectTransformUtility.WorldToScreenPoint(Camera.main, curRewardTrans.transform.position));
        }

        RefreshRewardShow();
    }

    protected override void OnShow()
    {
        GameCommon.IsShowCarding = true;
        GoldView.Instance.ShowGold = false;
        GC.Collect();
        ResetEntryAnim();
    }

    private void SetCanUndo(bool canUndo)
    {
        long propNum = dataService.GetPropNum((int)PropEnum.FreeUndo);
        freeUndoBG.SetActive(propNum > 0);
        if (freeUndoBG.activeInHierarchy)
            freeUndoNum.text = propNum.ToString();
    }

    private void ResetEntryAnim()
    {
        bottomRect.anchoredPosition = new Vector2(0, -200);
        comboBg.anchoredPosition = new Vector2(326, 200);
        groupRect.anchoredPosition = new Vector2(0, 200);
    }
    
    private void HandleEntryAnim(PlayGameEntryAnim obj)
    {
        bottomRect.DOAnchorPos(Vector2.zero, 0.5f);
        comboBg.DOAnchorPos(new Vector2(326, -50), 0.5f);
        groupRect.DOAnchorPos(Vector2.zero, 0.5f);
    }

    private void HandleExitAnim(PlayGameExitAnim obj)
    {
        bottomRect.DOAnchorPos(new Vector2(0, -200),0.5f);
        comboBg.DOAnchorPos(new Vector2(326, 200),0.5f);
        groupRect.DOAnchorPos(new Vector2(0, 200),0.5f);
    }
    
    
    private void CheckWild()
    {
        var isOpen = configService.GetBuyJokerCost(GameController.Instance.BattleCtrl.BattleLevel, 1) > 0;
        jokerBtn.gameObject.SetActive(isOpen);
        jokerCost.transform.parent.gameObject.SetActive(isOpen);
    }

    private void OnDisable()
    {
        SetSettingBGOpen(false);
        MoveBuyCardRect(false, true);
        GameCommon.IsShowCarding = false;
        GoldView.Instance.ShowGold = true;
    }

    private void OnScaleJokerEvent(GameEvent e)
    {
        if (GameController.Instance.BattleCtrl.gameData.CanJoker())
            DoScaleAnim(jokerBtn.transform);
    }

    private void OnScaleUndoEvent(GameEvent e)
    {
        if (!undoBtn.gameObject.activeSelf)
            return;
        DoScaleAnim(undoBtn.transform);
    }

    private void DoScaleAnim(Transform trans)
    {
        trans.DOKill();
        var seq = DOTween.Sequence();
        seq.Insert(0f, trans.DOScaleX(1.2f, 0.1f));
        seq.Insert(0f, trans.DOScaleY(1.2f, 0.1f));
        seq.Insert(0.1f, trans.DOScaleX(0.9f, 0.1f));
        seq.Insert(0.1f, trans.DOScaleY(0.9f, 0.1f));
        seq.Insert(0.2f, trans.DOScaleX(1.15f, 0.1f));
        seq.Insert(0.2f, trans.DOScaleY(1.15f, 0.1f));
        seq.Insert(0.3f, trans.DOScaleX(0.95f, 0.1f));
        seq.Insert(0.3f, trans.DOScaleY(0.95f, 0.1f));
        seq.Insert(0.4f, trans.DOScaleX(1.1f, 0.1f));
        seq.Insert(0.4f, trans.DOScaleY(1.1f, 0.1f));
        seq.Insert(0.5f, trans.DOScaleX(1f, 0.1f));
        seq.Insert(0.5f, trans.DOScaleY(1f, 0.1f));
        seq.Play();
    }

    private void OnMusicMuteEvent(MusicMuteEvent obj)
    {
        // musicMute.SetActive(obj.isMute);
    }

    private void OnSoundMuteEvent(SoundMuteEvent obj)
    {
        // soundMute.SetActive(obj.isMute);
    }

    public void BackBtnEvent()
    {
        TypeEventSystem.Send<CleanGameEvent>();
        SoundPlayer.Instance.PlayButton();
    }

    public void UndoBtnEvent()
    {
        if (GameController.Instance.IsRendering)
            return;
        TypeEventSystem.Send<UndoEvent>();
        SoundPlayer.Instance.PlayUndo();
    }

    public void JokerBtnEvent()
    {
        if (!GameController.Instance.IsPlaying) return;
        if (!BattleDataMgr.Instance.CanJoker())
        {
            SoundPlayer.Instance.PlayInvalidMove();
        }
        else
        {
            SoundPlayer.Instance.PlayMagicSkill();
        }

        TypeEventSystem.Send<JokerEvent>();
    }

    public void SettingOpenBtnEvent()
    {
        SetSettingBGOpen(!isShowSetting);
        SoundPlayer.Instance.PlayButton();
    }

    public void ExitBtnEvent()
    {
        SoundPlayer.Instance.PlayButton();
        SetSettingBGOpen(false);
        if (GameController.Instance.IsRendering || !GameController.Instance.IsPlaying) return;
        BoxBuilder.ShowExitGamePopup();
    }

    public void RestartBtnEvent()
    {
        if (GameController.Instance.IsRendering) return;
        var gameData = GameController.Instance.BattleCtrl.gameData;
        SetSettingBGOpen(false);
        SoundPlayer.Instance.PlayButton();
        ActivityManager.Instance.ClearResultAddCount();
        bool isEnough = ActivityManager.Instance.EnergyActivity.GetCurrentEnergy() > 0;
        if (isEnough)
        {
            TypeEventSystem.Send(new BattleCommandEvent() { command = BattleCommand.LoseGame });
            ViewQueueManager.Instance.ClearQueue();
            LevelUtils.LoadLevel(gameData.Level, model =>
            {
                GameUtils.CosumeAndReportStartEvent(gameData.Level, model);
            });
        }
        else
        {
            ActivityManager.Instance.CheckPushGift(Constants.ProductId.BankruptcyPack_4, GiftType.BrokenGift);
        }
    }

    public void GMBtnEvent()
    {
        SoundPlayer.Instance.PlayButton();
        BoxBuilder.ShowGm();
        SetSettingBGOpen(false);
    }

    public void MusicBtnEvent()
    {
        SoundPlayer.Instance.PlayButton();
        dataService.MusicMute = !dataService.MusicMute;
        musicMute.SetActive(dataService.MusicMute);
        if (dataService.MusicMute)
            SoundPlayer.Instance.PauseBgm();
        else
            SoundPlayer.Instance.UnPauseBgm();
    }

    public void SoundBtnEvent()
    {
        SoundPlayer.Instance.PlayButton();
        dataService.SoundMute = !dataService.SoundMute;
        soundMute.SetActive(dataService.SoundMute);
    }

    private void OnUpdateUndoBtnState(UpdateUndoBtnState obj)
    {
        if (!undoBtn.gameObject.activeSelf)
        {
            if (BattleDataMgr.Instance.CanUndo())
            {
                undoBtn.transform.localScale = Vector3.zero;
                undoBtn.transform.DOScale(Vector3.one, 0.3f);
                undoCost.transform.parent.localScale = Vector3.zero;
                undoCost.transform.parent.DOScale(Vector3.one, 0.3f);
            }
        }
        undoBtn.gameObject.MSetActive(BattleDataMgr.Instance.CanUndo());
        undoCost.transform.parent.gameObject.MSetActive(BattleDataMgr.Instance.CanUndo());
    }

    private void OnGameInitFinish(GameInitFinishEvent e)
    {
        comboColorQueue.Clear();
        runningComboSubscribe?.Dispose();
        runningComboSubscribe = null;
        toShowCoinReward = e.gameData.GetCoin();
        toShowStarReward = e.gameData.StarRewardNum;
        isRookieLevel = false;//dataService.MaxLevel == 1;//e.gameData.IsRookieLevel();
        var vis = !isRookieLevel;
        undoBtn.gameObject.SetActive(false);
        undoCost.transform.parent.gameObject.SetActive(false);
        jokerCost.transform.parent.gameObject.SetActive(vis);
        settingBtn.gameObject.SetActive(vis);
        MoveBuyCardRect(false, true);
        OnCanUndoChangeEvent(new CanUndoChangeEvent(e.gameData.CanUndo(), e.gameData));

        lastListNum = 0;
        lastStarCount = 0;
        comboBgAnim.enabled = false;
        ActivityManager.Instance.InitResultAddCount();
        OnPropChangeEvent(null);
        CheckWild();
        CheckCollectFlower();
        SetCostText(undoCost, e.gameData.GetNowUndoCost());
        SetCostText(jokerCost, e.gameData.GetNowBuyJokerCost());
        SetCostText(buyCardCost, e.gameData.GetNowBuyCardCost());
        InitLevelTitle();
        ComboChangeEventList.Clear();
        InComboAnim = false;
        comboStep = 1;
    }

    private void OnHandCardChangeEvent(HandCardChangeEvent e)
    {
        MoveBuyCardRect(e.handCardNum <= 0, false);
    }

    private void OnPropChangeEvent(PropChangeEvent obj)
    {
        if (obj == null || obj.prop == (int)PropEnum.FreeUndo)
        {
            long freeUndoNum = dataService.GetPropNum((int)PropEnum.FreeUndo);
            freeUndoBG.SetActive(freeUndoNum > 0);
            this.freeUndoNum.text = freeUndoNum.ToString();
        }

        if (obj == null || obj.prop == (int)PropEnum.FreeJoker)
        {
            long freeJokerNum = dataService.GetPropNum((int)PropEnum.FreeJoker);
            freeJoker.SetActive(freeJokerNum > 0);
            freeJoker.transform.Get<Text>("Text").text = freeJokerNum.ToString();
        }

        if (obj == null || obj.prop == (int)PropEnum.FreeBuyCard)
        {
            long freeBuyCardNum = dataService.GetPropNum((int)PropEnum.FreeBuyCard);
            freeBuyCard.SetActive(freeBuyCardNum > 0);
            freeBuyCard.transform.Get<Text>("Text").text = freeBuyCardNum.ToString();
        }
    }

    private void OnCanUndoChangeEvent(CanUndoChangeEvent e)
    {
        // Debug.Log($"OnCanUndoChangeEvent====== {e.canUndo}");
        if (isRookieLevel) return;
        SetCanUndo(e.canUndo);
        if (e.gameData != null)
            SetCostText(undoCost, e.gameData.GetNowUndoCost());
    }

    private void SetSettingBGOpen(bool toOpen)
    {
        if (isShowSetting == toOpen) return;
        isShowSetting = toOpen;
        settingMask.gameObject.SetActive(isShowSetting);
        settingBG.DOScale(isShowSetting ? 1 : 0, 0.3f);
    }

    private void MoveBuyCardRect(bool toShow, bool isImmediately)
    {
        if (isRookieLevel) toShow = false;
        if (isShowBuyCard == toShow) return;
        isShowBuyCard = toShow;
        if (toShow)
            buyCardRect.gameObject.SetActive(
                configService.GetBuyCardCost(GameController.Instance.BattleCtrl.BattleLevel, 1) > 0);
        if (isImmediately)
        {
            buyCardRect.anchoredPosition = toShow ? ShowBuyCardPos : HideBuyCardPos;
            endGameBtn.anchoredPosition = toShow ? ShowEndGamePos : HideEndGamePos;
        }
        else
        {
            buyCardRect.DOAnchorPos(toShow ? ShowBuyCardPos : HideBuyCardPos, 0.4f).SetEase(Ease.OutQuad);
            endGameBtn.DOAnchorPos(toShow ? ShowEndGamePos : HideEndGamePos, 0.4f).SetEase(Ease.OutQuad);
        }
    }

    private void MoveBottom(MoveGameViewBottom obj = null)
    {
        // if (obj == null)
        // {
        //     bottomRect.anchoredPosition = Vector2.zero;
        // }
        // else
        // {
        //     bottomRect.anchoredPosition = Vector2.zero;
        // }
        //bottomRect.anchoredPosition = Vector2.zero;
    }

    private void SetCostText(Text costText, int costNum)
    {
        costText.text = costNum > 0 ? costNum.ToString() : "免费";
    }

    private void OnBigBombEvent(BigBombEvent e)
    {
        var bigBombEff = transform.Find("bigbomb");
        if (bigBombEff != null)
        {
            bigBombEff.gameObject.SetActive(e.show);
        }
    }
}