﻿using Activities;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class CollectHoneyView : ViewBase
{
    private Button closeBtn;
    private Button tipBtn;
    private Image fillAmount;
    private ActivityTimeItem timeItem;
    [SerializeField]private List<BottleHoneyItem> bottleItemList;
    private List<float> progressValue = new List<float>() {0,0.2f, 0.37f, 0.54f, 0.7f, 1f};
    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(CloseFunc);
        tipBtn = transform.Get<Button>("Container/TipBtn");
        fillAmount = transform.Get<Image>("Container/Progress/Bg/FillAmount");
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(() =>
        {
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);
            BoxBuilder.HidePopup(gameObject);
        });
    }
    protected override void OnViewInit(bool isFirst)
    {
        if(!isFirst) return;
        TypeEventSystem.Register<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }
    
    //更新排行面板
    private void UpdatePanel(UpdateRankViewEvent obj)
    {

    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateRankViewEvent>(UpdatePanel);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
    }

    
    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.collectHoney);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.collectHoney).ActivityBigEndTime);
            }
            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.CollectHoneyProgress.ActivityEndTime);
            }
        }
        timeItem.SetTimeData(timeData);
    }
    
    
    protected override void OnShow()
    {
        if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockCollectHoneyPopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.UnlockCollectHoneyPopup);
            BoxBuilder.ShowUnlockCollectHoneyPopView();
        }
        UpdateBottle();
        UpdateProgress();
        RefreshTimer(null);
    }

    private void UpdateBottle()
    {
        int index = 0;
        foreach (var bottleItem in bottleItemList)
        {
            bottleItem.UpdateIndex(index);
            index++;
        }
    }

    private void UpdateProgress()
    {
        float value = 0f;
        float percent = (float) ActivityManager.Instance.CollectHoneyActivity.GetCurProgress() /
                        ActivityManager.Instance.CollectHoneyActivity.GetCurMaxProgress();
        if (dataService.CollectHoneyProgress.curLayer == 0)
        {
            value = 0;
        }
        else if (dataService.CollectHoneyProgress.curLayer == 1)
        {
            value = progressValue[1] * percent;
        }
        else
        {
            float t = 0f;
            float t1 = progressValue[dataService.CollectHoneyProgress.curLayer] -
                       progressValue[dataService.CollectHoneyProgress.curLayer - 1];
            for (int i = 0; i < dataService.CollectHoneyProgress.curLayer; i++)
            {
                t = progressValue[i];
            }
            value = t + percent * t1;
        }
        fillAmount.fillAmount = value;
    }
}
