using Doozy.Engine.UI;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

namespace View
{
    public class SignOutSuccessPopView : ViewBase
    {
        [SerializeField] private Button ContinueBtn;

        private UIPopup _uiPopup;
        
        protected override void OnAwake()
        {
            _uiPopup = GetComponent<UIPopup>();
            ContinueBtn.SetButtonClick(OnContinueBtnClick);
        }

        private void OnContinueBtnClick()
        {
            _uiPopup.Hide();
        }
    }
}