using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using System;
using SoliUtils;
using Activities;
using Model;

[RequireComponent(typeof(CanvasGroup))]
public class StartCollectLoveCardPopView : ViewBase
{
    private RectTransform collectFill;
    private GameObject nextRewardItem;
    private Text collectText;
    private Button CloseBtn;
    private Image BgImage2;
    private GameObject CollectLoveCardContent;
    private ActivityTimeItem timeItem;
    protected override void OnAwake()
    {
        CollectLoveCardContent = transform.Get<Transform>("Container/CollectLoveCardContent").gameObject;
        BgImage2 = transform.Get<Image>("Container/BgImage/BgImage2");
        CloseBtn = transform.Get<Button>("Container/CloseBtn");
        CloseBtn.SetButtonClick(CloseFunc);
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(EnterGameFunc);
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");

        nextRewardItem = CollectLoveCardContent.transform.Get<Transform>("Progress/NextRewardItem").gameObject;
        collectFill = CollectLoveCardContent.transform.Get<RectTransform>("Progress/FillAmount");
        collectText = CollectLoveCardContent.transform.Get<Text>("Progress/Text");
        InitPanel();
    }

    private void InitPanel()
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).ActivityBigEndTime);
        if (ActivityManager.Instance.GetActivityByType(ActivityType.collectLoveCard).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.CollectLoveCardProgress.ActivityEndTime);
        }
        dataService.CollectLoveCardProgress.PopBtn = false;
        BgImage2.enabled = false;

        UpdateCollectLoveCardContent();
        
        StopAllCoroutines();
        StartCoroutine(SetTimeItem(timeData));
        RefreshActivityTimer t = GameObjManager.Instance.PopClass<RefreshActivityTimer>(true);
        t.Init(ActivityType.collectLoveCard);
        TypeEventSystem.Send<RefreshActivityTimer>(t);
    }

    IEnumerator SetTimeItem(CountTimeData timeData)
    {
        while (!timeItem.gameObject.activeInHierarchy)
        {
            yield return null; 
        }
        timeItem.SetTimeData(timeData);
    }

    private void UpdateCollectLoveCardContent()
    {
        string tip = "";
        string title = "";
        string key = "";
        if (dataService.CollectLoveCardProgress.SubActivityType == 1)
        {
            key = "axfk_11";
            tip = "开启活动，收集爱心方块牌得奖励!";
            title = "爱心方块收集活动";
        }
        else
        {
            key = "axfk_12";
            BgImage2.SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectLoveCardAtlas, "axfk_14");
            tip = "开启活动，收集黑桃梅花牌得奖励!";
            title = "黑桃梅花收集活动";
            BgImage2.enabled = true;
        }
        CollectLoveCardContent.transform.Get<Image>("Progress/LastRewardItem/Icon").SetSpriteByAtlas(Constants.AtlasNamePath.ViewCollectLoveCardAtlas, key, true);
        transform.Get<Text>("Container/TipText").text = tip;
        transform.Get<Text>("Container/TitleText").text = title;
        SetNextReward();
        SetProgress(ActivityManager.Instance.CollectLoveCardActivity.GetNextReward());
    }

    void SetProgress(List<SeasonLvRewardItem> nextReward)
    {
        int nextCount = ActivityManager.Instance.CollectLoveCardActivity.GetNextLayerCollectCount();
        int curCount = ActivityManager.Instance.CollectLoveCardActivity.GetCurLayerCollectCount();
        collectText.text = $"{curCount}/{nextCount}";
        collectFill.sizeDelta = new Vector2(ActivityManager.Instance.CollectLoveCardActivity.GetRatio() * 526, collectFill.sizeDelta.y);
    }
    
    private void SetNextReward()
    {
        if (ActivityManager.Instance.CollectLoveCardActivity.CurIsMaxLayer())
        {
            nextRewardItem.gameObject.SetActive(false);
            return;
        }
        nextRewardItem.gameObject.SetActive(true);
        foreach (var tempItem in ActivityManager.Instance.CollectLoveCardActivity.GetNextReward())
        {
            int propEnum = int.Parse(tempItem.type.ToString());
            int propCount = tempItem.amount;
            Image propImage = nextRewardItem.transform.Get<Image>("PropImage");
            Text timeText = nextRewardItem.transform.Get<Text>("TimeText");
            Text numText = nextRewardItem.transform.Get<Text>("NumText");
            numText.text = "";
            timeText.gameObject.SetActive(GameUtils.IsLimitTimeReward((int)propEnum));
            if (GameUtils.IsLimitTimeReward((int)propEnum))
            {
                long infiniteTime = propCount;
                timeText.text = infiniteTime / 60 + "m";
            }
            else
            {
                numText.text = propEnum == (int)PropEnum.Coin ? propCount.ToString() : $"x{propCount}";
            }
            propImage.LoadPropSprite(propEnum == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : (int)propEnum);
            break;
        }
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;

    }

    protected override void OnInitedDestroy()
    {

    }
    protected override async void OnShow()
    {

    }

    private void EnterGameFunc()
    {
        ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.StartGamePopup, BoxBuilder.ShowStartGamePopup);
        if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockCollectLoveCardPopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.UnlockCollectLoveCardPopup);
            ViewQueueManager.Instance.AddWaitPopupViewClose(Constants.DoozyView.UnlockCollectLoveCardPopup, BoxBuilder.ShowUnlockCollectLoveCardPopView, true);
        }
        CloseFunc();
    }
}