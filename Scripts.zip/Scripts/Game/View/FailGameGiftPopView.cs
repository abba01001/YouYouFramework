using System;
using System.Collections;
using System.Collections.Generic;
using Activities;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class FailGameGiftPopView : ViewBase
{
    private string productKey = "";
    private bool isAdType = false;
    private Transform itemParent1;
    private Transform itemParent2;
    [SerializeField] private GameObject List1;
    [SerializeField] private GameObject List2;
    [SerializeField] private List<Transform> itemList1 = new List<Transform>();
    [SerializeField] private List<Transform> itemList2 = new List<Transform>();
    private Action BtnEvent;
    public void SetGiftType(string ProductId,bool IsAdType)
    {
        productKey = ProductId;
        isAdType = IsAdType;
        UpdateRewardItem();
    }
    
    void CloseFunc(GameRechargeEvent e = null)
    {
        BoxBuilder.HidePopup(gameObject);
    }
    
    protected override void OnViewInit(bool isFirstTime)
    {
        if (isFirstTime)
        {
            TypeEventSystem.Register<GameRechargeEvent>(CloseFunc);
        }
    }

    protected override void OnViewDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(CloseFunc);
    }

    private void UpdateRewardItem()
    {
        transform.Get<Transform>("Container/BuyBtn/Price").gameObject.SetActive(productKey != "");
        transform.Get<Transform>("Container/BuyBtn/Watch").gameObject.SetActive(isAdType);
        ActivityManager.Instance.AdRewardActivity.RefreshPushAdCount();
        if (isAdType)
        {
            UpdateItem(configService.ValueConfig["FailPushAdReward"]);
            BtnEvent = () =>
            {
                SoundPlayer.Instance.PlayButton();
#if UNITY_EDITOR
                BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(configService.ValueConfig["FailPushAdReward"]),
                    PropChangeWay.FreeItemAd, () =>
                    {
                        dataService.AdRewardProgress.UpdateProgress();
                        CloseFunc();
                    });
                return;
#endif
                AdPlayer.ShowFreeItemAd((() =>
                {
                    BoxBuilder.ShowRewardPop(GameUtils.AnalysisPropString(configService.ValueConfig["FailPushAdReward"]),
                        PropChangeWay.FreeItemAd, () =>
                        {
                            dataService.AdRewardProgress.UpdateProgress();
                            CloseFunc();
                        });
                }));
            };
            return;
        }

        if (productKey != "")
        {
            ShopModel model = configService.ShopConfig[productKey];
            transform.Get<Text>("Container/BuyBtn/Price").text = model.money.ToString();
            UpdateItem(model.reward);
            BtnEvent = () =>
            {
                SoundPlayer.Instance.PlayButton();
                PayUtils.RequestOrder(productKey);
            };
        }
    }

    private void UpdateItem(string reward)
    {
        int index = 0;
        Dictionary<int, int> tempReward = GameUtils.AnalysisPropString(reward);

        List<Transform> list = null;
        list = tempReward.Count > 4 ? itemList1 : itemList2;
        itemParent1.gameObject.SetActive(tempReward.Count > 4);
        itemParent2.gameObject.SetActive(tempReward.Count <= 4);
        foreach (var pair in tempReward)
        {
            Transform item = list[index];
            if (item == null) break;
            item.gameObject.SetActive(true);
            item.Get<Image>("PropImage")
                .LoadPropSprite(pair.Key == (int)PropEnum.Coin ? (int)PropEnum.MultiplyCoin : pair.Key);
            
            item.Get<Transform>($"TimeText").gameObject.SetActive(GameUtils.IsLimitTimeReward(pair.Key));
            item.Get<Text>($"NumText").text = "";
            if (GameUtils.IsLimitTimeReward(pair.Key))
            {
                item.Get<Text>($"TimeText").text = $"{pair.Value / 60}m";
            }
            else
            {
                item.Get<Text>($"NumText").text = pair.Key == (int)PropEnum.Coin ? pair.Value.ToString() : $"x{pair.Value}";
            }
            index++;
        }
    }

    protected override void OnAwake()
    {
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(() => CloseFunc());
        transform.Get<Button>("Container/BuyBtn").SetButtonClick(()=>BtnEvent());
        itemParent1 = transform.Get<Transform>("Container/ItemPanel1");
        itemParent2 = transform.Get<Transform>("Container/ItemPanel2");
        int index = 0;
        for (int i = 0; i < itemParent1.childCount; i++)
        {
            Transform item = itemParent1.GetChild(i);
            item.gameObject.SetActive(false);
            index++;
        }
        index = 0;
        for (int i = 0; i < itemParent2.childCount; i++)
        {
            Transform item = itemParent2.GetChild(i);
            item.gameObject.SetActive(false);
            index++;
        }
        UpdateRewardItem();
    }
}
