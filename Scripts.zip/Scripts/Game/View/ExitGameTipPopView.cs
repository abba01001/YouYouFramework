﻿using Activities;
using Doozy.Engine;
using Doozy.Engine.UI;
using Model;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class ExitGameTipPopView : ViewBase
{
    private Button sureBtn;
    private Button cancelBtn;
    private Dictionary<ActivityType, GameObject> collectList = new Dictionary<ActivityType, GameObject>();
    protected override void OnAwake()
    {
        sureBtn = transform.Get<Button>("Container/Panel/SureBtn");
        cancelBtn = transform.Get<Button>("Container/Panel/CancelBtn");
        transform.Find("anim_show").gameObject.SetActive(true);
        
        collectList.Add(ActivityType.collectFlower, transform.Get<Transform>("Container/Panel/ItemList/Item1").gameObject);
        collectList.Add(ActivityType.passRank, transform.Get<Transform>("Container/Panel/ItemList/Item2").gameObject);
        collectList.Add(ActivityType.collectLoveCard, transform.Get<Transform>("Container/Panel/ItemList/Item3").gameObject);
        collectList.Add(ActivityType.seasonPass, transform.Get<Transform>("Container/Panel/ItemList/Item4").gameObject);
        collectList.Add(ActivityType.limitPk, transform.Get<Transform>("Container/Panel/ItemList/Item5").gameObject);
        collectList.Add(ActivityType.endlessLevel, transform.Get<Transform>("Container/Panel/ItemList/Item6").gameObject);
    }

    public void SetValue(int solatium)
    {
        foreach (var item in collectList)
        {
            item.Value.SetActive(false);
            ActivityDataModel model = ActivityManager.Instance.GetActivityByType(item.Key);
            BaseActivityData data = model.localData as BaseActivityData;
            if (model.state == ActivityState.underWay && data.ResultAddCount != 0)
            {
                item.Value.SetActive(true);
                Transform Count = item.Value.transform.Find("Text");
                if (Count) Count.GetComponent<Text>().text = $"x{data.ResultAddCount}";
            }
        }

        sureBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(2);
            if (solatium > 0)
            {
                BoxBuilder.ShowSolatiumPopup(solatium);
                BoxBuilder.HidePopup(gameObject);
            }
            else
            {
                Exit();
            }
            TypeEventSystem.Send(new BattleCommandEvent() { command = BattleCommand.LoseGame });
        });

        cancelBtn.SetButtonClick(() =>
        {
            SoundPlayer.Instance.PlayCertainButton(2);
            transform.Find("anim_hide").gameObject.SetActive(true);
            BoxBuilder.HidePopup(gameObject);
        });
    }
    
    void Exit()
    {
        transform.Find("anim_hide").gameObject.SetActive(true);
        BoxBuilder.HidePopup(gameObject);
        Sequence seq = DOTween.Sequence();

        seq.AppendInterval(0.4f);
        
        GameController.Instance.ExitBattle();
        MoveGameViewBottom t = GameObjManager.Instance.PopClass<MoveGameViewBottom>(true);
        TypeEventSystem.Send<MoveGameViewBottom>(t);
        seq.AppendInterval(1f);
        seq.AppendCallback(() =>
        {
            //ActivityManager.Instance.CheckOpenActivity(false);
            if(ActivityManager.Instance.LavaPassActivity.CheckShowLavaPopup(BoxBuilder.ShowRestartPopup)) return;
            BoxBuilder.ShowRestartPopup();
        });
        ActivityManager.Instance.SaveActivityData();
    }
    
    

}
