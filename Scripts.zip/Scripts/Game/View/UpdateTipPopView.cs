using System;
using System.Collections;
using System.Collections.Generic;
using Doozy.Engine.UI;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class UpdateTipPopView : ViewBase
{
    private Button closeBtn;

    private Button jumpToBtn;

    //private Button continueBtn;

    private Text message;
    private Action JumpCb;
    private Action CloseCb;
    private Text title;
    protected override void OnAwake()
    {
        title = transform.Get<Text>("Container/Title/Icon");
        message = transform.Get<Text>("Container/Message");
        closeBtn = transform.Get<Button>("Container/BtnGroup/CloseButton");
        jumpToBtn = transform.Get<Button>("Container/BtnGroup/JumpButton");
        // continueBtn = transform.Get<Button>("Container/ContinueButton");


        closeBtn.SetButtonClick(() =>
        {
            CloseCb?.Invoke();
            BoxBuilder.HidePopup(gameObject);
        });

//        continueBtn.SetButtonClick(() =>
//        {
//            continueBtn.interactable = false;
//            BoxBuilder.HidePopup(gameObject);
//        });

        jumpToBtn.SetButtonClick(OnRateToHuawei);
        closeBtn.interactable = true;
    }

    public void SetUI(int showBtnType,Action jumpCb,Action closeCb,string content,string jumpText,string closeText,string titleText)
    {
        jumpToBtn.gameObject.SetActive(showBtnType == 0 || showBtnType == 1);
        closeBtn.gameObject.SetActive(showBtnType == 0 || showBtnType == 2);
        JumpCb = jumpCb;
        CloseCb = closeCb;
        message.text = content;
        jumpToBtn.transform.Get<Text>("Label").text = jumpText != "" ? jumpText : "确定";
        closeBtn.transform.Get<Text>("Label").text = closeText != "" ? closeText : "取消";
        title.text = titleText;
    }

    private void OnRateToHuawei()
    {
        JumpCb?.Invoke();
        BoxBuilder.HidePopup(gameObject);
        //RateToAppStore("com.eyu.solitaire", "com.android.vending");
        //openPackage("com.xiaomi.market");
    }

#if UNITY_IOS
#elif UNITY_ANDROID
    private  static void RateToAppStore(string appPkg, string marketPkg)
    {
        try
            {
                AndroidJavaClass intentClass = new AndroidJavaClass("android.content.Intent");
                AndroidJavaObject intentObject = new AndroidJavaObject("android.content.Intent");
                intentObject.Call<AndroidJavaObject>("setAction", intentClass.GetStatic<string>("ACTION_VIEW"));
                AndroidJavaClass uriClass = new AndroidJavaClass("android.net.Uri");
                AndroidJavaObject uriObject =
                    uriClass.CallStatic<AndroidJavaObject>("parse", "market://details?id=" + appPkg);
                intentObject.Call<AndroidJavaObject>("setData", uriObject);
                intentObject.Call<AndroidJavaObject>("setPackage", marketPkg);
                AndroidJavaClass unity = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                AndroidJavaObject currentActivity = unity.GetStatic<AndroidJavaObject>("currentActivity");
                currentActivity.Call("startActivity", intentObject);
              
                BoxBuilder.HideUpdateTipPopup();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                openPackage(marketPkg);
                //throw;
            }
        
    }
    
    private static void openPackage(string pkgName)//包名
    {
        try{
            using (AndroidJavaClass jcPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            {
                using (AndroidJavaObject joActivity = jcPlayer.GetStatic<AndroidJavaObject>("currentActivity"))
                {
                    using (AndroidJavaObject joPackageManager = joActivity.Call<AndroidJavaObject>("getPackageManager"))
                    {
                        using (AndroidJavaObject joIntent =
 joPackageManager.Call<AndroidJavaObject>("getLaunchIntentForPackage", pkgName))
                        {
                            if (null != joIntent)
                            {
                                joActivity.Call("startActivity", joIntent);
                                BoxBuilder.HideUpdateTipPopup();
                            }
                        }
                    }
                }
            }
         }
        catch (Exception e)
        {
             BoxBuilder.ShowTip("搜索不到GooglePlay，请先下载GooglePlay");
        }
    }
#else
    private void openPackage(string pkgName) //包名
    {
        BoxBuilder.HidePopup(gameObject);
    }

    private void RateToAppStore(string appPkg, string marketPkg)
    {
        Debug.Log($"当前平台为Unity编辑器，无操作");
        BoxBuilder.HidePopup(gameObject);
    }
#endif
}