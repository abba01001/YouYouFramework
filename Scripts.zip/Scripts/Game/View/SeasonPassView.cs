﻿using System;
using Activities;
using QFramework;
using System.Collections.Generic;
using DG.Tweening;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class SeasonPassView : ViewBase
{
    private Button tipBtn;
    private ActivityTimeItem timeItem;
    private Text progressText;
    private RectTransform progressValue;
    private Text levelText;
    private GameObject rewardBox;
    [SerializeField] private EfficientScrollRect _scrollRect;
    [SerializeField] private SeasonBuyItem SeasonBuyItem;
    [SerializeField] private GameObject seasonPassItem;
    protected override void OnAwake()
    {
        transform.Get<Button>("Container/CloseBtn").SetButtonClick(CloseFunc);
        transform.Get<Button>("Container/TipBtn").SetButtonClick(BoxBuilder.ShowUnlockSeasonPassPopView);
        transform.Get<Button>("Container/Activate/Btn").SetButtonClick(() =>
        {
            if (!dataService.SeasonPassProgress.IsPaid)
            {
                BoxBuilder.ShowStartSeasonPassPopup("detail");
            }
        });
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
        progressText = transform.Get<Text>("Container/Progress/Text");
        progressValue = transform.Get<RectTransform>("Container/Progress/bg/value");
        levelText = transform.Get<Text>("Container/Progress/Icon/Level");
        rewardBox = transform.Get<Transform>("Container/Progress/RewardBox").gameObject;
        seasonPassItem.SetActive(false);
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }
    
    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<GameRechargeEvent>(UpdatePanel);
    }

    private void UpdatePanel(GameRechargeEvent obj)
    {
        UpdateBuyItem();
        transform.Get<Text>("Container/Activate/Btn/Title").text = dataService.SeasonPassProgress.IsPaid ? "已开通" : "开通";
        rewardBox.gameObject.SetActive(ActivityManager.Instance.SeasonPassActivity.CurIsMaxLayer());
        LocatePos(dataService.SeasonPassProgress.curLayer);
        LocatePos();
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdatePanel);
    }

    protected override void OnShow()
    {
        ActivityManager.Instance.SeasonPassActivity.CheckFirstLayer();
        UpdatePanel(null);
        RefreshTimer();
        StartInitItem();
        LocatePos();
        UpdatProgress();
        Observable.NextFrame().Subscribe(_ =>
        {
            CheckPlayUpAnim();
        });
    }

    void CheckPlayUpAnim()
    {
        if (dataService.SeasonPassProgress.lastViewLayer == dataService.SeasonPassProgress.curLayer) return;
        FxMaskView.Instance.BlockOperation(true);
        foreach (var item in _scrollRect.GetItemList())
        {
            if (item.Index == dataService.SeasonPassProgress.curLayer - 2)
            {
                (item as SeasonPassItem).ShowRopeOpenAnim();
            }

            if (item.Index == dataService.SeasonPassProgress.curLayer - 1)
            {
                (item as SeasonPassItem).ShowRopeCloseAnim(.5f);
            }
        }
        dataService.SeasonPassProgress.lastViewLayer = dataService.SeasonPassProgress.curLayer;
        Observable.Timer(TimeSpan.FromSeconds(1.2f)).Subscribe(_ =>
        {
            FxMaskView.Instance.BlockOperation(false);
        });
        ActivityManager.Instance.SaveActivityData();
    }
    
    void StartInitItem()
    {
        _scrollRect.SetInitCompleteCb(() =>
        {
            RectTransform rect = _scrollRect.GetContentRect();
            rect.sizeDelta = new Vector2(rect.sizeDelta.x + 300, 0);
            SeasonBuyItem.transform.SetParent(rect);
            SeasonBuyItem.transform.SetAsLastSibling();
            SeasonBuyItem.transform.GetComponent<RectTransform>().anchoredPosition = new Vector2(Mathf.Abs(_scrollRect.GetContentRect().sizeDelta.x) - 300,0);
        });
        _scrollRect.SetUpdateItemCb((obj) =>
        {
            if (_scrollRect.GetCurIndex() > _scrollRect.GetDataLength() - 10)
            {
                SeasonBuyItem.transform.SetAsLastSibling();
            }
        });
        _scrollRect.Init(GameObjType.SeasonPassItem,seasonPassItem, GetData());
    }

    object[] GetData()
    {
        Dictionary<int, SeasonPassModel> list = ActivityManager.Instance.SeasonPassActivity.GetConfig();
        Dictionary<int, SeasonPassModel> realList = new Dictionary<int, SeasonPassModel>();
        foreach (var VARIABLE in list)
        {
            if (VARIABLE.Value.type == 1)
            {
                realList.Add(VARIABLE.Value.layer,VARIABLE.Value);
            }
        }
        
        object[] data = new object[realList.Count];
        int index = 0;
        foreach (var VARIABLE in realList)
        {
            data[index] = VARIABLE.Value;
            index++;
        }
        return data;
    }
    
    void RefreshTimer()
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();

        timeData.endTime = ActivityManager.Instance.GetActivityNowDateTime();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        if (ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass) != null && ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass).state 
                is ActivityState.waitEntry or ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass).ActivityBigEndTime);
        }
        if (ActivityManager.Instance.GetActivityByType(ActivityType.seasonPass).state == ActivityState.underWay)
        {
            timeData.endTime = TimeUtils.IntToDateTime(dataService.SeasonPassProgress.ActivityEndTime);
        }
        timeItem.SetTimeData(timeData);
    }

    private void LocatePos(int pos = -1)
    {
        if (pos != -1)
        {
            _scrollRect.SetScrollPos(pos);
        }
        else
        {
            _scrollRect.SetScrollPos(Mathf.Clamp(dataService.SeasonPassProgress.curLayer - 2,0,dataService.SeasonPassProgress.curLayer - 2));
        }
    }
    
    private void UpdateBuyItem()
    {
        SeasonBuyItem.RefreshData();
    }

    private void UpdatProgress()
    {
        int nextCount = ActivityManager.Instance.SeasonPassActivity.GetNextLayerCollectCount();
        int curCount = ActivityManager.Instance.SeasonPassActivity.GetCurLayerCollectCount();
        progressText.text = $"{curCount}/{nextCount}";
        float value = ActivityManager.Instance.SeasonPassActivity.GetRatio();
        if (dataService.SeasonPassProgress.curLayer == 0) value = 1;
        progressValue.localScale = new Vector3(value, 1, 1);
        levelText.text = $"{dataService.SeasonPassProgress.curLayer + 1}";
    }
}