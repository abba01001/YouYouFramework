using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

namespace View
{
    public class SeasonRewardType : MonoBehaviour
    {
        [SerializeField] private Image Icon;
        [SerializeField] private Text Text;
        [SerializeField] private GameObject TimeLimit;
        [SerializeField] private Text LimitTimeText;
        [SerializeField] public GameObject MultiRewardContainer;
        [SerializeField] private GameObject MultiRewardItem;
        [SerializeField] private bool IsBoxItem;
        public bool IsShowFlyAnim;

        public SeasonLvRewardItem Reward { private set; get; }

        private Button Btn;
        private IStorageService _storageService;
        private string _boxIcon;
        private Dictionary<int, int> _propDict;
        private DialogueItem _dialogueItem;

        public void Init(List<SeasonLvRewardItem> rewards, string boxIconId = "")
        {
            _boxIcon = boxIconId;
            Btn = GetComponent<Button>();
            Btn?.SetButtonClick(OnBoxBtnClick);
            _storageService = MainContainer.Container.Resolve<IStorageService>();
            if (rewards.Count > 1)
            {
                // 宝箱
                // if (string.IsNullOrEmpty(boxIconId) == false) Icon.sprite = _storageService.LoadBoxSprite($"battlepass_box_{boxIconId}_lock");
//                foreach (var reward in rewards)
//                {
//                    var item = Instantiate(MultiRewardItem, MultiRewardContainer.transform.GetChild(0), true);
//                    item.GetComponent<SeasonRewardType>().Init(new List<SeasonLvRewardItem>{reward});
//                    item.SetActive(true);
//                }
//                MultiRewardContainer.SetActive(true); // 宝箱中奖励默认显示
                
                _propDict = new Dictionary<int, int>();
                foreach (var reward in rewards)
                {
                    _propDict.Add(reward.type, reward.amount);
                }

                if (IsShowFlyAnim == false)
                {
                    _dialogueItem = GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>();
                    _dialogueItem.ShowItem(TextAnchor.LowerCenter, transform, new Vector2(0, 20), _propDict);
                    _dialogueItem.GetComponent<Canvas>().sortingOrder = 101;   
                }
            }
            else
            {
                // 普通奖励单品
                var reward = rewards[0];
                Reward = reward;
                Icon.LoadPropSprite(reward.type,false);
                if (IsBoxItem == false) Icon.SetNativeSize();
                Icon.rectTransform.sizeDelta = GameUtils.PropSizeDic[reward.type];

                if (reward.type == (int)PropEnum.TimeItemCactus || reward.type == (int)PropEnum.TimeItemEliminate || reward.type == (int)PropEnum.TimeItemJoker)
                {
                    // 限时道具
                    TimeLimit.SetActive(true);
                    LimitTimeText.text = $"{reward.amount / 60}m";
                }
                else
                {
                    // 普通到具
                    string count =  reward.type == (int)PropEnum.Coin ? $"+{reward.amount}" : $"×{reward.amount}";
                    Text.text = count;
                    Text.gameObject.SetActive(true);
                }
            }
            
            Show();
        }

        private void OnBoxBtnClick()
        {
            // 点击了宝箱
//            MultiRewardContainer.SetActive(!MultiRewardContainer.activeSelf);
            _dialogueItem = GameObjManager.Instance.PopGameObject(GameObjType.DialogueItem).GetComponent<DialogueItem>();
            _dialogueItem.ShowItem(TextAnchor.LowerCenter, transform, new Vector2(0, 20), _propDict);
            _dialogueItem.GetComponent<Canvas>().sortingOrder = 101;
        }

        public void Show()
        {
            gameObject.SetActive(true);
        }

        public void OpenBox()
        {
            // Icon.sprite = _storageService.LoadBoxSprite($"battlepass_box_{_boxIcon}_unlock");
        }
    }
}