using DG.Tweening;
using Doozy.Engine.UI;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using SoliUtils;
using Cysharp.Threading.Tasks;

namespace View
{
    public class UnlockNewFeaturePopup : ViewBase
    {
        [SerializeField] private Image Mask;
        [SerializeField] private Transform TargetContainer;
        [SerializeField] private Text TitleText;

        private UIPopup _uiPopup;
        private Transform _target;
        private Vector3 _targetPos;
        private UnityAction<GameObject> _showCallback;
        private UnityAction _hideCallback;
        
        protected override void OnAwake()
        {
            _uiPopup = GetComponent<UIPopup>();
        }

        protected override void OnShow()
        {
            
        }

        public async void SetTargetInfo(Transform target, Vector3 targetPos, UnityAction<GameObject> showCall,  UnityAction call)
        {
            _target = Instantiate(target.gameObject, TargetContainer, true).transform;
            _target.localPosition = Vector3.zero;
            _target.localScale = Vector3.zero;
            _targetPos = targetPos;
            _showCallback = showCall;
            _hideCallback = call;
            Color color = Mask.color;
            color.a = 180f / 255;
            Mask.DOColor(color, 0.3f);
            await UniTask.Delay(300);
            _target.DOScale(Vector3.one * 1.2f, 0.2f);
            await UniTask.Delay(200);
            _target.DOScale(Vector3.one, 0.1f);
            SoundPlayer.Instance.PlayComboFinish();
            _showCallback.Invoke(_target.gameObject);
            await UniTask.Delay(2500);
            PlayMoveAnim();
        }

        private void PlayMoveAnim()
        {
            Mask.gameObject.SetActive(false);
            TitleText.gameObject.SetActive(false);
            _target.DOMove(_targetPos, 0.5f).OnComplete(async () =>
            {
                SoundPlayer.Instance.PlayWinStreakBoxOut();
                await UniTask.Delay(200);
                TargetContainer.gameObject.SetActive(false);
                _hideCallback.Invoke();
                _uiPopup.Hide(true);
            });
        }
    }
}