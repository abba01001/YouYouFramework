﻿using Activities;
using QFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Coffee.UIExtensions;
using DG.Tweening;
using Model;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;
using UniRx;

public class DigTreasureView : ViewBase
{
    private Button closeBtn;
    private Button tipBtn;
    private ActivityTimeItem timeItem;
    private List<GameObject> gridList = new List<GameObject>();
    private Dictionary<int,GameObject> rewardList = new Dictionary<int,GameObject>();
    [SerializeField] private GameObject gridPrefab;
    [SerializeField] private GameObject rewardPrefab;
    [SerializeField] private RectTransform gridBg;
    [SerializeField] private RectTransform gridPanel;
    [SerializeField] private RectTransform digCountRect;
    [SerializeField] private RectTransform rewardBg;
    [SerializeField] private Text digCountText;
    [SerializeField] private List<GameObject> LayerList = new List<GameObject>();
    [SerializeField] private Image fillAmount;
    [SerializeField] private Text fillText;
    [SerializeField] private UIEffect BoxBtnBg;
    [SerializeField] private Animator digGo;
    [SerializeField] private RectTransform boxRewardBg;
    [SerializeField] private GameObject iconEf;
    public List<DigGridRewardModel> RewardModels = new List<DigGridRewardModel>();
    private Dictionary<int, GameObject> BoxRewards = new Dictionary<int, GameObject>();
    [SerializeField] private List<GameObject> PanelRewards;
    private Button PanelRewardCloseBtn;
    private GameObject TreasureRewardPanel;
    private int XWidth { get; set; }
    private int YWidth { get; set; }
    private int CellSize { get; set; }
    private Vector2 RewardPanelOrignPos { get; set; }//奖励面板坐标起点
    private Vector2 GridPanelOrignPos { get; set; }//格子面板坐标起点
    private List<Tween> fillTweenList = new List<Tween>();
    private bool isPlayingJumpAnim = false;
    private bool isPlayingDigAnim = false;
    protected override void OnAwake()
    {
        gridPrefab.gameObject.SetActive(false);
        rewardPrefab.gameObject.SetActive(false);
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(CloseFunc);
        digGo.gameObject.SetActive(false);
        tipBtn = transform.Get<Button>("Container/TipBtn");
        tipBtn.SetButtonClick(BoxBuilder.ShowUnlockDigTreasure);
        timeItem = transform.Get<ActivityTimeItem>("Container/RewardBox/ActivityTimeItem");
        TreasureRewardPanel = transform.Get<Transform>("TreasureRewardPanel").gameObject;
        PanelRewardCloseBtn = TreasureRewardPanel.Get<Button>("Container/CloseBtn");
        PanelRewardCloseBtn.SetButtonClick(() =>
        {
            TreasureRewardPanel.gameObject.SetActive(false);
            if (ActivityManager.Instance.DigTreasureActivity.CheckMaxLayer())
            {
                dataService.DigTreasureProgress.FinishGetReward = true;
                dataService.SaveData(true);
                CloseFunc();
                return;
            }
            RecycleItem();
            OnShow();
            isPlayingJumpAnim = false;
        });
    }
    protected override void OnViewInit(bool isFirst)
    {
        if(!isFirst) return;
        TypeEventSystem.Register<PlayGetTreasure>(OnPlayGetTreasure);
        TypeEventSystem.Register<JumpNextTreasure>(JumpNextPanel);
        TypeEventSystem.Register<RefreshActivityTimer>(RefreshTimer);
        TypeEventSystem.Register<GameRechargeEvent>(UpdateCount);
    }

    private (Vector2,Vector2) GetOffset(int index)
    {
        return index switch
        {
            0 => (new Vector2(0, 30), new Vector2(0, 0)),
            1 => (new Vector2(96, 30), new Vector2(0, 0)),
            2 => (new Vector2(332, 30), new Vector2(0, 0)),
            _ => (new Vector2(664, 30), new Vector2(-100, 0))
        };
    }

    private void CloseFunc()
    {
        if(isPlayingDigAnim || isPlayingJumpAnim) return;
        SoundPlayer.Instance.CheckActivityBgm(false,ActivityType.digTreasure);
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
    }
    
    private void JumpNextPanel(JumpNextTreasure obj)
    {
        isPlayingJumpAnim = true;
        PanelRewardCloseBtn.interactable = false;
        Observable.Timer(TimeSpan.FromSeconds(obj.delayPlay)).Subscribe(_ =>
        {
            TreasureRewardPanel.gameObject.SetActive(true);
            GameUtils.PlayAnimation(TreasureRewardPanel.GetComponent<Animator>(), "ani_DigTreasureReward_Reward_01", 0,
                () => { PanelRewardCloseBtn.interactable = true; }, false);
        });
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<PlayGetTreasure>(OnPlayGetTreasure);
        TypeEventSystem.UnRegister<JumpNextTreasure>(JumpNextPanel);
        TypeEventSystem.UnRegister<RefreshActivityTimer>(RefreshTimer);
        TypeEventSystem.UnRegister<GameRechargeEvent>(UpdateCount);
    }

    private void UpdateCount(GameRechargeEvent obj)
    {
        digCountText.text = $"{ActivityManager.Instance.DigTreasureActivity.GetDigCount()}";
    }
    
    void RefreshTimer(RefreshActivityTimer obj)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>();
        timeData.startTime = ActivityManager.Instance.GetActivityNowDateTime();
        ActivityDataModel model = ActivityManager.Instance.GetActivityByType(ActivityType.digTreasure);
        if (model != null)
        {
            if (model.state is ActivityState.waitEntry or ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(ActivityManager.Instance.GetActivityByType(ActivityType.digTreasure).ActivityBigEndTime);
            }
            if (model.state == ActivityState.underWay)
            {
                timeData.endTime = TimeUtils.IntToDateTime(dataService.DigTreasureProgress.ActivityEndTime);
            }
        }
        timeItem.SetTimeData(timeData);
    }
    
    
    protected override void OnShow()
    {
        if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockDigTreasurePopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.UnlockDigTreasurePopup);
            BoxBuilder.ShowUnlockDigTreasure();
        }
        SoundPlayer.Instance.CheckActivityBgm(true,ActivityType.digTreasure);
        dataService.DigTreasureProgress.IsFirstShow = false;
        InitParams();
        InitGridPanel();
        InitGridRewards();
        InitBoxRewards();
        UpdateShowReward();
        AdaptBgPos();
        RefreshTimer(null);
        UpdateProgress(false);
        UpdateLayerReward();
        ActivityManager.Instance.DigTreasureActivity.CheckJumpNextLayer(GetRewardOccupyGridIndex());
    }

    protected override void OnViewDestroy()
    {
        RecycleItem();
    }

    private void RecycleItem()
    {
        if (!GameObjManager.IsNull())
        {
            foreach (var go in gridList)
            {
                if (go != null)
                {
                    Destroy(go);
                }
            }
            foreach (var pair in rewardList)
            {
                if (pair.Value != null)
                {
                    Destroy(pair.Value);
                }
            }
            gridList.Clear();
            rewardList.Clear();
        }
    }

    void InitGridPanel()
    {
        rewardBg.gameObject.SetActive(false);
        var size = new Vector2(CellSize * XWidth, CellSize * YWidth) + new Vector2(30,30);
        Vector2 cellSize = Vector2.one * CellSize;
        gridPanel.sizeDelta = size;
        gridBg.sizeDelta = size;
        rewardBg.sizeDelta = size;
        digCountRect.anchoredPosition = new Vector2(0, size.y / 2 + 25);
        List<int> occupyList = ActivityManager.Instance.DigTreasureActivity.LoadOccupyGrid();
        int index = 0;
        for (int i = 0; i < YWidth; i++)
        {
            for (int j = 0; j < XWidth; j++)
            {
                bool show = !occupyList.Contains(index);
                GameObject obj = Instantiate(gridPrefab);
                obj.transform.SetParent(gridPanel);
                obj.SetActive(show);
                obj.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                obj.transform.localScale = Vector3.one;
                obj.GetComponent<RectTransform>().anchoredPosition = GetGridPos(index);
                obj.GetComponent<RectTransform>().sizeDelta = cellSize;
                int tempIndex = index;
                obj.GetComponent<Button>().SetButtonClick(() => OccupyGrid(tempIndex));
                gridList.Add(obj);
                HandleDecorate(obj,cellSize.x - 25,cellSize.y - 25);
                index++;
            }
        }
        Observable.Timer(TimeSpan.FromSeconds(0.2f)).Subscribe(_ => rewardBg.gameObject.SetActive(true));
        digCountText.text = $"{ActivityManager.Instance.DigTreasureActivity.GetDigCount()}";
    }

    private void HandleDecorate(GameObject obj,float xBorder,float yBorder)
    {
        for (int i = 0; i < 3; i++)
        {
            float percent = GameUtils.RandomRange(0f, 1f);
            var t = obj.Get<Transform>($"Decorate{i + 1}");
            t.gameObject.MSetActive(percent > 0.6f);
            if (percent >= 0.6f)
            {
                float x = GameUtils.RandomRange(0, xBorder);
                float y = GameUtils.RandomRange(0, yBorder);
                t.GetComponent<RectTransform>().anchoredPosition = new Vector2(x,y);
            }
        }
    }
  
    //占领格子
    private void OccupyGrid(int gridIndex)
    {
        if(isPlayingJumpAnim || isPlayingDigAnim) return;
        ActivityManager.Instance.DigTreasureActivity.OccupyGridByIndex(gridIndex, () =>
        {
            isPlayingDigAnim = true;
            PlayDigAnim(gridIndex);
            digCountText.text = $"{ActivityManager.Instance.DigTreasureActivity.GetDigCount()}";
            UpdateShowReward();
            ActivityManager.Instance.DigTreasureActivity.CheckReward(GetRewardOccupyGridIndex());
        }, () =>
        {
            BoxBuilder.ShowGiftBuyItemPopup(ActivityType.digTreasure);
        });
    }

    //奖励占领的格子索引
    private Dictionary<int, List<int>> GetRewardOccupyGridIndex()
    {
        Dictionary<int, List<int>> dic = new Dictionary<int, List<int>>();
        Dictionary<int,Vector2> rewards = ActivityManager.Instance.DigTreasureActivity.LoadRewardGrid();
        foreach (var model in RewardModels)
        {
            List<int> list = new List<int>();
            if (rewards.TryGetValue(model.PropId, out Vector2 pos))
            {
                int x = (int) pos.x;
                int y = (int) pos.y;
                for (int i = x; i < x + model.Width; i++)
                {
                    for (int j = y; j < y + model.Height; j++)
                    {
                        list.Add(j * XWidth + i);
                    }
                }
                dic.Add(model.PropId,list);
            }
        }
        return dic;
    }

    //播放物品飞到宝箱动画
    private void OnPlayGetTreasure(PlayGetTreasure obj)
    {
         if (rewardList.TryGetValue(obj.propIndex, out GameObject temp))
         {
             FxMaskView.Instance.BlockOperation(true);
             temp.gameObject.MSetActive(true);   
             Observable.Timer(TimeSpan.FromSeconds(obj.delayPlay)).Subscribe(_ =>
             {
                 GameObject reward = Instantiate(temp);
                 temp.gameObject.MSetActive(false);
                 reward.transform.localPosition = temp.transform.position;
                 reward.transform.localScale = Vector3.one;
                 reward.transform.SetParent(transform);
                 GameUtils.AdjustPivot(reward.GetComponent<RectTransform>(), new Vector2(1, 1) * 0.5f);
                 reward.gameObject.SetActive(true);
                 reward.transform.DOScale(Vector3.one * 1.5f, 0.4f).SetEase(Ease.OutCubic);
                 PlayFlyReward(reward, obj.propIndex, 0.4f);
                 Observable.Timer(TimeSpan.FromSeconds(2f)).Subscribe(_ =>
                 {
                     FxMaskView.Instance.BlockOperation(false);
                 });
             });
         }
    }

    private void PlayFlyReward(GameObject gridRewardObj,int propIndex,float delay)
    {
        foreach (var pair in BoxRewards)
        {
            if (pair.Key == propIndex)
            {
                var boxRewardObj = pair.Value.gameObject;
                Sequence seq = DOTween.Sequence();
                Vector2 targetSize = boxRewardObj.transform.GetComponent<RectTransform>().sizeDelta * boxRewardObj.transform.localScale;
                Vector3 startPos = gridRewardObj.transform.position;
                Vector3 endPos = boxRewardObj.transform.position + new Vector3(targetSize.x / 2,-targetSize.y / 2);
                Vector3 controlPos = startPos + new Vector3((startPos.x + endPos.x) / 2, -200);

                Vector3[] bezierArray = BezierUtils.GetBeizerList(startPos, controlPos, endPos, 10);
                seq.Insert(0f,gridRewardObj.transform.DOPath(bezierArray, 1f, PathType.CatmullRom).SetEase(Ease.InSine).SetDelay(delay));
                seq.Insert(0f,gridRewardObj.transform.DOScale(boxRewardObj.transform.localScale, 1f).SetEase(Ease.InSine).SetDelay(delay));
                seq.Insert(0f,gridRewardObj.transform.GetComponent<RectTransform>().DOSizeDelta(targetSize,1f).SetEase(Ease.InSine).SetDelay(delay));
                seq.InsertCallback(1f + delay, () =>
                {
                    GameUtils.SpawnIconEffect(boxRewardObj.transform.Find("PropImage"),GameObjType.CollectItemFx,iconEf);
                    Destroy(gridRewardObj);
                    SetReward(boxRewardObj,propIndex,false);
                    UpdateProgress(true);
                    UpdateLayerReward();
                    ActivityManager.Instance.DigTreasureActivity.CheckJumpNextLayer(GetRewardOccupyGridIndex());
                });
                break;
            }
        }
    }

    private void UpdateShowReward()
    {
        Dictionary<int, List<int>> rewardsIndex = GetRewardOccupyGridIndex();
        List<int> occupyList = ActivityManager.Instance.DigTreasureActivity.LoadOccupyGrid();
        foreach (var pair in rewardList)
        {
            var obj = pair.Value.gameObject;

            int state = 0;//0不显示，1未全部露出来，2全部露出来放到宝箱里
            if (rewardsIndex.TryGetValue(pair.Key, out List<int> list))
            {
                if (list.All(item => occupyList.Contains(item))) state = 2;
                else if (list.Any(item => occupyList.Contains(item)))  state = 1;
                else state = 0;
            }
            obj.MSetActive(state == 1);
        }
    }

    private void HandleIconScale(Image icon,int width,int height)
    {
        float scale = 0.6f;
        if (width == 1 && height == 2)
        {
            scale = 0.8f;
        }
        else if (width == 2 && height == 2)
        {
            scale = 1.2f;
        }
        else if (width == 3 && height == 3)
        {
            scale = 2f;
        }
        else if (width == 3 && height == 4)
        {
            scale = 2f;
        }
        else if (width == 4 && height == 4)
        {
            scale = 3f;
        }
        icon.transform.localScale = Vector3.one * scale;
    }

    private Vector2 GetGridPos(int index)
    {
        var x = GridPanelOrignPos.x + index % XWidth * CellSize;
        var y = GridPanelOrignPos.y + index / XWidth * CellSize;
        return new Vector2(x,y);
    }
    
    private void InitParams()
    {
        (XWidth,YWidth,CellSize) = ActivityManager.Instance.DigTreasureActivity.GetRowCollumn();

        RewardPanelOrignPos = new Vector2(14, -CellSize * YWidth - 14);
        GridPanelOrignPos = RewardPanelOrignPos + new Vector2(CellSize / 2, CellSize / 2);
    }

    private void AdaptBgPos()
    {
        gridBg.anchoredPosition = XWidth == 9 ? new Vector2(0, -30) : Vector2.zero;
        rewardBg.anchoredPosition = XWidth == 9 ? new Vector2(0, -30) : Vector2.zero;
        gridPanel.anchoredPosition = XWidth == 9 ? new Vector2(0, -30) : Vector2.zero;
    }
    
    //格子奖励
    private void InitGridRewards()
    {
        List<DigGridRewardModel> list = new List<DigGridRewardModel>();
        Dictionary<int, int> rewards = ActivityManager.Instance.DigTreasureActivity.GetCurRewards();
        if(rewards.Count == 0) return;
        RewardModels.Clear();
        int index = 1;
        foreach (var pair in rewards)
        {
            int x = 1;
            int y = 1;
            string grid = configService.GetGrid(pair.Key);
            if (grid != "")
            {
                string[] str = grid.Split(GameUtils.FirstSeparator);
                x = int.Parse(str[0]);
                y = int.Parse(str[1]);
            }
            RewardModels.Add(new DigGridRewardModel(index,pair.Key,pair.Value,x,y));
            index++;
        }
        RewardModels.Sort((a, b) => (b.Width * b.Height).CompareTo(a.Width * a.Height));
        
        Dictionary<int, Vector2> rewardGridList = ActivityManager.Instance.DigTreasureActivity.LoadRewardGrid();
        if (rewardGridList.Count == 0)
        {
            DigAlgorithmUtils utils = new DigAlgorithmUtils();
            utils.InitParams(XWidth, YWidth, CellSize, RewardModels);
            rewardGridList = utils.GetUnitPosList();
            ActivityManager.Instance.DigTreasureActivity.SaveRewardGrid(rewardGridList);
        }
        
        
        rewardList.Clear(); 
        foreach (var info in rewardGridList)
        {
            GameObject obj = Instantiate(rewardPrefab);
            obj.transform.SetParent(rewardBg);
            obj.SetActive(true);
            obj.transform.SetLocalPositionAndRotation(Vector3.zero,Quaternion.identity);
            obj.transform.localScale = Vector3.one;
            
            var pos = new Vector2(info.Value.x, info.Value.y) * CellSize + RewardPanelOrignPos;
            obj.transform.localPosition = Vector3.zero;
            obj.GetComponent<RectTransform>().anchoredPosition = pos;
            //obj.GetComponent<Image>().color = new Color(GameUtils.RandomRange(0f,1f),GameUtils.RandomRange(0f,1f),GameUtils.RandomRange(0f,1f));
            foreach (var model in RewardModels)
            {
                if (model.PropId == info.Key)
                {
                    obj.GetComponent<RectTransform>().sizeDelta = new Vector2(model.Width,model.Height) * CellSize;
                    var icon = obj.Get<Image>("PropImage");
                    icon.transform.localScale = Vector3.one;
                    icon.transform.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
                    GameUtils.LoadPropSprite(icon,model.PropId);
                    HandleIconScale(model, icon);
                    break;
                }
            }
            rewardList.Add(info.Key,obj);
        }
    }

    private void HandleIconScale(DigGridRewardModel model,Image icon)
    {
        float scale = 1f;
        Vector2 pos = Vector2.zero;
        if (configService.ItemConfig.ContainsKey(model.PropId))
        {
            icon.SetNativeSize();
            if (model.PropId == (int) PropEnum.Coin)
            {
                scale = 0.7f;
            }
            else if (model.PropId == (int) PropEnum.FreeJoker)
            {
                pos = new Vector2(0,-10);
                scale = 1.3f;
            }
            else if (model.PropId == (int) PropEnum.ItemWindmill)
            {
                pos = new Vector2(2.5f,-12);
                scale = 1.3f;
            }
        }
        else
        {
            icon.SetNativeSize();
            var size = icon.GetComponent<RectTransform>().sizeDelta;
            icon.GetComponent<RectTransform>().sizeDelta = new Vector2(size.x / 100, size.y / 100);
            if (model.PropId == 10030105)
            {
                pos = new Vector2(-20, 0);
                scale = 1.3f;
            }
            else if (model.PropId == 10080104)
            {
                pos = new Vector2(-10, 0);
            }
            else if (model.PropId == 10010103)
            {
                pos = new Vector2(-5, 0);
                scale = 0.55f;
            }
            else if (model.PropId == 10020105)
            {
                pos = new Vector2(-3, -15.5f);
                scale = 1.65f;
            }
            else if (model.PropId == 10040105)
            {
                pos = new Vector2(-10, 0f);
                scale = 1.6f;
            }
            else if (model.PropId == 10050105)
            {
                pos = new Vector2(-13, 0f);
                scale = 1.7f;
            }
            else if (model.PropId == 10080103)
            {
                pos = new Vector2(-6, 0f);
                scale = 0.8f;
            }
            else if (model.PropId == 10020103)
            {
                pos = new Vector2(-1, -1f);
                scale = 0.8f;
            }
            else if (model.PropId == 10030103)
            {
                scale = 0.95f;
            }
        }

        icon.GetComponent<RectTransform>().anchoredPosition = pos;
        icon.transform.localScale = Vector3.one * scale;
    }

    //初始化盒子奖励Obj
    private void InitBoxRewards()
    {
        boxRewardBg.sizeDelta = new Vector2(333, RewardModels.Count > 6 ? 320 : 230);
        BoxRewards.Clear();
        var parent = transform.Get<Transform>("Container/RewardBox/Box/Bg");
        for (int i = 0; i < parent.childCount; i++)
        {
            var obj = parent.GetChild(i).gameObject;
            obj.MSetActive(i < RewardModels.Count);
            if (i < RewardModels.Count)
            {
                BoxRewards.Add(RewardModels[i].PropId,obj);
                SetReward(obj, RewardModels[i].PropId, !dataService.DigTreasureProgress.GetRewardList.Contains(RewardModels[i].PropId));
            }
        }

        int index = 0;
        foreach (var obj in PanelRewards)
        {
            obj.MSetActive(index < RewardModels.Count);
            if (index < RewardModels.Count)
            {
                SetReward(obj, RewardModels[index].PropId, false);
            }
            index++;
        }
    }

    private bool IsMergeReward(int propId)
    {
        return configService.MergeItemConfig.ContainsKey(propId);
    }
    
    private void SetReward(GameObject obj,int propId,bool isGray)
    {
        DigGridRewardModel model = null;
        foreach (var mod in RewardModels)
        {
            if (mod.PropId == propId)
            {
                model = mod;
                break;
            }
        }
        if(model == null) return;
        
        var icon = obj.Get<Image>("PropImage");
        var num = obj.Get<Text>("NumText");
        var bar = obj.Get<Transform>("Bar");
        bool isMerge = IsMergeReward(model.PropId);
        num.gameObject.MSetActive(!isMerge);
        bar.gameObject.MSetActive(!isMerge);
        num.text = model.PropCount.ToString();
        GameUtils.LoadPropSprite(icon,model.PropId);
        foreach (var pair in obj.GetComponentsInChildren<UIEffect>(true))
        {
            pair.effectFactor = isGray ? 1 : 0;
        }
    }

    private void UpdateProgress(bool playAnim)
    {
        int total = RewardModels.Count;
        int value = dataService.DigTreasureProgress.GetRewardList.Count;
        float percent = (float)Math.Round((float)value / total, 2);
        BoxBtnBg.effectFactor = value == total ? 0 : 1;
        if (playAnim)
        {
            float orignCount = Mathf.Clamp((float) (value -1) / total,0,1);
            fillTweenList.Add(fillAmount.DOFillAmount(percent, 0.5f));
            fillTweenList.Add(DOTween.To(value => { fillText.text = Mathf.Floor(value).ToString(); }, orignCount * 100, percent * 100, 0.5f).SetEase(Ease.OutQuad));
        }
        else
        {
            foreach (var tween in fillTweenList)
            {
                DOTween.Kill(tween);
            }
            fillTweenList.Clear();
            fillAmount.fillAmount = percent;
            fillText.text = $"{percent * 100}";
        }
    }

    private void UpdateLayerReward()
    {
        int total = RewardModels.Count;
        int value = dataService.DigTreasureProgress.GetRewardList.Count;
        int curLayer = dataService.DigTreasureProgress.curLayer;
        int index = 0;
        foreach (var go in LayerList)
        {
            index++;
            go.transform.GetComponent<Image>().enabled = index == curLayer;
            var bar = go.transform.Find("Bar").gameObject;
            bar.SetActive(index == curLayer);
            if (index == curLayer)
            {
                bar.Get<Text>("Text").text = $"{value}/{total}";
            }
            go.transform.Find("Finish").gameObject.SetActive(index < curLayer);
        }

        transform.Get<Image>("Container/RewardBox/Box")
            .SetSpriteByAtlas(Constants.AtlasNamePath.ViewDigTreasuretAtlas, $"wabao_box_{curLayer}");
        TreasureRewardPanel.Get<Image>("Container/RewardIcon")
            .SetSpriteByAtlas(Constants.AtlasNamePath.ViewDigTreasuretAtlas, $"wabao_box_{curLayer}");

    }

    private void PlayDigAnim(int index)
    {
        if (gridList[index] != null)
        {
            var offset = gridList[index].GetComponent<RectTransform>().sizeDelta / 2;
            digGo.transform.position = gridList[index].transform.position;
            digGo.transform.localPosition += new Vector3(offset.x, offset.y, 0);
            digGo.gameObject.SetActive(true);
        }
        GameUtils.PlayAnimation(digGo,"ani_DigTreasure_dig",0, null,false);
        Observable.Timer(TimeSpan.FromSeconds(37f / 60)).Subscribe(_ =>
        {
            gridList[index]?.SetActive(false);
            isPlayingDigAnim = false;
        });
    }
    
}
