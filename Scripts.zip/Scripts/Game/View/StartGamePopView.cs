﻿using QFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Doozy.Engine.UI;
using UniRx;
using DG.Tweening;
using System;
using System.Linq;
using Activities;
using Doozy.Engine;
using Model;
using SoliUtils;

[RequireComponent(typeof(CanvasGroup))]
public class StartGamePopView : ViewBase
{
    private Button CloseBtn;
    private Text TitleText;
    private Action nextGameCloseFunc = null;
    private Action restartGameCloseFunc = null;

    private Transform itemLayout;
    private GameObject ItemDobule;
    private Transform activityItemParent;
    private List<GameObject> startActivityItem = new List<GameObject>();
    private List<GameObject> pages = new List<GameObject>();
    private GameObject activityItemPrefab;
    private int waitToLevel = -1;
    private List<int> selectItem = new List<int>(3);
    private Transform activityTimeItem;
    private PageScrollView pageScrollView;
    [SerializeField] private List<GameObject> collectList;

    protected override void OnAwake()
    {
        transform.Get<Button>("Container/TipBtn").SetButtonClick(() => { BoxBuilder.ShowUnlockStartGamePopView(); });
        TitleText = transform.Get<Text>("Container/BgImage/TitleText");
        CloseBtn = transform.Get<Button>("Container/CloseBtn");

        ItemDobule = transform.Find("Container/ItemDobule").gameObject;
        activityTimeItem = transform.Get<Transform>("Container/ItemDobule/bg_01/ActivityTimeItem");

        itemLayout = transform.Find("Container/ItemLayout");
        activityItemParent = transform.Get<Transform>("Container/ActivityItemParent");
        CloseBtn.SetButtonClick(() =>
        {
            dataService.OperatePreAddItem(4, (int) PropEnum.Xishu);
            CloseFunc();
        });

        var pageTrans = activityItemParent.Find("Pages");
        for (int i = 0; i < pageTrans.childCount; i++)
        {
            pages.Add(pageTrans.GetChild(i).Get<Transform>("Icon").gameObject);
            pages[i].transform.parent.gameObject.MSetActive(false);
        }

        SoundPlayer.Instance.PlayMainSound("Start_Popup");
    }

    private void CloseFunc()
    {
        SoundPlayer.Instance.PlayCertainButton(6);
        BoxBuilder.HidePopup(gameObject);
        if (startActivityItem != null)
        {
            foreach (var item in startActivityItem)
            {
                GameObjManager.Instance.PushGameObject(item);
            }

            startActivityItem = null;
        }

        if (nextGameCloseFunc != null)
        {
            nextGameCloseFunc.Invoke();
            return;
        }

        if (restartGameCloseFunc != null)
        {
            restartGameCloseFunc.Invoke();
            return;
        }
    }

    protected override void OnViewInit(bool isFirst)
    {
        if (isFirst == false) return;
        TypeEventSystem.Register<UpdateSelectItem>(OnUpdateSelectItem);
        TypeEventSystem.Register<PropChangeEvent>(OnPropChangeEvent);
        TypeEventSystem.Register<DownloadLevelJsonResultEvent>(OnDownloadLevelJsonResultEvent);
        TypeEventSystem.Register<UIPopupEvent>(OnUIPopupEvent);
        TypeEventSystem.Register<GameUpdateItemEvent>(OnUpdatePanel);
    }

    protected override void OnInitedDestroy()
    {
        TypeEventSystem.UnRegister<UpdateSelectItem>(OnUpdateSelectItem);
        TypeEventSystem.UnRegister<PropChangeEvent>(OnPropChangeEvent);
        TypeEventSystem.UnRegister<DownloadLevelJsonResultEvent>(OnDownloadLevelJsonResultEvent);
        TypeEventSystem.UnRegister<UIPopupEvent>(OnUIPopupEvent);
        TypeEventSystem.UnRegister<GameUpdateItemEvent>(OnUpdatePanel);
        GameCommon.IsShowingStartGamePopup = false;
    }

    private void OnUpdatePanel(GameUpdateItemEvent e)
    {
        OnShow();
    }

    private void OnUIPopupEvent(UIPopupEvent e)
    {
        if (e.popup == GetComponent<UIPopup>())
            return;
    }

    private void UpdatePage(int pageIndex)
    {
        foreach (var obj in pages)
        {
            obj.MSetActive(false);
        }

        pages[pageIndex].MSetActive(true);
    }

    protected override void OnShow()
    {
        GameCommon.IsShowingStartGamePopup = true;
        if (!dataService.CheckFirstPopup(Constants.DoozyView.UnlockStartGamePopup))
        {
            dataService.AddFirstPopup(Constants.DoozyView.UnlockStartGamePopup);
            BoxBuilder.ShowUnlockStartGamePopView();
        }
        SetStageHardShow();
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(EnterGameFunc);
        transform.Get<Text>("Container/EnterBtn/Label").text = "开始";

        Observable.NextFrame().Subscribe(_ => InitItem());
        CheckActivityItem();
    }


    
    public void OnUpdateSelectItem(UpdateSelectItem obj)
    {
        InitItem();
    }

    private void CheckActivityItem()
    {
        List<ActivityDataModel> list = ActivityManager.Instance.GetShowActivityItem();
        startActivityItem = new List<GameObject>();
        if (list.Count > 0)
        {
            pageScrollView = activityItemParent.Get<PageScrollView>("PageScrollItem");
            foreach (var model in list)
            {
                var obj = GameObjManager.Instance.PopGameObject(GameObjType.StartActivityItem);
                obj.SetActive(true);
                obj.transform.localScale = Vector3.one;
                obj.GetComponent<StartActivityItem>().SetActivityType(model.type);
                obj.GetComponent<StartActivityItem>().UpdatePanel();
                obj.GetComponent<StartActivityItem>().PlayAnim();
                startActivityItem.Add(obj);
            }

            int index = 0;
            foreach (var obj in pages)
            {
                obj.transform.parent.gameObject.MSetActive(index < list.Count);
                obj.gameObject.MSetActive(index == list.Count - 1);
                index++;
            }

            pageScrollView.InitParams(startActivityItem, UpdatePage, true, 0);
        }

        Observable.Timer(TimeSpan.FromSeconds(0.18f)).Subscribe(_ => { });
    }

    private void SetStageHardShow()
    {
        int hard = configService.GetStageHard(dataService.NowMaxLevel);
        transform.Get<Image>("Container/BgImage/bg_01")
            .SetSpriteByAtlas(Constants.AtlasNamePath.ViewStartGameAtlas, $"kstc_{hard + 1}_1", true);
        transform.Get<Image>("Container/BgImage/bg_03")
            .SetSpriteByAtlas(Constants.AtlasNamePath.ViewStartGameAtlas, $"kstc_{hard + 1}_2", true);
        transform.Get<Text>("Container/BgImage/Degree/Text").text = hard == 0 ? "" : hard == 1 ? "困难" : "超难";
        ItemDobule.Get<Image>("bg_01/BG")
            .SetSpriteByAtlas(Constants.AtlasNamePath.ViewStartGameAtlas, $"bet_zy_{hard + 1}", true);
        if (hard == 0)
        {
            transform.Get<Image>("Container/BgImage/Degree").gameObject.SetActive(false);
        }
        else
        {
            transform.Get<Image>("Container/BgImage/Degree").SetSpriteByAtlas(Constants.AtlasNamePath.ViewStartGameAtlas,
                $"kstc_{hard + 1}_4", true);
        }

        dataService.NowBet = hard == 0 ? 1 : hard == 1 ? 3 : 5; 
        TitleText.text = ActivityManager.Instance.EndlessLevelActivity.IsOpenActivity()
            ? $"回合{dataService.NowViewMaxLayer}"
            : $"第 {dataService.NowViewMaxLayer} 关";
        CheckActivityCollect();
        CheckItemDobule();
    }

    private void CheckItemDobule()
    {
        int seconds = dataService.GetDobuleCollectTime();
        ItemDobule.SetActive(seconds > 0);
        if (seconds <= 0) return;
        StartCoroutine("UpdateDoubleTime");
    }

    IEnumerator UpdateDoubleTime()
    {
        int time = dataService.GetDobuleCollectTime();
        int seconds = time - TimeUtils.UtcNow();
        Text infiniteTimeText = activityTimeItem.transform.Get<Text>("Text");
        infiniteTimeText.text = $"{seconds / 60}分{seconds % 60}秒";
        WaitForSecondsRealtime waitForSecondsRealtime = new WaitForSecondsRealtime(1f);
        while (seconds > 0)
        {
            yield return waitForSecondsRealtime;
            seconds--;
            infiniteTimeText.text = $"{seconds / 60}分{seconds % 60}秒";
        }

        ItemDobule.SetActive(false);
    }

    private void EnterGameFunc()
    {
        GlobalRes.DynamicLoadView(Constants.DoozyView.Game, () => { EnterGameDetail(); });
    }

    private void CheckActivityCollect()
    {
        int index = 0;
        foreach (var obj in collectList)
        {
            obj.MSetActive(false);
        }
        int hard = configService.GetStageHard(dataService.NowMaxLevel);
        var list = ActivityManager.Instance.GetCollectActivity();
        foreach (var model in list)
        {
            if (index >= collectList.Count) break;
            collectList[index].gameObject.MSetActive(true);
            var icon = collectList[index].transform.Get<Image>("Icon");
            var bg = collectList[index].transform.GetComponent<Image>();
            
            icon.SetSpriteByAtlas(Constants.AtlasNamePath.TextureCommonAtlas, GameUtils.GetCollectIcon(model.type), true, () =>
            {
                float targetHeight = 100;
                float targetWidth = 80;
                float originalWidth = icon.sprite.rect.width;
                float originalHeight = icon.sprite.rect.height;
                float aspectRatio = originalWidth / originalHeight;
                float newWidth;
                float newHeight;
                if (originalHeight >= originalWidth)
                {
                    newHeight = targetHeight;
                    newWidth = targetHeight * aspectRatio;
                }
                else
                {
                    newWidth = targetWidth;
                    newHeight = targetWidth / aspectRatio;
                }
                icon.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
            });
            
            bg.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStartGameAtlas, $"kstc_{hard + 1}_3");
            collectList[index].transform.Get<Text>("Count").text =
                $"x{dataService.NowBet * dataService.GetCollectBet()}";
            index++;
        }
    }

    private bool CheckPreAddItemConsume()
    {
        int coin = 0;
        foreach (var propEnum in dataService.PreAddItem)
        {
            PowerItemModel powerItemModel = configService.PowerItemConfig[propEnum];
            coin += powerItemModel.Price;
        }

        if (dataService.Coin < coin) return false;
        return true;
    }

    private void EnterGameDetail(Action cb = null)
    {
        SoundPlayer.Instance.PlayCertainButton(2);
        int toLevel = dataService.NowMaxLevel;
        bool isEnough = ActivityManager.Instance.EnergyActivity.GetCurrentEnergy() > 0;
        if (isEnough)
        {
            BoxBuilder.ClearNowShowPopup();
            ViewQueueManager.Instance.ClearQueue();
            LevelUtils.LoadLevel(toLevel, model =>
            {
                BoxBuilder.ShowSceneChangePop(() =>
                {
                    CosumeAndReportStartEvent(toLevel, model);
                    BoxBuilder.HidePopup(gameObject);
                }, BoxBuilder.HideSceneChangePop);
            });
            cb?.Invoke();
        }
        else
        {
            ActivityManager.Instance.CheckPushGift(Constants.ProductId.BankruptcyPack_4, GiftType.BrokenGift);
        }
    }

    private void InitItem()
    {
        int index = 0;
        StageModel stageModel = GameUtils.GetCurStageModel();
        for (int i = 0; i < 3; i++)
        {
            int? itemId = null;
            int? timeItemId = null;
            if (stageModel.ItemList.Count > index)
            {
                itemId = (int) stageModel.ItemList[index];
                timeItemId = (int) configService.PowerItemConfig[(int) itemId.Value].relateItem;
            }

            Button itemBtn = itemLayout.Get<Button>("ItemBtn" + (index + 1));
            itemBtn.StopAllCoroutines();
            Image itemBG = itemBtn.GetComponent<Image>();
            Image itemIcon = itemBtn.transform.Get<Image>("ItemIcon");
            GameObject lockImage = itemBtn.transform.Find("Lock").gameObject;
            GameObject addImage = itemBtn.transform.Find("AddImage").gameObject;
            GameObject select = itemBtn.transform.Find("Select").gameObject;
            GameObject selectBg = itemBtn.transform.Find("SelectBg").gameObject;
            GameObject infinite = itemBtn.transform.Find("Infinite").gameObject;
            GameObject haveNum = itemBtn.transform.Find("HaveNum").gameObject;
            GameObject LvTextBG = itemBtn.transform.Find("LvTextBG").gameObject;
            Text itemNumText = itemBtn.transform.Get<Text>("HaveNum/ItemNumText");

            bool isLock = !itemId.HasValue;
            int infiniteTime =
                timeItemId.HasValue ? (int) dataService.GetPropNum((int) timeItemId.Value) - TimeUtils.UtcNow() : -1;
            bool isInfinite = infiniteTime >= 0;
            bool isSelect = !isLock && (isInfinite || selectItem.Contains((int) itemId.Value));

            bool isPreAddItem = false;
            foreach (var propEnum in dataService.PreAddItem)
            {
                if (isLock) continue;
                if (propEnum == (int) itemId.Value)
                {
                    isSelect = true;
                    isPreAddItem = true;
                    break;
                }
            }

            long haveItemNum = itemId.HasValue ? dataService.GetPropNum((int) itemId.Value) : 0;
            itemBG.SetSpriteByAtlas(Constants.AtlasNamePath.ViewStartGameAtlas, isLock ? "kstc_zy_3" : "kstc_zy_4",
                true);
            lockImage.SetActive(isLock);
            LvTextBG.SetActive(isLock);
            itemIcon.gameObject.SetActive(!isLock);
            addImage.SetActive(!isLock && !isSelect && haveItemNum <= 0);
            select.SetActive(isSelect);
            selectBg.SetActive(isSelect);
            itemBG.color = !isSelect ? Color.white : Color.clear;
            infinite.SetActive(!isLock && isInfinite);
            if (!isLock && isInfinite) select.SetActive(false);
            haveNum.SetActive(!isSelect && haveItemNum > 0);
            if (!isLock)
            {
                itemIcon.LoadPropSprite((int) itemId.Value, false);
                Vector2 itemIconSize = GameUtils.PropSizeDic[(int) itemId.Value] * 0.55f;
                itemIcon.rectTransform.sizeDelta = isSelect ? (itemIconSize * 1.1f) : itemIconSize;
            }
            else
            {
                Text LvText = itemBtn.transform.Get<Text>("LvTextBG/LvText");
                StageModel findStageModel = null;
                for (int j = stageModel.id + 1; j < configService.GetStageConfig.Count; j++)
                {
                    if (configService.GetStageConfig[j].ItemList.Count > index)
                    {
                        findStageModel = configService.GetStageConfig[j];
                        break;
                    }
                }

                if (findStageModel == null)
                    LvTextBG.SetActive(false);
                else
                    LvText.text = $"{findStageModel.id}";
            }

            if (isInfinite)
            {
                if (!selectItem.Contains((int) itemId.Value) && !isPreAddItem)
                {
                    selectItem.Add((int) itemId.Value);
                }

                itemBtn.StartCoroutine(CountDown(infiniteTime, infinite.transform));
            }

            itemNumText.text = haveItemNum.ToString();
            itemBtn.SetButtonClick(() =>
            {
                SoundPlayer.Instance.PlayCertainButton(2);
                if (isLock || isInfinite) return;
                if (isSelect)
                {
                    isSelect = false;
                    if (!isPreAddItem)
                    {
                        selectItem.Remove((int) itemId.Value);
                    }
                    else
                    {
                        dataService.OperatePreAddItem(2, (int) itemId.Value);
                    }

                    itemBG.color = Color.white;
                    select.SetActive(false);
                    selectBg.SetActive(false);
                    haveNum.SetActive(haveItemNum > 0);
                }
                else
                {
                    if (haveItemNum > 0)
                    {
                        isSelect = true;
                        if (!isPreAddItem)
                        {
                            selectItem.Add((int) itemId.Value);
                        }

                        itemBG.color = Color.clear;
                        select.SetActive(!isInfinite);
                        selectBg.SetActive(!isInfinite);
                        haveNum.SetActive(false);
                    }
                    else
                    {
                        BoxBuilder.ShowBuyItemPopup(itemId.Value);
                    }
                }

                Vector2 itemIconSize = GameUtils.PropSizeDic[(int) itemId.Value] * 0.55f;
                itemIcon.rectTransform.sizeDelta = isSelect ? (itemIconSize * 1.1f) : itemIconSize;
            });
            index++;
        }
    }

    private IEnumerator CountDown(int infiniteTime, Transform infiniteTrans)
    {
        if (infiniteTime < 0) yield break;
        int time = infiniteTime;
        Text infiniteTimeText = infiniteTrans.transform.Get<Text>("InfiniteTimeText");
        infiniteTimeText.text = TimeUtils.GetDateFromTimestamp(time, time > 3600 ? "hh:mm:ss" : "mm:ss");
        WaitForSecondsRealtime waitForSecondsRealtime = new WaitForSecondsRealtime(1f);
        while (time >= 0)
        {
            yield return waitForSecondsRealtime;
            time--;
            infiniteTimeText.text = TimeUtils.GetDateFromTimestamp(time, time > 3600 ? "hh:mm:ss" : "mm:ss");
        }

        InitItem();
    }

    private void OnPropChangeEvent(PropChangeEvent obj)
    {
        if (obj.newNum <= obj.oldNum) return;
        if (configService.PowerItemConfig.ContainsKey(obj.prop))
        {
            if (!selectItem.Contains(obj.prop))
                selectItem.Add(obj.prop);
            InitItem();
        }
    }

    private void OnDownloadLevelJsonResultEvent(DownloadLevelJsonResultEvent obj)
    {
        BoxBuilder.HideSceneChangePop();
        if (waitToLevel <= 0) return;
        BoxBuilder.SetLoadingPopShow(false);
        if (LevelUtils.CheckVaild(waitToLevel, out var levelModel))
        {
            CosumeAndReportStartEvent(waitToLevel, levelModel);
            ViewQueueManager.Instance.ClearQueue();
        }

        waitToLevel = -1;
        BoxBuilder.HidePopup(gameObject);
    }

    public void SetRestart()
    {
        transform.Get<Text>("Container/EnterBtn/Label").text = "重新开始";
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(() =>
        {
            if (GameController.Instance.IsRendering) return;
            EnterGameDetail();
        });
        restartGameCloseFunc = () =>
        {
            if (UIView.IsViewVisible(Doozy.Engine.UI.Base.NamesDatabase.GENERAL, Constants.ViewName_Game))
            {
                BoxBuilder.ShowSceneChangePop(() =>
                {
                    ActivityManager.Instance.ClearResultAddCount();
                    GameEventMessage.SendEvent(Constants.DoozyEvent.GameEnd);
                }, BoxBuilder.HideSceneChangePop);
            }
        };
    }

    public void SetNextStart()
    {
        transform.Get<Text>("Container/EnterBtn/Label").text = "开始";
        transform.Get<Button>("Container/EnterBtn").SetButtonClick(() =>
        {
            GameEventMessage.SendEvent(Constants.DoozyEvent.NextGame);
            EnterGameDetail();
        });
        nextGameCloseFunc = () =>
        {
            if (UIView.IsViewVisible(Doozy.Engine.UI.Base.NamesDatabase.GENERAL, Constants.ViewName_Game))
            {
                BoxBuilder.ShowSceneChangePop(() =>
                {
                    ActivityManager.Instance.ClearResultAddCount();
                    GameEventMessage.SendEvent(Constants.DoozyEvent.GameEnd);
                }, BoxBuilder.HideSceneChangePop);
            }
        };
    }

    private void CosumeAndReportStartEvent(int toLevel, LevelModel levelModel)
    {
        var startCoin = dataService.Coin;
        int consumeCoin = (int) dataService.GetPreAddItemConsume();
        dataService.UseProp((int) PropEnum.Coin, PropChangeWay.GameBeforeUseProp, consumeCoin);
        ActivityManager.Instance.EnergyActivity.UseEnergy(1);

        int? eliminateUse = null;
        int? cactusUse = null;
        int? windmillUse = null;
        int? jokerUse = null;

        if (selectItem.Contains((int) PropEnum.ItemEliminate))
            eliminateUse = GameUtils.CosumePowerItem((int) PropEnum.ItemEliminate);
        if (dataService.PreAddItem.Contains((int) PropEnum.ItemEliminate)) eliminateUse = (int) PropEnum.ItemEliminate;

        if (selectItem.Contains((int) PropEnum.ItemCactus))
            cactusUse = GameUtils.CosumePowerItem((int) PropEnum.ItemCactus);
        if (dataService.PreAddItem.Contains((int) PropEnum.ItemCactus)) cactusUse = (int) PropEnum.ItemCactus;

        if (selectItem.Contains((int) PropEnum.ItemWindmill))
            windmillUse = GameUtils.CosumePowerItem((int) PropEnum.ItemWindmill);
        if (dataService.PreAddItem.Contains((int) PropEnum.ItemWindmill)) windmillUse = (int) PropEnum.ItemWindmill;

        if (selectItem.Contains((int) PropEnum.ItemJoker))
            jokerUse = GameUtils.CosumePowerItem((int) PropEnum.ItemJoker);
        if (dataService.PreAddItem.Contains((int) PropEnum.ItemJoker)) jokerUse = (int) PropEnum.ItemJoker;

        List<int> realUseList = new List<int>();
        if (eliminateUse.HasValue) realUseList.Add((int) eliminateUse.Value);
        if (jokerUse.HasValue) realUseList.Add((int) jokerUse.Value);
        if (cactusUse.HasValue) realUseList.Add((int) cactusUse.Value);
        if (windmillUse.HasValue) realUseList.Add((int) windmillUse.Value);
        string propType = "Energy";
        AnalyticUtils.ReportUser_Add(AnalyticsKey.BattleTimes, 1);
        int defaultCost = configService.GetStageCost(toLevel);
        configService.GetWinStreakIdx(dataService.SuccessiveVictory, out var stepIdx);
        var winStreakCards =  configService.GetWinStreakRewardCards(dataService.NowMaxLevel, stepIdx);
        var level_type = 1;
        var level = dataService.MaxLevel;
        if (ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel) != null &&
            ActivityManager.Instance.GetActivityByType(ActivityType.endlessLevel).state == ActivityState.underWay)
        {
            level = dataService.EndlessLevelProgress.ViewMaxLayer;
            level_type = 2;
        }

        var msg = new Dictionary<string, object>
        {
            {AnalyticsKey.StageType, level_type},
            {AnalyticsKey.StageId, level},
            {AnalyticsKey.WinstreakLevel, stepIdx},
            {AnalyticsKey.StageStartCostType, propType},
            {AnalyticsKey.StageStartCostValue, 0},
            {AnalyticsKey.StageStartCostTicketValue, 0},
            {AnalyticsKey.StageStartDefaultCost, defaultCost},
            {AnalyticsKey.MultiplyFactor, dataService.NowBet},
            {AnalyticsKey.StagePowerupDelthreeUse, eliminateUse == (int) PropEnum.ItemEliminate ? 1 : 0},
            {AnalyticsKey.StagePowerupWildUse, jokerUse == (int) PropEnum.ItemJoker ? 1 : 0},
            {AnalyticsKey.StagePowerupCactusUse, cactusUse == (int) PropEnum.ItemCactus ? 1 : 0},
            {AnalyticsKey.StagePowerupDelthreeLimitless, eliminateUse == (int) PropEnum.TimeItemEliminate ? 1 : 0},
            {AnalyticsKey.StagePowerupWildLimitless, jokerUse == (int) PropEnum.TimeItemJoker ? 1 : 0},
            {AnalyticsKey.StagePowerupCactusLimitless, cactusUse == (int) PropEnum.TimeItemCactus ? 1 : 0},
            {AnalyticsKey.Coin, startCoin}
        };
        AnalyticUtils.ReportEvent(AnalyticsKey.SoliBattleStart, msg);
        TypeEventSystem.Send(new StartGameEvent(toLevel, levelModel, 0, 0, winStreakCards,
            realUseList));
        GameEventMessage.SendEvent(Constants.DoozyEvent.StartGame);
        dataService.OperatePreAddItem(3, (int) PropEnum.Xishu);
    }
}