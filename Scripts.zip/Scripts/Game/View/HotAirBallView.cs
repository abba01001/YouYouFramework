
using UnityEngine;
using SoliUtils;
using Button = UnityEngine.UI.Button;
using System.Collections.Generic;
using UnityEngine.UI;
using System;
using UniRx;

public class HotAirBallView : ViewBase
{
    private Button closeBtn;
    private Image RewardItemImage;
    private Text RewardItemText;
    private Button okBtn;
    private Text priceText;
    private Image coinImg;
    private RawImage offImg;
    private Text offText;
    private ActivityTimeItem timeItem;

    private int BallId;


    protected override void OnAwake()
    {
        closeBtn = transform.Get<Button>("Container/CloseBtn");
        closeBtn.SetButtonClick(() => { BoxBuilder.HidePopup(gameObject); });

        okBtn = transform.Get<Button>("Container/OkBtn");
        okBtn.SetButtonClick(() =>
        {
            DoBuyEvent();
        });

        RewardItemImage = transform.Get<Image>($"Container/RewardItem/Icon");
        RewardItemText = transform.Get<Text>($"Container/RewardItem/CountText");

        priceText = transform.Get<Text>("Container/OkBtn/PriceText");
        coinImg = transform.Get<Image>("Container/OkBtn/CoinImage");
        offImg = transform.Get<RawImage>("Container/OkBtn/OffImg");
        offText = transform.Get<Text>("Container/OkBtn/OffImg/OffText");
        timeItem = transform.Get<ActivityTimeItem>("Container/ActivityTimeItem");
    }

    void RefreshTimer(DateTime endTime)
    {
        CountTimeData timeData = GameObjManager.Instance.PopClass<CountTimeData>(true);
        timeData.Clear();
        timeData.endTime = endTime;
        timeItem.SetTimeData(timeData);
    }

    void ShowReward()
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var data = dataService.GetMergeHotAirBallData();
        data.TryGetValue(BallId, out MergeHotAirBallModel model);
        if (model != null && configService.MergeHotAirBallConfig.TryGetValue(model.cfgId, out var cfg))
        {
            string[] param = cfg.reward.Split(GameUtils.FirstSeparator, StringSplitOptions.RemoveEmptyEntries);
            int reward_item_id = int.Parse(param[0]);
            int reward_item_count = int.Parse(param[1]);
            RewardItemImage.LoadPropSprite(reward_item_id, true, () =>
            {
                float targetHeight = 160;
                float targetWidth = 130;
                float originalWidth = RewardItemImage.sprite.rect.width;
                float originalHeight = RewardItemImage.sprite.rect.height;
                float aspectRatio = originalWidth / originalHeight;
                float newWidth;
                float newHeight;
                if (originalHeight >= originalWidth)
                {
                    newHeight = targetHeight;
                    newWidth = targetHeight * aspectRatio;
                }
                else
                {
                    newWidth = targetWidth;
                    newHeight = targetWidth / aspectRatio;
                }
                RewardItemImage.rectTransform.sizeDelta = new Vector2(newWidth, newHeight);
            });
            RewardItemText.gameObject.SetActive(reward_item_count > 1);
            RewardItemText.text = $"x{reward_item_count}";

            int price = cfg.price;
            if (cfg.purchase_type == 1)
            {
                coinImg.gameObject.SetActive(true);
                coinImg.LoadPropSprite((int)PropEnum.BuildCoin);
                priceText.text = $"{price}";
            }
            else if (cfg.purchase_type == 2)
            {
                coinImg.gameObject.SetActive(true);
                coinImg.LoadPropSprite((int)PropEnum.Coin);
                priceText.text = $"{price}";
            }
            else if (cfg.purchase_type == 3)
            {
                coinImg.gameObject.SetActive(false);
                priceText.text = $"{price}元";
                var pos = priceText.transform.localPosition;
                pos.x = 0;
                priceText.transform.localPosition = pos;
            }

            offImg.gameObject.SetActive(cfg.off < 100);
            offText.text = $"{cfg.off}%";

            DateTime dt = TimeUtils.UnixTimeStampToDateTime(cfg.time + model.time);
            RefreshTimer(dt);
        }
    }

    public void SetBallId(int ballId)
    {
        BallId = ballId;
        ShowReward();
    }

    void DoBuyEvent()
    {
        var configService = MainContainer.Container.Resolve<IConfigService>();
        var dataService = MainContainer.Container.Resolve<IDataService>();
        var data = dataService.GetMergeHotAirBallData();
        data.TryGetValue(BallId, out MergeHotAirBallModel model);
        if (model != null && configService.MergeHotAirBallConfig.TryGetValue(model.cfgId, out var cfg))
        {
            int price = cfg.price;
            if (cfg.purchase_type == 1)
            {
                if(dataService.BuildCoin >= price)
                {
                    dataService.BuyHotAirBall(model.id, cfg.id);
                }
                else
                {
                    BoxBuilder.ShowToast("建筑币不足");
                }
            }
            else if (cfg.purchase_type == 2)
            {
                if(dataService.Coin >= price)
                {
                    dataService.BuyHotAirBall(model.id, cfg.id);
                }
                else
                {
                    BoxBuilder.ShowToast("金币不足");
                }
            }
            else if (cfg.purchase_type == 3)
            {
                var paramex = $"{'{'}\"ball_id\":{model.id},\"cfg_id\":{model.cfgId}{'}'}";
                PayUtils.RequestOrder(cfg.product_id, paramex);
            }

            offImg.gameObject.SetActive(cfg.off < 100);
            offText.text = $"{cfg.off}%";

            DateTime dt = TimeUtils.UnixTimeStampToDateTime(cfg.time + model.time);
            RefreshTimer(dt);
        }
        else
        {
            BoxBuilder.ShowToast("无效气球");
        }
    }
}