﻿using System;
using System.Collections.Generic;
using UnityEngine;

static public partial class Constants
{
#if TestMode
    public const string ResVersion = "0.0.1";
#else
    public const string ResVersion = "0.2.14";
#endif
    public const string ApiUrl = "https://qxjlapi.6666net.com";
    public const string StorageUrl = "https://qxjlsite.6666net.com";
    public const string CnfAssetUrl = ""; //"http://solitaire-hw-qy.gogogame.com/" + ResVersion + "/";
    public const string ProvinceUrl = "https://api.live.bilibili.com/client/v1/Ip/getInfoNew";

    public const int DataVersion = 2;

    public const string AssetLastUpdateFile = "manifest.json";
    public const string AssetVersionConfigFile = "asset-version.json";
    public const string DefaultAssetVersionConfigFile = "default-remote-asset-version.json";

    public const string AssetTypeExcel = "excel";

    public const string DesKey = "g7uHygaenuWhnAKRXHzsrZX3T2D8pOQT";
    public const string ServerKey = "g8uHygaenuWhnAKRXHzsrZX3T2D7pOQT";


    public static readonly Vector2 CardSize = new Vector2(100f, 153f);
    public static readonly Vector2 CardSizeScale = new Vector2(1f, 1f);
    public static readonly Vector2 TwoValueCardSizeScale = new Vector2(1.5f, 1.5f);

    public const int ResolutionWidth = 1624;
    public const int ResolutionHeight = 750;
    public const float MatchOnWidthOrHeight = 0;
    public const int TargetFrameRate = 60;

    public const int HttpResponseOk = 200;
    public const int HttpResponseOkPartial = 206;
    public const int HttpResponseNotModified = 304;
    public const int HttpResponseErrorUrlIsNull = -1001;
    public const int HttpResponseRangeNotSatisfiable = 416;

    public const int ValueCardCount13 = 13;
    public const int ValueCardCount52 = 52;
    public const int MoreCardComboNumber = 5;
    public const int MoreCardMax = 2;

    public const int RegionNum = 2;

    public const int MergeLevelBoxItemId = 80001;
    public const int MergeExpBar1ItemId = 20001;
    public const int MergeExpBar5ItemId = 20005;
    

    public const string DefaultAvatarUrl = StorageUrl + "/avatars/1.jpg";


    public static readonly string[] FlowerResMap = new[]
    {
        "Assets/Res/Cards/Textures/huase_d.png",
        "Assets/Res/Cards/Textures/huase_a.png",
        "Assets/Res/Cards/Textures/huase_b.png",
        "Assets/Res/Cards/Textures/huase_c.png"
    };

    public static readonly string[] FlowerRes2Map = new[]
    {
        "Assets/Res/Cards/Textures/duodian_huase_4.png",
        "Assets/Res/Cards/Textures/duodian_huase_1.png",
        "Assets/Res/Cards/Textures/duodian_huase_2.png",
        "Assets/Res/Cards/Textures/duodian_huase_3.png"
    };

    public const string CardTypeValue = "value";
    public const string CardTypeJoker = "joker";
    public const string CardTypeBoom = "boom";
    public const string CardTypeZap = "zap";
    public const string CardTypeLock = "lock";
    public const string CardTypeKey = "key";
    public const string CardTypeThree = "plus_three";
    public const string CardTypeAnchor = "anchor";
    public const string CardTypeBanana = "banana";
    public const string CardTypeMonkey = "monkey";
    public const string CardTypeWindmill = "windmill";
    public const string CardTypeGold = "gold";
    public const string CardTypeMonochrome = "monochrome";
    public const string CardTypeTwovalue = "two_value";
    public const string CardTypeCopy = "copy";
    public const string CardTypeQuestion = "question";
    public const string CardTypeRudder = "rudder";
    public const string CardTypeCannon = "cannon";

    public const string ModifierTypeBomb = "bomb";
    public const string ModifierTypeBigBomb = "new_bomb";
    public const string ModifierTypeRising = "rising";
    public const string ModifierTypeLowering = "lowering";
    public const string ModifierTypeWater = "water";
    public const string ModifierTypeIce = "ice";
    public const string ModifierTypeLightning = "lightning";
    public const string ModifierTypeGreenLeaf = "greenLeaf";
    public const string ModifierTypeCloth = "cloth";
    public const string ModifierTypeMagicCloth = "magicCloth";
    public const string ModifierTypeRope = "suitRope";
    public const string ModifierTypeCoin = "coin";
    public const string ModifierTypeLinkRope = "link_rope";
    public const string ModifierTypeLizard = "lizard";
    public const string ModifierTypeTask = "task";

    public static Dictionary<CardType, GameObjType> CardType2ObjDic = new Dictionary<CardType, GameObjType>()
    {
        { CardType.Value, GameObjType.ValueCard },
        { CardType.Joker, GameObjType.JokerCard },
        { CardType.Boom, GameObjType.BoomCard },
        { CardType.Zap, GameObjType.ZapCard },
        { CardType.Lock, GameObjType.LockCard },
        { CardType.Key, GameObjType.KeyCard },
        { CardType.Three, GameObjType.ThreeCard },
        { CardType.Anchor, GameObjType.AnchorCard },
        { CardType.Gold, GameObjType.GoldCard },
        { CardType.Monochrome, GameObjType.MonochromeCard },
        { CardType.TwoValue, GameObjType.TwoValueCard },
        { CardType.Copy, GameObjType.CopyCard },
        { CardType.Windmill, GameObjType.WindmillCard },
        { CardType.Banana, GameObjType.BananaCard },
        { CardType.Monkey, GameObjType.MonkeyCard },
        { CardType.Question, GameObjType.QuestionCard },
        { CardType.Rudder, GameObjType.RudderCard },
        { CardType.Cannon, GameObjType.CannonCard },
    };

    //需要弹窗说明提示的特殊牌
    public static List<CardType> SpecialCardList = new List<CardType>()
    {
        CardType.Three,
        CardType.Zap,
        CardType.Boom,
        CardType.TwoValue,
        CardType.Lock,
        CardType.Anchor,
        CardType.Key,
        CardType.Banana,
        CardType.Monkey,
        CardType.Windmill,
        CardType.Gold,
        CardType.Monochrome,
        CardType.Copy,
        CardType.Joker,
        CardType.Rudder,
        CardType.Question
    };

    //需要弹窗说明提示的特殊牌
    public static List<ModifierType> SpecialModTypeList = new List<ModifierType>()
    {
        ModifierType.Bomb,
        ModifierType.Rising,
        ModifierType.Lowering,
        ModifierType.Water,
        ModifierType.Ice,
        ModifierType.Lightning,
        ModifierType.GreenLeaf,
        ModifierType.Cloth,
        ModifierType.MagicCloth,
        ModifierType.SuitRope,
        ModifierType.BigBomb,
        ModifierType.LinkRope
    };

    public static Dictionary<string, CardType> String2CardTypeDic = new Dictionary<string, CardType>()
    {
        { CardTypeValue, CardType.Value },
        { CardTypeJoker, CardType.Joker },
        { CardTypeBoom, CardType.Boom },
        { CardTypeZap, CardType.Zap },
        { CardTypeLock, CardType.Lock },
        { CardTypeKey, CardType.Key },
        { CardTypeThree, CardType.Three },
        { CardTypeAnchor, CardType.Anchor },
        { CardTypeGold, CardType.Gold },
        { CardTypeMonochrome, CardType.Monochrome },
        { CardTypeTwovalue, CardType.TwoValue },
        { CardTypeCopy, CardType.Copy },
        { CardTypeWindmill, CardType.Windmill },
        { CardTypeBanana, CardType.Banana },
        { CardTypeMonkey, CardType.Monkey },
        { CardTypeQuestion, CardType.Question },
        { CardTypeRudder, CardType.Rudder },
        { CardTypeCannon, CardType.Cannon },
    };

    public static Dictionary<CardType, string> CardType2StringDic = new Dictionary<CardType, string>()
    {
        { CardType.Value, CardTypeValue },
        { CardType.Joker, CardTypeJoker },
        { CardType.Boom, CardTypeBoom },
        { CardType.Zap, CardTypeZap },
        { CardType.Lock, CardTypeLock },
        { CardType.Key, CardTypeKey },
        { CardType.Three, CardTypeThree },
        { CardType.Anchor, CardTypeAnchor },
        { CardType.Gold, CardTypeGold },
        { CardType.Monochrome, CardTypeMonochrome },
        { CardType.TwoValue, CardTypeTwovalue },
        { CardType.Copy, CardTypeCopy },
        { CardType.Windmill, CardTypeWindmill },
        { CardType.Banana, CardTypeBanana },
        { CardType.Monkey, CardTypeMonkey },
        { CardType.Question, CardTypeQuestion },
        { CardType.Rudder, CardTypeRudder },
        { CardType.Cannon, CardTypeCannon },
    };

    public static Dictionary<string, ModifierType> String2ModTypeDic = new Dictionary<string, ModifierType>()
    {
        { ModifierTypeBomb, ModifierType.Bomb },
        { ModifierTypeBigBomb, ModifierType.BigBomb },
        { ModifierTypeRising, ModifierType.Rising },
        { ModifierTypeLowering, ModifierType.Lowering },
        { ModifierTypeWater, ModifierType.Water },
        { ModifierTypeIce, ModifierType.Ice },
        { ModifierTypeLightning, ModifierType.Lightning },
        { ModifierTypeGreenLeaf, ModifierType.GreenLeaf },
        { ModifierTypeCloth, ModifierType.Cloth },
        { ModifierTypeMagicCloth, ModifierType.MagicCloth },
        { ModifierTypeRope, ModifierType.SuitRope },
        { ModifierTypeCoin, ModifierType.Coin },
        { ModifierTypeLinkRope, ModifierType.LinkRope },
        { ModifierTypeLizard, ModifierType.Lizard },
        { ModifierTypeTask, ModifierType.Task },
    };

    public static Dictionary<ModifierType, string> ModType2StringDic = new Dictionary<ModifierType, string>()
    {
        { ModifierType.Bomb, ModifierTypeBomb },
        { ModifierType.BigBomb, ModifierTypeBigBomb },
        { ModifierType.Rising, ModifierTypeRising },
        { ModifierType.Lowering, ModifierTypeLowering },
        { ModifierType.Water, ModifierTypeWater },
        { ModifierType.Ice, ModifierTypeIce },
        { ModifierType.Lightning, ModifierTypeLightning },
        { ModifierType.GreenLeaf, ModifierTypeGreenLeaf },
        { ModifierType.Cloth, ModifierTypeCloth },
        { ModifierType.MagicCloth, ModifierTypeMagicCloth },
        { ModifierType.SuitRope, ModifierTypeRope },
        { ModifierType.Coin, ModifierTypeCoin },
        { ModifierType.LinkRope, ModifierTypeLinkRope },
        { ModifierType.Lizard, ModifierTypeLizard },
        { ModifierType.Task, ModifierTypeTask },
    };

    public static Dictionary<string, FlagType> BankruptcyFlagId = new Dictionary<string, FlagType>()
    {
        {ProductId.BankruptcyPack_1, FlagType.BankruptcyPack_1},
        {ProductId.BankruptcyPack_2, FlagType.BankruptcyPack_2},
        {ProductId.BankruptcyPack_3, FlagType.BankruptcyPack_3},
        {ProductId.BankruptcyPack_4, FlagType.BankruptcyPack_4},
        {ProductId.SmallBankruptcyPack_1, FlagType.SmallBankruptcyPack_1},
        {ProductId.SmallBankruptcyPack_2, FlagType.SmallBankruptcyPack_2},
        {ProductId.SmallBankruptcyPack_3, FlagType.SmallBankruptcyPack_3},
        {ProductId.SmallBankruptcyPack_4, FlagType.SmallBankruptcyPack_4},
    };

    #region 动画用常量参数

    public const string showFxStr = "Assets/Res/Prefabs/FX/liang_tx_01.prefab"; //亮牌特效
    public const string baoFx1Str = "Assets/Res/Prefabs/FX/bao_tx_01.prefab"; //爆炸特效1  剪刀用
    public const string baoFx2Str = "Assets/Res/Prefabs/FX/bao_tx_02.prefab"; //爆炸特效2  仙人掌用
    public const string baoFx3Str = "Assets/Res/Prefabs/FX/bao_tx_03.prefab"; //爆炸特效3  +3牌用

    public const string zapPrefabStr = "Assets/Res/Prefabs/FX/daoju_jiandao.prefab"; //剪刀道具
    public const string flyZapFxStr = "Assets/Res/Prefabs/FX/daoju_jiandao_dh_01.prefab"; //飞行的剪刀特效

    public const string boomPrefabStr = "Assets/Res/Prefabs/FX/daoju_boom.prefab"; //仙人掌爆炸道具
    public const string boomGatherFxStr = "Assets/Res/Prefabs/FX/shou_tx_01.prefab"; //仙人掌爆炸收拢特效

    public const string bombFxStr = "Assets/Res/Prefabs/FX/zhadan_bao_tx_01.prefab"; //大爆炸特效
    public const string fireFxStr = "Assets/Res/Prefabs/FX/bao_tx_FireCrackerMod_02.prefab"; //炮仗爆炸特效

    public const string iceBreakStr = "Assets/Res/Prefabs/FX/bing_sui_tx_01.prefab"; //冰碎效果
    public const string iceBreakFxStr = "Assets/Res/Prefabs/FX/bing_sui_tx_02.prefab"; //冰碎特效

    public const string threeFxPrefabStr = "Assets/Res/Prefabs/FX/pai_hua_tx_01.prefab"; //+3牌触发特效

    public const string keyPrefabStr = "Assets/Res/Prefabs/FX/daoju_key.prefab"; //钥匙道具
    public const string OpenLockFx = "Assets/Res/Prefabs/FX/jiesuo_bao_tx_01.prefab"; //锁打开触发特效

    public const string anchorPrefabStr = "Assets/Res/Prefabs/FX/tieqiao_dh.prefab"; //镐子道具
    public const string stoneBrokenStr = "Assets/Res/Prefabs/FX/shitou_sui_dh_01.prefab"; //碎石物体

    public const string cardChipFxStr = "Assets/Res/Prefabs/FX/Card_chip_dh.prefab"; //刀光特效  消牌强化道具用
    public const string cardChipItemStr = "Assets/Res/Cards/Prefabs/EliminateCard.prefab"; //刀光特效  消牌强化道具用
    public const string powerItemShowFxStr = "Assets/Res/Prefabs/FX/Show_card_tx_01.prefab"; //强化道具进场特效
    public const string buyJokerCardFxStr1 = "Assets/Res/Prefabs/FX/JokerCard_dianji_tx_01.prefab"; //购买万能牌1
    public const string buyJokerCardFxStr2 = "Assets/Res/Prefabs/FX/JokerCard_tuowei_lz_01.prefab"; //购买万能牌2
    public const string windmiallFx = "Assets/Res/Prefabs/FX/WindmillCard_tuowei_lz_01.prefab"; //风车牌特效

    public const string suitropeRope1 = "Assets/Res/Prefabs/FX/rope_tx_01.prefab"; //花绳子
    public const string suitropeRope2 = "Assets/Res/Prefabs/FX/rope_tx_02.prefab"; //花绳子
    public const string suitropeSuit0 = "Assets/Res/Prefabs/FX/rope_suit_tx_0.prefab"; //花绳子
    public const string suitropeSuit1 = "Assets/Res/Prefabs/FX/rope_suit_tx_1.prefab"; //花绳子
    public const string suitropeSuit2 = "Assets/Res/Prefabs/FX/rope_suit_tx_2.prefab"; //花绳子
    public const string suitropeSuit3 = "Assets/Res/Prefabs/FX/rope_suit_tx_3.prefab"; //花绳子
    public const string suitropeBao = "Assets/Res/Prefabs/FX/rope_bao_tx.prefab"; //花绳子
    public const string lightningFx01 = "Assets/Res/Prefabs/FX/LightningMod_fx_01.prefab"; //闪电
    public const string lightningFx02 = "Assets/Res/Prefabs/FX/LightningMod_fx_02.prefab"; //闪电
    public const string lightningFx03 = "Assets/Res/Prefabs/FX/LightningChain_tx.prefab"; //闪电链

    public const string CardBackTex_Normal = "Assets/Res/Cards/TexBack/back_normal.png";
    public const string CardBackTex_GreenLeaf = "Assets/Res/Cards/TexBack/back_leaf.png";
    public const string CardBackTex_Lighting = "Assets/Res/Cards/TexBack/back_lightning.png";
    public const string CardBackTex_BigBomb = "Assets/Res/Cards/TexBack/back_bigbomb.png";
    public const string CardBackTex_Win = "Assets/Res/Cards/TexBack/back_win.png";


    public const string CardFrontTex_Normal = "Assets/Res/Cards/TexFront/front_normal.png";
    public const string CardFrontTex_GreenLeaf = "Assets/Res/Cards/TexFront/front_leaf.png";
    public const string CardFrontTex_Lighting = "Assets/Res/Cards/TexFront/front_lightning.png";
    public const string CardFrontTex_BigBomb = "Assets/Res/Cards/TexFront/front_bigbomb.png";

    #endregion



    #region UI命名常量

    public static readonly string ViewName_Home = "Home";
    public static readonly string ViewName_Game = "Game";
    public static readonly string NodyName_Home = "HomeViewSubGraph";
    public static readonly string NodyName_Game = "View - Game";

    #endregion


    #region 预加载资源

    public static readonly List<Tuple<string, Type>> PreLoadResList = new List<Tuple<string, Type>>()
    {
        // new("Assets/Res/Prefabs/FX/daoju_jiandao_dh_01.prefab", typeof(GameObject)),
    };

    //图集资源名对应路径
    public struct AtlasNamePath
    {
        public const string MergeItemsAtlas = "Assets/Res/Merge/Textures/merge_items.spriteatlas";
        public const string PropsAtlas = "Assets/Res/Atlas/atlas_props.asset";
        public const string ViewHomeAtlas = "Assets/Res/Atlas/atlas_view_home.asset";
        public const string ViewHomeMapAtlas = "Assets/Res/Atlas/atlas_view_home_map.asset";
        public const string ViewFlowerAtlas = "Assets/Res/Atlas/atlas_view_flower.asset";
        public const string ViewSettingAtlas = "Assets/Res/Atlas/atlas_view_setting.asset";
        public const string ViewStartGameAtlas = "Assets/Res/Atlas/atlas_view_start_game.asset";
        public const string ViewWheelAtlas = "Assets/Res/Atlas/atlas_view_wheel.asset";
        public const string ViewGameAtlas = "Assets/Res/Atlas/atlas_view_game.asset";
        public const string StartPageAtlas = "Assets/Res/Atlas/atlas_view_start_page_item.asset";
        public const string ViewCollectFlowerAtlas = "Assets/Res/Atlas/atlas_view_collect_flower.asset";
        public const string ViewExitGameAtlas = "Assets/Res/Atlas/atlas_view_exit_game.asset";
        public const string ViewEndlessLevelAtlas = "Assets/Res/Atlas/atlas_view_endless_level.asset";
        public const string ViewLevelPassAtlas = "Assets/Res/Atlas/atlas_view_level_pass.asset";
        public const string ViewGradientGiftAtlas = "Assets/Res/Atlas/atlas_view_gradient_gift.asset";
        public const string ViewGiftDigtAtlas = "Assets/Res/Atlas/atlas_view_gift_dig.asset";
        public const string ViewDigTreasuretAtlas = "Assets/Res/Atlas/atlas_view_dig_treasure.asset";
        public const string ViewSaverAtlas = "Assets/Res/Atlas/atlas_view_saver.asset";
        public const string ViewCollectLoveCardAtlas = "Assets/Res/Atlas/atlas_view_collect_love_card.asset";
        public const string ViewPassRankAtlas = "Assets/Res/Atlas/atlas_view_pass_rank.asset";
        public const string ViewCarRankAtlas = "Assets/Res/Atlas/atlas_view_car_rank.asset";
        public const string ViewCookMealAtlas = "Assets/Res/Atlas/atlas_view_cook_meal.asset";
        public const string ViewWinningStreakAtlas = "Assets/Res/Atlas/atlas_view_winning_streak.asset";
        public const string ViewResultAtlas = "Assets/Res/Atlas/atlas_view_result.asset";
        public const string ViewEmailAtlas = "Assets/Res/Atlas/atlas_view_email.asset";
        public const string ViewShopAtlas = "Assets/Res/Atlas/atlas_view_shop.asset";
        public const string ViewStreakTipAtlas = "Assets/Res/Atlas/atlas_view_streak_tip.asset";
        public const string ViewLimitPkAtlas = "Assets/Res/Atlas/atlas_view_limit_pk.asset";
        public const string ViewCheckInAtlas = "Assets/Res/Atlas/atlas_view_checkin.asset";
        public const string ViewFarmingAtlas = "Assets/Res/Atlas/atlas_view_faming.asset";
        public const string ViewRabbitGiftAtlas = "Assets/Res/Atlas/atlas_view_rabbit_gift.asset";
        public const string ViewFirstGiftAtlas = "Assets/Res/Atlas/atlas_view_first_gift.asset";
        public const string SeasonPassAtlas = "Assets/Res/Atlas/atlas_view_season_pass.asset";
        public const string TextureBoxAtlas = "Assets/Res/Atlas/atlas_texture_box.asset";
        public const string TextureCommonAtlas = "Assets/Res/Atlas/atlas_texture_common.asset";
        public const string MergeOrderAtlas = "Assets/Res/Atlas/atlas_view_merge_order.asset";
        public const string ViewRookieAtlas = "Assets/Res/Atlas/atlas_view_rookie.asset";
        public const string ViewRegionRewards = "Assets/Res/Atlas/atlas_view_region_rewards.asset";
        

    }

    //内购产品id
    public struct ProductId
    {
        public const string MonthlySubscription = "MonthlySubscription";
        public const string WeeklySubscription = "WeeklySubscription";
        public const string FirstPayment = "FirstPayment";
        public const string SmallFirstPayment = "SmallFirstPayment";
        public const string HeartBeatGift = "HeartBeatGift";
        public const string ShovelGift = "ShovelGift";
        public const string ChefhatGift = "ChefhatGift";
        public const string SeasonPass = "SeasonPass";
        public const string PiggyBank = "PiggyBank";
        public const string WheelGiftPack = "WheelGiftPack";
        public const string DailyPurchaseLimit_1 = "DailyPurchaseLimit_1";
        public const string WeeklyPurchaseLimit_1 = "WeeklyPurchaseLimit_1";
        public const string MonthlyPurchaseLimit_1 = "MonthlyPurchaseLimit_1";
        public const string BankruptcyPack_1 = "BankruptcyPack_1";
        public const string BankruptcyPack_2 = "BankruptcyPack_2";
        public const string BankruptcyPack_3 = "BankruptcyPack_3";
        public const string BankruptcyPack_4 = "BankruptcyPack_4";

        public const string SmallBankruptcyPack_1 = "SmallBankruptcyPack_1";
        public const string SmallBankruptcyPack_2 = "SmallBankruptcyPack_2";
        public const string SmallBankruptcyPack_3 = "SmallBankruptcyPack_3";
        public const string SmallBankruptcyPack_4 = "SmallBankruptcyPack_4";

        public const string AssistancePack_1 = "AssistancePack_1";
        public const string NarrowDefeatPack_1 = "NarrowDefeatPack_1";
        public const string NarrowDefeatPack_2 = "NarrowDefeatPack_2";
        public const string NarrowDefeatPack_3 = "NarrowDefeatPack_3";
        
        public const string GiftPlusOne = "GiftPlusOne";
        public const string GiftPlusFour = "GiftPlusFour";
        public const string DiscountGift = "DiscountGift";
        
        public const string GiftDragOne_1_1 = "GiftDragOne_1_1";
        public const string GiftDragOne_1_2 = "GiftDragOne_1_2";
        public const string GiftDragOne_1_3 = "GiftDragOne_1_3";
        public const string GiftDragTwo_2_1 = "GiftDragTwo_2_1";
        public const string GiftDragTwo_2_2 = "GiftDragTwo_2_2";
        public const string GiftDragTwo_2_3 = "GiftDragTwo_2_3";
        public const string GiftDragSix_6_1 = "GiftDragSix_6_1";
        public const string GiftDragSix_6_2 = "GiftDragSix_6_2";
        public const string GiftDragSix_6_3 = "GiftDragSix_6_3";
        
        
    }

    //Item资源名对应路径
    public struct ItemNamePath
    {
        public const string PassRankItem = "Assets/Res/Prefabs/Item/PassRankItem.prefab";
        public const string WinStreakCard = "Assets/Res/Prefabs/Item/WinStreakCard.prefab";
        public const string StageProgressGift = "Assets/Res/Prefabs/Item/StageProgressGift.prefab";
        public const string RookieTipItem = "Assets/Res/Prefabs/Item/RookieTipItem.prefab";
        public const string FarmingPrefab = "Assets/Res/Prefabs/Item/FarmingPrefab.prefab";
        public const string BallonGift = "Assets/Res/Prefabs/Item/BallonGift.prefab";
        public const string CatalogueItem = "Assets/Res/Prefabs/Item/CatalogueItem.prefab";
        public const string StartActivityItem = "Assets/Res/Prefabs/Item/StartActivityItem.prefab";
        public const string BigShopItem = "Assets/Res/Prefabs/Item/BigShopItem.prefab";
        public const string SmallShopItem = "Assets/Res/Prefabs/Item/SmallShopItem.prefab";
        public const string SeasonPassShopItem = "Assets/Res/Prefabs/Item/SeasonPassShopItem.prefab";
    }

    #endregion

    public enum HandlePaidType
    {
        FirstPaidGift = 1, //首充礼包
        WeekVipCard, //周卡
        MonthVipCard, //月卡
        TodayFirstPaid, //每日首次充值
        ContinuousPaid, //连续每日充值，次日未充值即中断(第二天开始触发)
        TodaySecondPaid, //当日第2次付费
        TodayMorePaid, //当日第2+次付费
        TodayAccumulatedPaid, //当天付费到达N元
        HeartBeatGiftPaid, //1元首充
    }

    public enum ItemType
    {
        Asset = 1, //虚拟资产
        Item = 2, //普通道具
        ForceItem = 3, //开局强化道具
        TimeForceItem = 4, //开局强化道具计时
    }

    public enum MergeItemType
    {
        Normal = 1, //普通合成物
        AllMerge = 2, //万能合成物
        Exp = 3, //经验碎片
        Npc = 4, //NPC
        LevelBox = 5, //关卡宝箱
        MapBox = 6, //地图宝箱
        TimerBox = 7, //定时宝箱
        Market = 8, //集市合成物
        LimitedEdition = 9, //限定合成物
        BuildCoinBox = 10, //建造币宝箱
    }

}
