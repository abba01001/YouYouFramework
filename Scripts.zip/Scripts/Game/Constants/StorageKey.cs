static public partial class Constants
{
    public struct StorageKey
    {
        //配置
        public const string PatchAssetVersion = "PatchAssetVersion";
        public const string PatchAssetConfig = "PatchAssetConfig";
        public const string RemoteAssetConfig = "RemoteAssetConfig";
        public const string AssetVersion = "AssetVersion";
        public const string ValueConfig = "ValueConfig";
        public const string CollectFlowerConfig = "CollectFlowerConfig";
        public const string RobotConfig = "RobotConfig";
        public const string StageConfig = "NewStageConfig";
        // public const string HandleConfig = "HandleConfig";
        public const string RookieConfig = "RookieConfig";
        public const string RookieClickConfig = "RookieClickConfig";
        public const string RookieDialogueConfig = "RookieDialogueConfig";
        public const string RookieDragConfig = "RookieDragConfig";
        public const string RookieAnimConfig = "RookieAnimConfig";
        public const string ShopConfig = "ShopConfig";
        public const string CardRemainConfig = "CardRemainConfig";
        public const string ComboRewardConfig = "ComboRewardConfig";
        public const string SignInConfig = "SignInConfig";
        // public const string WheelConfig = "WheelConfig";
        public const string BetConfig = "BetConfig";
        public const string ItemConfig = "ItemConfig";
        public const string PowerItemConfig = "PowerItemConfig";
        public const string ActivitiesConfig = "ActivitiesConfig";
        public const string SeasonRewardConfig = "SeasonRewardConfig";
        public const string ActivitiesSwitchConfig = "ActivitiesSwitchConfig";
        public const string CollectLoveCardConfig = "CollectLoveCardConfig";
        public const string CollectMusicConfig = "CollectMusicConfig";
        public const string DigTreasureRewardConfig = "DigTreasureRewardConfig";
        public const string LevelPassConfig = "LevelPassConfig";
        public const string LavaPassConfig = "LavaPassConfig";
        // public const string FarmingConfig = "FarmingConfig";
        public const string UnlockConfig = "UnlockConfig";
        public const string CookMealConfig = "CookMealConfig";
        public const string MysteriousSeedConfig = "MysteriousSeedConfig";
        public const string MagicNectarConfig = "MagicNectarConfig";
        public const string RainbowDropsConfig = "RainbowDropsConfig";
        public const string EndlessStageOneConfig = "EndlessStageOneConfig";
        public const string EndlessStageTwoConfig = "EndlessStageTwoConfig";
        public const string EndlessLevelRewardConfig = "EndlessLevelRewardConfig";
        public const string WheelRewardConfig = "WheelRewardConfig";
        public const string PopupPriorityConfig = "PopupPriorityConfig";
        public const string AdRewardConfig = "AdRewardConfig";
        public const string PassRankRobotConfig = "PassRankRobotConfig";
        public const string CarRankRobotConfig = "CarRankRobotConfig";
        public const string GradientConfig = "GradientConfig";
        public const string GiftGradientCookConfig = "GiftGradientCookConfig";
        public const string GiftGradientDigConfig = "GiftGradientDigConfig";
        public const string PassRankRewardConfig = "PassRankRewardConfig";
        public const string CarRankRewardConfig = "CarRankRewardConfig";
        public const string LimitPkConfig = "LimitPkConfig";
        public const string PushGiftConfig = "PushGiftConfig";
        public const string SoundConfig = "SoundConfig";
        public const string CardDescConfig = "CardDescConfig";
        public const string SeasonPassConfig = "SeasonPassConfig";
        public const string NewUserSeasonPassConfig = "NewUserSeasonPassConfig";
        public const string SeasonExpConfig = "SeasonExpConfig";
        // public const string ExperienceConfig = "ExperienceConfig";
        // public const string LevelResultConfig = "LevelResultConfig";
        public const string TimingMessageConfig = "TimingMessageConfig";
        public const string HandleLevelConfig = "HandleLevelConfig";
        public const string HandleEndlessLevelConfig = "HandleEndlessLevelConfig";
        public const string HandleResultConfig = "HandleResultConfig";
        public const string HandleLabelConfig = "HandleLabelConfig";
        public const string HandleConsumConfig = "HandleConsumConfig";
        public const string HandlePaidConfig = "HandlePaidConfig";
        public const string MergeItemConfig = "MergeItemConfig";
        public const string MergeMapConfig = "MergeMapConfig";
        public const string MergeRegionRewardsConfig = "MergeRegionRewardsConfig";
        public const string MergeOrderDegreeConfig = "MergeOrderDegreeConfig";
        public const string MergeOrderListConfig = "MergeOrderListConfig";
        public const string MergeBuildConfig = "MergeBuildConfig";
        public const string MergeLevelBoxConfig = "MergeLevelBoxConfig";
        public const string MergeShopConfig = "MergeShopConfig";
        public const string MergeHotAirBallConfig = "MergeHotAirBallConfig";
        public const string MergeItemNpcConfig = "MergeItemNpcConfig";
        public const string MergeIllustratedConfig = "MergeIllustratedConfig";
        public const string EnergyConfig = "EnergyConfig";



        //用户数据
        public const string GameData = "GameData";
        public const string DataVersion = "DataVersion";
        public const string UserInfoData = "UserInfoData";
        public const string OpenId = "OpenId";
        public const string DeviceId = "DeviceId";
        public const string UserId = "UserId";
        public const string UserName = "UserName";
        public const string UserAvatar = "UserAvatar";
        public const string UserProvince = "UserProvince";
        public const string GameVersion = "GameVersion";
        public const string CameraRecord = "CameraRecord";
        public const string DataUpdateTime = "DataUpdateTime";
        public const string UserInfoRegisterTime = "UserInfoRegisterTime";
        public const string UserSignDay = "SignDay";
        public const string UserLastSignTime = "LastSignTime";
        public const string LastQuitTime = "LastQuitTime";
        public const string GetGoldTime = "GetGoldTime";
        public const string CardBackId = "CardBackId";
        public const string MaxLevel = "MaxLevel";
        public const string MaxLevelTime = "MaxLevelTime";
        public const string NextBuildId = "NextBuildId";
        public const string WheelRequestIndex = "WheelRequestIndex";
        public const string StageLevel = "StageLevel";
        public const string PropDic = "PropDic";
        public const string TimePropStartDic = "TimePropStartDic";
        // public const string BuildSelectDic = "BuildSelectDic";
        public const string PowerItemUnlockDic = "PowerItemUnlockDic";
        public const string TodayWatchShopAdTime = "TodayWatchShopAdTime";
        public const string CollectFlowerSuccessive = "CollectFlowerSuccessive";
        public const string TodayWatchWheelAdTime = "TodayWatchWheelAdTime";
        public const string TodayBrokenReceiveTime = "TodayBrokenReceiveTime";
        public const string SelectLanguage = "SelectLanguage";
        public const string InterAdInterval = "InterAdInterval";
        public const string LevelExperienceValue = "LevelExperienceValue";
        public const string CumulativeRechargeAmount = "CumulativeRechargeAmount";
        public const string CumulativeRechargeCount = "CumulativeRechargeCount";

        public const string FirstChargeUiOpenLv = "FirstChargeUiOpenLv";
        public const string IsFirstUseBetDic = "IsFirstUseBetDic";
        public const string SpecialCardDic = "SpecialCardDic";
        public const string DailyFlagDic = "DailyFlagDic";
        public const string WaitAddPropDic = "WaitAddPropDic";
        public const string BuyFlagDic = "BuyFlagDic";
        public const string FirstPopupDic = "FirstPopupDic";
        public const string OpenBetLevel = "OpenBetLevel";
        public const string LastShowBetLevel = "LastShowBetLevel";
        public const string NowBet = "NowBet";
        public const string FailSameLevelTimes = "FailSameLevelTimes";
        public const string SuccessiveVictory = "SuccessiveVictory";
        public const string FlowerStageStar = "StageStar"; //abandon on 0.2.0 version
        public const string WheelStar = "WheelStar"; //abandon on 0.2.0 version
        public const string TodayLevelPassTimes = "TodayLevelPassTimes";
        public const string LastRefreshTime = "LastRefreshTime";
        public const string TodayLaunchTimes = "TodayLaunchTimes";
        public const string FarmingProgress = "FarmingProgress";
        public const string IsFinishBattle = "IsFinishBattle";
        public const string DailyWinUseTime = "DailyWinUseTime";
        public const string VipBuyType = "VipBuyType";
        public const string VipIsProbation = "VipIsProbation";
        public const string VipEndTime = "VipEndTime";
        public const string VipLastRewardTime = "VipLastRewardTime";
        public const string LastCoinAdTime = "LastCoinAdTime";
        public const string LastFreeCoinAdTime = "LastFreeCoinAdTime";
        public const string FreeCoinAdCount = "FreeCoinAdCount";
        public const string FreeItemAdCount = "FreeItemAdCount";
        public const string FreeItemAdValue = "FreeItemAdValue";
        public const string HandlePaidData = "HandlePaidData";
        public const string LastChargeTime = "LastChargeTime";
        public const string TodayChargeTimes = "TodayChargeTimes";
        public const string TodayChargeMoney = "TodayChargeMoney";
        public const string AllChargeMoney = "AllChargeMoney";
        public const string NoTodayChargeTime = "NoTodayChargeTime";
        public const string OrderList = "OrderList";
        public const string MergeItemData = "MergeItemData";
        public const string UnlockCloudData = "UnlockCloudData";
        public const string UnlockGridData = "UnlockGridData";
        public const string GridExpData = "GridExpData";
        public const string MergeBubbleData = "MergeBubbleData";
        public const string MergeOrderData = "MergeOrderData";
        public const string MergeRegionData = "MergeRegionData";
        public const string MergeLevelBoxData = "MergeLevelBoxData";
        public const string MergeLevelBoxIndex = "MergeLevelBoxIndex";
        public const string MergeRegionUnlockBoxOrder = "MergeRegionUnlockBoxOrder";
        public const string MergeTodayOrderExp = "MergeTodayOrderExp";
        public const string MergeOrderExpDate = "MergeOrderExpDate";
        public const string MergeHotAirBallData = "MergeHotAirBallData";
        public const string MergeShopData = "MergeShopData";
        public const string MergeItemStateData = "MergeItemStateData";
        public const string EnergySaveData = "EnergySaveData";
        public const string RookieStatus = "RookieStatus";
        public const string OldDataVersionFlag = "OldDataVersionFlag";




        //本机数据
        public const string MusicMute = "MusicMute";
        public const string SoundMute = "SoundMute";
        public const string UserType = "UserType"; // 用户类型,独立于用户(0:匿名用户, 1:Facebook用户)
        public const string FbAccount = "FbAccount"; // fb 账号
        public const string InstallUid = "InstallUid"; // 安装时的Uid(对应firebase匿名Id)
        public const string IsBuyBeginner = "IsBuyBeginner";
        public const string IsBuyHeartBeatGift = "IsBuyHeartBeatGift";
        public const string IsSmallBuyBeginner = "IsSmallBuyBeginner";

        public const string IsCurWheelFinish = "IsCurWheelFinish";//当前轮盘是否完成
        public const string BeginnerGiftEndTime = "BeginnerGiftEndTime";
        public const string NowTriggerGiftProductID = "NowTriggerGiftProductID";
        public const string NowTriggerGiftEndTime = "NowTriggerGiftEndTime";
        public const string AfkRewardGetTime = "AfkRewardGetTime";
        public const string AfkRewardGetCount = "AfkRewardGetCount";
        public const string IsBeginnerShow = "IsBeginnerShow";
        public const string RookieTipFlag = "RookieTipFlag";
        public const string InstallVersion = "InstallVersion";
        public const string CurrentVersion = "CurrentVersion";
        public const string TodayNotificationCount = "TodayNotificationCount";

        // 活动数据
        public const string ActivitySaveData = "ActivitySaveData";
        // 竞标赛活动数据
        public const string PassRankProgress = "PassRankProgress";
        //鲜花赶集活动（关卡内收集活动）数据
        public const string CollectFlowerProgress = "CollectFlowerProgress";
        //爱心方块牌收集活动（爬塔活动连续通关）数据数据
        public const string CollectLoveCardProgress = "CollectLoveCardProgress";
    }

    public struct ValueConfigKey
    {
        public const string OriginalItem = "OriginalItem";
        public const string CoinFlyCountList = "CoinFlyCountList";
        public const string WheelOpenInterval = "WheelOpenInterval";
        public const string WheelOpenLevel = "WheelOpenLevel";
        public const string CoinRewardVideoValue = "CoinRewardVideoValue";
        public const string CoinRewardVideoDailyTimes = "CoinRewardVideoDailyTimes";
        public const string BrokenCoinNum = "BrokenCoinNum";
        public const string InterAdOpenlv = "InterAdOpenlv";
        public const string InterAdCooldown = "InterAdCooldown";
        public const string InterAdCooldownPayinguser = "InterAdCooldownPayinguser";
        public const string FailSameLevelShowRookie = "FailSameLevelShowRookie";
        public const string BuyCardGuar = "BuyCardGuar";
        public const string LevelCardCoinDistribute = "LevelCardCoinDistribute";

        public const string SaverAfterfullPopInterval = "SaverAfterfullPopInterval";
        public const string SaverRewardConstant = "SaverRawardConstant";
        public const string SaverInitial = "SaverInitial";
        public const string SaverBankMin = "SaverBankMin";
        public const string SaverBankMax = "SaverBankMax";
        public const string SaverWarning = "SaverWarning";
        public const string FirstChargeOpenInterval = "FirstChargeOpenInterval";
        public const string TriggerGiftTimeInterval = "TriggerGiftTimeInterval";
        public const string TriggerGiftCoinNum = "TriggerGiftCoinNum";
        public const string CollectFlowerOpenLv = "CollectFlowerOpenLv";
        public const string CollectLoveCardOpenLv = "CollectLoveCardOpenLv";
        public const string WinningStreakOpenTime = "WinningStreakOpenTime";
        public const string RandomCupFactor = "RandomCupFactor";
        public const string PassRankOpenLv = "PassRankOpenLv";
        public const string PerIsPlay = "PerIsPlay";
        public const string RandomPlayCount = "RandomPlayCount";
        public const string PassRankOpenTime = "PassRankOpenTime";
        public const string FinalTimeRank = "FinalTimeRank";
        public const string WinstreakRemainFactor = "WinstreakRemainFactor";
        public const string WildComboRemainFactor = "WildComboRemainFactor";
        public const string WildFreeRemainFactor = "WildFreeRemainFactor";
        public const string WildBuyRemainFactor = "WildBuyRemainFactor";

        public const string UpdateTipsOpenLv = "UpdateTipsOpenLv";

        public const string StageStar = "StageStar"; //abandon on 0.2.0 version
        public const string WheelStar = "WheelStar"; //abandon on 0.2.0 version
        public const string MessageLimit = "MessageLimit";
        public const string ReturnReward = "ReturnReward";
        public const string GetCupCount = "GetCupCount";
        public const string RankRule = "RankRule";
        public const string CollectRule = "CollectRule";
        public const string GetPassRankReward = "GetPassRankReward";
        public const string ReturnTime = "ReturnTime";
        public const string DailyWinTimes = "DailyWinTimes";


        //本机数据
        public const string MusicMute = "MusicMute";
        public const string SoundMute = "SoundMute";
        public const string IsBuyBeginner = "IsBuyBeginner";
        public const string RookieTipFlag = "RookieTipFlag";
        public const string IsFinishSaver = "IsFinishSaver";//added
        public const string IsCountDownEnd = "IsCountDownEnd";//added

        public const string InstallVersion = "InstallVersion";
        public const string CurrentVersion = "CurrentVersion";
        public const string FirstLanguage = "FirstLanguage";
        public const string Vibrate = "Vibrate";
        public const string Mp3Delay = "Mp3Delay";
        public const string LastPlaySongId = "LastPlaySongId";
        public const string GameQuality = "GameQuality";
        public const string KeyTypeGuideFlag = "KeyTypeGuideFlag";
        public const string RechargeGuide = "RechargeGuide";
        public const string NotificationAuth = "NotificationAuth";
        public const string GiveScore = "GiveScore"; //用户是否给游戏评星
        public const string VipButtonPosition = "VipButtonPosition";
        public const string EyuFirstOpen = "EyuFirstOpen";
        public const string EyuStartAppTimes = "EyuStartAppTimes";
        public const string EyuFirstWin = "EyuFirstWin";
        public const string EyuFirstLose = "EyuFirstLose";
        public const string ClickAdPlayFlag = "ClickAdPlayFlag";
        public const string TodayBattleTimes = "TodayBattleTimes";
        public const string QuestionCard = "QuestionCard";
    }

    public struct DoozyEvent
    {
        public const string Loaded = "Loaded";
        public const string EnterRookie = "EnterRookie";
        public const string GoHome = "GoHome";
        public const string GameResult = "GameResult";
        public const string StartGame = "StartGame";
        public const string GameEnd = "GameEnd";
        public const string NextGame = "NextGame";
    }

    public struct DoozyView
    {
        public const string Game = "Game";
        public const string FxMask = "FxMask";
        public const string Gold = "Gold";
        public const string Home = "Home";
        public const string Language = "Language";
        public const string Result = "Result";
        public const string Saver = "Saver";
        public const string Star = "Star";
        public const string Dialogue = "Dialogue";
        public const string Rookie = "Rookie";

        public const string WheelPopup = "WheelPopup";
        public const string MysteriousSeedPopup = "MysteriousSeedPopup";
        public const string SettingPopup = "SettingPopup";
        public const string CheckInPopup = "CheckInPopup";
        public const string FirstChargePopup = "FirstChargePopup";
        public const string SubscribeChargePopup = "SubscribeChargePopup";
        public const string HeartBeatGift = "HeartBeatGift";
        public const string EmailPopup = "EmailPopup";
        public const string HomeMapPopup = "HomeMapPopup";
        public const string GradientGiftPopup = "GradientGiftPopup";
        public const string GiftGradientDigPopup = "GiftGradientDigPopup";
        public const string GiftGradientCookPopup = "GiftGradientCookPopup";
        public const string BankruptcyGiftPopup = "BankruptcyGiftPopup";
        public const string FailGameGiftPopup = "FailGameGiftPopup";
        public const string FlowerPopup = "FlowerPopup";
        public const string BrokenPopup = "BrokenPopup";
        public const string BoxPopup = "BoxPopup";
        public const string LoadingPopup = "LoadingPopup";
        public const string RewardPopup = "RewardPopup";
        public const string SingleRewardPopup = "SingleRewardPopup";
        public const string ShopPopup = "ShopPopup";
        public const string SceneChangePopup = "SceneChangePopup";
        public const string LavaPassRewardPopup = "LavaPassRewardPopup";
        public const string GMPop = "GMPop";
        public const string UnlockLimitPkPopup = "UnlockLimitPkPopup";
        public const string EndWinStreakPopup = "EndWinStreakPopup";
        public const string ExitGameTipPopup = "ExitGameTipPopup";
        public const string SolatiumPopup = "SolatiumPopup";
        public const string StartGamePopup = "StartGamePopup";
        public const string GiftDragOnePopup = "GiftDragOnePopup";
        public const string GiftPlusOnePopup = "GiftPlusOnePopup";
        public const string GiftDiscountPopup = "GiftDiscountPopup";
        public const string GiftPlusFourPopup = "GiftPlusFourPopup";
        public const string GiftDragTwoPopup = "GiftDragTwoPopup";
        public const string GiftDragSixPopup = "GiftDragSixPopup";
        public const string ExitGamePopup = "ExitGamePopup";
        public const string GiftBuyItemPopup = "GiftBuyItemPopup";
        public const string SeasonPassPopup = "SeasonPassPopup";
        public const string DailyAdRewardPopup = "DailyAdRewardPopup";
        public const string StartSeassPassPopup = "StartSeassPassPopup";
        public const string SaverPopup = "SaverPopup";
        public const string StartLimitPkPopup = "StartLimitPkPopup";
        public const string LevelPassPopup = "LevelPassPopup";
        public const string LavaPassPopup = "LavaPassPopup";
        public const string StartLavaPass = "StartLavaPass";
        public const string UnlockLavaPass = "UnlockLavaPass";
        public const string StartLevelPassPopup = "StartLevelPassPopup";
        public const string StartCollectFlowerPopup = "StartCollectFlowerPopup";
        public const string StartMysteriousSeedPopup = "StartMysteriousSeedPopup";
        public const string StartEndlessLevelPopup = "StartEndlessLevelPopup";
        public const string EndlessLevelRankPopup = "EndlessLevelRankPopup";
        public const string StartCollectLoveCardPopup = "StartCollectLoveCardPopup";
        public const string StartPassRankPopup = "StartPassRankPopup";
        public const string StartCarRankPopup = "StartCarRankPopup";
        public const string RabbitGiftPopup = "RabbitGiftPopup";
        public const string SpecialCardTipPopup = "SpecialCardTipPopup";
        public const string GameResultPopup = "GameResultPopup";
        public const string StreakTipPopup = "StreakTipPopup";
        public const string PassRankPopup = "PassRankPopup";
        public const string CarRankPopup = "CarRankPopup";
        public const string CollectFlowerPopup = "CollectFlowerPopup";
        public const string CollectLoveCardPopup = "CollectLoveCardPopup";
        public const string CollectMusicPopup = "CollectMusicPopup";
        public const string CookMealPopup = "CookMealPopup";
        public const string CollectWaterPopup = "CollectWaterPopup";
        public const string CollectHoneyPopup = "CollectHoneyPopup";
        public const string PopCollectRewardPopup = "PopCollectRewardPopup";
        public const string DigTreasurePopup = "DigTreasurePopup";
        public const string PopRewardPopup = "PopRewardPopup";
        public const string BuyItemPopup = "BuyItemPopup";
        public const string BuyMergeItemPopup = "BuyMergeItemPopup";
        public const string DataSyncPopup = "DataSyncPopup";
        public const string DataSyncConfirmPopup = "DataSyncConfirmPopup";
        public const string SignInSuccessPopup = "SignInSuccessPopup";
        public const string SignOutConfirmPopup = "SignOutConfirmPopup";
        public const string SignOutSuccessPopup = "SignOutSuccessPopup";
        public const string UpdateTipPopView = "UpdateTipPopView";
        public const string CommonLoadingPopup = "CommonLoadingPopup";
        public const string ActivitySeasonPopup = "ActivitySeasonPopup";
        public const string UnlockBetPopup = "UnlockBetPopup";
        public const string UnlockStartGamePopup = "UnlockStartGamePopup";
        public const string UnlockCollectWaterPopup = "UnlockCollectWaterPopup";
        public const string UnlockCollectHoneyPopup = "UnlockCollectHoneyPopup";
        public const string UnlocklevelPassPopup = "UnlocklevelPassPopup";
        public const string UnlockWinStreakPopup = "UnlockWinStreakPopup";
        public const string UnlockSeasonPassPopup = "UnlockSeasonPassPopup";
        public const string UnlockCollectFlowerPopup = "UnlockCollectFlowerPopup";
        public const string UnlockCollectLoveCardPopup = "UnlockCollectLoveCardPopup";
        public const string UnlockPassRankPopup = "UnlockPassRankPopup";
        public const string UnlockCarRankPopup = "UnlockCarRankPopup";
        public const string UnlockRabbitPopup = "UnlockRabbitPopup";
        public const string UnlockEndlessLevelPopup = "UnlockEndlessLevelPopup";
        public const string UnlockDigTreasurePopup = "UnlockDigTreasurePopup";
        public const string UnlockMysteriousSeedPopup = "UnlockMysteriousSeedPopup";
        public const string UnlockCookMealPopup = "UnlockCookMealPopup";
        public const string FirstTimeSaverPopup = "FirstTimeSaverPopup";
        public const string FirstTimeSeasonPopup = "FirstTimeSeasonPopup";
        public const string SeasonDescPopup = "SeasonDescPopup";
        public const string SeasonPurchasePopup = "SeasonPurchasePopup";
        public const string SeasonRewardGetPopup = "SeasonRewardGetPopup";
        public const string UnlockNewFeaturePopup = "UnlockNewFeaturePopup";
        public const string HarvestPopup = "HarvestPopup";
        public const string VipPopup = "VipPopup";
        public const string VictoryPopup = "VictoryPopup";
        public const string VipRewardPopup = "VipRewardPopup";
        public const string TriggerGiftPopup = "TriggerGiftPopup";
        public const string LevelRankingPopup = "LevelRankingPopup";
        public const string RegionRewardsPopup = "RegionRewardsPopup";
        public const string MergeOrderPopup = "MergeOrderPopup";
        public const string MergeOrderBoughtPopup = "MergeOrderBoughtPopup";
        public const string MergeUnlockGridPopup = "MergeUnlockGridPopup";
        public const string CoinAdPopup = "CoinAdPopup";
        public const string IllustratedGuidePopup = "IllustratedGuidePopup";
        public const string EnergyPopup = "EnergyPopup";
        public const string BoxLessPopup = "BoxLessPopup";
        public const string DeleteMergeItemPopup = "DeleteMergeItemPopup";
        public const string InstructionsPurifyPopup = "InstructionsPurifyPopup";
        public const string InstructionsRewardPopup = "InstructionsRewardPopup";
        public const string HotAirBallPopup = "HotAirBallPopup";
        public const string MergeVersionRewardPopup = "MergeVersionRewardPopup";
        

    }
}