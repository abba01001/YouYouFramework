public enum ActivityType
{
    none,
    piggy, // 存钱罐
    collectFlower,//收集鲜花
    digTreasure,//挖宝
    collectMusic,//收集乐谱
    collectLoveCard,//收集爱心方块卡牌活动
    passRank,//奖杯竞标赛活动（通关排行榜）
    carRank,//赛车竞标赛活动（通关排行榜）
    winStreak,//连胜活动
    levelPass,//10关挑战
    lavaPass,//熔岩连胜
    wheel,//转盘
    seasonPass,//赛季通行证
    farmingCollect,//农场收获
    limitPk,//拳击赛
    gradientGift,//梯度巅峰礼包
    giftGradientDig,//挖宝梯度礼包
    giftGradientCook,//做饭梯度礼包
    adReward,//每日广告
    endlessLevel,//无尽关卡
    rabbitGift,//兔子连胜
    collectWater,//收集水滴
    collectHoney,//收集蜂蜜
    mysteriousSeed,//神秘种子
    cookMeal,//做饭
    giftDragOne,//1拖1礼包
    giftDragTwo,//1拖2礼包
    giftDragSix,//1拖6礼包
    giftPlusOne,//1+1礼包
    giftPlusFour,//1+4礼包
    giftDiscount,//特惠礼包
    
    
    
    coin,
    buildCoin,
}

//标记存储
public enum FlagType
{
    BankruptcyPack_1,
    BankruptcyPack_2,
    BankruptcyPack_3,
    BankruptcyPack_4,
    SmallBankruptcyPack_1,
    SmallBankruptcyPack_2,
    SmallBankruptcyPack_3,
    SmallBankruptcyPack_4,
    PushGift1,
    PushGift2,
    PushGift3,
    PushGift4,
    PushGift5,
    PushGift6,
    PushGift7,
    PushGift8,
    PushGift9,
    PushGift10,
    PushGift11,
    PushGift12,
    PushGift13,
    PushGift14,
    ShowHeartBeatGift,
    Month,
    Week,
    FirstCharge,
    SmallFirstCharge,
    HeartBeatGift,
    SignIn,
    FinalAdReward,
    DailyBuy,
    WeekBuy,
    MonthBuy,
}

public enum ActivityLoopType
{
    none,
    onlyOnce,
    weekdayDuration,
    hourDuration
}

/// <summary>
/// 活动状态
/// </summary>
public enum ActivityState
{
    waitOpen,//等待开放
    waitEntry, //等待玩家参与活动
    underWay, //玩家参与活动中
    waitFinished, //活动等待结束
    finished,//活动结束
}

//礼包类型
public enum GiftType
{
    BrokenGift,
    FailGift,
    
}

public enum CardType
{
    Value = 1,
    Joker,
    Boom,
    Zap,
    Lock,
    Key,
    Three,
    Anchor,
    Banana,
    Monkey,
    Windmill,
    Gold,
    Monochrome,
    TwoValue,
    Copy,
    Question,
    Rudder,
    Cannon

}

public enum ModifierType
{
    None = 0,
    Bomb = 1,
    Rising,
    Lowering,
    Water,
    Ice,
    Lightning,
    GreenLeaf,
    Cloth,
    MagicCloth,
    SuitRope,
    Coin,
    BigBomb,
    LinkRope,
    Lizard,
    Task
}

public enum MealType
{
    None = 0,
    StewedPork = 1,//红烧肉
    TomatoEgg = 2,//番茄炒蛋
    SoupDumpling = 3,//灌汤包
    BakedLobster = 4,//焗龙虾
    Salad = 5,//沙拉
}

public enum MealMaterialType
{
    None = 0,
    Tomato = 1,//番茄
    Carrot = 2,//胡萝卜
    Vegetable = 3,//蔬菜
    Cucumber = 4,//青瓜
    Egg = 5,//鸡蛋
    Garlic = 6,//大蒜
    Ketchup = 7,//番茄酱
    Potato = 8,//土豆
    Pork = 9,//猪肉
    Wheat = 10,//小麦
    Seasoning = 11,//调味料
    Lemon = 12,//柠檬
    Shrimp = 13,//虾
    Cheese = 14,//芝士
    Coin = 15,
    Pine = 16,
}

public enum MergeItemState
{
    None = 0,//未获得
    CanReward = 1,//可领奖
    HasReward = 2,//已领奖
}