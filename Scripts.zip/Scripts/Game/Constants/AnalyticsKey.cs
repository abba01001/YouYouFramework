
static class AnalyticsKey
{
    //事件
    public const string SoliFirstOpen = "SoliFirstOpen";
    public const string SoliLaunchGame = "SoliLaunchGame";
    public const string SoliEnterGame = "SoliEnterGame";
    public const string SoliShowView = "SoliShowView";
    public const string SoliHideView = "SoliHideView";
    public const string SoliBattleStart = "SoliBattleStart";
    public const string SoliBattleEnd = "SoliBattleEnd";
    public const string SoliPurchaseSuccess = "SoliPurchaseSuccess";
    public const string SoliPropertyChange = "SoliPropertyChange";
    public const string SoliClickPurchase = "SoliClickPurchase";
    public const string SoliBuild = "SoliBuild";
    public const string SoliFinishMap = "SoliFinishMap";
    public const string SoliUnlockBet = "SoliUnlockBet";
    public const string SoliBattlePassBuy = "SoliBattlePassBuy";
    public const string SoliBattlePassExp = "SoliBattlePassExp";
    public const string SoliBattlePassLevelUp = "SoliBattlePassLevelUp";
    public const string SoliBattlePassEnd = "SoliBattlePassEnd";
    public const string SoliPiggyFill = "SoliPiggyFill";
    public const string SoliPowerupDurationAppEnd = "SoliPowerupDurationAppEnd";
    public const string SoliPowerupLimitlessTimeAdd = "SoliPowerupLimitlessTimeAdd";
    public const string SoliPowerupLimitlessTimeEnd = "SoliPowerupLimitlessTimeEnd";
    public const string SoliNoHandCardInGame = "SoliNoHandCardInGame";
    public const string SoliAdClick = "SoliAdClick";
    public const string SoliAdShow = "SoliAdShow";
    public const string SoliNotification = "SoliNotification";
    public const string SoliSubscribeTrial = "SoliSubscribeTrial";
    public const string SoliSubscribeStart = "SoliSubscribeStart";
    public const string SoliSubscribeCancel = "SoliSubscribeCancel";
    public const string SoliSubscribeEnd = "SoliSubscribeEnd";
    public const string SoliRequestOrder = "SoliRequestOrder";
    public const string SoliRequestPay = "SoliRequestPay";
    public const string SoliPaySuccess = "SoliPaySuccess";
    public const string SoliCreateRoleEx = "SoliCreateRoleEx";
    public const string SoliCreateRole = "SoliCreateRole";

    //属性
    public const string FirstRegisterTime = "first_register_time"; //首次注册时间
    public const string FirstPayTime = "first_pay_time"; //首次付费时间
    public const string FirstCallPayLevel = "first_call_pay_level"; //首次付费关卡
    public const string LastLoginTime = "last_login_time"; //最后登录时间
    public const string LastPayTime = "last_pay_time"; //最后付费时间
    public const string TotalPayAmount = "total_pay_amount"; //累计付费金额
    public const string TotalPayCount = "total_pay_cnt"; //计付费次数
    
    
    


    public const string ViewName = "view_name"; //页面名字
    // public const string StageJson = "stage_json"; //关卡配置文件
    public const string LoginTimes = "login_times"; //累计登录次数
    public const string BattleTimes = "battle_times"; //累计战斗次数
    public const string LatestLevel = "latest_level"; //当前关卡
    //public const string LatestStars = "latest_stars"; //总星星数
    public const string LatestStars = "stars"; //星星数
    public const string StageType = "stage_type"; //关卡类型，1主线
    public const string StageId = "stage_id"; //关卡ID
    public const string MaxLevel = "level"; //最高关卡
    public const string PurchaseUsdMoney = "purchase_money_convert2usd"; //终身花费

    public const string IsEndlessLevel = "is_endless_level";//是否是无尽关卡
    public const string WinstreakLevel = "winstreak_level"; //连胜加成等级
    public const string WinstreakTimes = "winstreak_times"; //连胜次数
    public const string StageStartDefaultCost = "stage_start_default_cost"; //关卡配置消耗金币
    public const string StageStartCostType = "stage_start_cost_type"; //关卡开始消耗品类型
    public const string StageStartCostValue = "stage_start_cost_value"; //关卡开始消耗金币数量
    public const string StageStartCostTicketValue = "stage_start_cost_ticket"; //关卡开始消耗免费票数量

    public const string StagePowerupDelthreeUse = "powerup_delthree_use"; //强化道具开局消3张牌(用传1，不用传0)
    public const string StagePowerupWildUse = "powerup_wild_use"; //强化道具开局加2张万能(用传1，不用传0)
    public const string StagePowerupCactusUse = "powerup_cactus_use"; //强化道具开局加2张仙人掌(用传1，不用传0)
    public const string StagePowerupWindmillUse = "powerup_windmill_use"; //强化道具开局加2张风车牌(用传1，不用传0)
    public const string StagePowerupDelthreeLimitless = "powerup_delthree_limitless"; //限时强化开局消3张牌(有传1，没有传0)
    public const string StagePowerupWildLimitless = "powerup_wild_limitless"; //限时强化开局加2张万能(有传1，没有传0)
    public const string StagePowerupCactusLimitless = "powerup_cactus_limitless"; //限时强化开局加2张仙人掌(有传1，没有传0)
    public const string StagePowerupWindmillLimitless = "powerup_windmill_limitless"; //限时强化开局加2张风车牌(有传1，没有传0)

    public const string StageEndReason = "stage_end_reason"; //关卡结束原因 1胜利 2失败 3退出
    public const string StageEndAddcoinMatch = "stage_end_addcoin_match"; //消除桌面牌获得的金币
    public const string StageEndAddcoinComboreward = "stage_end_addcoin_comboreward"; //达成连击奖励获得的金币
    public const string StageEndOnecolorComborewardTime = "stage_end_comboreward_onecolor_times"; //触发同色连击奖励次数
    public const string StageEndJokerComborewardTime = "stage_end_item_joker_from_combo"; //达成连击奖励获得的万能数量
    public const string StageEndGetStar = "stage_end_star"; //通关星星获得数量
    public const string StageEndAddCoin = "stage_end_addcoin_win"; //通关获得的金币
    public const string StageEndComboMax = "stage_end_combo_max"; //最大连击次数
    public const string StageEndComborewardTimes = "stage_end_comboreward_times"; //获得n连击奖励的次数
    public const string StageEndItemUndoTimes = "stage_end_item_undo_times"; //本关卡使用回退的次数，包括免费和购买的
    public const string StageEndItemFillTimes = "stage_end_item_fill_times"; //本关卡使用补牌的次数，包括免费和购买的
    public const string StageEndItemJokerTimes = "stage_end_item_joker_times"; //本关卡使用万能的次数，包括免费和购买的
    public const string StageEndRemaincardsDesk = "stage_end_remaincards_desk"; //关卡结束时，桌面牌剩余数量
    public const string StageEndRemaincardsHand = "stage_end_remaincards_hand"; //关卡结束时，手牌剩余数量
    public const string StageEndAddCoinTotal = "stage_end_addcoin_total"; //本局内总获得金币（连击+连击奖励+手牌剩余+结算）
    public const string StageEndUseCoinTotal = "stage_end_usecoin_total"; //本局内总消耗金币（入场费+购买回退+万能+加五）

    public const string PurchaseSku = "purchase_sku"; //内购产品id
    public const string PurchaseCurrencyCode = "purchase_currency_code"; //内购产品货币码
    public const string PurchasePriceString = "purchase_price_str"; //内购产品价格字符串
    public const string PurchaseLocalPrice = "purchase_local_price"; //内购产品本地价格
    public const string PurchaseValueUsd = "purchase_price_convert2usd"; //内购产品配置美金价格
    public const string PurchaseScene = "purchase_scene"; //付费场景  home / game
    public const string PurchaseCurrentStage = "current_stage"; //付费前--当前关卡
    public const string PurchaseCurrentCoin = "current_coin"; //付费前--当前金币
    public const string PurchaseCurrentWild = "current_wild"; //付费前--当前万能
    public const string PurchaseCurrentUndo = "current_undo"; //付费前--当前回退
    public const string PurchaseCurrentFill = "current_fill"; //付费前--当前买牌
    public const string PurchaseCurrentPowerupDelthree = "current_powerup_delthree"; //付费前--当前强化道具消牌
    public const string PurchaseCurrentPowerupWild = "current_powerup_wild"; //付费前--当前强化道具万能牌
    public const string PurchaseCurrentPowerupCactus = "current_powerup_cactus"; //付费前--当前强化道具仙人掌牌
    public const string PurchaseTime = "purchase_times"; //此次是第几次付费

    public const string TrialDays = "trial_days"; //整型，试用持续的天数，如试用3天传3
    public const string TrialStartTime = "trial_start_time"; //时间戳，试用开始的时间点
    public const string TrialEndTime = "trial_end_time"; //时间戳，试用结束的时间点
    public const string SubscribeDays = "subscribe_days"; //整型，这次订阅的持续时长，如按月订阅31天传31
    public const string SubscribeStartTime = "subscribe_start_time"; //时间戳，订阅开始的时间点
    public const string SubscribeEndTime = "subscribe_end_time"; //时间戳，订阅开始的时间点
    public const string SubscribeTimes = "subscribe_times"; //整型，该玩家终身第x次订阅，第1次传1
    public const string SubscribeDuaration = "subscribe_duaration"; //整型，该玩家终身第x次订阅，第1次传1

    public const string PropChannel = "change_channel"; //货币道具变化途径
    public const string PropType = "property_type"; //货币道具类型
    public const string MultiplyFactor = "multiply_factor"; //加倍情况
    public const string MultiplyUnlockType = "unlock_type"; //加倍解锁方式
    public const string MultiplyUnlockCurrentStage = "current_stage"; //加倍解锁此时最新关卡
    public const string MultiplyUnlockCurrentCoin = "current_coin"; //加倍解锁此时金币
    public const string PropChangeType = "property_change_type"; //货币道具+-
    public const string PropValue = "property_value"; //货币道具变化值
    public const string PropValueBefore = "property_value_before"; //货币道具变化前的值
    public const string AdPlaceId = "placeid"; //广告位
    public const string AdRevenueUnitId = "ad_revenue_unitid"; //广告key
    public const string AdRevenueValue = "ad_revenue_value"; //广告价值
    public const string BattleSingleTime = "duration_battle"; //游戏单局时长
    public const string AppFullLifeTime = "duration_life"; //游戏终生时长
    public const string BuildMap = "map"; //建造地图
    public const string BuildLocation = "location"; //建造时建造位置
    public const string BuildChoice = "choice"; //建造时所选选项
    public const string BuildCost = "cost"; //建造消耗

    public const string NoHandCardTimes = "no_handcard_times"; //本场战斗第x次触发无手牌 
    public const string CurrentFreeBuyCard = "current_free_fill"; //当前免费加五 
    public const string CurrentFreeUndo = "current_free_undo"; //当前免费回退
    public const string CurrentFreeWild = "current_free_wild"; //当前免费万能
    public const string CurrentDeskCards = "current_desk_cards"; //桌面剩余牌数
    public const string BattleDuration = "bat_duration"; //战斗时长
    public const string Coin = "coin";
    public const string LevelJson = "lvjson";
    
    //存钱罐
    public const string PiggyAdd = "add"; //本次增加金币
    public const string PiggyTotal = "total"; //总金币数量
    public const string PiggyIsfull = "isfull"; //获得金币后是否填满

    //强化道具
    public const string PowerupType = "powerup_type"; //强化道具道具类型
    public const string PowerupTimeAdd = "powerup_time_add"; //获得的时长
    public const string PowerupTimeAfterAdd = "powerup_time_after_add"; //获得后的总时长
    public const string PowerupTimestampStart = "powerup_timestamp_start"; //更新后的开始时间戳
    public const string PowerupTimestampEnd = "powerup_timestamp_end"; //更新后的结束时间戳
    public const string PowerupTimeTotal = "powerup_time_total"; //本次时限型道具总时长
    public const string PowerupDuation = "powerup_duation"; //强化道具覆盖的在线时长
    public const string PowerupDelthreeDuation = "powerup_delthree_duation"; //消除3张覆盖的在线时长
    public const string PowerupWildDuation = "powerup_wild_duation"; //万能覆盖的在线时长
    public const string PowerupCactusDuation = "powerup_cactus_duation"; //仙人掌覆盖的在线时长

    // BattlePass
    public const string PayId = "pay_id"; // 购买id
    public const string CurrentStage = "current_stage"; // 当前关卡
    public const string CurrentCoin = "current_coin"; // 当前金币
    public const string BattlePassLevel = "battlepasslevel"; // 当前battlepass等级
    public const string Topup2UsdLife = "topup2usd_life"; // 购买时，充值金额

    public const string SeasonId = "season_id"; // 当前赛季id
    public const string Exp = "exp"; // 赛季增加经验值
    public const string DateDiffStart = "date_diff_start"; // 距离赛季开始的天数
    public const string IsPayBattlePass = "is_pay_battlepass"; // 是否充值了BattlePass
    public const string NotificationChannel = "channel";

    //活动
    public const string CollectFlower_Start = "CollectFlower_Start";
    public const string CollectFlower_Score = "CollectFlower_Score";
    public const string CollectFlower_End = "CollectFlower_End";
    public const string LevelPass_Start = "LevelPass_Start";
    public const string LevelPass_Score = "LevelPass_Score";
    public const string LevelPass_End = "LevelPass_End";
    public const string LimitPk_Start = "LimitPk_Start";
    public const string LimitPk_Score = "LimitPk_Score";
    public const string limitPk_End = "limitPk_End";
    public const string PassRank_Start = "PassRank_Start";
    public const string PassRank_Score = "PassRank_Score";
    public const string PassRank_End = "PassRank_End";
    public const string CarRank_Start = "CarRank_Start";
    public const string CarRank_Score = "CarRank_Score";
    public const string CarRank_End = "CarRank_End";
    public const string Lava_Start = "Lava_Start";
    public const string Lava_End = "Lava_End";
    public const string Endless_Start = "Endless_Start";
    public const string Endless_End = "Endless_End";
    public const string SeasonPass_Progress = "SeasonPass_Progress";
    public const string CollectLoveCard_Progress = "CollectLoveCard_Progress";
    public const string CollectMusic_Progress = "CollectMusic_Progress";
}
