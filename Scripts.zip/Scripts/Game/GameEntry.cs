using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.SceneManagement;

/// <summary>
/// 游戏入口 -- 热更桥接
/// </summary>
public static class GameEntry
{
    public static void Start()
    {
        Debug.Log("[GameEntry::Start] 热更完成进入游戏场景");
        //SceneManager.LoadScene("Scenes/MainScene");
        Addressables.LoadSceneAsync("Assets/Scenes/LauncherScene.unity");
    }
}
