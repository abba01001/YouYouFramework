using System.Collections.Generic;
using UnityEngine;

public class AIPanel : MonoBehaviour
{
    public GameObject LevelPanel;
    public GameObject GamePanel;
    public GameObject UnlimitPanel;
    public GameObject LevelResultPanel;
    public GameObject GameResultPanel;
    public GameObject UnlimitResultPanel;

    private void Start() 
    {
        LevelResultPanel.SetActive(false);
        GameResultPanel.SetActive(false);
        UnlimitResultPanel.SetActive(false);
        OnSimulatorTab(2);
    }

    public void OnSimulatorTab(int idx)
    {
        LevelPanel.SetActive(idx == 1);
        GamePanel.SetActive(idx == 2);
        UnlimitPanel.SetActive(idx == 3);
    }

    public void SetLevelData(List<ResultData> data)
    {
        LevelResultPanel.SetActive(true);
        LevelResultPanel.GetComponent<AILevelResultPanel>().SetResultData(data);
    }

    public void SetGameData(List<ResultData> data)
    {
        GameResultPanel.SetActive(true);
        GameResultPanel.GetComponent<AIGameResultPanel>().SetResultData(data);
    }
    
    public void SetUnlimitData(List<ResultData> data)
    {
        UnlimitResultPanel.SetActive(true);
        UnlimitResultPanel.GetComponent<AIUnlimitResultPanel>().SetResultData(data);
    }
}