using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// using XCharts;

public class AIUnlimitResultPanel : MonoBehaviour
{
    // public LineChart lineChart;
    // public ScatterChart scatterChart;
    public Toggle FirstToggle;
    public Toggle LastToggle;
    private List<ResultData> results;

    public void OnCloseBtn()
    {
        gameObject.SetActive(false);
    }

    public void SetResultData(List<ResultData> data)
    {
        results = data;
        FirstToggle.isOn = true;
        OnTab(1);

        LastToggle.gameObject.SetActive(true);
        var levelflag = -1;
        foreach(var d in results)
        {
            if(levelflag == -1)
                levelflag = d.gameData.Level;
            else
            {
                if(levelflag != d.gameData.Level)
                {
                    LastToggle.gameObject.SetActive(false);
                    break;
                }
            }
        }
    }

    public void OnTab(int idx)
    {
        // if(idx == 1)
        // {
        //     lineChart.gameObject.SetActive(true);
        //     scatterChart.gameObject.SetActive(false);
        //     ShowHandCards();
        // }
        // else if(idx == 2)
        // {
        //     lineChart.gameObject.SetActive(true);
        //     scatterChart.gameObject.SetActive(false);
        //     ShowComboTimes();
        // }
        // else if(idx == 3)
        // {
        //     lineChart.gameObject.SetActive(false);
        //     scatterChart.gameObject.SetActive(true);
        //     ShowHandCards2();
        // }
    }

    public void ShowHandCards()
    {
        // Dictionary<int, Tuple<int, int>> tarRate = new Dictionary<int, Tuple<int,int>>();
        // foreach(var d in results)
        // {
        //     var level = d.gameData.Level;
        //     var handCardsCount = d.useHandCardNum;
        //     if(tarRate.ContainsKey(d.gameData.Level))
        //     {
        //         var value = new Tuple<int, int>(tarRate[level].Item1 + 1,
        //             tarRate[level].Item2 + handCardsCount);
        //         tarRate[level] = value;
        //     }
        //     else
        //     {
        //         tarRate.Add(level, new Tuple<int, int>(1, handCardsCount));
        //     }
        // }

        // lineChart.RemoveData();
        // lineChart.AddSerie(SerieType.Line);
        // lineChart.title.text = "手牌使用数折线图";

        // var max = int.MinValue;
        // var min = int.MaxValue;
        // foreach(var d in tarRate)
        // {
        //     if(d.Key > max)
        //         max = d.Key;
        //     if(d.Key < min)
        //         min = d.Key;
        // }
        // for (int i = min; i <= max; i++)
        // {
        //     lineChart.AddXAxisData($"lv.{i}");
        // }

        // var res = new List<Tuple<int, float>>();
        // foreach(var d in tarRate)
        // {
        //     res.Add(new Tuple<int, float>(d.Key, d.Value.Item2/(float)(d.Value.Item1)));
        // }
        // foreach(var d in res)
        // {
        //     var data = new List<double>(){d.Item1, d.Item2};
        //     lineChart.AddData(0, data);
        // }
    }

    public void ShowComboTimes()
    {
        // Dictionary<int, Tuple<int, int>> tarRate = new Dictionary<int, Tuple<int,int>>();
        // foreach(var d in results)
        // {
        //     var level = d.gameData.Level;
        //     var comboTimes = d.gameCombo.FinishComboNum;
        //     if(tarRate.ContainsKey(d.gameData.Level))
        //     {
        //         var value = new Tuple<int, int>(tarRate[level].Item1 + 1,
        //             tarRate[level].Item2 + comboTimes);
        //         tarRate[level] = value;
        //     }
        //     else
        //     {
        //         tarRate.Add(level, new Tuple<int, int>(1, comboTimes));
        //     }
        // }

        // lineChart.RemoveData();
        // lineChart.AddSerie(SerieType.Line);
        // lineChart.title.text = "Combo次数折线图";

        // var max = int.MinValue;
        // var min = int.MaxValue;
        // foreach(var d in tarRate)
        // {
        //     if(d.Key > max)
        //         max = d.Key;
        //     if(d.Key < min)
        //         min = d.Key;
        // }
        // for (int i = min; i <= max; i++)
        // {
        //     lineChart.AddXAxisData($"lv.{i}");
        // }

        // var res = new List<Tuple<int, float>>();
        // foreach(var d in tarRate)
        // {
        //     res.Add(new Tuple<int, float>(d.Key, d.Value.Item2/(float)(d.Value.Item1)));
        // }
        // foreach(var d in res)
        // {
        //     var data = new List<double>(){d.Item1, d.Item2};
        //     lineChart.AddData(0, data);
        // }
    }

    public void ShowHandCards2()
    {
        // Dictionary<int, int> tarRate = new Dictionary<int, int>();
        // foreach(var d in results)
        // {
        //     var cards = d.useHandCardNum;
        //     if(tarRate.ContainsKey(cards))
        //     {
        //         var value = tarRate[cards]+1;
        //         tarRate[cards] = value;
        //     }
        //     else
        //     {
        //         tarRate.Add(cards, 1);
        //     }
        // }

        // scatterChart.RemoveData();
        // scatterChart.AddSerie(SerieType.Scatter);
        // scatterChart.series.list[0].symbol.size = 5;
        // scatterChart.title.text = "使用手牌数散点图";

        // if(tarRate.Count > 1)
        // {
        //     // var max = int.MinValue;
        //     // var min = int.MaxValue;
        //     // foreach(var d in tarRate)
        //     // {
        //     //     if(d.Key > max)
        //     //         max = d.Key;
        //     //     if(d.Key < min)
        //     //         min = d.Key;
        //     // }
        //     for (int i = 1; i <= 60; i++)
        //     {
        //         scatterChart.AddXAxisData($"手牌数.{i}");
        //     }
        //     foreach(var d in tarRate)
        //     {
        //         var data = new List<double>(){d.Key, d.Value};
        //         scatterChart.AddData(0, data);
        //     }
        // }
    }
}