using System;

namespace OBBUtils
{
    [Serializable]
    public class OBB
    {
        public Vec3 Pos { get; set; }
        public Vec3 AxisX { get; set; }
        public Vec3 AxisY { get; set; }
        public Vec3 AxisZ { get; set; }
        public Vec3 Half_size { get; set; }
    }
}