using System;
using System.Linq;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class AIGamePanel : MonoBehaviour
{
    public InputField LevelInput;
    public InputField RunTimesInput;
    public Toggle Dao;
    public Toggle Joker;
    public Toggle Windmill;
    public Toggle Win0;
    public Toggle Win1;
    public Toggle Win2;
    public Toggle Win3;

    private IConfigService configService;

    void Start()
    {
        configService = MainContainer.Container.Resolve<IConfigService>();
        RefreshView(1);
    }

    private void RefreshView(int level)
    {
        LevelInput.text = "1";
        RunTimesInput.text = "100";
        Dao.isOn = false;
        Joker.isOn = false;
        Windmill.isOn = false;
        Win0.isOn = true;
    }

    public void OnStartBtn()
    {
        var level = Convert.ToInt32(LevelInput.text);
        var runTimes = Convert.ToInt32(RunTimesInput.text);
        var dao = Convert.ToBoolean(Dao.isOn);
        var joker = Convert.ToBoolean(Joker.isOn);
        var windmill = Convert.ToBoolean(Windmill.isOn);
        var win0 = Convert.ToBoolean(Win0.isOn);
        var win1 = Convert.ToBoolean(Win1.isOn);
        var win2 = Convert.ToBoolean(Win2.isOn);
        var win3 = Convert.ToBoolean(Win3.isOn);

        TypeEventSystem.Send(new AIStartGameEvent(level, runTimes, dao, joker, windmill, win1, win2, win3));
    }

    public void OnLevelText()
    {
        var level = Convert.ToInt32(LevelInput.text);
        RefreshView(level);
    }
}