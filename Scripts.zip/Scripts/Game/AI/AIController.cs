using System;
using System.Collections.Generic;
using UnityEngine;
using QFramework;
using System.Linq;
using System.Collections;
using System.IO;
using SoliUtils;

public class ResultData
{
    public int userId;
    public GameData gameData;
    public bool isWin;
    public int useHandCardNum;
}


public class AIController : MonoBehaviour, ISingleton, IController
{
    public BattleController BattleCtrl { get; set; }
    private IConfigService configService;
    private IDataService dataService;

    public GameObject LoadingPanel;
    public AIPanel aiPanel;

    private int itemCount = 0;
    private List<ResultData> results = new List<ResultData>();
    private int playerCoin;
    private bool isWin;
    private int winCoin;
    private int userAutoId;
    private int oriCoin;
    private int useHandCardNum;
    private bool isUnlimitHandCardMode;


    void Awake()
    {
        TypeEventSystem.Register<AIStartLevelEvent>(OnAIStartLevelEvent);
        TypeEventSystem.Register<AIEditorStartLevelEvent>(OnAIEditorStartLevelEvent);
        TypeEventSystem.Register<AIStartGameEvent>(OnAIStartGameEvent);
        TypeEventSystem.Register<OperatCommandEvent>(OnOperatCommandEvent);

        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
    }

    void OnDestroy()
    {
        TypeEventSystem.UnRegister<AIStartLevelEvent>(OnAIStartLevelEvent);
        TypeEventSystem.UnRegister<AIEditorStartLevelEvent>(OnAIEditorStartLevelEvent);
        TypeEventSystem.UnRegister<AIStartGameEvent>(OnAIStartGameEvent);
        TypeEventSystem.UnRegister<OperatCommandEvent>(OnOperatCommandEvent);
    }

    private void OnOperatCommandEvent(OperatCommandEvent e)
    {
        if (e.operation is SystemStartOpt)
        {
            var count = 999;
            while (Play() && count > 0)
            {
                count--;
                if (count == 0)
                {
                    Debug.LogError("over calculate");
                    EndBattle();
                    break;
                }
                if (BattleDataMgr.Instance.IsFinish)
                {
                    EndBattle();
                    break;
                }
            }
            if (BattleDataMgr.Instance.HappendBigBomb)
            {
                EndBattle();
            }
        }
        else if (e.operation is SystemOverOpt)
        {
            EndBattle();
        }
    }

    private bool Play()
    {
        if (BattleDataMgr.Instance.IsFinish)
        {
            return false;
        }

        var clickCardId = BattleDataMgr.Instance.AIAction_BestCard();
        if (clickCardId == -1)
        {
            clickCardId = BattleDataMgr.Instance.AIAction_GoodCard();
        }
        if (clickCardId == -1)
        {
            clickCardId = BattleDataMgr.Instance.AIAction_FuncCard();
        }
        if (clickCardId == -1)
        {
            if (isUnlimitHandCardMode)
            {
                if (useHandCardNum > 60)
                {
                    BattleDataMgr.Instance.AIAction_EndBattle();
                    return false;
                }
                BattleDataMgr.Instance.AIAction_UnlimitedHandCard();
                useHandCardNum++;
                return true;
            }
            else
            {
                if (!BattleDataMgr.Instance.AIAction_FlopHandCard())
                {
                    if (itemCount > 0)
                    {
                        var deskCardsNum = BattleDataMgr.Instance.GetDeskCardsNum();
                        var buyCardsPrice = BattleCtrl.gameData.GetNowBuyCardCost();
                        var jokerCardPrice = BattleCtrl.gameData.GetNowBuyJokerCost();
                        if (deskCardsNum > 1 && playerCoin >= buyCardsPrice)
                        {
                            BattleCtrl.gameData.BuyCardNum++;
                            BattleDataMgr.Instance.BuyCards(BattleCtrl.gameData.BuyCardNum);
                            playerCoin -= buyCardsPrice;
                            Debug.LogWarning(playerCoin + "  buyCardsPrice " + buyCardsPrice);
                            itemCount--;
                        }
                        else if (deskCardsNum == 1)
                        {
                            if (playerCoin >= buyCardsPrice && buyCardsPrice < jokerCardPrice)
                            {
                                BattleCtrl.gameData.BuyCardNum++;
                                BattleDataMgr.Instance.BuyCards(BattleCtrl.gameData.BuyCardNum);
                                playerCoin -= buyCardsPrice;
                                Debug.LogWarning(playerCoin + "  buyCardsPrice " + buyCardsPrice);
                                itemCount--;
                            }
                            else if (playerCoin >= jokerCardPrice)
                            {
                                BattleDataMgr.Instance.UseJoker();
                                BattleCtrl.gameData.BuyJokerNum++;
                                playerCoin -= jokerCardPrice;
                                Debug.LogWarning(playerCoin + "  jokerCardPrice " + jokerCardPrice);
                                itemCount--;
                            }
                            else
                            {
                                itemCount = 0;
                            }
                        }
                        else
                        {
                            itemCount = 0;
                        }
                        return true;
                    }
                    else
                    {
                        BattleDataMgr.Instance.AIAction_EndBattle();
                    }
                }
                else
                {
                    useHandCardNum++;
                    return true;
                }
            }
        }
        else
        {
            BattleDataMgr.Instance.TouchCard(clickCardId);
            if (!BattleDataMgr.Instance.IsFinish)
            {
                return true;
            }
        }
        return false;
    }

    private void OnAIStartGameEvent(AIStartGameEvent e)
    {
        LoadingPanel.SetActive(true);
        results.Clear();
        StartCoroutine(DoOnAIStartGameEvent(e));
    }

    private IEnumerator DoOnAIStartGameEvent(AIStartGameEvent e)
    {
        yield return new WaitForSeconds(0.1f);
        userAutoId = 0;
        var level = e.level;
        var times = e.runTimes;
        List<int> items = new List<int>();
        if (e.dao)
        {
            items.Add((int)PropEnum.ItemEliminate);
        }
        if (e.windmill)
        {
            items.Add((int)PropEnum.ItemWindmill);
        }
        if (e.joker)
        {
            items.Add((int)PropEnum.ItemJoker);
        }
        var winstreakCards = new List<CardType>();
        if (e.win1)
        {
            winstreakCards.Add(CardType.Monochrome);
        }
        else if (e.win2)
        {
            winstreakCards.Add(CardType.Monochrome);
            winstreakCards.Add(CardType.Monochrome);
        }
        else if (e.win3)
        {
            winstreakCards.Add(CardType.Monochrome);
            winstreakCards.Add(CardType.Monochrome);
            winstreakCards.Add(CardType.Joker);
        }

        Debug.Log($"<color=red>================== 开始运行 level:{level} times:{times} ==================</color>");
        for (int i = 0; i < times; i++)
        {
            Debug.Log($"<color=yellow>run {i}</color>");
            userAutoId++;
            if (LevelUtils.CheckVaild(level, out var levelModel))
            {
                useHandCardNum = 0;
                BattleCtrl = new BattleController();
                BattleCtrl.BattleLevel = level;
                BattleCtrl.gameData = new GameData(configService, dataService, level, null);
                var battleConfig = BattleController.GenBattleConfig(level, levelModel, items, winstreakCards);
                BattleDataMgr.Instance.Clean();
                BattleDataMgr.Instance.LoadGame(battleConfig);
                yield return new WaitForSeconds(0.02f);
            }
        }
        Debug.Log($"<color=red>================== 运行完成 ==================</color>");
        ShowGame();
    }


    private void OnAIStartLevelEvent(AIStartLevelEvent e)
    {
        isUnlimitHandCardMode = e.unlimitHandCard;
        LoadingPanel.SetActive(true);
        results.Clear();
        StartCoroutine(DoAIStartLevelEvent(e));
    }

    private IEnumerator DoAIStartLevelEvent(AIStartLevelEvent e)
    {
        yield return new WaitForSeconds(0.1f);
        for (int level = e.level1; level <= e.level2; level++)
        {
            if (LevelUtils.CheckVaild(level, out var levelModel))
            {
                var times = e.runTimes;
                for (int i = 0; i < times; i++)
                {
                    useHandCardNum = 1;
                    playerCoin = int.MaxValue;
                    itemCount = e.itemCount;

                    BattleCtrl = new BattleController();
                    BattleCtrl.BattleLevel = level;
                    BattleCtrl.gameData = new GameData(configService, dataService, level, null);
                    BattleCtrl.gameData.EnterCoin = 0;
                    var battleConfig = BattleController.GenBattleConfig(level, levelModel, null);
                    BattleDataMgr.Instance.LoadGame(battleConfig);
                    yield return new WaitForSeconds(0.1f);
                }
            }
        }
        if (!e.unlimitHandCard)
            ShowLevel();
        else
            ShowUnlimit();
    }

    private void OnAIEditorStartLevelEvent(AIEditorStartLevelEvent e)
    {
        results.Clear();
        StartCoroutine(DoEditorAIStartLevelEvent(e));
    }

    private IEnumerator DoEditorAIStartLevelEvent(AIEditorStartLevelEvent e)
    {
        yield return new WaitForSeconds(0.1f);
        var random = e.isRandom;
        var isResult = e.isResult;
        var isLevel = e.isLevel;
        var result = e.result;
        var level = e.level;
        var times = e.runTimes;
        var items = e.itemCount;

        for (int i = 0; i < times; i++)
        {
            Debug.Log($"<color=#FFE53D>============ start {i + 1} ============</color>");
            itemCount = e.itemCount;

            playerCoin = int.MaxValue;
            BattleCtrl = new BattleController();
            BattleCtrl.BattleLevel = level;
            BattleCtrl.gameData = new GameData(configService, dataService, 1, null);
            BattleCtrl.gameData.EnterCoin = 0;
            var levelModel = e.levelModel.DeepCopy();
            var battleConfig = BattleController.GenBattleConfig(level, levelModel, null, null, isResult ? result : -1, random);
            BattleDataMgr.Instance.LoadGame(battleConfig);
            yield return new WaitForSeconds(0.1f);
        }

        var winCount = 0;
        foreach (var item in results)
        {
            if (item.isWin)
                winCount++;
        }
        TypeEventSystem.Send<AIEditorLevelResultEvent>(new AIEditorLevelResultEvent(((float)winCount) / results.Count));

    }

    private void EndBattle()
    {
        if(BattleCtrl == null)
            return;

        BattleCtrl.gameData.RemainDeskCardNum = BattleDataMgr.Instance.GetDeskCardsNum();
        BattleCtrl.gameData.RemainHandCardNum = BattleDataMgr.Instance.GetHandCardsNum();
        BattleCtrl.gameData.RemainStepNum = BattleDataMgr.Instance.AIAction_NeedStep();
        if (BattleDataMgr.Instance.CheckWin())
        {
            isWin = true;
            var coin = BattleCtrl.gameData.GetCoin();
            winCoin = coin;
            BattleCtrl.gameData.RemainCoin = playerCoin + winCoin;
            Debug.Log($"Level = {BattleCtrl.gameData.Level} Win");
            results.Add(new ResultData
            {
                userId = userAutoId,
                isWin = true,
                gameData = BattleCtrl.gameData,
                useHandCardNum = useHandCardNum,
            });
        }
        else
        {
            isWin = false;
            Debug.Log($"Level = {BattleCtrl.gameData.Level} Fail");
            results.Add(new ResultData
            {
                userId = userAutoId,
                isWin = false,
                gameData = BattleCtrl.gameData,
                useHandCardNum = useHandCardNum,
            });
        }

        BattleCtrl.EndGame();
        BattleCtrl = null;
    }

    public void OnSingletonInit()
    {

    }

    public static AIController Instance
    {
        get { return MonoSingletonProperty<AIController>.Instance; }
    }

    private void ShowLevel()
    {
        ExportData();
        LoadingPanel.SetActive(false);
        aiPanel.SetLevelData(results);
    }
    private void ShowGame()
    {
        ExportData2();
        LoadingPanel.SetActive(false);
        // aiPanel.SetGameData(results);
    }
    private void ShowUnlimit()
    {
        ExportData();
        LoadingPanel.SetActive(false);
        aiPanel.SetUnlimitData(results);
    }

    private void ExportData()
    {
        var json = "{\"oriCoin\":" + oriCoin + ", \"battleData\":[";
        int idx = 1;
        foreach (var data in results)
        {
            var str = $"\"uid\":{data.userId},\"level\":{data.gameData.Level},\"isWin\":{data.isWin.ToString().ToLower()},\"remainCoin\":{data.gameData.RemainCoin},\"rewardCoin\":{data.gameData.GetCoin()},\"remainHandCardNum\":{data.gameData.RemainHandCardNum},\"useHandCardNum\":{data.useHandCardNum}";
            json += "{" + str + "}";
            if (idx != results.Count)
                json += ",";
            idx++;
        }
        json += "]}";

        string desktopPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop);
        var filename = Path.Combine(desktopPath, "solitaire_data", $"{DateTime.Now:yyyyMMdd-HHmm}.json");
        WriteFile(filename, json);
    }

    private void ExportData2()
    {
        var json = "[\n";
        int idx = 1;
        int level = 1;
        Dictionary<int, int> steps = new Dictionary<int, int>();
        int winCount = 0;
        foreach (var data in results)
        {
            level = data.gameData.Level;
            var str = $"\"isWin\":{data.isWin.ToString().ToLower()},\"remain_desk\":{data.gameData.RemainDeskCardNum},\"need_step\":{data.gameData.RemainStepNum},\"remain_hand\":{data.gameData.RemainHandCardNum}";
            json += "{" + str + "}";
            if (idx != results.Count)
                json += ",\n";
            if (steps.ContainsKey(data.gameData.RemainStepNum))
                steps[data.gameData.RemainStepNum]++;
            else
                steps.Add(data.gameData.RemainStepNum, 1);
            if (data.isWin)
                winCount++;
        }
        json += "\n]\n";
        var keys = steps.Keys.ToList();
        keys.Sort();
        json += $"//json:{configService.StageConfig[level].json}, 开局次数:{results.Count}, 胜率:{((winCount / (float)results.Count) * 100).ToString("f2")}%, 剩余步骤的局数: ";
        idx = 1;
        foreach (var step in keys)
        {
            json += $"[{step}=>{steps[step]}]";
            if (idx != keys.Count)
                json += ", ";
            idx++;
        }

        string desktopPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop);
        var filename = Path.Combine(desktopPath, "solitaire_data", $"{DateTime.Now:MMddHHmmss}_lv{level}.json");
        WriteFile(filename, json);
    }

    static void WriteFile(string dst, string content)
    {
        var dir = Path.GetDirectoryName(dst);
        if (!Directory.Exists(dir))
        {
            Directory.CreateDirectory(dir);
        }
        File.WriteAllText(dst, content);
    }
}