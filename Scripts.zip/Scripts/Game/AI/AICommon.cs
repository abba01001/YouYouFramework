using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class AICommon
{
    public static int GameOriCoin = 10000;
    public static float GameLinkRate = 1.0f;
    public static float GameComboRate = 0.8f;
    public static int GameTime = 1;
    public static int GameToolNum = 2;

    public static int LvLevel = 30;
    public static float LvLinkRate = 1.0f;
    public static float LvComboRate = 0.8f;
    public static int LvTime = 50;
    public static int LvToolNum = 2;
    
}

public class AIStartGameEventOld : GameEvent
{
    public int oriCoin;
    public float linkRate;
    public float comboRate;
    public int time;
    public int toolNum;
}

public class AIGameResultEvent : GameEvent
{
    public List<Dictionary<int, int>> data;
}

public class AIStartLevelEventOld : GameEvent
{
    public int level;
    public float linkRate;
    public float comboRate;
    public int time;
    public int toolNum;
}

public class AILevelResultEvent : GameEvent
{
    public int level;
    public int win;
    public int lose;
}