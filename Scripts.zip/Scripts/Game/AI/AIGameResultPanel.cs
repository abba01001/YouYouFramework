using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// using XCharts;

public class AIGameResultPanel : MonoBehaviour
{
    // public LineChart lineChart;
    
    public Toggle FirstToggle;
    private List<ResultData> results;

    public void OnCloseBtn()
    {
        gameObject.SetActive(false);
    }

    public void SetResultData(List<ResultData> data)
    {
        results = data;
        FirstToggle.isOn = true;
        OnTab(1);
    }

    public void OnTab(int idx)
    {
        if(idx == 1)
        {
            ShowTopLevel();
        }
        else if(idx == 2)
        {
            ShowCoin();
        }
        else if(idx == 3)
        {
            ShowComboTimes();
        }
    }

    public void ShowCoin()
    {
        // lineChart.RemoveData();
        // lineChart.AddSerie(SerieType.Line);
        // lineChart.title.text = "金币折线图";
        
        // var minLv = 9999999;
        // var maxLv = 0;
        // foreach(var d in results)
        // {
        //     if(d.gameData.Level > maxLv)
        //         maxLv = d.gameData.Level;
        //     if(d.gameData.Level < minLv)
        //         minLv = d.gameData.Level;
        // }
        // for (int i = minLv; i <= maxLv; i++)
        // {
        //     lineChart.AddXAxisData($"lv.{i}");
        // }
        // foreach(var d in results)
        // {
        //     if(d.isWin)
        //     {
        //         lineChart.AddSerie(SerieType.Line);
        //         lineChart.AddData(d.userId, d.gameData.RemainCoin);
        //     }
        // }

    }

    public void ShowComboTimes()
    {
        // lineChart.RemoveData();
        // lineChart.AddSerie(SerieType.Line);
        // lineChart.title.text = "Combo次数折线图";
        
        // var minLv = 9999999;
        // var maxLv = 0;
        // foreach(var d in results)
        // {
        //     if(d.gameData.Level > maxLv)
        //         maxLv = d.gameData.Level;
        //     if(d.gameData.Level < minLv)
        //         minLv = d.gameData.Level;
        // }
        // for (int i = minLv; i <= maxLv; i++)
        // {
        //     lineChart.AddXAxisData($"lv.{i}");
        // }

        // Dictionary<int, List<ResultData>> userResultData = new Dictionary<int, List<ResultData>>();
        // foreach(var d in results)
        // {
        //     if(userResultData.ContainsKey(d.userId))
        //     {
        //         userResultData[d.userId].Add(d);
        //     }
        //     else
        //     {
        //         var dataList = new List<ResultData>();
        //         dataList.Add(d);
        //         userResultData.Add(d.userId, dataList);
        //     }
        // }

        // foreach(var d in userResultData)
        // {
        //     var data = d.Value;
        //     Dictionary<int, Tuple<int, int>> comboData = new Dictionary<int, Tuple<int,int>>();
        //     foreach(var d2 in data)
        //     {
        //         var level = d2.gameData.Level;
        //         var comboTimes = d2.gameCombo.FinishComboNum;
        //         if(comboData.ContainsKey(d2.gameData.Level))
        //         {
        //             var value = new Tuple<int, int>(comboData[level].Item1 + 1,
        //                 comboData[level].Item2 + comboTimes);
        //             comboData[level] = value;
        //         }
        //         else
        //         {
        //             comboData.Add(level, new Tuple<int, int>(1, comboTimes));
        //         }
        //     }
        //     foreach(var cd in comboData)
        //     {
        //         lineChart.AddSerie(SerieType.Line);
        //         lineChart.AddData(d.Key, cd.Value.Item2/(float)(cd.Value.Item1));
        //     }
        // }

    }

    public void ShowTopLevel()
    {
        // Dictionary<int, int> tarRate = new Dictionary<int, int>();
        // foreach(var d in results)
        // {
        //     var userid = d.userId;
        //     var level = d.gameData.Level;
        //     if(tarRate.ContainsKey(userid))
        //     {
        //         if(tarRate[userid] < level)
        //             tarRate[userid] = level;
        //     }
        //     else
        //     {
        //         tarRate.Add(userid, level);
        //     }
        // }
        
        // lineChart.RemoveData();
        // lineChart.AddSerie(SerieType.Line);
        // lineChart.title.text = "最高等级折线图";

        // var max = int.MinValue;
        // var min = int.MaxValue;
        // foreach(var d in tarRate)
        // {
        //     if(d.Key > max)
        //         max = d.Key;
        //     if(d.Key < min)
        //         min = d.Key;
        // }
        // for (int i = min; i <= max; i++)
        // {
        //     lineChart.AddXAxisData($"player.{i}");
        // }

        // foreach(var d in tarRate)
        // {
        //     var data = new List<double>(){d.Key, d.Value};
        //     lineChart.AddData(0, data);
        // }
    }


}