using System;
using System.Linq;
using QFramework;
using UnityEngine;
using UnityEngine.UI;
using SoliUtils;

public class AIUnlimitPanel : MonoBehaviour
{
    public InputField StartLevelInput;
    public InputField EndLevelInput;
    public InputField LinkRateInput;
    public InputField ComboRateInput;
    public InputField RunTimesInput;
    public Text LinkRateText;
    public Text ComboRateText;

    private IConfigService configService;

    void Start()
    {
        configService = MainContainer.Container.Resolve<IConfigService>();
        RefreshView(1);
    }

    private void RefreshView(int level)
    {
        // var configService = MainContainer.Container.Resolve<IConfigService>();
        // configService.HandleLevelConfig.TryGetValue(level, out var hLevelCfg);
        // if (hLevelCfg == null)
        // {
        //     hLevelCfg = configService.HandleLevelConfig.Last().Value;
        // }
        // int label = GameUtils.RandomIntFromFormatString(hLevelCfg.group);
        // configService.HandleLabelConfig.TryGetValue(label, out var hLabelCfg);
        // if (hLabelCfg == null)
        // {
        //     hLabelCfg = configService.HandleLabelConfig.Last().Value;
        // }
        // int result = GameUtils.RandomIntFromFormatString(hLabelCfg.result);
        // configService.HandleResultConfig.TryGetValue(result, out var hResultCfg);
        // if (hResultCfg == null)
        // {
        //     hResultCfg = configService.HandleResultConfig.Last().Value;
        // }

        // LinkRateText.text = hResultCfg.linkRate.ToString();
        // ComboRateText.text = hResultCfg.comboRate.ToString();
        // LinkRateInput.text = hResultCfg.linkRate.ToString();
        // ComboRateInput.text = hResultCfg.comboRate.ToString();
    }

    public void OnStartBtn()
    {
        var level1 = Convert.ToInt32(StartLevelInput.text);
        var level2 = Convert.ToInt32(EndLevelInput.text);

        var configService = MainContainer.Container.Resolve<IConfigService>();
        configService.HandleLevelConfig.TryGetValue(level1, out var hLevelCfg);
        if (hLevelCfg == null)
        {
            hLevelCfg = configService.HandleLevelConfig.Last().Value;
        }
        int label = GameUtils.RandomIntFromFormatString(hLevelCfg.group);
        configService.HandleLabelConfig.TryGetValue(label, out var hLabelCfg);
        if (hLabelCfg == null)
        {
            hLabelCfg = configService.HandleLabelConfig.Last().Value;
        }
        int result = GameUtils.RandomIntFromFormatString(hLabelCfg.result);
        configService.HandleResultConfig.TryGetValue(result, out var hResultCfg);
        if (hResultCfg == null)
        {
            hResultCfg = configService.HandleResultConfig.Last().Value;
        }
        
        // var linkRate = LinkRateInput.readOnly ? hResultCfg.linkRate : Convert.ToDouble(LinkRateInput.text);
        // var comboRate = ComboRateInput.readOnly ? hResultCfg.comboRate : Convert.ToDouble(ComboRateInput.text);
        // var runTimes = Convert.ToInt32(RunTimesInput.text);

        // TypeEventSystem.Send(new AIStartLevelEvent(
        //     level1, level2,
        //     (float)linkRate, (float)comboRate, 0, runTimes, true));
    }

    public void OnLevelText()
    {
        var level1 = Convert.ToInt32(StartLevelInput.text);
        RefreshView(level1);
        var level2 = Convert.ToInt32(EndLevelInput.text);
        if(level2 < level1)
        {
            EndLevelInput.text = level1.ToString();
        }
    }

    public void OnLinkRateToggleBtn(Toggle toggle)
    {
        if(toggle.gameObject.name.Equals("ConfigToggle"))
        {
            LinkRateInput.readOnly = toggle.isOn;
        }
    }

    public void OnComboRateToggleBtn(Toggle toggle)
    {
        if(toggle.gameObject.name.Equals("ConfigToggle"))
        {
            ComboRateInput.readOnly = toggle.isOn;
        }
    }
}