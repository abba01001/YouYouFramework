using System;
using System.Linq;
using QFramework;
using UnityEngine;

public class AIBattleController
{
    private IConfigService configService;
    private IDataService dataService;
    public GameData gameData;
    private System.Tuple<int, int> maxGuarTuple;
    private long startGameTime;

    public int BattleLevel { get; set; }
    public bool IsPlaying { get; private set; }

    public void CleanUp()
    {
        TypeEventSystem.UnRegister<UndoEvent>(OnUndoEvent);
        TypeEventSystem.UnRegister<JokerEvent>(OnJokerEvent);
        TypeEventSystem.UnRegister<BuyCardsEvent>(OnBuyCardsEvent);
        TypeEventSystem.UnRegister<ComboEvent>(OnComboEvent);
        TypeEventSystem.UnRegister<FlopHandCardEvent>(OnFlopHandCardEvent);
        TypeEventSystem.UnRegister<BattleResultEvent>(OnBattleResultEvent);
        TypeEventSystem.UnRegister<AddCollectCoinMod>(OnAddCollectCoinMod);
        BattleDataMgr.Instance.Clean();
        BattleViewMgr.Instance.Clean();
        gameData = null;
    }

    public AIBattleController()
    {
        TypeEventSystem.Register<UndoEvent>(OnUndoEvent);
        TypeEventSystem.Register<JokerEvent>(OnJokerEvent);
        TypeEventSystem.Register<BuyCardsEvent>(OnBuyCardsEvent);
        TypeEventSystem.Register<ComboEvent>(OnComboEvent);
        TypeEventSystem.Register<FlopHandCardEvent>(OnFlopHandCardEvent);
        TypeEventSystem.Register<BattleResultEvent>(OnBattleResultEvent);
        TypeEventSystem.Register<AddCollectCoinMod>(OnAddCollectCoinMod);

        configService = MainContainer.Container.Resolve<IConfigService>();
        dataService = MainContainer.Container.Resolve<IDataService>();
    }

    public void EndGame()
    {
        CleanUp();
    }

    public bool IsWin()
    {
        return BattleDataMgr.Instance.CheckWin();
    }

    private void OnUndoEvent(GameEvent e)
    {
        if(!BattleDataMgr.Instance.CanUndo())
            return;
        if (!gameData.BuyUndo()) 
            return;
        BattleCenter.Instance.OnUndoEvent();
        RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
        t.Init(gameData);
        TypeEventSystem.Send<RefreshGameViewEvent>(t);
    }

    private void OnJokerEvent(GameEvent e)
    {
        if(!BattleDataMgr.Instance.CanJoker())
            return;
        if (!gameData.BuyJoker())
            return;
        BattleCenter.Instance.OnJokerEvent();
        RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
        t.Init(gameData);
        TypeEventSystem.Send<RefreshGameViewEvent>(t);
    }

    private void OnBuyCardsEvent(GameEvent e)
    {
        if(!BattleDataMgr.Instance.CanBuyCards())
            return;
        if (!gameData.BuyCard()) 
            return;
        BattleCenter.Instance.OnBuyCardsEvent(gameData.UseBuyCardCount);
        RefreshGameViewEvent t = GameObjManager.Instance.PopClass<RefreshGameViewEvent>(true);
        t.Init(gameData);
        TypeEventSystem.Send<RefreshGameViewEvent>(t);
    }

    private void OnAddCollectCoinMod(AddCollectCoinMod addEvent)
    {
        CardModel cm = addEvent.coinModCard.cm;
        ModifierModel coinModifierModel = cm.modifiers.First(x => x.modType == ModifierType.Coin);
        Vector3 cardPos = new Vector3(cm.x, cm.y, cm.depth);
        gameData.AddRewardCoin(PropChangeWay.CoinMod, coinModifierModel.properties.param1 * dataService.NowBet, cardPos);
    }

    private void OnComboEvent(ComboEvent e)
    {
    }

    private void OnFlopHandCardEvent(GameEvent e)
    {
    }

    private void DoAddComboCard(int count, CardType cardType)
    {
        BattleDataMgr.Instance.AddComboCards(count, cardType, 0);
    }

    private void OnBattleResultEvent(BattleResultEvent e)
    {
        
    }

}