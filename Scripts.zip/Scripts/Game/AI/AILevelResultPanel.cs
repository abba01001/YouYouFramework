using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// using XCharts;

public class AILevelResultPanel : MonoBehaviour
{
    // public LineChart lineChart;
    public Toggle FirstToggle;
    private List<ResultData> results;

    public void OnCloseBtn()
    {
        gameObject.SetActive(false);
    }

    public void SetResultData(List<ResultData> data)
    {
        results = data;
        FirstToggle.isOn = true;
        OnTab(1);
    }

    public void OnTab(int idx)
    {
        if(idx == 1)
        {
            ShowWinRate();
        }
        else if(idx == 2)
        {
            ShowComboTimes();
        }
        else if(idx == 3)
        {
            ShowHandCards();
        }
    }

    public void ShowHandCards()
    {
        // Dictionary<int, Tuple<int, int>> tarRate = new Dictionary<int, Tuple<int,int>>();
        // foreach(var d in results)
        // {
        //     var level = d.gameData.Level;
        //     var handCardsCount = d.gameData.RemainHandCardNum;
        //     if(tarRate.ContainsKey(d.gameData.Level))
        //     {
        //         var value = new Tuple<int, int>(tarRate[level].Item1 + 1,
        //             tarRate[level].Item2 + handCardsCount);
        //         tarRate[level] = value;
        //     }
        //     else
        //     {
        //         tarRate.Add(level, new Tuple<int, int>(1, handCardsCount));
        //     }
        // }

        // lineChart.RemoveData();
        // lineChart.AddSerie(SerieType.Line);
        // lineChart.title.text = "手牌剩余数折线图";
        // var res = new List<Tuple<int, float>>();
        // foreach(var d in tarRate)
        // {
        //     res.Add(new Tuple<int, float>(d.Key, d.Value.Item2/(float)(d.Value.Item1)));
        // }
        // foreach(var d in res)
        // {
        //     lineChart.AddXAxisData($"lv.{d.Item1}");
        //     lineChart.AddData(0, d.Item2);
        // }
    }

    public void ShowComboTimes()
    {
        // Dictionary<int, Tuple<int, int>> tarRate = new Dictionary<int, Tuple<int,int>>();
        // foreach(var d in results)
        // {
        //     var level = d.gameData.Level;
        //     var comboTimes = d.gameCombo.FinishComboNum;
        //     if(tarRate.ContainsKey(d.gameData.Level))
        //     {
        //         var value = new Tuple<int, int>(tarRate[level].Item1 + 1,
        //             tarRate[level].Item2 + comboTimes);
        //         tarRate[level] = value;
        //     }
        //     else
        //     {
        //         tarRate.Add(level, new Tuple<int, int>(1, comboTimes));
        //     }
        // }

        // lineChart.RemoveData();
        // lineChart.AddSerie(SerieType.Line);
        // lineChart.title.text = "Combo次数折线图";
        // var res = new List<Tuple<int, float>>();
        // foreach(var d in tarRate)
        // {
        //     res.Add(new Tuple<int, float>(d.Key, d.Value.Item2/(float)(d.Value.Item1)));
        // }
        // foreach(var d in res)
        // {
        //     lineChart.AddXAxisData($"lv.{d.Item1}");
        //     lineChart.AddData(0, d.Item2);
        // }
    }

    public void ShowWinRate()
    {
        // Dictionary<int, Tuple<int, int>> tarRate = new Dictionary<int, Tuple<int,int>>();
        // foreach(var d in results)
        // {
        //     var level = d.gameData.Level;
        //     var winCount = d.isWin ? 1 : 0;
        //     var failCount = d.isWin ? 0 : 1;
        //     if(tarRate.ContainsKey(d.gameData.Level))
        //     {
        //         var value = new Tuple<int, int>(tarRate[level].Item1 + winCount,
        //             tarRate[level].Item2 + failCount);
        //         tarRate[level] = value;
        //     }
        //     else
        //     {
        //         tarRate.Add(level, new Tuple<int, int>(winCount, failCount));
        //     }
        // }
        
        // lineChart.RemoveData();
        // lineChart.AddSerie(SerieType.Line);
        // lineChart.title.text = "胜率折线图";
        // var res = new List<Tuple<int, float>>();
        // foreach(var d in tarRate)
        // {
        //     res.Add(new Tuple<int, float>(d.Key, d.Value.Item1/(float)(d.Value.Item1+d.Value.Item2)));
        // }
        // foreach(var d in res)
        // {
        //     lineChart.AddXAxisData($"lv.{d.Item1}");
        //     lineChart.AddData(0, d.Item2);
        // }
    }


}