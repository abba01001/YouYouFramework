using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public static class ExternFunc
{
    [DllImport("__Internal")]
    private static extern void ta_track(string event_name, string event_pramas);
    [DllImport("__Internal")]
    private static extern void ta_userSet(string pramas);
    [DllImport("__Internal")]
    private static extern void ta_userSetOnce(string pramas);
    [DllImport("__Internal")]
    private static extern void ta_userAdd(string pramas);
    [DllImport("__Internal")]
    private static extern void ta_trackFirst(string event_name, string event_pramas);


    [DllImport("__Internal")]
    private static extern void qySDK_create(int gameId, bool release);

    [DllImport("__Internal")]
    private static extern void qySDK_login();

    [DllImport("__Internal")]
    private static extern void qySDK_openCustomerService();

    [DllImport("__Internal")]
    private static extern void cleanAndRestart();

    [DllImport("__Internal")]
    private static extern void restart();

    [DllImport("__Internal")]
    private static extern void qySDK_submitData(int data_type, string server_id, string server_name,
        string role_id, string role_name, int role_level, int money_num, int vip);

    [DllImport("__Internal")]
    private static extern void qySDK_showRewardAd(string adunit_id, string place_id);

    [DllImport("__Internal")]
    private static extern void qySDK_pay(string role_id, string role_name, int role_level, int money, int game_gold, string product_id, string product_name, string product_desc, string order_id);

    [DllImport("__Internal")]
    private static extern void qxReportSDK_pay(string svr_order, string game_order, int money, string product_id, string item_desc, int retry_count);



    [DllImport("__Internal")]
    private static extern void wxCloud_init();

    [DllImport("__Internal")]
    private static extern void wxCloud_readUserData(string user_id);

    [DllImport("__Internal")]
    private static extern void wxCloud_writeUserData(string user_id, string data_json);

    [DllImport("__Internal")]
    private static extern void wxCloud_uploadFile(string cloudPath, string filePath);

    [DllImport("__Internal")]
    private static extern void wxCloud_getRanking();

    [DllImport("__Internal")]
    private static extern void wxShare();



    public static void TA_track(string event_name, string event_pramas)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        ta_track(event_name, event_pramas);
    }

    public static void TA_userSet(string pramas)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        ta_userSet(pramas);
    }

    public static void TA_userSetOnce(string pramas)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        ta_userSetOnce(pramas);
    }

    public static void TA_userAdd(string pramas)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        ta_userAdd(pramas);
    }

    public static void TA_trackFirst(string event_name, string event_pramas)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        ta_trackFirst(event_name, event_pramas);
    }


    public static void QYSDK_create(int gameId, bool release)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        qySDK_create(gameId, release);
    }

    public static void QYSDK_login()
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        qySDK_login();
    }

    public static void QYSDK_openCustomerService()
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        qySDK_openCustomerService();
    }

    public static void QYSDK_submitData(int data_type, string server_id, string server_name, string role_id, string role_name, int role_level, int money_num, int vip)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        qySDK_submitData(data_type, server_id, server_name, role_id, role_name, role_level, money_num, vip);
    }

    public static void QYSDK_showRewardAd(string adunit_id, string place_id)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        qySDK_showRewardAd(adunit_id, place_id);
    }


    public static void QYSDK_pay(string role_id, string role_name, int role_level, int money, int game_gold, string product_id, string product_name, string product_desc, string order_id)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        qySDK_pay(role_id, role_name, role_level, money, game_gold, product_id, product_name, product_desc, order_id);

    }
    public static void QXReportSDK_pay(string svr_order, string game_order, int money, string product_id, string item_desc, int retry_count)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        qxReportSDK_pay(svr_order, game_order, money, product_id, item_desc, retry_count);
    }

    public static void CleanAndRestart()
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        cleanAndRestart();
    }

    public static void Restart()
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        restart();
    }


    public static void WXCloud_init()
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        wxCloud_init();
    }


    public static void WXCloud_readUserData(string user_id)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        wxCloud_readUserData(user_id);
    }


    public static void WXCloud_writeUserData(string user_id, string data_json)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        wxCloud_writeUserData(user_id, data_json);
    }


    public static void WXCloud_uploadFile(string cloudPath, string filePath)
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        wxCloud_uploadFile(cloudPath, filePath);
    }


    public static void WXCloud_getRanking()
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        wxCloud_getRanking();
    }


    public static void WXShare()
    {
#if UNITY_EDITOR || !WEIXINMINIGAME
        return;
#endif
        wxShare();
    }

}
