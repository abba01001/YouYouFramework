using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
// using HybridCLR;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.Networking;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.UI;
using static UnityEngine.AddressableAssets.Addressables;

/// <summary>
/// Loading页检测更新并下载资源
/// </summary>
public class AADownloadManager : MonoBehaviour
{
    /// <summary>
    /// 显示下载状态和进度
    /// </summary>
    public Image progressImage;
    public Button retryButton;
    public Button CleanBtn;
    public Text updateText;

    // 下载每组资源大小
    List<long> downLoadSizeList = new List<long>();

    /// <summary>
    /// 下载多个文件列表
    /// </summary>
    List<string> downLoadKeyList = new List<string>();
    List<IResourceLocator> resourceLocators;

    // 总大小
    long totalSize = 0;
    // 下载进度
    float curProgressSize = 0;

    // 下载到那个资源
    int progressIndex = 0;

    // 下载资源总大小
    private long downLoadTotalSize = 0;

    // 当前下载大小
    private float curDownLoadSize = 0;

    void Start()
    {
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Application.targetFrameRate = 60;

        retryButton.gameObject.SetActive(false);
        InitAddressable();

        CleanBtn.onClick.AddListener((() =>
        {
            ExternFunc.CleanAndRestart();
        }));

        var fallbackFont = "https://qxjlsite.6666net.com/font/CLOUDHEIDAGBK.ttf";
        WeChatWASM.WX.GetWXFont(fallbackFont, (font) =>
        {
            updateText.font = font;
        });
    }

    /// <summary>
    /// 初始化 --> 加载远端的配置文件
    /// </summary>
    private async void InitAddressable()
    {
        ShowHintText(0, "正在初始化配置...");
        var initAddress = Addressables.InitializeAsync(false);
        await initAddress.Task;
        if (initAddress.Status == AsyncOperationStatus.Failed)
        {
            Debug.LogError("初始化失败");
            ShowHintText(0, "初始化失败");
            StartGame();
            return;
        }

        // CheckUpdateAsset();
        // Addressables.Release(initAddress);
        StartGame();
    }

    /// <summary>
    /// 检查是否有更新
    /// </summary>
    private async void CheckUpdateAsset()
    {
        ShowHintText(0, "正在检测更新配置...");
        retryButton.gameObject.SetActive(false);
        var checkCatLogUpdate = Addressables.CheckForCatalogUpdates(false);
        await checkCatLogUpdate.Task;
        if (checkCatLogUpdate.Status != AsyncOperationStatus.Succeeded)
        {
            Debug.LogError("检测更新失败");
            ShowHintText(0, "检测更新失败");

            // 展示重试按钮
            retryButton.gameObject.SetActive(true);
            retryButton.onClick.RemoveAllListeners();
            retryButton.onClick.AddListener(CheckUpdateAsset);
        }
        else
        {
            downLoadKeyList = checkCatLogUpdate.Result;
            if (downLoadKeyList.Count <= 0)
            {
                Debug.Log("无可更新内容，直接进入游戏...");
                ShowHintText(1, "无可更新内容");
                StartGame();
            }
            else
            {
                Debug.Log($"有{downLoadKeyList.Count}个资源需要更新");
                foreach (var item in downLoadKeyList)
                {
                    Debug.Log($"key: {item}");
                }
                CheckUpdateAssetSize();
            }
        }
        Addressables.Release(checkCatLogUpdate);
    }

    private async void CheckUpdateAssetSize()
    {
        ShowHintText(0, "正在校验更新资源大小...");
        retryButton.gameObject.SetActive(false);
        // true：自动清除缓存 ，更新资源列表，是否自动释放
        var updateCatLog = Addressables.UpdateCatalogs(false, downLoadKeyList, false);
        await updateCatLog.Task;

        if (updateCatLog.Status != AsyncOperationStatus.Succeeded)
        {
            Debug.LogError($"更新资源列表失败: {updateCatLog.OperationException}");
            ShowHintText(0, "更新资源列表失败");

            // 展示重试按钮
            retryButton.gameObject.SetActive(true);
            retryButton.onClick.RemoveAllListeners();
            retryButton.onClick.AddListener(CheckUpdateAssetSize);
            return;
        }

        resourceLocators = updateCatLog.Result;
        // Addressables.Release(updateCatLog);

        AsyncOperationHandle<long> operationHandle = default;
        foreach (var item in resourceLocators)
        {
            operationHandle = Addressables.GetDownloadSizeAsync(item.Keys);
            await operationHandle.Task;
            downLoadSizeList.Add(operationHandle.Result);
            totalSize += operationHandle.Result;
        }
        Debug.Log($"获取到的下载大小：{totalSize / 1048579f} M");
        Addressables.Release(operationHandle);

        if (totalSize <= 0)
        {
            Debug.Log("无可更新内容");
            ShowHintText(1, "无可更新内容");
            StartGame();
            return;
        }

        Debug.Log($"有{downLoadKeyList.Count}个资源需要更新");
        ShowHintText(0, $"有{downLoadKeyList.Count}个资源需要更新");

        progressIndex = 0;
        DownloadAsset();
    }

    private async void DownloadAsset()
    {
        ShowHintText(0, "正在更新资源...");
        retryButton.gameObject.SetActive(false);

        List<string> keys = new List<string>();
        foreach (var locator in resourceLocators)
        {
            foreach (var key in locator.Keys)
            {
                if (key is string)
                {
                    keys.Add((string)key);
                }
            }
        }

        AsyncOperationHandle downloadHandle = Addressables.DownloadDependenciesAsync(keys, MergeMode.Union);
        // AsyncOperationHandle downloadHandle = Addressables.DownloadDependenciesAsync(resourceLocators, MergeMode.Union);
        // await downloadHandle.Task;
        while (downloadHandle.Status == AsyncOperationStatus.None)
        {
            Debug.Log($"Download progress: {downloadHandle.PercentComplete * 100:F2}%");
            ShowHintText(downloadHandle.PercentComplete, $"正在更新资源... {downloadHandle.PercentComplete * 100:F2}%");
            await UniTask.Delay(10); // 等待一段时间后再更新进度显示
        }
        if (downloadHandle.Status == AsyncOperationStatus.Succeeded)
        {
            Debug.Log($"下载成功 ...");
            StartGame();
        }
        else
        {
            Debug.LogError($"下载失败... {downloadHandle.OperationException}");
            retryButton.gameObject.SetActive(true);
            retryButton.onClick.RemoveAllListeners();
            retryButton.onClick.AddListener(DownloadAsset);
        }
        Addressables.Release(downloadHandle);
    }

    // private void Update()
    // {
    //     if (Input.GetKeyDown(KeyCode.A))
    //     {
    //         Debug.Log("清理缓存...");
    //         Debug.Log($"{Application.persistentDataPath}");

    //         // 清理缓存
    //         Caching.ClearCache();
    //     }
    // }

    void ShowHintText(float progress, string text)
    {
        Debug.Log("====== ShowHintText : " + text);
        if (updateText != null)
        {
            updateText.text = text;
        }

        if (progressImage != null)
        {
            progressImage.fillAmount = progress;
        }
    }

    void StartGame()
    {
        Addressables.LoadSceneAsync("Assets/Scenes/LauncherScene.unity");
    }

    #region CLR -- 进入游戏

    private Assembly _hotUpdateAss;

    async void StartGame2()
    {
        // LoadMetadataForAOTAssemblies();
        
        Debug.Log($"StartGame LoadMetadataForAOTAssemblies2 start");
        // StartCoroutine(LoadMetadataForAOTAssemblies2());
        while(LoadAssemblyCount != AOTMetaAssemblyFiles.Count)
        {
            await UniTask.Delay(10);
        }
        Debug.Log($"StartGame LoadMetadataForAOTAssemblies2 end");
#if UNITY_EDITOR
        string hotUpdateName = "HotUpdate";
        _hotUpdateAss = System.AppDomain.CurrentDomain.GetAssemblies().First(a => a.GetName().Name == hotUpdateName);
#else
        // string hotUpdateName = "HotUpdate.dll.bytes";
        // _hotUpdateAss = Assembly.Load(ReadBytesFromStreamingAssets(hotUpdateName));

        await Task.Yield();
        
        string hotUpdateName = "HotUpdate.dll.bytes";
        // hotUpdateName = "test1.json";
        Debug.Log($"异步加载资源Key路径：{hotUpdateName}");
        AsyncOperationHandle<TextAsset> handle = Addressables.LoadAssetAsync<TextAsset>(hotUpdateName);
        await handle.Task;
        Debug.Log($"异步加载资源Key状态：{handle.Status}");
        if (handle.Status != AsyncOperationStatus.Succeeded)
        {
            Debug.LogError($"异步加载资源失败，资源Key路径：{hotUpdateName}，\n异常 {handle.OperationException}");
            //throw new Exception($"异步加载资源失败，资源Key路径：{hotUpdateName}，\n异常 {handle.OperationException}");
        }

        Debug.Log($"异步加载资源大小：{handle.Result.dataSize}");
        _hotUpdateAss = Assembly.Load(handle.Result.bytes);

#endif
        await Task.Yield();
        Type entryType = _hotUpdateAss.GetType("GameEntry");
        entryType.GetMethod("Start").Invoke(null, null);
    }

    private static List<string> AOTMetaAssemblyFiles { get; } = new List<string>()
    {
        "mscorlib.dll.bytes",
        "System.dll.bytes",
        "System.Core.dll.bytes",
        "Unity.ResourceManager.dll.bytes",
        "UniTask.dll.bytes",
    };

    private int LoadAssemblyCount = 0;

    /// <summary>
    /// 为aot assembly加载原始metadata， 这个代码放aot或者热更新都行。
    /// 一旦加载后，如果AOT泛型函数对应native实现不存在，则自动替换为解释模式执行
    /// </summary>
    private void LoadMetadataForAOTAssemblies()
    {
        // 注意，补充元数据是给AOT dll补充元数据，而不是给热更新dll补充元数据。
        // 热更新dll不缺元数据，不需要补充，如果调用LoadMetadataForAOTAssembly会返回错误
        // HomologousImageMode mode = HomologousImageMode.SuperSet;
        // foreach (var aotDllName in AOTMetaAssemblyFiles)
        // {
        //     byte[] dllBytes = ReadBytesFromStreamingAssets(aotDllName);
        //     // 加载assembly对应的dll，会自动为它hook。一旦aot泛型函数的native函数不存在，用解释器版本代码
        //     LoadImageErrorCode err = RuntimeApi.LoadMetadataForAOTAssembly(dllBytes, mode);
        //     Debug.Log($"LoadMetadataForAOTAssembly:{aotDllName}. mode:{mode} ret:{err}");
        // }
    }

    private byte[] ReadBytesFromStreamingAssets(string abName)
    {
        Debug.Log($"ReadAllBytes name: {abName}");
#if UNITY_ANDROID
            AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.PrivacyActivity");
            //jc.CallStatic<byte[]>("getFromAssets", name);
            AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity");
            byte[] oldBytes = jo.Call<byte[]>("getFromAssets", abName);
            return oldBytes;

            #region 在Android工程中添加读取方法

            // import java.io.File;
            // import java.io.FileInputStream;
            // import java.io.FileNotFoundException;
            // import java.io.FileOutputStream;
            // import java.io.IOException;
            // import java.io.InputStream;

            // public byte[] getFromAssets(String fileName) {
            //     Log.e("****", "getFromAssets:" + fileName);
            //     try {
            //         //得到资源中的Raw数据流
            //         InputStream in = getResources().getAssets().open(fileName);
            //         //得到数据的大小
            //         int length = in.available();
            //
            //         byte[] buffer = new byte[length];
            //             //读取数据
            //             in.read(buffer);
            //             //依test.txt的编码类型选择合适的编码，如果不调整会乱码
            //             //res = EncodingUtils.getString(buffer, "BIG5");
            //             //关闭
            //             in.close();
            //
            //         return buffer;
            //     } catch (Exception e) {
            //         e.printStackTrace();
            //         return null;
            //     }
            // }

            #endregion
#else
        byte[] oldBytes = File.ReadAllBytes(Application.streamingAssetsPath + "/" + abName);
        return oldBytes;
#endif

    }

    // IEnumerator LoadMetadataForAOTAssemblies2()
    // {
    //     HomologousImageMode mode = HomologousImageMode.SuperSet;
    //     foreach (var aotDllName in AOTMetaAssemblyFiles)
    //     {
    //         string filePath = System.IO.Path.Combine(Application.streamingAssetsPath, aotDllName);

    //         UnityWebRequest request = UnityWebRequest.Get(filePath);
    //         yield return request.SendWebRequest();

    //         if (request.result == UnityWebRequest.Result.Success)
    //         {
    //             byte[] dllBytes = request.downloadHandler.data;
    //             // 加载assembly对应的dll，会自动为它hook。一旦aot泛型函数的native函数不存在，用解释器版本代码
    //             LoadImageErrorCode err = RuntimeApi.LoadMetadataForAOTAssembly(dllBytes, mode);
    //             LoadAssemblyCount ++;
    //             Debug.Log($"LoadMetadataForAOTAssembly:{aotDllName}. mode:{mode} ret:{err}");
    //         }
    //         else
    //         {
    //             Debug.LogError("Failed to read file: " + request.error);
    //         }
    //     }
    // }

    #endregion
}