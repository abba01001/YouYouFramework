package com.yibaiip.qcxy.wxapi;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.content.Intent;
import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.unity3d.player.UnityPlayer;

public class WXPayEntryActivity extends Activity implements IWXAPIEventHandler {
    //根据其他开发者反馈的问题返回商户白屏时，给出加一个连接的解决方式
    private IWXAPI api;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        api = WXAPIFactory.createWXAPI(this, "wx-appid");
        api.handleIntent(getIntent(), this);
    }
    //白屏时加的连接
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        api.handleIntent(intent,this);
    }
    @Override
    public void onReq(BaseReq req) {
    }
    @Override
    public void onResp(BaseResp resp) {
        Log.d("Unity", "onPayFinish, errCode = " + resp.errCode);
        String result = resp.errCode == 0?"true":"false";
        UnityPlayer.UnitySendMessage("SDKManager", "PayCallBack", result);
        finish();
    }
}