package com.yibaiip.qcxy;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.alipay.sdk.app.EnvUtils;
import com.alipay.sdk.app.PayTask;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;
import com.yibaiip.qcxy.util.OrderInfoUtil2_0;

import java.util.Map;

public class MainActivity extends UnityPlayerActivity {
    private IWXAPI msgApi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void aliPay(final String orderInfo, final Context context){
        Log.i("Unity", "aliPay, result = " + orderInfo);
        Runnable payRun=new Runnable() {
            @Override
            public void run() {
                PayTask task=new PayTask((Activity)UnityPlayer.currentActivity);
//                String result= task.pay(orderInfo, true);
                Map<String, String> result = task.payV2(orderInfo, true);
                Log.i("Unity", "onALIPayFinish, result = " + result);
                String resultStatus = result.get("resultStatus");
                int ret = -1;
                if (resultStatus!=null&&resultStatus!=""){
                    ret =Integer.valueOf(resultStatus);
                }

                UnityPlayer.UnitySendMessage("SDKManager", "PayCallBack", ret == 9000?"true":"false");
            }
        };
        Thread payThread = new Thread(payRun);
        payThread.start();
    }
    public void  weichatPay(String appId,String partnerId,String prepayId,String nonceStr,String timeStamp,String sign){
        msgApi = WXAPIFactory.createWXAPI(this, appId);
        PayReq request = new PayReq();
        request.appId = appId;
        request.partnerId =partnerId;
        request.prepayId= prepayId;
        request.packageValue = "Sign=WXPay";
        request.nonceStr= nonceStr;
        request.timeStamp= timeStamp;
        request.sign=sign;
        Log.d("Unity",request.checkArgs()+"");//输出验签是否正确
        msgApi.sendReq(request);
    }
}