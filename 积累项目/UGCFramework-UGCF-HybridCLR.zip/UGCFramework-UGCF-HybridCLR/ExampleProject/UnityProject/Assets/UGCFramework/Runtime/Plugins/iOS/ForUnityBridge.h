#import <UIKit/UIKit.h>

@interface ForUnityBridge : UIResponder <UIApplicationDelegate>

+(instancetype)forUnityBridgeInstance;

@end