﻿using System.Collections;
using System.Collections.Generic;
using UGCF.Manager;
using UnityEngine;

public class Test3Node : Node
{
}
