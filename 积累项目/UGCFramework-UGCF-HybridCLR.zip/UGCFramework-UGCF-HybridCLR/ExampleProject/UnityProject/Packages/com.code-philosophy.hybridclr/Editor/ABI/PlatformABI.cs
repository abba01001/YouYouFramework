﻿namespace HybridCLR.Editor.ABI
{
    public enum PlatformABI
    {
        Universal32,
        Universal64,
        Arm64,
        WebGL32,
    }
}
