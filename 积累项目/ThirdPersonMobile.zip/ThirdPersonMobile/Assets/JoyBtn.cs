﻿/*******************************************************************
* Copyright(c) #YEAR# #COMPANY#
* All rights reserved.
*
* 文件名称: #SCRIPTFULLNAME#
* 简要描述:
* 
* 创建日期: #DATE#
* 作者:     #AUTHOR#
* 说明:  
******************************************************************/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JoyBtn : JoyStickButton
{
    public RectTransform Background;
    public RectTransform Knob;
    [Header("Input Values")]
    public float Horizontal = 0;
    public float Vertical = 0;


    public float offset;
    Vector2 PointPosition;
    // Use this for initialization
    public override void onTouchBegan(Touch pos)
    {
        Debug.Log(pos.position);
    }
    public override void onTouchEnd(Touch pos)
    {
        PointPosition = new Vector2(0f, 0f);
        Knob.transform.position = Background.position;
    }
    public override void onTouchMove(Touch pos)
    {
        PointPosition = new Vector2((pos.position.x - Background.position.x) / ((Background.rect.size.x - Knob.rect.size.x) / 2), (pos.position.y - Background.position.y) / ((Background.rect.size.y - Knob.rect.size.y) / 2));

        PointPosition = (PointPosition.magnitude > 1.0f) ? PointPosition.normalized : PointPosition;

        Knob.transform.position = new Vector2((PointPosition.x * ((Background.rect.size.x - Knob.rect.size.x) / 2) * offset) + Background.position.x, (PointPosition.y * ((Background.rect.size.y - Knob.rect.size.y) / 2) * offset) + Background.position.y);
    }
    public JoyCam joyCam;
    public Transform tag;
    public float angle;
    public float angle1;
    public bool isMove;
    public Vector3 ve3;

    public static float PointToAngle(Vector2 p1, Vector2 p2)
    {
        float angle = Mathf.Atan2(p2.y - p1.y, p2.x - p1.x) * 180 / Mathf.PI;

        if (angle >= 0 && angle <= 180)
        {
            return angle;
        }
        else
        {
            return 360 + angle;
        }
    }

    private void FixedUpdate()
    {
        Horizontal = PointPosition.x;
        Vertical = PointPosition.y;
        isMove = Mathf.Abs(Vertical - 0) > 0.2f || Mathf.Abs(Horizontal - 0) > 0.2f;
        joyCam.isMove = isMove;
        if (isMove)
        {
            Horizontal *= -1;
            Vertical *= -1;
            angle = PointToAngle(new Vector2(Vertical, Horizontal), Vector2.zero) - angle1 + Camera.main.transform.localEulerAngles.y;
            tag.transform.localEulerAngles = new Vector3(0, angle, 0);
            ve3 = Vector3.forward * 5f * Time.deltaTime;
            tag.transform.Translate(ve3);
        }
    }
}