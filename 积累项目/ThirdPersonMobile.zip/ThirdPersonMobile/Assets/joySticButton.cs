﻿/*******************************************************************
* Copyright(c) #YEAR# #COMPANY#
* All rights reserved.
*
* 文件名称: #SCRIPTFULLNAME#
* 简要描述:
* 
* 创建日期: #DATE#
* 作者:     #AUTHOR#
* 说明:  
******************************************************************/
using UnityEngine;

public class JoyStickButton : MonoBehaviour
{
    private bool active = false;
    public bool swallowTouch = true;
    // Start is called before the first frame update
    void Start()
    {

    }
    void OnDestroy()
    {

    }
    // Update is called once per frame
    void Update()
    {

    }
    public virtual  void onTouchBegan(Touch position)
    {
        Debug.Log("=========onTouchBegan=========: " + gameObject.name);
    }
    public virtual  void onTouchMove(Touch position)
    {
        Debug.Log("=========onTouchMove=========: " + gameObject.name);
    }
    public virtual void onTouchEnd(Touch position)
    {
        Debug.Log("=========onTouchEnd=========: " + gameObject.name);
    }
    public void setActive(bool state)
    {
        this.active = state;
    }
    public bool isActive()
    {
        return active;
    }
}
