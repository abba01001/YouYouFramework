﻿/*******************************************************************
* Copyright(c) #YEAR# #COMPANY#
* All rights reserved.
*
* 文件名称: #SCRIPTFULLNAME#
* 简要描述:
* 
* 创建日期: #DATE#
* 作者:     #AUTHOR#
* 说明:  
******************************************************************/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JoyCam : JoyStickButton
{
    public GameObject camTag;
    public GameObject target;
    public Vector3 offset = new Vector3(0, 1.6f, -3f);
    public bool isSelf = false;
    public bool isMove = false;
    public bool isRotating = false;
    public float distance = 0f;
    public float scrollSpeed = 0.5f;

    public float rotateSpeed = 2;
    public float mousex;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (isMove)
        {
           camTag.transform.localPosition = target.transform.localPosition + offset;
        }
        if (isRotating && isMove)
        {
            target.transform.localEulerAngles = new Vector3(target.transform.localEulerAngles.x, target.transform.localEulerAngles.y + mousex, target.transform.localEulerAngles.z);
        }
       camTag.transform.LookAt(new Vector3(target.transform.localPosition.x, target.transform.localPosition.y + 1f, target.transform.localPosition.z));

        Debug.Log("isRotating  " + isRotating + " isMove  " + isMove);
    }

    public override void onTouchBegan(Touch touch)
    {
        isRotating = false;
    }
    public override void onTouchEnd(Touch touch)
    {
        isRotating = false;
    }
    public override void onTouchMove(Touch touch)
    {
        isRotating = true;
        distance = offset.magnitude;
        distance += touch.deltaPosition.y * -scrollSpeed;
        distance = Mathf.Clamp(distance, 1.0f, 7.0f);
        offset = offset.normalized * distance;
       camTag.transform.localPosition = target.transform.localPosition + offset;
        mousex = touch.deltaPosition.x * rotateSpeed;
       camTag.transform.RotateAround(target.transform.localPosition, target.transform.up, mousex);
        offset =camTag.transform.localPosition - target.transform.localPosition;
    }
}