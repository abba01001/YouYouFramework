# AliPayAndWxPayToUnity
支付宝和微信支付接入Unity，安卓端的工程文件

接入文档：http://toxicstar.top/index.php/archives/89/
