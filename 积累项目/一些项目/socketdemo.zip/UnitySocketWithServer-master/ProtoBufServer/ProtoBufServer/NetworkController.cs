﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace ProtoBufServer
{
    public class NetworkController
    {
        //接收到客户端聊天消息
        public static void ReceiveChat(RequestChat data, ClientSocket client)
        {
            if (client != null)
            {
                ChatInfo chatInfo = new ChatInfo();
                chatInfo.channel = data.channel;
                chatInfo.content = data.content;
                chatInfo.player_info = null;
                Console.WriteLine("聊天信息:" + data.content + "+++频道:"+ data.channel);
                SendChat(client,"",chatInfo);
            }
        }

        //返回客户端聊天消息
        //这里广播客户端信息 TODO
        public static void SendChat(ClientSocket client, string _error,ChatInfo chat_Info)
        {
            ResponseChat response = new ResponseChat()
            {
                proto = (int)CmdEnum.Res_Chat,
                error = _error,
                chat_info = chat_Info,
            };

            byte[] bytes = ProtobufTool.CreateData(response.proto, response);
            Program.ClientBroadcastChat(bytes);
            //client.socket.Send(bytes);
        }

        //接收到客户端注册消息
        public static void ReceiveRegister(RequestRegister data, ClientSocket client)
        {
            if (client != null)
            {
                Console.WriteLine("注册用户:" + data.account);
                Player player = new Player(data.account, data.password, data.username);
                UnityGameServer.Instance.Players.Add(player);
                if (UnityGameServer.Instance.Save())
                {
                    PlayerInfo info = new PlayerInfo()
                    {
                        id = player.id,
                        account = player.account,
                        username = player.username,
                        passwrod = player.password
                    };

                    SendRegister(client, info, "");
                }
                else
                {
                    SendRegister(client, null, "注册失败");
                }
            }
        }

        //返回客户端注册消息
        public static void SendRegister(ClientSocket client,PlayerInfo info,string _error)
        {
            ResponseRegister response = new ResponseRegister() 
            {
                proto = (int)CmdEnum.Res_Register,
                error = _error,
                player_info = info
            };

            byte[] bytes = ProtobufTool.CreateData(response.proto, response);
            client.socket.Send(bytes);

        }

        //接收到客户端登录消息
        public static void ReceiveLogin(RequestLogin data,ClientSocket client)
        {
            //记录用户名
            if (client != null)
            {
                Player player = UnityGameServer.Instance.GetPlayerByAccount(data.account);
                if (player != null)
                {
                    if (player.password == data.password)
                    {
                        SendLogin(client,player,"", "登陆成功");
                        Console.WriteLine("登录用户：UserName={0}", data.account);
                    }
                    else
                    {
                        SendLogin(client,null,"密码不正确", "登陆失败");
                        Console.WriteLine("登录用户密码不正确：UserName={0}", data.account);
                    }
                }
                else
                {
                    SendLogin(client,null, "账号不存在", "登陆失败");
                    Console.WriteLine("登录用户账号不存在：UserName={0}", data.account);
                }
            }
        }

        //返回客户端登录消息
        public static void SendLogin(ClientSocket client,Player player,string error,string result)
        {
            ResponseLogin response = new ResponseLogin()
            {
                proto = (int)CmdEnum.Res_Login,
                error = error,
                result = result
            };

            if (player != null)
            {
                response.player = new PlayerInfo()
                {
                    id = player.id,
                    account = player.account,
                    passwrod = player.password,
                    username = player.username
                };
            }
            byte[] bytes = ProtobufTool.CreateData(response.proto, response);
            client.socket.Send(bytes);
        }

        //接收客户端心跳消息
        public static void ReceiveAlive(ClientSocket client)
        {
            if (client != null)
            {
                client.SetTicks(DateTime.Now.Ticks);
                SendAlive(client);
            }
        }

        //返回客户端心跳消息
        public static void SendAlive(ClientSocket client)
        {
            ResponseAlive response = new ResponseAlive()
            {
                proto = (int)CmdEnum.Res_Alive
            };
            byte[] bytes = ProtobufTool.CreateData(response.proto, response);
            client.socket.Send(bytes);
        }

        //接收客户端创建房间的消息
        public static void ReceiveCreateRoom(RequestCreateRoom req,ClientSocket m)
        {
            if (m != null)
            {
                RoomInfo info = RoomController.Instance.CreateRoom(m,req.player_id, req.room_name, req.password, req.can_watch, req.player_number);
                if (info != null)
                {
                    SendCreateRoom(m, info.room, "");
                    Console.WriteLine("{0}创建房间{1}",req.player_id,req.room_name);
                }
                else
                {
                    SendCreateRoom(m, null, "创建房间失败");
                    Console.WriteLine("{0}创建房间{1}失败", req.player_id, req.room_name);
                }
            }
        }

        //返回客户端创建房间的消息
        public static void SendCreateRoom(ClientSocket client,GameRoomInfo info,string error)
        {
            ResponseCreateRoom response = new ResponseCreateRoom()
            {
                proto = (int)CmdEnum.Res_CreateRoom,
                room = info,
                error = error
            };
            byte[] bytes = ProtobufTool.CreateData(response.proto, response);
            client.socket.Send(bytes);
        }


        //接收客户端获取房间列表的消息
        public static void ReceiveGetRooms(RequestGetRooms req,ClientSocket m)
        {
            if (m != null)
            {
                List<GameRoomInfo> infos = RoomController.Instance.GetRooms();
                SendGetRooms(m, infos);
                Console.WriteLine("{0}请求房间列表", m.socket.RemoteEndPoint.ToString());
            }
        }

        //返回客户端获取房间列表的消息
        public static void SendGetRooms(ClientSocket m,List<GameRoomInfo> infos)
        {
            ResponseGetRooms response = new ResponseGetRooms()
            {
                proto = (int)CmdEnum.Res_GetRooms,
            };
            response.rooms.AddRange(infos);

            byte[] bytes = ProtobufTool.CreateData(response.proto, response);
            m.socket.Send(bytes);
        }

        //接收客户端删除房间的消息
        public static void ReceiveDeleteRoom(RequestDeleteRoom req,ClientSocket m)
        { 
        }

        //返回客户端删除房间的消息
        public static void SendDeleteRoom()
        { 
        }
    }
}
