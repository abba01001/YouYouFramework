﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using ProtoBuf;
using ProtoBufServer;
using System.Net.Sockets;

/// <summary>
/// 字节控制类，一个单例类，用于缓存服务器发过来的所有byte数据，用于解决黏包、分包的问题
/// </summary>
public class ByteController
{
    private static ByteController m_self = null;
    public static ByteController Instance
    {
        get
        {
            if (m_self == null)
            {
                m_self = new ByteController();
            }
            return m_self;
        }
    }

    private ByteController() { }

    private Dictionary<Socket, List<byte>> Datas = new Dictionary<Socket, List<byte>>();
    private ByteBuffer buffer;

    public void AddBytes(Socket s,byte[] data,Action<Socket,CmdEnum,byte[]> HandleReceiveData)
    {
        //lock (Datas)
        {
            if (Datas.ContainsKey(s))
            {
                Datas[s].AddRange(data);
            }
            else
            {
                List<byte> l = new List<byte>();
                l.AddRange(data);
                Datas.Add(s, l);
            }
            buffer = ReadBytes(s);
            while (buffer != null)
            {
                int datalength = buffer.ReadShort();
                int typeId = buffer.ReadInt();
                byte[] pbdata = buffer.ReadBytes();

                HandleReceiveData(s, (CmdEnum)typeId, pbdata);
                buffer = ReadBytes(s);
            }
        }
    }

    public ByteBuffer ReadBytes(Socket s)
    {
        //lock (Datas)
        {
            if (!Datas.ContainsKey(s))
            {
                return null;
            }
            byte[] b = new byte[ProtobufTool.headLength];
            Array.Copy(Datas[s].ToArray(), 0, b, 0, b.Length);
            int dataLength = (int)BitConverter.ToInt16(b,0);

            //取出数据长度段
            if (Datas[s].Count >= ProtobufTool.headLength + dataLength)
            {
                //取出数据段
                byte[] data = new byte[ProtobufTool.headLength + dataLength];
                Array.Copy(Datas[s].ToArray(), 0, data, 0, dataLength + ProtobufTool.headLength);
                Datas[s].RemoveRange(0, ProtobufTool.headLength + dataLength);

                //如果这个没有了消息，则清除这个键值对
                if (Datas[s].Count <= 0)
                {
                    Datas.Remove(s);
                }

                return new ByteBuffer(data);
            }
            else
            {
                return null;
            }
        }
    }
}
