﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ProtoBuf;

namespace ProtoBufServer
{
    public class Program
    {
        private static byte[] result = new byte[10];
        private const int port = 8088;
        private static string IpStr = "127.0.0.1";
        private static Socket serverSocket;

        //心跳检测间隔
        private static int DisconnectTimeOut = 60;

        private static List<ClientSocket> AllClients = new List<ClientSocket>();

        static void Main(string[] args)
        {

            Console.Title = "测试服务器端主程序";

            IPAddress ip = IPAddress.Parse(IpStr);
            IPEndPoint ip_end_point = new IPEndPoint(ip, port);
            //创建服务器Socket对象，并设置相关属性  
            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //绑定ip和端口  
            serverSocket.Bind(ip_end_point);
            //设置最长的连接请求队列长度  
            serverSocket.Listen(10);
            Console.WriteLine("启动监听{0}成功", serverSocket.LocalEndPoint.ToString());

            //开启监听客户端连接
            ThreadPool.QueueUserWorkItem(ClientConnectListen);

            //开启心跳检测连接线程
            ThreadPool.QueueUserWorkItem(ClientAliveListen);

            Console.ReadLine();
        }

        //心跳连接线程
        private static void ClientAliveListen(object obj)
        {
            while (true)
            {
                Console.WriteLine("+++++++++心跳检测开始+++++++++时间:{0},连接客户端数目:{1}",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), AllClients.Count);
                for (int i = 0; i < AllClients.Count; i++)
                {
                    if (AllClients[i].CheckConnectState(DisconnectTimeOut))
                    {
                        continue;
                    }
                    else
                    {
                        //关闭当前连接
                        Console.WriteLine("关闭客户端连接:" + AllClients[i].ip);
                        
                        AllClients[i].socket.Close();
                        AllClients[i] = null;
                    }
                }
                int count = AllClients.Count;
                for (int i = 0; i < count; i++)
                {
                    AllClients.Remove(null);
                }
                Thread.Sleep(5000);
            }
        }

        /// <summary>
        /// 广播聊天信息
        /// </summary>
        /// <param name="bytes"></param>
        public static void ClientBroadcastChat(byte[] bytes)
        {
            for (int i = 0; i < AllClients.Count; i++)
            {
                if (AllClients[i]!= null && AllClients[i].socket.Connected)
                {
                    AllClients[i].socket.Send(bytes);
                }
            }
        }

        /// <summary>  
        /// 客户端连接请求监听  
        /// </summary>  
        private static void ClientConnectListen(object obj)
        {
            while (true)
            {
                //为新的客户端连接创建一个Socket对象  
                Socket clientSocket = serverSocket.Accept();

                //这里挂起线程，如果有客户端连接，则代码往下跑
                ClientSocket mSocket = new ClientSocket(clientSocket);

                AllClients.Add(mSocket);
                Console.WriteLine("客户端{0}成功连接", clientSocket.RemoteEndPoint.ToString());
                
                //每个客户端连接创建一个线程来接受该客户端发送的消息  
                Thread thread = new Thread(RecieveMessage);
                thread.Start(clientSocket);

                //记录当前线程
                mSocket.SetThread(thread);
            }
        }

        public static ClientSocket GetClientSocket(Socket m)
        {
            for (int i = 0; i < AllClients.Count; i++)
            {
                if (m.RemoteEndPoint.ToString() == AllClients[i].ip)
                {
                    return AllClients[i];
                }
            }
            return null;
        }

        /// <summary>  
        /// 接收指定客户端Socket的消息  
        /// </summary>  
        /// <param name="clientSocket"></param>  
        private static void RecieveMessage(object clientSocket)
        {
            Socket mClientSocket = (Socket)clientSocket;
            while (true)
            {
                try
                {
                    int receiveNumber = mClientSocket.Receive(result);
                    if(receiveNumber > 0)
                    {
                        byte[] r = new byte[receiveNumber];
                        Array.Copy(result, 0, r, 0, r.Length);
                        ByteController.Instance.AddBytes(mClientSocket,r, HandleReceiveData);
                    }
                    else if (receiveNumber == 0 || receiveNumber == -1)
                    {
                        mClientSocket.Close();
                        break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("ReceiveMessage Class(ex):" + ex.Message);
                    if (mClientSocket != null)
                    {
                        try
                        {
                            mClientSocket.Close();
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("ReceiveMessage Class(e):" + e.Message);
                        }
                    }
                    break;
                }
            }
        }

        //接收客户端发送的数据
        public static void HandleReceiveData(Socket socket, CmdEnum cmd, byte[] data)
        {
            ClientSocket m = GetClientSocket(socket);
            if (m == null)
            {
                socket.Close();
                return;
            }

            //通过协议号判断选择的解析类  
            if (cmd == CmdEnum.Req_Login)
            {
                RequestLogin clientReq = SerializeTool.Deserialize<RequestLogin>(data);
                NetworkController.ReceiveLogin(clientReq, m);
            }
            else if (cmd == CmdEnum.Req_Alive)
            {
                NetworkController.ReceiveAlive(m);
            }
            else if (cmd == CmdEnum.Req_Register)
            {
                RequestRegister req = SerializeTool.Deserialize<RequestRegister>(data);
                NetworkController.ReceiveRegister(req, m);
            }
            else if (cmd == CmdEnum.Req_Chat)
            {
                RequestChat req = SerializeTool.Deserialize<RequestChat>(data);
                NetworkController.ReceiveChat(req, m);
            }
            else if (cmd == CmdEnum.Req_CreateRoom)
            {
                RequestCreateRoom req = SerializeTool.Deserialize<RequestCreateRoom>(data);
                NetworkController.ReceiveCreateRoom(req, m);
            }
            else if (cmd == CmdEnum.Req_GetRooms)
            {
                RequestGetRooms req = SerializeTool.Deserialize<RequestGetRooms>(data);
                NetworkController.ReceiveGetRooms(req, m);
            }
            else if (cmd == CmdEnum.Req_DeleteRoom)
            {
                RequestDeleteRoom req = SerializeTool.Deserialize<RequestDeleteRoom>(data);
                NetworkController.ReceiveDeleteRoom(req, m);
            }
        }
    }
}
