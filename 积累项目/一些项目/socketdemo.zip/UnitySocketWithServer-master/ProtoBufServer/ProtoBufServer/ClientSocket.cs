﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProtoBufServer
{
    public class ClientSocket
    {
        public string userName;
        public string ip;
        public long ticks;
        public Socket socket;
        public Thread receiveThread;

        public ClientSocket(Socket mSocket)
        {
            if (mSocket != null)
            {
                ticks = DateTime.Now.Ticks;
                socket = mSocket;
                ip = mSocket.RemoteEndPoint.ToString();
                userName = "";
            }
        }

        public void SetUserName(string name)
        {
            userName = name;
        }

        /// <summary>
        /// 客户端每次心跳设置一次时间
        /// </summary>
        /// <param name="ticks"></param>
        public void SetTicks(long ticks)
        {
            this.ticks = ticks;
        }

        public void SetThread(Thread t)
        {
            receiveThread = t;
        }

        /// <summary>
        /// 检测客户端连接状态
        /// </summary>
        /// <param name="sec">检测间隔秒数</param>
        /// <returns></returns>
        public bool CheckConnectState(long sec)
        {
            long temp = DateTime.Now.Ticks - ticks;
            if ((temp / 10000000) > sec)
            {
                return false;
            }
            return true;
        }
    }
}
