public static class GameData
{
    public static PlayerInfo playerInfo;
}
